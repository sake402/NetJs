
//--TRIMMABLE-BOUNDARY-START(25501)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $XAXWCb;
    let $dfcWxj;
    let $cWusIc;
    let $uWpzqk;
    let $VGYwUb;
    let $JKYTjb;
    let $GvNvcj;
    let $jZOPId;
    let $syEaIi;
    let $ReqlOa;
    let $qLEdba;
    let $UbDDXj;
    let $BhWKqg;
    let $nRhJfj;
    let $NckNfl;
    let $VceaKg;
    let $vySRQf;
    let $tHYiie;
    let $cjwOcb;
    let $MFRNwi;
    let $FhxHLk;
    let $TgPgCh;
    let $JOubfd;
    let $oHMxld;
    let $AvSSKf;
    let $XMtEEk;
    let $DhrUPg;
    let $DzNAdc;
    let $DouGqc;
    let $YdTqdf;
    let $iflhoi;
    let $hSUzye;
    let $QxTxnf;
    let $RaWMDg;
    let $bIpRgj;
    let $ERAwke;
    let $PWmtCg;
    let $gCryhc;
    let $ppovak;
    let $MTxdud;
    let $WHsmdj;
    let $FdkXYa;
    let $xRvqVk;
    let $bVCyga;
    let $GGIOKg;
    let $FFUCue;
    let $vRLHBe;
    let $TqZJFa;
    let $dyqlVc;
    let $RaCUwc;
    let $OPeUAd;
    let $ELbzRk;
    let $KlpDcj;
    let $vMGoSi;
    let $fBCjra;
    let $cvwFMi;
    let $nlrkJc;
    let $sXsyej;
    let $nAYQNh;
    let $leZkDh;
    let $ItFLXg;
    let $IJerma;
    let $iFGNgd;
    let $bzPtPh;
    let $Cneqjl;
    let $ZmrzRc;
    let $zYwAce;
    let $DSqMWj;
    let $oqCkph;
    let $CXHCqj;
    let $dRILHc;
    let $tpLUVb;
    let $cWlXSa;
    let $UaKIui;
    let $HpZFbf;
    let $OntvFi;
    let $qJWHwd;
    let $cIqotj;
    let $fYBBzk;
    let $SJcMba;
    let $XqhMTe;
    let $ETFJRi;
    let $Ctryrc;
    let $SNCblk;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.GreenHouseLogger", 
    {
  "h": 25501,
  "f": "LivingThing.Core.IOT.Devices.GreenHouseLogger",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.GreenHouseLogger",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.GreenHouseLogger",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5HcmVlbkhvdXNlTG9nZ2VyLkdyZWVuSG91c2VMb2dnZXJEZXZpY2UiOiB7DQogICAgICAiQ2F0ZWdvcmllcyI6IFsgIlNtYXJ0IEhvbWUiIF0sDQogICAgICAiTmFtZSI6ICJHcmVlbkhvdXNlTG9nZ2VyIiwNCiAgICAgICJJY29uIjogeyAiTmFtZSI6ICJtZGkgbWRpLXNvbGFyLXBhbmVsIiB9LA0KICAgICAgIlRoZW1lQ29sb3IiOiAiI2ZiZjIzNiIsDQogICAgICAiRGVzY3JpcHRpb24iOiAiUnVuIHRvcCBub3RjaCBtb25pdG9yaW5nLCBhbmFseXRpY3MgYW5kIGRpYWdub3N0aWNzIG9uIHNvbGFyIGludmVydGVyIGluc3RhbGxhdGlvbi4iLA0KICAgICAgIkJhbm5lckltYWdlIjogIn4vaW1nL2Jhbm5lci5qcGciLA0KICAgICAgIlNjb3BlIjogIkhvbWUiLA0KICAgICAgIlNlY3VyaXRpZXMiOiAiQ2hhbGxlbmdlSGFuZFNoYWtlQXV0aGVudGljYXRpb25Qcm90b2NvbCxBZHZhbmNlZEVuY3J5cHRpb25TdGFuZGFyZCxFbGxpcHRpY0N1cnZlRmlybXdhcmVVcGRhdGVTaWduaW5nIiwNCiAgICAgICJTdGF0dXNlcyI6IFsgIlN0YXR1cy5Tb2xhclZvbHRhZ2UiLCAiU3RhdHVzLkJhdHRlcnlWb2x0YWdlIiwgIlN0YXR1cy5JbnZlcnRlckN1cnJlbnQiIF0sDQogICAgICAiQ29uZmlndXJhdGlvbnMiOiB7DQogICAgICAgICJsb2dTdW0iOiB7ICJMYWJlbCI6ICJMb2cgRGFpbHkgU3VtbWFyeSIgfSwNCiAgICAgICAgImxvZ2RWIjogeyAiTGFiZWwiOiAiTG9nIFZvbHRhZ2UgQ2hhbmdlIiB9LA0KICAgICAgICAibG9nZEkiOiB7ICJMYWJlbCI6ICJMb2cgQ3VycmVudCBDaGFuZ2UiIH0sDQogICAgICAgICJsb2dTZWMiOiB7ICJMYWJlbCI6ICJNaW5pbXVtIGxvZyBpbnRlcnZhbChzKSIgfSwNCiAgICAgICAgInJldiI6IHsgIkxhYmVsIjogIlBvbGFyaXR5IENvbnRyb2wiIH0NCiAgICAgIH0NCiAgICB9DQogIH0NCn0="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2122653)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerLog`, ($self) => class GreenHouseLoggerLog extends $.$XBGm.LCICDi.iSmartDeviceLogModel
        {
            //--TRIMMABLE-BOUNDARY-START(12887024541)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887024541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Time.GetHashCode();
            }
            //--TRIMMABLE-BOUNDARY-END(12887024541)
            
            //--TRIMMABLE-BOUNDARY-START(8592057245)
            /*bool */ Equals$1(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592057245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let log;
                if ($.$is(obj, $.$CgOi.LCIDGM.GreenHouseLoggerLog, { set $v($v){ log = $v; } }))
                {
                    return $.$$.S.DateTime.op_Equality(log.Time, this.Time);
                }
                return $.$$.S.Object.Equals$1.call(this, obj);
            }
            //--TRIMMABLE-BOUNDARY-END(8592057245)
            
            //--TRIMMABLE-BOUNDARY-START(4297089949)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297089949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297089949)
            
            //--TRIMMABLE-BOUNDARY-START(4297089949)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297089949)
            
            static $h = 2122653;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceLogModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887024541),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2122653,
      "h": 12887024541,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12887024541),
//--TRIMMABLE-BOUNDARY-START(8592057245),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2122653,
      "h": 8592057245,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8592057245)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297089949),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2122653,
      "h": 4297089949,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297089949)
  ],
  "h": 2122653,
  "a": [
    {
      "t": 31361366,
      "c": 8621295958,
      "n": [
        {
          "n": "Provider",
          "v": 2974621,
          "t": 188547073
        }
      ]
    },
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Flags",
          "v": 0,
          "t": 655361
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceLog, $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerLog`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerLog`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2122653)
        
        

        //--TRIMMABLE-BOUNDARY-START(2253725)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModelCustomAttributesProvider`, ($self) => class GreenHouseLoggerResetQuotaModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297221021)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297221021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297221021)
            
            static $h = 2253725;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297221021),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2253725,
      "h": 4297221021,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297221021)
  ],
  "h": 2253725
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerResetQuotaModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerResetQuotaModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2253725)
        
        

        //--TRIMMABLE-BOUNDARY-START(1139613)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerDeviceModelCustomAttributesProvider`, ($self) => class GreenHouseLoggerDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296106909)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296106909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296106909)
            
            static $h = 1139613;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296106909),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1139613,
      "h": 4296106909,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296106909)
  ],
  "h": 1139613
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1139613)
        
        

        //--TRIMMABLE-BOUNDARY-START(1926045)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModelCustomAttributesProvider`, ($self) => class GreenHouseLoggerDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296893341)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296893341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceSendDataModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296893341)
            
            static $h = 1926045;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296893341),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1926045,
      "h": 4296893341,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296893341)
  ],
  "h": 1926045
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1926045)
        
        

        //--TRIMMABLE-BOUNDARY-START(3761053)
        $asm.$cls(`$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class GreenHouseLoggerDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298728349)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298728349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298728349)
            
            static $h = 3761053;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298728349),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3761053,
      "h": 4298728349,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298728349)
  ],
  "h": 3761053
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Settings${separator}GreenHouseLoggerDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3761053)
        
        

        //--TRIMMABLE-BOUNDARY-START(1663901)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModelCustomAttributesProvider`, ($self) => class GreenHouseLoggerDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296631197)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296631197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296631197)
            
            static $h = 1663901;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296631197),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1663901,
      "h": 4296631197,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296631197)
  ],
  "h": 1663901
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1663901)
        
        

        //--TRIMMABLE-BOUNDARY-START(1401757)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class GreenHouseLoggerDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296369053)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296369053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$$($.$CgOi.LCIDGM.GreenLoggerStatus, $.$CgOi.LCIDGM.GreenHouseLoggerLog).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296369053)
            
            static $h = 1401757;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296369053),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1401757,
      "h": 4296369053,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296369053)
  ],
  "h": 1401757
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1401757)
        
        

        //--TRIMMABLE-BOUNDARY-START(2515869)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerServiceModelCustomAttributesProvider`, ($self) => class GreenHouseLoggerServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297483165)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297483165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297483165)
            
            static $h = 2515869;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297483165),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2515869,
      "h": 4297483165,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297483165)
  ],
  "h": 2515869
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2515869)
        
        

        //--TRIMMABLE-BOUNDARY-START(287645)
        $asm.$cls(`$CgOi.LCIDG.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295254941)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295254941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelCustomAttributesProvider, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerDeviceModelCustomAttributesProvider, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModelCustomAttributesProvider, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModelCustomAttributesProvider, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModelCustomAttributesProvider, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModelCustomAttributesProvider, $.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerServiceModelCustomAttributesProvider, $.$CgOi.LCIDGM.GreenHouseLoggerServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CgOi.LCIDGM.GreenHouseLoggerZeroModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerZeroModelCustomAttributesProvider, $.$CgOi.LCIDGM.GreenHouseLoggerZeroModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsCustomAttributesProvider, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsCustomAttributesProvider, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295254941)
            
            static $h = 287645;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295254941),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 287645,
      "h": 4295254941,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295254941)
  ],
  "h": 287645
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(287645)
        
        

        //--TRIMMABLE-BOUNDARY-START(2057117)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class GreenHouseLoggerDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591991709)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591991709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $cWusIc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2057117,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591991709)
            
            //--TRIMMABLE-BOUNDARY-START(4297024413)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297024413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297024413)
            
            //--TRIMMABLE-BOUNDARY-START(4297024413)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297024413)
            
            static $h = 2057117;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591991709),
    {
      "r": 65537,
      "n": "Register",
      "d": 2057117,
      "h": 8591991709,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591991709)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297024413),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2057117,
      "h": 4297024413,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297024413)
  ],
  "h": 2057117
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2057117)
        
        

        //--TRIMMABLE-BOUNDARY-START(2778013)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerZeroModelCustomAttributesProvider`, ($self) => class GreenHouseLoggerZeroModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297745309)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297745309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297745309)
            
            static $h = 2778013;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297745309),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2778013,
      "h": 4297745309,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297745309)
  ],
  "h": 2778013
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerZeroModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerZeroModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2778013)
        
        

        //--TRIMMABLE-BOUNDARY-START(4023197)
        $asm.$cls(`$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsCustomAttributesProvider`, ($self) => class GreenHouseLoggerDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298990493)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298990493)
            
            //--TRIMMABLE-BOUNDARY-START(8593957789)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593957789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("BatteryCapacity", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Unit=Ah"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $VGYwUb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4023197,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $JKYTjb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4023197,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593957789)
            
            static $h = 4023197;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593957789),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4023197,
      "h": 8593957789,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593957789)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298990493),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4023197,
      "h": 4298990493,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298990493)
  ],
  "h": 4023197
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Settings${separator}GreenHouseLoggerDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4023197)
        
        

        //--TRIMMABLE-BOUNDARY-START(1270685)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerDeviceModelTypeDescriptorBuilder`, ($self) => class GreenHouseLoggerDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591205277)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591205277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModelTypeDescriptor()
                        const $t1 = $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $GvNvcj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1270685,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591205277)
            
            //--TRIMMABLE-BOUNDARY-START(4296237981)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296237981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296237981)
            
            //--TRIMMABLE-BOUNDARY-START(4296237981)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296237981)
            
            static $h = 1270685;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591205277),
    {
      "r": 65537,
      "n": "Register",
      "d": 1270685,
      "h": 8591205277,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591205277)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296237981),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1270685,
      "h": 4296237981,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296237981)
  ],
  "h": 1270685
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1270685)
        
        

        //--TRIMMABLE-BOUNDARY-START(1794973)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModelTypeDescriptorBuilder`, ($self) => class GreenHouseLoggerDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591729565)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591729565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $nRhJfj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1794973,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591729565)
            
            //--TRIMMABLE-BOUNDARY-START(4296762269)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296762269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296762269)
            
            //--TRIMMABLE-BOUNDARY-START(4296762269)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296762269)
            
            static $h = 1794973;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591729565),
    {
      "r": 65537,
      "n": "Register",
      "d": 1794973,
      "h": 8591729565,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591729565)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296762269),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1794973,
      "h": 4296762269,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296762269)
  ],
  "h": 1794973
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1794973)
        
        

        //--TRIMMABLE-BOUNDARY-START(2646941)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerServiceModelTypeDescriptorBuilder`, ($self) => class GreenHouseLoggerServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592581533)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592581533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CgOi.LCIDGM.GreenHouseLoggerServiceModelTypeDescriptor()
                        const $t1 = $.$CgOi.LCIDGM.GreenHouseLoggerServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $tHYiie ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2646941,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592581533)
            
            //--TRIMMABLE-BOUNDARY-START(4297614237)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297614237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297614237)
            
            //--TRIMMABLE-BOUNDARY-START(4297614237)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297614237)
            
            static $h = 2646941;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592581533),
    {
      "r": 65537,
      "n": "Register",
      "d": 2646941,
      "h": 8592581533,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592581533)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297614237),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2646941,
      "h": 4297614237,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297614237)
  ],
  "h": 2646941
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2646941)
        
        

        //--TRIMMABLE-BOUNDARY-START(1532829)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class GreenHouseLoggerDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591467421)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591467421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $VceaKg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1532829,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591467421)
            
            //--TRIMMABLE-BOUNDARY-START(4296500125)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296500125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296500125)
            
            //--TRIMMABLE-BOUNDARY-START(4296500125)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296500125)
            
            static $h = 1532829;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591467421),
    {
      "r": 65537,
      "n": "Register",
      "d": 1532829,
      "h": 8591467421,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591467421)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296500125),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1532829,
      "h": 4296500125,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296500125)
  ],
  "h": 1532829
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1532829)
        
        

        //--TRIMMABLE-BOUNDARY-START(156573)
        $asm.$cls(`$CgOi.LCIDG._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295123869)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295123869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$CgOi.LCIDG.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295123869)
            
            static $h = 156573;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295123869),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 156573,
      "h": 4295123869,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295123869)
  ],
  "h": 156573
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(156573)
        
        

        //--TRIMMABLE-BOUNDARY-START(4219805)
        $asm.$cls(`$CgOi.LCIDG.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4299187101)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299187101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptorBuilder.Register();
                $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModelTypeDescriptorBuilder.Register();
                $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModelTypeDescriptorBuilder.Register();
                $.$CgOi.LCIDGM.GreenHouseLoggerServiceModelTypeDescriptorBuilder.Register();
                $.$CgOi.LCIDGM.GreenHouseLoggerZeroModelTypeDescriptorBuilder.Register();
                $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4299187101)
            
            static $h = 4219805;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299187101),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 4219805,
      "h": 4299187101,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4299187101)
  ],
  "h": 4219805
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4219805)
        
        

        //--TRIMMABLE-BOUNDARY-START(1008541)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptorBuilder`, ($self) => class GreenHouseLoggerClassificationModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590943133)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590943133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor()
                        const $t1 = $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerClassificationModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $GGIOKg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1008541,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590943133)
            
            //--TRIMMABLE-BOUNDARY-START(4295975837)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295975837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295975837)
            
            //--TRIMMABLE-BOUNDARY-START(4295975837)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295975837)
            
            static $h = 1008541;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590943133),
    {
      "r": 65537,
      "n": "Register",
      "d": 1008541,
      "h": 8590943133,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590943133)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295975837),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1008541,
      "h": 4295975837,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295975837)
  ],
  "h": 1008541
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerClassificationModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerClassificationModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1008541)
        
        

        //--TRIMMABLE-BOUNDARY-START(4154269)
        $asm.$cls(`$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsTypeDescriptorBuilder`, ($self) => class GreenHouseLoggerDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594088861)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594088861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsTypeDescriptor()
                        const $t1 = $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $PWmtCg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4154269,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594088861)
            
            //--TRIMMABLE-BOUNDARY-START(4299121565)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299121565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299121565)
            
            //--TRIMMABLE-BOUNDARY-START(4299121565)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299121565)
            
            static $h = 4154269;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594088861),
    {
      "r": 65537,
      "n": "Register",
      "d": 4154269,
      "h": 8594088861,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594088861)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299121565),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4154269,
      "h": 4299121565,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299121565)
  ],
  "h": 4154269
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Settings${separator}GreenHouseLoggerDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4154269)
        
        

        //--TRIMMABLE-BOUNDARY-START(2909085)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerZeroModelTypeDescriptorBuilder`, ($self) => class GreenHouseLoggerZeroModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592843677)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592843677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CgOi.LCIDGM.GreenHouseLoggerZeroModelTypeDescriptor()
                        const $t1 = $.$CgOi.LCIDGM.GreenHouseLoggerZeroModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerZeroModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $DouGqc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2909085,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CgOi.LCIDGM.GreenHouseLoggerZeroModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592843677)
            
            //--TRIMMABLE-BOUNDARY-START(4297876381)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297876381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297876381)
            
            //--TRIMMABLE-BOUNDARY-START(4297876381)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297876381)
            
            static $h = 2909085;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592843677),
    {
      "r": 65537,
      "n": "Register",
      "d": 2909085,
      "h": 8592843677,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592843677)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297876381),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2909085,
      "h": 4297876381,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297876381)
  ],
  "h": 2909085
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerZeroModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerZeroModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2909085)
        
        

        //--TRIMMABLE-BOUNDARY-START(2384797)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModelTypeDescriptorBuilder`, ($self) => class GreenHouseLoggerResetQuotaModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592319389)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592319389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModelTypeDescriptor()
                        const $t1 = $.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerResetQuotaModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $hSUzye ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2384797,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592319389)
            
            //--TRIMMABLE-BOUNDARY-START(4297352093)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297352093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297352093)
            
            //--TRIMMABLE-BOUNDARY-START(4297352093)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297352093)
            
            static $h = 2384797;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592319389),
    {
      "r": 65537,
      "n": "Register",
      "d": 2384797,
      "h": 8592319389,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592319389)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297352093),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2384797,
      "h": 4297352093,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297352093)
  ],
  "h": 2384797
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerResetQuotaModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerResetQuotaModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2384797)
        
        

        //--TRIMMABLE-BOUNDARY-START(3892125)
        $asm.$cls(`$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class GreenHouseLoggerDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593826717)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593826717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $oqCkph ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3892125,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593826717)
            
            //--TRIMMABLE-BOUNDARY-START(4298859421)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298859421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298859421)
            
            //--TRIMMABLE-BOUNDARY-START(4298859421)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298859421)
            
            static $h = 3892125;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593826717),
    {
      "r": 65537,
      "n": "Register",
      "d": 3892125,
      "h": 8593826717,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593826717)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298859421),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3892125,
      "h": 4298859421,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298859421)
  ],
  "h": 3892125
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Settings${separator}GreenHouseLoggerDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3892125)
        
        

        //--TRIMMABLE-BOUNDARY-START(877469)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerClassificationModelCustomAttributesProvider`, ($self) => class GreenHouseLoggerClassificationModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295844765)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295844765)
            
            //--TRIMMABLE-BOUNDARY-START(8590812061)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590812061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(6, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("SolarHarvest", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Unit=Ah"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("UsageCharge", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Unit=Ah"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("InverterCharge", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Unit=Ah"], [-1], null);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PeakSolarCurrent", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Unit=A"], [-1], null);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PeakUsageCurrent", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Unit=A"], [-1], null);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PeakChargingCurrent", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Unit=A"], [-1], null);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $bIpRgj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":877469,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $ERAwke ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":877469,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICP.BaseDeviceDataClassificationModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590812061)
            
            static $h = 877469;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590812061),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 877469,
      "h": 8590812061,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590812061)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295844765),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 877469,
      "h": 4295844765,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295844765)
  ],
  "h": 877469
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerClassificationModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerClassificationModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(877469)
        
        

        //--TRIMMABLE-BOUNDARY-START(222109)
        $asm.$cls(`$CgOi.LCIDG.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180091293)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180091293)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295189405)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295189405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295189405)
            
            //--TRIMMABLE-BOUNDARY-START(4295189405)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295189405)
            
            static $h = 222109;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180091293),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885123997,
        "f": 50331649
      },
      "n": "Paths",
      "d": 222109,
      "h": 17180091293,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180091293)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295189405),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 222109,
      "h": 4295189405,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295189405)
  ],
  "h": 222109
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(222109)
        
        

        //--TRIMMABLE-BOUNDARY-START(3171229)
        $asm.$cls(`$CgOi.LCIDG.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17183040413)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$CgOi.LCIDGV.GreenHouseHistoryPage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$CgOi.LCIDGV.GreenHouseHistoryPage().$ctor$6();
                    }, $XAXWCb ??= {"r":2752627,"n":"","d":3171229,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$CgOi.LCIDGV.GreenHouseLoggerDeviceDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$CgOi.LCIDGV.GreenHouseLoggerDeviceDetails().$ctor$4();
                    }, $dfcWxj ??= {"r":2752627,"n":"","d":3171229,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17183040413)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4298138525)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298138525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298138525)
            
            //--TRIMMABLE-BOUNDARY-START(4298138525)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298138525)
            
            static $h = 3171229;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183040413),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888073117,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 3171229,
      "h": 17183040413,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17183040413)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298138525),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3171229,
      "h": 4298138525,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298138525)
  ],
  "h": 3171229
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3171229)
        
        

        //--TRIMMABLE-BOUNDARY-START(2974621)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLogPacketDataTypeProvider`, ($self) => class GreenHouseLogPacketDataTypeProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592909213)
            /*Type */ GetType$1(/*PacketBuilder*/ packet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592909213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                packet.GetByte(-1);
                /*var*/ let t = packet.GetByte(-1);
                return t === 0 ? $.$CgOi.LCIDGM.InstantLog.$type : $.$CgOi.LCIDGM.DailyLog.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8592909213)
            
            //--TRIMMABLE-BOUNDARY-START(4315646294)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IPacketBuilderDataTypeProvider.GetType(LivingThing.Core.Frameworks.Common.Data.PacketBuilder)
            LCFCD$IPacketBuilderDataTypeProvider$GetType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4315646294);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetType$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4315646294)
            
            //--TRIMMABLE-BOUNDARY-START(4297941917)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297941917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297941917)
            
            //--TRIMMABLE-BOUNDARY-START(4297941917)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297941917)
            
            static $h = 2974621;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592909213),
    {
      "r": 188547073,
      "p": [
        {
          "n": "packet",
          "p": 31164758
        }
      ],
      "n": "GetType",
      "o": "@$1",
      "d": 2974621,
      "h": 8592909213,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592909213)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297941917),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2974621,
      "h": 4297941917,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297941917)
  ],
  "h": 2974621
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IPacketBuilderDataTypeProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLogPacketDataTypeProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLogPacketDataTypeProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2974621)
        
        

        //--TRIMMABLE-BOUNDARY-START(3433373)
        $asm.$cls(`$CgOi.LCIDG.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593367965)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593367965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$CgOi.LCIDG.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$CgOi.LCIDG.GreenHouseLoggerDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$CgOi.LCIDG.GreenHouseLoggerDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$CgOi.LCIDG.GreenHouseLoggerDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$CgOi.LCIDG.GreenHouseLoggerDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$CgOi.LCIDG.GreenHouseLoggerDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$CgOi.LCIDG.GreenHouseLoggerDeviceFamily, x);
                }, $syEaIi ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":3433373,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$CgOi.LCIDG.GreenHouseLoggerDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$CgOi.LCIDG.GreenHouseLoggerDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $ReqlOa ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":3433373,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$CgOi.LCIDG.GreenHouseLoggerDevice)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$CgOi.LCIDG.GreenHouseLoggerDeviceFamily, x);
                }, $qLEdba ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$CgOi.LCIDG.GreenHouseLoggerDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":3433373,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$CgOi.LCIDG.GreenHouseLoggerDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICP.IIOTDeviceDataClassifier$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel), $.$CgOi.LCIDG.GreenHouseLoggerDataClassifier, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$CgOi.LCIDG.GreenHouseLoggerDevice, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$CgOi.LCIDG.GreenHouseLoggerDevice, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$CgOi.LCIDG.GreenHouseLoggerDevice, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$CgOi.LCIDG.GreenHouseLoggerDevice), $.$CgOi.LCIDGPC.GreenHouseDeviceCommands$$($.$CgOi.LCIDG.GreenHouseLoggerDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$hDPm.LCFCI.IViewProvider$$($.$CgOi.LCIDGM.InstantLog), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$CgOi.LCIDG.GreenHouseLoggerDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$CgOi.LCIDGV.GreenHouseLoggerViewRenderer, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$CgOi.LCIDG.GreenHouseLoggerDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$CgOi.LCIDGV.GreenHouseLoggerViewRenderer, x);
                }, $UbDDXj ??= {"r":$.$ntej.LCICD$1.IDeviceViewRenderer$$($.$CgOi.LCIDG.GreenHouseLoggerDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":3433373,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$hDPm.LCFCI.IViewProvider$$($.$CgOi.LCIDGM.InstantLog)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$CgOi.LCIDGV.GreenHouseLoggerViewRenderer, x);
                }, $BhWKqg ??= {"r":$.$hDPm.LCFCI.IViewProvider$$($.$CgOi.LCIDGM.InstantLog).$h,"p":[{"n":"x","p":327718}],"n":"","d":3433373,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8593367965)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$CgOi.LCIDG.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298400669)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298400669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298400669)
            
            //--TRIMMABLE-BOUNDARY-START(4298400669)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298400669)
            
            static $h = 3433373;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593367965),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3433373,
      "h": 8593367965,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593367965)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298400669),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3433373,
      "h": 4298400669,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298400669)
  ],
  "h": 3433373
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3433373)
        
        

        //--TRIMMABLE-BOUNDARY-START(4875165)
        $asm.$cls(`$CgOi.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299842461)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299842461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299842461)
            
            //--TRIMMABLE-BOUNDARY-START(4299842461)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299842461)
            
            static $h = 4875165;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299842461),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4875165,
      "h": 4299842461,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299842461)
  ],
  "h": 4875165
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4875165)
        
        

        //--TRIMMABLE-BOUNDARY-START(4940701)
        $asm.$cls(`$CgOi.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299907997)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299907997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299907997)
            
            //--TRIMMABLE-BOUNDARY-START(4299907997)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299907997)
            
            static $h = 4940701;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299907997),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4940701,
      "h": 4299907997,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299907997)
  ],
  "h": 4940701,
  "a": [
    {
      "t": 4875165,
      "c": 4299842461
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4940701)
        
        

        //--TRIMMABLE-BOUNDARY-START(2188189)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel`, ($self) => class GreenHouseLoggerResetQuotaModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297155485)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297155485);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297155485)
            
            //--TRIMMABLE-BOUNDARY-START(8592122781)
            /*int */ get Command()
            {
                return ((128 + 2) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(8592122781)
            
            //--TRIMMABLE-BOUNDARY-START(4297155485)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297155485)
            
            static $h = 2188189;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8592122781),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182057373,
        "f": 50364417
      },
      "n": "Command",
      "d": 2188189,
      "h": 8592122781,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592122781)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297155485),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2188189,
      "h": 4297155485,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297155485)
  ],
  "h": 2188189
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerResetQuotaModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerResetQuotaModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2188189)
        
        

        //--TRIMMABLE-BOUNDARY-START(2712477)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerZeroModel`, ($self) => class GreenHouseLoggerZeroModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297679773)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297679773);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297679773)
            
            //--TRIMMABLE-BOUNDARY-START(8592647069)
            /*int */ get Command()
            {
                return ((128 + 3) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(8592647069)
            
            //--TRIMMABLE-BOUNDARY-START(4297679773)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297679773)
            
            static $h = 2712477;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8592647069),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182581661,
        "f": 50364417
      },
      "n": "Command",
      "d": 2712477,
      "h": 8592647069,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592647069)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297679773),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2712477,
      "h": 4297679773,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297679773)
  ],
  "h": 2712477
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerZeroModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerZeroModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2712477)
        
        

        //--TRIMMABLE-BOUNDARY-START(3040157)
        $asm.$cls(`$CgOi.LCIDGM.GreenLoggerStatus`, ($self) => class GreenLoggerStatus extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(339305456541)
            /*double*/ SolarVoltage = 0;
            //--TRIMMABLE-BOUNDARY-END(339305456541)
            
            //--TRIMMABLE-BOUNDARY-START(330715521949)
            /*double*/ SolarCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(330715521949)
            
            //--TRIMMABLE-BOUNDARY-START(73017484189)
            /*double*/ BatteryVoltage = 0;
            //--TRIMMABLE-BOUNDARY-END(73017484189)
            
            //--TRIMMABLE-BOUNDARY-START(201866503069)
            /*double*/ InverterChargeCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(201866503069)
            
            //--TRIMMABLE-BOUNDARY-START(352190358429)
            /*double*/ UsageCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(352190358429)
            
            //--TRIMMABLE-BOUNDARY-START(335010489245)
            /*double*/ SolarHarvest = 0;
            //--TRIMMABLE-BOUNDARY-END(335010489245)
            
            //--TRIMMABLE-BOUNDARY-START(64427549597)
            /*double*/ BatteryCharge = 0;
            //--TRIMMABLE-BOUNDARY-END(64427549597)
            
            //--TRIMMABLE-BOUNDARY-START(197571535773)
            /*double*/ InverterCharge = 0;
            //--TRIMMABLE-BOUNDARY-END(197571535773)
            
            //--TRIMMABLE-BOUNDARY-START(347895391133)
            /*double*/ UsageCharge = 0;
            //--TRIMMABLE-BOUNDARY-END(347895391133)
            
            //--TRIMMABLE-BOUNDARY-START(214751404957)
            /*double*/ MaximumSolarCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(214751404957)
            
            //--TRIMMABLE-BOUNDARY-START(206161470365)
            /*double*/ MaximumChargeCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(206161470365)
            
            //--TRIMMABLE-BOUNDARY-START(210456437661)
            /*double*/ MaximumLoadCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(210456437661)
            
            //--TRIMMABLE-BOUNDARY-START(343600423837)
            /*bool*/ Switch = false;
            //--TRIMMABLE-BOUNDARY-END(343600423837)
            
            //--TRIMMABLE-BOUNDARY-START(68722516893)
            /*double */ get BatteryCurrent()
            {
                return this.SolarCurrent + this.InverterChargeCurrent + this.UsageCurrent;
            }
            //--TRIMMABLE-BOUNDARY-END(68722516893)
            
            //--TRIMMABLE-BOUNDARY-START(60132582301)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132582301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60132582301)
            
            //--TRIMMABLE-BOUNDARY-START(60132582301)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(60132582301)
            
            static $h = 3040157;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(339305456541),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167506764701,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300650750877,
        "f": 83886081
      },
      "n": "SolarVoltage",
      "d": 3040157,
      "h": 339305456541,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 501,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//ThresholdChanges=0.25",
                "//Unit=V"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(339305456541),
//--TRIMMABLE-BOUNDARY-START(330715521949),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150326895517,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283470881693,
        "f": 83886081
      },
      "n": "SolarCurrent",
      "d": 3040157,
      "h": 330715521949,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 502,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//ThresholdChanges=1",
                "//Unit=A"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(330715521949),
//--TRIMMABLE-BOUNDARY-START(73017484189),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98787287965,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231931274141,
        "f": 83886081
      },
      "n": "BatteryVoltage",
      "d": 3040157,
      "h": 73017484189,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 503,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//ThresholdChanges=0.25",
                "//Unit=V"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73017484189),
//--TRIMMABLE-BOUNDARY-START(201866503069),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115967157149,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249111143325,
        "f": 83886081
      },
      "n": "InverterChargeCurrent",
      "d": 3040157,
      "h": 201866503069,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 504,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//ThresholdChanges=1",
                "//Unit=A"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201866503069),
//--TRIMMABLE-BOUNDARY-START(352190358429),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193276568477,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 326420554653,
        "f": 83886081
      },
      "n": "UsageCurrent",
      "d": 3040157,
      "h": 352190358429,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 505,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//ThresholdChanges=1",
                "//Unit=A"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(352190358429),
//--TRIMMABLE-BOUNDARY-START(335010489245),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158916830109,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292060816285,
        "f": 83886081
      },
      "n": "SolarHarvest",
      "d": 3040157,
      "h": 335010489245,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 506,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//ThresholdChanges=1",
                "//Unit=Ah"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(335010489245),
//--TRIMMABLE-BOUNDARY-START(64427549597),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81607418781,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223341339549,
        "f": 83886081
      },
      "n": "BatteryCharge",
      "d": 3040157,
      "h": 64427549597,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 507,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//ThresholdChanges=1",
                "//Unit=Ah"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64427549597),
//--TRIMMABLE-BOUNDARY-START(197571535773),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107377222557,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240521208733,
        "f": 83886081
      },
      "n": "InverterCharge",
      "d": 3040157,
      "h": 197571535773,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 508,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//ThresholdChanges=1",
                "//Unit=Ah"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197571535773),
//--TRIMMABLE-BOUNDARY-START(347895391133),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184686633885,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317830620061,
        "f": 83886081
      },
      "n": "UsageCharge",
      "d": 3040157,
      "h": 347895391133,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 509,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//ThresholdChanges=1",
                "//Unit=Ah"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(347895391133),
//--TRIMMABLE-BOUNDARY-START(214751404957),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141736960925,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274880947101,
        "f": 83886081
      },
      "n": "MaximumSolarCurrent",
      "d": 3040157,
      "h": 214751404957,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 510,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 100,
              "t": 2722134
            },
            {
              "n": "Options",
              "v": [
                "//ThresholdChanges=1",
                "//Unit=A"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214751404957),
//--TRIMMABLE-BOUNDARY-START(206161470365),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124557091741,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257701077917,
        "f": 83886081
      },
      "n": "MaximumChargeCurrent",
      "d": 3040157,
      "h": 206161470365,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 511,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 100,
              "t": 2722134
            },
            {
              "n": "Options",
              "v": [
                "//ThresholdChanges=1",
                "//Unit=A"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206161470365),
//--TRIMMABLE-BOUNDARY-START(210456437661),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133147026333,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266291012509,
        "f": 83886081
      },
      "n": "MaximumLoadCurrent",
      "d": 3040157,
      "h": 210456437661,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 512,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 100,
              "t": 2722134
            },
            {
              "n": "Options",
              "v": [
                "//ThresholdChanges=1",
                "//Unit=A"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210456437661),
//--TRIMMABLE-BOUNDARY-START(343600423837),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176096699293,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309240685469,
        "f": 83886081
      },
      "n": "Switch",
      "d": 3040157,
      "h": 343600423837,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 513,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(343600423837),
//--TRIMMABLE-BOUNDARY-START(68722516893),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90197353373,
        "f": 50331649
      },
      "n": "BatteryCurrent",
      "d": 3040157,
      "h": 68722516893,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68722516893)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(60132582301),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3040157,
      "h": 60132582301,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60132582301)
  ],
  "h": 3040157
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenLoggerStatus`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenLoggerStatus`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3040157)
        
        

        //--TRIMMABLE-BOUNDARY-START(811933)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerClassificationModel`, ($self) => class GreenHouseLoggerClassificationModel extends $.$XBGm.LCICP.BaseDeviceDataClassificationModel
        {
            //--TRIMMABLE-BOUNDARY-START(158914601885)
            /*double*/ SolarHarvest = 0;
            //--TRIMMABLE-BOUNDARY-END(158914601885)
            
            //--TRIMMABLE-BOUNDARY-START(163209569181)
            /*double*/ UsageCharge = 0;
            //--TRIMMABLE-BOUNDARY-END(163209569181)
            
            //--TRIMMABLE-BOUNDARY-START(90195125149)
            /*double*/ InverterCharge = 0;
            //--TRIMMABLE-BOUNDARY-END(90195125149)
            
            //--TRIMMABLE-BOUNDARY-START(98785059741)
            /*double*/ PeakSolarCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(98785059741)
            
            //--TRIMMABLE-BOUNDARY-START(103080027037)
            /*double*/ PeakUsageCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(103080027037)
            
            //--TRIMMABLE-BOUNDARY-START(94490092445)
            /*double*/ PeakChargingCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(94490092445)
            
            //--TRIMMABLE-BOUNDARY-START(85900157853)
            /*object? */ GetChartDataPoint(/*IPropertyDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900157853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = descriptor.LCFCD$1$IPropertyDescriptor$Name;
                switch($switch1)
                {
                    case "PeakChargingCurrent":
                    return $.$box(this.PeakChargingCurrent, $.$$.S.Double);
                    case "PeakUsageCurrent":
                    return $.$box(this.PeakUsageCurrent, $.$$.S.Double);
                    case "PeakSolarCurrent":
                    return $.$box(this.PeakSolarCurrent, $.$$.S.Double);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(85900157853)
            
            //--TRIMMABLE-BOUNDARY-START(30065583005)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065583005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065583005)
            
            //--TRIMMABLE-BOUNDARY-START(30065583005)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(30065583005)
            
            static $h = 811933;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICP.BaseDeviceDataClassificationModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(158914601885),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015255965,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029699997,
        "f": 83886081
      },
      "n": "SolarHarvest",
      "d": 811933,
      "h": 158914601885,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Unit=Ah"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914601885),
//--TRIMMABLE-BOUNDARY-START(163209569181),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605190557,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619634589,
        "f": 83886081
      },
      "n": "UsageCharge",
      "d": 811933,
      "h": 163209569181,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Unit=Ah"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163209569181),
//--TRIMMABLE-BOUNDARY-START(90195125149),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655517597,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669961629,
        "f": 83886081
      },
      "n": "InverterCharge",
      "d": 811933,
      "h": 90195125149,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Unit=Ah"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90195125149),
//--TRIMMABLE-BOUNDARY-START(98785059741),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835386781,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849830813,
        "f": 83886081
      },
      "n": "PeakSolarCurrent",
      "d": 811933,
      "h": 98785059741,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Unit=A"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98785059741),
//--TRIMMABLE-BOUNDARY-START(103080027037),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425321373,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439765405,
        "f": 83886081
      },
      "n": "PeakUsageCurrent",
      "d": 811933,
      "h": 103080027037,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Unit=A"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103080027037),
//--TRIMMABLE-BOUNDARY-START(94490092445),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245452189,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259896221,
        "f": 83886081
      },
      "n": "PeakChargingCurrent",
      "d": 811933,
      "h": 94490092445,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Unit=A"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94490092445)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85900157853),
    {
      "r": 131073,
      "p": [
        {
          "n": "descriptor",
          "p": 40733014
        }
      ],
      "n": "GetChartDataPoint",
      "d": 811933,
      "h": 85900157853,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85900157853)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065583005),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 811933,
      "h": 30065583005,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065583005)
  ],
  "h": 811933
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICP.IIOTDeviceClassifiedData, $.$fPer.LCFCD.IChartableData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerClassificationModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerClassificationModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(811933)
        
        

        //--TRIMMABLE-BOUNDARY-START(3105693)
        $asm.$cls(`$CgOi.LCIDGM.InstantLog`, ($self) => class InstantLog extends $.$CgOi.LCIDGM.GreenHouseLoggerLog
        {
            //--TRIMMABLE-BOUNDARY-START(133147091869)
            /*double*/ SolarVoltage = 0;
            //--TRIMMABLE-BOUNDARY-END(133147091869)
            
            //--TRIMMABLE-BOUNDARY-START(128852124573)
            /*double*/ SolarCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(128852124573)
            
            //--TRIMMABLE-BOUNDARY-START(30067876765)
            /*double*/ BatteryVoltage = 0;
            //--TRIMMABLE-BOUNDARY-END(30067876765)
            
            //--TRIMMABLE-BOUNDARY-START(137442059165)
            /*double*/ UsageCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(137442059165)
            
            //--TRIMMABLE-BOUNDARY-START(81607484317)
            /*double*/ InverterChargeCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(81607484317)
            
            //--TRIMMABLE-BOUNDARY-START(34362844061)
            /*void */ CompleteDecodeNotify()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362844061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SolarVoltage /= 100;
                this.SolarCurrent /= 100;
                this.BatteryVoltage /= 100;
                this.UsageCurrent /= 100;
                this.InverterChargeCurrent /= 100;
            }
            //--TRIMMABLE-BOUNDARY-END(34362844061)
            
            //--TRIMMABLE-BOUNDARY-START(4311058774)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.ICompleteDecodeNotification.CompleteDecodeNotify()
            LCFCD$ICompleteDecodeNotification$CompleteDecodeNotify()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4311058774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CompleteDecodeNotify(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4311058774)
            
            //--TRIMMABLE-BOUNDARY-START(25772909469)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772909469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25772909469)
            
            //--TRIMMABLE-BOUNDARY-START(25772909469)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(25772909469)
            
            static $h = 3105693;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$CgOi.LCIDGM.GreenHouseLoggerLog; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133147091869),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68722582429,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115967222685,
        "f": 83886081
      },
      "n": "SolarVoltage",
      "d": 3105693,
      "h": 133147091869,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1002,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 524289,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133147091869),
//--TRIMMABLE-BOUNDARY-START(128852124573),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132647837,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107377288093,
        "f": 83886081
      },
      "n": "SolarCurrent",
      "d": 3105693,
      "h": 128852124573,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1003,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 524289,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128852124573),
//--TRIMMABLE-BOUNDARY-START(30067876765),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952778653,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90197418909,
        "f": 83886081
      },
      "n": "BatteryVoltage",
      "d": 3105693,
      "h": 30067876765,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1004,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 524289,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30067876765),
//--TRIMMABLE-BOUNDARY-START(137442059165),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77312517021,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124557157277,
        "f": 83886081
      },
      "n": "UsageCurrent",
      "d": 3105693,
      "h": 137442059165,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1005,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 524289,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137442059165),
//--TRIMMABLE-BOUNDARY-START(81607484317),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542713245,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98787353501,
        "f": 83886081
      },
      "n": "InverterChargeCurrent",
      "d": 3105693,
      "h": 81607484317,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1006,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 524289,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81607484317)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34362844061),
    {
      "r": 65537,
      "n": "CompleteDecodeNotify",
      "d": 3105693,
      "h": 34362844061,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362844061)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25772909469),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3105693,
      "h": 25772909469,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772909469)
  ],
  "h": 3105693
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceLog, $.$fPer.LCFCD.IOrderedSchemaPacketBuilder, $.$fPer.LCFCD.ICompleteDecodeNotification ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.InstantLog`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}InstantLog`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3105693)
        
        

        //--TRIMMABLE-BOUNDARY-START(746397)
        $asm.$cls(`$CgOi.LCIDGM.DailyLog`, ($self) => class DailyLog extends $.$CgOi.LCIDGM.GreenHouseLoggerLog
        {
            //--TRIMMABLE-BOUNDARY-START(107374928797)
            /*double*/ SolarCharge = 0;
            //--TRIMMABLE-BOUNDARY-END(107374928797)
            
            //--TRIMMABLE-BOUNDARY-START(25770550173)
            /*double*/ BatteryCharge = 0;
            //--TRIMMABLE-BOUNDARY-END(25770550173)
            
            //--TRIMMABLE-BOUNDARY-START(68720223133)
            /*double*/ InverterCharge = 0;
            //--TRIMMABLE-BOUNDARY-END(68720223133)
            
            //--TRIMMABLE-BOUNDARY-START(111669896093)
            /*double*/ UsageCharge = 0;
            //--TRIMMABLE-BOUNDARY-END(111669896093)
            
            //--TRIMMABLE-BOUNDARY-START(30065517469)
            /*void */ CompleteDecodeNotify()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065517469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SolarCharge /= 100;
                this.BatteryCharge /= 100;
                this.InverterCharge /= 100;
                this.UsageCharge /= 100;
            }
            //--TRIMMABLE-BOUNDARY-END(30065517469)
            
            //--TRIMMABLE-BOUNDARY-START(4311058774)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.ICompleteDecodeNotification.CompleteDecodeNotify()
            LCFCD$ICompleteDecodeNotification$CompleteDecodeNotify()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4311058774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CompleteDecodeNotify(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4311058774)
            
            //--TRIMMABLE-BOUNDARY-START(21475582877)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475582877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475582877)
            
            //--TRIMMABLE-BOUNDARY-START(21475582877)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21475582877)
            
            static $h = 746397;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$CgOi.LCIDGM.GreenHouseLoggerLog; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107374928797),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835321245,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490026909,
        "f": 83886081
      },
      "n": "SolarCharge",
      "d": 746397,
      "h": 107374928797,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2002,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 655361,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107374928797),
//--TRIMMABLE-BOUNDARY-START(25770550173),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655452061,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310157725,
        "f": 83886081
      },
      "n": "BatteryCharge",
      "d": 746397,
      "h": 25770550173,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2003,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 655361,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770550173),
//--TRIMMABLE-BOUNDARY-START(68720223133),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245386653,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900092317,
        "f": 83886081
      },
      "n": "InverterCharge",
      "d": 746397,
      "h": 68720223133,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2004,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 655361,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720223133),
//--TRIMMABLE-BOUNDARY-START(111669896093),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425255837,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079961501,
        "f": 83886081
      },
      "n": "UsageCharge",
      "d": 746397,
      "h": 111669896093,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2005,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 655361,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111669896093)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065517469),
    {
      "r": 65537,
      "n": "CompleteDecodeNotify",
      "d": 746397,
      "h": 30065517469,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065517469)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475582877),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 746397,
      "h": 21475582877,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475582877)
  ],
  "h": 746397
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceLog, $.$fPer.LCFCD.IOrderedSchemaPacketBuilder, $.$fPer.LCFCD.ICompleteDecodeNotification ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.DailyLog`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}DailyLog`; }
        });
        //--TRIMMABLE-BOUNDARY-END(746397)
        
        

        //--TRIMMABLE-BOUNDARY-START(91037)
        $asm.$cls(`$CgOi.LCIDG._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590025629)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590025629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590025629)
            
            //--TRIMMABLE-BOUNDARY-START(4295058333)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295058333);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295058333)
            
            //--TRIMMABLE-BOUNDARY-START(4295058333)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295058333)
            
            static $h = 91037;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590025629),
    {
      "r": 65537,
      "n": "Execute",
      "d": 91037,
      "h": 8590025629,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590025629)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295058333),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 91037,
      "h": 4295058333,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295058333)
  ],
  "h": 91037
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(91037)
        
        

        //--TRIMMABLE-BOUNDARY-START(4285341)
        $asm.$cls(`$CgOi.LCIDGV.GreenHouseDiagramArrowDown`, ($self) => class GreenHouseDiagramArrowDown extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(17184154525)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184154525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17184154525)
            
            //--TRIMMABLE-BOUNDARY-START(42953958301)
            /*int*/ GridRow = 0;
            //--TRIMMABLE-BOUNDARY-END(42953958301)
            
            //--TRIMMABLE-BOUNDARY-START(38658991005)
            /*int*/ GridColumn = 0;
            //--TRIMMABLE-BOUNDARY-END(38658991005)
            
            //--TRIMMABLE-BOUNDARY-START(12889187229)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889187229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12889187229)
            
            //--TRIMMABLE-BOUNDARY-START(12889187229)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12889187229)
            
            static $h = 4285341;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42953958301),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34364023709,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60133827485,
        "f": 83886081
      },
      "n": "GridRow",
      "d": 4285341,
      "h": 42953958301,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42953958301),
//--TRIMMABLE-BOUNDARY-START(38658991005),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25774089117,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51543892893,
        "f": 83886081
      },
      "n": "GridColumn",
      "d": 4285341,
      "h": 38658991005,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38658991005)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17184154525),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 4285341,
      "h": 17184154525,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17184154525)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12889187229),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4285341,
      "h": 12889187229,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889187229)
  ],
  "h": 4285341
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Views.GreenHouseDiagramArrowDown`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Views${separator}GreenHouseDiagramArrowDown`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4285341)
        
        

        //--TRIMMABLE-BOUNDARY-START(4809629)
        $asm.$cls(`$CgOi.LCIDGV.GreenHouseStatus`, ($self) => class GreenHouseStatus extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21479646109)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479646109);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21479646109)
            
            //--TRIMMABLE-BOUNDARY-START(51544417181)
            /*string*/ Icon = null;
            //--TRIMMABLE-BOUNDARY-END(51544417181)
            
            //--TRIMMABLE-BOUNDARY-START(85904155549)
            /*string*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(85904155549)
            
            //--TRIMMABLE-BOUNDARY-START(55839384477)
            /*string*/ Label = null;
            //--TRIMMABLE-BOUNDARY-END(55839384477)
            
            //--TRIMMABLE-BOUNDARY-START(17184678813)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184678813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17184678813)
            
            //--TRIMMABLE-BOUNDARY-START(17184678813)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17184678813)
            
            static $h = 4809629;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51544417181),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069580701,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64429319069,
        "f": 83886081
      },
      "n": "Icon",
      "d": 4809629,
      "h": 51544417181,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51544417181),
//--TRIMMABLE-BOUNDARY-START(85904155549),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47249449885,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81609188253,
        "f": 83886081
      },
      "n": "Value",
      "d": 4809629,
      "h": 85904155549,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85904155549),
//--TRIMMABLE-BOUNDARY-START(55839384477),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38659515293,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73019253661,
        "f": 83886081
      },
      "n": "Label",
      "d": 4809629,
      "h": 55839384477,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55839384477)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21479646109),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 4809629,
      "h": 21479646109,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21479646109)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17184678813),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4809629,
      "h": 17184678813,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17184678813)
  ],
  "h": 4809629
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Views.GreenHouseStatus`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Views${separator}GreenHouseStatus`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4809629)
        
        

        //--TRIMMABLE-BOUNDARY-START(4350877)
        $asm.$cls(`$CgOi.LCIDGV.GreenHouseDiagramCard`, ($self) => class GreenHouseDiagramCard extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(38659056541)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38659056541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38659056541)
            
            //--TRIMMABLE-BOUNDARY-START(184687944605)
            /*string*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(184687944605)
            
            //--TRIMMABLE-BOUNDARY-START(188982911901)
            /*string*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(188982911901)
            
            //--TRIMMABLE-BOUNDARY-START(111673500573)
            /*string*/ Icon = null;
            //--TRIMMABLE-BOUNDARY-END(111673500573)
            
            //--TRIMMABLE-BOUNDARY-START(115968467869)
            /*RenderFragment*/ IconView = null;
            //--TRIMMABLE-BOUNDARY-END(115968467869)
            
            //--TRIMMABLE-BOUNDARY-START(107378533277)
            /*int*/ GridRow = 0;
            //--TRIMMABLE-BOUNDARY-END(107378533277)
            
            //--TRIMMABLE-BOUNDARY-START(103083565981)
            /*int*/ GridColumn = 0;
            //--TRIMMABLE-BOUNDARY-END(103083565981)
            
            //--TRIMMABLE-BOUNDARY-START(120263435165)
            /*int*/ Margin = 0;
            //--TRIMMABLE-BOUNDARY-END(120263435165)
            
            //--TRIMMABLE-BOUNDARY-START(34364089245)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34364089245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34364089245)
            
            //--TRIMMABLE-BOUNDARY-START(34364089245)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(34364089245)
            
            static $h = 4350877;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(184687944605),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90198664093,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171803042717,
        "f": 83886081
      },
      "n": "Title",
      "d": 4350877,
      "h": 184687944605,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184687944605),
//--TRIMMABLE-BOUNDARY-START(188982911901),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98788598685,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180392977309,
        "f": 83886081
      },
      "n": "Value",
      "d": 4350877,
      "h": 188982911901,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188982911901),
//--TRIMMABLE-BOUNDARY-START(111673500573),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64428860317,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146033238941,
        "f": 83886081
      },
      "n": "Icon",
      "d": 4350877,
      "h": 111673500573,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111673500573),
//--TRIMMABLE-BOUNDARY-START(115968467869),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73018794909,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154623173533,
        "f": 83886081
      },
      "n": "IconView",
      "d": 4350877,
      "h": 115968467869,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115968467869),
//--TRIMMABLE-BOUNDARY-START(107378533277),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55838925725,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137443304349,
        "f": 83886081
      },
      "n": "GridRow",
      "d": 4350877,
      "h": 107378533277,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107378533277),
//--TRIMMABLE-BOUNDARY-START(103083565981),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47248991133,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128853369757,
        "f": 83886081
      },
      "n": "GridColumn",
      "d": 4350877,
      "h": 103083565981,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103083565981),
//--TRIMMABLE-BOUNDARY-START(120263435165),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81608729501,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163213108125,
        "f": 83886081
      },
      "n": "Margin",
      "d": 4350877,
      "h": 120263435165,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120263435165)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38659056541),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 4350877,
      "h": 38659056541,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38659056541)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34364089245),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4350877,
      "h": 34364089245,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34364089245)
  ],
  "h": 4350877
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Views.GreenHouseDiagramCard`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Views${separator}GreenHouseDiagramCard`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4350877)
        
        

        //--TRIMMABLE-BOUNDARY-START(4481949)
        $asm.$cls(`$CgOi.LCIDGV.GreenHouseInstantLog`, ($self) => class GreenHouseInstantLog extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$CgOi.LCIDGM.InstantLog)
        {
            //--TRIMMABLE-BOUNDARY-START(8594416541)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594416541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "b");
                __builder.AddContent$3(1, this.ViewModel.Time);
                __builder.CloseElement();
                __builder.AddMarkupContent(2, "\r\n    ");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "row mgt");
                __builder.AddMarkupContent(5, "<div class=\"col-a text-center\"><i class=\"mdi mdi-solar-panel fsz-30 hx-05 wx-05 round bd stack flex mgc-a bg-secondary\"></i></div>\r\n        ");
                __builder.OpenElement(6, "div");
                __builder.AddAttribute$5(7, "class", "col-10 stack");
                __builder.OpenElement(8, "div");
                __builder.AddAttribute$5(9, "class", "bdb bd-secondary fill text-center row");
                __builder.OpenElement(10, "div");
                __builder.AddAttribute$5(11, "class", "col-10 text-center stack");
                __builder.AddMarkupContent(12, "<div class=\"fill\"></div>\r\n                    ");
                __builder.OpenElement(13, "b");
                __builder.AddContent$4(14, `${$.$strNN(this.ViewModel.SolarVoltage)}V`);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(15, "\r\n                <div class=\"hf bdr bd-secondary\" style=\"transform: translateX(-5px) translateY(5px) rotate(-45deg)\"></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(16, "\r\n            ");
                __builder.OpenElement(17, "div");
                __builder.AddAttribute$5(18, "class", "fill text-center row");
                __builder.OpenElement(19, "div");
                __builder.AddAttribute$5(20, "class", "col-10 text-center stack");
                __builder.OpenElement(21, "b");
                __builder.AddContent$4(22, `${$.$strNN(this.ViewModel.SolarCurrent)}A`);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(23, "\r\n                <div class=\"hf bdr bd-secondary\" style=\"transform: translateX(-5px) translateY(-5px) rotate(45deg)\"></div>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(24, "\r\n        ");
                __builder.AddMarkupContent(25, "<div class=\"col-a\"><i class=\"mdi mdi-battery fsz-30 hx-05 wx-05 round bd stack flex mgc-a bg-primary\"></i></div>\r\n        ");
                __builder.OpenElement(26, "div");
                __builder.AddAttribute$5(27, "class", "col-10 stack");
                __builder.OpenElement(28, "div");
                __builder.AddAttribute$5(29, "class", "bdb bd-secondary fill text-center row");
                __builder.OpenElement(30, "div");
                __builder.AddAttribute$5(31, "class", "col-10 text-center stack");
                __builder.AddMarkupContent(32, "<div class=\"fill\"></div>\r\n                    ");
                __builder.OpenElement(33, "b");
                __builder.AddContent$4(34, `${$.$strNN(this.ViewModel.BatteryVoltage)}V`);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(35, "\r\n                <div class=\"hf bdr bd-secondary\" style=\"transform: translateX(-5px) translateY(5px) rotate(-45deg)\"></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(36, "\r\n            ");
                __builder.OpenElement(37, "div");
                __builder.AddAttribute$5(38, "class", "fill text-center row");
                __builder.OpenElement(39, "div");
                __builder.AddAttribute$5(40, "class", "col-10 text-center stack");
                __builder.OpenElement(41, "b");
                __builder.AddContent$4(42, `${$.$strNN(this.ViewModel.UsageCurrent)}A`);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(43, "\r\n                <div class=\"hf bdr bd-secondary\" style=\"transform: translateX(-5px) translateY(-5px) rotate(45deg)\"></div>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(44, "\r\n        ");
                __builder.AddMarkupContent(45, "<div class=\"col-a z-2\"><i class=\"mdi mdi-devices fsz-30 hx-05 wx-05 round bd stack flex mgc-a bg-info\"></i></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(46, "\r\n    ");
                __builder.AddMarkupContent(47, "<div class=\"row\"><div class=\"col-3\"><small class=\"nowrap\">Solar Panel</small></div>\r\n        <div class=\"col-3 text-center\"><small class=\"nowrap\">Battery</small></div>\r\n        <div class=\"col-3 text-right\"><small class=\"nowrap mgr\">Load</small></div></div>");
            }
            //--TRIMMABLE-BOUNDARY-END(8594416541)
            
            //--TRIMMABLE-BOUNDARY-START(4299449245)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299449245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299449245)
            
            //--TRIMMABLE-BOUNDARY-START(4299449245)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4299449245)
            
            static $h = 4481949;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$CgOi.LCIDGM.InstantLog); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594416541),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 4481949,
      "h": 8594416541,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8594416541)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299449245),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4481949,
      "h": 4299449245,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299449245)
  ],
  "h": 4481949
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Views.GreenHouseInstantLog`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Views${separator}GreenHouseInstantLog`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4481949)
        
        

        //--TRIMMABLE-BOUNDARY-START(1860509)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel`, ($self) => class GreenHouseLoggerDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceSendDataModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296827805)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296827805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296827805)
            
            //--TRIMMABLE-BOUNDARY-START(4296827805)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296827805)
            
            static $h = 1860509;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceSendDataModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296827805),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1860509,
      "h": 4296827805,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296827805)
  ],
  "h": 1860509
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1860509)
        
        

        //--TRIMMABLE-BOUNDARY-START(2843549)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerZeroModelTypeDescriptor`, ($self) => class GreenHouseLoggerZeroModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerZeroModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297810845)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297810845);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CgOi.LCIDGM.GreenHouseLoggerZeroModelTypeDescriptor.GenerateProperties($.$CgOi.LCIDGM.GreenHouseLoggerZeroModel, this, factory);
                    }, $YdTqdf ??= {"r":65537,"n":"","d":2843549,"h":0,"f":17825794}), 0, "GreenHouseLoggerZeroModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GreenHouseLogger\\Models_GreenHouseLoggerZeroModel_LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerZeroModelTypeDescriptorBuilder.g.cs", "GreenHouseLoggerZeroModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297810845)
            
            //--TRIMMABLE-BOUNDARY-START(12887745437)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887745437);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGM.GreenHouseLoggerZeroModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Command";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerZeroModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerZeroModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$CgOi.LCIDGM.GreenHouseLoggerZeroModel)).Command);
                        }, $iflhoi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2843549,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887745437)
            
            //--TRIMMABLE-BOUNDARY-START(17182712733)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerZeroModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182712733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182712733)
            
            //--TRIMMABLE-BOUNDARY-START(8592778141)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerZeroModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592778141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CgOi.LCIDGM.GreenHouseLoggerZeroModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CgOi.LCIDGM.GreenHouseLoggerZeroModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerZeroModel)))
                {
                    /*var*/ let result = $.$CgOi.LCIDGM.GreenHouseLoggerZeroModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerZeroModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CgOi.LCIDGM.GreenHouseLoggerZeroModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerZeroModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592778141)
            
            static $h = 2843549;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerZeroModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887745437),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2843549,
      "h": 12887745437,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887745437),
//--TRIMMABLE-BOUNDARY-START(17182712733),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2712477,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2843549,
      "h": 17182712733,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182712733),
//--TRIMMABLE-BOUNDARY-START(8592778141),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2712477,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2843549,
      "h": 8592778141,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592778141)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297810845),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2843549,
      "h": 4297810845,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297810845)
  ],
  "h": 2843549
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerZeroModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerZeroModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerZeroModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2843549)
        
        

        //--TRIMMABLE-BOUNDARY-START(2319261)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModelTypeDescriptor`, ($self) => class GreenHouseLoggerResetQuotaModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297286557)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297286557);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModelTypeDescriptor.GenerateProperties($.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel, this, factory);
                    }, $QxTxnf ??= {"r":65537,"n":"","d":2319261,"h":0,"f":17825794}), 0, "GreenHouseLoggerResetQuotaModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GreenHouseLogger\\Models_GreenHouseLoggerResetQuotaModel_LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerResetQuotaModelTypeDescriptorBuilder.g.cs", "GreenHouseLoggerResetQuotaModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297286557)
            
            //--TRIMMABLE-BOUNDARY-START(12887221149)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887221149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Command";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerResetQuotaModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel)).Command);
                        }, $RaWMDg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2319261,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887221149)
            
            //--TRIMMABLE-BOUNDARY-START(17182188445)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerResetQuotaModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182188445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182188445)
            
            //--TRIMMABLE-BOUNDARY-START(8592253853)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerResetQuotaModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592253853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel)))
                {
                    /*var*/ let result = $.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592253853)
            
            static $h = 2319261;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887221149),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2319261,
      "h": 12887221149,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887221149),
//--TRIMMABLE-BOUNDARY-START(17182188445),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2188189,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2319261,
      "h": 17182188445,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182188445),
//--TRIMMABLE-BOUNDARY-START(8592253853),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2188189,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2319261,
      "h": 8592253853,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592253853)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297286557),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2319261,
      "h": 4297286557,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297286557)
  ],
  "h": 2319261
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerResetQuotaModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerResetQuotaModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2319261)
        
        

        //--TRIMMABLE-BOUNDARY-START(943005)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor`, ($self) => class GreenHouseLoggerClassificationModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295910301)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295910301);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor.GenerateProperties($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel, this, factory);
                    }, $FFUCue ??= {"r":65537,"n":"","d":943005,"h":0,"f":17825794}), 0, "GreenHouseLoggerClassificationModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GreenHouseLogger\\Models_GreenHouseLoggerClassificationModel_LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerClassificationModelTypeDescriptorBuilder.g.cs", "GreenHouseLoggerClassificationModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295910301)
            
            //--TRIMMABLE-BOUNDARY-START(12885844893)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885844893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SolarHarvest"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel.$type, $.$discardRef(), "SolarHarvest", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SolarHarvest")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "SolarHarvest";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerClassificationModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel)).SolarHarvest);
                        }, $vRLHBe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":943005,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.SolarHarvest = value.AsDouble();
                        }, $TqZJFa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":943005,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("UsageCharge"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel.$type, $.$discardRef(), "UsageCharge", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("UsageCharge")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "UsageCharge";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerClassificationModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel)).UsageCharge);
                        }, $dyqlVc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":943005,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.UsageCharge = value.AsDouble();
                        }, $RaCUwc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":943005,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("InverterCharge"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel.$type, $.$discardRef(), "InverterCharge", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("InverterCharge")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "InverterCharge";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerClassificationModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel)).InverterCharge);
                        }, $OPeUAd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":943005,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.InverterCharge = value.AsDouble();
                        }, $ELbzRk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":943005,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PeakSolarCurrent"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel.$type, $.$discardRef(), "PeakSolarCurrent", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PeakSolarCurrent")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "PeakSolarCurrent";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerClassificationModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel)).PeakSolarCurrent);
                        }, $KlpDcj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":943005,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PeakSolarCurrent = value.AsDouble();
                        }, $vMGoSi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":943005,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PeakUsageCurrent"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel.$type, $.$discardRef(), "PeakUsageCurrent", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PeakUsageCurrent")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "PeakUsageCurrent";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerClassificationModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel)).PeakUsageCurrent);
                        }, $fBCjra ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":943005,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PeakUsageCurrent = value.AsDouble();
                        }, $cvwFMi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":943005,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PeakChargingCurrent"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel.$type, $.$discardRef(), "PeakChargingCurrent", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PeakChargingCurrent")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "PeakChargingCurrent";
                        $i11.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerClassificationModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel)).PeakChargingCurrent);
                        }, $nlrkJc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":943005,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PeakChargingCurrent = value.AsDouble();
                        }, $sXsyej ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":943005,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICP.BaseDeviceDataClassificationModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885844893)
            
            //--TRIMMABLE-BOUNDARY-START(17180812189)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerClassificationModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180812189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Processings.BaseDeviceDataClassificationModel?*/ let targetBase = _target;
                $.$XBGm.LCICP.BaseDeviceDataClassificationModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICP.BaseDeviceDataClassificationModel));
                {
                    /*var*/ let _SolarHarvest = _target.SolarHarvest;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SolarHarvest"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _SolarHarvest, ($v) => _SolarHarvest = $v, $.$$.S.Double)))
                    {
                        _target.SolarHarvest = _SolarHarvest;
                    }
                }
                {
                    /*var*/ let _UsageCharge = _target.UsageCharge;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("UsageCharge"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _UsageCharge, ($v) => _UsageCharge = $v, $.$$.S.Double)))
                    {
                        _target.UsageCharge = _UsageCharge;
                    }
                }
                {
                    /*var*/ let _InverterCharge = _target.InverterCharge;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("InverterCharge"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _InverterCharge, ($v) => _InverterCharge = $v, $.$$.S.Double)))
                    {
                        _target.InverterCharge = _InverterCharge;
                    }
                }
                {
                    /*var*/ let _PeakSolarCurrent = _target.PeakSolarCurrent;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PeakSolarCurrent"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _PeakSolarCurrent, ($v) => _PeakSolarCurrent = $v, $.$$.S.Double)))
                    {
                        _target.PeakSolarCurrent = _PeakSolarCurrent;
                    }
                }
                {
                    /*var*/ let _PeakUsageCurrent = _target.PeakUsageCurrent;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PeakUsageCurrent"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _PeakUsageCurrent, ($v) => _PeakUsageCurrent = $v, $.$$.S.Double)))
                    {
                        _target.PeakUsageCurrent = _PeakUsageCurrent;
                    }
                }
                {
                    /*var*/ let _PeakChargingCurrent = _target.PeakChargingCurrent;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PeakChargingCurrent"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _PeakChargingCurrent, ($v) => _PeakChargingCurrent = $v, $.$$.S.Double)))
                    {
                        _target.PeakChargingCurrent = _PeakChargingCurrent;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180812189)
            
            //--TRIMMABLE-BOUNDARY-START(8590877597)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerClassificationModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590877597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel)))
                {
                    /*var*/ let result = $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590877597)
            
            static $h = 943005;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885844893),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 943005,
      "h": 12885844893,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885844893),
//--TRIMMABLE-BOUNDARY-START(17180812189),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 811933,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 943005,
      "h": 17180812189,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180812189),
//--TRIMMABLE-BOUNDARY-START(8590877597),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 811933,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 943005,
      "h": 8590877597,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590877597)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295910301),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 943005,
      "h": 4295910301,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295910301)
  ],
  "h": 943005
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerClassificationModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerClassificationModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(943005)
        
        

        //--TRIMMABLE-BOUNDARY-START(3236765)
        $asm.$cls(`$CgOi.LCIDGPC.GreenHouseDeviceCommands<>`, (TDevice) => $asm.$gt(`$CgOi.LCIDGPC.GreenHouseDeviceCommands<>`, [TDevice], ($self) => class GreenHouseDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12888138653)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12888138653)
            
            //--TRIMMABLE-BOUNDARY-START(17183105949)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183105949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$CgOi.LCIDGPC.GreenHouseDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17183105949)
            
            //--TRIMMABLE-BOUNDARY-START(8593171357)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593171357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593171357)
            
            //--TRIMMABLE-BOUNDARY-START(8593171357)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8593171357)
            
            //--TRIMMABLE-BOUNDARY-START(4298204061)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298204061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12888138653)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [new $.$CgOi.LCIDGPCV.GreenHouseLoggerResetQuotaCommand().$ctor$6(), new $.$CgOi.LCIDGPCV.GreenHouseLoggerZeroCommand().$ctor$6()], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12888138653)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298204061)
            
            static $H = 3236765;
            static $h = 3236765;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183105949),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17183105949,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17183105949)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12888138653),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12888138653,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12888138653)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593171357),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8593171357,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593171357)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 3236765,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Protocol.Commands.GreenHouseDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Protocol${separator}Commands${separator}GreenHouseDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3236765)
        
        

        //--TRIMMABLE-BOUNDARY-START(3302301)
        $asm.$cls(`$CgOi.LCIDGPCV.GreenHouseLoggerResetQuotaCommand`, ($self) => class GreenHouseLoggerResetQuotaCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298269597)
            $ctor$6()
            {
                super.$ctor$5("Reset", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298269597);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298269597)
            
            //--TRIMMABLE-BOUNDARY-START(17183171485)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-refresh"/*MaterialDesignIconNames.Refresh*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17183171485)
            
            //--TRIMMABLE-BOUNDARY-START(4298269597)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4298269597)
            
            static $h = 3302301;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$CgOi.LCIDGM.GreenHouseLoggerResetQuotaModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183171485),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888204189,
        "f": 50364417
      },
      "n": "Icon",
      "d": 3302301,
      "h": 17183171485,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17183171485)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298269597),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 3302301,
      "h": 4298269597,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298269597)
  ],
  "h": 3302301
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Protocol.Commands.Variants.GreenHouseLoggerResetQuotaCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Protocol${separator}Commands${separator}Variants${separator}GreenHouseLoggerResetQuotaCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3302301)
        
        

        //--TRIMMABLE-BOUNDARY-START(3367837)
        $asm.$cls(`$CgOi.LCIDGPCV.GreenHouseLoggerZeroCommand`, ($self) => class GreenHouseLoggerZeroCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$CgOi.LCIDGM.GreenHouseLoggerZeroModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298335133)
            $ctor$6()
            {
                super.$ctor$5("Zero", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298335133);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298335133)
            
            //--TRIMMABLE-BOUNDARY-START(17183237021)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-current-dc"/*MaterialDesignIconNames.CurrentDc*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17183237021)
            
            //--TRIMMABLE-BOUNDARY-START(4298335133)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4298335133)
            
            static $h = 3367837;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$CgOi.LCIDGM.GreenHouseLoggerZeroModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183237021),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888269725,
        "f": 50364417
      },
      "n": "Icon",
      "d": 3367837,
      "h": 17183237021,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17183237021)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298335133),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 3367837,
      "h": 4298335133,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298335133)
  ],
  "h": 3367837
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Protocol.Commands.Variants.GreenHouseLoggerZeroCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Protocol${separator}Commands${separator}Variants${separator}GreenHouseLoggerZeroCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3367837)
        
        

        //--TRIMMABLE-BOUNDARY-START(1991581)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModelTypeDescriptor`, ($self) => class GreenHouseLoggerDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296958877)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296958877);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModelTypeDescriptor.GenerateProperties($.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, this, factory);
                    }, $uWpzqk ??= {"r":65537,"n":"","d":1991581,"h":0,"f":17825794}), 0, "GreenHouseLoggerDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GreenHouseLogger\\Models_GreenHouseLoggerDeviceSendDataModel_LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceSendDataModelTypeDescriptorBuilder.g.cs", "GreenHouseLoggerDeviceSendDataModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296958877)
            
            //--TRIMMABLE-BOUNDARY-START(12886893469)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886893469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886893469)
            
            //--TRIMMABLE-BOUNDARY-START(17181860765)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181860765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceSendDataModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceSendDataModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181860765)
            
            //--TRIMMABLE-BOUNDARY-START(8591926173)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591926173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591926173)
            
            static $h = 1991581;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886893469),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1991581,
      "h": 12886893469,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886893469),
//--TRIMMABLE-BOUNDARY-START(17181860765),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1860509,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1991581,
      "h": 17181860765,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181860765),
//--TRIMMABLE-BOUNDARY-START(8591926173),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1860509,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1991581,
      "h": 8591926173,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591926173)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296958877),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1991581,
      "h": 4296958877,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296958877)
  ],
  "h": 1991581
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1991581)
        
        

        //--TRIMMABLE-BOUNDARY-START(1336221)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel`, ($self) => class GreenHouseLoggerDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$CgOi.LCIDGM.GreenLoggerStatus, $.$CgOi.LCIDGM.GreenHouseLoggerLog)
        {
            //--TRIMMABLE-BOUNDARY-START(8591270813)
            /*object? */ GetChartDataPoint(/*IPropertyDescriptor*/ desc)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591270813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Status !== null)
                {
                    return $.$fPer.LCFCP$1.PropertyExtension.GetValue(this.Status, desc.LCFCD$1$IPropertyDescriptor$Name, null);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8591270813)
            
            //--TRIMMABLE-BOUNDARY-START(4296303517)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296303517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296303517)
            
            //--TRIMMABLE-BOUNDARY-START(4296303517)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296303517)
            
            static $h = 1336221;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$CgOi.LCIDGM.GreenLoggerStatus, $.$CgOi.LCIDGM.GreenHouseLoggerLog); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591270813),
    {
      "r": 131073,
      "p": [
        {
          "n": "desc",
          "p": 40733014
        }
      ],
      "n": "GetChartDataPoint",
      "d": 1336221,
      "h": 8591270813,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591270813)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296303517),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1336221,
      "h": 4296303517,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296303517)
  ],
  "h": 1336221
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1336221)
        
        

        //--TRIMMABLE-BOUNDARY-START(1467293)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModelTypeDescriptor`, ($self) => class GreenHouseLoggerDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296434589)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296434589);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, this, factory);
                    }, $vySRQf ??= {"r":65537,"n":"","d":1467293,"h":0,"f":17825794}), 0, "GreenHouseLoggerDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GreenHouseLogger\\Models_GreenHouseLoggerDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "GreenHouseLoggerDeviceReceivedDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296434589)
            
            //--TRIMMABLE-BOUNDARY-START(12886369181)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886369181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$CgOi.LCIDGM.GreenLoggerStatus, $.$CgOi.LCIDGM.GreenHouseLoggerLog).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886369181)
            
            //--TRIMMABLE-BOUNDARY-START(17181336477)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181336477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenLoggerStatus, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerLog>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$CgOi.LCIDGM.GreenLoggerStatus, $.$CgOi.LCIDGM.GreenHouseLoggerLog).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$CgOi.LCIDGM.GreenLoggerStatus, $.$CgOi.LCIDGM.GreenHouseLoggerLog)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181336477)
            
            //--TRIMMABLE-BOUNDARY-START(8591401885)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591401885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591401885)
            
            static $h = 1467293;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886369181),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1467293,
      "h": 12886369181,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886369181),
//--TRIMMABLE-BOUNDARY-START(17181336477),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1336221,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1467293,
      "h": 17181336477,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181336477),
//--TRIMMABLE-BOUNDARY-START(8591401885),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1336221,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1467293,
      "h": 8591401885,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591401885)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296434589),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1467293,
      "h": 4296434589,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296434589)
  ],
  "h": 1467293
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1467293)
        
        

        //--TRIMMABLE-BOUNDARY-START(353181)
        $asm.$cls(`$CgOi.LCIDG.GreenHouseLoggerDataClassifier`, ($self) => class GreenHouseLoggerDataClassifier extends $.$XBGm.LCICP.BaseDeviceDataClassifier$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8590287773)
            /*IEnumerable<IIOTDeviceClassifiedData> */ Classify(/*IIOTDeviceModel*/ device, /*IEnumerable<GreenHouseLoggerDeviceReceivedDataModel>*/ data, /*DateTime*/ startTime, /*DateTime*/ endTime, /*PeriodicInterval*/ interval)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590287773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.N.InterfaceVarianceStubHandler.Create($.$sl.SL.Enumerable.Where($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel, $.$fPer.LCFCD.DataClassifier.ClassifyByInterval($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel, data, startTime, endTime, interval, new ($.$$.S.Func$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Nullable$$($.$$.S.DateTime))))().$ctor(this,  (/*d*/ d) =>
                {
                    return new ($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Nullable$$($.$$.S.DateTime)))().$ctor$3($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(d.DateCreated), d.DateExtended);
                }, $MFRNwi ??= {"r":$.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Nullable$$($.$$.S.DateTime)).$h,"p":[{"n":"d","p":1336221}],"n":"","d":353181,"h":0,"f":17825794}), new ($.$$.S.Func$$$$$($.$$.S.DateTime, $.$$.S.DateTime, $.$$.SCG.IEnumerable$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel), $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel))().$ctor(this,  (/**/ start, /**/ end, /*datas*/ datas) =>
                {
                    if (!$.$sl.SL.Enumerable.Any$1($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, datas))
                    {
                        return null;
                    }
                    return (() =>
                    {
                        //new $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel()
                        const $t1 = $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.StartDate = start;
                        $i1.EndDate = end;
                        $i1.SolarHarvest = $.$sl.SL.Enumerable.Sum$16($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, datas, new ($.$$.S.Func$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$$.S.Double))().$ctor(this,  (/*d*/ d) =>
                        {
                            return (d.Status?.SolarHarvest ?? null) ?? 0;
                        }, $FhxHLk ??= {"r":1179649,"p":[{"n":"d","p":1336221}],"n":"","d":353181,"h":0,"f":17825794}));
                        $i1.UsageCharge = $.$sl.SL.Enumerable.Sum$16($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, datas, new ($.$$.S.Func$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$$.S.Double))().$ctor(this,  (/**/ d) =>
                        {
                            return (d.Status?.UsageCharge ?? null) ?? 0;
                        }, $TgPgCh ??= {"r":1179649,"p":[{"n":"d","p":1336221}],"n":"","d":353181,"h":0,"f":17825794}));
                        $i1.InverterCharge = $.$sl.SL.Enumerable.Sum$16($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, datas, new ($.$$.S.Func$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$$.S.Double))().$ctor(this,  (/*d*/ d) =>
                        {
                            return (d.Status?.InverterCharge ?? null) ?? 0;
                        }, $JOubfd ??= {"r":1179649,"p":[{"n":"d","p":1336221}],"n":"","d":353181,"h":0,"f":17825794}));
                        $i1.PeakSolarCurrent = $.$sl.SL.Enumerable.Max$13($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, datas, new ($.$$.S.Func$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$$.S.Double))().$ctor(this,  (/*d*/ d) =>
                        {
                            return (d.Status?.SolarCurrent ?? null) ?? 0;
                        }, $oHMxld ??= {"r":1179649,"p":[{"n":"d","p":1336221}],"n":"","d":353181,"h":0,"f":17825794}));
                        $i1.PeakUsageCurrent = $.$sl.SL.Enumerable.Max$13($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, datas, new ($.$$.S.Func$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$$.S.Double))().$ctor(this,  (/**/ d) =>
                        {
                            return (d.Status?.UsageCurrent ?? null) ?? 0;
                        }, $AvSSKf ??= {"r":1179649,"p":[{"n":"d","p":1336221}],"n":"","d":353181,"h":0,"f":17825794}));
                        $i1.PeakChargingCurrent = $.$sl.SL.Enumerable.Max$13($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, datas, new ($.$$.S.Func$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$$.S.Double))().$ctor(this,  (/*d*/ d) =>
                        {
                            return (d.Status?.BatteryCurrent ?? null) ?? 0;
                        }, $XMtEEk ??= {"r":1179649,"p":[{"n":"d","p":1336221}],"n":"","d":353181,"h":0,"f":17825794}));
                        return $i1;
                    })();
                }, $DhrUPg ??= {"r":811933,"p":[{"n":"start","p":65994753},{"n":"end","p":65994753},{"n":"datas","p":$.$$.SCG.IEnumerable$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel).$h}],"n":"","d":353181,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return t !== null;
                }, $DzNAdc ??= {"r":262145,"p":[{"n":"t","p":811933}],"n":"","d":353181,"h":0,"f":17825794})), $.$$.SCG.IEnumerable$$($.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel), $.$$.SCG.IEnumerable$$($.$XBGm.LCICP.IIOTDeviceClassifiedData));
            }
            //--TRIMMABLE-BOUNDARY-END(8590287773)
            
            //--TRIMMABLE-BOUNDARY-START(4295320477)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295320477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295320477)
            
            //--TRIMMABLE-BOUNDARY-START(4295320477)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295320477)
            
            static $h = 353181;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICP.BaseDeviceDataClassifier$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerClassificationModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590287773),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCICP.IIOTDeviceClassifiedData).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel).$h
        },
        {
          "n": "startTime",
          "p": 65994753
        },
        {
          "n": "endTime",
          "p": 65994753
        },
        {
          "n": "interval",
          "p": 7178582
        }
      ],
      "n": "Classify",
      "d": 353181,
      "h": 8590287773,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590287773)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295320477),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 353181,
      "h": 4295320477,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295320477)
  ],
  "h": 353181
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICP.IIOTDeviceDataClassifier$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel), $.$fPer.LCFCD.IChartable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.GreenHouseLoggerDataClassifier`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}GreenHouseLoggerDataClassifier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(353181)
        
        

        //--TRIMMABLE-BOUNDARY-START(418717)
        $asm.$cls(`$CgOi.LCIDG.GreenHouseLoggerDataConverter`, ($self) => class GreenHouseLoggerDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295386013)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295386013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295386013)
            
            //--TRIMMABLE-BOUNDARY-START(4295386013)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295386013)
            
            static $h = 418717;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295386013),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 418717,
      "h": 4295386013,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295386013)
  ],
  "h": 418717
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.GreenHouseLoggerDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}GreenHouseLoggerDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(418717)
        
        

        $asm.$typeProxy("$CgOi.LCIDGM.GreenHouseLoggerServiceModel", "$CgOi.LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerServiceModel");
        $asm.$typeProxy("$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel", "$CgOi.LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceScopeModel");
        $asm.$typeProxy("$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings", "$CgOi.LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettings");
        $asm.$typeProxy("$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings", "$CgOi.LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings");
        $asm.$typeProxy("$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler", "$CgOi.LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerDeviceStatusHandler");
        $asm.$typeProxy("$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient", "$CgOi.LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerDeviceHubClient");
        $asm.$typeProxy("$CgOi.LCIDGS.IGreenHouseLoggerRemoteService", "$CgOi.LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerRemoteService");
        //--TRIMMABLE-BOUNDARY-START(1074077)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerDeviceModel`, ($self) => class GreenHouseLoggerDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296041373)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296041373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296041373)
            
            //--TRIMMABLE-BOUNDARY-START(4296041373)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296041373)
            
            static $h = 1074077;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296041373),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1074077,
      "h": 4296041373,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296041373)
  ],
  "h": 1074077
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1074077)
        
        

        //--TRIMMABLE-BOUNDARY-START(1598365)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel`, ($self) => class GreenHouseLoggerDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296565661)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296565661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296565661)
            
            //--TRIMMABLE-BOUNDARY-START(4296565661)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296565661)
            
            static $h = 1598365;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296565661),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1598365,
      "h": 4296565661,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296565661)
  ],
  "h": 1598365
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1598365)
        
        

        //--TRIMMABLE-BOUNDARY-START(3695517)
        $asm.$cls(`$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings`, ($self) => class GreenHouseLoggerDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(103082910621)
            /*IOTDeviceInternalConfiguration<bool>*/ LogDailySummary = null;
            //--TRIMMABLE-BOUNDARY-END(103082910621)
            
            //--TRIMMABLE-BOUNDARY-START(111672845213)
            /*IOTDeviceInternalConfiguration<double>*/ LogdV = null;
            //--TRIMMABLE-BOUNDARY-END(111672845213)
            
            //--TRIMMABLE-BOUNDARY-START(107377877917)
            /*IOTDeviceInternalConfiguration<double>*/ LogdI = null;
            //--TRIMMABLE-BOUNDARY-END(107377877917)
            
            //--TRIMMABLE-BOUNDARY-START(115967812509)
            /*IOTDeviceInternalConfiguration<byte>*/ MinLogInterval = null;
            //--TRIMMABLE-BOUNDARY-END(115967812509)
            
            //--TRIMMABLE-BOUNDARY-START(120262779805)
            /*IOTDeviceInternalConfiguration<byte>*/ Reverse = null;
            //--TRIMMABLE-BOUNDARY-END(120262779805)
            
            //--TRIMMABLE-BOUNDARY-START(184687289245)
            /*IOTDeviceInternalConfiguration<double>*/ SolarCurrentRef = null;
            //--TRIMMABLE-BOUNDARY-END(184687289245)
            
            //--TRIMMABLE-BOUNDARY-START(98787943325)
            /*IOTDeviceInternalConfiguration<double>*/ InveterCurrentRef = null;
            //--TRIMMABLE-BOUNDARY-END(98787943325)
            
            //--TRIMMABLE-BOUNDARY-START(34363433885)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363433885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34363433885)
            
            //--TRIMMABLE-BOUNDARY-START(34363433885)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(34363433885)
            
            static $h = 3695517;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103082910621),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51543303069,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137442648989,
        "f": 83886081
      },
      "n": "LogDailySummary",
      "d": 3695517,
      "h": 103082910621,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103082910621),
//--TRIMMABLE-BOUNDARY-START(111672845213),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68723172253,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154622518173,
        "f": 83886081
      },
      "n": "LogdV",
      "d": 3695517,
      "h": 111672845213,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111672845213),
//--TRIMMABLE-BOUNDARY-START(107377877917),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60133237661,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146032583581,
        "f": 83886081
      },
      "n": "LogdI",
      "d": 3695517,
      "h": 107377877917,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107377877917),
//--TRIMMABLE-BOUNDARY-START(115967812509),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77313106845,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163212452765,
        "f": 83886081
      },
      "n": "MinLogInterval",
      "d": 3695517,
      "h": 115967812509,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115967812509),
//--TRIMMABLE-BOUNDARY-START(120262779805),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85903041437,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171802387357,
        "f": 83886081
      },
      "n": "Reverse",
      "d": 3695517,
      "h": 120262779805,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120262779805),
//--TRIMMABLE-BOUNDARY-START(184687289245),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94492976029,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180392321949,
        "f": 83886081
      },
      "n": "SolarCurrentRef",
      "d": 3695517,
      "h": 184687289245,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184687289245),
//--TRIMMABLE-BOUNDARY-START(98787943325),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42953368477,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128852714397,
        "f": 83886081
      },
      "n": "InveterCurrentRef",
      "d": 3695517,
      "h": 98787943325,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98787943325)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34363433885),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3695517,
      "h": 34363433885,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34363433885)
  ],
  "h": 3695517
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Settings${separator}GreenHouseLoggerDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3695517)
        
        

        //--TRIMMABLE-BOUNDARY-START(3498909)
        $asm.$cls(`$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient`, ($self) => class IGreenHouseLoggerDeviceHubClient
        {
            static $h = 3498909;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3498909
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Services${separator}IGreenHouseLoggerDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3498909)
        
        

        //--TRIMMABLE-BOUNDARY-START(2450333)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerServiceModel`, ($self) => class GreenHouseLoggerServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297417629)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297417629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297417629)
            
            //--TRIMMABLE-BOUNDARY-START(4297417629)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4297417629)
            
            static $h = 2450333;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297417629),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 2450333,
      "h": 4297417629,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297417629)
  ],
  "h": 2450333
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2450333)
        
        

        //--TRIMMABLE-BOUNDARY-START(3629981)
        $asm.$cls(`$CgOi.LCIDGS.IGreenHouseLoggerRemoteService`, ($self) => class IGreenHouseLoggerRemoteService
        {
            static $h = 3629981;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3629981
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Services${separator}IGreenHouseLoggerRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3629981)
        
        

        //--TRIMMABLE-BOUNDARY-START(3564445)
        $asm.$cls(`$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler`, ($self) => class IGreenHouseLoggerDeviceStatusHandler
        {
            static $h = 3564445;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3564445
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Services${separator}IGreenHouseLoggerDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3564445)
        
        

        //--TRIMMABLE-BOUNDARY-START(3957661)
        $asm.$cls(`$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings`, ($self) => class GreenHouseLoggerDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $self, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(21478794141)
            /*double*/ BatteryCapacity = 0;
            //--TRIMMABLE-BOUNDARY-END(21478794141)
            
            //--TRIMMABLE-BOUNDARY-START(25773761437)
            /*string?*/ BatteryVoltageTransform = null;
            //--TRIMMABLE-BOUNDARY-END(25773761437)
            
            //--TRIMMABLE-BOUNDARY-START(90198270877)
            /*string?*/ SolarVoltageTransform = null;
            //--TRIMMABLE-BOUNDARY-END(90198270877)
            
            //--TRIMMABLE-BOUNDARY-START(30068728733)
            /*double */ CorrectBatteryVoltage(/*double*/ voltage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068728733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.BatteryVoltageTransform !== null)
                {
                    return $.$DJRY.LCFCD.InterpreterExtension.EvaluateExpression($.$$.S.Double, $.$$.S.Double, this.BatteryVoltageTransform, voltage, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["v"], null, null));
                }
                return voltage;
            }
            //--TRIMMABLE-BOUNDARY-END(30068728733)
            
            //--TRIMMABLE-BOUNDARY-START(34363696029)
            /*double */ CorrectSolarVoltage(/*double*/ voltage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363696029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.SolarVoltageTransform !== null)
                {
                    return $.$DJRY.LCFCD.InterpreterExtension.EvaluateExpression($.$$.S.Double, $.$$.S.Double, this.SolarVoltageTransform, voltage, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["v"], null, null));
                }
                return voltage;
            }
            //--TRIMMABLE-BOUNDARY-END(34363696029)
            
            //--TRIMMABLE-BOUNDARY-START(17183826845)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183826845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183826845)
            
            //--TRIMMABLE-BOUNDARY-START(17183826845)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(17183826845)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21478794141)
                this.BatteryCapacity = 100;
                //--TRIMMABLE-BOUNDARY-END(21478794141)
                
            }
            static $h = 3957661;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21478794141),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42953630621,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68723434397,
        "f": 83886081
      },
      "n": "BatteryCapacity",
      "d": 3957661,
      "h": 21478794141,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "Unit=Ah"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21478794141),
//--TRIMMABLE-BOUNDARY-START(25773761437),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51543565213,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77313368989,
        "f": 83886081
      },
      "n": "BatteryVoltageTransform",
      "d": 3957661,
      "h": 25773761437,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25773761437),
//--TRIMMABLE-BOUNDARY-START(90198270877),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60133499805,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85903303581,
        "f": 83886081
      },
      "n": "SolarVoltageTransform",
      "d": 3957661,
      "h": 90198270877,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90198270877)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30068728733),
    {
      "r": 1179649,
      "p": [
        {
          "n": "voltage",
          "p": 1179649
        }
      ],
      "n": "CorrectBatteryVoltage",
      "d": 3957661,
      "h": 30068728733,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30068728733),
//--TRIMMABLE-BOUNDARY-START(34363696029),
    {
      "r": 1179649,
      "p": [
        {
          "n": "voltage",
          "p": 1179649
        }
      ],
      "n": "CorrectSolarVoltage",
      "d": 3957661,
      "h": 34363696029,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34363696029)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183826845),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3957661,
      "h": 17183826845,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183826845)
  ],
  "h": 3957661
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Settings${separator}GreenHouseLoggerDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3957661)
        
        

        //--TRIMMABLE-BOUNDARY-START(680861)
        $asm.$cls(`$CgOi.LCIDG.GreenHouseLoggerDeviceModelDefinition`, ($self) => class GreenHouseLoggerDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4295648157)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295648157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295648157)
            
            //--TRIMMABLE-BOUNDARY-START(4295648157)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295648157)
            
            static $h = 680861;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295648157),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 680861,
      "h": 4295648157,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295648157)
  ],
  "h": 680861
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.GreenHouseLoggerDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}GreenHouseLoggerDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(680861)
        
        

        //--TRIMMABLE-BOUNDARY-START(1205149)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerDeviceModelTypeDescriptor`, ($self) => class GreenHouseLoggerDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296172445)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296172445);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModelTypeDescriptor.GenerateProperties($.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, this, factory);
                    }, $jZOPId ??= {"r":65537,"n":"","d":1205149,"h":0,"f":17825794}), 0, "GreenHouseLoggerDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GreenHouseLogger\\Models_GreenHouseLoggerDeviceModel_LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceModelTypeDescriptorBuilder.g.cs", "GreenHouseLoggerDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296172445)
            
            //--TRIMMABLE-BOUNDARY-START(12886107037)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886107037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886107037)
            
            //--TRIMMABLE-BOUNDARY-START(17181074333)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181074333);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettings, LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceSendDataModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerDeviceStatusHandler, LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerDeviceHubClient, LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181074333)
            
            //--TRIMMABLE-BOUNDARY-START(8591139741)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591139741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel)))
                {
                    /*var*/ let result = $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591139741)
            
            static $h = 1205149;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886107037),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1205149,
      "h": 12886107037,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886107037),
//--TRIMMABLE-BOUNDARY-START(17181074333),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1074077,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1205149,
      "h": 17181074333,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181074333),
//--TRIMMABLE-BOUNDARY-START(8591139741),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1074077,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1205149,
      "h": 8591139741,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591139741)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296172445),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1205149,
      "h": 4296172445,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296172445)
  ],
  "h": 1205149
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1205149)
        
        

        //--TRIMMABLE-BOUNDARY-START(1729437)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModelTypeDescriptor`, ($self) => class GreenHouseLoggerDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296696733)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296696733);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModelTypeDescriptor.GenerateProperties($.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, this, factory);
                    }, $NckNfl ??= {"r":65537,"n":"","d":1729437,"h":0,"f":17825794}), 0, "GreenHouseLoggerDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GreenHouseLogger\\Models_GreenHouseLoggerDeviceScopeModel_LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceScopeModelTypeDescriptorBuilder.g.cs", "GreenHouseLoggerDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296696733)
            
            //--TRIMMABLE-BOUNDARY-START(12886631325)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886631325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886631325)
            
            //--TRIMMABLE-BOUNDARY-START(17181598621)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181598621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettings, LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceSendDataModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerDeviceStatusHandler, LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerDeviceHubClient, LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181598621)
            
            //--TRIMMABLE-BOUNDARY-START(8591664029)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591664029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel)))
                {
                    /*var*/ let result = $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591664029)
            
            static $h = 1729437;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886631325),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1729437,
      "h": 12886631325,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886631325),
//--TRIMMABLE-BOUNDARY-START(17181598621),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1598365,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1729437,
      "h": 17181598621,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181598621),
//--TRIMMABLE-BOUNDARY-START(8591664029),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1598365,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1729437,
      "h": 8591664029,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591664029)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296696733),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1729437,
      "h": 4296696733,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296696733)
  ],
  "h": 1729437
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1729437)
        
        

        //--TRIMMABLE-BOUNDARY-START(2581405)
        $asm.$cls(`$CgOi.LCIDGM.GreenHouseLoggerServiceModelTypeDescriptor`, ($self) => class GreenHouseLoggerServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297548701)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297548701);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CgOi.LCIDGM.GreenHouseLoggerServiceModelTypeDescriptor.GenerateProperties($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, this, factory);
                    }, $cjwOcb ??= {"r":65537,"n":"","d":2581405,"h":0,"f":17825794}), 0, "GreenHouseLoggerServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GreenHouseLogger\\Models_GreenHouseLoggerServiceModel_LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerServiceModelTypeDescriptorBuilder.g.cs", "GreenHouseLoggerServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297548701)
            
            //--TRIMMABLE-BOUNDARY-START(12887483293)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887483293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887483293)
            
            //--TRIMMABLE-BOUNDARY-START(17182450589)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182450589);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettings, LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceSendDataModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerDeviceStatusHandler, LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerDeviceHubClient, LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182450589)
            
            //--TRIMMABLE-BOUNDARY-START(8592515997)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592515997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CgOi.LCIDGM.GreenHouseLoggerServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerServiceModel)))
                {
                    /*var*/ let result = $.$CgOi.LCIDGM.GreenHouseLoggerServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGM.GreenHouseLoggerServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592515997)
            
            static $h = 2581405;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887483293),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2581405,
      "h": 12887483293,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887483293),
//--TRIMMABLE-BOUNDARY-START(17182450589),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2450333,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2581405,
      "h": 17182450589,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182450589),
//--TRIMMABLE-BOUNDARY-START(8592515997),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2450333,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2581405,
      "h": 8592515997,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592515997)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297548701),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2581405,
      "h": 4297548701,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297548701)
  ],
  "h": 2581405
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Models${separator}GreenHouseLoggerServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2581405)
        
        

        //--TRIMMABLE-BOUNDARY-START(4088733)
        $asm.$cls(`$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsTypeDescriptor`, ($self) => class GreenHouseLoggerDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299056029)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299056029);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsTypeDescriptor.GenerateProperties($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, this, factory);
                    }, $gCryhc ??= {"r":65537,"n":"","d":4088733,"h":0,"f":17825794}), 0, "GreenHouseLoggerDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GreenHouseLogger\\Settings_GreenHouseLoggerDeviceSettings_LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettingsTypeDescriptorBuilder.g.cs", "GreenHouseLoggerDeviceSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299056029)
            
            //--TRIMMABLE-BOUNDARY-START(12888990621)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888990621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BatteryCapacity"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings.$type, $.$discardRef(), "BatteryCapacity", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BatteryCapacity")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "BatteryCapacity";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings)).BatteryCapacity);
                        }, $ppovak ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4088733,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.BatteryCapacity = value.AsDouble();
                        }, $MTxdud ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4088733,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BatteryVoltageTransform"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings.$type, $.$discardRef(), "BatteryVoltageTransform", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BatteryVoltageTransform")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "BatteryVoltageTransform";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings)).BatteryVoltageTransform);
                        }, $WHsmdj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4088733,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.BatteryVoltageTransform = value.AsReference($.$$.S.String);
                        }, $FdkXYa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4088733,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SolarVoltageTransform"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings.$type, $.$discardRef(), "SolarVoltageTransform", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SolarVoltageTransform")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "SolarVoltageTransform";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettings";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings)).SolarVoltageTransform);
                        }, $xRvqVk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4088733,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SolarVoltageTransform = value.AsReference($.$$.S.String);
                        }, $bVCyga ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4088733,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888990621)
            
            //--TRIMMABLE-BOUNDARY-START(17183957917)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183957917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettings, LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceSendDataModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerDeviceStatusHandler, LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerDeviceHubClient, LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).iSmartDeviceSettings));
                {
                    /*var*/ let _BatteryCapacity = _target.BatteryCapacity;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BatteryCapacity"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _BatteryCapacity, ($v) => _BatteryCapacity = $v, $.$$.S.Double)))
                    {
                        _target.BatteryCapacity = _BatteryCapacity;
                    }
                }
                {
                    /*var*/ let _BatteryVoltageTransform = _target.BatteryVoltageTransform;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BatteryVoltageTransform"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _BatteryVoltageTransform, ($v) => _BatteryVoltageTransform = $v, $.$$.S.String)))
                    {
                        _target.BatteryVoltageTransform = _BatteryVoltageTransform;
                    }
                }
                {
                    /*var*/ let _SolarVoltageTransform = _target.SolarVoltageTransform;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SolarVoltageTransform"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _SolarVoltageTransform, ($v) => _SolarVoltageTransform = $v, $.$$.S.String)))
                    {
                        _target.SolarVoltageTransform = _SolarVoltageTransform;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183957917)
            
            //--TRIMMABLE-BOUNDARY-START(8594023325)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594023325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings)))
                {
                    /*var*/ let result = $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594023325)
            
            static $h = 4088733;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888990621),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4088733,
      "h": 12888990621,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888990621),
//--TRIMMABLE-BOUNDARY-START(17183957917),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3957661,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4088733,
      "h": 17183957917,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183957917),
//--TRIMMABLE-BOUNDARY-START(8594023325),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3957661,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4088733,
      "h": 8594023325,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594023325)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299056029),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4088733,
      "h": 4299056029,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299056029)
  ],
  "h": 4088733
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Settings${separator}GreenHouseLoggerDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4088733)
        
        

        //--TRIMMABLE-BOUNDARY-START(3826589)
        $asm.$cls(`$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor`, ($self) => class GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298793885)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298793885);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, this, factory);
                    }, $CXHCqj ??= {"r":65537,"n":"","d":3826589,"h":0,"f":17825794}), 0, "GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GreenHouseLogger\\Settings_GreenHouseLoggerDeviceHardwareSettings_LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298793885)
            
            //--TRIMMABLE-BOUNDARY-START(12888728477)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888728477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LogDailySummary"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings.$type, $.$discardRef(), "LogDailySummary", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LogDailySummary")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "LogDailySummary";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean), ($.$cast(target, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings)).LogDailySummary);
                        }, $dRILHc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3826589,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LogDailySummary = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean));
                        }, $tpLUVb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3826589,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LogdV"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings.$type, $.$discardRef(), "LogdV", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LogdV")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "LogdV";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double), ($.$cast(target, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings)).LogdV);
                        }, $cWlXSa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3826589,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LogdV = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double));
                        }, $UaKIui ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3826589,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LogdI"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings.$type, $.$discardRef(), "LogdI", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LogdI")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "LogdI";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double), ($.$cast(target, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings)).LogdI);
                        }, $HpZFbf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3826589,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LogdI = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double));
                        }, $OntvFi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3826589,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MinLogInterval"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings.$type, $.$discardRef(), "MinLogInterval", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MinLogInterval")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "MinLogInterval";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte), ($.$cast(target, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings)).MinLogInterval);
                        }, $qJWHwd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3826589,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.MinLogInterval = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte));
                        }, $cIqotj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3826589,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Reverse"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings.$type, $.$discardRef(), "Reverse", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Reverse")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Reverse";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte), ($.$cast(target, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings)).Reverse);
                        }, $fYBBzk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3826589,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Reverse = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte));
                        }, $SJcMba ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3826589,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SolarCurrentRef"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings.$type, $.$discardRef(), "SolarCurrentRef", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SolarCurrentRef")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "SolarCurrentRef";
                        $i11.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double), ($.$cast(target, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings)).SolarCurrentRef);
                        }, $XqhMTe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3826589,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SolarCurrentRef = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double));
                        }, $ETFJRi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3826589,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("InveterCurrentRef"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings.$type, $.$discardRef(), "InveterCurrentRef", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("InveterCurrentRef")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "InveterCurrentRef";
                        $i13.DelaredOn = "LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double), ($.$cast(target, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings)).InveterCurrentRef);
                        }, $Ctryrc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3826589,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.InveterCurrentRef = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double));
                        }, $SNCblk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3826589,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888728477)
            
            //--TRIMMABLE-BOUNDARY-START(17183695773)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183695773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceSettings, LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.GreenHouseLoggerDeviceSendDataModel, LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerDeviceStatusHandler, LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerDeviceHubClient, LivingThing.Core.IOT.Devices.GreenHouseLogger.Services.IGreenHouseLoggerRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService).iSmartDeviceHardwareSettings));
                {
                    /*var*/ let _LogDailySummary = _target.LogDailySummary;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LogDailySummary"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _LogDailySummary, ($v) => _LogDailySummary = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean))))
                    {
                        _target.LogDailySummary = _LogDailySummary;
                    }
                }
                {
                    /*var*/ let _LogdV = _target.LogdV;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LogdV"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _LogdV, ($v) => _LogdV = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double))))
                    {
                        _target.LogdV = _LogdV;
                    }
                }
                {
                    /*var*/ let _LogdI = _target.LogdI;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LogdI"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _LogdI, ($v) => _LogdI = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double))))
                    {
                        _target.LogdI = _LogdI;
                    }
                }
                {
                    /*var*/ let _MinLogInterval = _target.MinLogInterval;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MinLogInterval"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _MinLogInterval, ($v) => _MinLogInterval = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte))))
                    {
                        _target.MinLogInterval = _MinLogInterval;
                    }
                }
                {
                    /*var*/ let _Reverse = _target.Reverse;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Reverse"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Reverse, ($v) => _Reverse = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte))))
                    {
                        _target.Reverse = _Reverse;
                    }
                }
                {
                    /*var*/ let _SolarCurrentRef = _target.SolarCurrentRef;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SolarCurrentRef"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _SolarCurrentRef, ($v) => _SolarCurrentRef = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double))))
                    {
                        _target.SolarCurrentRef = _SolarCurrentRef;
                    }
                }
                {
                    /*var*/ let _InveterCurrentRef = _target.InveterCurrentRef;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("InveterCurrentRef"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _InveterCurrentRef, ($v) => _InveterCurrentRef = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Double))))
                    {
                        _target.InveterCurrentRef = _InveterCurrentRef;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183695773)
            
            //--TRIMMABLE-BOUNDARY-START(8593761181)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593761181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593761181)
            
            static $h = 3826589;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888728477),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3826589,
      "h": 12888728477,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888728477),
//--TRIMMABLE-BOUNDARY-START(17183695773),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3695517,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3826589,
      "h": 17183695773,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183695773),
//--TRIMMABLE-BOUNDARY-START(8593761181),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3695517,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3826589,
      "h": 8593761181,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593761181)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298793885),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3826589,
      "h": 4298793885,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298793885)
  ],
  "h": 3826589
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Settings.GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Settings${separator}GreenHouseLoggerDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3826589)
        
        

        //--TRIMMABLE-BOUNDARY-START(484253)
        $asm.$cls(`$CgOi.LCIDG.GreenHouseLoggerDevice`, ($self) => class GreenHouseLoggerDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$CgOi.LCIDGM.GreenLoggerStatus).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4295451549)
            $ctor$2(/*IIOTDeviceFamily<GreenHouseLoggerDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*GreenHouseLoggerDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295451549);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295451549)
            
            static $h = 484253;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDG.GreenHouseLoggerDevice, $.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$CgOi.LCIDGM.GreenLoggerStatus).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295451549),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$CgOi.LCIDG.GreenHouseLoggerDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 1074077
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 484253,
      "h": 4295451549,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295451549)
  ],
  "h": 484253
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.GreenHouseLoggerDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}GreenHouseLoggerDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(484253)
        
        

        //--TRIMMABLE-BOUNDARY-START(549789)
        $asm.$cls(`$CgOi.LCIDG.GreenHouseLoggerDeviceDefinition`, ($self) => class GreenHouseLoggerDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDG.GreenHouseLoggerDevice, $.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$CgOi.LCIDGM.GreenLoggerStatus)
        {
            //--TRIMMABLE-BOUNDARY-START(4295517085)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295517085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295517085)
            
            //--TRIMMABLE-BOUNDARY-START(4295517085)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295517085)
            
            static $h = 549789;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDG.GreenHouseLoggerDevice, $.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$CgOi.LCIDGM.GreenLoggerStatus); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295517085),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 549789,
      "h": 4295517085,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295517085)
  ],
  "h": 549789
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.GreenHouseLoggerDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}GreenHouseLoggerDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(549789)
        
        

        //--TRIMMABLE-BOUNDARY-START(615325)
        $asm.$cls(`$CgOi.LCIDG.GreenHouseLoggerDeviceFamily`, ($self) => class GreenHouseLoggerDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDG.GreenHouseLoggerDevice, $.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4295582621)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<GreenHouseLoggerDeviceReceivedDataModel, GreenHouseLoggerDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<GreenHouseLoggerDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295582621);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295582621)
            
            //--TRIMMABLE-BOUNDARY-START(8590549917)
            /*Type */ get DeviceLogType()
            {
                return $.$CgOi.LCIDGM.GreenHouseLoggerLog.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8590549917)
            
            static $h = 615325;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$CgOi.LCIDG.GreenHouseLoggerDevice, $.$CgOi.LCIDGM.GreenHouseLoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceModel, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceStatusHandler, $.$CgOi.LCIDGS.IGreenHouseLoggerDeviceHubClient, $.$CgOi.LCIDGS.IGreenHouseLoggerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590549917),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180484509,
        "f": 50364417
      },
      "n": "DeviceLogType",
      "d": 615325,
      "h": 8590549917,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8590549917)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295582621),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 615325,
      "h": 4295582621,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295582621)
  ],
  "h": 615325
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$CgOi.LCIDG.GreenHouseLoggerDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$CgOi.LCIDG.GreenHouseLoggerDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.GreenHouseLoggerDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}GreenHouseLoggerDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(615325)
        
        

        //--TRIMMABLE-BOUNDARY-START(4744093)
        $asm.$cls(`$CgOi.LCIDGV.GreenHouseLoggerViewRenderer`, ($self) => class GreenHouseLoggerViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$CgOi.LCIDG.GreenHouseLoggerDevice, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299711389)
            $ctor$3(/*IOTRootViewModel*/ root)
            {
                super.$ctor$2(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299711389);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299711389)
            
            //--TRIMMABLE-BOUNDARY-START(12889645981)
            /*RenderFragment */ GetView(/*IClientUnitOfWork*/ ui, /*GreenHouseLoggerDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>*/ clicked, /*Func<Task>*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889645981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === 3/*DeviceViewType.Details*/)
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$CgOi.LCIDGV.GreenHouseLoggerDeviceDetails, $.$CgOi.LCIDGV.GreenHouseLoggerDetailsViewModel, new $.$CgOi.LCIDGV.GreenHouseLoggerDetailsViewModel().$ctor$9(this.Root, device.OwnerScope, device), true, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(12889645981)
            
            //--TRIMMABLE-BOUNDARY-START(8594678685)
            /*RenderFragment */ GetView$1(/*ContainerContext<InstantLog>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594678685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$CgOi.LCIDGV.GreenHouseInstantLog, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("ViewModel", value.Model);
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8594678685)
            
            //--TRIMMABLE-BOUNDARY-START(4360984234)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IViewProvider<LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.InstantLog>.GetView(LivingThing.Core.Frameworks.Client.Interface.ContainerContext<LivingThing.Core.IOT.Devices.GreenHouseLogger.Models.InstantLog>)
            LCFCI$IViewProvider$LivingThing$Core$IOT$Devices$GreenHouseLogger$Models$InstantLog$GetView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4360984234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetView$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4360984234)
            
            static $h = 4744093;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$CgOi.LCIDG.GreenHouseLoggerDevice, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889645981),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 484253
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 4744093,
      "h": 12889645981,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12889645981),
//--TRIMMABLE-BOUNDARY-START(8594678685),
    {
      "r": 6881395,
      "p": [
        {
          "n": "value",
          "p": $.$hDPm.LCFCI.ContainerContext$$($.$CgOi.LCIDGM.InstantLog).$h
        }
      ],
      "n": "GetView",
      "o": "@$1",
      "d": 4744093,
      "h": 8594678685,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594678685)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299711389),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4744093,
      "h": 4299711389,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299711389)
  ],
  "h": 4744093
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$CgOi.LCIDG.GreenHouseLoggerDevice), $.$ntej.LCICD$1.IDeviceViewRenderer, $.$hDPm.LCFCI.IViewProvider$$($.$CgOi.LCIDGM.InstantLog) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Views.GreenHouseLoggerViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Views${separator}GreenHouseLoggerViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4744093)
        
        

        //--TRIMMABLE-BOUNDARY-START(4678557)
        $asm.$cls(`$CgOi.LCIDGV.GreenHouseLoggerHistoryViewModel`, ($self) => class GreenHouseLoggerHistoryViewModel extends $.$ntej.LCICV.DeviceViewModel$$($.$CgOi.LCIDG.GreenHouseLoggerDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(4299645853)
            $ctor$7(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*GreenHouseLoggerDevice*/ device)
            {
                super.$ctor$6(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299645853);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299645853)
            
            static $h = 4678557;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.DeviceViewModel$$($.$CgOi.LCIDG.GreenHouseLoggerDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299645853),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 484253
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 4678557,
      "h": 4299645853,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299645853)
  ],
  "h": 4678557
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IChartable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Views.GreenHouseLoggerHistoryViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Views${separator}GreenHouseLoggerHistoryViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4678557)
        
        

        //--TRIMMABLE-BOUNDARY-START(4416413)
        $asm.$cls(`$CgOi.LCIDGV.GreenHouseHistoryPage`, ($self) => class GreenHouseHistoryPage extends $.$lJUR.LCFCS.ApplicationPageBaseOfViewModel$$($.$CgOi.LCIDGV.GreenHouseLoggerHistoryViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(34364154781)
            /*string */ get OptimizedComponentName()
            {
                return "greenhousehistorypage";
            }
            //--TRIMMABLE-BOUNDARY-END(34364154781)
            
            //--TRIMMABLE-BOUNDARY-START(47249056669)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47249056669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$CgOi.LCIDGV.GreenHouseLoggerHistoryViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(47249056669)
            
            //--TRIMMABLE-BOUNDARY-START(51544023965)
            /*GreenHouseLoggerHistoryViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(51544023965)
            
            //--TRIMMABLE-BOUNDARY-START(12889318301)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889318301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12889318301)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8594351005)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594351005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594351005)
            
            //--TRIMMABLE-BOUNDARY-START(8594351005)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(8594351005)
            
            static $h = 4416413;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationPageBaseOfViewModel$$($.$CgOi.LCIDGV.GreenHouseLoggerHistoryViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34364154781),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479252893,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 4416413,
      "h": 34364154781,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34364154781),
//--TRIMMABLE-BOUNDARY-START(51544023965),
    {
      "p": 4678557,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069187485,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42954089373,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 4416413,
      "h": 51544023965,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51544023965)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47249056669),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 4416413,
      "h": 47249056669,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47249056669),
//--TRIMMABLE-BOUNDARY-START(12889318301),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 4416413,
      "h": 12889318301,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12889318301)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594351005),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 4416413,
      "h": 8594351005,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594351005)
  ],
  "h": 4416413
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Views.GreenHouseHistoryPage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Views${separator}GreenHouseHistoryPage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4416413)
        
        

        //--TRIMMABLE-BOUNDARY-START(4547485)
        $asm.$cls(`$CgOi.LCIDGV.GreenHouseLoggerDetailsViewModel`, ($self) => class GreenHouseLoggerDetailsViewModel extends $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$CgOi.LCIDG.GreenHouseLoggerDevice, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299514781)
            $ctor$9(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*GreenHouseLoggerDevice*/ device)
            {
                super.$ctor$8(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299514781);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299514781)
            
            //--TRIMMABLE-BOUNDARY-START(8594482077)
            /*IEnumerable<IPropertyDescriptor> */ get Charts$1()
            {
                return $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataPointDescriptor), [(() =>
                {
                    //new $.$fPer.LCFCD.DataPointDescriptor()
                    const $t1 = $.$fPer.LCFCD.DataPointDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Name = "SolarVoltage";
                    $i1.Label = $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle("SolarVoltage");
                    return $i1;
                })(), (() =>
                {
                    //new $.$fPer.LCFCD.DataPointDescriptor()
                    const $t2 = $.$fPer.LCFCD.DataPointDescriptor;
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.Name = "SolarCurrent";
                    $i2.Label = $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle("SolarCurrent");
                    return $i2;
                })(), (() =>
                {
                    //new $.$fPer.LCFCD.DataPointDescriptor()
                    const $t3 = $.$fPer.LCFCD.DataPointDescriptor;
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.Name = "BatteryVoltage";
                    $i3.Label = $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle("BatteryVoltage");
                    return $i3;
                })(), (() =>
                {
                    //new $.$fPer.LCFCD.DataPointDescriptor()
                    const $t4 = $.$fPer.LCFCD.DataPointDescriptor;
                    const $i4 = new $t4();
                    $i4.$ctor$1();
                    $i4.Name = "InverterChargeCurrent";
                    $i4.Label = $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle("InverterChargeCurrent");
                    return $i4;
                })(), (() =>
                {
                    //new $.$fPer.LCFCD.DataPointDescriptor()
                    const $t5 = $.$fPer.LCFCD.DataPointDescriptor;
                    const $i5 = new $t5();
                    $i5.$ctor$1();
                    $i5.Name = "UsageCurrent";
                    $i5.Label = $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle("UsageCurrent");
                    return $i5;
                })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.DataPointDescriptor), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor));
            }
            //--TRIMMABLE-BOUNDARY-END(8594482077)
            
            static $h = 4547485;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$CgOi.LCIDG.GreenHouseLoggerDevice, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceSettings, $.$CgOi.LCIDGS$1.GreenHouseLoggerDeviceHardwareSettings, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel, $.$CgOi.LCIDGM.GreenHouseLoggerDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8594482077),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17184416669,
        "f": 50331649
      },
      "n": "Charts",
      "o": "@$1",
      "d": 4547485,
      "h": 8594482077,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8594482077)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299514781),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 484253
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 4547485,
      "h": 4299514781,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299514781)
  ],
  "h": 4547485
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$ntej.LCICDV.IDeviceDetailsViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IChartable$$($.$CgOi.LCIDGM.GreenHouseLoggerDeviceReceivedDataModel), $.$fPer.LCFCD.IChartable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Views.GreenHouseLoggerDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Views${separator}GreenHouseLoggerDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4547485)
        
        

        //--TRIMMABLE-BOUNDARY-START(4613021)
        $asm.$cls(`$CgOi.LCIDGV.GreenHouseLoggerDeviceDetails`, ($self) => class GreenHouseLoggerDeviceDetails extends $.$hDPm.LCFCC$1.BaseComponent$$($.$CgOi.LCIDGV.GreenHouseLoggerDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(51544220573)
            /*GreenHouseLoggerDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(51544220573)
            
            //--TRIMMABLE-BOUNDARY-START(34364351389)
            /*string */ get OptimizedComponentName()
            {
                return "greenhouseloggerdevicedetails";
            }
            //--TRIMMABLE-BOUNDARY-END(34364351389)
            
            //--TRIMMABLE-BOUNDARY-START(47249253277)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47249253277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$CgOi.LCIDGV.GreenHouseLoggerDetailsViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(47249253277)
            
            //--TRIMMABLE-BOUNDARY-START(12889514909)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889514909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let solarVoltage = this.ViewModel.Device$1.Settings$1.CorrectSolarVoltage((this.ViewModel.Device$1.Received?.Status?.SolarVoltage ?? null) ?? 0);
                /*var*/ let batteryVoltage = this.ViewModel.Device$1.Settings$1.CorrectBatteryVoltage((this.ViewModel.Device$1.Received?.Status?.BatteryVoltage ?? null) ?? 0);
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$CgOi.LCIDG.GreenHouseLoggerDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$CgOi.LCIDG.GreenHouseLoggerDevice), this.ViewModel));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$4.Themable, 3);
                    __builder2.AddAttribute$3(4, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors)))().$ctor(this, ( (/**/ theme) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            /*int*/ let size = 100;
                            /*double*/ let angle = 2 * 3.141592653589793/*Math.PI*/ / 1.3;
                            /*double*/ let harvestProportion = (this.ViewModel.Device$1.Received?.Status?.SolarHarvest ?? null) ?? 0;
                            /*double*/ let usageProportion = $.$$.S.Math.Abs$1((this.ViewModel.Device$1.Received?.Status?.UsageCharge ?? null) ?? 0);
                            /*double*/ let storedProportion = (this.ViewModel.Device$1.Received?.Status?.BatteryCharge ?? null) ?? 0;
                            /*var*/ let max = $.$$.S.Math.Max$2($.$$.S.Math.Max$2(harvestProportion * 1.2, $.$$.S.Math.Max$2(usageProportion, storedProportion)), this.ViewModel.Device$1.Settings$1.BatteryCapacity);
                            if (max < 1)
                            {
                                max = 1;
                            }
                            harvestProportion /= max;
                            usageProportion /= max;
                            storedProportion /= max;
                            /*var*/ let builder = $.$hDPm.LCFCCSF.SVGBuilder.Create(size, size, 0/*DimensionUnit.None*/, true, 0, 0);
                            builder.LCFCCSF$ISVGGroupBuilder$Group(new ($.$$.S.Action$$($.$hDPm.LCFCCSF.ISVGBuilder))().$ctor(this,  (/*builder*/ builder) =>
                            {
                                return $.$hDPm.LCFCCSWD.DoughnutExtension.Doughnut(builder, (() =>
                                {
                                    //new $.$hDPm.LCFCCSWD.DoughnutModel()
                                    const $t2 = $.$hDPm.LCFCCSWD.DoughnutModel;
                                    const $i2 = new $t2();
                                    $i2.$ctor$1();
                                    $i2.Size = size;
                                    $i2.BackgroundColor = theme.Model.CardBackgroundColor;
                                    $i2.StrokeWidth = 2.8;
                                    $i2.Radius = 0.45;
                                    $i2.CoverageAngle = $.$cast(angle, $.$$.S.Single);
                                    $i2.Sections = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$hDPm.LCFCCSWD.DoughnutSection), [(() =>
                                    {
                                        //new $.$hDPm.LCFCCSWD.DoughnutSection()
                                        const $t3 = $.$hDPm.LCFCCSWD.DoughnutSection;
                                        const $i3 = new $t3();
                                        $i3.$ctor$1();
                                        $i3.Proportion = $.$cast(harvestProportion, $.$$.S.Single);
                                        $i3.Color = $.$$.System.Array.$ReadT1.call(theme.Model.ChartColors, 0);
                                        return $i3;
                                    })()], [-1], null);
                                    return $i2;
                                })());
                            }, $nAYQNh ??= {"r":65537,"p":[{"n":"builder","p":46945962}],"n":"","d":4613021,"h":0,"f":17825794})).LCFCCSF$ISVGGroupBuilder$Group(new ($.$$.S.Action$$($.$hDPm.LCFCCSF.ISVGBuilder))().$ctor(this,  (/*builder*/ builder) =>
                            {
                                return $.$hDPm.LCFCCSWD.DoughnutExtension.Doughnut(builder, (() =>
                                {
                                    //new $.$hDPm.LCFCCSWD.DoughnutModel()
                                    const $t4 = $.$hDPm.LCFCCSWD.DoughnutModel;
                                    const $i4 = new $t4();
                                    $i4.$ctor$1();
                                    $i4.BackgroundColor = theme.Model.CardBackgroundColor;
                                    $i4.StrokeWidth = 2.8;
                                    $i4.Size = size;
                                    $i4.Radius = 0.4;
                                    $i4.CoverageAngle = $.$cast(angle, $.$$.S.Single);
                                    $i4.Sections = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$hDPm.LCFCCSWD.DoughnutSection), [(() =>
                                    {
                                        //new $.$hDPm.LCFCCSWD.DoughnutSection()
                                        const $t5 = $.$hDPm.LCFCCSWD.DoughnutSection;
                                        const $i5 = new $t5();
                                        $i5.$ctor$1();
                                        $i5.Proportion = $.$cast(usageProportion, $.$$.S.Single);
                                        $i5.Color = $.$$.System.Array.$ReadT1.call(theme.Model.ChartColors, 1);
                                        return $i5;
                                    })()], [-1], null);
                                    return $i4;
                                })());
                            }, $leZkDh ??= {"r":65537,"p":[{"n":"builder","p":46945962}],"n":"","d":4613021,"h":0,"f":17825794})).LCFCCSF$ISVGGroupBuilder$Group(new ($.$$.S.Action$$($.$hDPm.LCFCCSF.ISVGBuilder))().$ctor(this,  (/*builder*/ builder) =>
                            {
                                return $.$hDPm.LCFCCSWD.DoughnutExtension.Doughnut(builder, (() =>
                                {
                                    //new $.$hDPm.LCFCCSWD.DoughnutModel()
                                    const $t6 = $.$hDPm.LCFCCSWD.DoughnutModel;
                                    const $i6 = new $t6();
                                    $i6.$ctor$1();
                                    $i6.BackgroundColor = theme.Model.CardBackgroundColor;
                                    $i6.StrokeWidth = 2.8;
                                    $i6.Size = size;
                                    $i6.Radius = 0.35;
                                    $i6.CoverageAngle = $.$cast(angle, $.$$.S.Single);
                                    $i6.Sections = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$hDPm.LCFCCSWD.DoughnutSection), [(() =>
                                    {
                                        //new $.$hDPm.LCFCCSWD.DoughnutSection()
                                        const $t7 = $.$hDPm.LCFCCSWD.DoughnutSection;
                                        const $i7 = new $t7();
                                        $i7.$ctor$1();
                                        $i7.Proportion = $.$cast(storedProportion, $.$$.S.Single);
                                        $i7.Color = $.$$.System.Array.$ReadT1.call(theme.Model.ChartColors, 2);
                                        return $i7;
                                    })()], [-1], null);
                                    return $i6;
                                })());
                            }, $ItFLXg ??= {"r":65537,"p":[{"n":"builder","p":46945962}],"n":"","d":4613021,"h":0,"f":17825794})).LCFCCSF$ISVGGroupBuilder$Group(new ($.$$.S.Action$$($.$hDPm.LCFCCSF.ISVGBuilder))().$ctor(this,  (/*builder*/ builder) =>
                            {
                                return builder.LCFCCSF$ISVGBuilder$MoveTo(0.5, 0.25).LCFCCSF$ISVGTextBuilder$Text("Harvest").LCFCCSF$ISVGBuilder$FillColor($.$$.System.Array.$ReadT1.call(theme.Model.ChartColors, 0)).LCFCCSF$ISVGBuilder$BaseLine(4/*BaseLine.Middle*/).LCFCCSF$ISVGBuilder$TextAnchor(2/*TextAnchor.Middle*/).LCFCCSF$ISVGBuilder$Attribute("class", "mdi mdi-sunlight fsz-7").LCFCCSF$ISVGBuilder$MoveTo(0.5, 0.33).LCFCCSF$ISVGTextBuilder$Text((() =>
                                {
                                    var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                                    $handler.AppendFormatted($.$box(((this.ViewModel.Device$1.Received?.Status?.SolarHarvest ?? null) ?? 0), $.$$.S.Double), null, "N2");
                                    $handler.AppendLiteral("Ah");
                                    return $handler.ToStringAndClear                            ();
                                })()).LCFCCSF$ISVGBuilder$FillColor($.$$.System.Array.$ReadT1.call(theme.Model.ChartColors, 0)).LCFCCSF$ISVGBuilder$BaseLine(4/*BaseLine.Middle*/).LCFCCSF$ISVGBuilder$TextAnchor(2/*TextAnchor.Middle*/).LCFCCSF$ISVGBuilder$Attribute("class", "fsz-10 fw-bold");
                            }, $IJerma ??= {"r":65537,"p":[{"n":"builder","p":46945962}],"n":"","d":4613021,"h":0,"f":17825794})).LCFCCSF$ISVGGroupBuilder$Group(new ($.$$.S.Action$$($.$hDPm.LCFCCSF.ISVGBuilder))().$ctor(this,  (/*builder*/ builder) =>
                            {
                                return builder.LCFCCSF$ISVGBuilder$MoveTo(0.5, 0.45).LCFCCSF$ISVGTextBuilder$Text("Usage").LCFCCSF$ISVGBuilder$FillColor($.$$.System.Array.$ReadT1.call(theme.Model.ChartColors, 1)).LCFCCSF$ISVGBuilder$BaseLine(4/*BaseLine.Middle*/).LCFCCSF$ISVGBuilder$TextAnchor(2/*TextAnchor.Middle*/).LCFCCSF$ISVGBuilder$Attribute("class", "mdi mdi-sunlight fsz-7").LCFCCSF$ISVGBuilder$MoveTo(0.5, 0.54).LCFCCSF$ISVGTextBuilder$Text((() =>
                                {
                                    var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                                    $handler.AppendFormatted($.$box(((this.ViewModel.Device$1.Received?.Status?.UsageCharge ?? null) ?? 0), $.$$.S.Double), null, "N2");
                                    $handler.AppendLiteral("Ah");
                                    return $handler.ToStringAndClear                            ();
                                })()).LCFCCSF$ISVGBuilder$FillColor($.$$.System.Array.$ReadT1.call(theme.Model.ChartColors, 1)).LCFCCSF$ISVGBuilder$BaseLine(4/*BaseLine.Middle*/).LCFCCSF$ISVGBuilder$TextAnchor(2/*TextAnchor.Middle*/).LCFCCSF$ISVGBuilder$Attribute("class", "fsz-10 fw-bold");
                            }, $iFGNgd ??= {"r":65537,"p":[{"n":"builder","p":46945962}],"n":"","d":4613021,"h":0,"f":17825794})).LCFCCSF$ISVGGroupBuilder$Group(new ($.$$.S.Action$$($.$hDPm.LCFCCSF.ISVGBuilder))().$ctor(this,  (/**/ builder) =>
                            {
                                return builder.LCFCCSF$ISVGBuilder$MoveTo(0.5, 0.67).LCFCCSF$ISVGTextBuilder$Text("Stored").LCFCCSF$ISVGBuilder$FillColor($.$$.System.Array.$ReadT1.call(theme.Model.ChartColors, 2)).LCFCCSF$ISVGBuilder$BaseLine(4/*BaseLine.Middle*/).LCFCCSF$ISVGBuilder$TextAnchor(2/*TextAnchor.Middle*/).LCFCCSF$ISVGBuilder$Attribute("class", "mdi mdi-sunlight fsz-7").LCFCCSF$ISVGBuilder$MoveTo(0.5, 0.75).LCFCCSF$ISVGTextBuilder$Text((() =>
                                {
                                    var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                                    $handler.AppendFormatted($.$box(((this.ViewModel.Device$1.Received?.Status?.BatteryCharge ?? null) ?? 0), $.$$.S.Double), null, "N2");
                                    $handler.AppendLiteral("Ah");
                                    return $handler.ToStringAndClear                            ();
                                })()).LCFCCSF$ISVGBuilder$FillColor($.$$.System.Array.$ReadT1.call(theme.Model.ChartColors, 2)).LCFCCSF$ISVGBuilder$BaseLine(4/*BaseLine.Middle*/).LCFCCSF$ISVGBuilder$TextAnchor(2/*TextAnchor.Middle*/).LCFCCSF$ISVGBuilder$Attribute("class", "fsz-10 fw-bold");
                            }, $bzPtPh ??= {"r":65537,"p":[{"n":"builder","p":46945962}],"n":"","d":4613021,"h":0,"f":17825794}));
                            __builder3.OpenElement(5, "div");
                            __builder3.AddAttribute$5(6, "class", "pd");
                            __builder3.OpenElement(7, "div");
                            __builder3.AddAttribute$5(8, "class", "wx-25 mgx-a");
                            __builder3.AddContent$1(9, builder.LCFCCSF$ISVGBuilder$Build());
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(10, "\r\n                ");
                            __builder3.OpenElement(11, "div");
                            __builder3.AddAttribute$5(12, "class", "mgt grid gap-1 colm-15");
                            /*var*/ let cards = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [{ Icon : "mdi mdi-battery-50", Theme : $.$fPer.LCFC.Theme.Primary, Label : "Battery Voltage", Value : batteryVoltage, Unit : "V", Maximum : 0 }, { Icon : `mdi mdi-battery-${$.$strNN(((this.ViewModel.Device$1.Received?.Status?.BatteryCurrent ?? null) > 0 ? "plus" : "minus"))}`, Theme : $.$fPer.LCFC.Theme.Error, Label : "Charge/Discharge Current", Value : (this.ViewModel.Device$1.Received?.Status?.BatteryCurrent ?? null) ?? 0, Unit : "A", Maximum : 0 }, { Icon : "mdi mdi-solar-panel", Theme : $.$fPer.LCFC.Theme.Secondary, Label : "Solar Voltage", Value : solarVoltage, Unit : "V", Maximum : 0 }, { Icon : "mdi mdi-solar-panel", Theme : $.$fPer.LCFC.Theme.Error, Label : "Solar Current", Value : (this.ViewModel.Device$1.Received?.Status?.SolarCurrent ?? null) ?? 0, Unit : "A", Maximum : (this.ViewModel.Device$1.Received?.Status?.MaximumSolarCurrent ?? null) ?? 0 }, { Icon : "mdi mdi-battery-plus", Theme : $.$fPer.LCFC.Theme.Info, Label : "Utility Charging Current", Value : (this.ViewModel.Device$1.Received?.Status?.InverterChargeCurrent ?? null) ?? 0, Unit : "A", Maximum : 0 }, { Icon : `mdi mdi-battery-plus`, Theme : $.$fPer.LCFC.Theme.Info, Label : "Load Current", Value : (this.ViewModel.Device$1.Received?.Status?.UsageCurrent ?? null) ?? 0, Unit : "A", Maximum : (this.ViewModel.Device$1.Received?.Status?.MaximumLoadCurrent ?? null) ?? 0 }], null, null);
                            let $i8 = 0;
                            let $arr8 = cards;
                            while ($i8 < $arr8.length)
                            {
                                let card = $arr8[$i8++];
                                __builder3.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 13);
                                __builder3.AddComponentParameter(14, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 21/*CardFeatures.Default*/ | 4/*CardFeatures.Shadow*/ | 2/*CardFeatures.Corner*/), $.$hDPm.LCFCCC$1.CardFeatures));
                                __builder3.AddAttribute$3(15, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(16, "div");
                                    __builder4.AddAttribute$5(17, "class", "flex");
                                    __builder4.OpenElement(18, "i");
                                    __builder4.AddAttribute$5(19, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN((card.Icon)) + " mgr") + " mgy-a") + " cl-") + $.$strNN(($.$$.S.String.ToLower.call(card.Theme.ToString())))) + " fsz-25");
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(20, "\r\n                                ");
                                    __builder4.OpenElement(21, "h2");
                                    __builder4.AddAttribute$5(22, "class", $.$strNN($.$strNN("mg-a" + " cl-") + $.$strNN(($.$$.S.String.ToLower.call(card.Theme.ToString())))) + " text-center");
                                    __builder4.AddContent$4(23, (() =>
                                    {
                                        var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(0, 2);
                                        $handler.AppendFormatted($.$box(card.Value, $.$$.S.Double), null, "N2");
                                        $handler.AppendFormatted($.$box(card.Unit, $.$$.S.String), null, null);
                                        return $handler.ToStringAndClear                                ();
                                    })());
                                    __builder4.CloseElement();
                                    if (card.Maximum !== 0)
                                    {
                                        __builder4.OpenElement(24, "small");
                                        __builder4.AddContent$4(25, (() =>
                                        {
                                            var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(0, 1);
                                            $handler.AppendFormatted($.$box(card.Maximum, $.$$.S.Double), null, "N2");
                                            return $handler.ToStringAndClear                                    ();
                                        })());
                                        __builder4.CloseElement();
                                    }
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(26, "\r\n                            ");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCP$5.ProgressBar, 27);
                                    __builder4.AddComponentParameter(28, "Progress", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 50), $.$$.S.Int32));
                                    __builder4.AddComponentParameter(29, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, card.Theme));
                                    __builder4.AddComponentParameter(30, "BackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Tertiary));
                                    __builder4.AddComponentParameter(31, "Class", "corner mgt");
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(32, "\r\n                            ");
                                    __builder4.OpenElement(33, "span");
                                    __builder4.AddAttribute$5(34, "class", "text-center d-block mgt");
                                    __builder4.AddContent$4(35, card.Label);
                                    __builder4.CloseElement();
                                }), $Cneqjl ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":4613021,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                        }, $ZmrzRc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":4613021,"h":0,"f":17825794});
                    }), $zYwAce ??= {"r":6881395,"p":[{"n":"theme","p":$.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors).$h}],"n":"","d":4613021,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $DSqMWj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":4613021,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12889514909)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8594547613)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594547613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594547613)
            
            //--TRIMMABLE-BOUNDARY-START(8594547613)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8594547613)
            
            static $h = 4613021;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$CgOi.LCIDGV.GreenHouseLoggerDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51544220573),
    {
      "p": 4547485,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069384093,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42954285981,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 4613021,
      "h": 51544220573,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51544220573),
//--TRIMMABLE-BOUNDARY-START(34364351389),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479449501,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 4613021,
      "h": 34364351389,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34364351389)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47249253277),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 4613021,
      "h": 47249253277,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47249253277),
//--TRIMMABLE-BOUNDARY-START(12889514909),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 4613021,
      "h": 12889514909,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12889514909)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594547613),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4613021,
      "h": 8594547613,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594547613)
  ],
  "h": 4613021
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GreenHouseLogger.Views.GreenHouseLoggerDeviceDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GreenHouseLogger${separator}Views${separator}GreenHouseLoggerDeviceDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4613021)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(25501)
