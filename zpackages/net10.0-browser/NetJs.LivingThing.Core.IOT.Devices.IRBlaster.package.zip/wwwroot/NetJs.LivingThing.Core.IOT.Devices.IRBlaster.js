
//--TRIMMABLE-BOUNDARY-START(55218)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $LhAmZc;
    let $KjKXCk;
    let $Wvasfi;
    let $NtKMOd;
    let $BddGKb;
    let $KyfYOb;
    let $kXuydf;
    let $vkipBe;
    let $eoVbof;
    let $BaDhNa;
    let $xJfxhj;
    let $dkrqlk;
    let $xkynbb;
    let $fxZekh;
    let $TNRoJi;
    let $UUHOgg;
    let $GmGTsi;
    let $NKSoRa;
    let $dybFVi;
    let $OvJhpl;
    let $NDpjqe;
    let $XhDRLf;
    let $lzZnxd;
    let $FAxIFc;
    let $fPOpKh;
    let $QPKfrb;
    let $eNMJri;
    let $dwnhzd;
    let $RuyVVh;
    let $BrHCmf;
    let $vjOGkb;
    let $lWUzkj;
    let $mbQpxh;
    let $rEgnNg;
    let $fQERGa;
    let $yhUKsf;
    let $tFDfFh;
    let $yisbOk;
    let $EOrJKh;
    let $xlQApa;
    let $OAzNvk;
    let $CSMTFk;
    let $XQkdqg;
    let $QykLKh;
    let $yeAvLi;
    let $YLWJIb;
    let $iMZgqj;
    let $HPmrzb;
    let $dyHKTi;
    let $GWDRkc;
    let $ntVhyg;
    let $itqfRf;
    let $hFlDMb;
    let $SIffYf;
    let $YNqlAb;
    let $CdsRxj;
    let $RZwwXb;
    let $wYIvLb;
    let $ihLWEd;
    let $GAfumc;
    let $GDExbh;
    let $hhvCxg;
    let $PoIGJb;
    let $bwmDoj;
    let $vwXisj;
    let $hVwXrb;
    let $DlsFEk;
    let $SjGQGd;
    let $Dlfdla;
    let $QLIdMi;
    let $YYxSTd;
    let $YvGsEd;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.IRBlaster", 
    {
  "h": 55218,
  "f": "LivingThing.Core.IOT.Devices.IRBlaster",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.IRBlaster",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.IRBlaster",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5JUkJsYXN0ZXIuSVJCbGFzdGVyRGV2aWNlIjogew0KICAgICAgIkNhdGVnb3JpZXMiOiBbICJTbWFydCBIb21lIiBdLA0KICAgICAgIk5hbWUiOiAiSVIgQmxhc3RlciIsDQogICAgICAiRGVzY3JpcHRpb24iOiAiU21hcnQgbG9uZyByYW5nZSBJUiBlbWl0dGVyIGZvciByZW1vdGUgY29udHJvbCIsDQogICAgICAiQmFubmVySW1hZ2UiOiAifi9JUkJsYXN0ZXIvaW1nL2Jhbm5lci5qcGciLA0KICAgICAgIkljb24iOiB7ICJOYW1lIjogIm1kaSBtZGktbGlnaHRidWxiLW9uIiB9LA0KICAgICAgIlRoZW1lQ29sb3IiOiAiI2Q3N2JiYSIsDQogICAgICAiRmxhZ3MiOiAiRmVhdHVyZWQsUHVibGlzaGVkIiwNCiAgICAgICJTZWN1cml0aWVzIjogIkNoYWxsZW5nZUhhbmRTaGFrZUF1dGhlbnRpY2F0aW9uUHJvdG9jb2wsQWR2YW5jZWRFbmNyeXB0aW9uU3RhbmRhcmQsRWxsaXB0aWNDdXJ2ZUZpcm13YXJlVXBkYXRlU2lnbmluZyIsDQogICAgICAiRmVhdHVyZXMiOiBbDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiUmVtb3RlIENvbnRyb2wiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJTd2l0Y2ggQXBwbGlhbmNlcyBPbi9PZmYsIGV2ZW4gcmVtb3RlbHkuIiwNCiAgICAgICAgICAiSWNvbiI6IHsgIkljb24iOiAiUmVtb3RlVFYiIH0NCiAgICAgICAgfQ0KICAgICAgXSwNCiAgICAgICJCZW5lZml0cyI6IFsNCiAgICAgICAgew0KICAgICAgICAgICJUaXRsZSI6ICJSZWFsLXRpbWUgQWNjZXNzIiwNCiAgICAgICAgICAiRGVzY3JpcHRpb24iOiAiU3RheSBjb25lY3RlZCB0byB5b3VyIGhvbWUgZnJvbSBhbnl3aGVyZSB5b3UgbWlnaHQgYmUiLA0KICAgICAgICAgICJJY29uIjogeyAiSWNvbiI6ICJDaGFydCIgfQ0KICAgICAgICB9DQogICAgICBdLA0KICAgICAgIlNwZWNpZmljYXRpb25zIjogWw0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIlN1cHBseSBWb2x0YWdlIiwNCiAgICAgICAgICAiVmFsdWUiOiAiMTJWIg0KICAgICAgICB9DQogICAgICBdLA0KICAgICAgIlN0YXR1c05hbWVzIjogIlN0YXR1cy5TdGF0dXMsU3RhdHVzLkNvdW50RG93biINCiAgICB9DQogIH0NCn0="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(710578)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterClearReBlastControlModelCustomAttributesProvider`, ($self) => class IRBlasterClearReBlastControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295677874)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295677874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295677874)
            
            static $h = 710578;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295677874),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 710578,
      "h": 4295677874,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295677874)
  ],
  "h": 710578
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterClearReBlastControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterClearReBlastControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(710578)
        
        

        //--TRIMMABLE-BOUNDARY-START(2152370)
        $asm.$cls(`$HGGn.LCIDIM.IRBlasterDeviceModelCustomAttributesProvider`, ($self) => class IRBlasterDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297119666)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297119666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297119666)
            
            static $h = 2152370;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297119666),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2152370,
      "h": 4297119666,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297119666)
  ],
  "h": 2152370
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Models${separator}IRBlasterDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2152370)
        
        

        //--TRIMMABLE-BOUNDARY-START(3856306)
        $asm.$cls(`$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class IRBlasterDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298823602)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298823602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$HGGn.LCIDIS$2.IRBlasterStatusModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298823602)
            
            static $h = 3856306;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298823602),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3856306,
      "h": 4298823602,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298823602)
  ],
  "h": 3856306
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Statuses${separator}IRBlasterDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3856306)
        
        

        //--TRIMMABLE-BOUNDARY-START(186290)
        $asm.$cls(`$HGGn.LCIDI._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295153586)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295153586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$HGGn.LCIDI.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295153586)
            
            static $h = 186290;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295153586),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 186290,
      "h": 4295153586,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295153586)
  ],
  "h": 186290
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(186290)
        
        

        //--TRIMMABLE-BOUNDARY-START(382898)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterBlastControlModelCustomAttributesProvider`, ($self) => class IRBlasterBlastControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295350194)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295350194)
            
            //--TRIMMABLE-BOUNDARY-START(8590317490)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590317490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$HGGn.LCIDIC.IRBlasterBlastControlModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(4, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Frequency", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            $i3.ConvertType = ($.$$.S.UInt16.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Code", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (4);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Repeat", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (5);
                            $i5.ConvertType = ($.$$.S.Byte.$type);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PersistIndex", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (6);
                            $i6.ConvertType = ($.$$.S.Int16.$type);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$HGGn.LCIDIC.IRBlasterBlastControlModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $BddGKb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":382898,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $KyfYOb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":382898,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590317490)
            
            static $h = 382898;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590317490),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 382898,
      "h": 8590317490,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590317490)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295350194),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 382898,
      "h": 4295350194,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295350194)
  ],
  "h": 382898
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterBlastControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterBlastControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(382898)
        
        

        //--TRIMMABLE-BOUNDARY-START(2676658)
        $asm.$cls(`$HGGn.LCIDIM.IRBlasterServiceModelCustomAttributesProvider`, ($self) => class IRBlasterServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297643954)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297643954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297643954)
            
            static $h = 2676658;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297643954),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2676658,
      "h": 4297643954,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297643954)
  ],
  "h": 2676658
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Models${separator}IRBlasterServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2676658)
        
        

        //--TRIMMABLE-BOUNDARY-START(3266482)
        $asm.$cls(`$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class IRBlasterDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298233778)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298233778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298233778)
            
            static $h = 3266482;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298233778),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3266482,
      "h": 4298233778,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298233778)
  ],
  "h": 3266482
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Settings${separator}IRBlasterDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3266482)
        
        

        //--TRIMMABLE-BOUNDARY-START(2021298)
        $asm.$cls(`$HGGn.LCIDI.IRBlasterUtility`, ($self) => class IRBlasterUtility
        {
            //--TRIMMABLE-BOUNDARY-START(4296988594)
            static /*ulong */ EncodeNumber(/*string*/ displayId, /*int*/ commandType, /*int*/ brightness, /*double*/ displayNumber)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296988594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let bytes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [8], null);
                /*var*/ let hexId = $.$$.S.String.Substring.call(displayId, ((displayId.length - 4) | 0), 4);
                /*int*/  function HexToInt(/*char*/ hex)
                {
                    if (hex < /*A*/ 65)
                    {
                        return hex - /*0*/ 48;
                    }
                    return ((10 + (hex - /*A*/ 65)) | 0);
                }
                /*var*/ let byteIds = $.$sl.SL.Enumerable.ToArray($.$$.S.Int32, $.$sl.SL.Enumerable.Select$1($.$$.S.Char, $.$$.S.Int32, hexId, new ($.$$.S.Func$$$($.$$.S.Char, $.$$.S.Int32))().$ctor(this, HexToInt, $GmGTsi ??= {"r":655361,"p":[{"n":"hex","p":458753}],"n":"HexToInt","d":2021298,"h":0,"f":16777218})));
                $.$$.System.Array.$WriteT1.call(bytes, $.$cast(((($.$$.System.Array.$ReadT1.call(byteIds, 3) + (($.$$.System.Array.$ReadT1.call(byteIds, 2) * 16) | 0)) | 0)), $.$$.S.Byte), 0);
                $.$$.System.Array.$WriteT1.call(bytes, $.$cast(((($.$$.System.Array.$ReadT1.call(byteIds, 1) + (($.$$.System.Array.$ReadT1.call(byteIds, 0) * 16) | 0)) | 0)), $.$$.S.Byte), 1);
                $.$$.System.Array.$WriteT1.call(bytes, 0, 2);
                /*int*/ let iNumber = $.$cast(displayNumber, $.$$.S.Int32);
                if (iNumber !== displayNumber)
                {
                    $.$$.System.Array.$WriteT1.call(bytes, 2, 3);
                    iNumber = $.$cast((displayNumber * 100), $.$$.S.Int32);
                }
                else 
                {
                    $.$$.System.Array.$WriteT1.call(bytes, 0, 3);
                }
                /*var*/ let bright = ($.trunc(($.$$.S.Math.Min$4(brightness, 100)) / 30)) % 4;
                $.$$.System.Array.$WriteT1.call(bytes, $.$$.System.Array.$ReadT1.call(bytes, 3) | $.$cast((bright << 6), $.$$.S.Byte), 3);
                $.$$.System.Array.$WriteT1.call(bytes, $.$cast((((($.trunc(iNumber / 10)) % 10) << 4) | (($.trunc(iNumber / 1)) % 10)), $.$$.S.Byte), 4);
                $.$$.System.Array.$WriteT1.call(bytes, $.$cast((((($.trunc(iNumber / 1000)) % 10) << 4) | (($.trunc(iNumber / 100)) % 10)), $.$$.S.Byte), 5);
                $.$$.System.Array.$WriteT1.call(bytes, $.$cast((((($.trunc(iNumber / 100000)) % 10) << 4) | (($.trunc(iNumber / 10000)) % 10)), $.$$.S.Byte), 6);
                /*var*/ let checksum = ((((((((((((((((((((((((((((($.$$.System.Array.$ReadT1.call(bytes, 0) & 15) + ($.$$.System.Array.$ReadT1.call(bytes, 0) >>> 4)) | 0) + ($.$$.System.Array.$ReadT1.call(bytes, 1) & 15)) | 0) + ($.$$.System.Array.$ReadT1.call(bytes, 1) >>> 4)) | 0) + ($.$$.System.Array.$ReadT1.call(bytes, 2) & 15)) | 0) + ($.$$.System.Array.$ReadT1.call(bytes, 2) >>> 4)) | 0) + ($.$$.System.Array.$ReadT1.call(bytes, 3) & 15)) | 0) + ($.$$.System.Array.$ReadT1.call(bytes, 3) >>> 4)) | 0) + ($.$$.System.Array.$ReadT1.call(bytes, 4) & 15)) | 0) + ($.$$.System.Array.$ReadT1.call(bytes, 4) >>> 4)) | 0) + ($.$$.System.Array.$ReadT1.call(bytes, 5) & 15)) | 0) + ($.$$.System.Array.$ReadT1.call(bytes, 5) >>> 4)) | 0) + ($.$$.System.Array.$ReadT1.call(bytes, 6) & 15)) | 0) + ($.$$.System.Array.$ReadT1.call(bytes, 6) >>> 4)) | 0) + (commandType & 15)) | 0);
                checksum = ((256 - (checksum & 15)) | 0);
                $.$$.System.Array.$WriteT1.call(bytes, $.$cast((((checksum & 15) << 4) | (commandType & 15)), $.$$.S.Byte), 7);
                return (BigInt.asUintN(64, ($.$cast($.$$.System.Array.$ReadT1.call(bytes, 0), $.$$.S.UInt64)) << 0n)) | (BigInt.asUintN(64, ($.$cast($.$$.System.Array.$ReadT1.call(bytes, 1), $.$$.S.UInt64)) << 8n)) | (BigInt.asUintN(64, ($.$cast($.$$.System.Array.$ReadT1.call(bytes, 2), $.$$.S.UInt64)) << 16n)) | (BigInt.asUintN(64, ($.$cast($.$$.System.Array.$ReadT1.call(bytes, 3), $.$$.S.UInt64)) << 24n)) | (BigInt.asUintN(64, ($.$cast($.$$.System.Array.$ReadT1.call(bytes, 4), $.$$.S.UInt64)) << 32n)) | (BigInt.asUintN(64, ($.$cast($.$$.System.Array.$ReadT1.call(bytes, 5), $.$$.S.UInt64)) << 40n)) | (BigInt.asUintN(64, ($.$cast($.$$.System.Array.$ReadT1.call(bytes, 6), $.$$.S.UInt64)) << 48n)) | (BigInt.asUintN(64, ($.$cast($.$$.System.Array.$ReadT1.call(bytes, 7), $.$$.S.UInt64)) << 56n));
            }
            //--TRIMMABLE-BOUNDARY-END(4296988594)
            
            static $h = 2021298;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296988594),
    {
      "r": 983041,
      "p": [
        {
          "n": "displayId",
          "p": 1310721
        },
        {
          "n": "commandType",
          "p": 655361
        },
        {
          "n": "brightness",
          "p": 655361
        },
        {
          "n": "displayNumber",
          "p": 1179649
        }
      ],
      "n": "EncodeNumber",
      "d": 2021298,
      "h": 4296988594,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296988594)
  ],
  "h": 2021298
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.IRBlasterUtility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}IRBlasterUtility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2021298)
        
        

        //--TRIMMABLE-BOUNDARY-START(2545586)
        $asm.$cls(`$HGGn.LCIDIM.IRBlasterDeviceScopeModelTypeDescriptorBuilder`, ($self) => class IRBlasterDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592480178)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592480178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$HGGn.LCIDIM.IRBlasterDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$HGGn.LCIDIM.IRBlasterDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $kXuydf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2545586,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$HGGn.LCIDIM.IRBlasterDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592480178)
            
            //--TRIMMABLE-BOUNDARY-START(4297512882)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297512882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297512882)
            
            //--TRIMMABLE-BOUNDARY-START(4297512882)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297512882)
            
            static $h = 2545586;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592480178),
    {
      "r": 65537,
      "n": "Register",
      "d": 2545586,
      "h": 8592480178,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592480178)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297512882),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2545586,
      "h": 4297512882,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297512882)
  ],
  "h": 2545586
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Models${separator}IRBlasterDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2545586)
        
        

        //--TRIMMABLE-BOUNDARY-START(4315058)
        $asm.$cls(`$HGGn.LCIDI.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4299282354)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299282354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$HGGn.LCIDIC.IRBlasterBlastControlModelTypeDescriptorBuilder.Register();
                $.$HGGn.LCIDIC.IRBlasterClearReBlastControlModelTypeDescriptorBuilder.Register();
                $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptorBuilder.Register();
                $.$HGGn.LCIDIM.IRBlasterDeviceModelTypeDescriptorBuilder.Register();
                $.$HGGn.LCIDIM.IRBlasterDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$HGGn.LCIDIM.IRBlasterServiceModelTypeDescriptorBuilder.Register();
                $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$HGGn.LCIDIS$2.IRBlasterStatusModelTypeDescriptorBuilder.Register();
                $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$HGGn.LCIDIS$1.IRBlasterDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4299282354)
            
            static $h = 4315058;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299282354),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 4315058,
      "h": 4299282354,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4299282354)
  ],
  "h": 4315058
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4315058)
        
        

        //--TRIMMABLE-BOUNDARY-START(1365938)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterSetNumberControlModelCustomAttributesProvider`, ($self) => class IRBlasterSetNumberControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296333234)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296333234)
            
            //--TRIMMABLE-BOUNDARY-START(8591300530)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591300530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$HGGn.LCIDIC.IRBlasterSetNumberControlModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(7, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Frequency", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            $i3.ConvertType = ($.$$.S.UInt16.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DisplayId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (3);
                            $i4.Exclude = $.$cast((128), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Number", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (4);
                            $i5.Exclude = $.$cast((128), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Brightness", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (4);
                            $i6.Exclude = $.$cast((128), $.$fPer.LCFCA$1.SchemaType);
                            $i6.InputType = $.$cast(6n, $.$fPer.LCFC.InputType);
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Minumum=0", "//Maximum=100"], [-1], null);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Code", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (4);
                            $i7.Exclude = $.$cast((1), $.$fPer.LCFCA$1.SchemaType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Repeat", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Order = (5);
                            $i8.ConvertType = ($.$$.S.Byte.$type);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PersistIndex", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Order = (6);
                            $i9.ConvertType = ($.$$.S.Int16.$type);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$HGGn.LCIDIC.IRBlasterSetNumberControlModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $xkynbb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1365938,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $fxZekh ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1365938,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591300530)
            
            static $h = 1365938;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591300530),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1365938,
      "h": 8591300530,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591300530)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296333234),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1365938,
      "h": 4296333234,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296333234)
  ],
  "h": 1365938
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterSetNumberControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1365938)
        
        

        //--TRIMMABLE-BOUNDARY-START(2414514)
        $asm.$cls(`$HGGn.LCIDIM.IRBlasterDeviceScopeModelCustomAttributesProvider`, ($self) => class IRBlasterDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297381810)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297381810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297381810)
            
            static $h = 2414514;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297381810),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2414514,
      "h": 4297381810,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297381810)
  ],
  "h": 2414514
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Models${separator}IRBlasterDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2414514)
        
        

        //--TRIMMABLE-BOUNDARY-START(1038258)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterDeviceSendDataModelCustomAttributesProvider`, ($self) => class IRBlasterDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296005554)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296005554)
            
            //--TRIMMABLE-BOUNDARY-START(8590972850)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590972850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Blast", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (13432);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $xJfxhj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1038258,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $dkrqlk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1038258,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandsModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590972850)
            
            static $h = 1038258;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590972850),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1038258,
      "h": 8590972850,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590972850)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296005554),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1038258,
      "h": 4296005554,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296005554)
  ],
  "h": 1038258
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1038258)
        
        

        //--TRIMMABLE-BOUNDARY-START(2283442)
        $asm.$cls(`$HGGn.LCIDIM.IRBlasterDeviceModelTypeDescriptorBuilder`, ($self) => class IRBlasterDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592218034)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592218034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$HGGn.LCIDIM.IRBlasterDeviceModelTypeDescriptor()
                        const $t1 = $.$HGGn.LCIDIM.IRBlasterDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $eoVbof ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2283442,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$HGGn.LCIDIM.IRBlasterDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592218034)
            
            //--TRIMMABLE-BOUNDARY-START(4297250738)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297250738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297250738)
            
            //--TRIMMABLE-BOUNDARY-START(4297250738)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297250738)
            
            static $h = 2283442;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592218034),
    {
      "r": 65537,
      "n": "Register",
      "d": 2283442,
      "h": 8592218034,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592218034)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297250738),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2283442,
      "h": 4297250738,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297250738)
  ],
  "h": 2283442
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Models${separator}IRBlasterDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2283442)
        
        

        //--TRIMMABLE-BOUNDARY-START(3528626)
        $asm.$cls(`$HGGn.LCIDIS$1.IRBlasterDeviceSettingsCustomAttributesProvider`, ($self) => class IRBlasterDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298495922)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298495922)
            
            //--TRIMMABLE-BOUNDARY-START(8593463218)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593463218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$HGGn.LCIDIS$1.IRBlasterDeviceSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Displays", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.InputType = $.$cast(1152921504606846976n, $.$fPer.LCFC.InputType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$HGGn.LCIDIS$1.IRBlasterDeviceSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $TNRoJi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3528626,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $UUHOgg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3528626,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593463218)
            
            static $h = 3528626;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593463218),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3528626,
      "h": 8593463218,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593463218)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298495922),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3528626,
      "h": 4298495922,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298495922)
  ],
  "h": 3528626
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Settings${separator}IRBlasterDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3528626)
        
        

        //--TRIMMABLE-BOUNDARY-START(3397554)
        $asm.$cls(`$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class IRBlasterDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593332146)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593332146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $NKSoRa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3397554,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593332146)
            
            //--TRIMMABLE-BOUNDARY-START(4298364850)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298364850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298364850)
            
            //--TRIMMABLE-BOUNDARY-START(4298364850)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298364850)
            
            static $h = 3397554;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593332146),
    {
      "r": 65537,
      "n": "Register",
      "d": 3397554,
      "h": 8593332146,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593332146)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298364850),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3397554,
      "h": 4298364850,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298364850)
  ],
  "h": 3397554
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Settings${separator}IRBlasterDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3397554)
        
        

        //--TRIMMABLE-BOUNDARY-START(4249522)
        $asm.$cls(`$HGGn.LCIDIS$2.IRBlasterStatusModelTypeDescriptorBuilder`, ($self) => class IRBlasterStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594184114)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594184114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$HGGn.LCIDIS$2.IRBlasterStatusModelTypeDescriptor()
                        const $t1 = $.$HGGn.LCIDIS$2.IRBlasterStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $lWUzkj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4249522,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$HGGn.LCIDIS$2.IRBlasterStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594184114)
            
            //--TRIMMABLE-BOUNDARY-START(4299216818)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299216818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299216818)
            
            //--TRIMMABLE-BOUNDARY-START(4299216818)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299216818)
            
            static $h = 4249522;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594184114),
    {
      "r": 65537,
      "n": "Register",
      "d": 4249522,
      "h": 8594184114,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594184114)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299216818),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4249522,
      "h": 4299216818,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299216818)
  ],
  "h": 4249522
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Statuses${separator}IRBlasterStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4249522)
        
        

        //--TRIMMABLE-BOUNDARY-START(513970)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterBlastControlModelTypeDescriptorBuilder`, ($self) => class IRBlasterBlastControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590448562)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590448562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$HGGn.LCIDIC.IRBlasterBlastControlModelTypeDescriptor()
                        const $t1 = $.$HGGn.LCIDIC.IRBlasterBlastControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterBlastControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $QykLKh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":513970,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$HGGn.LCIDIC.IRBlasterBlastControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590448562)
            
            //--TRIMMABLE-BOUNDARY-START(4295481266)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295481266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295481266)
            
            //--TRIMMABLE-BOUNDARY-START(4295481266)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295481266)
            
            static $h = 513970;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590448562),
    {
      "r": 65537,
      "n": "Register",
      "d": 513970,
      "h": 8590448562,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590448562)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295481266),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 513970,
      "h": 4295481266,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295481266)
  ],
  "h": 513970
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterBlastControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterBlastControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(513970)
        
        

        //--TRIMMABLE-BOUNDARY-START(1497010)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptorBuilder`, ($self) => class IRBlasterSetNumberControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591431602)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591431602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor()
                        const $t1 = $.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $CdsRxj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1497010,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$HGGn.LCIDIC.IRBlasterSetNumberControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591431602)
            
            //--TRIMMABLE-BOUNDARY-START(4296464306)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296464306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296464306)
            
            //--TRIMMABLE-BOUNDARY-START(4296464306)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296464306)
            
            static $h = 1497010;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591431602),
    {
      "r": 65537,
      "n": "Register",
      "d": 1497010,
      "h": 8591431602,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591431602)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296464306),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1497010,
      "h": 4296464306,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296464306)
  ],
  "h": 1497010
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterSetNumberControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1497010)
        
        

        //--TRIMMABLE-BOUNDARY-START(2807730)
        $asm.$cls(`$HGGn.LCIDIM.IRBlasterServiceModelTypeDescriptorBuilder`, ($self) => class IRBlasterServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592742322)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592742322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$HGGn.LCIDIM.IRBlasterServiceModelTypeDescriptor()
                        const $t1 = $.$HGGn.LCIDIM.IRBlasterServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $OvJhpl ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2807730,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$HGGn.LCIDIM.IRBlasterServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592742322)
            
            //--TRIMMABLE-BOUNDARY-START(4297775026)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297775026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297775026)
            
            //--TRIMMABLE-BOUNDARY-START(4297775026)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297775026)
            
            static $h = 2807730;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592742322),
    {
      "r": 65537,
      "n": "Register",
      "d": 2807730,
      "h": 8592742322,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592742322)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297775026),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2807730,
      "h": 4297775026,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297775026)
  ],
  "h": 2807730
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Models${separator}IRBlasterServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2807730)
        
        

        //--TRIMMABLE-BOUNDARY-START(1169330)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class IRBlasterDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591103922)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591103922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $XhDRLf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1169330,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591103922)
            
            //--TRIMMABLE-BOUNDARY-START(4296136626)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296136626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296136626)
            
            //--TRIMMABLE-BOUNDARY-START(4296136626)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296136626)
            
            static $h = 1169330;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591103922),
    {
      "r": 65537,
      "n": "Register",
      "d": 1169330,
      "h": 8591103922,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591103922)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296136626),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1169330,
      "h": 4296136626,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296136626)
  ],
  "h": 1169330
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1169330)
        
        

        //--TRIMMABLE-BOUNDARY-START(3659698)
        $asm.$cls(`$HGGn.LCIDIS$1.IRBlasterDeviceSettingsTypeDescriptorBuilder`, ($self) => class IRBlasterDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593594290)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593594290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$HGGn.LCIDIS$1.IRBlasterDeviceSettingsTypeDescriptor()
                        const $t1 = $.$HGGn.LCIDIS$1.IRBlasterDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $dwnhzd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3659698,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$HGGn.LCIDIS$1.IRBlasterDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593594290)
            
            //--TRIMMABLE-BOUNDARY-START(4298626994)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298626994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298626994)
            
            //--TRIMMABLE-BOUNDARY-START(4298626994)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298626994)
            
            static $h = 3659698;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593594290),
    {
      "r": 65537,
      "n": "Register",
      "d": 3659698,
      "h": 8593594290,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593594290)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298626994),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3659698,
      "h": 4298626994,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298626994)
  ],
  "h": 3659698
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Settings${separator}IRBlasterDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3659698)
        
        

        //--TRIMMABLE-BOUNDARY-START(4118450)
        $asm.$cls(`$HGGn.LCIDIS$2.IRBlasterStatusModelCustomAttributesProvider`, ($self) => class IRBlasterStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299085746)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299085746)
            
            //--TRIMMABLE-BOUNDARY-START(8594053042)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594053042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$HGGn.LCIDIS$2.IRBlasterStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Blasting", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.ConvertType = ($.$$.S.UInt16.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("BlastCapacity", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.ConvertType = ($.$$.S.UInt16.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$HGGn.LCIDIS$2.IRBlasterStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $QPKfrb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4118450,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $eNMJri ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4118450,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594053042)
            
            static $h = 4118450;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594053042),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4118450,
      "h": 8594053042,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594053042)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299085746),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4118450,
      "h": 4299085746,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299085746)
  ],
  "h": 4118450
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Statuses${separator}IRBlasterStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4118450)
        
        

        //--TRIMMABLE-BOUNDARY-START(1628082)
        $asm.$cls(`$HGGn.LCIDI.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296595378)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296595378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$HGGn.LCIDIC.IRBlasterBlastControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$HGGn.LCIDIC.IRBlasterBlastControlModelCustomAttributesProvider, $.$HGGn.LCIDIC.IRBlasterBlastControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$HGGn.LCIDIC.IRBlasterClearReBlastControlModelCustomAttributesProvider, $.$HGGn.LCIDIC.IRBlasterClearReBlastControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$HGGn.LCIDIC.IRBlasterDeviceSendDataModelCustomAttributesProvider, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$HGGn.LCIDIC.IRBlasterSetNumberControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$HGGn.LCIDIC.IRBlasterSetNumberControlModelCustomAttributesProvider, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$HGGn.LCIDIM.IRBlasterDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$HGGn.LCIDIM.IRBlasterDeviceModelCustomAttributesProvider, $.$HGGn.LCIDIM.IRBlasterDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$HGGn.LCIDIM.IRBlasterDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$HGGn.LCIDIM.IRBlasterDeviceScopeModelCustomAttributesProvider, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$HGGn.LCIDIM.IRBlasterServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$HGGn.LCIDIM.IRBlasterServiceModelCustomAttributesProvider, $.$HGGn.LCIDIM.IRBlasterServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModelCustomAttributesProvider, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$HGGn.LCIDIS$2.IRBlasterStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$HGGn.LCIDIS$2.IRBlasterStatusModelCustomAttributesProvider, $.$HGGn.LCIDIS$2.IRBlasterStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettingsCustomAttributesProvider, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$HGGn.LCIDIS$1.IRBlasterDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$HGGn.LCIDIS$1.IRBlasterDeviceSettingsCustomAttributesProvider, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4296595378)
            
            static $h = 1628082;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296595378),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 1628082,
      "h": 4296595378,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296595378)
  ],
  "h": 1628082
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1628082)
        
        

        //--TRIMMABLE-BOUNDARY-START(841650)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterClearReBlastControlModelTypeDescriptorBuilder`, ($self) => class IRBlasterClearReBlastControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590776242)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590776242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$HGGn.LCIDIC.IRBlasterClearReBlastControlModelTypeDescriptor()
                        const $t1 = $.$HGGn.LCIDIC.IRBlasterClearReBlastControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterClearReBlastControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $hFlDMb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":841650,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590776242)
            
            //--TRIMMABLE-BOUNDARY-START(4295808946)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295808946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295808946)
            
            //--TRIMMABLE-BOUNDARY-START(4295808946)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295808946)
            
            static $h = 841650;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590776242),
    {
      "r": 65537,
      "n": "Register",
      "d": 841650,
      "h": 8590776242,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590776242)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295808946),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 841650,
      "h": 4295808946,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295808946)
  ],
  "h": 841650
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterClearReBlastControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterClearReBlastControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(841650)
        
        

        //--TRIMMABLE-BOUNDARY-START(3987378)
        $asm.$cls(`$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class IRBlasterDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593921970)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593921970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ntVhyg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3987378,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593921970)
            
            //--TRIMMABLE-BOUNDARY-START(4298954674)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298954674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298954674)
            
            //--TRIMMABLE-BOUNDARY-START(4298954674)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298954674)
            
            static $h = 3987378;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593921970),
    {
      "r": 65537,
      "n": "Register",
      "d": 3987378,
      "h": 8593921970,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593921970)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298954674),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3987378,
      "h": 4298954674,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298954674)
  ],
  "h": 3987378
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Statuses${separator}IRBlasterDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3987378)
        
        

        //--TRIMMABLE-BOUNDARY-START(1562546)
        $asm.$cls(`$HGGn.LCIDI.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181431730)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17181431730)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4296529842)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296529842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296529842)
            
            //--TRIMMABLE-BOUNDARY-START(4296529842)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296529842)
            
            static $h = 1562546;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181431730),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886464434,
        "f": 50331649
      },
      "n": "Paths",
      "d": 1562546,
      "h": 17181431730,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181431730)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296529842),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1562546,
      "h": 4296529842,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296529842)
  ],
  "h": 1562546
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1562546)
        
        

        //--TRIMMABLE-BOUNDARY-START(2938802)
        $asm.$cls(`$HGGn.LCIDI.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592873394)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592873394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$HGGn.LCIDI.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$HGGn.LCIDI.IRBlasterDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$HGGn.LCIDI.IRBlasterDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$HGGn.LCIDI.IRBlasterDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$HGGn.LCIDI.IRBlasterDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$HGGn.LCIDI.IRBlasterDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HGGn.LCIDI.IRBlasterDeviceFamily, x);
                }, $KjKXCk ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":2938802,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HGGn.LCIDI.IRBlasterDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$HGGn.LCIDI.IRBlasterDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $Wvasfi ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":2938802,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$HGGn.LCIDI.IRBlasterDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$HGGn.LCIDI.IRBlasterDeviceFamily, x);
                }, $NtKMOd ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$HGGn.LCIDI.IRBlasterDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":2938802,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$HGGn.LCIDI.IRBlasterDevice, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$HGGn.LCIDI.IRBlasterDevice, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$HGGn.LCIDI.IRBlasterDevice, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$HGGn.LCIDI.IRBlasterDevice), $.$HGGn.LCIDIC.IRBlasterDeviceCommands$$($.$HGGn.LCIDI.IRBlasterDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$HGGn.LCIDI.IRBlasterDevice), $.$HGGn.LCIDIV.IRBlasterViewRenderer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592873394)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HGGn.LCIDI.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297906098)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297906098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297906098)
            
            //--TRIMMABLE-BOUNDARY-START(4297906098)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297906098)
            
            static $h = 2938802;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592873394),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2938802,
      "h": 8592873394,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592873394)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297906098),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2938802,
      "h": 4297906098,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297906098)
  ],
  "h": 2938802
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2938802)
        
        

        //--TRIMMABLE-BOUNDARY-START(2873266)
        $asm.$cls(`$HGGn.LCIDI.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17182742450)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$HGGn.LCIDIV.IRBlasterDeviceDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$HGGn.LCIDIV.IRBlasterDeviceDetails().$ctor$4();
                    }, $LhAmZc ??= {"r":2752627,"n":"","d":2873266,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17182742450)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4297840562)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297840562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297840562)
            
            //--TRIMMABLE-BOUNDARY-START(4297840562)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297840562)
            
            static $h = 2873266;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182742450),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887775154,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 2873266,
      "h": 17182742450,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182742450)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297840562),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2873266,
      "h": 4297840562,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297840562)
  ],
  "h": 2873266
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2873266)
        
        

        //--TRIMMABLE-BOUNDARY-START(3725234)
        $asm.$cls(`$HGGn.LCIDIS$1.IRBlasterDisplayDevice`, ($self) => class IRBlasterDisplayDevice extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(124557776818)
            /*string?*/ Label = null;
            //--TRIMMABLE-BOUNDARY-END(124557776818)
            
            //--TRIMMABLE-BOUNDARY-START(115967842226)
            /*string*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(115967842226)
            
            //--TRIMMABLE-BOUNDARY-START(128852744114)
            /*double*/ Number = 0;
            //--TRIMMABLE-BOUNDARY-END(128852744114)
            
            //--TRIMMABLE-BOUNDARY-START(34363463602)
            /*int*/ Brightness = 0;
            //--TRIMMABLE-BOUNDARY-END(34363463602)
            
            //--TRIMMABLE-BOUNDARY-START(120262809522)
            /*string?*/ Image = null;
            //--TRIMMABLE-BOUNDARY-END(120262809522)
            
            //--TRIMMABLE-BOUNDARY-START(176097384370)
            /*string? */ get Title()
            {
                return this.Label;
            }
            //--TRIMMABLE-BOUNDARY-END(176097384370)
            
            //--TRIMMABLE-BOUNDARY-START(38658430898)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(38658430898)
            
            //--TRIMMABLE-BOUNDARY-START(111672874930)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit(this.Image);
            }
            //--TRIMMABLE-BOUNDARY-END(111672874930)
            
            //--TRIMMABLE-BOUNDARY-START(180392351666)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180392351666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Label ?? this.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(180392351666)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(30068496306)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068496306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30068496306)
            
            //--TRIMMABLE-BOUNDARY-START(30068496306)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(30068496306)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(115967842226)
                this.Id = null;
                //--TRIMMABLE-BOUNDARY-END(115967842226)
                
                //--TRIMMABLE-BOUNDARY-START(34363463602)
                this.Brightness = 100;
                //--TRIMMABLE-BOUNDARY-END(34363463602)
                
            }
            static $h = 3725234;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124557776818),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90198038450,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163212482482,
        "f": 83886081
      },
      "n": "Label",
      "d": 3725234,
      "h": 124557776818,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124557776818),
//--TRIMMABLE-BOUNDARY-START(115967842226),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73018169266,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146032613298,
        "f": 83886081
      },
      "n": "Id",
      "d": 3725234,
      "h": 115967842226,
      "f": 2097153,
      "a": [
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115967842226),
//--TRIMMABLE-BOUNDARY-START(128852744114),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98787973042,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171802417074,
        "f": 83886081
      },
      "n": "Number",
      "d": 3725234,
      "h": 128852744114,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128852744114),
//--TRIMMABLE-BOUNDARY-START(34363463602),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47248365490,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137442678706,
        "f": 83886081
      },
      "n": "Brightness",
      "d": 3725234,
      "h": 34363463602,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 6,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34363463602),
//--TRIMMABLE-BOUNDARY-START(120262809522),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81608103858,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154622547890,
        "f": 83886081
      },
      "n": "Image",
      "d": 3725234,
      "h": 120262809522,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 14,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120262809522),
//--TRIMMABLE-BOUNDARY-START(176097384370),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107377907634,
        "f": 50331649
      },
      "n": "Title",
      "d": 3725234,
      "h": 176097384370,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176097384370),
//--TRIMMABLE-BOUNDARY-START(38658430898),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55838300082,
        "f": 50331649
      },
      "n": "Description",
      "d": 3725234,
      "h": 38658430898,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38658430898),
//--TRIMMABLE-BOUNDARY-START(111672874930),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64428234674,
        "f": 50331649
      },
      "n": "Icon",
      "d": 3725234,
      "h": 111672874930,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111672874930)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(180392351666),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 3725234,
      "h": 180392351666,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180392351666)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30068496306),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3725234,
      "h": 30068496306,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30068496306)
  ],
  "h": 3725234
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDisplayDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Settings${separator}IRBlasterDisplayDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3725234)
        
        

        //--TRIMMABLE-BOUNDARY-START(4577202)
        $asm.$cls(`$HGGn.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299544498)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299544498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299544498)
            
            //--TRIMMABLE-BOUNDARY-START(4299544498)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299544498)
            
            static $h = 4577202;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299544498),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4577202,
      "h": 4299544498,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299544498)
  ],
  "h": 4577202
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4577202)
        
        

        //--TRIMMABLE-BOUNDARY-START(4642738)
        $asm.$cls(`$HGGn.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299610034)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299610034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299610034)
            
            //--TRIMMABLE-BOUNDARY-START(4299610034)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299610034)
            
            static $h = 4642738;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299610034),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4642738,
      "h": 4299610034,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299610034)
  ],
  "h": 4642738,
  "a": [
    {
      "t": 4577202,
      "c": 4299544498
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4642738)
        
        

        //--TRIMMABLE-BOUNDARY-START(645042)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterClearReBlastControlModel`, ($self) => class IRBlasterClearReBlastControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(8590579634)
            /*int */ get Command()
            {
                return ((128 + 2) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(8590579634)
            
            //--TRIMMABLE-BOUNDARY-START(4295612338)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295612338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295612338)
            
            //--TRIMMABLE-BOUNDARY-START(4295612338)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295612338)
            
            static $h = 645042;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590579634),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180514226,
        "f": 50364417
      },
      "n": "Command",
      "d": 645042,
      "h": 8590579634,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8590579634)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295612338),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 645042,
      "h": 4295612338,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295612338)
  ],
  "h": 645042
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterClearReBlastControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterClearReBlastControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(645042)
        
        

        //--TRIMMABLE-BOUNDARY-START(317362)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterBlastControlModel`, ($self) => class IRBlasterBlastControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(21475153842)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475153842);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475153842)
            
            //--TRIMMABLE-BOUNDARY-START(25770121138)
            $ctor$3(/*int*/ frequency, /*ulong*/ code, /*int*/ repeat, /*int*/ persistIndex)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770121138);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Frequency = frequency;
                    this.Code = code;
                    this.Repeat = repeat;
                    this.PersistIndex = persistIndex;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770121138)
            
            //--TRIMMABLE-BOUNDARY-START(34360055730)
            /*int */ get Command()
            {
                return ((128 + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(34360055730)
            
            //--TRIMMABLE-BOUNDARY-START(38655023026)
            /*int*/ Frequency = 0;
            //--TRIMMABLE-BOUNDARY-END(38655023026)
            
            //--TRIMMABLE-BOUNDARY-START(30065088434)
            /*ulong*/ Code = 0n;
            //--TRIMMABLE-BOUNDARY-END(30065088434)
            
            //--TRIMMABLE-BOUNDARY-START(90194630578)
            /*int*/ Repeat = 0;
            //--TRIMMABLE-BOUNDARY-END(90194630578)
            
            //--TRIMMABLE-BOUNDARY-START(85899663282)
            /*int*/ PersistIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(85899663282)
            
            //--TRIMMABLE-BOUNDARY-START(21475153842)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21475153842)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38655023026)
                this.Frequency = 38000;
                //--TRIMMABLE-BOUNDARY-END(38655023026)
                
            }
            static $h = 317362;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360055730),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834892210,
        "f": 50364417
      },
      "n": "Command",
      "d": 317362,
      "h": 34360055730,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360055730),
//--TRIMMABLE-BOUNDARY-START(38655023026),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424826802,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374499762,
        "f": 83886082
      },
      "n": "Frequency",
      "d": 317362,
      "h": 38655023026,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655023026),
//--TRIMMABLE-BOUNDARY-START(30065088434),
    {
      "p": 983041,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244957618,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784565170,
        "f": 83886082
      },
      "n": "Code",
      "d": 317362,
      "h": 30065088434,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065088434),
//--TRIMMABLE-BOUNDARY-START(90194630578),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604695986,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554368946,
        "f": 83886082
      },
      "n": "Repeat",
      "d": 317362,
      "h": 90194630578,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90194630578),
//--TRIMMABLE-BOUNDARY-START(85899663282),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014761394,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964434354,
        "f": 83886082
      },
      "n": "PersistIndex",
      "d": 317362,
      "h": 85899663282,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 6,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 524289,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85899663282)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475153842),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 317362,
      "h": 21475153842,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475153842),
//--TRIMMABLE-BOUNDARY-START(25770121138),
    {
      "p": [
        {
          "n": "frequency",
          "p": 655361
        },
        {
          "n": "code",
          "p": 983041
        },
        {
          "n": "repeat",
          "p": 655361
        },
        {
          "n": "persistIndex",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 317362,
      "h": 25770121138,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770121138)
  ],
  "h": 317362
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterBlastControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterBlastControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(317362)
        
        

        //--TRIMMABLE-BOUNDARY-START(4052914)
        $asm.$cls(`$HGGn.LCIDIS$2.IRBlasterStatusModel`, ($self) => class IRBlasterStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(21478889394)
            /*int*/ Blasting = 0;
            //--TRIMMABLE-BOUNDARY-END(21478889394)
            
            //--TRIMMABLE-BOUNDARY-START(17183922098)
            /*int*/ BlastCapacity = 0;
            //--TRIMMABLE-BOUNDARY-END(17183922098)
            
            //--TRIMMABLE-BOUNDARY-START(12888954802)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888954802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888954802)
            
            //--TRIMMABLE-BOUNDARY-START(12888954802)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12888954802)
            
            static $h = 4052914;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21478889394),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38658758578,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55838627762,
        "f": 83886081
      },
      "n": "Blasting",
      "d": 4052914,
      "h": 21478889394,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21478889394),
//--TRIMMABLE-BOUNDARY-START(17183922098),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068823986,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47248693170,
        "f": 83886081
      },
      "n": "BlastCapacity",
      "d": 4052914,
      "h": 17183922098,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17183922098)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888954802),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4052914,
      "h": 12888954802,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888954802)
  ],
  "h": 4052914
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Statuses${separator}IRBlasterStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4052914)
        
        

        //--TRIMMABLE-BOUNDARY-START(1300402)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterSetNumberControlModel`, ($self) => class IRBlasterSetNumberControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(21476136882)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476136882);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476136882)
            
            //--TRIMMABLE-BOUNDARY-START(38656006066)
            /*int */ get Command()
            {
                return ((128 + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(38656006066)
            
            //--TRIMMABLE-BOUNDARY-START(51540907954)
            /*int*/ Frequency = 0;
            //--TRIMMABLE-BOUNDARY-END(51540907954)
            
            //--TRIMMABLE-BOUNDARY-START(42950973362)
            /*string?*/ displayId = null;
            //--TRIMMABLE-BOUNDARY-END(42950973362)
            
            //--TRIMMABLE-BOUNDARY-START(47245940658)
            /*string? */ get DisplayId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900646322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.displayId;
            }
            /*string? */ set DisplayId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210057650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.displayId = value;
                this.TryEncode();
            }
            //--TRIMMABLE-BOUNDARY-END(47245940658)
            
            //--TRIMMABLE-BOUNDARY-START(124555351986)
            /*double*/ number = 0;
            //--TRIMMABLE-BOUNDARY-END(124555351986)
            
            //--TRIMMABLE-BOUNDARY-START(128850319282)
            /*double */ get Number()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080515506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.number;
            }
            /*double */ set Number(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389926834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.number = value;
                this.TryEncode();
            }
            //--TRIMMABLE-BOUNDARY-END(128850319282)
            
            //--TRIMMABLE-BOUNDARY-START(25771104178)
            /*int*/ brightness = 100;
            //--TRIMMABLE-BOUNDARY-END(25771104178)
            
            //--TRIMMABLE-BOUNDARY-START(30066071474)
            /*int */ get Brightness()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130842546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.brightness;
            }
            /*int */ set Brightness(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030188466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.brightness = value;
                this.TryEncode();
            }
            //--TRIMMABLE-BOUNDARY-END(30066071474)
            
            //--TRIMMABLE-BOUNDARY-START(34361038770)
            /*ulong*/ Code = 0n;
            //--TRIMMABLE-BOUNDARY-END(34361038770)
            
            //--TRIMMABLE-BOUNDARY-START(137440253874)
            /*int*/ Repeat = 0;
            //--TRIMMABLE-BOUNDARY-END(137440253874)
            
            //--TRIMMABLE-BOUNDARY-START(133145286578)
            /*int*/ PersistIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(133145286578)
            
            //--TRIMMABLE-BOUNDARY-START(201864763314)
            /*void */ TryEncode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864763314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.displayId !== null)
                {
                    this.Code = $.$HGGn.LCIDI.IRBlasterUtility.EncodeNumber(this.displayId, 0, this.Brightness, this.Number);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201864763314)
            
            //--TRIMMABLE-BOUNDARY-START(21476136882)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21476136882)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51540907954)
                this.Frequency = 38000;
                //--TRIMMABLE-BOUNDARY-END(51540907954)
                
                //--TRIMMABLE-BOUNDARY-START(137440253874)
                this.Repeat = 1;
                //--TRIMMABLE-BOUNDARY-END(137440253874)
                
                //--TRIMMABLE-BOUNDARY-START(133145286578)
                this.PersistIndex = -1;
                //--TRIMMABLE-BOUNDARY-END(133145286578)
                
            }
            static $h = 1300402;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656006066),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310711730,
        "f": 50364417
      },
      "n": "Command",
      "d": 1300402,
      "h": 38656006066,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38656006066),
//--TRIMMABLE-BOUNDARY-START(51540907954),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490580914,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799992242,
        "f": 83886081
      },
      "n": "Frequency",
      "d": 1300402,
      "h": 51540907954,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540907954),
//--TRIMMABLE-BOUNDARY-START(47245940658),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900646322,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163210057650,
        "f": 83886081
      },
      "n": "DisplayId",
      "d": 1300402,
      "h": 47245940658,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 128,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245940658),
//--TRIMMABLE-BOUNDARY-START(128850319282),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080515506,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180389926834,
        "f": 83886081
      },
      "n": "Number",
      "d": 1300402,
      "h": 128850319282,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 128,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128850319282),
//--TRIMMABLE-BOUNDARY-START(30066071474),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130842546,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146030188466,
        "f": 83886081
      },
      "n": "Brightness",
      "d": 1300402,
      "h": 30066071474,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 128,
              "t": 2722134
            },
            {
              "n": "InputType",
              "v": 6,
              "t": 47614294
            },
            {
              "n": "Options",
              "v": [
                "//Minumum=0",
                "//Maximum=100"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066071474),
//--TRIMMABLE-BOUNDARY-START(34361038770),
    {
      "p": 983041,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720777138,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620123058,
        "f": 83886081
      },
      "n": "Code",
      "d": 1300402,
      "h": 34361038770,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361038770),
//--TRIMMABLE-BOUNDARY-START(137440253874),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260384690,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197569796018,
        "f": 83886081
      },
      "n": "Repeat",
      "d": 1300402,
      "h": 137440253874,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137440253874),
//--TRIMMABLE-BOUNDARY-START(133145286578),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670450098,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188979861426,
        "f": 83886081
      },
      "n": "PersistIndex",
      "d": 1300402,
      "h": 133145286578,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 6,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 524289,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133145286578)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(201864763314),
    {
      "r": 65537,
      "n": "TryEncode",
      "d": 1300402,
      "h": 201864763314,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(201864763314)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42950973362),
    {
      "t": 1310721,
      "n": "displayId",
      "d": 1300402,
      "h": 42950973362,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950973362),
//--TRIMMABLE-BOUNDARY-START(124555351986),
    {
      "t": 1179649,
      "n": "number",
      "d": 1300402,
      "h": 124555351986,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(124555351986),
//--TRIMMABLE-BOUNDARY-START(25771104178),
    {
      "t": 655361,
      "n": "brightness",
      "d": 1300402,
      "h": 25771104178,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771104178)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476136882),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1300402,
      "h": 21476136882,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476136882)
  ],
  "h": 1300402
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterSetNumberControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1300402)
        
        

        //--TRIMMABLE-BOUNDARY-START(120754)
        $asm.$cls(`$HGGn.LCIDI._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590055346)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590055346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590055346)
            
            //--TRIMMABLE-BOUNDARY-START(4295088050)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295088050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295088050)
            
            //--TRIMMABLE-BOUNDARY-START(4295088050)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295088050)
            
            static $h = 120754;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590055346),
    {
      "r": 65537,
      "n": "Execute",
      "d": 120754,
      "h": 8590055346,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590055346)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295088050),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 120754,
      "h": 4295088050,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295088050)
  ],
  "h": 120754
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(120754)
        
        

        //--TRIMMABLE-BOUNDARY-START(4183986)
        $asm.$cls(`$HGGn.LCIDIS$2.IRBlasterStatusModelTypeDescriptor`, ($self) => class IRBlasterStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIS$2.IRBlasterStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299151282)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299151282);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$HGGn.LCIDIS$2.IRBlasterStatusModelTypeDescriptor.GenerateProperties($.$HGGn.LCIDIS$2.IRBlasterStatusModel, this, factory);
                    }, $mbQpxh ??= {"r":65537,"n":"","d":4183986,"h":0,"f":17825794}), 0, "IRBlasterStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.IRBlaster\\Models_Statuses_IRBlasterStatusModel_LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterStatusModelTypeDescriptorBuilder.g.cs", "IRBlasterStatusModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299151282)
            
            //--TRIMMABLE-BOUNDARY-START(12889085874)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889085874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Blasting"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIS$2.IRBlasterStatusModel.$type, $.$discardRef(), "Blasting", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Blasting")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Blasting";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIS$2.IRBlasterStatusModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$HGGn.LCIDIS$2.IRBlasterStatusModel)).Blasting);
                        }, $rEgnNg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4183986,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIS$2.IRBlasterStatusModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.Blasting = value.AsInt();
                        }, $fQERGa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4183986,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BlastCapacity"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIS$2.IRBlasterStatusModel.$type, $.$discardRef(), "BlastCapacity", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BlastCapacity")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "BlastCapacity";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIS$2.IRBlasterStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$HGGn.LCIDIS$2.IRBlasterStatusModel)).BlastCapacity);
                        }, $yhUKsf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4183986,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIS$2.IRBlasterStatusModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.BlastCapacity = value.AsInt();
                        }, $tFDfFh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4183986,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889085874)
            
            //--TRIMMABLE-BOUNDARY-START(17184053170)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184053170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _Blasting = _target.Blasting;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Blasting"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Blasting, ($v) => _Blasting = $v, $.$$.S.Int32)))
                    {
                        _target.Blasting = _Blasting;
                    }
                }
                {
                    /*var*/ let _BlastCapacity = _target.BlastCapacity;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BlastCapacity"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _BlastCapacity, ($v) => _BlastCapacity = $v, $.$$.S.Int32)))
                    {
                        _target.BlastCapacity = _BlastCapacity;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184053170)
            
            //--TRIMMABLE-BOUNDARY-START(8594118578)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594118578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$HGGn.LCIDIS$2.IRBlasterStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$HGGn.LCIDIS$2.IRBlasterStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIS$2.IRBlasterStatusModel)))
                {
                    /*var*/ let result = $.$HGGn.LCIDIS$2.IRBlasterStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIS$2.IRBlasterStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$HGGn.LCIDIS$2.IRBlasterStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIS$2.IRBlasterStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594118578)
            
            static $h = 4183986;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIS$2.IRBlasterStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889085874),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4183986,
      "h": 12889085874,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889085874),
//--TRIMMABLE-BOUNDARY-START(17184053170),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4052914,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4183986,
      "h": 17184053170,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184053170),
//--TRIMMABLE-BOUNDARY-START(8594118578),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4052914,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4183986,
      "h": 8594118578,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594118578)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299151282),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4183986,
      "h": 4299151282,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299151282)
  ],
  "h": 4183986
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$HGGn.LCIDIS$2.IRBlasterStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Statuses${separator}IRBlasterStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4183986)
        
        

        //--TRIMMABLE-BOUNDARY-START(448434)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterBlastControlModelTypeDescriptor`, ($self) => class IRBlasterBlastControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIC.IRBlasterBlastControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295415730)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295415730);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$HGGn.LCIDIC.IRBlasterBlastControlModelTypeDescriptor.GenerateProperties($.$HGGn.LCIDIC.IRBlasterBlastControlModel, this, factory);
                    }, $yeAvLi ??= {"r":65537,"n":"","d":448434,"h":0,"f":17825794}), 0, "IRBlasterBlastControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.IRBlaster\\Models_Commands_IRBlasterBlastControlModel_LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterBlastControlModelTypeDescriptorBuilder.g.cs", "IRBlasterBlastControlModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295415730)
            
            //--TRIMMABLE-BOUNDARY-START(12885350322)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885350322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Frequency"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIC.IRBlasterBlastControlModel.$type, $.$discardRef(), "Frequency", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Frequency")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Frequency";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterBlastControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterBlastControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$HGGn.LCIDIC.IRBlasterBlastControlModel)).Frequency);
                        }, $YLWJIb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":448434,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Code"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIC.IRBlasterBlastControlModel.$type, $.$discardRef(), "Code", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Code")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.UInt64, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Code";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterBlastControlModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterBlastControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$14(($.$cast(target, $.$HGGn.LCIDIC.IRBlasterBlastControlModel)).Code);
                        }, $iMZgqj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":448434,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Repeat"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIC.IRBlasterBlastControlModel.$type, $.$discardRef(), "Repeat", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Repeat")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Repeat";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterBlastControlModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterBlastControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$HGGn.LCIDIC.IRBlasterBlastControlModel)).Repeat);
                        }, $HPmrzb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":448434,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PersistIndex"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIC.IRBlasterBlastControlModel.$type, $.$discardRef(), "PersistIndex", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PersistIndex")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "PersistIndex";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterBlastControlModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterBlastControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$HGGn.LCIDIC.IRBlasterBlastControlModel)).PersistIndex);
                        }, $dyHKTi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":448434,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIC.IRBlasterBlastControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Command";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterBlastControlModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterBlastControlModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$HGGn.LCIDIC.IRBlasterBlastControlModel)).Command);
                        }, $GWDRkc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":448434,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885350322)
            
            //--TRIMMABLE-BOUNDARY-START(17180317618)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterBlastControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180317618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Frequency = _target.Frequency;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Frequency"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Frequency, ($v) => _Frequency = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _Code = _target.Code;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Code"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.UInt64));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.UInt64, property, $.$ref(() => _Code, ($v) => _Code = $v, $.$$.S.UInt64)))
                    {
                    }
                }
                {
                    /*var*/ let _Repeat = _target.Repeat;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Repeat"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Repeat, ($v) => _Repeat = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _PersistIndex = _target.PersistIndex;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PersistIndex"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _PersistIndex, ($v) => _PersistIndex = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180317618)
            
            //--TRIMMABLE-BOUNDARY-START(8590383026)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterBlastControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590383026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$HGGn.LCIDIC.IRBlasterBlastControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$HGGn.LCIDIC.IRBlasterBlastControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIC.IRBlasterBlastControlModel)))
                {
                    /*var*/ let result = $.$HGGn.LCIDIC.IRBlasterBlastControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIC.IRBlasterBlastControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$HGGn.LCIDIC.IRBlasterBlastControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIC.IRBlasterBlastControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590383026)
            
            static $h = 448434;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIC.IRBlasterBlastControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885350322),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 448434,
      "h": 12885350322,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885350322),
//--TRIMMABLE-BOUNDARY-START(17180317618),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 317362,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 448434,
      "h": 17180317618,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180317618),
//--TRIMMABLE-BOUNDARY-START(8590383026),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 317362,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 448434,
      "h": 8590383026,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590383026)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295415730),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 448434,
      "h": 4295415730,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295415730)
  ],
  "h": 448434
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$HGGn.LCIDIC.IRBlasterBlastControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterBlastControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterBlastControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(448434)
        
        

        //--TRIMMABLE-BOUNDARY-START(1431474)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor`, ($self) => class IRBlasterSetNumberControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIC.IRBlasterSetNumberControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296398770)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296398770);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor.GenerateProperties($.$HGGn.LCIDIC.IRBlasterSetNumberControlModel, this, factory);
                    }, $RZwwXb ??= {"r":65537,"n":"","d":1431474,"h":0,"f":17825794}), 0, "IRBlasterSetNumberControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.IRBlaster\\Models_Commands_IRBlasterSetNumberControlModel_LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberControlModelTypeDescriptorBuilder.g.cs", "IRBlasterSetNumberControlModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296398770)
            
            //--TRIMMABLE-BOUNDARY-START(12886333362)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886333362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Frequency"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel.$type, $.$discardRef(), "Frequency", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Frequency")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Frequency";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel)).Frequency);
                        }, $wYIvLb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1431474,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Frequency = value.AsInt();
                        }, $ihLWEd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1431474,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DisplayId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel.$type, $.$discardRef(), "DisplayId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DisplayId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "DisplayId";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberControlModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel)).DisplayId);
                        }, $GAfumc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1431474,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DisplayId = value.AsReference($.$$.S.String);
                        }, $GDExbh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1431474,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Number"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel.$type, $.$discardRef(), "Number", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Number")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Number";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberControlModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel)).Number);
                        }, $hhvCxg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1431474,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Number = value.AsDouble();
                        }, $PoIGJb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1431474,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Brightness"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel.$type, $.$discardRef(), "Brightness", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Brightness")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Brightness";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberControlModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel)).Brightness);
                        }, $bwmDoj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1431474,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Brightness = value.AsInt();
                        }, $vwXisj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1431474,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Code"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel.$type, $.$discardRef(), "Code", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Code")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.UInt64, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Code";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberControlModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$14(($.$cast(target, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel)).Code);
                        }, $hVwXrb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1431474,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Code = value.AsULong();
                        }, $DlsFEk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1431474,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Repeat"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel.$type, $.$discardRef(), "Repeat", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Repeat")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Repeat";
                        $i11.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberControlModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel)).Repeat);
                        }, $SjGQGd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1431474,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Repeat = value.AsInt();
                        }, $Dlfdla ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1431474,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PersistIndex"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel.$type, $.$discardRef(), "PersistIndex", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PersistIndex")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "PersistIndex";
                        $i13.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberControlModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel)).PersistIndex);
                        }, $QLIdMi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1431474,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PersistIndex = value.AsInt();
                        }, $YYxSTd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1431474,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Command";
                        $i15.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberControlModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel)).Command);
                        }, $YvGsEd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1431474,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886333362)
            
            //--TRIMMABLE-BOUNDARY-START(17181300658)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181300658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Frequency = _target.Frequency;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Frequency"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Frequency, ($v) => _Frequency = $v, $.$$.S.Int32)))
                    {
                        _target.Frequency = _Frequency;
                    }
                }
                {
                    /*var*/ let _DisplayId = _target.DisplayId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DisplayId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _DisplayId, ($v) => _DisplayId = $v, $.$$.S.String)))
                    {
                        _target.DisplayId = _DisplayId;
                    }
                }
                {
                    /*var*/ let _Number = _target.Number;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Number"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Number, ($v) => _Number = $v, $.$$.S.Double)))
                    {
                        _target.Number = _Number;
                    }
                }
                {
                    /*var*/ let _Brightness = _target.Brightness;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Brightness"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Brightness, ($v) => _Brightness = $v, $.$$.S.Int32)))
                    {
                        _target.Brightness = _Brightness;
                    }
                }
                {
                    /*var*/ let _Code = _target.Code;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Code"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.UInt64));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.UInt64, property, $.$ref(() => _Code, ($v) => _Code = $v, $.$$.S.UInt64)))
                    {
                        _target.Code = _Code;
                    }
                }
                {
                    /*var*/ let _Repeat = _target.Repeat;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Repeat"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Repeat, ($v) => _Repeat = $v, $.$$.S.Int32)))
                    {
                        _target.Repeat = _Repeat;
                    }
                }
                {
                    /*var*/ let _PersistIndex = _target.PersistIndex;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PersistIndex"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _PersistIndex, ($v) => _PersistIndex = $v, $.$$.S.Int32)))
                    {
                        _target.PersistIndex = _PersistIndex;
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181300658)
            
            //--TRIMMABLE-BOUNDARY-START(8591366066)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591366066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel)))
                {
                    /*var*/ let result = $.$HGGn.LCIDIC.IRBlasterSetNumberControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591366066)
            
            static $h = 1431474;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIC.IRBlasterSetNumberControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886333362),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1431474,
      "h": 12886333362,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886333362),
//--TRIMMABLE-BOUNDARY-START(17181300658),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1300402,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1431474,
      "h": 17181300658,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181300658),
//--TRIMMABLE-BOUNDARY-START(8591366066),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1300402,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1431474,
      "h": 8591366066,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591366066)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296398770),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1431474,
      "h": 4296398770,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296398770)
  ],
  "h": 1431474
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$HGGn.LCIDIC.IRBlasterSetNumberControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterSetNumberControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1431474)
        
        

        //--TRIMMABLE-BOUNDARY-START(776114)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterClearReBlastControlModelTypeDescriptor`, ($self) => class IRBlasterClearReBlastControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295743410)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295743410);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$HGGn.LCIDIC.IRBlasterClearReBlastControlModelTypeDescriptor.GenerateProperties($.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel, this, factory);
                    }, $SIffYf ??= {"r":65537,"n":"","d":776114,"h":0,"f":17825794}), 0, "IRBlasterClearReBlastControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.IRBlaster\\Models_Commands_IRBlasterClearReBlastControlModel_LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterClearReBlastControlModelTypeDescriptorBuilder.g.cs", "IRBlasterClearReBlastControlModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295743410)
            
            //--TRIMMABLE-BOUNDARY-START(12885678002)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885678002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Command";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterClearReBlastControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterClearReBlastControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel)).Command);
                        }, $YNqlAb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":776114,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885678002)
            
            //--TRIMMABLE-BOUNDARY-START(17180645298)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterClearReBlastControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180645298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180645298)
            
            //--TRIMMABLE-BOUNDARY-START(8590710706)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterClearReBlastControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590710706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel)))
                {
                    /*var*/ let result = $.$HGGn.LCIDIC.IRBlasterClearReBlastControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590710706)
            
            static $h = 776114;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885678002),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 776114,
      "h": 12885678002,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885678002),
//--TRIMMABLE-BOUNDARY-START(17180645298),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 645042,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 776114,
      "h": 17180645298,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180645298),
//--TRIMMABLE-BOUNDARY-START(8590710706),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 645042,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 776114,
      "h": 8590710706,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590710706)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295743410),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 776114,
      "h": 4295743410,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295743410)
  ],
  "h": 776114
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterClearReBlastControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterClearReBlastControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(776114)
        
        

        //--TRIMMABLE-BOUNDARY-START(907186)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterDeviceCommands<>`, (TDevice) => $asm.$gt(`$HGGn.LCIDIC.IRBlasterDeviceCommands<>`, [TDevice], ($self) => class IRBlasterDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12885809074)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12885809074)
            
            //--TRIMMABLE-BOUNDARY-START(17180776370)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel?*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180776370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$HGGn.LCIDIC.IRBlasterDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17180776370)
            
            //--TRIMMABLE-BOUNDARY-START(8590841778)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590841778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590841778)
            
            //--TRIMMABLE-BOUNDARY-START(8590841778)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590841778)
            
            //--TRIMMABLE-BOUNDARY-START(4295874482)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295874482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885809074)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [new $.$HGGn.LCIDIC.IRBlasterSetNumberCommand().$ctor$6(), new $.$HGGn.LCIDIC.IRBlasterBlastCommand().$ctor$6(), new $.$HGGn.LCIDIC.IRBlasterClearReBlastCommand().$ctor$6()], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12885809074)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295874482)
            
            static $H = 907186;
            static $h = 907186;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180776370),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17180776370,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180776370)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885809074),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12885809074,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885809074)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590841778),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8590841778,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590841778)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 907186,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(907186)
        
        

        //--TRIMMABLE-BOUNDARY-START(579506)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterClearReBlastCommand`, ($self) => class IRBlasterClearReBlastCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295546802)
            $ctor$6()
            {
                super.$ctor$5("Clear", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295546802);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295546802)
            
            //--TRIMMABLE-BOUNDARY-START(17180448690)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-radio"/*MaterialDesignIconNames.Radio*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17180448690)
            
            //--TRIMMABLE-BOUNDARY-START(4295546802)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295546802)
            
            static $h = 579506;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180448690),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885481394,
        "f": 50364417
      },
      "n": "Icon",
      "d": 579506,
      "h": 17180448690,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180448690)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295546802),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 579506,
      "h": 4295546802,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295546802)
  ],
  "h": 579506
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterClearReBlastCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterClearReBlastCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(579506)
        
        

        //--TRIMMABLE-BOUNDARY-START(251826)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterBlastCommand`, ($self) => class IRBlasterBlastCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$HGGn.LCIDIC.IRBlasterBlastControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295219122)
            $ctor$6()
            {
                super.$ctor$5("Blast", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295219122);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295219122)
            
            //--TRIMMABLE-BOUNDARY-START(17180121010)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-radio"/*MaterialDesignIconNames.Radio*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17180121010)
            
            //--TRIMMABLE-BOUNDARY-START(4295219122)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295219122)
            
            static $h = 251826;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$HGGn.LCIDIC.IRBlasterBlastControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180121010),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885153714,
        "f": 50364417
      },
      "n": "Icon",
      "d": 251826,
      "h": 17180121010,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180121010)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295219122),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 251826,
      "h": 4295219122,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295219122)
  ],
  "h": 251826
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterBlastCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterBlastCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(251826)
        
        

        //--TRIMMABLE-BOUNDARY-START(1234866)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterSetNumberCommand`, ($self) => class IRBlasterSetNumberCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$HGGn.LCIDIC.IRBlasterSetNumberControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296202162)
            $ctor$6()
            {
                super.$ctor$5("SetNumber", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296202162);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296202162)
            
            //--TRIMMABLE-BOUNDARY-START(17181104050)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-radio"/*MaterialDesignIconNames.Radio*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17181104050)
            
            //--TRIMMABLE-BOUNDARY-START(4296202162)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296202162)
            
            static $h = 1234866;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$HGGn.LCIDIC.IRBlasterSetNumberControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181104050),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886136754,
        "f": 50364417
      },
      "n": "Icon",
      "d": 1234866,
      "h": 17181104050,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17181104050)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296202162),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1234866,
      "h": 4296202162,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296202162)
  ],
  "h": 1234866
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterSetNumberCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterSetNumberCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1234866)
        
        

        //--TRIMMABLE-BOUNDARY-START(972722)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterDeviceSendDataModel`, ($self) => class IRBlasterDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceCommandsModel
        {
            //--TRIMMABLE-BOUNDARY-START(8590907314)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590907314);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590907314)
            
            //--TRIMMABLE-BOUNDARY-START(12885874610)
            $ctor$5(/*IRBlasterBlastControlModel*/ blast)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885874610);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Blast = blast;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885874610)
            
            //--TRIMMABLE-BOUNDARY-START(17180841906)
            /*IRBlasterBlastControlModel?*/ Blast = null;
            //--TRIMMABLE-BOUNDARY-END(17180841906)
            
            //--TRIMMABLE-BOUNDARY-START(8590907314)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8590907314)
            
            static $h = 972722;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandsModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180841906),
    {
      "p": 317362,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770776498,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360711090,
        "f": 83886081
      },
      "n": "Blast",
      "d": 972722,
      "h": 17180841906,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 13432,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180841906)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590907314),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 972722,
      "h": 8590907314,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590907314),
//--TRIMMABLE-BOUNDARY-START(12885874610),
    {
      "p": [
        {
          "n": "blast",
          "p": 317362
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 972722,
      "h": 12885874610,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885874610)
  ],
  "h": 972722
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(972722)
        
        

        //--TRIMMABLE-BOUNDARY-START(3790770)
        $asm.$cls(`$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel`, ($self) => class IRBlasterDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$HGGn.LCIDIS$2.IRBlasterStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298758066)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298758066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298758066)
            
            //--TRIMMABLE-BOUNDARY-START(4298758066)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4298758066)
            
            static $h = 3790770;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$HGGn.LCIDIS$2.IRBlasterStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298758066),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3790770,
      "h": 4298758066,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298758066)
  ],
  "h": 3790770
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Statuses${separator}IRBlasterDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3790770)
        
        

        //--TRIMMABLE-BOUNDARY-START(1103794)
        $asm.$cls(`$HGGn.LCIDIC.IRBlasterDeviceSendDataModelTypeDescriptor`, ($self) => class IRBlasterDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296071090)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296071090);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModelTypeDescriptor.GenerateProperties($.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, this, factory);
                    }, $lzZnxd ??= {"r":65537,"n":"","d":1103794,"h":0,"f":17825794}), 0, "IRBlasterDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.IRBlaster\\Models_Commands_IRBlasterDeviceSendDataModel_LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterDeviceSendDataModelTypeDescriptorBuilder.g.cs", "IRBlasterDeviceSendDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296071090)
            
            //--TRIMMABLE-BOUNDARY-START(12886005682)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886005682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Blast"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel.$type, $.$discardRef(), "Blast", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Blast")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$HGGn.LCIDIC.IRBlasterBlastControlModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Blast";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterDeviceSendDataModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$HGGn.LCIDIC.IRBlasterBlastControlModel, ($.$cast(target, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel)).Blast);
                        }, $FAxIFc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1103794,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIC.IRBlasterDeviceSendDataModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Blast = value.AsReference($.$HGGn.LCIDIC.IRBlasterBlastControlModel);
                        }, $fPOpKh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1103794,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886005682)
            
            //--TRIMMABLE-BOUNDARY-START(17180972978)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180972978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandsModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandsModel));
                {
                    /*var*/ let _Blast = _target.Blast;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Blast"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$HGGn.LCIDIC.IRBlasterBlastControlModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Blast, ($v) => _Blast = $v, $.$HGGn.LCIDIC.IRBlasterBlastControlModel)))
                    {
                        _target.Blast = _Blast;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180972978)
            
            //--TRIMMABLE-BOUNDARY-START(8591038386)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591038386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591038386)
            
            static $h = 1103794;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886005682),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1103794,
      "h": 12886005682,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886005682),
//--TRIMMABLE-BOUNDARY-START(17180972978),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 972722,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1103794,
      "h": 17180972978,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180972978),
//--TRIMMABLE-BOUNDARY-START(8591038386),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 972722,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1103794,
      "h": 8591038386,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591038386)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296071090),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1103794,
      "h": 4296071090,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296071090)
  ],
  "h": 1103794
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Commands${separator}IRBlasterDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1103794)
        
        

        //--TRIMMABLE-BOUNDARY-START(3921842)
        $asm.$cls(`$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModelTypeDescriptor`, ($self) => class IRBlasterDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298889138)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298889138);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, this, factory);
                    }, $itqfRf ??= {"r":65537,"n":"","d":3921842,"h":0,"f":17825794}), 0, "IRBlasterDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.IRBlaster\\Models_Statuses_IRBlasterDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "IRBlasterDeviceReceivedDataModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298889138)
            
            //--TRIMMABLE-BOUNDARY-START(12888823730)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888823730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$HGGn.LCIDIS$2.IRBlasterStatusModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888823730)
            
            //--TRIMMABLE-BOUNDARY-START(17183791026)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183791026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterStatusModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$HGGn.LCIDIS$2.IRBlasterStatusModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$HGGn.LCIDIS$2.IRBlasterStatusModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183791026)
            
            //--TRIMMABLE-BOUNDARY-START(8593856434)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593856434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593856434)
            
            static $h = 3921842;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888823730),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3921842,
      "h": 12888823730,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888823730),
//--TRIMMABLE-BOUNDARY-START(17183791026),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3790770,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3921842,
      "h": 17183791026,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183791026),
//--TRIMMABLE-BOUNDARY-START(8593856434),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3790770,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3921842,
      "h": 8593856434,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593856434)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298889138),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3921842,
      "h": 4298889138,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298889138)
  ],
  "h": 3921842
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Statuses${separator}IRBlasterDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3921842)
        
        

        //--TRIMMABLE-BOUNDARY-START(1693618)
        $asm.$cls(`$HGGn.LCIDI.IRBlasterDataConverter`, ($self) => class IRBlasterDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296660914)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296660914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296660914)
            
            //--TRIMMABLE-BOUNDARY-START(4296660914)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296660914)
            
            static $h = 1693618;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296660914),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1693618,
      "h": 4296660914,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296660914)
  ],
  "h": 1693618
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.IRBlasterDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}IRBlasterDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1693618)
        
        

        //--TRIMMABLE-BOUNDARY-START(3004338)
        $asm.$cls(`$HGGn.LCIDIS.IIRBlasterDeviceHubClient`, ($self) => class IIRBlasterDeviceHubClient
        {
            static $h = 3004338;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3004338
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Services${separator}IIRBlasterDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3004338)
        
        

        $asm.$typeProxy("$HGGn.LCIDIM.IRBlasterServiceModel", "$HGGn.LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterServiceModel");
        $asm.$typeProxy("$HGGn.LCIDIM.IRBlasterDeviceScopeModel", "$HGGn.LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceScopeModel");
        $asm.$typeProxy("$HGGn.LCIDIM.IRBlasterDeviceModel", "$HGGn.LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceModel");
        $asm.$typeProxy("$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings", "$HGGn.LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceHardwareSettings");
        $asm.$typeProxy("$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler", "$HGGn.LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterDeviceStatusHandler");
        $asm.$typeProxy("$HGGn.LCIDIS.IIRBlasterRemoteService", "$HGGn.LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterRemoteService");
        //--TRIMMABLE-BOUNDARY-START(3463090)
        $asm.$cls(`$HGGn.LCIDIS$1.IRBlasterDeviceSettings`, ($self) => class IRBlasterDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $self, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(12888364978)
            /*IEnumerable<IRBlasterDisplayDevice>?*/ Displays = null;
            //--TRIMMABLE-BOUNDARY-END(12888364978)
            
            //--TRIMMABLE-BOUNDARY-START(8593397682)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593397682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593397682)
            
            //--TRIMMABLE-BOUNDARY-START(8593397682)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8593397682)
            
            static $h = 3463090;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12888364978),
    {
      "p": $.$$.SCG.IEnumerable$$($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478299570,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30068234162,
        "f": 83886081
      },
      "n": "Displays",
      "d": 3463090,
      "h": 12888364978,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 1152921504606846976,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12888364978)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593397682),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3463090,
      "h": 8593397682,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593397682)
  ],
  "h": 3463090
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Settings${separator}IRBlasterDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3463090)
        
        

        //--TRIMMABLE-BOUNDARY-START(3135410)
        $asm.$cls(`$HGGn.LCIDIS.IIRBlasterRemoteService`, ($self) => class IIRBlasterRemoteService
        {
            static $h = 3135410;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3135410
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$HGGn.LCIDIM.IRBlasterServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$HGGn.LCIDIM.IRBlasterServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$HGGn.LCIDIM.IRBlasterServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$HGGn.LCIDIM.IRBlasterServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$HGGn.LCIDIM.IRBlasterServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$HGGn.LCIDIM.IRBlasterServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$HGGn.LCIDIM.IRBlasterServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$HGGn.LCIDIM.IRBlasterServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Services${separator}IIRBlasterRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3135410)
        
        

        //--TRIMMABLE-BOUNDARY-START(2348978)
        $asm.$cls(`$HGGn.LCIDIM.IRBlasterDeviceScopeModel`, ($self) => class IRBlasterDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297316274)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297316274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297316274)
            
            //--TRIMMABLE-BOUNDARY-START(4297316274)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4297316274)
            
            static $h = 2348978;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297316274),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 2348978,
      "h": 4297316274,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297316274)
  ],
  "h": 2348978
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Models${separator}IRBlasterDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2348978)
        
        

        //--TRIMMABLE-BOUNDARY-START(3069874)
        $asm.$cls(`$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler`, ($self) => class IIRBlasterDeviceStatusHandler
        {
            static $h = 3069874;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3069874
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Services${separator}IIRBlasterDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3069874)
        
        

        //--TRIMMABLE-BOUNDARY-START(3200946)
        $asm.$cls(`$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings`, ($self) => class IRBlasterDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4298168242)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298168242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298168242)
            
            //--TRIMMABLE-BOUNDARY-START(4298168242)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298168242)
            
            static $h = 3200946;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298168242),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3200946,
      "h": 4298168242,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298168242)
  ],
  "h": 3200946
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Settings${separator}IRBlasterDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3200946)
        
        

        //--TRIMMABLE-BOUNDARY-START(2086834)
        $asm.$cls(`$HGGn.LCIDIM.IRBlasterDeviceModel`, ($self) => class IRBlasterDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297054130)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297054130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297054130)
            
            //--TRIMMABLE-BOUNDARY-START(4297054130)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4297054130)
            
            static $h = 2086834;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297054130),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 2086834,
      "h": 4297054130,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297054130)
  ],
  "h": 2086834
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Models${separator}IRBlasterDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2086834)
        
        

        //--TRIMMABLE-BOUNDARY-START(2611122)
        $asm.$cls(`$HGGn.LCIDIM.IRBlasterServiceModel`, ($self) => class IRBlasterServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297578418)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297578418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297578418)
            
            //--TRIMMABLE-BOUNDARY-START(4297578418)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4297578418)
            
            static $h = 2611122;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297578418),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 2611122,
      "h": 4297578418,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297578418)
  ],
  "h": 2611122
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Models${separator}IRBlasterServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2611122)
        
        

        //--TRIMMABLE-BOUNDARY-START(1955762)
        $asm.$cls(`$HGGn.LCIDI.IRBlasterDeviceModelDefinition`, ($self) => class IRBlasterDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4296923058)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296923058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296923058)
            
            //--TRIMMABLE-BOUNDARY-START(4296923058)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296923058)
            
            static $h = 1955762;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296923058),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1955762,
      "h": 4296923058,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296923058)
  ],
  "h": 1955762
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.IRBlasterDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}IRBlasterDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1955762)
        
        

        //--TRIMMABLE-BOUNDARY-START(2480050)
        $asm.$cls(`$HGGn.LCIDIM.IRBlasterDeviceScopeModelTypeDescriptor`, ($self) => class IRBlasterDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIM.IRBlasterDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297447346)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297447346);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$HGGn.LCIDIM.IRBlasterDeviceScopeModelTypeDescriptor.GenerateProperties($.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, this, factory);
                    }, $vkipBe ??= {"r":65537,"n":"","d":2480050,"h":0,"f":17825794}), 0, "IRBlasterDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.IRBlaster\\Models_IRBlasterDeviceScopeModel_LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceScopeModelTypeDescriptorBuilder.g.cs", "IRBlasterDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297447346)
            
            //--TRIMMABLE-BOUNDARY-START(12887381938)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887381938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887381938)
            
            //--TRIMMABLE-BOUNDARY-START(17182349234)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182349234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceModel, LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceSettings, LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterDeviceSendDataModel, LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterDeviceStatusHandler, LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterDeviceHubClient, LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182349234)
            
            //--TRIMMABLE-BOUNDARY-START(8592414642)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592414642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel)))
                {
                    /*var*/ let result = $.$HGGn.LCIDIM.IRBlasterDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592414642)
            
            static $h = 2480050;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIM.IRBlasterDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887381938),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2480050,
      "h": 12887381938,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887381938),
//--TRIMMABLE-BOUNDARY-START(17182349234),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2348978,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2480050,
      "h": 17182349234,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182349234),
//--TRIMMABLE-BOUNDARY-START(8592414642),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2348978,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2480050,
      "h": 8592414642,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592414642)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297447346),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2480050,
      "h": 4297447346,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297447346)
  ],
  "h": 2480050
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$HGGn.LCIDIM.IRBlasterDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Models${separator}IRBlasterDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2480050)
        
        

        //--TRIMMABLE-BOUNDARY-START(2217906)
        $asm.$cls(`$HGGn.LCIDIM.IRBlasterDeviceModelTypeDescriptor`, ($self) => class IRBlasterDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIM.IRBlasterDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297185202)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297185202);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$HGGn.LCIDIM.IRBlasterDeviceModelTypeDescriptor.GenerateProperties($.$HGGn.LCIDIM.IRBlasterDeviceModel, this, factory);
                    }, $BaDhNa ??= {"r":65537,"n":"","d":2217906,"h":0,"f":17825794}), 0, "IRBlasterDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.IRBlaster\\Models_IRBlasterDeviceModel_LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceModelTypeDescriptorBuilder.g.cs", "IRBlasterDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297185202)
            
            //--TRIMMABLE-BOUNDARY-START(12887119794)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887119794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887119794)
            
            //--TRIMMABLE-BOUNDARY-START(17182087090)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182087090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceModel, LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceSettings, LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterDeviceSendDataModel, LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterDeviceStatusHandler, LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterDeviceHubClient, LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182087090)
            
            //--TRIMMABLE-BOUNDARY-START(8592152498)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592152498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$HGGn.LCIDIM.IRBlasterDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$HGGn.LCIDIM.IRBlasterDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIM.IRBlasterDeviceModel)))
                {
                    /*var*/ let result = $.$HGGn.LCIDIM.IRBlasterDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIM.IRBlasterDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$HGGn.LCIDIM.IRBlasterDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIM.IRBlasterDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592152498)
            
            static $h = 2217906;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIM.IRBlasterDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887119794),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2217906,
      "h": 12887119794,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887119794),
//--TRIMMABLE-BOUNDARY-START(17182087090),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2086834,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2217906,
      "h": 17182087090,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182087090),
//--TRIMMABLE-BOUNDARY-START(8592152498),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2086834,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2217906,
      "h": 8592152498,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592152498)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297185202),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2217906,
      "h": 4297185202,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297185202)
  ],
  "h": 2217906
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$HGGn.LCIDIM.IRBlasterDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Models${separator}IRBlasterDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2217906)
        
        

        //--TRIMMABLE-BOUNDARY-START(3332018)
        $asm.$cls(`$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettingsTypeDescriptor`, ($self) => class IRBlasterDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298299314)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298299314);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, this, factory);
                    }, $dybFVi ??= {"r":65537,"n":"","d":3332018,"h":0,"f":17825794}), 0, "IRBlasterDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.IRBlaster\\Settings_IRBlasterDeviceHardwareSettings_LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "IRBlasterDeviceHardwareSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298299314)
            
            //--TRIMMABLE-BOUNDARY-START(12888233906)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888233906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888233906)
            
            //--TRIMMABLE-BOUNDARY-START(17183201202)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183201202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceModel, LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceSettings, LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterDeviceSendDataModel, LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterDeviceStatusHandler, LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterDeviceHubClient, LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).iSmartDeviceHardwareSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183201202)
            
            //--TRIMMABLE-BOUNDARY-START(8593266610)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593266610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593266610)
            
            static $h = 3332018;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888233906),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3332018,
      "h": 12888233906,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888233906),
//--TRIMMABLE-BOUNDARY-START(17183201202),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3200946,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3332018,
      "h": 17183201202,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183201202),
//--TRIMMABLE-BOUNDARY-START(8593266610),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3200946,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3332018,
      "h": 8593266610,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593266610)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298299314),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3332018,
      "h": 4298299314,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298299314)
  ],
  "h": 3332018
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Settings${separator}IRBlasterDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3332018)
        
        

        //--TRIMMABLE-BOUNDARY-START(2742194)
        $asm.$cls(`$HGGn.LCIDIM.IRBlasterServiceModelTypeDescriptor`, ($self) => class IRBlasterServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIM.IRBlasterServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297709490)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297709490);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$HGGn.LCIDIM.IRBlasterServiceModelTypeDescriptor.GenerateProperties($.$HGGn.LCIDIM.IRBlasterServiceModel, this, factory);
                    }, $NDpjqe ??= {"r":65537,"n":"","d":2742194,"h":0,"f":17825794}), 0, "IRBlasterServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.IRBlaster\\Models_IRBlasterServiceModel_LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterServiceModelTypeDescriptorBuilder.g.cs", "IRBlasterServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297709490)
            
            //--TRIMMABLE-BOUNDARY-START(12887644082)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887644082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887644082)
            
            //--TRIMMABLE-BOUNDARY-START(17182611378)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182611378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceModel, LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceSettings, LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterDeviceSendDataModel, LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterDeviceStatusHandler, LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterDeviceHubClient, LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182611378)
            
            //--TRIMMABLE-BOUNDARY-START(8592676786)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592676786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$HGGn.LCIDIM.IRBlasterServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$HGGn.LCIDIM.IRBlasterServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIM.IRBlasterServiceModel)))
                {
                    /*var*/ let result = $.$HGGn.LCIDIM.IRBlasterServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIM.IRBlasterServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$HGGn.LCIDIM.IRBlasterServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIM.IRBlasterServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592676786)
            
            static $h = 2742194;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIM.IRBlasterServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887644082),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2742194,
      "h": 12887644082,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887644082),
//--TRIMMABLE-BOUNDARY-START(17182611378),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2611122,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2742194,
      "h": 17182611378,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182611378),
//--TRIMMABLE-BOUNDARY-START(8592676786),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2611122,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2742194,
      "h": 8592676786,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592676786)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297709490),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2742194,
      "h": 4297709490,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297709490)
  ],
  "h": 2742194
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$HGGn.LCIDIM.IRBlasterServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Models${separator}IRBlasterServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2742194)
        
        

        //--TRIMMABLE-BOUNDARY-START(3594162)
        $asm.$cls(`$HGGn.LCIDIS$1.IRBlasterDeviceSettingsTypeDescriptor`, ($self) => class IRBlasterDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIS$1.IRBlasterDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298561458)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298561458);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$HGGn.LCIDIS$1.IRBlasterDeviceSettingsTypeDescriptor.GenerateProperties($.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, this, factory);
                    }, $RuyVVh ??= {"r":65537,"n":"","d":3594162,"h":0,"f":17825794}), 0, "IRBlasterDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.IRBlaster\\Settings_IRBlasterDeviceSettings_LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceSettingsTypeDescriptorBuilder.g.cs", "IRBlasterDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298561458)
            
            //--TRIMMABLE-BOUNDARY-START(12888496050)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888496050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Displays"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings.$type, $.$discardRef(), "Displays", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Displays")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Displays";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIS$1.IRBlasterDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice), ($.$cast(target, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings)).Displays);
                        }, $BrHCmf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3594162,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$HGGn.LCIDIS$1.IRBlasterDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Displays = value.AsReference($.$$.SCG.IEnumerable$$($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice));
                        }, $vjOGkb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3594162,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888496050)
            
            //--TRIMMABLE-BOUNDARY-START(17183463346)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183463346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.IRBlaster.Models.IRBlasterDeviceModel, LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceSettings, LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.IRBlaster.Statuses.IRBlasterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.IRBlaster.Commands.IRBlasterDeviceSendDataModel, LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterDeviceStatusHandler, LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterDeviceHubClient, LivingThing.Core.IOT.Devices.IRBlaster.Services.IIRBlasterRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService).iSmartDeviceSettings));
                {
                    /*var*/ let _Displays = _target.Displays;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Displays"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice), $.$HGGn.LCIDIS$1.IRBlasterDisplayDevice));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice), $.$HGGn.LCIDIS$1.IRBlasterDisplayDevice, property, $.$ref(() => _Displays, ($v) => _Displays = $v, $.$$.SCG.IEnumerable$$($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice))))
                    {
                        _target.Displays = _Displays;
                        if (_Displays !== null)
                        {
                            let $en6 = _Displays.SCG$IEnumerable$$$GetEnumerator();
                            while ($en6.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en6.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$HGGn.LCIDIS$1.IRBlasterDisplayDevice)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice), $.$HGGn.LCIDIS$1.IRBlasterDisplayDevice, property, $.$ref(() => _Displays, ($v) => _Displays = $v, $.$$.SCG.IEnumerable$$($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183463346)
            
            //--TRIMMABLE-BOUNDARY-START(8593528754)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593528754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings)))
                {
                    /*var*/ let result = $.$HGGn.LCIDIS$1.IRBlasterDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593528754)
            
            static $h = 3594162;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$HGGn.LCIDIS$1.IRBlasterDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888496050),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3594162,
      "h": 12888496050,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888496050),
//--TRIMMABLE-BOUNDARY-START(17183463346),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3463090,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3594162,
      "h": 17183463346,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183463346),
//--TRIMMABLE-BOUNDARY-START(8593528754),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3463090,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3594162,
      "h": 8593528754,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593528754)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298561458),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3594162,
      "h": 4298561458,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298561458)
  ],
  "h": 3594162
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$HGGn.LCIDIS$1.IRBlasterDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Settings${separator}IRBlasterDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3594162)
        
        

        //--TRIMMABLE-BOUNDARY-START(1759154)
        $asm.$cls(`$HGGn.LCIDI.IRBlasterDevice`, ($self) => class IRBlasterDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$HGGn.LCIDIS$2.IRBlasterStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4296726450)
            $ctor$2(/*IIOTDeviceFamily<IRBlasterDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*IRBlasterDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296726450);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296726450)
            
            //--TRIMMABLE-BOUNDARY-START(8591693746)
            /*Task */ Blast(/*int*/ frequency, /*ulong*/ code, /*int*/ repeat, /*int*/ persistIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591693746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$HGGn.LCIDIC.IRBlasterBlastCommand, $.$HGGn.LCIDIC.IRBlasterBlastControlModel, this, new $.$HGGn.LCIDIC.IRBlasterBlastCommand().$ctor$6(), new $.$HGGn.LCIDIC.IRBlasterBlastControlModel().$ctor$3(frequency, code, repeat, persistIndex));
            }
            //--TRIMMABLE-BOUNDARY-END(8591693746)
            
            //--TRIMMABLE-BOUNDARY-START(17181628338)
            /*Task */ SendNumber(/*string*/ displayId, /*double*/ number, /*int*/ brightness, /*int*/ frequency, /*int*/ repeat, /*int*/ persistIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181628338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$HGGn.LCIDIC.IRBlasterSetNumberCommand, $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel, this, new $.$HGGn.LCIDIC.IRBlasterSetNumberCommand().$ctor$6(), (() =>
                {
                    //new $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel()
                    const $t1 = $.$HGGn.LCIDIC.IRBlasterSetNumberControlModel;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Frequency = frequency;
                    $i1.Number = number;
                    $i1.DisplayId = displayId;
                    $i1.Repeat = repeat;
                    $i1.PersistIndex = persistIndex;
                    $i1.Brightness = brightness;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(17181628338)
            
            //--TRIMMABLE-BOUNDARY-START(12886661042)
            /*Task */ ClearReBlast()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886661042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$HGGn.LCIDIC.IRBlasterClearReBlastCommand, $.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel, this, new $.$HGGn.LCIDIC.IRBlasterClearReBlastCommand().$ctor$6(), new $.$HGGn.LCIDIC.IRBlasterClearReBlastControlModel().$ctor$2());
            }
            //--TRIMMABLE-BOUNDARY-END(12886661042)
            
            static $h = 1759154;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDI.IRBlasterDevice, $.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$HGGn.LCIDIS$2.IRBlasterStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591693746),
    {
      "r": 178454529,
      "p": [
        {
          "n": "frequency",
          "p": 655361
        },
        {
          "n": "code",
          "p": 983041
        },
        {
          "n": "repeat",
          "p": 655361
        },
        {
          "n": "persistIndex",
          "p": 655361
        }
      ],
      "n": "Blast",
      "d": 1759154,
      "h": 8591693746,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591693746),
//--TRIMMABLE-BOUNDARY-START(17181628338),
    {
      "r": 178454529,
      "p": [
        {
          "n": "displayId",
          "p": 1310721
        },
        {
          "n": "number",
          "p": 1179649
        },
        {
          "n": "brightness",
          "p": 655361
        },
        {
          "n": "frequency",
          "p": 655361,
          "f": 65,
          "v": 38000
        },
        {
          "n": "repeat",
          "p": 655361,
          "f": 65,
          "v": 5
        },
        {
          "n": "persistIndex",
          "p": 655361,
          "f": 65,
          "v": -1
        }
      ],
      "n": "SendNumber",
      "d": 1759154,
      "h": 17181628338,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181628338),
//--TRIMMABLE-BOUNDARY-START(12886661042),
    {
      "r": 178454529,
      "n": "ClearReBlast",
      "d": 1759154,
      "h": 12886661042,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886661042)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296726450),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$HGGn.LCIDI.IRBlasterDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 2086834
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1759154,
      "h": 4296726450,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296726450)
  ],
  "h": 1759154
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.IRBlasterDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}IRBlasterDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1759154)
        
        

        //--TRIMMABLE-BOUNDARY-START(1824690)
        $asm.$cls(`$HGGn.LCIDI.IRBlasterDeviceDefinition`, ($self) => class IRBlasterDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDI.IRBlasterDevice, $.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$HGGn.LCIDIS$2.IRBlasterStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296791986)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296791986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296791986)
            
            //--TRIMMABLE-BOUNDARY-START(4296791986)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296791986)
            
            static $h = 1824690;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDI.IRBlasterDevice, $.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$HGGn.LCIDIS$2.IRBlasterStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296791986),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1824690,
      "h": 4296791986,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296791986)
  ],
  "h": 1824690
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.IRBlasterDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}IRBlasterDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1824690)
        
        

        //--TRIMMABLE-BOUNDARY-START(1890226)
        $asm.$cls(`$HGGn.LCIDI.IRBlasterDeviceFamily`, ($self) => class IRBlasterDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDI.IRBlasterDevice, $.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4296857522)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<IRBlasterDeviceReceivedDataModel, IRBlasterDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<IRBlasterDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296857522);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296857522)
            
            static $h = 1890226;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$HGGn.LCIDI.IRBlasterDevice, $.$HGGn.LCIDIM.IRBlasterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$HGGn.LCIDIM.IRBlasterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$HGGn.LCIDIM.IRBlasterDeviceModel, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel, $.$HGGn.LCIDIS.IIRBlasterDeviceStatusHandler, $.$HGGn.LCIDIS.IIRBlasterDeviceHubClient, $.$HGGn.LCIDIS.IIRBlasterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296857522),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1890226,
      "h": 4296857522,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296857522)
  ],
  "h": 1890226
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$HGGn.LCIDI.IRBlasterDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$HGGn.LCIDI.IRBlasterDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.IRBlasterDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}IRBlasterDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1890226)
        
        

        //--TRIMMABLE-BOUNDARY-START(4511666)
        $asm.$cls(`$HGGn.LCIDIV.IRBlasterViewRenderer`, ($self) => class IRBlasterViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$HGGn.LCIDI.IRBlasterDevice, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299478962)
            $ctor$3(/*IOTRootViewModel*/ root)
            {
                super.$ctor$2(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299478962);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299478962)
            
            //--TRIMMABLE-BOUNDARY-START(8594446258)
            /*RenderFragment? */ GetView(/*IClientUnitOfWork*/ ui, /*IRBlasterDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>?*/ clicked, /*Func<Task>?*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594446258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === 3/*DeviceViewType.Details*/)
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$HGGn.LCIDIV.IRBlasterDeviceDetails, $.$HGGn.LCIDIV.IRBlasterDetailsViewModel, new $.$HGGn.LCIDIV.IRBlasterDetailsViewModel().$ctor$9(this.Root, device.OwnerScope, device), true, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(8594446258)
            
            static $h = 4511666;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$HGGn.LCIDI.IRBlasterDevice, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594446258),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 1759154
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 4511666,
      "h": 8594446258,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8594446258)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299478962),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4511666,
      "h": 4299478962,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299478962)
  ],
  "h": 4511666
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$HGGn.LCIDI.IRBlasterDevice), $.$ntej.LCICD$1.IDeviceViewRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Views.IRBlasterViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Views${separator}IRBlasterViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4511666)
        
        

        //--TRIMMABLE-BOUNDARY-START(4380594)
        $asm.$cls(`$HGGn.LCIDIV.IRBlasterDetailsViewModel`, ($self) => class IRBlasterDetailsViewModel extends $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$HGGn.LCIDI.IRBlasterDevice, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299347890)
            $ctor$9(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*IRBlasterDevice*/ device)
            {
                super.$ctor$8(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299347890);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299347890)
            
            //--TRIMMABLE-BOUNDARY-START(42954053554)
            /*string */ get Title()
            {
                return `${$.$strNN(this.Device$1.Model$1.Name)} (Smart Endpoint)`;
            }
            //--TRIMMABLE-BOUNDARY-END(42954053554)
            
            //--TRIMMABLE-BOUNDARY-START(38659086258)
            /*Task */ Restart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38659086258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    $.$XBGm.LCICDi.iSmartDeviceCommandExtension.Reset$2(this.Device$1);
                }
                catch($e)
                {
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(38659086258)
            
            //--TRIMMABLE-BOUNDARY-START(34364118962)
            /*Task *//*async*/  ResetBlasters()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34364118962);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t1, $r1;
                        ($t1 = this.Device$1.ClearReBlast(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    }
                    catch($e)
                    {
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34364118962)
            
            //--TRIMMABLE-BOUNDARY-START(25774184370)
            /*Task *//*async*/  RemoteUpdate(/*IRBlasterDisplayDevice*/ display)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25774184370);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = this.Device$1.SendNumber(display.Id, display.Number, display.Brightness, 38000, 5, -1), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25774184370)
            
            //--TRIMMABLE-BOUNDARY-START(8594315186)
            /*Task *//*async*/  AddDisplay()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    let $t4, $r4;
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8594315186);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let display = ($t3 = $.$hDPm.LCFCI.ViewPresenterExtensions.Form($.$hDPm.LCFCI.ViewConfiguration, $.$HGGn.LCIDIS$1.IRBlasterDisplayDevice, this.Root.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Add Display", false), null, null, null, null, 0, 4131, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    /*var*/ let settings = this.Device$1.Model$1.Settings ?? new $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings().$ctor$4();
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDisplayDevice>?*/ let __ca1__;
                    settings.Displays = $.$sl.SL.Enumerable.ToList($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice, (((__ca1__ = settings.Displays) !== null ? ($.$sl.SL.Enumerable.Concat($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice, __ca1__, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice), [display], null, null)) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice), [display], null, null)) : $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice), [display], null, null))));
                    this.Device$1.Model$1.Settings = settings;
                    ($t4 = this.Device$1.OwnerScope.LCICI$IIOTDeviceScope$UpdateDevice($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDevice), [ this.Device$1 ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    ($t5 = this.RemoteUpdate(display), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8594315186)
            
            //--TRIMMABLE-BOUNDARY-START(12889282482)
            /*Task *//*async*/  EditDisplay(/*IRBlasterDisplayDevice*/ display)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    let $t7, $r7;
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12889282482);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let settings = this.Device$1.Model$1.Settings ?? new $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings().$ctor$4();
                    ($t6 = $.$hDPm.LCFCI.ViewPresenterExtensions.Form($.$hDPm.LCFCI.ViewConfiguration, $.$HGGn.LCIDIS$1.IRBlasterDisplayDevice, this.Root.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Edit Display", false), null, display, null, null, 0, 4131, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    this.Device$1.Model$1.Settings = settings;
                    ($t7 = this.Device$1.OwnerScope.LCICI$IIOTDeviceScope$UpdateDevice($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDevice), [ this.Device$1 ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    ($t8 = this.RemoteUpdate(display), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12889282482)
            
            //--TRIMMABLE-BOUNDARY-START(30069151666)
            /*Task *//*async*/  RemoveDisplay(/*IRBlasterDisplayDevice*/ display)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t9, $r9;
                    let $t10, $r10;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30069151666);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let settings = this.Device$1.Model$1.Settings ?? new $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings().$ctor$4();
                    ($t9 = this.Root.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Confirm(`Delete ${$.$strNN(display.Label)}`, `This operation is not reversible`, "Yes", "No"), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    settings.Displays = $.$sl.SL.Enumerable.ToList($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice, $.$sl.SL.Enumerable.Except$1($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice, settings.Displays, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice), [display], null, null)));
                    this.Device$1.Model$1.Settings = settings;
                    ($t10 = this.Device$1.OwnerScope.LCICI$IIOTDeviceScope$UpdateDevice($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDevice), [ this.Device$1 ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30069151666)
            
            static $h = 4380594;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$HGGn.LCIDI.IRBlasterDevice, $.$HGGn.LCIDIS$1.IRBlasterDeviceSettings, $.$HGGn.LCIDIS$1.IRBlasterDeviceHardwareSettings, $.$HGGn.LCIDIS$2.IRBlasterDeviceReceivedDataModel, $.$HGGn.LCIDIC.IRBlasterDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42954053554),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479217074,
        "f": 50331649
      },
      "n": "Title",
      "d": 4380594,
      "h": 42954053554,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42954053554)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38659086258),
    {
      "r": 178454529,
      "n": "Restart",
      "d": 4380594,
      "h": 38659086258,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38659086258),
//--TRIMMABLE-BOUNDARY-START(34364118962),
    {
      "r": 178454529,
      "n": "ResetBlasters",
      "d": 4380594,
      "h": 34364118962,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(34364118962),
//--TRIMMABLE-BOUNDARY-START(25774184370),
    {
      "r": 178454529,
      "p": [
        {
          "n": "display",
          "p": 3725234
        }
      ],
      "n": "RemoteUpdate",
      "d": 4380594,
      "h": 25774184370,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(25774184370),
//--TRIMMABLE-BOUNDARY-START(8594315186),
    {
      "r": 178454529,
      "n": "AddDisplay",
      "d": 4380594,
      "h": 8594315186,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(8594315186),
//--TRIMMABLE-BOUNDARY-START(12889282482),
    {
      "r": 178454529,
      "p": [
        {
          "n": "display",
          "p": 3725234
        }
      ],
      "n": "EditDisplay",
      "d": 4380594,
      "h": 12889282482,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(12889282482),
//--TRIMMABLE-BOUNDARY-START(30069151666),
    {
      "r": 178454529,
      "p": [
        {
          "n": "display",
          "p": 3725234
        }
      ],
      "n": "RemoveDisplay",
      "d": 4380594,
      "h": 30069151666,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(30069151666)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299347890),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 1759154
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 4380594,
      "h": 4299347890,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299347890)
  ],
  "h": 4380594
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICDV.IDeviceDetailsViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Views.IRBlasterDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Views${separator}IRBlasterDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4380594)
        
        

        //--TRIMMABLE-BOUNDARY-START(4446130)
        $asm.$cls(`$HGGn.LCIDIV.IRBlasterDeviceDetails`, ($self) => class IRBlasterDeviceDetails extends $.$hDPm.LCFCC$1.BaseComponent$$($.$HGGn.LCIDIV.IRBlasterDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(64428955570)
            /*string */ get OptimizedComponentName()
            {
                return "irblasterdevicedetails";
            }
            //--TRIMMABLE-BOUNDARY-END(64428955570)
            
            //--TRIMMABLE-BOUNDARY-START(90198759346)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90198759346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$HGGn.LCIDIV.IRBlasterDetailsViewModel);
                    return true;
                    case "Page":
                    this.Page = $.$cast(parameter.Value, $.$lJUR.LCFCS.IApplicationPageContext);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(90198759346)
            
            //--TRIMMABLE-BOUNDARY-START(94493726642)
            /*IRBlasterDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(94493726642)
            
            //--TRIMMABLE-BOUNDARY-START(68723922866)
            /*IApplicationPageContext?*/ Page = null;
            //--TRIMMABLE-BOUNDARY-END(68723922866)
            
            //--TRIMMABLE-BOUNDARY-START(60133988274)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60133988274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let pg;
                if ($.$is(this.Page, $.$lJUR.LCFCS.ApplicationPageFactoryContext$$($.$NXre.LCID.SmartDeviceBase), { set $v($v){ pg = $v; } }))
                {
                    pg.FloatingButtons = new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext)))().$ctor(this,  (/*c*/ c) =>
                    {
                        return this.FloatingButton();
                    }, $yisbOk ??= {"r":6881395,"p":[{"n":"c","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext).$h}],"n":"","d":4446130,"h":0,"f":17825794});
                }
                _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, (/*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                    {
                        while(!this.disposed)
                        {
                            let $t5, $r5;
                            if (this.ViewModel.Device$1.IsAvailable && this.ViewModel.Device$1.Settings$1.Displays !== null)
                            {
                                let $en2 = this.ViewModel.Device$1.Settings$1.Displays.SCG$IEnumerable$$$GetEnumerator();
                                while ($en2.SC$1$IEnumerator$MoveNext())
                                {
                                    let display = $en2.SCG$IEnumerator$$$Current;
                                    {
                                        try
                                        {
                                            let $t3, $r3;
                                            let $t4, $r4;
                                            ($t3 = $.$$.STT.Task.Delay$1(2000), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                            ($t4 = this.ViewModel.RemoteUpdate(display), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                        }
                                        catch(e)
                                        {
                                            $.$fPer.LCFCL.LoggingFactory.LogException(e, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.IRBlaster\\IRBlasterDeviceDetails.razor.cs", "OnInitialized", 41);
                                        }
                                    }
                                }
                            }
                            ($t5 = $.$$.STT.Task.Delay$1(1000), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        }
                    });
                }), $EOrJKh ??= {"r":178454529,"n":"","d":4446130,"h":0,"f":17829890}));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(60133988274)
            
            //--TRIMMABLE-BOUNDARY-START(25774249906)
            /*bool*/ disposed = false;
            //--TRIMMABLE-BOUNDARY-END(25774249906)
            
            //--TRIMMABLE-BOUNDARY-START(21479282610)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479282610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.disposed = true;
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(21479282610)
            
            //--TRIMMABLE-BOUNDARY-START(17184315314)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184315314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$HGGn.LCIDI.IRBlasterDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$HGGn.LCIDI.IRBlasterDevice), this.ViewModel));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    if (this.ViewModel.Device$1.Settings$1.Displays !== null)
                    {
                        __builder2.OpenElement(3, "div");
                        __builder2.AddAttribute$5(4, "class", "grid colm-15 gap-1 pd");
                        let $en6 = this.ViewModel.Device$1.Settings$1.Displays.SCG$IEnumerable$$$GetEnumerator();
                        while ($en6.SC$1$IEnumerator$MoveNext())
                        {
                            let _display = $en6.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let display = _display;
                                __builder2.OpenElement(5, "div");
                                __builder2.AddAttribute$5(6, "class", "bg-card stack clip clickable");
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 7, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                {
                                    return this.ViewModel.EditDisplay(display);
                                }, $xlQApa ??= {"r":178454529,"n":"","d":4446130,"h":0,"f":17825794})));
                                __builder2.SetKey(display);
                                __builder2.OpenElement(8, "div");
                                __builder2.AddAttribute$5(9, "class", "hx-1 pos-rel animate");
                                __builder2.OpenElement(10, "button");
                                __builder2.AddAttribute$5(11, "class", "mdi mdi-delete bg-transparent pos-abs fade-in-hover l-0 t-0 pd-2 round cl-error bg-gray-02 wx-04 hx-04 mg-2 fsz-18");
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 12, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                {
                                    return this.ViewModel.RemoveDisplay(display);
                                }, $OAzNvk ??= {"r":178454529,"n":"","d":4446130,"h":0,"f":17825794})));
                                $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 13, "onclick", true);
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(14, "\r\n                        ");
                                __builder2.OpenElement(15, "div");
                                __builder2.AddAttribute$5(16, "class", "pos-abs r-0 t-0 bg-error-07 corner-bl-3 cl-white pd-2 fsz-18");
                                __builder2.AddContent$4(17, "\u20A6"/*Money.NairaSymbol*/);
                                __builder2.AddContent$4(18, $.$$.S.Double.ToString$3.call(display.Number, "#,###"));
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(19, "\r\n                        ");
                                __builder2.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 20);
                                __builder2.AddComponentParameter(21, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, display.Image));
                                __builder2.AddComponentParameter(22, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                __builder2.CloseComponent();
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(23, "\r\n                    ");
                                __builder2.OpenElement(24, "div");
                                __builder2.AddAttribute$5(25, "class", "pd bdt");
                                __builder2.OpenElement(26, "h3");
                                __builder2.AddAttribute$5(27, "class", "mg-0");
                                __builder2.AddContent$4(28, display.Label);
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(29, "\r\n                        ");
                                __builder2.OpenElement(30, "small");
                                __builder2.AddAttribute$5(31, "class", "op-7");
                                __builder2.AddContent$4(32, display.Id);
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                            }
                        }
                        __builder2.CloseElement();
                    }
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.Devices.IRBlaster.Settings.IRBlasterDisplayDevice>?*/ let __ca1__;
                    if (!(((__ca1__ = this.ViewModel.Device$1.Settings$1.Displays) !== null ? $.$sl.SL.Enumerable.Any$1($.$HGGn.LCIDIS$1.IRBlasterDisplayDevice, __ca1__) : false)) || this.Page === null)
                    {
                        __builder2.OpenElement(33, "div");
                        __builder2.AddAttribute$5(34, "class", "stack mgt");
                        __builder2.OpenElement(35, "button");
                        __builder2.AddAttribute$5(36, "class", "fsz-50 bg-primary-01 mdi mdi-plus corner-10 miwx-2 mgx-a");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 37, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this.ViewModel, this.ViewModel.AddDisplay)));
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(38, "\r\n            ");
                        __builder2.AddMarkupContent(39, "<span class=\"mgx-a fsz-20\">Add Display</span>");
                        __builder2.CloseElement();
                    }
                }), $CSMTFk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":4446130,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17184315314)
            
            //--TRIMMABLE-BOUNDARY-START(30069217202)
            /*RenderFragment */ FloatingButton()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30069217202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 40);
                    __builder2.AddComponentParameter(41, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder2.AddComponentParameter(42, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 132178/*ButtonFeatures.FloatingButton*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.AddComponentParameter(43, "Class", "mdi mdi-plus");
                    __builder2.AddComponentParameter(44, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this.ViewModel, this.ViewModel.AddDisplay))));
                    __builder2.CloseComponent();
                }, $XQkdqg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":4446130,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(30069217202)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12889348018)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889348018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12889348018)
            
            //--TRIMMABLE-BOUNDARY-START(12889348018)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12889348018)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(94493726642)
                this.ViewModel = null;
                //--TRIMMABLE-BOUNDARY-END(94493726642)
                
            }
            static $h = 4446130;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$HGGn.LCIDIV.IRBlasterDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64428955570),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38659151794,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 4446130,
      "h": 64428955570,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64428955570),
//--TRIMMABLE-BOUNDARY-START(94493726642),
    {
      "p": 4380594,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55839020978,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85903792050,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 4446130,
      "h": 94493726642,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94493726642),
//--TRIMMABLE-BOUNDARY-START(68723922866),
    {
      "p": 4730953,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47249086386,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77313857458,
        "f": 83886081
      },
      "n": "Page",
      "d": 4446130,
      "h": 68723922866,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68723922866)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90198759346),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 4446130,
      "h": 90198759346,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90198759346),
//--TRIMMABLE-BOUNDARY-START(60133988274),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 4446130,
      "h": 60133988274,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(60133988274),
//--TRIMMABLE-BOUNDARY-START(21479282610),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 4446130,
      "h": 21479282610,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21479282610),
//--TRIMMABLE-BOUNDARY-START(17184315314),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 4446130,
      "h": 17184315314,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17184315314),
//--TRIMMABLE-BOUNDARY-START(30069217202),
    {
      "r": 6881395,
      "n": "FloatingButton",
      "d": 4446130,
      "h": 30069217202,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30069217202)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25774249906),
    {
      "t": 262145,
      "n": "disposed",
      "d": 4446130,
      "h": 25774249906,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25774249906)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12889348018),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4446130,
      "h": 12889348018,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889348018)
  ],
  "h": 4446130
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCC$1.IManagedBaseComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IRBlaster.Views.IRBlasterDeviceDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IRBlaster${separator}Views${separator}IRBlasterDeviceDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4446130)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(55218)
