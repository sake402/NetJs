
//--TRIMMABLE-BOUNDARY-START(9095)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $Ggxhcc;
    let $Kvgrta;
    let $aWIIAk;
    let $PpcdIc;
    let $fGVFfa;
    let $kOllHd;
    let $yeURCk;
    let $YzfIPc;
    let $JzRUuf;
    let $suCehg;
    let $WlEyBi;
    let $bnRzFf;
    let $RGLUgh;
    let $fqZFjh;
    let $tINzHe;
    let $oAlxPe;
    let $nzCxjb;
    let $fbDqbl;
    let $fLfiMc;
    let $Zbtkqg;
    let $ElsKbc;
    let $vCvzHi;
    let $IOWkub;
    let $UtQTQf;
    let $iooBQb;
    let $FWFHoa;
    let $rMxoqa;
    let $IOKbgl;
    let $Hliyrb;
    let $SmHOAe;
    let $EWyImh;
    let $qTHJXh;
    let $emvGCd;
    let $jEUAFg;
    let $lmecVb;
    let $iDNFBc;
    let $cQwlef;
    let $vQZuMc;
    let $pTveRf;
    let $sPpKah;
    let $jYqfZb;
    let $uKOeGe;
    let $QICawj;
    let $jueRBc;
    let $skrptf;
    let $VXjgZj;
    let $qGSGbg;
    let $aPSIJk;
    let $oclEic;
    let $CluQLf;
    let $llEmHb;
    let $ZsdBKe;
    let $HkcXIb;
    let $OLVsVa;
    let $QVbkBj;
    let $HVGNtd;
    let $WKStqh;
    let $HFzaja;
    let $gqEDif;
    let $bnvJkj;
    let $RdPwWf;
    let $iHSREi;
    let $WvFZpk;
    let $zzfZNa;
    let $EHZXlg;
    let $ULfDai;
    let $AtPQhf;
    let $wcAshg;
    let $artLJe;
    let $oKzHcf;
    let $PTalsg;
    let $pybyzb;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.LEDMatrix", 
    {
  "h": 9095,
  "f": "LivingThing.Core.IOT.Devices.LEDMatrix",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.LEDMatrix",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.LEDMatrix",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5MRURNYXRyaXguU21hcnRMRURNYXRyaXhEZXZpY2UiOiB7DQogICAgICAiQ2F0ZWdvcmllcyI6IFsgIkxpZ2h0bmluZyIsICJBZHZlcnRzIiBdLA0KICAgICAgIk5hbWUiOiAiU21hcnQgTEVEIE1hdHJpeCIsDQogICAgICAiRGVzY3JpcHRpb24iOiAiTEVEIG1hdHJpeCBkaXNwbGF5IHNpZ25hZ2UvYm9hcmQiLA0KICAgICAgIkJhbm5lckltYWdlIjogIn4vaW1nL3ByaWNlZGlzcGxheS5qcGciLA0KICAgICAgIkltYWdlcyI6WyAifi9pbWcvcHJpY2VkaXNwbGF5LmpwZyIsICJ\u002BL2ltZy9wcmljZWRpc3BsYXkyLmpwZyJdLA0KICAgICAgIkljb24iOiB7ICJOYW1lIjogIm1kaSBtZGktZWxlY3RyaWMtc3dpdGNoIiB9LA0KICAgICAgIlRoZW1lQ29sb3IiOiAiI2Q3N2JiYSIsDQogICAgICAiRmxhZ3MiOiAiRmVhdHVyZWQsUHVibGlzaGVkIiwNCiAgICAgICJTZWN1cml0aWVzIjogIkNoYWxsZW5nZUhhbmRTaGFrZUF1dGhlbnRpY2F0aW9uUHJvdG9jb2wsQWR2YW5jZWRFbmNyeXB0aW9uU3RhbmRhcmQsRWxsaXB0aWNDdXJ2ZUZpcm13YXJlVXBkYXRlU2lnbmluZyIsDQogICAgICAiVmFyaWFudHMiOiBbDQogICAgICAgIHsNCiAgICAgICAgICAiTmFtZSI6ICJGb3JlY291cnQgUHJpY2UgRGlzcGxheSIsDQogICAgICAgICAgIkltYWdlcyI6IFsgIn4vcHJpY2VkaXNwbGF5LmpwZyIsICJ\u002BL2ltZy9wcmljZWRpc3BsYXkyLmpwZyIgXSwNCiAgICAgICAgICAiRGVzY3JpcHRpb24iOiAiQ2xvdWQgY29ubmVjdGVkIGZvcmVjb3VydCBMRUQgcHJpY2UgZGlzcGxheSBib2FyZCIsDQogICAgICAgICAgIlNlcnZpY2VMaW5rIjogIkxFRE1hdHJpeC9QcmljZSINCiAgICAgICAgfQ0KICAgICAgXSwNCiAgICAgICJGZWF0dXJlcyI6IFsNCiAgICAgICAgew0KICAgICAgICAgICJUaXRsZSI6ICJDb25uZWN0aXZpdHkiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJXaUZpL0dQUlMiDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiQ2xvdWQiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJMaXZpbmdUaGluZ\u002BKEoiINCiAgICAgICAgfSwNCiAgICAgICAgew0KICAgICAgICAgICJUaXRsZSI6ICJQcm90b2NvbCIsDQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogImlTbWFydOKEoiINCiAgICAgICAgfQ0KICAgICAgXSwNCiAgICAgICJCZW5lZml0cyI6IFsNCiAgICAgICAgew0KICAgICAgICAgICJUaXRsZSI6ICJJbnN0YW50IFVwZGF0ZSIsDQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogIlVwZGF0ZSB0aGUgY29udGVudCBvZiB0aGUgZGlzcGxheSBmcm9tIGFueXdoZXJlIGluIHRoZSB3b3JsZCwgYnkgc2ltcGx5IGxvZ2dpbmcgaW50byB0aGUgTGl2aW5nVGhpbmcgY2xvdWQgZGFzaGJvYXJkIg0KICAgICAgICB9DQogICAgICBdLA0KICAgICAgIlNwZWNpZmljYXRpb25zIjogWw0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIlN1cHBseSBWb2x0YWdlIiwNCiAgICAgICAgICAiVmFsdWUiOiAiMTEwVi8yMjBWIg0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIkNvbG9ycyIsDQogICAgICAgICAgIlZhbHVlIjogIlJlZC9HcmVlbi9CbHVlL1doaXRlIg0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIlNlY3VyaXR5IiwNCiAgICAgICAgICAiVmFsdWUiOiAiTWlsaXRhcnkgZ3JhZGUiDQogICAgICAgIH0NCiAgICAgIF0NCiAgICB9DQogIH0NCn0="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(729991)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class SmartLEDMatrixDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295697287)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295697287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$$($.$PkgL.LCIDLM.SmartLEDMatrixStatusModel, $.$PkgL.LCIDLM.SmartLEDMatrixLogModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295697287)
            
            static $h = 729991;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295697287),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 729991,
      "h": 4295697287,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295697287)
  ],
  "h": 729991
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(729991)
        
        

        //--TRIMMABLE-BOUNDARY-START(467847)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDeviceModelCustomAttributesProvider`, ($self) => class SmartLEDMatrixDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295435143)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295435143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295435143)
            
            static $h = 467847;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295435143),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 467847,
      "h": 4295435143,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295435143)
  ],
  "h": 467847
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(467847)
        
        

        //--TRIMMABLE-BOUNDARY-START(2958215)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixServiceModelCustomAttributesProvider`, ($self) => class SmartLEDMatrixServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297925511)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297925511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297925511)
            
            static $h = 2958215;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297925511),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2958215,
      "h": 4297925511,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297925511)
  ],
  "h": 2958215
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2958215)
        
        

        //--TRIMMABLE-BOUNDARY-START(4268935)
        $asm.$cls(`$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettingsCustomAttributesProvider`, ($self) => class SmartLEDMatrixDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299236231)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299236231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299236231)
            
            static $h = 4268935;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299236231),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4268935,
      "h": 4299236231,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299236231)
  ],
  "h": 4268935
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Settings${separator}SmartLEDMatrixDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4268935)
        
        

        //--TRIMMABLE-BOUNDARY-START(271239)
        $asm.$cls(`$PkgL.LCIDL.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295238535)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295238535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixDeviceModelCustomAttributesProvider, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModelCustomAttributesProvider, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModelCustomAttributesProvider, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModelCustomAttributesProvider, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PkgL.LCIDLM.SmartLEDMatrixDisplayMode.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixDisplayModeCustomAttributesProvider, $.$PkgL.LCIDLM.SmartLEDMatrixDisplayModeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PkgL.LCIDLM.SmartLEDMatrixLogModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixLogModelCustomAttributesProvider, $.$PkgL.LCIDLM.SmartLEDMatrixLogModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModelCustomAttributesProvider, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModelCustomAttributesProvider, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixServiceModelCustomAttributesProvider, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PkgL.LCIDLM.SmartLEDMatrixStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixStatusModelCustomAttributesProvider, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettingsCustomAttributesProvider, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettingsCustomAttributesProvider, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295238535)
            
            static $h = 271239;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295238535),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 271239,
      "h": 4295238535,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295238535)
  ],
  "h": 271239
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(271239)
        
        

        //--TRIMMABLE-BOUNDARY-START(1516423)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDisplayModeCustomAttributesProvider`, ($self) => class SmartLEDMatrixDisplayModeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296483719)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296483719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296483719)
            
            static $h = 1516423;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296483719),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1516423,
      "h": 4296483719,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296483719)
  ],
  "h": 1516423
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDisplayModeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDisplayModeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1516423)
        
        

        //--TRIMMABLE-BOUNDARY-START(4793223)
        $asm.$cls(`$PkgL.LCIDL.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4299760519)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299760519);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModelTypeDescriptorBuilder.Register();
                $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$PkgL.LCIDLM.SmartLEDMatrixLogModelTypeDescriptorBuilder.Register();
                $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModelTypeDescriptorBuilder.Register();
                $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModelTypeDescriptorBuilder.Register();
                $.$fPer.LCFCD$1.SystemTypeDescriptor.RegisterLazyTypeDescriptorRegistrar($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$().$type, new ($.$$.S.Action$$($.$typeArray($.$$.S.Type)))().$ctor(this,  (/*types*/ types) =>
                {
                    return $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelTypeDescriptorBuilder$$().$type.MakeGenericType(types).GetMethod$9("Register", 8/*System.Reflection.BindingFlags.Static*/ | 16/*System.Reflection.BindingFlags.Public*/).Invoke(null, null);
                }, $Ggxhcc ??= {"r":65537,"p":[{"n":"types","p":$.$typeArray($.$$.S.Type).$h}],"n":"","d":4793223,"h":0,"f":17825794}));
                $.$PkgL.LCIDLM.SmartLEDMatrixServiceModelTypeDescriptorBuilder.Register();
                $.$PkgL.LCIDLM.SmartLEDMatrixStatusModelTypeDescriptorBuilder.Register();
                $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4299760519)
            
            static $h = 4793223;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299760519),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 4793223,
      "h": 4299760519,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4299760519)
  ],
  "h": 4793223
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4793223)
        
        

        //--TRIMMABLE-BOUNDARY-START(4006791)
        $asm.$cls(`$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class SmartLEDMatrixDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298974087)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298974087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298974087)
            
            static $h = 4006791;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298974087),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4006791,
      "h": 4298974087,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298974087)
  ],
  "h": 4006791
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Settings${separator}SmartLEDMatrixDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4006791)
        
        

        //--TRIMMABLE-BOUNDARY-START(861063)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class SmartLEDMatrixDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590795655)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590795655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $PpcdIc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":861063,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590795655)
            
            //--TRIMMABLE-BOUNDARY-START(4295828359)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295828359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295828359)
            
            //--TRIMMABLE-BOUNDARY-START(4295828359)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295828359)
            
            static $h = 861063;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590795655),
    {
      "r": 65537,
      "n": "Register",
      "d": 861063,
      "h": 8590795655,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590795655)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295828359),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 861063,
      "h": 4295828359,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295828359)
  ],
  "h": 861063
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(861063)
        
        

        //--TRIMMABLE-BOUNDARY-START(3482503)
        $asm.$cls(`$PkgL.LCIDL.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593417095)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593417095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$PkgL.LCIDLV.PriceDisplay, "LivingThing.Core.IOT.Devices.LEDMatrix", "Views\\PriceDisplay", "Price Display", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/LEDMatrix/PriceDisplay" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8593417095)
            
            //--TRIMMABLE-BOUNDARY-START(4298449799)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298449799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298449799)
            
            //--TRIMMABLE-BOUNDARY-START(4298449799)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298449799)
            
            static $h = 3482503;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593417095),
    {
      "r": 65537,
      "n": "Build",
      "d": 3482503,
      "h": 8593417095,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8593417095)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298449799),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3482503,
      "h": 4298449799,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298449799)
  ],
  "h": 3482503
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3482503)
        
        

        //--TRIMMABLE-BOUNDARY-START(1254279)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModelCustomAttributesProvider`, ($self) => class SmartLEDMatrixDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296221575)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296221575)
            
            //--TRIMMABLE-BOUNDARY-START(8591188871)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591188871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("On", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (13432);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $Kvgrta ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1254279,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $aWIIAk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1254279,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceSendDataModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591188871)
            
            static $h = 1254279;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591188871),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1254279,
      "h": 8591188871,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591188871)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296221575),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1254279,
      "h": 4296221575,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296221575)
  ],
  "h": 1254279
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1254279)
        
        

        //--TRIMMABLE-BOUNDARY-START(992135)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModelCustomAttributesProvider`, ($self) => class SmartLEDMatrixDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295959431)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295959431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295959431)
            
            static $h = 992135;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295959431),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 992135,
      "h": 4295959431,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295959431)
  ],
  "h": 992135
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(992135)
        
        

        //--TRIMMABLE-BOUNDARY-START(2630535)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelCustomAttributesProvider<>`, (TControl) => $asm.$gt(`$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelCustomAttributesProvider<>`, [TControl], ($self) => class SmartLEDMatrixRegionControlModelCustomAttributesProvider$$
        {
            //--TRIMMABLE-BOUNDARY-START(4297597831)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297597831)
            
            //--TRIMMABLE-BOUNDARY-START(8592565127)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592565127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelCustomAttributesProvider$$(TControl).compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Region", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1024);
                            $i3.ConvertType = ($.$$.S.Byte.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Mode", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (1025);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("RegionControl", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (1025);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelCustomAttributesProvider$$(TControl).compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $kOllHd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $yeURCk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592565127)
            
            static $H = 2630535;
            static $h = 2630535;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592565127),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": this.$h,
      "H": 8592565127,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592565127)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297597831),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": this.$h,
      "H": 4297597831,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297597831)
  ],
  "s": [
    {
      "h": TControl?.$h??1572864,
      "n": "TControl",
      "c": [16487825
      ]
    }
  ],
  "r": 1,
  "H": 2630535,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixRegionControlModelCustomAttributesProvider<${TControl?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixRegionControlModelCustomAttributesProvider$${TControl?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2630535)
        
        

        //--TRIMMABLE-BOUNDARY-START(3220359)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixStatusModelCustomAttributesProvider`, ($self) => class SmartLEDMatrixStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298187655)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298187655)
            
            //--TRIMMABLE-BOUNDARY-START(8593154951)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593154951);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$PkgL.LCIDLM.SmartLEDMatrixStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(4, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Width", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.ConvertType = ($.$$.S.Int16.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Height", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.ConvertType = ($.$$.S.Int16.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Brightness", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3);
                            $i5.ConvertType = ($.$$.S.Byte.$type);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Regions", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (4);
                            $i6.Flags = (65536);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$PkgL.LCIDLM.SmartLEDMatrixStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $suCehg ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3220359,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $WlEyBi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3220359,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593154951)
            
            static $h = 3220359;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593154951),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3220359,
      "h": 8593154951,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593154951)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298187655),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3220359,
      "h": 4298187655,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298187655)
  ],
  "h": 3220359
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3220359)
        
        

        //--TRIMMABLE-BOUNDARY-START(1647495)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixLogModelCustomAttributesProvider`, ($self) => class SmartLEDMatrixLogModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296614791)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296614791)
            
            //--TRIMMABLE-BOUNDARY-START(8591582087)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591582087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$PkgL.LCIDLM.SmartLEDMatrixLogModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Id", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (12);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$PkgL.LCIDLM.SmartLEDMatrixLogModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $YzfIPc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1647495,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $JzRUuf ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1647495,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceLogModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591582087)
            
            static $h = 1647495;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591582087),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1647495,
      "h": 8591582087,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591582087)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296614791),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1647495,
      "h": 4296614791,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296614791)
  ],
  "h": 1647495
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixLogModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixLogModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1647495)
        
        

        //--TRIMMABLE-BOUNDARY-START(2696071)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelCustomAttributesProviderRegistrar1`, ($self) => class SmartLEDMatrixRegionControlModelCustomAttributesProviderRegistrar1
        {
            //--TRIMMABLE-BOUNDARY-START(4297663367)
            static /*void */ AddGeneratedFastAttributesOfSmartLEDMatrixRegionControlModel(TControl, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297663367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl).$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelCustomAttributesProvider$$(TControl), $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelCustomAttributesProvider$$(TControl).GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4297663367)
            
            static $h = 2696071;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297663367),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TControl"
      ],
      "n": "AddGeneratedFastAttributesOfSmartLEDMatrixRegionControlModel",
      "d": 2696071,
      "h": 4297663367,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(4297663367)
  ],
  "h": 2696071
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixRegionControlModelCustomAttributesProviderRegistrar1`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixRegionControlModelCustomAttributesProviderRegistrar1`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2696071)
        
        

        //--TRIMMABLE-BOUNDARY-START(2106247)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModelTypeDescriptorBuilder`, ($self) => class SmartLEDMatrixPriceSetConfigControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592040839)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592040839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModelTypeDescriptor()
                        const $t1 = $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetConfigControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $oAlxPe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2106247,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592040839)
            
            //--TRIMMABLE-BOUNDARY-START(4297073543)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297073543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297073543)
            
            //--TRIMMABLE-BOUNDARY-START(4297073543)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297073543)
            
            static $h = 2106247;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592040839),
    {
      "r": 65537,
      "n": "Register",
      "d": 2106247,
      "h": 8592040839,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592040839)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297073543),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2106247,
      "h": 4297073543,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297073543)
  ],
  "h": 2106247
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetConfigControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixPriceSetConfigControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2106247)
        
        

        //--TRIMMABLE-BOUNDARY-START(336775)
        $asm.$cls(`$PkgL.LCIDL.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295304071)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295304071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295304071)
            
            static $h = 336775;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295304071),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 336775,
      "h": 4295304071,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295304071)
  ],
  "h": 336775
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(336775)
        
        

        //--TRIMMABLE-BOUNDARY-START(598919)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDeviceModelTypeDescriptorBuilder`, ($self) => class SmartLEDMatrixDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590533511)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590533511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModelTypeDescriptor()
                        const $t1 = $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $bnRzFf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":598919,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590533511)
            
            //--TRIMMABLE-BOUNDARY-START(4295566215)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295566215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295566215)
            
            //--TRIMMABLE-BOUNDARY-START(4295566215)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295566215)
            
            static $h = 598919;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590533511),
    {
      "r": 65537,
      "n": "Register",
      "d": 598919,
      "h": 8590533511,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590533511)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295566215),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 598919,
      "h": 4295566215,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295566215)
  ],
  "h": 598919
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(598919)
        
        

        //--TRIMMABLE-BOUNDARY-START(2368391)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModelTypeDescriptorBuilder`, ($self) => class SmartLEDMatrixPriceSetPriceControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592302983)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592302983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModelTypeDescriptor()
                        const $t1 = $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetPriceControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $UtQTQf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2368391,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592302983)
            
            //--TRIMMABLE-BOUNDARY-START(4297335687)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297335687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297335687)
            
            //--TRIMMABLE-BOUNDARY-START(4297335687)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297335687)
            
            static $h = 2368391;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592302983),
    {
      "r": 65537,
      "n": "Register",
      "d": 2368391,
      "h": 8592302983,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592302983)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297335687),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2368391,
      "h": 4297335687,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297335687)
  ],
  "h": 2368391
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetPriceControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixPriceSetPriceControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2368391)
        
        

        //--TRIMMABLE-BOUNDARY-START(1975175)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModelCustomAttributesProvider`, ($self) => class SmartLEDMatrixPriceSetConfigControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296942471)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296942471)
            
            //--TRIMMABLE-BOUNDARY-START(8591909767)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591909767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Config", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $fqZFjh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1975175,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $tINzHe ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1975175,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591909767)
            
            static $h = 1975175;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591909767),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1975175,
      "h": 8591909767,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591909767)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296942471),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1975175,
      "h": 4296942471,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296942471)
  ],
  "h": 1975175
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetConfigControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixPriceSetConfigControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1975175)
        
        

        //--TRIMMABLE-BOUNDARY-START(4400007)
        $asm.$cls(`$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettingsTypeDescriptorBuilder`, ($self) => class SmartLEDMatrixDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594334599)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594334599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettingsTypeDescriptor()
                        const $t1 = $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Zbtkqg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4400007,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594334599)
            
            //--TRIMMABLE-BOUNDARY-START(4299367303)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299367303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299367303)
            
            //--TRIMMABLE-BOUNDARY-START(4299367303)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299367303)
            
            static $h = 4400007;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594334599),
    {
      "r": 65537,
      "n": "Register",
      "d": 4400007,
      "h": 8594334599,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594334599)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299367303),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4400007,
      "h": 4299367303,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299367303)
  ],
  "h": 4400007
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Settings${separator}SmartLEDMatrixDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4400007)
        
        

        //--TRIMMABLE-BOUNDARY-START(2237319)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModelCustomAttributesProvider`, ($self) => class SmartLEDMatrixPriceSetPriceControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297204615)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297204615)
            
            //--TRIMMABLE-BOUNDARY-START(8592171911)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592171911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Prices", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $vCvzHi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2237319,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $IOWkub ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2237319,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592171911)
            
            static $h = 2237319;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592171911),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2237319,
      "h": 8592171911,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592171911)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297204615),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2237319,
      "h": 4297204615,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297204615)
  ],
  "h": 2237319
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetPriceControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixPriceSetPriceControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2237319)
        
        

        //--TRIMMABLE-BOUNDARY-START(1778567)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixLogModelTypeDescriptorBuilder`, ($self) => class SmartLEDMatrixLogModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591713159)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591713159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PkgL.LCIDLM.SmartLEDMatrixLogModelTypeDescriptor()
                        const $t1 = $.$PkgL.LCIDLM.SmartLEDMatrixLogModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixLogModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $EWyImh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1778567,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PkgL.LCIDLM.SmartLEDMatrixLogModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591713159)
            
            //--TRIMMABLE-BOUNDARY-START(4296745863)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296745863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296745863)
            
            //--TRIMMABLE-BOUNDARY-START(4296745863)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296745863)
            
            static $h = 1778567;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591713159),
    {
      "r": 65537,
      "n": "Register",
      "d": 1778567,
      "h": 8591713159,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591713159)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296745863),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1778567,
      "h": 4296745863,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296745863)
  ],
  "h": 1778567
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixLogModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixLogModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1778567)
        
        

        //--TRIMMABLE-BOUNDARY-START(140167)
        $asm.$cls(`$PkgL.LCIDL._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295107463)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295107463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$PkgL.LCIDL.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295107463)
            
            static $h = 140167;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295107463),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 140167,
      "h": 4295107463,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295107463)
  ],
  "h": 140167
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(140167)
        
        

        //--TRIMMABLE-BOUNDARY-START(2827143)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelTypeDescriptorBuilder<>`, (TControl) => $asm.$gt(`$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelTypeDescriptorBuilder<>`, [TControl], ($self) => class SmartLEDMatrixRegionControlModelTypeDescriptorBuilder$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592761735)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592761735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelTypeDescriptor$$(TControl)()
                        const $t1 = $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelTypeDescriptor$$(TControl);
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixRegionControlModel<TControl>");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $OLVsVa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl).$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592761735)
            
            //--TRIMMABLE-BOUNDARY-START(4297794439)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297794439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297794439)
            
            //--TRIMMABLE-BOUNDARY-START(4297794439)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297794439)
            
            static $H = 2827143;
            static $h = 2827143;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592761735),
    {
      "r": 65537,
      "n": "Register",
      "d": this.$h,
      "H": 8592761735,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592761735)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297794439),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4297794439,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297794439)
  ],
  "s": [
    {
      "h": TControl?.$h??1572864,
      "n": "TControl",
      "c": [16487825
      ]
    }
  ],
  "r": 1,
  "H": 2827143,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixRegionControlModelTypeDescriptorBuilder<${TControl?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixRegionControlModelTypeDescriptorBuilder$${TControl?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2827143)
        
        

        //--TRIMMABLE-BOUNDARY-START(1123207)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModelTypeDescriptorBuilder`, ($self) => class SmartLEDMatrixDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591057799)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591057799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Hliyrb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1123207,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591057799)
            
            //--TRIMMABLE-BOUNDARY-START(4296090503)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296090503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296090503)
            
            //--TRIMMABLE-BOUNDARY-START(4296090503)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296090503)
            
            static $h = 1123207;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591057799),
    {
      "r": 65537,
      "n": "Register",
      "d": 1123207,
      "h": 8591057799,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591057799)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296090503),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1123207,
      "h": 4296090503,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296090503)
  ],
  "h": 1123207
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1123207)
        
        

        //--TRIMMABLE-BOUNDARY-START(3089287)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixServiceModelTypeDescriptorBuilder`, ($self) => class SmartLEDMatrixServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593023879)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593023879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PkgL.LCIDLM.SmartLEDMatrixServiceModelTypeDescriptor()
                        const $t1 = $.$PkgL.LCIDLM.SmartLEDMatrixServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $iDNFBc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3089287,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593023879)
            
            //--TRIMMABLE-BOUNDARY-START(4298056583)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298056583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298056583)
            
            //--TRIMMABLE-BOUNDARY-START(4298056583)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298056583)
            
            static $h = 3089287;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593023879),
    {
      "r": 65537,
      "n": "Register",
      "d": 3089287,
      "h": 8593023879,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593023879)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298056583),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3089287,
      "h": 4298056583,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298056583)
  ],
  "h": 3089287
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3089287)
        
        

        //--TRIMMABLE-BOUNDARY-START(1385351)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class SmartLEDMatrixDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591319943)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591319943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $CluQLf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1385351,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591319943)
            
            //--TRIMMABLE-BOUNDARY-START(4296352647)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296352647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296352647)
            
            //--TRIMMABLE-BOUNDARY-START(4296352647)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296352647)
            
            static $h = 1385351;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591319943),
    {
      "r": 65537,
      "n": "Register",
      "d": 1385351,
      "h": 8591319943,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591319943)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296352647),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1385351,
      "h": 4296352647,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296352647)
  ],
  "h": 1385351
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1385351)
        
        

        //--TRIMMABLE-BOUNDARY-START(4137863)
        $asm.$cls(`$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class SmartLEDMatrixDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594072455)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594072455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $aPSIJk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4137863,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594072455)
            
            //--TRIMMABLE-BOUNDARY-START(4299105159)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299105159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299105159)
            
            //--TRIMMABLE-BOUNDARY-START(4299105159)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299105159)
            
            static $h = 4137863;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594072455),
    {
      "r": 65537,
      "n": "Register",
      "d": 4137863,
      "h": 8594072455,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594072455)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299105159),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4137863,
      "h": 4299105159,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299105159)
  ],
  "h": 4137863
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Settings${separator}SmartLEDMatrixDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4137863)
        
        

        //--TRIMMABLE-BOUNDARY-START(3351431)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixStatusModelTypeDescriptorBuilder`, ($self) => class SmartLEDMatrixStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593286023)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593286023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PkgL.LCIDLM.SmartLEDMatrixStatusModelTypeDescriptor()
                        const $t1 = $.$PkgL.LCIDLM.SmartLEDMatrixStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $WvFZpk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3351431,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PkgL.LCIDLM.SmartLEDMatrixStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593286023)
            
            //--TRIMMABLE-BOUNDARY-START(4298318727)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298318727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298318727)
            
            //--TRIMMABLE-BOUNDARY-START(4298318727)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298318727)
            
            static $h = 3351431;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593286023),
    {
      "r": 65537,
      "n": "Register",
      "d": 3351431,
      "h": 8593286023,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593286023)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298318727),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3351431,
      "h": 4298318727,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298318727)
  ],
  "h": 3351431
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3351431)
        
        

        //--TRIMMABLE-BOUNDARY-START(205703)
        $asm.$cls(`$PkgL.LCIDL.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180074887)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$sl.SL.Enumerable.Empty($.$$.S.String);
            }
            //--TRIMMABLE-BOUNDARY-END(17180074887)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295172999)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295172999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295172999)
            
            //--TRIMMABLE-BOUNDARY-START(4295172999)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295172999)
            
            static $h = 205703;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180074887),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885107591,
        "f": 50331649
      },
      "n": "Paths",
      "d": 205703,
      "h": 17180074887,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180074887)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295172999),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 205703,
      "h": 4295172999,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295172999)
  ],
  "h": 205703
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(205703)
        
        

        //--TRIMMABLE-BOUNDARY-START(1844103)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixPriceConfig`, ($self) => class SmartLEDMatrixPriceConfig extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51541451655)
            /*int*/ CharactersWidth = 0;
            //--TRIMMABLE-BOUNDARY-END(51541451655)
            
            //--TRIMMABLE-BOUNDARY-START(47246484359)
            /*int*/ CharactersHeight = 0;
            //--TRIMMABLE-BOUNDARY-END(47246484359)
            
            //--TRIMMABLE-BOUNDARY-START(154620666759)
            /*int*/ SegmentWidth = 0;
            //--TRIMMABLE-BOUNDARY-END(154620666759)
            
            //--TRIMMABLE-BOUNDARY-START(146030732167)
            /*int*/ SegmentHeight = 0;
            //--TRIMMABLE-BOUNDARY-END(146030732167)
            
            //--TRIMMABLE-BOUNDARY-START(150325699463)
            /*int*/ SegmentSpace = 0;
            //--TRIMMABLE-BOUNDARY-END(150325699463)
            
            //--TRIMMABLE-BOUNDARY-START(55836418951)
            /*int*/ DecimalPoint = 0;
            //--TRIMMABLE-BOUNDARY-END(55836418951)
            
            //--TRIMMABLE-BOUNDARY-START(64426353543)
            /*bool*/ FloatingDecimal = false;
            //--TRIMMABLE-BOUNDARY-END(64426353543)
            
            //--TRIMMABLE-BOUNDARY-START(236225045383)
            /*bool*/ UseSegment = false;
            //--TRIMMABLE-BOUNDARY-END(236225045383)
            
            //--TRIMMABLE-BOUNDARY-START(60131386247)
            /*bool*/ DisplayIsSegment = false;
            //--TRIMMABLE-BOUNDARY-END(60131386247)
            
            //--TRIMMABLE-BOUNDARY-START(42951517063)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951517063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951517063)
            
            //--TRIMMABLE-BOUNDARY-START(42951517063)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(42951517063)
            
            static $h = 1844103;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51541451655),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606222727,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171800535943,
        "f": 83886081
      },
      "n": "CharactersWidth",
      "d": 1844103,
      "h": 51541451655,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541451655),
//--TRIMMABLE-BOUNDARY-START(47246484359),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016288135,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163210601351,
        "f": 83886081
      },
      "n": "CharactersHeight",
      "d": 1844103,
      "h": 47246484359,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47246484359),
//--TRIMMABLE-BOUNDARY-START(154620666759),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145830279,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223340143495,
        "f": 83886081
      },
      "n": "SegmentWidth",
      "d": 1844103,
      "h": 154620666759,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154620666759),
//--TRIMMABLE-BOUNDARY-START(146030732167),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965961095,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206160274311,
        "f": 83886081
      },
      "n": "SegmentHeight",
      "d": 1844103,
      "h": 146030732167,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146030732167),
//--TRIMMABLE-BOUNDARY-START(150325699463),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555895687,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214750208903,
        "f": 83886081
      },
      "n": "SegmentSpace",
      "d": 1844103,
      "h": 150325699463,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150325699463),
//--TRIMMABLE-BOUNDARY-START(55836418951),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196157319,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180390470535,
        "f": 83886081
      },
      "n": "DecimalPoint",
      "d": 1844103,
      "h": 55836418951,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 6,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836418951),
//--TRIMMABLE-BOUNDARY-START(64426353543),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376026503,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197570339719,
        "f": 83886081
      },
      "n": "FloatingDecimal",
      "d": 1844103,
      "h": 64426353543,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 7,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64426353543),
//--TRIMMABLE-BOUNDARY-START(236225045383),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735764871,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231930078087,
        "f": 83886081
      },
      "n": "UseSegment",
      "d": 1844103,
      "h": 236225045383,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 8,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(236225045383),
//--TRIMMABLE-BOUNDARY-START(60131386247),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786091911,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188980405127,
        "f": 83886081
      },
      "n": "DisplayIsSegment",
      "d": 1844103,
      "h": 60131386247,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 9,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60131386247)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42951517063),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1844103,
      "h": 42951517063,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951517063)
  ],
  "h": 1844103
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceConfig`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixPriceConfig`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1844103)
        
        

        //--TRIMMABLE-BOUNDARY-START(2433927)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixPriceStatus`, ($self) => class SmartLEDMatrixPriceStatus extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(167506158471)
            /*SmartLEDMatrixPriceConfig?*/ Config = null;
            //--TRIMMABLE-BOUNDARY-END(167506158471)
            
            //--TRIMMABLE-BOUNDARY-START(171801125767)
            /*int*/ Display00 = 0;
            //--TRIMMABLE-BOUNDARY-END(171801125767)
            
            //--TRIMMABLE-BOUNDARY-START(176096093063)
            /*int*/ Display01 = 0;
            //--TRIMMABLE-BOUNDARY-END(176096093063)
            
            //--TRIMMABLE-BOUNDARY-START(180391060359)
            /*int*/ Display02 = 0;
            //--TRIMMABLE-BOUNDARY-END(180391060359)
            
            //--TRIMMABLE-BOUNDARY-START(184686027655)
            /*int*/ Display03 = 0;
            //--TRIMMABLE-BOUNDARY-END(184686027655)
            
            //--TRIMMABLE-BOUNDARY-START(188980994951)
            /*int*/ Display04 = 0;
            //--TRIMMABLE-BOUNDARY-END(188980994951)
            
            //--TRIMMABLE-BOUNDARY-START(193275962247)
            /*int*/ Display05 = 0;
            //--TRIMMABLE-BOUNDARY-END(193275962247)
            
            //--TRIMMABLE-BOUNDARY-START(197570929543)
            /*int*/ Display10 = 0;
            //--TRIMMABLE-BOUNDARY-END(197570929543)
            
            //--TRIMMABLE-BOUNDARY-START(201865896839)
            /*int*/ Display11 = 0;
            //--TRIMMABLE-BOUNDARY-END(201865896839)
            
            //--TRIMMABLE-BOUNDARY-START(206160864135)
            /*int*/ Display12 = 0;
            //--TRIMMABLE-BOUNDARY-END(206160864135)
            
            //--TRIMMABLE-BOUNDARY-START(210455831431)
            /*int*/ Display13 = 0;
            //--TRIMMABLE-BOUNDARY-END(210455831431)
            
            //--TRIMMABLE-BOUNDARY-START(214750798727)
            /*int*/ Display14 = 0;
            //--TRIMMABLE-BOUNDARY-END(214750798727)
            
            //--TRIMMABLE-BOUNDARY-START(219045766023)
            /*int*/ Display15 = 0;
            //--TRIMMABLE-BOUNDARY-END(219045766023)
            
            //--TRIMMABLE-BOUNDARY-START(223340733319)
            /*int*/ Display20 = 0;
            //--TRIMMABLE-BOUNDARY-END(223340733319)
            
            //--TRIMMABLE-BOUNDARY-START(227635700615)
            /*int*/ Display21 = 0;
            //--TRIMMABLE-BOUNDARY-END(227635700615)
            
            //--TRIMMABLE-BOUNDARY-START(231930667911)
            /*int*/ Display22 = 0;
            //--TRIMMABLE-BOUNDARY-END(231930667911)
            
            //--TRIMMABLE-BOUNDARY-START(236225635207)
            /*int*/ Display23 = 0;
            //--TRIMMABLE-BOUNDARY-END(236225635207)
            
            //--TRIMMABLE-BOUNDARY-START(240520602503)
            /*int*/ Display24 = 0;
            //--TRIMMABLE-BOUNDARY-END(240520602503)
            
            //--TRIMMABLE-BOUNDARY-START(244815569799)
            /*int*/ Display25 = 0;
            //--TRIMMABLE-BOUNDARY-END(244815569799)
            
            //--TRIMMABLE-BOUNDARY-START(249110537095)
            /*int*/ Display30 = 0;
            //--TRIMMABLE-BOUNDARY-END(249110537095)
            
            //--TRIMMABLE-BOUNDARY-START(253405504391)
            /*int*/ Display31 = 0;
            //--TRIMMABLE-BOUNDARY-END(253405504391)
            
            //--TRIMMABLE-BOUNDARY-START(257700471687)
            /*int*/ Display32 = 0;
            //--TRIMMABLE-BOUNDARY-END(257700471687)
            
            //--TRIMMABLE-BOUNDARY-START(261995438983)
            /*int*/ Display33 = 0;
            //--TRIMMABLE-BOUNDARY-END(261995438983)
            
            //--TRIMMABLE-BOUNDARY-START(266290406279)
            /*int*/ Display34 = 0;
            //--TRIMMABLE-BOUNDARY-END(266290406279)
            
            //--TRIMMABLE-BOUNDARY-START(270585373575)
            /*int*/ Display35 = 0;
            //--TRIMMABLE-BOUNDARY-END(270585373575)
            
            //--TRIMMABLE-BOUNDARY-START(274880340871)
            /*int*/ Display40 = 0;
            //--TRIMMABLE-BOUNDARY-END(274880340871)
            
            //--TRIMMABLE-BOUNDARY-START(279175308167)
            /*int*/ Display41 = 0;
            //--TRIMMABLE-BOUNDARY-END(279175308167)
            
            //--TRIMMABLE-BOUNDARY-START(283470275463)
            /*int*/ Display42 = 0;
            //--TRIMMABLE-BOUNDARY-END(283470275463)
            
            //--TRIMMABLE-BOUNDARY-START(287765242759)
            /*int*/ Display43 = 0;
            //--TRIMMABLE-BOUNDARY-END(287765242759)
            
            //--TRIMMABLE-BOUNDARY-START(292060210055)
            /*int*/ Display44 = 0;
            //--TRIMMABLE-BOUNDARY-END(292060210055)
            
            //--TRIMMABLE-BOUNDARY-START(296355177351)
            /*int*/ Display45 = 0;
            //--TRIMMABLE-BOUNDARY-END(296355177351)
            
            //--TRIMMABLE-BOUNDARY-START(300650144647)
            /*int*/ Display50 = 0;
            //--TRIMMABLE-BOUNDARY-END(300650144647)
            
            //--TRIMMABLE-BOUNDARY-START(304945111943)
            /*int*/ Display51 = 0;
            //--TRIMMABLE-BOUNDARY-END(304945111943)
            
            //--TRIMMABLE-BOUNDARY-START(309240079239)
            /*int*/ Display52 = 0;
            //--TRIMMABLE-BOUNDARY-END(309240079239)
            
            //--TRIMMABLE-BOUNDARY-START(313535046535)
            /*int*/ Display53 = 0;
            //--TRIMMABLE-BOUNDARY-END(313535046535)
            
            //--TRIMMABLE-BOUNDARY-START(317830013831)
            /*int*/ Display54 = 0;
            //--TRIMMABLE-BOUNDARY-END(317830013831)
            
            //--TRIMMABLE-BOUNDARY-START(322124981127)
            /*int*/ Display55 = 0;
            //--TRIMMABLE-BOUNDARY-END(322124981127)
            
            //--TRIMMABLE-BOUNDARY-START(326419948423)
            /*int[][] */ get Displays()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$$.S.Int32)), [$.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [this.Display00, this.Display01, this.Display02, this.Display03, this.Display04, this.Display05], [-1], null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [this.Display10, this.Display11, this.Display12, this.Display13, this.Display14, this.Display15], [-1], null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [this.Display20, this.Display21, this.Display22, this.Display23, this.Display24, this.Display25], [-1], null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [this.Display30, this.Display31, this.Display32, this.Display33, this.Display34, this.Display35], [-1], null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [this.Display40, this.Display41, this.Display42, this.Display43, this.Display44, this.Display45], [-1], null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [this.Display50, this.Display51, this.Display52, this.Display53, this.Display54, this.Display55], [-1], null)], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(326419948423)
            
            //--TRIMMABLE-BOUNDARY-START(798866350983)
            /*int */ get Scale0()
            {
                return $.$$.S.Int32.op_GreaterThanOrEqual((this.Config?.CharactersWidth ?? null), 0) ? $.$cast(Math.pow(10, $.$$.S.Math.Max$4(((this.Config.CharactersWidth - 1) | 0), 0)), $.$$.S.Int32) : 100000;
            }
            //--TRIMMABLE-BOUNDARY-END(798866350983)
            
            //--TRIMMABLE-BOUNDARY-START(803161318279)
            /*int */ get Scale1()
            {
                return $.$$.S.Int32.op_GreaterThanOrEqual((this.Config?.CharactersWidth ?? null), 1) ? $.$cast(Math.pow(10, $.$$.S.Math.Max$4(((this.Config.CharactersWidth - 2) | 0), 0)), $.$$.S.Int32) : 10000;
            }
            //--TRIMMABLE-BOUNDARY-END(803161318279)
            
            //--TRIMMABLE-BOUNDARY-START(807456285575)
            /*int */ get Scale2()
            {
                return $.$$.S.Int32.op_GreaterThanOrEqual((this.Config?.CharactersWidth ?? null), 2) ? $.$cast(Math.pow(10, $.$$.S.Math.Max$4(((this.Config.CharactersWidth - 3) | 0), 0)), $.$$.S.Int32) : 1000;
            }
            //--TRIMMABLE-BOUNDARY-END(807456285575)
            
            //--TRIMMABLE-BOUNDARY-START(811751252871)
            /*int */ get Scale3()
            {
                return $.$$.S.Int32.op_GreaterThanOrEqual((this.Config?.CharactersWidth ?? null), 3) ? $.$cast(Math.pow(10, $.$$.S.Math.Max$4(((this.Config.CharactersWidth - 4) | 0), 0)), $.$$.S.Int32) : 100;
            }
            //--TRIMMABLE-BOUNDARY-END(811751252871)
            
            //--TRIMMABLE-BOUNDARY-START(816046220167)
            /*int */ get Scale4()
            {
                return $.$$.S.Int32.op_GreaterThanOrEqual((this.Config?.CharactersWidth ?? null), 4) ? $.$cast(Math.pow(10, $.$$.S.Math.Max$4(((this.Config.CharactersWidth - 5) | 0), 0)), $.$$.S.Int32) : 10;
            }
            //--TRIMMABLE-BOUNDARY-END(816046220167)
            
            //--TRIMMABLE-BOUNDARY-START(820341187463)
            /*int */ get Scale5()
            {
                return $.$$.S.Int32.op_GreaterThanOrEqual((this.Config?.CharactersWidth ?? null), 5) ? $.$cast(Math.pow(10, $.$$.S.Math.Max$4(((this.Config.CharactersWidth - 6) | 0), 0)), $.$$.S.Int32) : 1;
            }
            //--TRIMMABLE-BOUNDARY-END(820341187463)
            
            //--TRIMMABLE-BOUNDARY-START(768801579911)
            /*int */ get Line0()
            {
                return ((((((((((((this.Scale0 * this.Display00) | 0) + ((this.Scale1 * this.Display01) | 0)) | 0) + ((this.Scale2 * this.Display02) | 0)) | 0) + ((this.Scale3 * this.Display03) | 0)) | 0) + ((this.Scale4 * this.Display04) | 0)) | 0) + ((this.Scale5 * this.Display05) | 0)) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(768801579911)
            
            //--TRIMMABLE-BOUNDARY-START(773096547207)
            /*int */ get Line1()
            {
                return ((((((((((((this.Scale0 * this.Display10) | 0) + ((this.Scale1 * this.Display11) | 0)) | 0) + ((this.Scale2 * this.Display12) | 0)) | 0) + ((this.Scale3 * this.Display13) | 0)) | 0) + ((this.Scale4 * this.Display14) | 0)) | 0) + ((this.Scale5 * this.Display15) | 0)) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(773096547207)
            
            //--TRIMMABLE-BOUNDARY-START(777391514503)
            /*int */ get Line2()
            {
                return ((((((((((((this.Scale0 * this.Display20) | 0) + ((this.Scale1 * this.Display21) | 0)) | 0) + ((this.Scale2 * this.Display22) | 0)) | 0) + ((this.Scale3 * this.Display23) | 0)) | 0) + ((this.Scale4 * this.Display25) | 0)) | 0) + ((this.Scale5 * this.Display25) | 0)) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(777391514503)
            
            //--TRIMMABLE-BOUNDARY-START(781686481799)
            /*int */ get Line3()
            {
                return ((((((((((((this.Scale0 * this.Display30) | 0) + ((this.Scale1 * this.Display31) | 0)) | 0) + ((this.Scale2 * this.Display32) | 0)) | 0) + ((this.Scale3 * this.Display33) | 0)) | 0) + ((this.Scale4 * this.Display35) | 0)) | 0) + ((this.Scale5 * this.Display35) | 0)) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(781686481799)
            
            //--TRIMMABLE-BOUNDARY-START(785981449095)
            /*int */ get Line4()
            {
                return ((((((((((((this.Scale0 * this.Display40) | 0) + ((this.Scale1 * this.Display41) | 0)) | 0) + ((this.Scale2 * this.Display42) | 0)) | 0) + ((this.Scale3 * this.Display43) | 0)) | 0) + ((this.Scale4 * this.Display45) | 0)) | 0) + ((this.Scale5 * this.Display45) | 0)) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(785981449095)
            
            //--TRIMMABLE-BOUNDARY-START(790276416391)
            /*int */ get Line5()
            {
                return ((((((((((((this.Scale0 * this.Display50) | 0) + ((this.Scale1 * this.Display51) | 0)) | 0) + ((this.Scale2 * this.Display52) | 0)) | 0) + ((this.Scale3 * this.Display53) | 0)) | 0) + ((this.Scale4 * this.Display55) | 0)) | 0) + ((this.Scale5 * this.Display55) | 0)) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(790276416391)
            
            //--TRIMMABLE-BOUNDARY-START(794571383687)
            /*int[] */ get Lines()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [this.Line0, this.Line1, this.Line2, this.Line3, this.Line4, this.Line5], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(794571383687)
            
            //--TRIMMABLE-BOUNDARY-START(163211191175)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211191175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(163211191175)
            
            //--TRIMMABLE-BOUNDARY-START(163211191175)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(163211191175)
            
            static $h = 2433927;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(167506158471),
    {
      "p": 1844103,
      "g": {
        "r": 0,
        "d": 0,
        "h": 335009883015,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 828931122055,
        "f": 83886081
      },
      "n": "Config",
      "d": 2433927,
      "h": 167506158471,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167506158471),
//--TRIMMABLE-BOUNDARY-START(171801125767),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 343599817607,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 837521056647,
        "f": 83886081
      },
      "n": "Display00",
      "d": 2433927,
      "h": 171801125767,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 20,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171801125767),
//--TRIMMABLE-BOUNDARY-START(176096093063),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 352189752199,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 846110991239,
        "f": 83886081
      },
      "n": "Display01",
      "d": 2433927,
      "h": 176096093063,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 21,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176096093063),
//--TRIMMABLE-BOUNDARY-START(180391060359),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 360779686791,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 854700925831,
        "f": 83886081
      },
      "n": "Display02",
      "d": 2433927,
      "h": 180391060359,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 22,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180391060359),
//--TRIMMABLE-BOUNDARY-START(184686027655),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 369369621383,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 863290860423,
        "f": 83886081
      },
      "n": "Display03",
      "d": 2433927,
      "h": 184686027655,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 23,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184686027655),
//--TRIMMABLE-BOUNDARY-START(188980994951),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 377959555975,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 871880795015,
        "f": 83886081
      },
      "n": "Display04",
      "d": 2433927,
      "h": 188980994951,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 24,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188980994951),
//--TRIMMABLE-BOUNDARY-START(193275962247),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 386549490567,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 880470729607,
        "f": 83886081
      },
      "n": "Display05",
      "d": 2433927,
      "h": 193275962247,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 25,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193275962247),
//--TRIMMABLE-BOUNDARY-START(197570929543),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 395139425159,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 889060664199,
        "f": 83886081
      },
      "n": "Display10",
      "d": 2433927,
      "h": 197570929543,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 30,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197570929543),
//--TRIMMABLE-BOUNDARY-START(201865896839),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 403729359751,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 897650598791,
        "f": 83886081
      },
      "n": "Display11",
      "d": 2433927,
      "h": 201865896839,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 31,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201865896839),
//--TRIMMABLE-BOUNDARY-START(206160864135),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 412319294343,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 906240533383,
        "f": 83886081
      },
      "n": "Display12",
      "d": 2433927,
      "h": 206160864135,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 32,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206160864135),
//--TRIMMABLE-BOUNDARY-START(210455831431),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 420909228935,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 914830467975,
        "f": 83886081
      },
      "n": "Display13",
      "d": 2433927,
      "h": 210455831431,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 33,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210455831431),
//--TRIMMABLE-BOUNDARY-START(214750798727),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 429499163527,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 923420402567,
        "f": 83886081
      },
      "n": "Display14",
      "d": 2433927,
      "h": 214750798727,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 34,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214750798727),
//--TRIMMABLE-BOUNDARY-START(219045766023),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 438089098119,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 932010337159,
        "f": 83886081
      },
      "n": "Display15",
      "d": 2433927,
      "h": 219045766023,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 35,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(219045766023),
//--TRIMMABLE-BOUNDARY-START(223340733319),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 446679032711,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 940600271751,
        "f": 83886081
      },
      "n": "Display20",
      "d": 2433927,
      "h": 223340733319,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 40,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(223340733319),
//--TRIMMABLE-BOUNDARY-START(227635700615),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 455268967303,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 949190206343,
        "f": 83886081
      },
      "n": "Display21",
      "d": 2433927,
      "h": 227635700615,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 41,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(227635700615),
//--TRIMMABLE-BOUNDARY-START(231930667911),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 463858901895,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 957780140935,
        "f": 83886081
      },
      "n": "Display22",
      "d": 2433927,
      "h": 231930667911,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 42,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(231930667911),
//--TRIMMABLE-BOUNDARY-START(236225635207),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 472448836487,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 966370075527,
        "f": 83886081
      },
      "n": "Display23",
      "d": 2433927,
      "h": 236225635207,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 43,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(236225635207),
//--TRIMMABLE-BOUNDARY-START(240520602503),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 481038771079,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 974960010119,
        "f": 83886081
      },
      "n": "Display24",
      "d": 2433927,
      "h": 240520602503,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 44,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(240520602503),
//--TRIMMABLE-BOUNDARY-START(244815569799),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 489628705671,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 983549944711,
        "f": 83886081
      },
      "n": "Display25",
      "d": 2433927,
      "h": 244815569799,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 45,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(244815569799),
//--TRIMMABLE-BOUNDARY-START(249110537095),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 498218640263,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 992139879303,
        "f": 83886081
      },
      "n": "Display30",
      "d": 2433927,
      "h": 249110537095,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 50,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(249110537095),
//--TRIMMABLE-BOUNDARY-START(253405504391),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 506808574855,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1000729813895,
        "f": 83886081
      },
      "n": "Display31",
      "d": 2433927,
      "h": 253405504391,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 51,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253405504391),
//--TRIMMABLE-BOUNDARY-START(257700471687),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 515398509447,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1009319748487,
        "f": 83886081
      },
      "n": "Display32",
      "d": 2433927,
      "h": 257700471687,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 52,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(257700471687),
//--TRIMMABLE-BOUNDARY-START(261995438983),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 523988444039,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1017909683079,
        "f": 83886081
      },
      "n": "Display33",
      "d": 2433927,
      "h": 261995438983,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 53,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(261995438983),
//--TRIMMABLE-BOUNDARY-START(266290406279),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 532578378631,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1026499617671,
        "f": 83886081
      },
      "n": "Display34",
      "d": 2433927,
      "h": 266290406279,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 54,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(266290406279),
//--TRIMMABLE-BOUNDARY-START(270585373575),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 541168313223,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1035089552263,
        "f": 83886081
      },
      "n": "Display35",
      "d": 2433927,
      "h": 270585373575,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 55,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(270585373575),
//--TRIMMABLE-BOUNDARY-START(274880340871),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 549758247815,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1043679486855,
        "f": 83886081
      },
      "n": "Display40",
      "d": 2433927,
      "h": 274880340871,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 60,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(274880340871),
//--TRIMMABLE-BOUNDARY-START(279175308167),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 558348182407,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1052269421447,
        "f": 83886081
      },
      "n": "Display41",
      "d": 2433927,
      "h": 279175308167,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 61,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(279175308167),
//--TRIMMABLE-BOUNDARY-START(283470275463),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 566938116999,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1060859356039,
        "f": 83886081
      },
      "n": "Display42",
      "d": 2433927,
      "h": 283470275463,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 62,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(283470275463),
//--TRIMMABLE-BOUNDARY-START(287765242759),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 575528051591,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1069449290631,
        "f": 83886081
      },
      "n": "Display43",
      "d": 2433927,
      "h": 287765242759,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 63,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(287765242759),
//--TRIMMABLE-BOUNDARY-START(292060210055),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 584117986183,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1078039225223,
        "f": 83886081
      },
      "n": "Display44",
      "d": 2433927,
      "h": 292060210055,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 64,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(292060210055),
//--TRIMMABLE-BOUNDARY-START(296355177351),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 592707920775,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1086629159815,
        "f": 83886081
      },
      "n": "Display45",
      "d": 2433927,
      "h": 296355177351,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 65,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(296355177351),
//--TRIMMABLE-BOUNDARY-START(300650144647),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 601297855367,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1095219094407,
        "f": 83886081
      },
      "n": "Display50",
      "d": 2433927,
      "h": 300650144647,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 70,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(300650144647),
//--TRIMMABLE-BOUNDARY-START(304945111943),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 609887789959,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1103809028999,
        "f": 83886081
      },
      "n": "Display51",
      "d": 2433927,
      "h": 304945111943,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 71,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(304945111943),
//--TRIMMABLE-BOUNDARY-START(309240079239),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 618477724551,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1112398963591,
        "f": 83886081
      },
      "n": "Display52",
      "d": 2433927,
      "h": 309240079239,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 72,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(309240079239),
//--TRIMMABLE-BOUNDARY-START(313535046535),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 627067659143,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1120988898183,
        "f": 83886081
      },
      "n": "Display53",
      "d": 2433927,
      "h": 313535046535,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 73,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(313535046535),
//--TRIMMABLE-BOUNDARY-START(317830013831),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 635657593735,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1129578832775,
        "f": 83886081
      },
      "n": "Display54",
      "d": 2433927,
      "h": 317830013831,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 74,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(317830013831),
//--TRIMMABLE-BOUNDARY-START(322124981127),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 644247528327,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1138168767367,
        "f": 83886081
      },
      "n": "Display55",
      "d": 2433927,
      "h": 322124981127,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 75,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(322124981127),
//--TRIMMABLE-BOUNDARY-START(326419948423),
    {
      "p": $.$typeArray($.$typeArray($.$$.S.Int32)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 652837462919,
        "f": 50331649
      },
      "n": "Displays",
      "d": 2433927,
      "h": 326419948423,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(326419948423),
//--TRIMMABLE-BOUNDARY-START(798866350983),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 721556939655,
        "f": 50331650
      },
      "n": "Scale0",
      "d": 2433927,
      "h": 798866350983,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(798866350983),
//--TRIMMABLE-BOUNDARY-START(803161318279),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 730146874247,
        "f": 50331650
      },
      "n": "Scale1",
      "d": 2433927,
      "h": 803161318279,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(803161318279),
//--TRIMMABLE-BOUNDARY-START(807456285575),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 738736808839,
        "f": 50331650
      },
      "n": "Scale2",
      "d": 2433927,
      "h": 807456285575,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(807456285575),
//--TRIMMABLE-BOUNDARY-START(811751252871),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 747326743431,
        "f": 50331650
      },
      "n": "Scale3",
      "d": 2433927,
      "h": 811751252871,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(811751252871),
//--TRIMMABLE-BOUNDARY-START(816046220167),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 755916678023,
        "f": 50331650
      },
      "n": "Scale4",
      "d": 2433927,
      "h": 816046220167,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(816046220167),
//--TRIMMABLE-BOUNDARY-START(820341187463),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 764506612615,
        "f": 50331650
      },
      "n": "Scale5",
      "d": 2433927,
      "h": 820341187463,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(820341187463),
//--TRIMMABLE-BOUNDARY-START(768801579911),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 661427397511,
        "f": 50331649
      },
      "n": "Line0",
      "d": 2433927,
      "h": 768801579911,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(768801579911),
//--TRIMMABLE-BOUNDARY-START(773096547207),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 670017332103,
        "f": 50331649
      },
      "n": "Line1",
      "d": 2433927,
      "h": 773096547207,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(773096547207),
//--TRIMMABLE-BOUNDARY-START(777391514503),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 678607266695,
        "f": 50331649
      },
      "n": "Line2",
      "d": 2433927,
      "h": 777391514503,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(777391514503),
//--TRIMMABLE-BOUNDARY-START(781686481799),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 687197201287,
        "f": 50331649
      },
      "n": "Line3",
      "d": 2433927,
      "h": 781686481799,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(781686481799),
//--TRIMMABLE-BOUNDARY-START(785981449095),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 695787135879,
        "f": 50331649
      },
      "n": "Line4",
      "d": 2433927,
      "h": 785981449095,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(785981449095),
//--TRIMMABLE-BOUNDARY-START(790276416391),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 704377070471,
        "f": 50331649
      },
      "n": "Line5",
      "d": 2433927,
      "h": 790276416391,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(790276416391),
//--TRIMMABLE-BOUNDARY-START(794571383687),
    {
      "p": $.$typeArray($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 712967005063,
        "f": 50331649
      },
      "n": "Lines",
      "d": 2433927,
      "h": 794571383687,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(794571383687)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(163211191175),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2433927,
      "h": 163211191175,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163211191175)
  ],
  "h": 2433927
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceStatus`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixPriceStatus`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2433927)
        
        

        //--TRIMMABLE-BOUNDARY-START(3416967)
        $asm.$cls(`$PkgL.LCIDL.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17183286151)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$PkgL.LCIDLV.PriceDisplay.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$PkgL.LCIDLV.PriceDisplay().$ctor$6();
                    }, $IOKbgl ??= {"r":2752627,"n":"","d":3416967,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17183286151)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4298384263)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298384263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298384263)
            
            //--TRIMMABLE-BOUNDARY-START(4298384263)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298384263)
            
            static $h = 3416967;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183286151),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888318855,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 3416967,
      "h": 17183286151,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17183286151)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298384263),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3416967,
      "h": 4298384263,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298384263)
  ],
  "h": 3416967
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3416967)
        
        

        //--TRIMMABLE-BOUNDARY-START(3679111)
        $asm.$cls(`$PkgL.LCIDL.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593613703)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593613703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$PkgL.LCIDL.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$PkgL.LCIDL.SmartLEDMatrixDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$PkgL.LCIDL.SmartLEDMatrixDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$PkgL.LCIDL.SmartLEDMatrixDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PkgL.LCIDL.SmartLEDMatrixDeviceFamily, x);
                }, $uKOeGe ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":3679111,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PkgL.LCIDL.SmartLEDMatrixDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$PkgL.LCIDL.SmartLEDMatrixDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $QICawj ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":3679111,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$PkgL.LCIDL.SmartLEDMatrixDevice)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PkgL.LCIDL.SmartLEDMatrixDeviceFamily, x);
                }, $jueRBc ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$PkgL.LCIDL.SmartLEDMatrixDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":3679111,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PkgL.LCIDL.SmartLEDMatrixDeviceFamily, x);
                }, $skrptf ??= {"r":$.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType).$h,"p":[{"n":"x","p":327718}],"n":"","d":3679111,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PkgL.LCIDL.SmartLEDMatrixDeviceFamily, x);
                }, $VXjgZj ??= {"r":$.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType).$h,"p":[{"n":"x","p":327718}],"n":"","d":3679111,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$PkgL.LCIDL.SmartLEDMatrixDevice), $.$PkgL.LCIDLP.SmartLEDMatrixDeviceCommands$$($.$PkgL.LCIDL.SmartLEDMatrixDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$PkgL.LCIDLV.SmartLEDMatrixClientAppViewModel, services);
                $.$sZVd.LCFCA.ClientApplicationExtension.AddApplication$1($.$PkgL.LCIDLV.PriceDisplay, services, "LEDPriceDisplay", "LED Price Display", "Controls LED price display board remotely"/*PriceDisplay.Description*/, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-led-on"/*MaterialDesignIconNames.LedOn*/), $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.ForegroundColor = "#FFF";
                    $i1.BackgroundColor = "#678480";
                    return $i1;
                })()), new ($.$$.S.Action$$($.$sZVd.LCFCA.ClientApplicationModel$$($.$PkgL.LCIDLV.PriceDisplay)))().$ctor(this,  (/*a*/ a) =>
                {
                    a.Categories = $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "IOT" ], null, null);
                    a.Paths = $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/LEDMatrix/PriceDisplay"/*PriceDisplay.Route*/ ], null, null);
                }, $qGSGbg ??= {"r":65537,"p":[{"n":"a","p":$.$sZVd.LCFCA.ClientApplicationModel$$($.$PkgL.LCIDLV.PriceDisplay).$h}],"n":"","d":3679111,"h":0,"f":17825794}));
                $.$PkgL.LCIDL.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$PkgL.LCIDL.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8593613703)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PkgL.LCIDL.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298646407)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298646407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298646407)
            
            //--TRIMMABLE-BOUNDARY-START(4298646407)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298646407)
            
            static $h = 3679111;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593613703),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3679111,
      "h": 8593613703,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593613703)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298646407),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3679111,
      "h": 4298646407,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298646407)
  ],
  "h": 3679111
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3679111)
        
        

        //--TRIMMABLE-BOUNDARY-START(5251975)
        $asm.$cls(`$PkgL.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4300219271)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300219271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300219271)
            
            //--TRIMMABLE-BOUNDARY-START(4300219271)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4300219271)
            
            static $h = 5251975;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300219271),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5251975,
      "h": 4300219271,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300219271)
  ],
  "h": 5251975
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5251975)
        
        

        //--TRIMMABLE-BOUNDARY-START(5317511)
        $asm.$cls(`$PkgL.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4300284807)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300284807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300284807)
            
            //--TRIMMABLE-BOUNDARY-START(4300284807)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4300284807)
            
            static $h = 5317511;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300284807),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5317511,
      "h": 4300284807,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300284807)
  ],
  "h": 5317511,
  "a": [
    {
      "t": 5251975,
      "c": 4300219271
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5317511)
        
        

        //--TRIMMABLE-BOUNDARY-START(1909639)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel`, ($self) => class SmartLEDMatrixPriceSetConfigControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(8591844231)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591844231);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591844231)
            
            //--TRIMMABLE-BOUNDARY-START(12886811527)
            $ctor$3(/*SmartLEDMatrixPriceConfig*/ config)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886811527);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Config = config;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886811527)
            
            //--TRIMMABLE-BOUNDARY-START(17181778823)
            /*int */ get Command()
            {
                return ((128 + 2) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(17181778823)
            
            //--TRIMMABLE-BOUNDARY-START(21476746119)
            /*SmartLEDMatrixPriceConfig*/ Config = null;
            //--TRIMMABLE-BOUNDARY-END(21476746119)
            
            //--TRIMMABLE-BOUNDARY-START(8591844231)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8591844231)
            
            static $h = 1909639;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181778823),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066680711,
        "f": 50364417
      },
      "n": "Command",
      "d": 1909639,
      "h": 17181778823,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17181778823),
//--TRIMMABLE-BOUNDARY-START(21476746119),
    {
      "p": 1844103,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656615303,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47246549895,
        "f": 83886082
      },
      "n": "Config",
      "d": 1909639,
      "h": 21476746119,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476746119)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591844231),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1909639,
      "h": 8591844231,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591844231),
//--TRIMMABLE-BOUNDARY-START(12886811527),
    {
      "p": [
        {
          "n": "config",
          "p": 1844103
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1909639,
      "h": 12886811527,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886811527)
  ],
  "h": 1909639
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetConfigControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixPriceSetConfigControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1909639)
        
        

        //--TRIMMABLE-BOUNDARY-START(2171783)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel`, ($self) => class SmartLEDMatrixPriceSetPriceControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(8592106375)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592106375);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592106375)
            
            //--TRIMMABLE-BOUNDARY-START(12887073671)
            $ctor$3(/*params int[]*/ prices)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887073671);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Prices = prices;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887073671)
            
            //--TRIMMABLE-BOUNDARY-START(17182040967)
            /*int */ get Command()
            {
                return ((128 + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(17182040967)
            
            //--TRIMMABLE-BOUNDARY-START(38656877447)
            /*int[]*/ Prices = null;
            //--TRIMMABLE-BOUNDARY-END(38656877447)
            
            //--TRIMMABLE-BOUNDARY-START(8592106375)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592106375)
            
            static $h = 2171783;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182040967),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771975559,
        "f": 50364417
      },
      "n": "Command",
      "d": 2171783,
      "h": 17182040967,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17182040967),
//--TRIMMABLE-BOUNDARY-START(38656877447),
    {
      "p": $.$typeArray($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361910151,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47246812039,
        "f": 83886082
      },
      "n": "Prices",
      "d": 2171783,
      "h": 38656877447,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656877447)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592106375),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2171783,
      "h": 8592106375,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592106375),
//--TRIMMABLE-BOUNDARY-START(12887073671),
    {
      "p": [
        {
          "n": "prices",
          "p": $.$typeArray($.$$.S.Int32).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2171783,
      "h": 12887073671,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887073671)
  ],
  "h": 2171783
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetPriceControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixPriceSetPriceControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2171783)
        
        

        //--TRIMMABLE-BOUNDARY-START(2564999)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel<>`, (TControl) => $asm.$gt(`$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel<>`, [TControl], ($self) => class SmartLEDMatrixRegionControlModel$$ extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(17182434183)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182434183);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182434183)
            
            //--TRIMMABLE-BOUNDARY-START(21477401479)
            $ctor$3(/*int*/ region, /*SmartLEDMatrixDisplayMode*/ mode, /*TControl*/ regionControl)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477401479);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Region = region;
                    this.Mode = mode;
                    this.RegionControl = regionControl;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477401479)
            
            //--TRIMMABLE-BOUNDARY-START(25772368775)
            /*int */ get Command()
            {
                return ((128 + 64) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(25772368775)
            
            //--TRIMMABLE-BOUNDARY-START(68722041735)
            /*int*/ Region = 0;
            //--TRIMMABLE-BOUNDARY-END(68722041735)
            
            //--TRIMMABLE-BOUNDARY-START(64427074439)
            /*SmartLEDMatrixDisplayMode*/ Mode = 0;
            //--TRIMMABLE-BOUNDARY-END(64427074439)
            
            //--TRIMMABLE-BOUNDARY-START(73017009031)
            /*TControl*/ RegionControl = $.$default(TControl);
            //--TRIMMABLE-BOUNDARY-END(73017009031)
            
            //--TRIMMABLE-BOUNDARY-START(17182434183)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17182434183)
            
            static $H = 2564999;
            static $h = 2564999;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772368775),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34362303367,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50364417
      },
      "n": "Command",
      "d": this.$h,
      "H": 25772368775,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25772368775),
//--TRIMMABLE-BOUNDARY-START(68722041735),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51542172551,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 90196878215,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 83886081
      },
      "n": "Region",
      "d": this.$h,
      "H": 68722041735,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1024,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68722041735),
//--TRIMMABLE-BOUNDARY-START(64427074439),
    {
      "p": 1450887,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42952237959,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 81606943623,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 83886081
      },
      "n": "Mode",
      "d": this.$h,
      "H": 64427074439,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1025,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64427074439),
//--TRIMMABLE-BOUNDARY-START(73017009031),
    {
      "p": TControl?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60132107143,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 98786812807,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 83886081
      },
      "n": "RegionControl",
      "d": this.$h,
      "H": 73017009031,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1025,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73017009031)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182434183),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 17182434183,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182434183),
//--TRIMMABLE-BOUNDARY-START(21477401479),
    {
      "p": [
        {
          "n": "region",
          "p": 655361
        },
        {
          "n": "mode",
          "p": 1450887
        },
        {
          "n": "regionControl",
          "p": TControl?.$h??1572864
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 21477401479,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477401479)
  ],
  "s": [
    {
      "h": TControl?.$h??1572864,
      "n": "TControl",
      "c": [16487825
      ]
    }
  ],
  "r": 1,
  "H": 2564999,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixRegionControlModel<${TControl?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixRegionControlModel$${TControl?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2564999)
        
        

        //--TRIMMABLE-BOUNDARY-START(3154823)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixStatusModel`, ($self) => class SmartLEDMatrixStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(107377337223)
            /*int*/ Width = 0;
            //--TRIMMABLE-BOUNDARY-END(107377337223)
            
            //--TRIMMABLE-BOUNDARY-START(64427664263)
            /*int*/ Height = 0;
            //--TRIMMABLE-BOUNDARY-END(64427664263)
            
            //--TRIMMABLE-BOUNDARY-START(25772958599)
            /*int*/ Brightness = 0;
            //--TRIMMABLE-BOUNDARY-END(25772958599)
            
            //--TRIMMABLE-BOUNDARY-START(68722631559)
            /*SmartLEDMatrixRegion[]?*/ Regions = null;
            //--TRIMMABLE-BOUNDARY-END(68722631559)
            
            //--TRIMMABLE-BOUNDARY-START(21477991303)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477991303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477991303)
            
            //--TRIMMABLE-BOUNDARY-START(21477991303)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21477991303)
            
            static $h = 3154823;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107377337223),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132696967,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103082369927,
        "f": 83886081
      },
      "n": "Width",
      "d": 3154823,
      "h": 107377337223,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 524289,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107377337223),
//--TRIMMABLE-BOUNDARY-START(64427664263),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952827783,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85902500743,
        "f": 83886081
      },
      "n": "Height",
      "d": 3154823,
      "h": 64427664263,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 524289,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64427664263),
//--TRIMMABLE-BOUNDARY-START(25772958599),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362893191,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77312566151,
        "f": 83886081
      },
      "n": "Brightness",
      "d": 3154823,
      "h": 25772958599,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25772958599),
//--TRIMMABLE-BOUNDARY-START(68722631559),
    {
      "p": $.$typeArray($.$PkgL.LCIDLM.SmartLEDMatrixRegion).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542762375,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94492435335,
        "f": 83886081
      },
      "n": "Regions",
      "d": 3154823,
      "h": 68722631559,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "Flags",
              "v": 65536,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68722631559)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477991303),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3154823,
      "h": 21477991303,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477991303)
  ],
  "h": 3154823
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3154823)
        
        

        //--TRIMMABLE-BOUNDARY-START(1581959)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixLogModel`, ($self) => class SmartLEDMatrixLogModel extends $.$XBGm.LCICDi.iSmartDeviceLogModel
        {
            //--TRIMMABLE-BOUNDARY-START(30066353031)
            /*string?*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(30066353031)
            
            //--TRIMMABLE-BOUNDARY-START(34361320327)
            /*bool */ get IsValid()
            {
                return this.Id !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(34361320327)
            
            //--TRIMMABLE-BOUNDARY-START(8591516551)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591516551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591516551)
            
            //--TRIMMABLE-BOUNDARY-START(8591516551)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8591516551)
            
            static $h = 1581959;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceLogModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066353031),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181451143,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42951254919,
        "f": 83886081
      },
      "n": "Id",
      "d": 1581959,
      "h": 30066353031,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 12,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066353031),
//--TRIMMABLE-BOUNDARY-START(34361320327),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771385735,
        "f": 50364417
      },
      "n": "IsValid",
      "d": 1581959,
      "h": 34361320327,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361320327)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591516551),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1581959,
      "h": 8591516551,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591516551)
  ],
  "h": 1581959
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceLog, $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixLogModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixLogModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1581959)
        
        

        //--TRIMMABLE-BOUNDARY-START(1450887)
        $asm.$str(`$PkgL.LCIDLM.SmartLEDMatrixDisplayMode`, ($self) => class SmartLEDMatrixDisplayMode extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static DISPLAY_BLANK = 0;
            static DISPLAY_SNAKE = 1;
            static DISPLAY_OPEN = 2;
            static DISPLAY_CLOSE = 3;
            static DISPLAY_STATIC = 4;
            static DISPLAY_SERIAL_STATIC = 5;
            static DISPLAY_PRICE = 6;
            static DISPLAY_MESSAGE = 7;
            static DISPLAY_DIGITAL_CLOCK = 8;
            static DISPLAY_ANALOG_CLOCK = 9;
            static DISPLAY_POV_ANALOG_CLOCK = 10;
            static DISPLAY_DATE = 11;
            static DISPLAY_TEMPERATURE = 12;
            static DISPLAY_STOPWATCH = 13;
            static DISPLAY_TIMER = 14;
            static DISPLAY_LOGO = 15;
            static DISPLAY_HYMN = 16;
            static DISPLAY_MODE_TYPE_COUNT = 17;
            static DISPLAY_DEFAULT_MODE = 18;
            static DISPLAY_ALL_CONTENT = 255;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1450887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "DISPLAY_BLANK": 0n,
                    "DISPLAY_SNAKE": 1n,
                    "DISPLAY_OPEN": 2n,
                    "DISPLAY_CLOSE": 3n,
                    "DISPLAY_STATIC": 4n,
                    "DISPLAY_SERIAL_STATIC": 5n,
                    "DISPLAY_PRICE": 6n,
                    "DISPLAY_MESSAGE": 7n,
                    "DISPLAY_DIGITAL_CLOCK": 8n,
                    "DISPLAY_ANALOG_CLOCK": 9n,
                    "DISPLAY_POV_ANALOG_CLOCK": 10n,
                    "DISPLAY_DATE": 11n,
                    "DISPLAY_TEMPERATURE": 12n,
                    "DISPLAY_STOPWATCH": 13n,
                    "DISPLAY_TIMER": 14n,
                    "DISPLAY_LOGO": 15n,
                    "DISPLAY_HYMN": 16n,
                    "DISPLAY_MODE_TYPE_COUNT": 17n,
                    "DISPLAY_DEFAULT_MODE": 18n,
                    "DISPLAY_ALL_CONTENT": 255n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296418183)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296418183);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296418183)
            
            //--TRIMMABLE-BOUNDARY-START(4296418183)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296418183)
            
            static $h = 1450887;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181320071),
    {
      "t": 1450887,
      "n": "DISPLAY_BLANK",
      "d": 1450887,
      "h": 17181320071,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181320071),
//--TRIMMABLE-BOUNDARY-START(73015894919),
    {
      "t": 1450887,
      "n": "DISPLAY_SNAKE",
      "d": 1450887,
      "h": 73015894919,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015894919),
//--TRIMMABLE-BOUNDARY-START(55836025735),
    {
      "t": 1450887,
      "n": "DISPLAY_OPEN",
      "d": 1450887,
      "h": 55836025735,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55836025735),
//--TRIMMABLE-BOUNDARY-START(21476287367),
    {
      "t": 1450887,
      "n": "DISPLAY_CLOSE",
      "d": 1450887,
      "h": 21476287367,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476287367),
//--TRIMMABLE-BOUNDARY-START(77310862215),
    {
      "t": 1450887,
      "n": "DISPLAY_STATIC",
      "d": 1450887,
      "h": 77310862215,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310862215),
//--TRIMMABLE-BOUNDARY-START(68720927623),
    {
      "t": 1450887,
      "n": "DISPLAY_SERIAL_STATIC",
      "d": 1450887,
      "h": 68720927623,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720927623),
//--TRIMMABLE-BOUNDARY-START(64425960327),
    {
      "t": 1450887,
      "n": "DISPLAY_PRICE",
      "d": 1450887,
      "h": 64425960327,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425960327),
//--TRIMMABLE-BOUNDARY-START(47246091143),
    {
      "t": 1450887,
      "n": "DISPLAY_MESSAGE",
      "d": 1450887,
      "h": 47246091143,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246091143),
//--TRIMMABLE-BOUNDARY-START(34361189255),
    {
      "t": 1450887,
      "n": "DISPLAY_DIGITAL_CLOCK",
      "d": 1450887,
      "h": 34361189255,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361189255),
//--TRIMMABLE-BOUNDARY-START(12886352775),
    {
      "t": 1450887,
      "n": "DISPLAY_ANALOG_CLOCK",
      "d": 1450887,
      "h": 12886352775,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886352775),
//--TRIMMABLE-BOUNDARY-START(60130993031),
    {
      "t": 1450887,
      "n": "DISPLAY_POV_ANALOG_CLOCK",
      "d": 1450887,
      "h": 60130993031,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130993031),
//--TRIMMABLE-BOUNDARY-START(25771254663),
    {
      "t": 1450887,
      "n": "DISPLAY_DATE",
      "d": 1450887,
      "h": 25771254663,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771254663),
//--TRIMMABLE-BOUNDARY-START(85900796807),
    {
      "t": 1450887,
      "n": "DISPLAY_TEMPERATURE",
      "d": 1450887,
      "h": 85900796807,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85900796807),
//--TRIMMABLE-BOUNDARY-START(81605829511),
    {
      "t": 1450887,
      "n": "DISPLAY_STOPWATCH",
      "d": 1450887,
      "h": 81605829511,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81605829511),
//--TRIMMABLE-BOUNDARY-START(90195764103),
    {
      "t": 1450887,
      "n": "DISPLAY_TIMER",
      "d": 1450887,
      "h": 90195764103,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90195764103),
//--TRIMMABLE-BOUNDARY-START(42951123847),
    {
      "t": 1450887,
      "n": "DISPLAY_LOGO",
      "d": 1450887,
      "h": 42951123847,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951123847),
//--TRIMMABLE-BOUNDARY-START(38656156551),
    {
      "t": 1450887,
      "n": "DISPLAY_HYMN",
      "d": 1450887,
      "h": 38656156551,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656156551),
//--TRIMMABLE-BOUNDARY-START(51541058439),
    {
      "t": 1450887,
      "n": "DISPLAY_MODE_TYPE_COUNT",
      "d": 1450887,
      "h": 51541058439,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541058439),
//--TRIMMABLE-BOUNDARY-START(30066221959),
    {
      "t": 1450887,
      "n": "DISPLAY_DEFAULT_MODE",
      "d": 1450887,
      "h": 30066221959,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066221959),
//--TRIMMABLE-BOUNDARY-START(8591385479),
    {
      "t": 1450887,
      "n": "DISPLAY_ALL_CONTENT",
      "d": 1450887,
      "h": 8591385479,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591385479)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296418183),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1450887,
      "h": 4296418183,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296418183)
  ],
  "h": 1450887
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDisplayMode`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDisplayMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1450887)
        
        

        //--TRIMMABLE-BOUNDARY-START(74631)
        $asm.$cls(`$PkgL.LCIDL._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590009223)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590009223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590009223)
            
            //--TRIMMABLE-BOUNDARY-START(4295041927)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295041927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295041927)
            
            //--TRIMMABLE-BOUNDARY-START(4295041927)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295041927)
            
            static $h = 74631;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590009223),
    {
      "r": 65537,
      "n": "Execute",
      "d": 74631,
      "h": 8590009223,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590009223)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295041927),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 74631,
      "h": 4295041927,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295041927)
  ],
  "h": 74631
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(74631)
        
        

        //--TRIMMABLE-BOUNDARY-START(1188743)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel`, ($self) => class SmartLEDMatrixDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceSendDataModel
        {
            //--TRIMMABLE-BOUNDARY-START(8591123335)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591123335);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591123335)
            
            //--TRIMMABLE-BOUNDARY-START(12886090631)
            $ctor$4(/*SmartLEDMatrixPriceSetPriceControlModel*/ on)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886090631);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.On = on;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886090631)
            
            //--TRIMMABLE-BOUNDARY-START(25770992519)
            /*SmartLEDMatrixPriceSetPriceControlModel?*/ On = null;
            //--TRIMMABLE-BOUNDARY-END(25770992519)
            
            //--TRIMMABLE-BOUNDARY-START(8591123335)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8591123335)
            
            static $h = 1188743;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceSendDataModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770992519),
    {
      "p": 2171783,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476025223,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360927111,
        "f": 83886081
      },
      "n": "On",
      "d": 1188743,
      "h": 25770992519,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 13432,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770992519)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591123335),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1188743,
      "h": 8591123335,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591123335),
//--TRIMMABLE-BOUNDARY-START(12886090631),
    {
      "p": [
        {
          "n": "on",
          "p": 2171783
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1188743,
      "h": 12886090631,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886090631)
  ],
  "h": 1188743
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1188743)
        
        

        //--TRIMMABLE-BOUNDARY-START(2040711)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModelTypeDescriptor`, ($self) => class SmartLEDMatrixPriceSetConfigControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297008007)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297008007);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModelTypeDescriptor.GenerateProperties($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel, this, factory);
                    }, $nzCxjb ??= {"r":65537,"n":"","d":2040711,"h":0,"f":17825794}), 0, "SmartLEDMatrixPriceSetConfigControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDMatrix\\Models_SmartLEDMatrixPriceSetConfigControlModel_LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetConfigControlModelTypeDescriptorBuilder.g.cs", "SmartLEDMatrixPriceSetConfigControlModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297008007)
            
            //--TRIMMABLE-BOUNDARY-START(12886942599)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886942599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Config"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel.$type, $.$discardRef(), "Config", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Config")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$PkgL.LCIDLM.SmartLEDMatrixPriceConfig, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Config";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetConfigControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$PkgL.LCIDLM.SmartLEDMatrixPriceConfig, ($.$cast(target, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel)).Config);
                        }, $fbDqbl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2040711,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Command";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetConfigControlModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel)).Command);
                        }, $fLfiMc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2040711,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886942599)
            
            //--TRIMMABLE-BOUNDARY-START(17181909895)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetConfigControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181909895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Config = _target.Config;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Config"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceConfig));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Config, ($v) => _Config = $v, $.$PkgL.LCIDLM.SmartLEDMatrixPriceConfig)))
                    {
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181909895)
            
            //--TRIMMABLE-BOUNDARY-START(8591975303)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetConfigControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591975303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel)))
                {
                    /*var*/ let result = $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591975303)
            
            static $h = 2040711;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886942599),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2040711,
      "h": 12886942599,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886942599),
//--TRIMMABLE-BOUNDARY-START(17181909895),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1909639,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2040711,
      "h": 17181909895,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181909895),
//--TRIMMABLE-BOUNDARY-START(8591975303),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1909639,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2040711,
      "h": 8591975303,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591975303)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297008007),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2040711,
      "h": 4297008007,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297008007)
  ],
  "h": 2040711
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetConfigControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixPriceSetConfigControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2040711)
        
        

        //--TRIMMABLE-BOUNDARY-START(2302855)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModelTypeDescriptor`, ($self) => class SmartLEDMatrixPriceSetPriceControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297270151)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297270151);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModelTypeDescriptor.GenerateProperties($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel, this, factory);
                    }, $iooBQb ??= {"r":65537,"n":"","d":2302855,"h":0,"f":17825794}), 0, "SmartLEDMatrixPriceSetPriceControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDMatrix\\Models_SmartLEDMatrixPriceSetPriceControlModel_LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetPriceControlModelTypeDescriptorBuilder.g.cs", "SmartLEDMatrixPriceSetPriceControlModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297270151)
            
            //--TRIMMABLE-BOUNDARY-START(12887204743)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887204743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Prices"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel.$type, $.$discardRef(), "Prices", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Prices")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.Int32), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Prices";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetPriceControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.Int32), ($.$cast(target, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel)).Prices);
                        }, $FWFHoa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2302855,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Command";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetPriceControlModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel)).Command);
                        }, $rMxoqa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2302855,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887204743)
            
            //--TRIMMABLE-BOUNDARY-START(17182172039)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetPriceControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182172039);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Prices = _target.Prices;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Prices"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.Int32)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.Int32), $.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.Int32), $.$$.S.Int32, property, $.$ref(() => _Prices, ($v) => _Prices = $v, $.$typeArray($.$$.S.Int32))))
                    {
                        if (_Prices !== null)
                        {
                            let $i8 = 0;
                            let $arr8 = _Prices;
                            while ($i8 < $arr8.length)
                            {
                                let item = $arr8[$i8++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.Int32)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.Int32), $.$$.S.Int32, property, $.$ref(() => _Prices, ($v) => _Prices = $v, $.$typeArray($.$$.S.Int32)));
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182172039)
            
            //--TRIMMABLE-BOUNDARY-START(8592237447)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetPriceControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592237447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel)))
                {
                    /*var*/ let result = $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592237447)
            
            static $h = 2302855;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887204743),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2302855,
      "h": 12887204743,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887204743),
//--TRIMMABLE-BOUNDARY-START(17182172039),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2171783,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2302855,
      "h": 17182172039,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182172039),
//--TRIMMABLE-BOUNDARY-START(8592237447),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2171783,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2302855,
      "h": 8592237447,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592237447)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297270151),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2302855,
      "h": 4297270151,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297270151)
  ],
  "h": 2302855
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixPriceSetPriceControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixPriceSetPriceControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2302855)
        
        

        //--TRIMMABLE-BOUNDARY-START(2761607)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelTypeDescriptor<>`, (TControl) => $asm.$gt(`$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelTypeDescriptor<>`, [TControl], ($self) => class SmartLEDMatrixRegionControlModelTypeDescriptor$$ extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl))
        {
            //--TRIMMABLE-BOUNDARY-START(4297728903)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297728903);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelTypeDescriptor$$(TControl).GenerateProperties($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl), this, factory);
                    }, $QVbkBj ??= {"r":65537,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), 0, "SmartLEDMatrixRegionControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDMatrix\\Models_SmartLEDMatrixRegionControlModel_LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixRegionControlModel_TControl_TypeDescriptorBuilder.g.cs", "SmartLEDMatrixRegionControlModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297728903)
            
            //--TRIMMABLE-BOUNDARY-START(12887663495)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887663495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Region"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl).$type, $.$discardRef(), "Region", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Region")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Region";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixRegionControlModel<TControl>";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelTypeDescriptor$$(TControl), /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl))).Region);
                        }, $HVGNtd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelTypeDescriptor$$(TControl), /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Region = value.AsInt();
                        }, $WKStqh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Mode"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl).$type, $.$discardRef(), "Mode", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Mode")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$PkgL.LCIDLM.SmartLEDMatrixDisplayMode, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Mode";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixRegionControlModel<TControl>";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelTypeDescriptor$$(TControl), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$PkgL.LCIDLM.SmartLEDMatrixDisplayMode, ($.$cast(target, $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl))).Mode);
                        }, $HFzaja ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelTypeDescriptor$$(TControl), /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Mode = value.AsEnumValue($.$PkgL.LCIDLM.SmartLEDMatrixDisplayMode);
                        }, $gqEDif ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("RegionControl"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl).$type, $.$discardRef(), "RegionControl", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("RegionControl")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From(TControl, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "RegionControl";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixRegionControlModel<TControl>";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelTypeDescriptor$$(TControl), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference(TControl, ($.$cast(target, $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl))).RegionControl);
                        }, $bnvJkj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelTypeDescriptor$$(TControl), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.RegionControl = value.AsReference(TControl);
                        }, $RdPwWf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl).$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Command";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixRegionControlModel<TControl>";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelTypeDescriptor$$(TControl), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl))).Command);
                        }, $iHSREi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887663495)
            
            //--TRIMMABLE-BOUNDARY-START(17182630791)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixRegionControlModel<TControl>*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182630791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Region = _target.Region;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Region"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Region, ($v) => _Region = $v, $.$$.S.Int32)))
                    {
                        _target.Region = _Region;
                    }
                }
                {
                    /*var*/ let _Mode = _target.Mode;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Mode"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixDisplayMode));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$PkgL.LCIDLM.SmartLEDMatrixDisplayMode, () => _Mode, ($v) => _Mode = $v, null, true)))
                    {
                        _target.Mode = _Mode;
                    }
                }
                {
                    /*var*/ let _RegionControl = _target.RegionControl;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("RegionControl"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$(TControl));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _RegionControl, ($v) => _RegionControl = $v, TControl)))
                    {
                        _target.RegionControl = _RegionControl;
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182630791)
            
            //--TRIMMABLE-BOUNDARY-START(8592696199)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixRegionControlModel<TControl>?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592696199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new ($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl))().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl), null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl))))
                {
                    /*var*/ let result = $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModelTypeDescriptor$$(TControl).VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl)));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl), null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl)));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592696199)
            
            static $H = 2761607;
            static $h = 2761607;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887663495),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": this.$h,
      "H": 12887663495,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887663495),
//--TRIMMABLE-BOUNDARY-START(17182630791),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl).$h,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": this.$h,
      "H": 17182630791,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182630791),
//--TRIMMABLE-BOUNDARY-START(8592696199),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl).$h,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": this.$h,
      "H": 8592696199,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592696199)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297728903),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4297728903,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297728903)
  ],
  "s": [
    {
      "h": TControl?.$h??1572864,
      "n": "TControl",
      "c": [16487825
      ]
    }
  ],
  "r": 1,
  "H": 2761607,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl)), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixRegionControlModelTypeDescriptor<${TControl?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixRegionControlModelTypeDescriptor$${TControl?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2761607)
        
        

        //--TRIMMABLE-BOUNDARY-START(3285895)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixStatusModelTypeDescriptor`, ($self) => class SmartLEDMatrixStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298253191)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298253191);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PkgL.LCIDLM.SmartLEDMatrixStatusModelTypeDescriptor.GenerateProperties($.$PkgL.LCIDLM.SmartLEDMatrixStatusModel, this, factory);
                    }, $zzfZNa ??= {"r":65537,"n":"","d":3285895,"h":0,"f":17825794}), 0, "SmartLEDMatrixStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDMatrix\\Models_SmartLEDMatrixStatusModel_LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixStatusModelTypeDescriptorBuilder.g.cs", "SmartLEDMatrixStatusModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298253191)
            
            //--TRIMMABLE-BOUNDARY-START(12888187783)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888187783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Width"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel.$type, $.$discardRef(), "Width", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Width")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Width";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel)).Width);
                        }, $EHZXlg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3285895,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Width = value.AsInt();
                        }, $ULfDai ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3285895,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Height"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel.$type, $.$discardRef(), "Height", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Height")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Height";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel)).Height);
                        }, $AtPQhf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3285895,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Height = value.AsInt();
                        }, $wcAshg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3285895,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Brightness"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel.$type, $.$discardRef(), "Brightness", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Brightness")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Brightness";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixStatusModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel)).Brightness);
                        }, $artLJe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3285895,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Brightness = value.AsInt();
                        }, $oKzHcf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3285895,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Regions"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel.$type, $.$discardRef(), "Regions", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Regions")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$PkgL.LCIDLM.SmartLEDMatrixRegion), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Regions";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixStatusModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$PkgL.LCIDLM.SmartLEDMatrixRegion), ($.$cast(target, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel)).Regions);
                        }, $PTalsg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3285895,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Regions = value.AsReference($.$typeArray($.$PkgL.LCIDLM.SmartLEDMatrixRegion));
                        }, $pybyzb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3285895,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888187783)
            
            //--TRIMMABLE-BOUNDARY-START(17183155079)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183155079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _Width = _target.Width;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Width"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Width, ($v) => _Width = $v, $.$$.S.Int32)))
                    {
                        _target.Width = _Width;
                    }
                }
                {
                    /*var*/ let _Height = _target.Height;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Height"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Height, ($v) => _Height = $v, $.$$.S.Int32)))
                    {
                        _target.Height = _Height;
                    }
                }
                {
                    /*var*/ let _Brightness = _target.Brightness;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Brightness"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Brightness, ($v) => _Brightness = $v, $.$$.S.Int32)))
                    {
                        _target.Brightness = _Brightness;
                    }
                }
                {
                    /*var*/ let _Regions = _target.Regions;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Regions"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$PkgL.LCIDLM.SmartLEDMatrixRegion)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$PkgL.LCIDLM.SmartLEDMatrixRegion), $.$PkgL.LCIDLM.SmartLEDMatrixRegion));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$PkgL.LCIDLM.SmartLEDMatrixRegion), $.$PkgL.LCIDLM.SmartLEDMatrixRegion, property, $.$ref(() => _Regions, ($v) => _Regions = $v, $.$typeArray($.$PkgL.LCIDLM.SmartLEDMatrixRegion))))
                    {
                        _target.Regions = _Regions;
                        if (_Regions !== null)
                        {
                            let $i15 = 0;
                            let $arr15 = _Regions;
                            while ($i15 < $arr15.length)
                            {
                                let item = $arr15[$i15++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$PkgL.LCIDLM.SmartLEDMatrixRegion)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$PkgL.LCIDLM.SmartLEDMatrixRegion), $.$PkgL.LCIDLM.SmartLEDMatrixRegion, property, $.$ref(() => _Regions, ($v) => _Regions = $v, $.$typeArray($.$PkgL.LCIDLM.SmartLEDMatrixRegion)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183155079)
            
            //--TRIMMABLE-BOUNDARY-START(8593220487)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593220487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel)))
                {
                    /*var*/ let result = $.$PkgL.LCIDLM.SmartLEDMatrixStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593220487)
            
            static $h = 3285895;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888187783),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3285895,
      "h": 12888187783,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888187783),
//--TRIMMABLE-BOUNDARY-START(17183155079),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3154823,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3285895,
      "h": 17183155079,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183155079),
//--TRIMMABLE-BOUNDARY-START(8593220487),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3154823,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3285895,
      "h": 8593220487,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593220487)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298253191),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3285895,
      "h": 4298253191,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298253191)
  ],
  "h": 3285895
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3285895)
        
        

        //--TRIMMABLE-BOUNDARY-START(1713031)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixLogModelTypeDescriptor`, ($self) => class SmartLEDMatrixLogModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296680327)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296680327);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PkgL.LCIDLM.SmartLEDMatrixLogModelTypeDescriptor.GenerateProperties($.$PkgL.LCIDLM.SmartLEDMatrixLogModel, this, factory);
                    }, $qTHJXh ??= {"r":65537,"n":"","d":1713031,"h":0,"f":17825794}), 0, "SmartLEDMatrixLogModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDMatrix\\Models_SmartLEDMatrixLogModel_LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixLogModelTypeDescriptorBuilder.g.cs", "SmartLEDMatrixLogModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296680327)
            
            //--TRIMMABLE-BOUNDARY-START(12886614919)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886614919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Id"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PkgL.LCIDLM.SmartLEDMatrixLogModel.$type, $.$discardRef(), "Id", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Id")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Id";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixLogModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$PkgL.LCIDLM.SmartLEDMatrixLogModel)).Id);
                        }, $emvGCd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1713031,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixLogModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Id = value.AsReference($.$$.S.String);
                        }, $jEUAFg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1713031,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsValid"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PkgL.LCIDLM.SmartLEDMatrixLogModel.$type, $.$discardRef(), "IsValid", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsValid")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "IsValid";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixLogModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$PkgL.LCIDLM.SmartLEDMatrixLogModel)).IsValid);
                        }, $lmecVb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1713031,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceLogModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886614919)
            
            //--TRIMMABLE-BOUNDARY-START(17181582215)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixLogModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181582215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceLogModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceLogModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceLogModel));
                {
                    /*var*/ let _Id = _target.Id;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Id"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Id, ($v) => _Id = $v, $.$$.S.String)))
                    {
                        _target.Id = _Id;
                    }
                }
                {
                    /*var*/ let _IsValid = _target.IsValid;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsValid"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsValid, ($v) => _IsValid = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181582215)
            
            //--TRIMMABLE-BOUNDARY-START(8591647623)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixLogModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591647623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PkgL.LCIDLM.SmartLEDMatrixLogModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixLogModel)))
                {
                    /*var*/ let result = $.$PkgL.LCIDLM.SmartLEDMatrixLogModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixLogModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixLogModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591647623)
            
            static $h = 1713031;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886614919),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1713031,
      "h": 12886614919,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886614919),
//--TRIMMABLE-BOUNDARY-START(17181582215),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1581959,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1713031,
      "h": 17181582215,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181582215),
//--TRIMMABLE-BOUNDARY-START(8591647623),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1581959,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1713031,
      "h": 8591647623,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591647623)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296680327),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1713031,
      "h": 4296680327,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296680327)
  ],
  "h": 1713031
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixLogModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixLogModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixLogModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1713031)
        
        

        //--TRIMMABLE-BOUNDARY-START(2499463)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixRegion`, ($self) => class SmartLEDMatrixRegion extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21477335943)
            /*SmartLEDMatrixPriceStatus?*/ Price = null;
            //--TRIMMABLE-BOUNDARY-END(21477335943)
            
            //--TRIMMABLE-BOUNDARY-START(8592434055)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592434055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592434055)
            
            //--TRIMMABLE-BOUNDARY-START(8592434055)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8592434055)
            
            static $h = 2499463;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477335943),
    {
      "p": 2433927,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182368647,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30067270535,
        "f": 83886081
      },
      "n": "Price",
      "d": 2499463,
      "h": 21477335943,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 6,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21477335943)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592434055),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2499463,
      "h": 8592434055,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592434055)
  ],
  "h": 2499463
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.Byte), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixRegion`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixRegion`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2499463)
        
        

        //--TRIMMABLE-BOUNDARY-START(3548039)
        $asm.$cls(`$PkgL.LCIDLP.SmartLEDMatrixDeviceCommands<>`, (TDevice) => $asm.$gt(`$PkgL.LCIDLP.SmartLEDMatrixDeviceCommands<>`, [TDevice], ($self) => class SmartLEDMatrixDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12888449927)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12888449927)
            
            //--TRIMMABLE-BOUNDARY-START(17183417223)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel?*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183417223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$PkgL.LCIDLP.SmartLEDMatrixDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17183417223)
            
            //--TRIMMABLE-BOUNDARY-START(8593482631)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593482631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593482631)
            
            //--TRIMMABLE-BOUNDARY-START(8593482631)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8593482631)
            
            //--TRIMMABLE-BOUNDARY-START(4298515335)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298515335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12888449927)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12888449927)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298515335)
            
            static $H = 3548039;
            static $h = 3548039;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183417223),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17183417223,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17183417223)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12888449927),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12888449927,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12888449927)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593482631),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8593482631,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593482631)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 3548039,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Protocol.SmartLEDMatrixDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Protocol${separator}SmartLEDMatrixDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3548039)
        
        

        //--TRIMMABLE-BOUNDARY-START(3613575)
        $asm.$cls(`$PkgL.LCIDLP.SmartLEDMatrixRegionControlCommand<>`, (TControl) => $asm.$gt(`$PkgL.LCIDLP.SmartLEDMatrixRegionControlCommand<>`, [TControl], ($self) => class SmartLEDMatrixRegionControlCommand$$ extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl))
        {
            //--TRIMMABLE-BOUNDARY-START(4298580871)
            $ctor$6()
            {
                super.$ctor$5("Control", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298580871);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298580871)
            
            //--TRIMMABLE-BOUNDARY-START(17183482759)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-controller"/*MaterialDesignIconNames.Controller*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17183482759)
            
            //--TRIMMABLE-BOUNDARY-START(4298580871)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4298580871)
            
            static $H = 3613575;
            static $h = 3613575;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$(TControl)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183482759),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "H": 12888515463,
        "h": Number(BigInt(this.$h)|0x300000000n),
        "f": 50364417
      },
      "n": "Icon",
      "d": this.$h,
      "H": 17183482759,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17183482759)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298580871),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": this.$h,
      "H": 4298580871,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298580871)
  ],
  "s": [
    {
      "h": TControl?.$h??1572864,
      "n": "TControl",
      "c": [16487825
      ]
    }
  ],
  "r": 1,
  "H": 3613575,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Protocol.SmartLEDMatrixRegionControlCommand<${TControl?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Protocol${separator}SmartLEDMatrixRegionControlCommand$${TControl?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3613575)
        
        

        //--TRIMMABLE-BOUNDARY-START(1319815)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModelTypeDescriptor`, ($self) => class SmartLEDMatrixDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296287111)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296287111);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModelTypeDescriptor.GenerateProperties($.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, this, factory);
                    }, $llEmHb ??= {"r":65537,"n":"","d":1319815,"h":0,"f":17825794}), 0, "SmartLEDMatrixDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDMatrix\\Models_SmartLEDMatrixDeviceSendDataModel_LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceSendDataModelTypeDescriptorBuilder.g.cs", "SmartLEDMatrixDeviceSendDataModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296287111)
            
            //--TRIMMABLE-BOUNDARY-START(12886221703)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886221703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("On"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel.$type, $.$discardRef(), "On", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("On")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "On";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceSendDataModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel, ($.$cast(target, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel)).On);
                        }, $ZsdBKe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1319815,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.On = value.AsReference($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel);
                        }, $HkcXIb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1319815,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886221703)
            
            //--TRIMMABLE-BOUNDARY-START(17181188999)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181188999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceSendDataModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceSendDataModel));
                {
                    /*var*/ let _On = _target.On;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("On"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _On, ($v) => _On = $v, $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel)))
                    {
                        _target.On = _On;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181188999)
            
            //--TRIMMABLE-BOUNDARY-START(8591254407)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591254407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591254407)
            
            static $h = 1319815;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886221703),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1319815,
      "h": 12886221703,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886221703),
//--TRIMMABLE-BOUNDARY-START(17181188999),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1188743,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1319815,
      "h": 17181188999,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181188999),
//--TRIMMABLE-BOUNDARY-START(8591254407),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1188743,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1319815,
      "h": 8591254407,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591254407)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296287111),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1319815,
      "h": 4296287111,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296287111)
  ],
  "h": 1319815
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1319815)
        
        

        //--TRIMMABLE-BOUNDARY-START(664455)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel`, ($self) => class SmartLEDMatrixDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$PkgL.LCIDLM.SmartLEDMatrixStatusModel, $.$PkgL.LCIDLM.SmartLEDMatrixLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8590599047)
            /*IOTDeviceSendDataModel? */ Ack()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590599047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Log !== null ? new $.$XBGm.LCICDi.iSmartDeviceAcknowledgeLogModel().$ctor$3(-1) : null;
            }
            //--TRIMMABLE-BOUNDARY-END(8590599047)
            
            //--TRIMMABLE-BOUNDARY-START(4295631751)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295631751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295631751)
            
            //--TRIMMABLE-BOUNDARY-START(4295631751)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295631751)
            
            static $h = 664455;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$PkgL.LCIDLM.SmartLEDMatrixStatusModel, $.$PkgL.LCIDLM.SmartLEDMatrixLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590599047),
    {
      "r": 39425425,
      "n": "Ack",
      "d": 664455,
      "h": 8590599047,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590599047)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295631751),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 664455,
      "h": 4295631751,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295631751)
  ],
  "h": 664455
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(664455)
        
        

        //--TRIMMABLE-BOUNDARY-START(795527)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModelTypeDescriptor`, ($self) => class SmartLEDMatrixDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295762823)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295762823);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, this, factory);
                    }, $fGVFfa ??= {"r":65537,"n":"","d":795527,"h":0,"f":17825794}), 0, "SmartLEDMatrixDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDMatrix\\Models_SmartLEDMatrixDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "SmartLEDMatrixDeviceReceivedDataModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295762823)
            
            //--TRIMMABLE-BOUNDARY-START(12885697415)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885697415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$PkgL.LCIDLM.SmartLEDMatrixStatusModel, $.$PkgL.LCIDLM.SmartLEDMatrixLogModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885697415)
            
            //--TRIMMABLE-BOUNDARY-START(17180664711)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180664711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixStatusModel, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixLogModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$PkgL.LCIDLM.SmartLEDMatrixStatusModel, $.$PkgL.LCIDLM.SmartLEDMatrixLogModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$PkgL.LCIDLM.SmartLEDMatrixStatusModel, $.$PkgL.LCIDLM.SmartLEDMatrixLogModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180664711)
            
            //--TRIMMABLE-BOUNDARY-START(8590730119)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590730119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590730119)
            
            static $h = 795527;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885697415),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 795527,
      "h": 12885697415,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885697415),
//--TRIMMABLE-BOUNDARY-START(17180664711),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 664455,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 795527,
      "h": 17180664711,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180664711),
//--TRIMMABLE-BOUNDARY-START(8590730119),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 664455,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 795527,
      "h": 8590730119,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590730119)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295762823),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 795527,
      "h": 4295762823,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295762823)
  ],
  "h": 795527
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(795527)
        
        

        //--TRIMMABLE-BOUNDARY-START(4465543)
        $asm.$cls(`$PkgL.LCIDL.SmartLEDMatrixDataConverter`, ($self) => class SmartLEDMatrixDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299432839)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299432839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299432839)
            
            //--TRIMMABLE-BOUNDARY-START(4299432839)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299432839)
            
            static $h = 4465543;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299432839),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4465543,
      "h": 4299432839,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299432839)
  ],
  "h": 4465543
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.SmartLEDMatrixDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}SmartLEDMatrixDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4465543)
        
        

        $asm.$typeProxy("$PkgL.LCIDLM.SmartLEDMatrixServiceModel", "$PkgL.LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixServiceModel");
        $asm.$typeProxy("$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel", "$PkgL.LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceScopeModel");
        $asm.$typeProxy("$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings", "$PkgL.LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceSettings");
        $asm.$typeProxy("$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings", "$PkgL.LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceHardwareSettings");
        $asm.$typeProxy("$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler", "$PkgL.LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixDeviceStatusHandler");
        $asm.$typeProxy("$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient", "$PkgL.LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixDeviceHubClient");
        $asm.$typeProxy("$PkgL.LCIDLS.ISmartLEDMatrixRemoteService", "$PkgL.LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixRemoteService");
        //--TRIMMABLE-BOUNDARY-START(402311)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDeviceModel`, ($self) => class SmartLEDMatrixDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295369607)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295369607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295369607)
            
            //--TRIMMABLE-BOUNDARY-START(4295369607)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295369607)
            
            static $h = 402311;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295369607),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 402311,
      "h": 4295369607,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295369607)
  ],
  "h": 402311
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(402311)
        
        

        //--TRIMMABLE-BOUNDARY-START(926599)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel`, ($self) => class SmartLEDMatrixDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295893895)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295893895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295893895)
            
            //--TRIMMABLE-BOUNDARY-START(4295893895)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295893895)
            
            static $h = 926599;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295893895),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 926599,
      "h": 4295893895,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295893895)
  ],
  "h": 926599
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(926599)
        
        

        //--TRIMMABLE-BOUNDARY-START(2892679)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixServiceModel`, ($self) => class SmartLEDMatrixServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297859975)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297859975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297859975)
            
            //--TRIMMABLE-BOUNDARY-START(4297859975)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4297859975)
            
            static $h = 2892679;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297859975),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 2892679,
      "h": 4297859975,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297859975)
  ],
  "h": 2892679
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2892679)
        
        

        //--TRIMMABLE-BOUNDARY-START(3744647)
        $asm.$cls(`$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient`, ($self) => class ISmartLEDMatrixDeviceHubClient
        {
            static $h = 3744647;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3744647
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Services${separator}ISmartLEDMatrixDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3744647)
        
        

        //--TRIMMABLE-BOUNDARY-START(4203399)
        $asm.$cls(`$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings`, ($self) => class SmartLEDMatrixDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $self, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4299170695)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299170695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299170695)
            
            //--TRIMMABLE-BOUNDARY-START(4299170695)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4299170695)
            
            static $h = 4203399;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299170695),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4203399,
      "h": 4299170695,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299170695)
  ],
  "h": 4203399
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Settings${separator}SmartLEDMatrixDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4203399)
        
        

        //--TRIMMABLE-BOUNDARY-START(3875719)
        $asm.$cls(`$PkgL.LCIDLS.ISmartLEDMatrixRemoteService`, ($self) => class ISmartLEDMatrixRemoteService
        {
            static $h = 3875719;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3875719
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Services${separator}ISmartLEDMatrixRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3875719)
        
        

        //--TRIMMABLE-BOUNDARY-START(3810183)
        $asm.$cls(`$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler`, ($self) => class ISmartLEDMatrixDeviceStatusHandler
        {
            static $h = 3810183;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3810183
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Services${separator}ISmartLEDMatrixDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3810183)
        
        

        //--TRIMMABLE-BOUNDARY-START(3941255)
        $asm.$cls(`$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings`, ($self) => class SmartLEDMatrixDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4298908551)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298908551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298908551)
            
            //--TRIMMABLE-BOUNDARY-START(4298908551)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298908551)
            
            static $h = 3941255;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298908551),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3941255,
      "h": 4298908551,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298908551)
  ],
  "h": 3941255
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Settings${separator}SmartLEDMatrixDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3941255)
        
        

        //--TRIMMABLE-BOUNDARY-START(4727687)
        $asm.$cls(`$PkgL.LCIDL.SmartLEDMatrixDeviceModelDefinition`, ($self) => class SmartLEDMatrixDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4299694983)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299694983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299694983)
            
            //--TRIMMABLE-BOUNDARY-START(4299694983)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299694983)
            
            static $h = 4727687;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299694983),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4727687,
      "h": 4299694983,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299694983)
  ],
  "h": 4727687
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.SmartLEDMatrixDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}SmartLEDMatrixDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4727687)
        
        

        //--TRIMMABLE-BOUNDARY-START(533383)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDeviceModelTypeDescriptor`, ($self) => class SmartLEDMatrixDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295500679)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295500679);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModelTypeDescriptor.GenerateProperties($.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, this, factory);
                    }, $RGLUgh ??= {"r":65537,"n":"","d":533383,"h":0,"f":17825794}), 0, "SmartLEDMatrixDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDMatrix\\Models_SmartLEDMatrixDeviceModel_LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceModelTypeDescriptorBuilder.g.cs", "SmartLEDMatrixDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295500679)
            
            //--TRIMMABLE-BOUNDARY-START(12885435271)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885435271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885435271)
            
            //--TRIMMABLE-BOUNDARY-START(17180402567)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180402567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceModel, LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceSettings, LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceSendDataModel, LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixDeviceStatusHandler, LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixDeviceHubClient, LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180402567)
            
            //--TRIMMABLE-BOUNDARY-START(8590467975)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590467975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel)))
                {
                    /*var*/ let result = $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590467975)
            
            static $h = 533383;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885435271),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 533383,
      "h": 12885435271,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885435271),
//--TRIMMABLE-BOUNDARY-START(17180402567),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 402311,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 533383,
      "h": 17180402567,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180402567),
//--TRIMMABLE-BOUNDARY-START(8590467975),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 402311,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 533383,
      "h": 8590467975,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590467975)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295500679),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 533383,
      "h": 4295500679,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295500679)
  ],
  "h": 533383
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(533383)
        
        

        //--TRIMMABLE-BOUNDARY-START(4334471)
        $asm.$cls(`$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettingsTypeDescriptor`, ($self) => class SmartLEDMatrixDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299301767)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299301767);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettingsTypeDescriptor.GenerateProperties($.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, this, factory);
                    }, $ElsKbc ??= {"r":65537,"n":"","d":4334471,"h":0,"f":17825794}), 0, "SmartLEDMatrixDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDMatrix\\Settings_SmartLEDMatrixDeviceSettings_LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceSettingsTypeDescriptorBuilder.g.cs", "SmartLEDMatrixDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299301767)
            
            //--TRIMMABLE-BOUNDARY-START(12889236359)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889236359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889236359)
            
            //--TRIMMABLE-BOUNDARY-START(17184203655)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184203655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceModel, LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceSettings, LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceSendDataModel, LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixDeviceStatusHandler, LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixDeviceHubClient, LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).iSmartDeviceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184203655)
            
            //--TRIMMABLE-BOUNDARY-START(8594269063)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594269063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings)))
                {
                    /*var*/ let result = $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594269063)
            
            static $h = 4334471;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889236359),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4334471,
      "h": 12889236359,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889236359),
//--TRIMMABLE-BOUNDARY-START(17184203655),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4203399,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4334471,
      "h": 17184203655,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184203655),
//--TRIMMABLE-BOUNDARY-START(8594269063),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4203399,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4334471,
      "h": 8594269063,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594269063)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299301767),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4334471,
      "h": 4299301767,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299301767)
  ],
  "h": 4334471
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Settings${separator}SmartLEDMatrixDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4334471)
        
        

        //--TRIMMABLE-BOUNDARY-START(1057671)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModelTypeDescriptor`, ($self) => class SmartLEDMatrixDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296024967)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296024967);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModelTypeDescriptor.GenerateProperties($.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, this, factory);
                    }, $SmHOAe ??= {"r":65537,"n":"","d":1057671,"h":0,"f":17825794}), 0, "SmartLEDMatrixDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDMatrix\\Models_SmartLEDMatrixDeviceScopeModel_LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceScopeModelTypeDescriptorBuilder.g.cs", "SmartLEDMatrixDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296024967)
            
            //--TRIMMABLE-BOUNDARY-START(12885959559)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885959559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885959559)
            
            //--TRIMMABLE-BOUNDARY-START(17180926855)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180926855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceModel, LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceSettings, LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceSendDataModel, LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixDeviceStatusHandler, LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixDeviceHubClient, LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180926855)
            
            //--TRIMMABLE-BOUNDARY-START(8590992263)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590992263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel)))
                {
                    /*var*/ let result = $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590992263)
            
            static $h = 1057671;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885959559),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1057671,
      "h": 12885959559,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885959559),
//--TRIMMABLE-BOUNDARY-START(17180926855),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 926599,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1057671,
      "h": 17180926855,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180926855),
//--TRIMMABLE-BOUNDARY-START(8590992263),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 926599,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1057671,
      "h": 8590992263,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590992263)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296024967),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1057671,
      "h": 4296024967,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296024967)
  ],
  "h": 1057671
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1057671)
        
        

        //--TRIMMABLE-BOUNDARY-START(3023751)
        $asm.$cls(`$PkgL.LCIDLM.SmartLEDMatrixServiceModelTypeDescriptor`, ($self) => class SmartLEDMatrixServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297991047)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297991047);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PkgL.LCIDLM.SmartLEDMatrixServiceModelTypeDescriptor.GenerateProperties($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, this, factory);
                    }, $cQwlef ??= {"r":65537,"n":"","d":3023751,"h":0,"f":17825794}), 0, "SmartLEDMatrixServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDMatrix\\Models_SmartLEDMatrixServiceModel_LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixServiceModelTypeDescriptorBuilder.g.cs", "SmartLEDMatrixServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297991047)
            
            //--TRIMMABLE-BOUNDARY-START(12887925639)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887925639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887925639)
            
            //--TRIMMABLE-BOUNDARY-START(17182892935)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182892935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceModel, LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceSettings, LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceSendDataModel, LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixDeviceStatusHandler, LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixDeviceHubClient, LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182892935)
            
            //--TRIMMABLE-BOUNDARY-START(8592958343)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592958343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel)))
                {
                    /*var*/ let result = $.$PkgL.LCIDLM.SmartLEDMatrixServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592958343)
            
            static $h = 3023751;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887925639),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3023751,
      "h": 12887925639,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887925639),
//--TRIMMABLE-BOUNDARY-START(17182892935),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2892679,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3023751,
      "h": 17182892935,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182892935),
//--TRIMMABLE-BOUNDARY-START(8592958343),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2892679,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3023751,
      "h": 8592958343,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592958343)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297991047),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3023751,
      "h": 4297991047,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297991047)
  ],
  "h": 3023751
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Models${separator}SmartLEDMatrixServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3023751)
        
        

        //--TRIMMABLE-BOUNDARY-START(4072327)
        $asm.$cls(`$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettingsTypeDescriptor`, ($self) => class SmartLEDMatrixDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299039623)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299039623);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, this, factory);
                    }, $oclEic ??= {"r":65537,"n":"","d":4072327,"h":0,"f":17825794}), 0, "SmartLEDMatrixDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDMatrix\\Settings_SmartLEDMatrixDeviceHardwareSettings_LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "SmartLEDMatrixDeviceHardwareSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299039623)
            
            //--TRIMMABLE-BOUNDARY-START(12888974215)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888974215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888974215)
            
            //--TRIMMABLE-BOUNDARY-START(17183941511)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183941511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceModel, LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceSettings, LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.LEDMatrix.Models.SmartLEDMatrixDeviceSendDataModel, LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixDeviceStatusHandler, LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixDeviceHubClient, LivingThing.Core.IOT.Devices.LEDMatrix.Services.ISmartLEDMatrixRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService).iSmartDeviceHardwareSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183941511)
            
            //--TRIMMABLE-BOUNDARY-START(8594006919)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594006919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594006919)
            
            static $h = 4072327;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888974215),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4072327,
      "h": 12888974215,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888974215),
//--TRIMMABLE-BOUNDARY-START(17183941511),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3941255,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4072327,
      "h": 17183941511,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183941511),
//--TRIMMABLE-BOUNDARY-START(8594006919),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3941255,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4072327,
      "h": 8594006919,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594006919)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299039623),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4072327,
      "h": 4299039623,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299039623)
  ],
  "h": 4072327
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Settings.SmartLEDMatrixDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Settings${separator}SmartLEDMatrixDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4072327)
        
        

        //--TRIMMABLE-BOUNDARY-START(4531079)
        $asm.$cls(`$PkgL.LCIDL.SmartLEDMatrixDevice`, ($self) => class SmartLEDMatrixDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4299498375)
            $ctor$2(/*IIOTDeviceFamily<SmartLEDMatrixDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*SmartLEDMatrixDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299498375);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299498375)
            
            //--TRIMMABLE-BOUNDARY-START(8594465671)
            /*Task */ SetPrice(/*int*/ price1, /*int*/ price2, /*int*/ price3, /*int*/ price4, /*int*/ price5, /*int*/ price6)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594465671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(8594465671)
            
            static $h = 4531079;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594465671),
    {
      "r": 178454529,
      "p": [
        {
          "n": "price1",
          "p": 655361
        },
        {
          "n": "price2",
          "p": 655361
        },
        {
          "n": "price3",
          "p": 655361
        },
        {
          "n": "price4",
          "p": 655361
        },
        {
          "n": "price5",
          "p": 655361
        },
        {
          "n": "price6",
          "p": 655361
        }
      ],
      "n": "SetPrice",
      "d": 4531079,
      "h": 8594465671,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594465671)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299498375),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$PkgL.LCIDL.SmartLEDMatrixDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 402311
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4531079,
      "h": 4299498375,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299498375)
  ],
  "h": 4531079
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.SmartLEDMatrixDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}SmartLEDMatrixDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4531079)
        
        

        //--TRIMMABLE-BOUNDARY-START(4596615)
        $asm.$cls(`$PkgL.LCIDL.SmartLEDMatrixDeviceDefinition`, ($self) => class SmartLEDMatrixDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299563911)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299563911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299563911)
            
            //--TRIMMABLE-BOUNDARY-START(4299563911)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299563911)
            
            static $h = 4596615;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$PkgL.LCIDLM.SmartLEDMatrixStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299563911),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4596615,
      "h": 4299563911,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299563911)
  ],
  "h": 4596615
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.SmartLEDMatrixDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}SmartLEDMatrixDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4596615)
        
        

        //--TRIMMABLE-BOUNDARY-START(4662151)
        $asm.$cls(`$PkgL.LCIDL.SmartLEDMatrixDeviceFamily`, ($self) => class SmartLEDMatrixDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4299629447)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<SmartLEDMatrixDeviceReceivedDataModel, SmartLEDMatrixDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<SmartLEDMatrixDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299629447);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299629447)
            
            //--TRIMMABLE-BOUNDARY-START(8594596743)
            /*Type */ get DeviceLogType()
            {
                return $.$PkgL.LCIDLM.SmartLEDMatrixLogModel.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8594596743)
            
            //--TRIMMABLE-BOUNDARY-START(12889564039)
            /*IIOTDeviceFamilyFeatures */ get Features()
            {
                return super.Features | 1/*IIOTDeviceFamilyFeatures.NoDatabase*/;
            }
            //--TRIMMABLE-BOUNDARY-END(12889564039)
            
            static $h = 4662151;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8594596743),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479498631,
        "f": 50364417
      },
      "n": "DeviceLogType",
      "d": 4662151,
      "h": 8594596743,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8594596743),
//--TRIMMABLE-BOUNDARY-START(12889564039),
    {
      "p": 26842513,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069433223,
        "f": 50364417
      },
      "n": "Features",
      "d": 4662151,
      "h": 12889564039,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12889564039)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299629447),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4662151,
      "h": 4299629447,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299629447)
  ],
  "h": 4662151
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$PkgL.LCIDL.SmartLEDMatrixDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.SmartLEDMatrixDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}SmartLEDMatrixDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4662151)
        
        

        $asm.$typeProxy("$PkgL.LCIDLV.SmartLEDMatrixClientAppViewModel", "$PkgL.LivingThing.Core.IOT.Devices.LEDMatrix.Views.SmartLEDMatrixClientAppViewModel");
        $asm.$typeProxy("$PkgL.LCIDLV.SmartLEDMatrixClientAppServiceViewModel", "$PkgL.LivingThing.Core.IOT.Devices.LEDMatrix.Views.SmartLEDMatrixClientAppServiceViewModel");
        $asm.$typeProxy("$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceScopeViewModel", "$PkgL.LivingThing.Core.IOT.Devices.LEDMatrix.Views.SmartLEDMatrixClientAppDeviceScopeViewModel");
        //--TRIMMABLE-BOUNDARY-START(5055367)
        $asm.$cls(`$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel`, ($self) => class SmartLEDMatrixClientAppDeviceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppServiceViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceScopeViewModel, $self, $.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4300022663)
            $ctor$7(/*SmartLEDMatrixClientAppServiceViewModel*/ service, /*SmartLEDMatrixDeviceModel*/ model, /*IEnumerable<SmartLEDMatrixClientAppDeviceScopeViewModel>*/ scopes)
            {
                super.$ctor$7(service, model, scopes);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300022663);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300022663)
            
            static $h = 5055367;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppServiceViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceScopeViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel, $.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300022663),
    {
      "p": [
        {
          "n": "service",
          "p": 5120903
        },
        {
          "n": "model",
          "p": 402311
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 5055367,
      "h": 4300022663,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300022663)
  ],
  "h": 5055367
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICV.IIOTDeviceViewModel$$$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTDeviceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Views.SmartLEDMatrixClientAppDeviceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Views${separator}SmartLEDMatrixClientAppDeviceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5055367)
        
        

        //--TRIMMABLE-BOUNDARY-START(5186439)
        $asm.$cls(`$PkgL.LCIDLV.SmartLEDMatrixClientAppViewModel`, ($self) => class SmartLEDMatrixClientAppViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($self, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppServiceViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceScopeViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel, $.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4300153735)
            $ctor$5(/*IOTRootViewModel*/ root, /*SmartLEDMatrixDeviceFamily*/ family, /*IHubConnector<ISmartLEDMatrixDeviceHubClient>*/ hubConnector)
            {
                super.$ctor$5(root, family, hubConnector);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300153735);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300153735)
            
            //--TRIMMABLE-BOUNDARY-START(8595121031)
            /*bool */ get Authorize()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(8595121031)
            
            //--TRIMMABLE-BOUNDARY-START(21480022919)
            /*SmartLEDMatrixClientAppServiceViewModel */ GetServiceViewModel(/*SmartLEDMatrixServiceModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21480022919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$PkgL.LCIDLV.SmartLEDMatrixClientAppServiceViewModel().$ctor$3(this, model);
            }
            //--TRIMMABLE-BOUNDARY-END(21480022919)
            
            //--TRIMMABLE-BOUNDARY-START(25774990215)
            /*ValueTask<IEnumerable<UserServiceSubscriptionModel<SmartLEDMatrixServiceModel>>> *//*async*/  LoadServices()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel))), $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel)), async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25774990215);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let services = ($t1 = this.LoadServicesFromJWT(null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, services);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25774990215)
            
            static $h = 5186439;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppServiceViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceScopeViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel, $.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8595121031),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17185055623,
        "f": 50364417
      },
      "n": "Authorize",
      "d": 5186439,
      "h": 8595121031,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8595121031)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21480022919),
    {
      "r": 5120903,
      "p": [
        {
          "n": "model",
          "p": 2892679
        }
      ],
      "n": "GetServiceViewModel",
      "d": 5186439,
      "h": 21480022919,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21480022919),
//--TRIMMABLE-BOUNDARY-START(25774990215),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel))).$h,
      "n": "LoadServices",
      "d": 5186439,
      "h": 25774990215,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(25774990215)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300153735),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "family",
          "p": 4662151
        },
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$($.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5186439,
      "h": 4300153735,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300153735)
  ],
  "h": 5186439
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$ntej.LCICV.IIOTAppViewModel$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel), $.$ntej.LCICV.IIOTApplicationViewModel, $.$vWqU.LCFCC.IServiceViewModel$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel), $.$vWqU.LCFCC.IServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$yleQ.LCFCA.IApplicationService, $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$vWqU.LCFCC.IServiceSubscriptionViewModel$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel), $.$vWqU.LCFCC.IServiceSubscriptionViewModel, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IClientRootService$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel), $.$vWqU.LCFCC.IClientRootService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Views.SmartLEDMatrixClientAppViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Views${separator}SmartLEDMatrixClientAppViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5186439)
        
        

        //--TRIMMABLE-BOUNDARY-START(4989831)
        $asm.$cls(`$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceScopeViewModel`, ($self) => class SmartLEDMatrixClientAppDeviceScopeViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppServiceViewModel, $self, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel, $.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4299957127)
            $ctor$3(/*SmartLEDMatrixClientAppServiceViewModel*/ service, /*SmartLEDMatrixDeviceScopeModel*/ model, /*IEnumerable<SmartLEDMatrixClientAppDeviceViewModel>*/ devices)
            {
                super.$ctor$3(service, model, devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299957127);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299957127)
            
            static $h = 4989831;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppServiceViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceScopeViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel, $.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299957127),
    {
      "p": [
        {
          "n": "service",
          "p": 5120903
        },
        {
          "n": "model",
          "p": 926599
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4989831,
      "h": 4299957127,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299957127)
  ],
  "h": 4989831
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$vWqU.LCFCC.IViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTDeviceScopeViewModel$$$($.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Views.SmartLEDMatrixClientAppDeviceScopeViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Views${separator}SmartLEDMatrixClientAppDeviceScopeViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4989831)
        
        

        //--TRIMMABLE-BOUNDARY-START(5120903)
        $asm.$cls(`$PkgL.LCIDLV.SmartLEDMatrixClientAppServiceViewModel`, ($self) => class SmartLEDMatrixClientAppServiceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppViewModel, $self, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceScopeViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel, $.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4300088199)
            $ctor$3(/*SmartLEDMatrixClientAppViewModel*/ app, /*SmartLEDMatrixServiceModel*/ model)
            {
                super.$ctor$3(app, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300088199);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300088199)
            
            //--TRIMMABLE-BOUNDARY-START(8595055495)
            /*SmartLEDMatrixClientAppDeviceScopeViewModel */ GetDeviceScopeViewModel(/*SmartLEDMatrixDeviceScopeModel*/ model, /*IEnumerable<SmartLEDMatrixClientAppDeviceViewModel>*/ devices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595055495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceScopeViewModel().$ctor$3(this, model, devices);
            }
            //--TRIMMABLE-BOUNDARY-END(8595055495)
            
            //--TRIMMABLE-BOUNDARY-START(12890022791)
            /*SmartLEDMatrixClientAppDeviceViewModel */ GetDeviceViewModel(/*SmartLEDMatrixDeviceModel*/ model, /*IEnumerable<SmartLEDMatrixClientAppDeviceScopeViewModel>*/ scopes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890022791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel().$ctor$7(this, model, scopes);
            }
            //--TRIMMABLE-BOUNDARY-END(12890022791)
            
            static $h = 5120903;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppServiceViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceScopeViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel, $.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595055495),
    {
      "r": 4989831,
      "p": [
        {
          "n": "model",
          "p": 926599
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel).$h
        }
      ],
      "n": "GetDeviceScopeViewModel",
      "d": 5120903,
      "h": 8595055495,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8595055495),
//--TRIMMABLE-BOUNDARY-START(12890022791),
    {
      "r": 5055367,
      "p": [
        {
          "n": "model",
          "p": 402311
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": "GetDeviceViewModel",
      "d": 5120903,
      "h": 12890022791,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12890022791)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300088199),
    {
      "p": [
        {
          "n": "app",
          "p": 5186439
        },
        {
          "n": "model",
          "p": 2892679
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5120903,
      "h": 4300088199,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300088199)
  ],
  "h": 5120903
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTApplicationServiceViewModel$$$$$$$$($.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceScopeViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTApplicationServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Views.SmartLEDMatrixClientAppServiceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Views${separator}SmartLEDMatrixClientAppServiceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5120903)
        
        

        //--TRIMMABLE-BOUNDARY-START(4924295)
        $asm.$cls(`$PkgL.LCIDLV.SmartLEDMatrixClientAppDefinition`, ($self) => class SmartLEDMatrixClientAppDefinition extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppServiceViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceScopeViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel, $.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299891591)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299891591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299891591)
            
            //--TRIMMABLE-BOUNDARY-START(4299891591)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299891591)
            
            static $h = 4924295;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppServiceViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceScopeViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel, $.$PkgL.LCIDL.SmartLEDMatrixDevice, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceModel, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceSettings, $.$PkgL.LCIDLS$1.SmartLEDMatrixDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceReceivedDataModel, $.$PkgL.LCIDLM.SmartLEDMatrixDeviceSendDataModel, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceStatusHandler, $.$PkgL.LCIDLS.ISmartLEDMatrixDeviceHubClient, $.$PkgL.LCIDLS.ISmartLEDMatrixRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299891591),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4924295,
      "h": 4299891591,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299891591)
  ],
  "h": 4924295
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Views.SmartLEDMatrixClientAppDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Views${separator}SmartLEDMatrixClientAppDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4924295)
        
        

        //--TRIMMABLE-BOUNDARY-START(4858759)
        $asm.$cls(`$PkgL.LCIDLV.PriceDisplay`, ($self) => class PriceDisplay extends $.$ntej.LCICS$2.JWTDashboard$$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppViewModel, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(47249499015)
            /*string */ get OptimizedComponentName()
            {
                return "pricedisplay jwtdashboard";
            }
            //--TRIMMABLE-BOUNDARY-END(47249499015)
            
            //--TRIMMABLE-BOUNDARY-START(51544466311)
            /*string*/ static Route = null;
            //--TRIMMABLE-BOUNDARY-END(51544466311)
            
            //--TRIMMABLE-BOUNDARY-START(17184727943)
            /*string*/ static Description = null;
            //--TRIMMABLE-BOUNDARY-END(17184727943)
            
            //--TRIMMABLE-BOUNDARY-START(21479695239)
            /*Task *//*async*/  EditPrice(/*SmartLEDMatrixClientAppDeviceViewModel*/ device)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21479695239);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let status = device.Received$1;
                    /*var*/ let price = (status?.Status?.Regions?.[0].Price ?? null);
                    /*var*/ let prices = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [(price?.Config?.CharactersHeight ?? null) ?? 3], null);
                    if (price !== null)
                    {
                        $.$$.S.Array.Copy$2(price.Lines, prices, $.$$.S.Math.Min$4(prices.length, price.Lines.length));
                    }
                    prices = $.$sl.SL.Enumerable.ToArray($.$$.S.Int32, (($t1 = $.$hDPm.LCFCI.ViewPresenterExtensions.Input($.$hDPm.LCFCI.ViewConfiguration, $.$$.SCG.IEnumerable$$($.$$.S.Int32), this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Edit Prices", false), null, prices, 0n, null, 0, 4, 4131, null, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)))));
                    ($t2 = $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishTo($.$PkgL.LCIDLP.SmartLEDMatrixRegionControlCommand$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel), $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel), new ($.$PkgL.LCIDLP.SmartLEDMatrixRegionControlCommand$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel))().$ctor$6(), device.RemoteClient, new ($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel))().$ctor$3(0, 6/*SmartLEDMatrixDisplayMode.DISPLAY_PRICE*/, new $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel().$ctor$3($.$sl.SL.Enumerable.ToArray($.$$.S.Int32, prices)))), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21479695239)
            
            //--TRIMMABLE-BOUNDARY-START(12889760647)
            /*Task *//*async*/  BultEditPrice()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12889760647);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let prices = $.$sl.SL.Enumerable.ToArray($.$$.S.Int32, (($t3 = $.$hDPm.LCFCI.ViewPresenterExtensions.Input($.$hDPm.LCFCI.ViewConfiguration, $.$$.SCG.IEnumerable$$($.$$.S.Int32), this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Edit Prices", false), null, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [6], null), 0n, null, 0, 4, 4131, null, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)))));
                    /*List<Task>*/ let tasks = new ($.$$.SCG.List$$($.$$.STT.Task))().$ctor$1();
                    let $en4 = $.$sl.SL.Enumerable.SelectMany$2($.$PkgL.LCIDLV.SmartLEDMatrixClientAppServiceViewModel, $.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel, this.ViewModel.Services, new ($.$$.S.Func$$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppServiceViewModel, $.$$.SCG.IEnumerable$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel)))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d.Devices;
                    }, $vQZuMc ??= {"r":$.$$.SCG.IEnumerable$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppDeviceViewModel).$h,"p":[{"n":"d","p":5120903}],"n":"","d":4858759,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let device = $en4.SCG$IEnumerator$$$Current;
                        {
                            tasks.Add($.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishTo($.$PkgL.LCIDLP.SmartLEDMatrixRegionControlCommand$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel), $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel), new ($.$PkgL.LCIDLP.SmartLEDMatrixRegionControlCommand$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel))().$ctor$6(), device.RemoteClient, new ($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel))().$ctor$3(0, 6/*SmartLEDMatrixDisplayMode.DISPLAY_PRICE*/, new $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetPriceControlModel().$ctor$3($.$sl.SL.Enumerable.ToArray($.$$.S.Int32, prices)))));
                        }
                    }
                    ($t5 = $.$$.STT.Task.WhenAll(tasks), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12889760647)
            
            //--TRIMMABLE-BOUNDARY-START(25774662535)
            /*Task *//*async*/  EditSettings(/*SmartLEDMatrixClientAppDeviceViewModel*/ device)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25774662535);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let status = device.Received$1;
                    /*var*/ let config = ($t6 = $.$hDPm.LCFCI.ViewPresenterExtensions.Form($.$hDPm.LCFCI.ViewConfiguration, $.$PkgL.LCIDLM.SmartLEDMatrixPriceConfig, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Settings", false), null, (status?.Status?.Regions?.[0]?.Price?.Config ?? null), null, null, 0, 4131, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    ($t7 = $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishTo($.$PkgL.LCIDLP.SmartLEDMatrixRegionControlCommand$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel), $.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel), new ($.$PkgL.LCIDLP.SmartLEDMatrixRegionControlCommand$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel))().$ctor$6(), device.RemoteClient, new ($.$PkgL.LCIDLM.SmartLEDMatrixRegionControlModel$$($.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel))().$ctor$3(0, 6/*SmartLEDMatrixDisplayMode.DISPLAY_PRICE*/, new $.$PkgL.LCIDLM.SmartLEDMatrixPriceSetConfigControlModel().$ctor$3(config))), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25774662535)
            
            //--TRIMMABLE-BOUNDARY-START(8594793351)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594793351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this, super.BuildRenderTree);
                __builder.AddContent$1(0, view);
            }
            //--TRIMMABLE-BOUNDARY-END(8594793351)
            
            //--TRIMMABLE-BOUNDARY-START(55839433607)
            /*RenderFragment */ get View()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                {
                    __builder2.OpenElement(1, "div");
                    __builder2.AddAttribute$5(2, "class", "hv-10 stack");
                    __builder2.OpenElement(3, "div");
                    __builder2.AddAttribute$5(4, "class", "pd bg-card flex");
                    __builder2.OpenElement(5, "h2");
                    __builder2.AddAttribute$5(6, "class", "mgy-a fill");
                    __builder2.AddContent$4(7, this.ViewModel.SelectedServiceViewModel.Model.Title);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(8, "\r\n            ");
                    __builder2.OpenElement(9, "button");
                    __builder2.AddAttribute$5(10, "class", "mgy-a bg-primary pdy-2 pdx-4 corner");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 11, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.BultEditPrice)));
                    __builder2.AddContent$4(12, "Bulk Price Update");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(13, "\r\n            ");
                    __builder2.OpenElement(14, "button");
                    __builder2.AddAttribute$5(15, "class", "mgy-a bg-error mgl pdy-2 pdx-4 corner");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 16, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Reset)));
                    __builder2.AddContent$4(17, "Reset");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(18, "\r\n        ");
                    __builder2.OpenElement(19, "div");
                    __builder2.AddAttribute$5(20, "class", "grid gap-2 colm-3 pd scroll-y");
                    let $en8 = this.ViewModel.SelectedServiceViewModel.Devices.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let device = $en8.SCG$IEnumerator$$$Current;
                        {
                            __builder2.OpenElement(21, "div");
                            __builder2.AddAttribute$5(22, "class", "bg-card bd");
                            __builder2.OpenElement(23, "div");
                            __builder2.AddAttribute$5(24, "class", "bdb pd flex");
                            __builder2.OpenElement(25, "div");
                            __builder2.AddAttribute$5(26, "class", "stack fill");
                            __builder2.OpenElement(27, "h3");
                            __builder2.AddAttribute$5(28, "class", "mg-0");
                            __builder2.AddContent$4(29, device.Model$1.Name);
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(30, "\r\n                        ");
                            __builder2.OpenElement(31, "small");
                            __builder2.AddAttribute$5(32, "class", "op-8");
                            __builder2.AddContent$4(33, device.Model$1.UniqueId);
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(34, "\r\n                    ");
                            __builder2.OpenElement(35, "button");
                            __builder2.AddAttribute$5(36, "class", "mdi mdi-menu mgy-a mgl bg-transparent");
                            __builder2.AddAttribute$5(37, "title", "Set Price");
                            __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 38, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                            {
                                return this.EditPrice(device);
                            }, $pTveRf ??= {"r":178454529,"n":"","d":4858759,"h":0,"f":17825794})));
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(39, "\r\n                    ");
                            __builder2.OpenElement(40, "button");
                            __builder2.AddAttribute$5(41, "class", "mdi mdi-cogs mgy-a mgl bg-transparent");
                            __builder2.AddAttribute$5(42, "title", "Configure");
                            __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 43, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                            {
                                return this.EditSettings(device);
                            }, $sPpKah ??= {"r":178454529,"n":"","d":4858759,"h":0,"f":17825794})));
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(44, "\r\n                ");
                            __builder2.OpenElement(45, "div");
                            __builder2.AddAttribute$5(46, "class", "pd stack");
                            /*var*/ let price = (device.Received$1?.Status?.Regions?.[0]?.Price ?? null);
                            if ((price?.Config ?? null) !== null)
                            {
                                /*var*/ let displays = price.Displays;
                                for(/*int*/ let y = 0; y < price.Config.CharactersHeight; y++)
                                {
                                    __builder2.OpenElement(47, "div");
                                    __builder2.AddAttribute$5(48, "class", "flex");
                                    for(/*int*/ let x = 0; x < price.Config.CharactersWidth; x++)
                                    {
                                        if (!price.Config.FloatingDecimal && x === ((price.Config.CharactersWidth - price.Config.DecimalPoint) | 0))
                                        {
                                            __builder2.AddMarkupContent(49, "<div class=\"flex mgy-a\"><span class=\"fsz-50 cl-error mgy-a\">:</span></div>");
                                        }
                                        if (price.Config.FloatingDecimal && x === ((price.Config.CharactersWidth - price.Config.DecimalPoint) | 0))
                                        {
                                            __builder2.OpenComponent$1($.$hDPm.LCFCCG.SevenSegment, 50);
                                            __builder2.AddComponentParameter(51, "Height", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, null));
                                            __builder2.AddComponentParameter(52, "Width", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, null));
                                            __builder2.AddComponentParameter(53, "Class", "mgb-a");
                                            __builder2.AddComponentParameter(54, "Number", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, $.$$.System.Array.$ReadT1.call($.$$.System.Array.$ReadT1.call(displays, y), x)), $.$$.S.Int32));
                                            __builder2.CloseComponent();
                                        }
                                        else 
                                        {
                                            __builder2.OpenComponent$1($.$hDPm.LCFCCG.SevenSegment, 55);
                                            __builder2.AddComponentParameter(56, "Height", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, null));
                                            __builder2.AddComponentParameter(57, "Width", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, null));
                                            __builder2.AddComponentParameter(58, "Class", "mgy-a");
                                            __builder2.AddComponentParameter(59, "Number", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, $.$$.System.Array.$ReadT1.call($.$$.System.Array.$ReadT1.call(displays, y), x)), $.$$.S.Int32));
                                            __builder2.CloseComponent();
                                        }
                                    }
                                    __builder2.CloseElement();
                                }
                            }
                            else 
                            {
                                __builder2.OpenElement(60, "img");
                                __builder2.AddAttribute$5(61, "src", this.ResolvePath("img/iot.png", true, false, false));
                                __builder2.AddAttribute$5(62, "class", "mawx-25 mg-a");
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(63, "\r\n                    ");
                                __builder2.AddMarkupContent(64, "<p class=\"text-center\">Waiting for connection from node...</p>");
                            }
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }
                    }
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                }, $jYqfZb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":4858759,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(55839433607)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4299826055)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299826055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299826055)
            
            //--TRIMMABLE-BOUNDARY-START(4299826055)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4299826055)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(51544466311)
                    this.Route = "/LEDMatrix/PriceDisplay";
                    //--TRIMMABLE-BOUNDARY-END(51544466311)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17184727943)
                    this.Description = "Controls LED price display board remotely";
                    //--TRIMMABLE-BOUNDARY-END(17184727943)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 4858759;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICS$2.JWTDashboard$$$($.$PkgL.LCIDLV.SmartLEDMatrixClientAppViewModel, $.$PkgL.LCIDLM.SmartLEDMatrixServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47249499015),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34364597127,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 4858759,
      "h": 47249499015,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47249499015),
//--TRIMMABLE-BOUNDARY-START(55839433607),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42954531719,
        "f": 50364420
      },
      "n": "View",
      "d": 4858759,
      "h": 55839433607,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(55839433607)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21479695239),
    {
      "r": 178454529,
      "p": [
        {
          "n": "device",
          "p": 5055367
        }
      ],
      "n": "EditPrice",
      "d": 4858759,
      "h": 21479695239,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(21479695239),
//--TRIMMABLE-BOUNDARY-START(12889760647),
    {
      "r": 178454529,
      "n": "BultEditPrice",
      "d": 4858759,
      "h": 12889760647,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(12889760647),
//--TRIMMABLE-BOUNDARY-START(25774662535),
    {
      "r": 178454529,
      "p": [
        {
          "n": "device",
          "p": 5055367
        }
      ],
      "n": "EditSettings",
      "d": 4858759,
      "h": 25774662535,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(25774662535),
//--TRIMMABLE-BOUNDARY-START(8594793351),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 4858759,
      "h": 8594793351,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8594793351)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51544466311),
    {
      "t": 1310721,
      "n": "Route",
      "d": 4858759,
      "h": 51544466311,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51544466311),
//--TRIMMABLE-BOUNDARY-START(17184727943),
    {
      "t": 1310721,
      "n": "Description",
      "d": 4858759,
      "h": 17184727943,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17184727943)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299826055),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 4858759,
      "h": 4299826055,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299826055)
  ],
  "h": 4858759,
  "a": [
    {
      "t": 30640470,
      "c": 25800444246,
      "n": [
        {
          "n": "OpenGraphTitle",
          "v": "LED Price Display Control",
          "t": 1310721
        },
        {
          "n": "OpenGraphDescription",
          "v": "Controls LED price display board remotely",
          "t": 1310721
        },
        {
          "n": "OpenGraphPath",
          "v": "/LEDMatrix/PriceDisplay",
          "t": 1310721
        },
        {
          "n": "OpenGraphImage",
          "v": "_content/LivingThing.Core.IOT.Devices.LEDMatrix/img/pricedisplay.png",
          "t": 1310721
        },
        {
          "n": "OpenGraphType",
          "v": 2,
          "t": 30902614
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/LEDMatrix/PriceDisplay",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.Views.PriceDisplay`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}Views${separator}PriceDisplay`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4858759)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(9095)
