
//--TRIMMABLE-BOUNDARY-START(32444)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $dmoKEd;
    let $EyNEWd;
    let $pkoAid;
    let $Zbvtxg;
    let $RZnrel;
    let $oYvPtf;
    let $PwyZsj;
    let $IMlipe;
    let $XkXcbe;
    let $okHmpg;
    let $FAqQda;
    let $WYOzmi;
    let $CDWeOg;
    let $OXSOia;
    let $sEwsra;
    let $kvqLVj;
    let $kxnqOf;
    let $CAuJcl;
    let $GpOqcg;
    let $bstRlb;
    let $TrnKya;
    let $TWqzzf;
    let $sXBSWa;
    let $MtjWYb;
    let $wRDyTd;
    let $djOuFc;
    let $aVgMki;
    let $RoKlZa;
    let $ozzAuf;
    let $bRIECk;
    let $XTsiqh;
    let $itmXla;
    let $hlkyGb;
    let $sVpWWd;
    let $gloBBf;
    let $toXNze;
    let $Gruozj;
    let $KOeLCf;
    let $mSLtHi;
    let $AJUERi;
    let $lIsRyc;
    let $QqzZdl;
    let $eshfoh;
    let $JUqUlk;
    let $MyEcXc;
    let $RjQqui;
    let $QpmaEj;
    let $EMiadb;
    let $UoJxLj;
    let $RfTeDj;
    let $eIBOOf;
    let $PnHgGe;
    let $MWnYnc;
    let $houIBf;
    let $EUxhOk;
    let $IcRJMj;
    let $PBSfej;
    let $EbpTXc;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.LEDStrip", 
    {
  "h": 32444,
  "f": "LivingThing.Core.IOT.Devices.LEDStrip",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.LEDStrip",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.LEDStrip",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5MRURTdHJpcC5MRURTdHJpcERldmljZSI6IHsNCiAgICAgICJDYXRlZ29yaWVzIjogWyAiU21hcnQgSG9tZSIgXSwNCiAgICAgICJOYW1lIjogIkxFRFN0cmlwIiwNCiAgICAgICJEZXNjcmlwdGlvbiI6ICJCZWF1dGlmeSB5b3VyIGhvbWUgYW5kIHNjZW5lcyB3aXRoIG11bHRpY29sb3IgUkdCIExFRC4iLA0KICAgICAgIkJhbm5lckltYWdlIjogIn4vTEVEU3RyaXAvaW1nL2Jhbm5lci5qcGciLA0KICAgICAgIkljb24iOiB7ICJOYW1lIjogIm1kaSBtZGktbGVkLXN0cmlwIiB9LA0KICAgICAgIlRoZW1lQ29sb3IiOiAiIzZhYmUzMCIsDQogICAgICAiU2VjdXJpdGllcyI6ICJDaGFsbGVuZ2VIYW5kU2hha2VBdXRoZW50aWNhdGlvblByb3RvY29sLEFkdmFuY2VkRW5jcnlwdGlvblN0YW5kYXJkLEVsbGlwdGljQ3VydmVGaXJtd2FyZVVwZGF0ZVNpZ25pbmciLA0KICAgICAgIlN0YXR1c2VzIjogW10sDQogICAgICAiUHJvdG9jb2xOYW1lIjogIkJpbmFyeVBhY2tldCIsDQogICAgICAiQ2xpY2tDb21tYW5kIjogeyAiTmFtZSI6ICJCbGFuayIgfSwNCiAgICAgICJQcm90b2NvbCI6IHsNCiAgICAgICAgIlN0YXR1c2VzIjogWw0KICAgICAgICAgIHsNCiAgICAgICAgICAgICJOYW1lIjogIlN0YXR1cyIsDQogICAgICAgICAgICAiRGF0YVBvaW50cyI6IFsNCiAgICAgICAgICAgICAgew0KICAgICAgICAgICAgICAgICJOYW1lIjogIiNQcmVmaXgiLA0KICAgICAgICAgICAgICAgICJUeXBlIjogInVpbnQxNl90IiwNCiAgICAgICAgICAgICAgICAiVmFsdWUiOiAyMjEzMA0KICAgICAgICAgICAgICB9LA0KICAgICAgICAgICAgICB7DQogICAgICAgICAgICAgICAgIk5hbWUiOiAiQ29sb3JzIiwNCiAgICAgICAgICAgICAgICAiVHlwZSI6ICJyZ2IiLA0KICAgICAgICAgICAgICAgICJDb3VudCI6IC0xDQogICAgICAgICAgICAgIH0NCiAgICAgICAgICAgIF0NCiAgICAgICAgICB9DQogICAgICAgIF0sDQogICAgICAgICJDb21tYW5kcyI6IFsNCg0KICAgICAgICBdDQogICAgICB9DQogICAgfQ0KICB9DQp9"
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(360124)
        $asm.$cls(`$CACm.LCIDLC.ICommandInterface`, ($self) => class ICommandInterface
        {
            static $h = 360124;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590294716),
    {
      "r": 65537,
      "n": "Blank",
      "o": "LCIDLC$ICommandInterface$Blank",
      "d": 360124,
      "h": 8590294716,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590294716),
//--TRIMMABLE-BOUNDARY-START(188978921148),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        }
      ],
      "n": "SetAll",
      "o": "LCIDLC$ICommandInterface$SetAll",
      "d": 360124,
      "h": 188978921148,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(188978921148),
//--TRIMMABLE-BOUNDARY-START(17180229308),
    {
      "r": 65537,
      "p": [
        {
          "n": "ballCount",
          "p": 589825
        },
        {
          "n": "colors",
          "p": $.$typeArray($.$sdp.SD.Color).$h
        },
        {
          "n": "time",
          "p": 589825,
          "f": 65,
          "v": 10000
        }
      ],
      "n": "BouncingColoredBalls",
      "o": "LCIDLC$ICommandInterface$BouncingColoredBalls",
      "d": 360124,
      "h": 17180229308,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180229308),
//--TRIMMABLE-BOUNDARY-START(12885262012),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "ballCount",
          "p": 589825,
          "f": 65,
          "v": 3
        },
        {
          "n": "time",
          "p": 589825,
          "f": 65,
          "v": 10000
        }
      ],
      "n": "BouncingBalls",
      "o": "LCIDLC$ICommandInterface$BouncingBalls",
      "d": 360124,
      "h": 12885262012,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885262012),
//--TRIMMABLE-BOUNDARY-START(38655065788),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "speedDelay",
          "p": 589825,
          "f": 65,
          "v": 20
        }
      ],
      "n": "ColorWipe",
      "o": "LCIDLC$ICommandInterface$ColorWipe",
      "d": 360124,
      "h": 38655065788,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38655065788),
//--TRIMMABLE-BOUNDARY-START(42950033084),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "EyeSize",
          "p": 589825,
          "f": 65,
          "v": 4
        },
        {
          "n": "speedDelay",
          "p": 589825,
          "f": 65,
          "v": 10
        },
        {
          "n": "returnDelay",
          "p": 589825,
          "f": 65,
          "v": 5
        }
      ],
      "n": "CylonBounce",
      "o": "LCIDLC$ICommandInterface$CylonBounce",
      "d": 360124,
      "h": 42950033084,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42950033084),
//--TRIMMABLE-BOUNDARY-START(150324215484),
    {
      "r": 65537,
      "n": "RGBLoop",
      "o": "LCIDLC$ICommandInterface$RGBLoop",
      "d": 360124,
      "h": 150324215484,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(150324215484),
//--TRIMMABLE-BOUNDARY-START(47245000380),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        }
      ],
      "n": "FadeInOut",
      "o": "LCIDLC$ICommandInterface$FadeInOut",
      "d": 360124,
      "h": 47245000380,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47245000380),
//--TRIMMABLE-BOUNDARY-START(55834934972),
    {
      "r": 65537,
      "p": [
        {
          "n": "Cooling",
          "p": 589825,
          "f": 65,
          "v": 55
        },
        {
          "n": "Sparking",
          "p": 589825,
          "f": 65,
          "v": 120
        },
        {
          "n": "SpeedDelay",
          "p": 589825,
          "f": 65,
          "v": 15
        }
      ],
      "n": "Fire",
      "o": "LCIDLC$ICommandInterface$Fire",
      "d": 360124,
      "h": 55834934972,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(55834934972),
//--TRIMMABLE-BOUNDARY-START(73014804156),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "EyeWidth",
          "p": 589825,
          "f": 65,
          "v": 1
        },
        {
          "n": "EyeSpace",
          "p": 589825,
          "f": 65,
          "v": 4
        },
        {
          "n": "Fade",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "Steps",
          "p": 589825,
          "f": 65,
          "v": 25
        },
        {
          "n": "FadeDelay",
          "p": 589825,
          "f": 65,
          "v": 75
        },
        {
          "n": "EndPause",
          "p": 589825,
          "f": 65,
          "v": 5000
        }
      ],
      "n": "HalloweenEyes",
      "o": "LCIDLC$ICommandInterface$HalloweenEyes",
      "d": 360124,
      "h": 73014804156,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(73014804156),
//--TRIMMABLE-BOUNDARY-START(77309771452),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "EyeSize",
          "p": 589825,
          "f": 65,
          "v": 8
        },
        {
          "n": "SpeedDelay",
          "p": 589825,
          "f": 65,
          "v": 10
        },
        {
          "n": "ReturnDelay",
          "p": 589825,
          "f": 65,
          "v": 50
        }
      ],
      "n": "NewKITT",
      "o": "LCIDLC$ICommandInterface$NewKITT",
      "d": 360124,
      "h": 77309771452,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(77309771452),
//--TRIMMABLE-BOUNDARY-START(115964477116),
    {
      "r": 65537,
      "p": [
        {
          "n": "SpeedDelay",
          "p": 589825,
          "f": 65,
          "v": 20
        }
      ],
      "n": "RainbowCycle",
      "o": "LCIDLC$ICommandInterface$RainbowCycle",
      "d": 360124,
      "h": 115964477116,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(115964477116),
//--TRIMMABLE-BOUNDARY-START(236223561404),
    {
      "r": 65537,
      "p": [
        {
          "n": "Count",
          "p": 589825,
          "f": 65,
          "v": 20
        },
        {
          "n": "SpeedDelay",
          "p": 589825,
          "f": 65,
          "v": 20
        },
        {
          "n": "OnlyOne",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "TwinkleRandom",
      "o": "LCIDLC$ICommandInterface$TwinkleRandom",
      "d": 360124,
      "h": 236223561404,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(236223561404),
//--TRIMMABLE-BOUNDARY-START(154619182780),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "WaveDelay",
          "p": 589825,
          "f": 65,
          "v": 50
        }
      ],
      "n": "RunningLights",
      "o": "LCIDLC$ICommandInterface$RunningLights",
      "d": 360124,
      "h": 154619182780,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(154619182780),
//--TRIMMABLE-BOUNDARY-START(197568855740),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "SparkleDelay",
          "p": 589825,
          "f": 65,
          "v": 20
        },
        {
          "n": "SpeedDelay",
          "p": 589825,
          "f": 65,
          "v": 500
        }
      ],
      "n": "SnowSparkle",
      "o": "LCIDLC$ICommandInterface$SnowSparkle",
      "d": 360124,
      "h": 197568855740,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(197568855740),
//--TRIMMABLE-BOUNDARY-START(201863823036),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "SpeedDelay",
          "p": 589825,
          "f": 65,
          "v": 0
        }
      ],
      "n": "Sparkle",
      "o": "LCIDLC$ICommandInterface$Sparkle",
      "d": 360124,
      "h": 201863823036,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(201863823036),
//--TRIMMABLE-BOUNDARY-START(214748724924),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "StrobeCount",
          "p": 589825,
          "f": 65,
          "v": 10
        },
        {
          "n": "FlashDelay",
          "p": 589825,
          "f": 65,
          "v": 50
        },
        {
          "n": "EndPause",
          "p": 589825,
          "f": 65,
          "v": 1000
        }
      ],
      "n": "Strobe",
      "o": "LCIDLC$ICommandInterface$Strobe",
      "d": 360124,
      "h": 214748724924,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(214748724924),
//--TRIMMABLE-BOUNDARY-START(227633626812),
    {
      "r": 65537,
      "p": [
        {
          "n": "SpeedDelay",
          "p": 589825,
          "f": 65,
          "v": 50
        }
      ],
      "n": "TheaterChaseRainbow",
      "o": "LCIDLC$ICommandInterface$TheaterChaseRainbow",
      "d": 360124,
      "h": 227633626812,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(227633626812),
//--TRIMMABLE-BOUNDARY-START(223338659516),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "SpeedDelay",
          "p": 589825,
          "f": 65,
          "v": 50
        }
      ],
      "n": "TheaterChase",
      "o": "LCIDLC$ICommandInterface$TheaterChase",
      "d": 360124,
      "h": 223338659516,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(223338659516),
//--TRIMMABLE-BOUNDARY-START(231928594108),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "Count",
          "p": 589825,
          "f": 65,
          "v": 10
        },
        {
          "n": "SpeedDelay",
          "p": 589825,
          "f": 65,
          "v": 100
        },
        {
          "n": "OnlyOne",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "Twinkle",
      "o": "LCIDLC$ICommandInterface$Twinkle",
      "d": 360124,
      "h": 231928594108,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(231928594108),
//--TRIMMABLE-BOUNDARY-START(120259444412),
    {
      "r": 65537,
      "p": [
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 20
        }
      ],
      "n": "RainbowFade",
      "o": "LCIDLC$ICommandInterface$RainbowFade",
      "d": 360124,
      "h": 120259444412,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(120259444412),
//--TRIMMABLE-BOUNDARY-START(124554411708),
    {
      "r": 65537,
      "p": [
        {
          "n": "istep",
          "p": 589825,
          "f": 65,
          "v": 10
        },
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 20
        }
      ],
      "n": "RainbowLoop",
      "o": "LCIDLC$ICommandInterface$RainbowLoop",
      "d": 360124,
      "h": 124554411708,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(124554411708),
//--TRIMMABLE-BOUNDARY-START(137439313596),
    {
      "r": 65537,
      "p": [
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 20
        }
      ],
      "n": "RandomBurst",
      "o": "LCIDLC$ICommandInterface$RandomBurst",
      "d": 360124,
      "h": 137439313596,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(137439313596),
//--TRIMMABLE-BOUNDARY-START(21475196604),
    {
      "r": 65537,
      "p": [
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 20
        }
      ],
      "n": "ColorBounce",
      "o": "LCIDLC$ICommandInterface$ColorBounce",
      "d": 360124,
      "h": 21475196604,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475196604),
//--TRIMMABLE-BOUNDARY-START(85899706044),
    {
      "r": 65537,
      "p": [
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 40
        }
      ],
      "n": "PoliceLights1",
      "o": "LCIDLC$ICommandInterface$PoliceLights1",
      "d": 360124,
      "h": 85899706044,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(85899706044),
//--TRIMMABLE-BOUNDARY-START(90194673340),
    {
      "r": 65537,
      "p": [
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 40
        }
      ],
      "n": "PoliceLightsAll",
      "o": "LCIDLC$ICommandInterface$PoliceLightsAll",
      "d": 360124,
      "h": 90194673340,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(90194673340),
//--TRIMMABLE-BOUNDARY-START(25770163900),
    {
      "r": 65537,
      "p": [
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 40
        }
      ],
      "n": "ColorBounceFade",
      "o": "LCIDLC$ICommandInterface$ColorBounceFade",
      "d": 360124,
      "h": 25770163900,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770163900),
//--TRIMMABLE-BOUNDARY-START(64424869564),
    {
      "r": 65537,
      "p": [
        {
          "n": "thishue",
          "p": 589825,
          "f": 65,
          "v": 200
        },
        {
          "n": "thissat",
          "p": 589825,
          "f": 65,
          "v": 255
        }
      ],
      "n": "Flicker",
      "o": "LCIDLC$ICommandInterface$Flicker",
      "d": 360124,
      "h": 64424869564,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(64424869564),
//--TRIMMABLE-BOUNDARY-START(98784607932),
    {
      "r": 65537,
      "p": [
        {
          "n": "ahue",
          "p": 589825,
          "f": 65,
          "v": 0
        },
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 10
        }
      ],
      "n": "PulseOneColorAll",
      "o": "LCIDLC$ICommandInterface$PulseOneColorAll",
      "d": 360124,
      "h": 98784607932,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(98784607932),
//--TRIMMABLE-BOUNDARY-START(103079575228),
    {
      "r": 65537,
      "p": [
        {
          "n": "ahue",
          "p": 589825,
          "f": 65,
          "v": 0
        },
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 10
        }
      ],
      "n": "PulseOneColorAllRev",
      "o": "LCIDLC$ICommandInterface$PulseOneColorAllRev",
      "d": 360124,
      "h": 103079575228,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(103079575228),
//--TRIMMABLE-BOUNDARY-START(141734280892),
    {
      "r": 65537,
      "p": [
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 30
        }
      ],
      "n": "RandomMarch",
      "o": "LCIDLC$ICommandInterface$RandomMarch",
      "d": 360124,
      "h": 141734280892,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(141734280892),
//--TRIMMABLE-BOUNDARY-START(133144346300),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        }
      ],
      "n": "Random",
      "o": "LCIDLC$ICommandInterface$Random",
      "d": 360124,
      "h": 133144346300,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(133144346300),
//--TRIMMABLE-BOUNDARY-START(158914150076),
    {
      "r": 65537,
      "p": [
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 80
        }
      ],
      "n": "RwbMarch",
      "o": "LCIDLC$ICommandInterface$RwbMarch",
      "d": 360124,
      "h": 158914150076,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(158914150076),
//--TRIMMABLE-BOUNDARY-START(240518528700),
    {
      "r": 65537,
      "n": "WhiteTemps",
      "o": "LCIDLC$ICommandInterface$WhiteTemps",
      "d": 360124,
      "h": 240518528700,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(240518528700),
//--TRIMMABLE-BOUNDARY-START(34360098492),
    {
      "r": 65537,
      "p": [
        {
          "n": "hue",
          "p": 655361
        }
      ],
      "n": "ColorLoopVarDelay",
      "o": "LCIDLC$ICommandInterface$ColorLoopVarDelay",
      "d": 360124,
      "h": 34360098492,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34360098492),
//--TRIMMABLE-BOUNDARY-START(30065131196),
    {
      "r": 65537,
      "n": "ColorLoopRandDelay",
      "o": "LCIDLC$ICommandInterface$ColorLoopRandDelay",
      "d": 360124,
      "h": 30065131196,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30065131196),
//--TRIMMABLE-BOUNDARY-START(210453757628),
    {
      "r": 65537,
      "p": [
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 100
        }
      ],
      "n": "StripMarchCW",
      "o": "LCIDLC$ICommandInterface$StripMarchCW",
      "d": 360124,
      "h": 210453757628,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(210453757628),
//--TRIMMABLE-BOUNDARY-START(206158790332),
    {
      "r": 65537,
      "p": [
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 100
        }
      ],
      "n": "StripMarchCCW",
      "o": "LCIDLC$ICommandInterface$StripMarchCCW",
      "d": 360124,
      "h": 206158790332,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(206158790332),
//--TRIMMABLE-BOUNDARY-START(94489640636),
    {
      "r": 65537,
      "p": [
        {
          "n": "ahue",
          "p": 589825,
          "f": 65,
          "v": 0
        },
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 100
        }
      ],
      "n": "PopHorizontal",
      "o": "LCIDLC$ICommandInterface$PopHorizontal",
      "d": 360124,
      "h": 94489640636,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(94489640636),
//--TRIMMABLE-BOUNDARY-START(107374542524),
    {
      "r": 65537,
      "p": [
        {
          "n": "ahue",
          "p": 589825,
          "f": 65,
          "v": 0
        },
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 100
        }
      ],
      "n": "QuadBrightCurve",
      "o": "LCIDLC$ICommandInterface$QuadBrightCurve",
      "d": 360124,
      "h": 107374542524,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(107374542524),
//--TRIMMABLE-BOUNDARY-START(60129902268),
    {
      "r": 65537,
      "n": "Flame",
      "o": "LCIDLC$ICommandInterface$Flame",
      "d": 360124,
      "h": 60129902268,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(60129902268),
//--TRIMMABLE-BOUNDARY-START(111669509820),
    {
      "r": 65537,
      "p": [
        {
          "n": "ahue",
          "p": 589825,
          "f": 65,
          "v": 0
        },
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 60
        }
      ],
      "n": "Radiation",
      "o": "LCIDLC$ICommandInterface$Radiation",
      "d": 360124,
      "h": 111669509820,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(111669509820),
//--TRIMMABLE-BOUNDARY-START(219043692220),
    {
      "r": 65537,
      "p": [
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 500
        }
      ],
      "n": "SwissCross",
      "o": "LCIDLC$ICommandInterface$SwissCross",
      "d": 360124,
      "h": 219043692220,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(219043692220),
//--TRIMMABLE-BOUNDARY-START(68719836860),
    {
      "r": 65537,
      "p": [
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 500
        }
      ],
      "n": "Germany",
      "o": "LCIDLC$ICommandInterface$Germany",
      "d": 360124,
      "h": 68719836860,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(68719836860),
//--TRIMMABLE-BOUNDARY-START(193273888444),
    {
      "r": 65537,
      "p": [
        {
          "n": "ahue",
          "p": 589825,
          "f": 65,
          "v": 0
        },
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 35
        }
      ],
      "n": "SinBrightWave",
      "o": "LCIDLC$ICommandInterface$SinBrightWave",
      "d": 360124,
      "h": 193273888444,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(193273888444),
//--TRIMMABLE-BOUNDARY-START(51539967676),
    {
      "r": 65537,
      "p": [
        {
          "n": "ahue",
          "p": 589825,
          "f": 65,
          "v": 0
        },
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 60
        }
      ],
      "n": "FadeVertical",
      "o": "LCIDLC$ICommandInterface$FadeVertical",
      "d": 360124,
      "h": 51539967676,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51539967676),
//--TRIMMABLE-BOUNDARY-START(128849379004),
    {
      "r": 65537,
      "p": [
        {
          "n": "istep",
          "p": 589825,
          "f": 65,
          "v": 15
        },
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 50
        }
      ],
      "n": "RainbowVertical",
      "o": "LCIDLC$ICommandInterface$RainbowVertical",
      "d": 360124,
      "h": 128849379004,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(128849379004),
//--TRIMMABLE-BOUNDARY-START(81604738748),
    {
      "r": 65537,
      "p": [
        {
          "n": "idelay",
          "p": 589825,
          "f": 65,
          "v": 50
        }
      ],
      "n": "Pacman",
      "o": "LCIDLC$ICommandInterface$Pacman",
      "d": 360124,
      "h": 81604738748,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(81604738748),
//--TRIMMABLE-BOUNDARY-START(180388986556),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "wait",
          "p": 589825,
          "f": 65,
          "v": 30
        }
      ],
      "n": "ScannerUp",
      "o": "LCIDLC$ICommandInterface$ScannerUp",
      "d": 360124,
      "h": 180388986556,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(180388986556),
//--TRIMMABLE-BOUNDARY-START(163209117372),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "wait",
          "p": 589825,
          "f": 65,
          "v": 30
        }
      ],
      "n": "ScannerDown",
      "o": "LCIDLC$ICommandInterface$ScannerDown",
      "d": 360124,
      "h": 163209117372,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(163209117372),
//--TRIMMABLE-BOUNDARY-START(184683953852),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "start",
          "p": 589825,
          "f": 65,
          "v": 0
        },
        {
          "n": "wait",
          "p": 589825,
          "f": 65,
          "v": 30
        }
      ],
      "n": "ScannerUp2",
      "o": "LCIDLC$ICommandInterface$ScannerUp2",
      "d": 360124,
      "h": 184683953852,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(184683953852),
//--TRIMMABLE-BOUNDARY-START(167504084668),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "start",
          "p": 589825,
          "f": 65,
          "v": 0
        },
        {
          "n": "wait",
          "p": 589825,
          "f": 65,
          "v": 30
        }
      ],
      "n": "ScannerDown2",
      "o": "LCIDLC$ICommandInterface$ScannerDown2",
      "d": 360124,
      "h": 167504084668,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(167504084668),
//--TRIMMABLE-BOUNDARY-START(171799051964),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "wait",
          "p": 589825,
          "f": 65,
          "v": 30
        }
      ],
      "n": "ScannerMirror",
      "o": "LCIDLC$ICommandInterface$ScannerMirror",
      "d": 360124,
      "h": 171799051964,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(171799051964),
//--TRIMMABLE-BOUNDARY-START(176094019260),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "wait",
          "p": 589825,
          "f": 65,
          "v": 30
        }
      ],
      "n": "ScannerMirror2",
      "o": "LCIDLC$ICommandInterface$ScannerMirror2",
      "d": 360124,
      "h": 176094019260,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(176094019260),
//--TRIMMABLE-BOUNDARY-START(4295327420),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        },
        {
          "n": "wait",
          "p": 589825,
          "f": 65,
          "v": 50
        }
      ],
      "n": "Bar",
      "o": "LCIDLC$ICommandInterface$Bar",
      "d": 360124,
      "h": 4295327420,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295327420),
//--TRIMMABLE-BOUNDARY-START(146029248188),
    {
      "r": 65537,
      "p": [
        {
          "n": "wait",
          "p": 589825,
          "f": 65,
          "v": 50
        }
      ],
      "n": "RandomPixelColor",
      "o": "LCIDLC$ICommandInterface$RandomPixelColor",
      "d": 360124,
      "h": 146029248188,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(146029248188)
  ],
  "h": 360124
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Commands.ICommandInterface`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Commands${separator}ICommandInterface`; }
        });
        //--TRIMMABLE-BOUNDARY-END(360124)
        
        

        //--TRIMMABLE-BOUNDARY-START(1474236)
        $asm.$cls(`$CACm.LCIDLM.LEDStripDeviceScopeModelCustomAttributesProvider`, ($self) => class LEDStripDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296441532)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296441532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296441532)
            
            static $h = 1474236;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296441532),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1474236,
      "h": 4296441532,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296441532)
  ],
  "h": 1474236
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1474236)
        
        

        //--TRIMMABLE-BOUNDARY-START(1736380)
        $asm.$cls(`$CACm.LCIDLM.LEDStripDeviceSendDataModelCustomAttributesProvider`, ($self) => class LEDStripDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296703676)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296703676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceSendDataModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296703676)
            
            static $h = 1736380;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296703676),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1736380,
      "h": 4296703676,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296703676)
  ],
  "h": 1736380
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1736380)
        
        

        //--TRIMMABLE-BOUNDARY-START(1212092)
        $asm.$cls(`$CACm.LCIDLM.LEDStripDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class LEDStripDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296179388)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296179388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$CACm.LCIDLM.LEDStripStatus).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296179388)
            
            static $h = 1212092;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296179388),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1212092,
      "h": 4296179388,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296179388)
  ],
  "h": 1212092
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1212092)
        
        

        //--TRIMMABLE-BOUNDARY-START(1998524)
        $asm.$cls(`$CACm.LCIDLM.LEDStripServiceModelCustomAttributesProvider`, ($self) => class LEDStripServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296965820)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296965820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296965820)
            
            static $h = 1998524;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296965820),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1998524,
      "h": 4296965820,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296965820)
  ],
  "h": 1998524
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1998524)
        
        

        //--TRIMMABLE-BOUNDARY-START(556732)
        $asm.$cls(`$CACm.LCIDL$1.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295524028)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295524028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CACm.LCIDLM.LEDStripDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CACm.LCIDLM.LEDStripDeviceModelCustomAttributesProvider, $.$CACm.LCIDLM.LEDStripDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModelCustomAttributesProvider, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CACm.LCIDLM.LEDStripDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CACm.LCIDLM.LEDStripDeviceScopeModelCustomAttributesProvider, $.$CACm.LCIDLM.LEDStripDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CACm.LCIDLM.LEDStripDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CACm.LCIDLM.LEDStripDeviceSendDataModelCustomAttributesProvider, $.$CACm.LCIDLM.LEDStripDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CACm.LCIDLM.LEDStripServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CACm.LCIDLM.LEDStripServiceModelCustomAttributesProvider, $.$CACm.LCIDLM.LEDStripServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsCustomAttributesProvider, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CACm.LCIDLS$1.LEDStripDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CACm.LCIDLS$1.LEDStripDeviceSettingsCustomAttributesProvider, $.$CACm.LCIDLS$1.LEDStripDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295524028)
            
            static $h = 556732;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295524028),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 556732,
      "h": 4295524028,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295524028)
  ],
  "h": 556732
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(556732)
        
        

        //--TRIMMABLE-BOUNDARY-START(3178172)
        $asm.$cls(`$CACm.LCIDL$1.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298145468)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298145468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$CACm.LCIDLM.LEDStripDeviceModelTypeDescriptorBuilder.Register();
                $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$CACm.LCIDLM.LEDStripDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$CACm.LCIDLM.LEDStripDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$CACm.LCIDLM.LEDStripServiceModelTypeDescriptorBuilder.Register();
                $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$CACm.LCIDLS$1.LEDStripDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298145468)
            
            static $h = 3178172;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298145468),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3178172,
      "h": 4298145468,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298145468)
  ],
  "h": 3178172
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3178172)
        
        

        //--TRIMMABLE-BOUNDARY-START(949948)
        $asm.$cls(`$CACm.LCIDLM.LEDStripDeviceModelCustomAttributesProvider`, ($self) => class LEDStripDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295917244)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295917244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295917244)
            
            static $h = 949948;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295917244),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 949948,
      "h": 4295917244,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295917244)
  ],
  "h": 949948
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(949948)
        
        

        //--TRIMMABLE-BOUNDARY-START(1081020)
        $asm.$cls(`$CACm.LCIDLM.LEDStripDeviceModelTypeDescriptorBuilder`, ($self) => class LEDStripDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591015612)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591015612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CACm.LCIDLM.LEDStripDeviceModelTypeDescriptor()
                        const $t1 = $.$CACm.LCIDLM.LEDStripDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $FAqQda ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1081020,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CACm.LCIDLM.LEDStripDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591015612)
            
            //--TRIMMABLE-BOUNDARY-START(4296048316)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296048316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296048316)
            
            //--TRIMMABLE-BOUNDARY-START(4296048316)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296048316)
            
            static $h = 1081020;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591015612),
    {
      "r": 65537,
      "n": "Register",
      "d": 1081020,
      "h": 8591015612,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591015612)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296048316),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1081020,
      "h": 4296048316,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296048316)
  ],
  "h": 1081020
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1081020)
        
        

        //--TRIMMABLE-BOUNDARY-START(1605308)
        $asm.$cls(`$CACm.LCIDLM.LEDStripDeviceScopeModelTypeDescriptorBuilder`, ($self) => class LEDStripDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591539900)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591539900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CACm.LCIDLM.LEDStripDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$CACm.LCIDLM.LEDStripDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $sEwsra ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1605308,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CACm.LCIDLM.LEDStripDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591539900)
            
            //--TRIMMABLE-BOUNDARY-START(4296572604)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296572604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296572604)
            
            //--TRIMMABLE-BOUNDARY-START(4296572604)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296572604)
            
            static $h = 1605308;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591539900),
    {
      "r": 65537,
      "n": "Register",
      "d": 1605308,
      "h": 8591539900,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591539900)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296572604),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1605308,
      "h": 4296572604,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296572604)
  ],
  "h": 1605308
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1605308)
        
        

        //--TRIMMABLE-BOUNDARY-START(1343164)
        $asm.$cls(`$CACm.LCIDLM.LEDStripDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class LEDStripDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591277756)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591277756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $XkXcbe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1343164,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591277756)
            
            //--TRIMMABLE-BOUNDARY-START(4296310460)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296310460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296310460)
            
            //--TRIMMABLE-BOUNDARY-START(4296310460)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296310460)
            
            static $h = 1343164;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591277756),
    {
      "r": 65537,
      "n": "Register",
      "d": 1343164,
      "h": 8591277756,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591277756)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296310460),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1343164,
      "h": 4296310460,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296310460)
  ],
  "h": 1343164
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1343164)
        
        

        //--TRIMMABLE-BOUNDARY-START(2981564)
        $asm.$cls(`$CACm.LCIDLS$1.LEDStripDeviceSettingsCustomAttributesProvider`, ($self) => class LEDStripDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297948860)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297948860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297948860)
            
            static $h = 2981564;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297948860),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2981564,
      "h": 4297948860,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297948860)
  ],
  "h": 2981564
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Settings${separator}LEDStripDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2981564)
        
        

        //--TRIMMABLE-BOUNDARY-START(2129596)
        $asm.$cls(`$CACm.LCIDLM.LEDStripServiceModelTypeDescriptorBuilder`, ($self) => class LEDStripServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592064188)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592064188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CACm.LCIDLM.LEDStripServiceModelTypeDescriptor()
                        const $t1 = $.$CACm.LCIDLM.LEDStripServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $CDWeOg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2129596,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CACm.LCIDLM.LEDStripServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592064188)
            
            //--TRIMMABLE-BOUNDARY-START(4297096892)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297096892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297096892)
            
            //--TRIMMABLE-BOUNDARY-START(4297096892)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297096892)
            
            static $h = 2129596;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592064188),
    {
      "r": 65537,
      "n": "Register",
      "d": 2129596,
      "h": 8592064188,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592064188)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297096892),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2129596,
      "h": 4297096892,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297096892)
  ],
  "h": 2129596
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2129596)
        
        

        //--TRIMMABLE-BOUNDARY-START(3112636)
        $asm.$cls(`$CACm.LCIDLS$1.LEDStripDeviceSettingsTypeDescriptorBuilder`, ($self) => class LEDStripDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593047228)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593047228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CACm.LCIDLS$1.LEDStripDeviceSettingsTypeDescriptor()
                        const $t1 = $.$CACm.LCIDLS$1.LEDStripDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $TrnKya ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3112636,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CACm.LCIDLS$1.LEDStripDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593047228)
            
            //--TRIMMABLE-BOUNDARY-START(4298079932)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298079932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298079932)
            
            //--TRIMMABLE-BOUNDARY-START(4298079932)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298079932)
            
            static $h = 3112636;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593047228),
    {
      "r": 65537,
      "n": "Register",
      "d": 3112636,
      "h": 8593047228,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593047228)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298079932),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3112636,
      "h": 4298079932,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298079932)
  ],
  "h": 3112636
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Settings${separator}LEDStripDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3112636)
        
        

        //--TRIMMABLE-BOUNDARY-START(1867452)
        $asm.$cls(`$CACm.LCIDLM.LEDStripDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class LEDStripDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591802044)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591802044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CACm.LCIDLM.LEDStripDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$CACm.LCIDLM.LEDStripDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $kxnqOf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1867452,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CACm.LCIDLM.LEDStripDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591802044)
            
            //--TRIMMABLE-BOUNDARY-START(4296834748)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296834748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296834748)
            
            //--TRIMMABLE-BOUNDARY-START(4296834748)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296834748)
            
            static $h = 1867452;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591802044),
    {
      "r": 65537,
      "n": "Register",
      "d": 1867452,
      "h": 8591802044,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591802044)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296834748),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1867452,
      "h": 4296834748,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296834748)
  ],
  "h": 1867452
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1867452)
        
        

        //--TRIMMABLE-BOUNDARY-START(2719420)
        $asm.$cls(`$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class LEDStripDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297686716)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297686716)
            
            //--TRIMMABLE-BOUNDARY-START(8592654012)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592654012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Leds", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Key = "lcnt";
                            $i3.Order = (20);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Arrangement", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Key = "larr";
                            $i4.Order = (21);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Pattern", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Key = "_lpat";
                            $i5.Order = (22);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $GpOqcg ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2719420,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $bstRlb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2719420,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592654012)
            
            static $h = 2719420;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592654012),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2719420,
      "h": 8592654012,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592654012)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297686716),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2719420,
      "h": 4297686716,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297686716)
  ],
  "h": 2719420
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Settings${separator}LEDStripDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2719420)
        
        

        //--TRIMMABLE-BOUNDARY-START(2850492)
        $asm.$cls(`$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class LEDStripDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592785084)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592785084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $aVgMki ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2850492,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592785084)
            
            //--TRIMMABLE-BOUNDARY-START(4297817788)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297817788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297817788)
            
            //--TRIMMABLE-BOUNDARY-START(4297817788)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297817788)
            
            static $h = 2850492;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592785084),
    {
      "r": 65537,
      "n": "Register",
      "d": 2850492,
      "h": 8592785084,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592785084)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297817788),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2850492,
      "h": 4297817788,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297817788)
  ],
  "h": 2850492
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Settings${separator}LEDStripDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2850492)
        
        

        //--TRIMMABLE-BOUNDARY-START(97980)
        $asm.$cls(`$CACm._LCIDLVL.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(8590032572)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*global::System.Object*/ __arg1, /*int*/ __seq2, /*global::System.Object*/ __arg2, /*int*/ __seq3, /*global::System.Object*/ __arg3, /*int*/ __seq4, /*TValue*/ __arg4, /*int*/ __seq5, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg5, /*int*/ __seq6, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg6)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590032572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "input-value", __arg1);
                __builder.AddComponentParameter(__seq2, "input-min", __arg2);
                __builder.AddComponentParameter(__seq3, "input-max", __arg3);
                __builder.AddComponentParameter(__seq4, "Value", $.$box(__arg4, TValue));
                __builder.AddComponentParameter(__seq5, "ValueChanged", __arg5);
                __builder.AddComponentParameter(__seq6, "ValueExpression", __arg6);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590032572)
            
            //--TRIMMABLE-BOUNDARY-START(12884999868)
            static /*void */ CreateInputEditor_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*global::System.Object*/ __arg1, /*int*/ __seq2, /*global::System.Object*/ __arg2, /*int*/ __seq3, /*global::System.Object*/ __arg3, /*int*/ __seq4, /*TValue*/ __arg4, /*int*/ __seq5, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg5, /*int*/ __seq6, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg6)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884999868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "input-value", __arg1);
                __builder.AddComponentParameter(__seq2, "input-min", __arg2);
                __builder.AddComponentParameter(__seq3, "input-max", __arg3);
                __builder.AddComponentParameter(__seq4, "Value", $.$box(__arg4, TValue));
                __builder.AddComponentParameter(__seq5, "ValueChanged", __arg5);
                __builder.AddComponentParameter(__seq6, "ValueExpression", __arg6);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12884999868)
            
            //--TRIMMABLE-BOUNDARY-START(4295065276)
            static /*void */ CreateDataList_2(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Common.Client.IViewController*/ __arg1, /*int*/ __seq2, /*global::System.Boolean*/ __arg2, /*int*/ __seq3, /*global::System.Int32*/ __arg3, /*int*/ __seq4, /*global::System.Object*/ __arg4, /*int*/ __seq5, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<T>>>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295065276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "Controller", __arg1);
                __builder.AddComponentParameter(__seq2, "Selectable", $.$box(__arg2, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq3, "PadContent", $.$box(__arg3, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq4, "Bordered", __arg4);
                __builder.AddComponentParameter(__seq5, "ChildContent", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295065276)
            
            static $h = 97980;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590032572),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 131073
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 131073
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 131073
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq6",
          "p": 655361
        },
        {
          "n": "__arg6",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 97980,
      "h": 8590032572,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590032572),
//--TRIMMABLE-BOUNDARY-START(12884999868),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 131073
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 131073
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 131073
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq6",
          "p": 655361
        },
        {
          "n": "__arg6",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_1",
      "d": 97980,
      "h": 12884999868,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12884999868),
//--TRIMMABLE-BOUNDARY-START(4295065276),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 5856680
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 262145
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 655361
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": 131073
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateDataList_2",
      "d": 97980,
      "h": 4295065276,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295065276)
  ],
  "h": 97980
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.IOT.Devices.LEDStrip.Views.LEDStripDetailsPage.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Views${separator}LEDStripDetailsPage${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(97980)
        
        

        //--TRIMMABLE-BOUNDARY-START(294588)
        $asm.$cls(`$CACm.LCIDL$1._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295261884)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295261884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$CACm.LCIDL$1.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295261884)
            
            static $h = 294588;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295261884),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 294588,
      "h": 4295261884,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295261884)
  ],
  "h": 294588
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(294588)
        
        

        //--TRIMMABLE-BOUNDARY-START(491196)
        $asm.$cls(`$CACm.LCIDL$1.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180360380)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180360380)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295458492)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295458492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295458492)
            
            //--TRIMMABLE-BOUNDARY-START(4295458492)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295458492)
            
            static $h = 491196;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180360380),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885393084,
        "f": 50331649
      },
      "n": "Paths",
      "d": 491196,
      "h": 17180360380,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180360380)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295458492),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 491196,
      "h": 4295458492,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295458492)
  ],
  "h": 491196
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(491196)
        
        

        //--TRIMMABLE-BOUNDARY-START(2260668)
        $asm.$cls(`$CACm.LCIDL$1.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17182129852)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$CACm.LCIDLV.LEDStripDetailsPage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$CACm.LCIDLV.LEDStripDetailsPage().$ctor$4();
                    }, $dmoKEd ??= {"r":2752627,"n":"","d":2260668,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$CACm.LCIDLV.LEDStripMinorStatus.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$CACm.LCIDLV.LEDStripMinorStatus().$ctor$4();
                    }, $EyNEWd ??= {"r":2752627,"n":"","d":2260668,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17182129852)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4297227964)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297227964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297227964)
            
            //--TRIMMABLE-BOUNDARY-START(4297227964)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297227964)
            
            static $h = 2260668;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182129852),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887162556,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 2260668,
      "h": 17182129852,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182129852)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297227964),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2260668,
      "h": 4297227964,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297227964)
  ],
  "h": 2260668
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2260668)
        
        

        //--TRIMMABLE-BOUNDARY-START(2326204)
        $asm.$cls(`$CACm.LCIDL$1.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592260796)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592260796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$CACm.LCIDL$1.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$CACm.LCIDL$1.LEDStripDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$CACm.LCIDL$1.LEDStripDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$CACm.LCIDL$1.LEDStripDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$CACm.LCIDL$1.LEDStripDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$CACm.LCIDL$1.LEDStripDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$CACm.LCIDL$1.LEDStripDeviceFamily, x);
                }, $Zbvtxg ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":2326204,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$CACm.LCIDL$1.LEDStripDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$CACm.LCIDL$1.LEDStripDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $RZnrel ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":2326204,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$CACm.LCIDL$1.LEDStripDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$CACm.LCIDL$1.LEDStripDeviceFamily, x);
                }, $oYvPtf ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$CACm.LCIDL$1.LEDStripDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":2326204,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel), $.$XBGm.LCICPB.BinaryPacketProtocol$$$$($.$CACm.LCIDL$1.LEDStripDevice, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICPB.BinaryPacketProtocolDecoder$$$($.$CACm.LCIDL$1.LEDStripDevice, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICPB.BinaryPacketProtocolEncoder$$$($.$CACm.LCIDL$1.LEDStripDevice, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICPB.BinaryPacketProtocolCommands$$($.$CACm.LCIDL$1.LEDStripDevice), $.$CACm.LCIDLC.LEDStripCommand$$($.$CACm.LCIDL$1.LEDStripDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$CACm.LCIDL$1.LEDStripDevice), $.$CACm.LCIDLV.LEDStripViewRenderer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592260796)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$CACm.LCIDL$1.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297293500)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297293500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297293500)
            
            //--TRIMMABLE-BOUNDARY-START(4297293500)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297293500)
            
            static $h = 2326204;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592260796),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2326204,
      "h": 8592260796,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592260796)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297293500),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2326204,
      "h": 4297293500,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297293500)
  ],
  "h": 2326204
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2326204)
        
        

        //--TRIMMABLE-BOUNDARY-START(3505852)
        $asm.$cls(`$CACm.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298473148)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298473148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298473148)
            
            //--TRIMMABLE-BOUNDARY-START(4298473148)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298473148)
            
            static $h = 3505852;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298473148),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3505852,
      "h": 4298473148,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298473148)
  ],
  "h": 3505852
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3505852)
        
        

        //--TRIMMABLE-BOUNDARY-START(3571388)
        $asm.$cls(`$CACm.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298538684)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298538684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298538684)
            
            //--TRIMMABLE-BOUNDARY-START(4298538684)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298538684)
            
            static $h = 3571388;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298538684),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3571388,
      "h": 4298538684,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298538684)
  ],
  "h": 3571388,
  "a": [
    {
      "t": 3505852,
      "c": 4298473148
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3571388)
        
        

        //--TRIMMABLE-BOUNDARY-START(2588348)
        $asm.$str(`$CACm.LCIDLS$1.LEDColor`, ($self) => class LEDColor extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(25772392124)
            /*byte*/ A = 0;
            //--TRIMMABLE-BOUNDARY-END(25772392124)
            
            //--TRIMMABLE-BOUNDARY-START(73017032380)
            /*byte*/ R = 0;
            //--TRIMMABLE-BOUNDARY-END(73017032380)
            
            //--TRIMMABLE-BOUNDARY-START(34362326716)
            /*byte*/ G = 0;
            //--TRIMMABLE-BOUNDARY-END(34362326716)
            
            //--TRIMMABLE-BOUNDARY-START(30067359420)
            /*byte*/ B = 0;
            //--TRIMMABLE-BOUNDARY-END(30067359420)
            
            //--TRIMMABLE-BOUNDARY-START(111671738044)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671738044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `R:${$.$strNN(this.R)}, G:${$.$strNN(this.G)}, B:${$.$strNN(this.B)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(111671738044)
            
            //--TRIMMABLE-BOUNDARY-START(21477424828)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477424828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477424828)
            
            //--TRIMMABLE-BOUNDARY-START(21477424828)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21477424828)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.A = this.A;
                copy.R = this.R;
                copy.G = this.G;
                copy.B = this.B;
                return copy;
            }
            static $h = 2588348;
            static $z = 4;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772392124),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952261308,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81606966972,
        "f": 83886081
      },
      "n": "A",
      "d": 2588348,
      "h": 25772392124,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772392124),
//--TRIMMABLE-BOUNDARY-START(73017032380),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68722065084,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107376770748,
        "f": 83886081
      },
      "n": "R",
      "d": 2588348,
      "h": 73017032380,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73017032380),
//--TRIMMABLE-BOUNDARY-START(34362326716),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132130492,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98786836156,
        "f": 83886081
      },
      "n": "G",
      "d": 2588348,
      "h": 34362326716,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362326716),
//--TRIMMABLE-BOUNDARY-START(30067359420),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542195900,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196901564,
        "f": 83886081
      },
      "n": "B",
      "d": 2588348,
      "h": 30067359420,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067359420)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111671738044),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2588348,
      "h": 111671738044,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111671738044)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477424828),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2588348,
      "h": 21477424828,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477424828)
  ],
  "h": 2588348
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDColor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Settings${separator}LEDColor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2588348)
        
        

        //--TRIMMABLE-BOUNDARY-START(2195132)
        $asm.$cls(`$CACm.LCIDLM.LEDStripStatus`, ($self) => class LEDStripStatus extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(12887097020)
            /*Color[]*/ Colors = null;
            //--TRIMMABLE-BOUNDARY-END(12887097020)
            
            //--TRIMMABLE-BOUNDARY-START(8592129724)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592129724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592129724)
            
            //--TRIMMABLE-BOUNDARY-START(8592129724)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592129724)
            
            static $h = 2195132;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887097020),
    {
      "p": $.$typeArray($.$sdp.SD.Color).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477031612,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066966204,
        "f": 83886081
      },
      "n": "Colors",
      "d": 2195132,
      "h": 12887097020,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12887097020)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592129724),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2195132,
      "h": 8592129724,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592129724)
  ],
  "h": 2195132
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripStatus`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripStatus`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2195132)
        
        

        //--TRIMMABLE-BOUNDARY-START(229052)
        $asm.$cls(`$CACm.LCIDL$1._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590163644)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590163644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590163644)
            
            //--TRIMMABLE-BOUNDARY-START(4295196348)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295196348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295196348)
            
            //--TRIMMABLE-BOUNDARY-START(4295196348)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295196348)
            
            static $h = 229052;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590163644),
    {
      "r": 65537,
      "n": "Execute",
      "d": 229052,
      "h": 8590163644,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590163644)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295196348),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 229052,
      "h": 4295196348,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295196348)
  ],
  "h": 229052
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(229052)
        
        

        //--TRIMMABLE-BOUNDARY-START(1670844)
        $asm.$cls(`$CACm.LCIDLM.LEDStripDeviceSendDataModel`, ($self) => class LEDStripDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceSendDataModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296638140)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296638140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296638140)
            
            //--TRIMMABLE-BOUNDARY-START(4296638140)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296638140)
            
            static $h = 1670844;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceSendDataModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296638140),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1670844,
      "h": 4296638140,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296638140)
  ],
  "h": 1670844
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1670844)
        
        

        //--TRIMMABLE-BOUNDARY-START(425660)
        $asm.$cls(`$CACm.LCIDLC.LEDStripCommand<>`, (TOwner) => $asm.$gt(`$CACm.LCIDLC.LEDStripCommand<>`, [TOwner], ($self) => class LEDStripCommand$$ extends $.$XBGm.LCICPB.BinaryPacketProtocolCommands$$(TOwner)
        {
            //--TRIMMABLE-BOUNDARY-START(4295392956)
            $ctor$4(/*IConfigurationParser*/ config)
            {
                super.$ctor$3(config);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295392956);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295392956)
            
            //--TRIMMABLE-BOUNDARY-START(12885327548)
            /*string */ Type(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885327548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === $.$sdp.SD.Color.$type)
                {
                    return "rgb";
                }
                return $.$$.S.String.ToLower.call(type.Name);
            }
            //--TRIMMABLE-BOUNDARY-END(12885327548)
            
            //--TRIMMABLE-BOUNDARY-START(8590360252)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel?*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590360252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.N.InterfaceVarianceStubHandler.Create($.$sl.SL.Enumerable.Select$1($.$$.SR.MethodInfo, $.$XBGm.LCICPC.ConfigurationDescriptorProtocolCommand, $.$CACm.LCIDLC.ICommandInterface.$type.GetMethods(), new ($.$$.S.Func$$$($.$$.SR.MethodInfo, $.$XBGm.LCICPC.ConfigurationDescriptorProtocolCommand))().$ctor(this,  (/*method*/ method) =>
                {
                    return this.GetCommand((() =>
                    {
                        //new $.$XBGm.LCICPM.IOTDeviceProtocolCommadDescriptor()
                        const $t1 = $.$XBGm.LCICPM.IOTDeviceProtocolCommadDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = method.Name;
                        $i1.DataPoints = $.$sl.SL.Enumerable.ToArray($.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor, $.$sl.SL.Enumerable.Concat($.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor), [(() =>
                        {
                            //new $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor$$($.$$.S.UInt16)()
                            const $t2 = $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor$$($.$$.S.UInt16);
                            const $i2 = new $t2();
                            $i2.$ctor$3();
                            $i2.Name = "Prefix";
                            $i2.DefaultValue = $.$box(34083, $.$$.S.Int32);
                            $i2.Accessibility = 2/*PropertyAccessibility.Read*/;
                            return $i2;
                        })(), (() =>
                        {
                            //new $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor$$($.$$.S.Byte)()
                            const $t3 = $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor$$($.$$.S.Byte);
                            const $i3 = new $t3();
                            $i3.$ctor$3();
                            $i3.Name = "Save";
                            return $i3;
                        })(), (() =>
                        {
                            //new $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor$$($.$$.S.String)()
                            const $t4 = $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor$$($.$$.S.String);
                            const $i4 = new $t4();
                            $i4.$ctor$3();
                            $i4.Name = "Method";
                            $i4.DefaultValue = method.Name;
                            return $i4;
                        })(), (() =>
                        {
                            //new $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor$$($.$$.S.Int16)()
                            const $t5 = $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor$$($.$$.S.Int16);
                            const $i5 = new $t5();
                            $i5.$ctor$3();
                            $i5.Name = "Duration";
                            return $i5;
                        })()], [-1], null), $.$sl.SL.Enumerable.Select$1($.$$.SR.ParameterInfo, $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor, method.GetParameters(), new ($.$$.S.Func$$$($.$$.SR.ParameterInfo, $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor))().$ctor(this,  (/**/ methodParameter) =>
                        {
                            return $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor.FromRuntimeDataType(methodParameter.ParameterType, methodParameter.Name);
                        }, $PwyZsj ??= {"r":36541841,"p":[{"n":"methodParameter","p":119078913}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}))));
                        return $i1;
                    })());
                }, $IMlipe ??= {"r":47551889,"p":[{"n":"method","p":117571585}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), $.$$.SCG.IEnumerable$$($.$XBGm.LCICPC.ConfigurationDescriptorProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand));
            }
            //--TRIMMABLE-BOUNDARY-END(8590360252)
            
            static $H = 425660;
            static $h = 425660;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICPB.BinaryPacketProtocolCommands$$(TOwner); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885327548),
    {
      "r": 1310721,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "Type",
      "d": this.$h,
      "H": 12885327548,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12885327548),
//--TRIMMABLE-BOUNDARY-START(8590360252),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 8590360252,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590360252)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295392956),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 4295392956,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295392956)
  ],
  "s": [
    {
      "h": TOwner?.$h??1572864,
      "n": "TOwner"
    }
  ],
  "r": 1,
  "H": 425660,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Commands.LEDStripCommand<${TOwner?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Commands${separator}LEDStripCommand$${TOwner?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(425660)
        
        

        //--TRIMMABLE-BOUNDARY-START(1801916)
        $asm.$cls(`$CACm.LCIDLM.LEDStripDeviceSendDataModelTypeDescriptor`, ($self) => class LEDStripDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CACm.LCIDLM.LEDStripDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296769212)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296769212);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CACm.LCIDLM.LEDStripDeviceSendDataModelTypeDescriptor.GenerateProperties($.$CACm.LCIDLM.LEDStripDeviceSendDataModel, this, factory);
                    }, $CAuJcl ??= {"r":65537,"n":"","d":1801916,"h":0,"f":17825794}), 0, "LEDStripDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDStrip\\Models_LEDStripDeviceSendDataModel_LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceSendDataModelTypeDescriptorBuilder.g.cs", "LEDStripDeviceSendDataModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296769212)
            
            //--TRIMMABLE-BOUNDARY-START(12886703804)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886703804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886703804)
            
            //--TRIMMABLE-BOUNDARY-START(17181671100)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181671100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceSendDataModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceSendDataModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181671100)
            
            //--TRIMMABLE-BOUNDARY-START(8591736508)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591736508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CACm.LCIDLM.LEDStripDeviceSendDataModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$CACm.LCIDLM.LEDStripDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591736508)
            
            static $h = 1801916;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CACm.LCIDLM.LEDStripDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886703804),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1801916,
      "h": 12886703804,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886703804),
//--TRIMMABLE-BOUNDARY-START(17181671100),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1670844,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1801916,
      "h": 17181671100,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181671100),
//--TRIMMABLE-BOUNDARY-START(8591736508),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1670844,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1801916,
      "h": 8591736508,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591736508)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296769212),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1801916,
      "h": 4296769212,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296769212)
  ],
  "h": 1801916
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CACm.LCIDLM.LEDStripDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1801916)
        
        

        //--TRIMMABLE-BOUNDARY-START(3374780)
        $asm.$cls(`$CACm.LCIDLV.LEDStripMinorStatus`, ($self) => class LEDStripMinorStatus extends $.$hDPm.LCFCC$1.BaseComponent$$($.$ntej.LCICDV.MinorStatusViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(51542982332)
            /*MinorStatusViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(51542982332)
            
            //--TRIMMABLE-BOUNDARY-START(34363113148)
            /*string */ get OptimizedComponentName()
            {
                return "ledstripminorstatus";
            }
            //--TRIMMABLE-BOUNDARY-END(34363113148)
            
            //--TRIMMABLE-BOUNDARY-START(47248015036)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47248015036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$ntej.LCICDV.MinorStatusViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(47248015036)
            
            //--TRIMMABLE-BOUNDARY-START(12888276668)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888276668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceReceivedDataModel?*/ let __ca1__;
                /*LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripStatus?*/ let __ca2__;
                /*System.Drawing.Color[]*/ let __ca3__;
                /*var*/ let colors = $.$$.S.String.Join$5(", ", ((__ca1__ = ($.$cast(this.ViewModel.Device$1, $.$CACm.LCIDL$1.LEDStripDevice)).Received) !== null ? (((__ca2__ = __ca1__.Status) !== null ? (((__ca3__ = __ca2__.Colors) !== null ? ($.$sl.SL.Enumerable.Select$1($.$sdp.SD.Color, $.$$.S.String, __ca3__, new ($.$$.S.Func$$$($.$sdp.SD.Color, $.$$.S.String))().$ctor(this,  (/*color*/ color) =>
                {
                    return (() =>
                    {
                        var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 3);
                        $handler.AppendLiteral("#");
                        $handler.AppendFormatted($.$box(color.R, $.$$.S.Byte), null, "X2");
                        $handler.AppendFormatted($.$box(color.G, $.$$.S.Byte), null, "X2");
                        $handler.AppendFormatted($.$box(color.B, $.$$.S.Byte), null, "X2");
                        return $handler.ToStringAndClear                ();
                    })();
                }, $pkoAid ??= {"r":1310721,"p":[{"n":"color","p":65561}],"n":"","d":3374780,"h":0,"f":17825794})) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [0], null)) : $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [0], null)) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [0], null)) : $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [0], null)) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [0], null)) : $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [0], null)));
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "corner-2");
                __builder.AddAttribute$5(2, "style", " " + $.$strNN((`height:15px;background-image:linear-gradient(to right, ${$.$strNN(colors)})`)));
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(12888276668)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8593309372)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593309372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593309372)
            
            //--TRIMMABLE-BOUNDARY-START(8593309372)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8593309372)
            
            static $h = 3374780;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$ntej.LCICDV.MinorStatusViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542982332),
    {
      "p": 10585110,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068145852,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42953047740,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 3374780,
      "h": 51542982332,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51542982332),
//--TRIMMABLE-BOUNDARY-START(34363113148),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478211260,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 3374780,
      "h": 34363113148,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34363113148)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47248015036),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 3374780,
      "h": 47248015036,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47248015036),
//--TRIMMABLE-BOUNDARY-START(12888276668),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 3374780,
      "h": 12888276668,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12888276668)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593309372),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3374780,
      "h": 8593309372,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593309372)
  ],
  "h": 3374780
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Views.LEDStripMinorStatus`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Views${separator}LEDStripMinorStatus`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3374780)
        
        

        //--TRIMMABLE-BOUNDARY-START(1146556)
        $asm.$cls(`$CACm.LCIDLM.LEDStripDeviceReceivedDataModel`, ($self) => class LEDStripDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$CACm.LCIDLM.LEDStripStatus)
        {
            //--TRIMMABLE-BOUNDARY-START(4296113852)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296113852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296113852)
            
            //--TRIMMABLE-BOUNDARY-START(4296113852)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296113852)
            
            static $h = 1146556;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$CACm.LCIDLM.LEDStripStatus); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296113852),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1146556,
      "h": 4296113852,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296113852)
  ],
  "h": 1146556
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1146556)
        
        

        //--TRIMMABLE-BOUNDARY-START(1277628)
        $asm.$cls(`$CACm.LCIDLM.LEDStripDeviceReceivedDataModelTypeDescriptor`, ($self) => class LEDStripDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296244924)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296244924);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, this, factory);
                    }, $okHmpg ??= {"r":65537,"n":"","d":1277628,"h":0,"f":17825794}), 0, "LEDStripDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDStrip\\Models_LEDStripDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "LEDStripDeviceReceivedDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296244924)
            
            //--TRIMMABLE-BOUNDARY-START(12886179516)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886179516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$CACm.LCIDLM.LEDStripStatus).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886179516)
            
            //--TRIMMABLE-BOUNDARY-START(17181146812)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181146812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripStatus>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$CACm.LCIDLM.LEDStripStatus).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$CACm.LCIDLM.LEDStripStatus)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181146812)
            
            //--TRIMMABLE-BOUNDARY-START(8591212220)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591212220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591212220)
            
            static $h = 1277628;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886179516),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1277628,
      "h": 12886179516,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886179516),
//--TRIMMABLE-BOUNDARY-START(17181146812),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1146556,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1277628,
      "h": 17181146812,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181146812),
//--TRIMMABLE-BOUNDARY-START(8591212220),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1146556,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1277628,
      "h": 8591212220,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591212220)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296244924),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1277628,
      "h": 4296244924,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296244924)
  ],
  "h": 1277628
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1277628)
        
        

        //--TRIMMABLE-BOUNDARY-START(622268)
        $asm.$cls(`$CACm.LCIDL$1.LEDStripDataConverter`, ($self) => class LEDStripDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295589564)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295589564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295589564)
            
            //--TRIMMABLE-BOUNDARY-START(4295589564)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295589564)
            
            static $h = 622268;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295589564),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 622268,
      "h": 4295589564,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295589564)
  ],
  "h": 622268
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.LEDStripDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}LEDStripDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(622268)
        
        

        //--TRIMMABLE-BOUNDARY-START(2391740)
        $asm.$cls(`$CACm.LCIDLS.ILEDStripDeviceHubClient`, ($self) => class ILEDStripDeviceHubClient
        {
            static $h = 2391740;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2391740
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Services${separator}ILEDStripDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2391740)
        
        

        $asm.$typeProxy("$CACm.LCIDLM.LEDStripServiceModel", "$CACm.LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripServiceModel");
        $asm.$typeProxy("$CACm.LCIDLM.LEDStripDeviceScopeModel", "$CACm.LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceScopeModel");
        $asm.$typeProxy("$CACm.LCIDLS$1.LEDStripDeviceSettings", "$CACm.LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceSettings");
        $asm.$typeProxy("$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings", "$CACm.LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettings");
        $asm.$typeProxy("$CACm.LCIDLS.ILEDStripDeviceStatusHandler", "$CACm.LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripDeviceStatusHandler");
        $asm.$typeProxy("$CACm.LCIDLS.ILEDStripRemoteService", "$CACm.LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripRemoteService");
        //--TRIMMABLE-BOUNDARY-START(884412)
        $asm.$cls(`$CACm.LCIDLM.LEDStripDeviceModel`, ($self) => class LEDStripDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295851708)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295851708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295851708)
            
            //--TRIMMABLE-BOUNDARY-START(4295851708)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295851708)
            
            static $h = 884412;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295851708),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 884412,
      "h": 4295851708,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295851708)
  ],
  "h": 884412
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(884412)
        
        

        //--TRIMMABLE-BOUNDARY-START(2522812)
        $asm.$cls(`$CACm.LCIDLS.ILEDStripRemoteService`, ($self) => class ILEDStripRemoteService
        {
            static $h = 2522812;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2522812
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$CACm.LCIDLM.LEDStripServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$CACm.LCIDLM.LEDStripServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$CACm.LCIDLM.LEDStripServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$CACm.LCIDLM.LEDStripServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$CACm.LCIDLM.LEDStripServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$CACm.LCIDLM.LEDStripServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$CACm.LCIDLM.LEDStripServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$CACm.LCIDLM.LEDStripServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Services${separator}ILEDStripRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2522812)
        
        

        //--TRIMMABLE-BOUNDARY-START(1932988)
        $asm.$cls(`$CACm.LCIDLM.LEDStripServiceModel`, ($self) => class LEDStripServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296900284)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296900284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296900284)
            
            //--TRIMMABLE-BOUNDARY-START(4296900284)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4296900284)
            
            static $h = 1932988;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296900284),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 1932988,
      "h": 4296900284,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296900284)
  ],
  "h": 1932988
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1932988)
        
        

        //--TRIMMABLE-BOUNDARY-START(1408700)
        $asm.$cls(`$CACm.LCIDLM.LEDStripDeviceScopeModel`, ($self) => class LEDStripDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296375996)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296375996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296375996)
            
            //--TRIMMABLE-BOUNDARY-START(4296375996)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296375996)
            
            static $h = 1408700;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296375996),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1408700,
      "h": 4296375996,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296375996)
  ],
  "h": 1408700
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1408700)
        
        

        //--TRIMMABLE-BOUNDARY-START(2457276)
        $asm.$cls(`$CACm.LCIDLS.ILEDStripDeviceStatusHandler`, ($self) => class ILEDStripDeviceStatusHandler
        {
            static $h = 2457276;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2457276
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Services${separator}ILEDStripDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2457276)
        
        

        //--TRIMMABLE-BOUNDARY-START(2653884)
        $asm.$cls(`$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings`, ($self) => class LEDStripDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(51542261436)
            /*IOTDeviceInternalConfiguration<ushort>*/ Leds = null;
            //--TRIMMABLE-BOUNDARY-END(51542261436)
            
            //--TRIMMABLE-BOUNDARY-START(21477490364)
            /*IOTDeviceInternalConfiguration<byte>*/ Arrangement = null;
            //--TRIMMABLE-BOUNDARY-END(21477490364)
            
            //--TRIMMABLE-BOUNDARY-START(55837228732)
            /*IOTDeviceInternalConfigurations<byte>*/ Pattern = null;
            //--TRIMMABLE-BOUNDARY-END(55837228732)
            
            //--TRIMMABLE-BOUNDARY-START(17182523068)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182523068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182523068)
            
            //--TRIMMABLE-BOUNDARY-START(17182523068)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17182523068)
            
            static $h = 2653884;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542261436),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt16).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657359548,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73017097916,
        "f": 83886081
      },
      "n": "Leds",
      "d": 2653884,
      "h": 51542261436,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "lcnt",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 20,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51542261436),
//--TRIMMABLE-BOUNDARY-START(21477490364),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067424956,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64427163324,
        "f": 83886081
      },
      "n": "Arrangement",
      "d": 2653884,
      "h": 21477490364,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "larr",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 21,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21477490364),
//--TRIMMABLE-BOUNDARY-START(55837228732),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247294140,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81607032508,
        "f": 83886081
      },
      "n": "Pattern",
      "d": 2653884,
      "h": 55837228732,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "_lpat",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 22,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55837228732)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182523068),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2653884,
      "h": 17182523068,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182523068)
  ],
  "h": 2653884
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Settings${separator}LEDStripDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2653884)
        
        

        //--TRIMMABLE-BOUNDARY-START(2916028)
        $asm.$cls(`$CACm.LCIDLS$1.LEDStripDeviceSettings`, ($self) => class LEDStripDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $self, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(30067687100)
            /*int*/ static PalleteSize = 10;
            //--TRIMMABLE-BOUNDARY-END(30067687100)
            
            //--TRIMMABLE-BOUNDARY-START(21477752508)
            /*LEDColor[]*/ pallete = null;
            //--TRIMMABLE-BOUNDARY-END(21477752508)
            
            //--TRIMMABLE-BOUNDARY-START(25772719804)
            /*LEDColor[] */ get Palletes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182785212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.pallete;
            }
            /*LEDColor[] */ set Palletes(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657621692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.pallete = value;
                if (this.pallete.length < $.$CACm.LCIDLS$1.LEDStripDeviceSettings.PalleteSize)
                {
                    this.pallete = $.$sl.SL.Enumerable.ToArray($.$CACm.LCIDLS$1.LEDColor, $.$sl.SL.Enumerable.Concat($.$CACm.LCIDLS$1.LEDColor, this.pallete, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$CACm.LCIDLS$1.LEDColor), null, [(($.$CACm.LCIDLS$1.LEDStripDeviceSettings.PalleteSize - this.pallete.length) | 0)], null)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772719804)
            
            //--TRIMMABLE-BOUNDARY-START(8592850620)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592850620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592850620)
            
            //--TRIMMABLE-BOUNDARY-START(8592850620)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8592850620)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21477752508)
                this.pallete = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$CACm.LCIDLS$1.LEDColor), null, [$.$CACm.LCIDLS$1.LEDStripDeviceSettings.PalleteSize], null);
                //--TRIMMABLE-BOUNDARY-END(21477752508)
                
            }
            static $h = 2916028;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772719804),
    {
      "p": $.$typeArray($.$CACm.LCIDLS$1.LEDColor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182785212,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38657621692,
        "f": 83886081
      },
      "n": "Palletes",
      "d": 2916028,
      "h": 25772719804,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772719804)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30067687100),
    {
      "t": 655361,
      "n": "PalleteSize",
      "d": 2916028,
      "h": 30067687100,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30067687100),
//--TRIMMABLE-BOUNDARY-START(21477752508),
    {
      "t": $.$typeArray($.$CACm.LCIDLS$1.LEDColor).$h,
      "n": "pallete",
      "d": 2916028,
      "h": 21477752508,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477752508)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592850620),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2916028,
      "h": 8592850620,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592850620)
  ],
  "h": 2916028
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Settings${separator}LEDStripDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2916028)
        
        

        //--TRIMMABLE-BOUNDARY-START(163516)
        $asm.$cls(`$CACm.LCIDL.LEDStripDeviceModelDefinition`, ($self) => class LEDStripDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4295130812)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295130812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295130812)
            
            //--TRIMMABLE-BOUNDARY-START(4295130812)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295130812)
            
            static $h = 163516;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295130812),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 163516,
      "h": 4295130812,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295130812)
  ],
  "h": 163516
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.LEDStripDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}LEDStripDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(163516)
        
        

        //--TRIMMABLE-BOUNDARY-START(1539772)
        $asm.$cls(`$CACm.LCIDLM.LEDStripDeviceScopeModelTypeDescriptor`, ($self) => class LEDStripDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CACm.LCIDLM.LEDStripDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296507068)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296507068);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CACm.LCIDLM.LEDStripDeviceScopeModelTypeDescriptor.GenerateProperties($.$CACm.LCIDLM.LEDStripDeviceScopeModel, this, factory);
                    }, $kvqLVj ??= {"r":65537,"n":"","d":1539772,"h":0,"f":17825794}), 0, "LEDStripDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDStrip\\Models_LEDStripDeviceScopeModel_LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceScopeModelTypeDescriptorBuilder.g.cs", "LEDStripDeviceScopeModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296507068)
            
            //--TRIMMABLE-BOUNDARY-START(12886441660)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886441660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886441660)
            
            //--TRIMMABLE-BOUNDARY-START(17181408956)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181408956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceModel, LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceSettings, LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceSendDataModel, LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripDeviceStatusHandler, LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripDeviceHubClient, LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181408956)
            
            //--TRIMMABLE-BOUNDARY-START(8591474364)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591474364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CACm.LCIDLM.LEDStripDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLM.LEDStripDeviceScopeModel)))
                {
                    /*var*/ let result = $.$CACm.LCIDLM.LEDStripDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLM.LEDStripDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLM.LEDStripDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591474364)
            
            static $h = 1539772;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CACm.LCIDLM.LEDStripDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886441660),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1539772,
      "h": 12886441660,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886441660),
//--TRIMMABLE-BOUNDARY-START(17181408956),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1408700,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1539772,
      "h": 17181408956,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181408956),
//--TRIMMABLE-BOUNDARY-START(8591474364),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1408700,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1539772,
      "h": 8591474364,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591474364)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296507068),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1539772,
      "h": 4296507068,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296507068)
  ],
  "h": 1539772
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CACm.LCIDLM.LEDStripDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1539772)
        
        

        //--TRIMMABLE-BOUNDARY-START(1015484)
        $asm.$cls(`$CACm.LCIDLM.LEDStripDeviceModelTypeDescriptor`, ($self) => class LEDStripDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CACm.LCIDLM.LEDStripDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295982780)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295982780);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CACm.LCIDLM.LEDStripDeviceModelTypeDescriptor.GenerateProperties($.$CACm.LCIDLM.LEDStripDeviceModel, this, factory);
                    }, $WYOzmi ??= {"r":65537,"n":"","d":1015484,"h":0,"f":17825794}), 0, "LEDStripDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDStrip\\Models_LEDStripDeviceModel_LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceModelTypeDescriptorBuilder.g.cs", "LEDStripDeviceModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295982780)
            
            //--TRIMMABLE-BOUNDARY-START(12885917372)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885917372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885917372)
            
            //--TRIMMABLE-BOUNDARY-START(17180884668)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180884668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceModel, LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceSettings, LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceSendDataModel, LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripDeviceStatusHandler, LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripDeviceHubClient, LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180884668)
            
            //--TRIMMABLE-BOUNDARY-START(8590950076)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590950076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CACm.LCIDLM.LEDStripDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CACm.LCIDLM.LEDStripDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLM.LEDStripDeviceModel)))
                {
                    /*var*/ let result = $.$CACm.LCIDLM.LEDStripDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLM.LEDStripDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CACm.LCIDLM.LEDStripDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLM.LEDStripDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590950076)
            
            static $h = 1015484;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CACm.LCIDLM.LEDStripDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885917372),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1015484,
      "h": 12885917372,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885917372),
//--TRIMMABLE-BOUNDARY-START(17180884668),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 884412,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1015484,
      "h": 17180884668,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180884668),
//--TRIMMABLE-BOUNDARY-START(8590950076),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 884412,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1015484,
      "h": 8590950076,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590950076)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295982780),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1015484,
      "h": 4295982780,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295982780)
  ],
  "h": 1015484
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CACm.LCIDLM.LEDStripDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1015484)
        
        

        //--TRIMMABLE-BOUNDARY-START(2064060)
        $asm.$cls(`$CACm.LCIDLM.LEDStripServiceModelTypeDescriptor`, ($self) => class LEDStripServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CACm.LCIDLM.LEDStripServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297031356)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297031356);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CACm.LCIDLM.LEDStripServiceModelTypeDescriptor.GenerateProperties($.$CACm.LCIDLM.LEDStripServiceModel, this, factory);
                    }, $OXSOia ??= {"r":65537,"n":"","d":2064060,"h":0,"f":17825794}), 0, "LEDStripServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDStrip\\Models_LEDStripServiceModel_LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripServiceModelTypeDescriptorBuilder.g.cs", "LEDStripServiceModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297031356)
            
            //--TRIMMABLE-BOUNDARY-START(12886965948)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886965948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886965948)
            
            //--TRIMMABLE-BOUNDARY-START(17181933244)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181933244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceModel, LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceSettings, LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceSendDataModel, LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripDeviceStatusHandler, LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripDeviceHubClient, LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181933244)
            
            //--TRIMMABLE-BOUNDARY-START(8591998652)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591998652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CACm.LCIDLM.LEDStripServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CACm.LCIDLM.LEDStripServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLM.LEDStripServiceModel)))
                {
                    /*var*/ let result = $.$CACm.LCIDLM.LEDStripServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLM.LEDStripServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CACm.LCIDLM.LEDStripServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLM.LEDStripServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591998652)
            
            static $h = 2064060;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CACm.LCIDLM.LEDStripServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886965948),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2064060,
      "h": 12886965948,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886965948),
//--TRIMMABLE-BOUNDARY-START(17181933244),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1932988,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2064060,
      "h": 17181933244,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181933244),
//--TRIMMABLE-BOUNDARY-START(8591998652),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1932988,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2064060,
      "h": 8591998652,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591998652)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297031356),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2064060,
      "h": 4297031356,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297031356)
  ],
  "h": 2064060
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CACm.LCIDLM.LEDStripServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Models${separator}LEDStripServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2064060)
        
        

        //--TRIMMABLE-BOUNDARY-START(3047100)
        $asm.$cls(`$CACm.LCIDLS$1.LEDStripDeviceSettingsTypeDescriptor`, ($self) => class LEDStripDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CACm.LCIDLS$1.LEDStripDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298014396)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298014396);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CACm.LCIDLS$1.LEDStripDeviceSettingsTypeDescriptor.GenerateProperties($.$CACm.LCIDLS$1.LEDStripDeviceSettings, this, factory);
                    }, $TWqzzf ??= {"r":65537,"n":"","d":3047100,"h":0,"f":17825794}), 0, "LEDStripDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDStrip\\Settings_LEDStripDeviceSettings_LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceSettingsTypeDescriptorBuilder.g.cs", "LEDStripDeviceSettingsTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298014396)
            
            //--TRIMMABLE-BOUNDARY-START(12887948988)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887948988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Palletes"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CACm.LCIDLS$1.LEDStripDeviceSettings.$type, $.$discardRef(), "Palletes", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Palletes")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$CACm.LCIDLS$1.LEDColor), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Palletes";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CACm.LCIDLS$1.LEDStripDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$CACm.LCIDLS$1.LEDColor), ($.$cast(target, $.$CACm.LCIDLS$1.LEDStripDeviceSettings)).Palletes);
                        }, $sXBSWa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3047100,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CACm.LCIDLS$1.LEDStripDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Palletes = value.AsReference($.$typeArray($.$CACm.LCIDLS$1.LEDColor));
                        }, $MtjWYb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3047100,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887948988)
            
            //--TRIMMABLE-BOUNDARY-START(17182916284)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182916284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceModel, LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceSettings, LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceSendDataModel, LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripDeviceStatusHandler, LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripDeviceHubClient, LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).iSmartDeviceSettings));
                {
                    /*var*/ let _Palletes = _target.Palletes;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Palletes"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$CACm.LCIDLS$1.LEDColor)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$CACm.LCIDLS$1.LEDColor), $.$CACm.LCIDLS$1.LEDColor));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$CACm.LCIDLS$1.LEDColor), $.$CACm.LCIDLS$1.LEDColor, property, $.$ref(() => _Palletes, ($v) => _Palletes = $v, $.$typeArray($.$CACm.LCIDLS$1.LEDColor))))
                    {
                        _target.Palletes = _Palletes;
                        if (_Palletes !== null)
                        {
                            let $i6 = 0;
                            let $arr6 = _Palletes;
                            while ($i6 < $arr6.length)
                            {
                                let item = $arr6[$i6++];
                                /*var*/ let _item = $.$clone(item);
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$CACm.LCIDLS$1.LEDColor, () => _item, ($v) => _item = $v, null, true)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$CACm.LCIDLS$1.LEDColor), $.$CACm.LCIDLS$1.LEDColor, property, $.$ref(() => _Palletes, ($v) => _Palletes = $v, $.$typeArray($.$CACm.LCIDLS$1.LEDColor)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182916284)
            
            //--TRIMMABLE-BOUNDARY-START(8592981692)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592981692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CACm.LCIDLS$1.LEDStripDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLS$1.LEDStripDeviceSettings)))
                {
                    /*var*/ let result = $.$CACm.LCIDLS$1.LEDStripDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLS$1.LEDStripDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLS$1.LEDStripDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592981692)
            
            static $h = 3047100;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CACm.LCIDLS$1.LEDStripDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887948988),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3047100,
      "h": 12887948988,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887948988),
//--TRIMMABLE-BOUNDARY-START(17182916284),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2916028,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3047100,
      "h": 17182916284,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182916284),
//--TRIMMABLE-BOUNDARY-START(8592981692),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2916028,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3047100,
      "h": 8592981692,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592981692)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298014396),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3047100,
      "h": 4298014396,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298014396)
  ],
  "h": 3047100
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CACm.LCIDLS$1.LEDStripDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Settings${separator}LEDStripDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3047100)
        
        

        //--TRIMMABLE-BOUNDARY-START(2784956)
        $asm.$cls(`$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsTypeDescriptor`, ($self) => class LEDStripDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297752252)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297752252);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, this, factory);
                    }, $RoKlZa ??= {"r":65537,"n":"","d":2784956,"h":0,"f":17825794}), 0, "LEDStripDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LEDStrip\\Settings_LEDStripDeviceHardwareSettings_LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "LEDStripDeviceHardwareSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297752252)
            
            //--TRIMMABLE-BOUNDARY-START(12887686844)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887686844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Leds"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings.$type, $.$discardRef(), "Leds", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Leds")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt16), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Leds";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt16), ($.$cast(target, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings)).Leds);
                        }, $ozzAuf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2784956,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Leds = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt16));
                        }, $bRIECk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2784956,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Arrangement"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings.$type, $.$discardRef(), "Arrangement", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Arrangement")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Arrangement";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte), ($.$cast(target, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings)).Arrangement);
                        }, $XTsiqh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2784956,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Arrangement = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte));
                        }, $itmXla ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2784956,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Pattern"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings.$type, $.$discardRef(), "Pattern", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Pattern")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$$.S.Byte), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Pattern";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettings";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$$.S.Byte), ($.$cast(target, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings)).Pattern);
                        }, $hlkyGb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2784956,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Pattern = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$$.S.Byte));
                        }, $sVpWWd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2784956,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887686844)
            
            //--TRIMMABLE-BOUNDARY-START(17182654140)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182654140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceModel, LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceSettings, LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceSendDataModel, LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripDeviceStatusHandler, LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripDeviceHubClient, LivingThing.Core.IOT.Devices.LEDStrip.Services.ILEDStripRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService).iSmartDeviceHardwareSettings));
                {
                    /*var*/ let _Leds = _target.Leds;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Leds"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt16)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Leds, ($v) => _Leds = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt16))))
                    {
                        _target.Leds = _Leds;
                    }
                }
                {
                    /*var*/ let _Arrangement = _target.Arrangement;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Arrangement"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Arrangement, ($v) => _Arrangement = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte))))
                    {
                        _target.Arrangement = _Arrangement;
                    }
                }
                {
                    /*var*/ let _Pattern = _target.Pattern;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Pattern"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$$.S.Byte)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Pattern, ($v) => _Pattern = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$$.S.Byte))))
                    {
                        _target.Pattern = _Pattern;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182654140)
            
            //--TRIMMABLE-BOUNDARY-START(8592719548)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592719548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592719548)
            
            static $h = 2784956;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887686844),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2784956,
      "h": 12887686844,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887686844),
//--TRIMMABLE-BOUNDARY-START(17182654140),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2653884,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2784956,
      "h": 17182654140,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182654140),
//--TRIMMABLE-BOUNDARY-START(8592719548),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2653884,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2784956,
      "h": 8592719548,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592719548)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297752252),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2784956,
      "h": 4297752252,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297752252)
  ],
  "h": 2784956
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Settings.LEDStripDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Settings${separator}LEDStripDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2784956)
        
        

        //--TRIMMABLE-BOUNDARY-START(687804)
        $asm.$cls(`$CACm.LCIDL$1.LEDStripDevice`, ($self) => class LEDStripDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$CACm.LCIDLM.LEDStripStatus).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4295655100)
            $ctor$2(/*IIOTDeviceFamily<LEDStripDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*LEDStripDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295655100);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295655100)
            
            //--TRIMMABLE-BOUNDARY-START(21475524284)
            /*IconDescriptor */ get Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180556988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let icon = super.Icon;
                if (this.IsAvailable && (this.Received?.Status?.Colors ?? null) !== null)
                {
                    return $.$with(icon, ($clone) =>
                    {
                        $clone.Theme = $.$with(icon.Theme, ($clone) =>
                        {
                            $clone.BackgroundColor = (() =>
                            {
                                var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(0, 3);
                                $handler.AppendFormatted($.$box($.$$.System.Array.$ReadT1.call(this.Received.Status.Colors, 0).R, $.$$.S.Byte), null, "X2");
                                $handler.AppendFormatted($.$box($.$$.System.Array.$ReadT1.call(this.Received.Status.Colors, 0).G, $.$$.S.Byte), null, "X2");
                                $handler.AppendFormatted($.$box($.$$.System.Array.$ReadT1.call(this.Received.Status.Colors, 0).B, $.$$.S.Byte), null, "X2");
                                return $handler.ToStringAndClear                        ();
                            })();
                        });
                    });
                }
                return icon;
            }
            //--TRIMMABLE-BOUNDARY-END(21475524284)
            
            //--TRIMMABLE-BOUNDARY-START(8590622396)
            /*Task */ Clicked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590622396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceExtension.SendCommand$4(this, "Blank", (() =>
                {
                    //new $.$$.SCG.List$$($.$fPer.LCFCD$1.IObservableDataDescriptor)()
                    const $t1 = $.$$.SCG.List$$($.$fPer.LCFCD$1.IObservableDataDescriptor);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Add((() =>
                    {
                        //new $.$XBGm.LCICM.IOTDeviceDataPointModel$$($.$$.S.Int32)()
                        const $t2 = $.$XBGm.LCICM.IOTDeviceDataPointModel$$($.$$.S.Int32);
                        const $i2 = new $t2();
                        $i2.$ctor$7(0, 0);
                        $i2.Name = "save";
                        return $i2;
                    })());
                    $i1.Add((() =>
                    {
                        //new $.$XBGm.LCICM.IOTDeviceDataPointModel$$($.$$.S.Int32)()
                        const $t3 = $.$XBGm.LCICM.IOTDeviceDataPointModel$$($.$$.S.Int32);
                        const $i3 = new $t3();
                        $i3.$ctor$7(0, 0);
                        $i3.Name = "duration";
                        return $i3;
                    })());
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(8590622396)
            
            //--TRIMMABLE-BOUNDARY-START(25770491580)
            /*void */ SetAllColor(/*Color*/ color)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770491580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let command = $.$sl.SL.Enumerable.Single($.$XBGm.LCICI.IIOTDeviceProtocolCommand, this.Family$1.LCICI$IIOTDeviceFamily$Protocol.LCICI$IIOTDeviceProtocol$GetCommands(null), new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$$.S.Boolean))().$ctor(this,  (/**/ c) =>
                {
                    return c.LCICI$IIOTDeviceProtocolCommand$Name === "Set Color";
                }, $wRDyTd ??= {"r":262145,"p":[{"n":"c","p":27694481}],"n":"","d":687804,"h":0,"f":17825794}));
                _ = $.$XBGm.LCIC.IOTDeviceExtension.SendCommand$3(this, command, (() =>
                {
                    //new $.$$.SCG.List$$($.$fPer.LCFCD$1.IObservableDataDescriptor)()
                    const $t4 = $.$$.SCG.List$$($.$fPer.LCFCD$1.IObservableDataDescriptor);
                    const $i4 = new $t4();
                    $i4.$ctor$1();
                    $i4.Add((() =>
                    {
                        //new $.$XBGm.LCICM.IOTDeviceDataPointModel$$($.$sdp.SD.Color)()
                        const $t5 = $.$XBGm.LCICM.IOTDeviceDataPointModel$$($.$sdp.SD.Color);
                        const $i5 = new $t5();
                        $i5.$ctor$7(0, color);
                        $i5.Name = "Color";
                        return $i5;
                    })());
                    return $i4;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(25770491580)
            
            static $h = 687804;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDL$1.LEDStripDevice, $.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$CACm.LCIDLM.LEDStripStatus).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475524284),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180556988,
        "f": 50364417
      },
      "n": "Icon",
      "d": 687804,
      "h": 21475524284,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475524284)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590622396),
    {
      "r": 178454529,
      "n": "Clicked",
      "d": 687804,
      "h": 8590622396,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590622396),
//--TRIMMABLE-BOUNDARY-START(25770491580),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 65561
        }
      ],
      "n": "SetAllColor",
      "d": 687804,
      "h": 25770491580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770491580)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295655100),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$CACm.LCIDL$1.LEDStripDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 884412
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 687804,
      "h": 4295655100,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295655100)
  ],
  "h": 687804
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.LEDStripDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}LEDStripDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(687804)
        
        

        //--TRIMMABLE-BOUNDARY-START(753340)
        $asm.$cls(`$CACm.LCIDL$1.LEDStripDeviceDefinition`, ($self) => class LEDStripDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDL$1.LEDStripDevice, $.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$CACm.LCIDLM.LEDStripStatus)
        {
            //--TRIMMABLE-BOUNDARY-START(4295720636)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295720636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295720636)
            
            //--TRIMMABLE-BOUNDARY-START(4295720636)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295720636)
            
            static $h = 753340;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDL$1.LEDStripDevice, $.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$CACm.LCIDLM.LEDStripStatus); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295720636),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 753340,
      "h": 4295720636,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295720636)
  ],
  "h": 753340
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.LEDStripDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}LEDStripDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(753340)
        
        

        //--TRIMMABLE-BOUNDARY-START(818876)
        $asm.$cls(`$CACm.LCIDL$1.LEDStripDeviceFamily`, ($self) => class LEDStripDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDL$1.LEDStripDevice, $.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4295786172)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<LEDStripDeviceReceivedDataModel, LEDStripDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<LEDStripDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295786172);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295786172)
            
            static $h = 818876;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$CACm.LCIDL$1.LEDStripDevice, $.$CACm.LCIDLM.LEDStripServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CACm.LCIDLM.LEDStripDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CACm.LCIDLM.LEDStripDeviceModel, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel, $.$CACm.LCIDLS.ILEDStripDeviceStatusHandler, $.$CACm.LCIDLS.ILEDStripDeviceHubClient, $.$CACm.LCIDLS.ILEDStripRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295786172),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 818876,
      "h": 4295786172,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295786172)
  ],
  "h": 818876
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$CACm.LCIDL$1.LEDStripDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$CACm.LCIDL$1.LEDStripDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.LEDStripDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}LEDStripDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(818876)
        
        

        //--TRIMMABLE-BOUNDARY-START(3440316)
        $asm.$cls(`$CACm.LCIDLV.LEDStripViewRenderer`, ($self) => class LEDStripViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$CACm.LCIDL$1.LEDStripDevice, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298407612)
            $ctor$3(/*IOTRootViewModel*/ root)
            {
                super.$ctor$2(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298407612);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298407612)
            
            //--TRIMMABLE-BOUNDARY-START(8593374908)
            /*RenderFragment */ GetView(/*IClientUnitOfWork*/ ui, /*LEDStripDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>*/ clicked, /*Func<Task>*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593374908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceReceivedDataModel?*/ let __ca1__;
                /*LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripStatus?*/ let __ca2__;
                /*System.Drawing.Color[]*/ let __ca3__;
                if (type === 3/*DeviceViewType.Details*/)
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$CACm.LCIDLV.LEDStripDetailsPage, $.$CACm.LCIDLV.LEDStripDetailsViewModel, new $.$CACm.LCIDLV.LEDStripDetailsViewModel().$ctor$7(this.Root, device.OwnerScope, device), true, null);
                }
                else if (type === 0/*DeviceViewType.MinorStatus*/ && $.$$.S.Int32.op_GreaterThan(((__ca1__ = device.Received) !== null ? ((__ca2__ = __ca1__.Status) !== null ? ((__ca3__ = __ca2__.Colors) !== null ? $.$sl.SL.Enumerable.Count$1($.$sdp.SD.Color, __ca3__) : null) : null) : null), 0))
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$CACm.LCIDLV.LEDStripMinorStatus, $.$ntej.LCICDV.MinorStatusViewModel, new $.$ntej.LCICDV.MinorStatusViewModel().$ctor$7(this.Root, device.OwnerScope, device), true, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(8593374908)
            
            static $h = 3440316;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$CACm.LCIDL$1.LEDStripDevice, $.$CACm.LCIDLS$1.LEDStripDeviceSettings, $.$CACm.LCIDLS$1.LEDStripDeviceHardwareSettings, $.$CACm.LCIDLM.LEDStripDeviceReceivedDataModel, $.$CACm.LCIDLM.LEDStripDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593374908),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 687804
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 3440316,
      "h": 8593374908,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8593374908)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298407612),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3440316,
      "h": 4298407612,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298407612)
  ],
  "h": 3440316
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$CACm.LCIDL$1.LEDStripDevice), $.$ntej.LCICD$1.IDeviceViewRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Views.LEDStripViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Views${separator}LEDStripViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3440316)
        
        

        //--TRIMMABLE-BOUNDARY-START(3309244)
        $asm.$cls(`$CACm.LCIDLV.LEDStripDetailsViewModel`, ($self) => class LEDStripDetailsViewModel extends $.$ntej.LCICV.DeviceViewModel$$($.$CACm.LCIDL$1.LEDStripDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(38658014908)
            /*Color*/ color;
            //--TRIMMABLE-BOUNDARY-END(38658014908)
            
            //--TRIMMABLE-BOUNDARY-START(42952982204)
            /*Color */ get Color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68722785980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.color;
            }
            /*Color */ set Color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115967426236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdp.SD.Color.op_Inequality(this.color, value))
                {
                    this.color = value;
                    {
                        if (this.CurrentMode !== null)
                        {
                            _ = this.RunAnimation(this.CurrentMode, null);
                        }
                    }
                    this.RaisePropertyChanged$1("Color");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42952982204)
            
            //--TRIMMABLE-BOUNDARY-START(154622131900)
            /*double*/ Speed = 0;
            //--TRIMMABLE-BOUNDARY-END(154622131900)
            
            //--TRIMMABLE-BOUNDARY-START(51542916796)
            /*double*/ Duration = 0;
            //--TRIMMABLE-BOUNDARY-END(51542916796)
            
            //--TRIMMABLE-BOUNDARY-START(146032197308)
            /*void */ SetColor(/*Color*/ _color)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146032197308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Color = _color;
            }
            //--TRIMMABLE-BOUNDARY-END(146032197308)
            
            //--TRIMMABLE-BOUNDARY-START(25773113020)
            /*IEnumerable<string>*/ animations = null;
            //--TRIMMABLE-BOUNDARY-END(25773113020)
            
            //--TRIMMABLE-BOUNDARY-START(17183178428)
            $ctor$7(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*LEDStripDevice*/ device)
            {
                super.$ctor$6(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17183178428);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183178428)
            
            //--TRIMMABLE-BOUNDARY-START(30068080316)
            /*IEnumerable<string> */ get Animations()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132851388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.animations ??= $.$sl.SL.Enumerable.Select$1($.$$.SR.MethodInfo, $.$$.S.String, $.$CACm.LCIDLC.ICommandInterface.$type.GetMethods(), new ($.$$.S.Func$$$($.$$.SR.MethodInfo, $.$$.S.String))().$ctor(this,  (/**/ m) =>
                {
                    return $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle(m.Name);
                }, $djOuFc ??= {"r":1310721,"p":[{"n":"m","p":117571585}],"n":"","d":3309244,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(30068080316)
            
            //--TRIMMABLE-BOUNDARY-START(47247949500)
            /*string*/ CurrentMode = null;
            //--TRIMMABLE-BOUNDARY-END(47247949500)
            
            //--TRIMMABLE-BOUNDARY-START(98787557052)
            /*void */ ModeSelected(/*string*/ mode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787557052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CurrentMode = mode;
                _ = this.RunAnimation(mode, null);
            }
            //--TRIMMABLE-BOUNDARY-END(98787557052)
            
            //--TRIMMABLE-BOUNDARY-START(103082524348)
            /*Task */ RunAndSave()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082524348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.CurrentMode !== null)
                {
                    return this.RunAnimation(this.CurrentMode, true);
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(103082524348)
            
            //--TRIMMABLE-BOUNDARY-START(34363047612)
            /*Task */ ClearSaved()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363047612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.CurrentMode !== null)
                {
                    return this.RunAnimation(this.CurrentMode, false);
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(34363047612)
            
            //--TRIMMABLE-BOUNDARY-START(107377491644)
            /*Task *//*async*/  RunAnimation(/*string*/ _method, /*bool?*/ save)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107377491644);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    _method = _method ?? ($t1 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCC$IUIService$Prompt.LCFCC$IUIPromptService$Select($.$$.S.String, "Select Animation", "Cancel", null, $.$sl.SL.Enumerable.ToArray($.$$.S.String, this.Animations)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if (!$.$$.S.String.IsNullOrEmpty(_method))
                    {
                        this.CurrentMode = _method;
                        /*MethodInfo*/ let method = $.$CACm.LCIDLC.ICommandInterface.$type.GetMethod$12($.$$.S.String.Replace$3.call(this.CurrentMode, " ", ""));
                        /*List<IObservableDataDescriptor>*/ let parameters = new ($.$$.SCG.List$$($.$fPer.LCFCD$1.IObservableDataDescriptor))().$ctor$1();
                        /*var*/ let command = this.Device$1.Family$1.LCICI$IIOTDeviceFamily$DeviceDescriptor.CommunicationProtocol.GetCommandTypeByName(_method);
                        parameters.Add(new ($.$XBGm.LCICM.IOTDeviceDataPointModel$$($.$$.S.Int32))().$ctor$6($.$cast(command.GetDataPointPropertyByName("save"), $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor$$($.$$.S.Int32)), save === false ? 255 : (save === true ? 1 : 0)));
                        parameters.Add(new ($.$XBGm.LCICM.IOTDeviceDataPointModel$$($.$$.S.Int32))().$ctor$6($.$cast(command.GetDataPointPropertyByName("duration"), $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor$$($.$$.S.Int32)), $.$cast(this.Duration, $.$$.S.Int32)));
                        let $i2 = 0;
                        let $arr2 = method.GetParameters();
                        while ($i2 < $arr2.length)
                        {
                            let parameter = $arr2[$i2++];
                            if (parameter.ParameterType === $.$sdp.SD.Color.$type)
                            {
                                parameters.Add(new ($.$XBGm.LCICM.IOTDeviceDataPointModel$$($.$sdp.SD.Color))().$ctor$6($.$cast(command.GetDataPointPropertyByName(parameter.Name), $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor$$($.$sdp.SD.Color)), this.Color));
                            }
                            else if ($.$$.S.String.Contains$2.call(parameter.Name, "speed", 3/*StringComparison.InvariantCultureIgnoreCase*/) || $.$$.S.String.Contains$2.call(parameter.Name, "delay", 3/*StringComparison.InvariantCultureIgnoreCase*/))
                            {
                                parameters.Add(new ($.$XBGm.LCICM.IOTDeviceDataPointModel$$($.$$.S.Double))().$ctor$6($.$cast(command.GetDataPointPropertyByName(parameter.Name), $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor$$($.$$.S.Double)), (100 - this.Speed) * 10));
                            }
                            else if ($.$$.S.String.Contains$2.call(parameter.Name, "hue", 3/*StringComparison.InvariantCultureIgnoreCase*/))
                            {
                                parameters.Add(new ($.$XBGm.LCICM.IOTDeviceDataPointModel$$($.$$.S.Int32))().$ctor$6($.$cast(command.GetDataPointPropertyByName(parameter.Name), $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor$$($.$$.S.Int32)), $.$cast(this.Color.GetHue(), $.$$.S.Int32)));
                            }
                            else if (parameter.DefaultValue !== $.$$.S.DBNull.Value)
                            {
                                parameters.Add($.$XBGm.LCICM.IOTDeviceDataPointModel.From(parameter.DefaultValue, command.GetDataPointPropertyByName(parameter.Name)));
                            }
                        }
                        try
                        {
                            let $t3, $r3;
                            ($t3 = $.$XBGm.LCIC.IOTDeviceExtension.SendCommand$4(this.Device$1, method.Name, parameters), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        }
                        catch($e)
                        {
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107377491644)
            
            //--TRIMMABLE-BOUNDARY-START(21478145724)
            /*Task */ Animate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478145724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RunAnimation(null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(21478145724)
            
            //--TRIMMABLE-BOUNDARY-START(150327164604)
            /*Task *//*async*/  SetColor$1(/*int*/ index, /*Color*/ color)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150327164604);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let palletes = this.Device$1.Settings$1.Palletes;
                    $.$$.System.Array.$WriteT1.call(palletes, (() =>
                    {
                        //new $.$CACm.LCIDLS$1.LEDColor()
                        const $t4 = $.$CACm.LCIDLS$1.LEDColor;
                        const $i4 = new $t4();
                        $i4.$ctor$2();
                        $i4.A = color.A;
                        $i4.R = color.R;
                        $i4.G = color.G;
                        $i4.B = color.B;
                        return $i4;
                    })(), index);
                    this.Device$1.Settings$1.Palletes = palletes;
                    ($t5 = this.Device$1.OwnerScope.LCICI$IIOTDeviceScope$UpdateDevice($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDevice), [ this.Device$1 ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    this.RaisePropertyChanged$1("SetColor");
                });
            }
            //--TRIMMABLE-BOUNDARY-END(150327164604)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38658014908)
                this.color = $.$default($.$sdp.SD.Color);
                //--TRIMMABLE-BOUNDARY-END(38658014908)
                
            }
            static $h = 3309244;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.DeviceViewModel$$($.$CACm.LCIDL$1.LEDStripDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42952982204),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68722785980,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115967426236,
        "f": 83886081
      },
      "n": "Color",
      "d": 3309244,
      "h": 42952982204,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952982204),
//--TRIMMABLE-BOUNDARY-START(154622131900),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94492589756,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141737230012,
        "f": 83886081
      },
      "n": "Speed",
      "d": 3309244,
      "h": 154622131900,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154622131900),
//--TRIMMABLE-BOUNDARY-START(51542916796),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85902655164,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133147295420,
        "f": 83886081
      },
      "n": "Duration",
      "d": 3309244,
      "h": 51542916796,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51542916796),
//--TRIMMABLE-BOUNDARY-START(30068080316),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132851388,
        "f": 50331649
      },
      "n": "Animations",
      "d": 3309244,
      "h": 30068080316,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30068080316),
//--TRIMMABLE-BOUNDARY-START(47247949500),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77312720572,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124557360828,
        "f": 83886081
      },
      "n": "CurrentMode",
      "d": 3309244,
      "h": 47247949500,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247949500)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(146032197308),
    {
      "r": 65537,
      "p": [
        {
          "n": "_color",
          "p": 65561
        }
      ],
      "n": "SetColor",
      "d": 3309244,
      "h": 146032197308,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146032197308),
//--TRIMMABLE-BOUNDARY-START(98787557052),
    {
      "r": 65537,
      "p": [
        {
          "n": "mode",
          "p": 1310721
        }
      ],
      "n": "ModeSelected",
      "d": 3309244,
      "h": 98787557052,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98787557052),
//--TRIMMABLE-BOUNDARY-START(103082524348),
    {
      "r": 178454529,
      "n": "RunAndSave",
      "d": 3309244,
      "h": 103082524348,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103082524348),
//--TRIMMABLE-BOUNDARY-START(34363047612),
    {
      "r": 178454529,
      "n": "ClearSaved",
      "d": 3309244,
      "h": 34363047612,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34363047612),
//--TRIMMABLE-BOUNDARY-START(107377491644),
    {
      "r": 178454529,
      "p": [
        {
          "n": "_method",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "save",
          "p": $.$typeNullable($.$$.S.Boolean).$h,
          "f": 65
        }
      ],
      "n": "RunAnimation",
      "d": 3309244,
      "h": 107377491644,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(107377491644),
//--TRIMMABLE-BOUNDARY-START(21478145724),
    {
      "r": 178454529,
      "n": "Animate",
      "d": 3309244,
      "h": 21478145724,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478145724),
//--TRIMMABLE-BOUNDARY-START(150327164604),
    {
      "r": 178454529,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "color",
          "p": 65561
        }
      ],
      "n": "SetColor",
      "o": "@$1",
      "d": 3309244,
      "h": 150327164604,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(150327164604)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38658014908),
    {
      "t": 65561,
      "n": "color",
      "d": 3309244,
      "h": 38658014908,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38658014908),
//--TRIMMABLE-BOUNDARY-START(25773113020),
    {
      "t": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "n": "animations",
      "d": 3309244,
      "h": 25773113020,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25773113020)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183178428),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 687804
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 3309244,
      "h": 17183178428,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183178428)
  ],
  "h": 3309244
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IChartable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Views.LEDStripDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Views${separator}LEDStripDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3309244)
        
        

        //--TRIMMABLE-BOUNDARY-START(3243708)
        $asm.$cls(`$CACm.LCIDLV.LEDStripDetailsPage`, ($self) => class LEDStripDetailsPage extends $.$hDPm.LCFCC$1.BaseComponent$$($.$CACm.LCIDLV.LEDStripDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(51542851260)
            /*string */ get OptimizedComponentName()
            {
                return "ledstripdetailspage";
            }
            //--TRIMMABLE-BOUNDARY-END(51542851260)
            
            //--TRIMMABLE-BOUNDARY-START(64427753148)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427753148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$CACm.LCIDLV.LEDStripDetailsViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(64427753148)
            
            //--TRIMMABLE-BOUNDARY-START(68722720444)
            /*LEDStripDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(68722720444)
            
            //--TRIMMABLE-BOUNDARY-START(47247883964)
            /*ValueTask<bool> */ OnSelected(/*DataListSelection<string>*/ selection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247883964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ViewModel.ModeSelected($.$sl.SL.Enumerable.First$1($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.S.String), selection.SelectedItems).LCFCCD$1$IDataListItemContext$$$Data);
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(47247883964)
            
            //--TRIMMABLE-BOUNDARY-START(21478080188)
            /*Task *//*async*/  ChooseColor(/*int*/ index)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21478080188);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*Color*/ let color = ($t2 = this.ViewModel.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCC$IUIService$Prompt.LCFCC$IUIPromptService$Prompt$1($.$hDPm.LCFCCC$9.ColorWheel, $.$sdp.SD.Color, "Choose Pallete Color", 1/*UIPromptFlags.OK*/ | 2/*UIPromptFlags.Cancel*/, $.$$.ST$1.CancellationToken.None, new ($.$$.S.Action$$($.$hDPm.LCFCCC$9.ColorWheel))().$ctor(this,  (/*wheel*/ wheel) =>
                    {
                        return wheel.Class = "d-block mg-a";
                    }, $gloBBf ??= {"r":65537,"p":[{"n":"wheel","p":10507946}],"n":"","d":3243708,"h":0,"f":17825794})), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    ($t3 = this.ViewModel.SetColor$1(index, color), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21478080188)
            
            //--TRIMMABLE-BOUNDARY-START(17183112892)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183112892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$CACm.LCIDL$1.LEDStripDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$CACm.LCIDL$1.LEDStripDevice), this.ViewModel));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    /*LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripDeviceReceivedDataModel?*/ let __ca1__;
                    /*LivingThing.Core.IOT.Devices.LEDStrip.Models.LEDStripStatus?*/ let __ca2__;
                    /*System.Drawing.Color[]*/ let __ca3__;
                    /*var*/ let colors = $.$$.S.String.Join$5(", ", ((__ca1__ = this.ViewModel.Device$1.Received) !== null ? (((__ca2__ = __ca1__.Status) !== null ? (((__ca3__ = __ca2__.Colors) !== null ? ($.$sl.SL.Enumerable.Select$1($.$sdp.SD.Color, $.$$.S.String, __ca3__, new ($.$$.S.Func$$$($.$sdp.SD.Color, $.$$.S.String))().$ctor(this,  (/**/ color) =>
                    {
                        return (() =>
                        {
                            var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 3);
                            $handler.AppendLiteral("#");
                            $handler.AppendFormatted($.$box(color.R, $.$$.S.Byte), null, "X2");
                            $handler.AppendFormatted($.$box(color.G, $.$$.S.Byte), null, "X2");
                            $handler.AppendFormatted($.$box(color.B, $.$$.S.Byte), null, "X2");
                            return $handler.ToStringAndClear                    ();
                        })();
                    }, $toXNze ??= {"r":1310721,"p":[{"n":"color","p":65561}],"n":"","d":3243708,"h":0,"f":17825794})) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [0], null)) : $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [0], null)) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [0], null)) : $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [0], null)) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [0], null)) : $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [0], null)));
                    __builder2.OpenElement(3, "div");
                    __builder2.AddAttribute$5(4, "style", " " + $.$strNN((`height:5px;background-image:linear-gradient(to right, ${$.$strNN(colors)})`)));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(5, "\r\n    ");
                    __builder2.OpenElement(6, "div");
                    __builder2.AddAttribute$5(7, "class", "flex bdb pdb-2 mgb-2");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCC$9.ColorWheel, 8);
                    __builder2.AddComponentParameter(9, "Class", "mg-a");
                    __builder2.AddComponentParameter(10, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 200), $.$$.S.Int32));
                    __builder2.AddComponentParameter(11, "Width", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 200), $.$$.S.Int32));
                    __builder2.AddComponentParameter(12, "Color", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sdp.SD.Color, this.ViewModel.Color));
                    __builder2.AddComponentParameter(13, "ColorChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$sdp.SD.Color), $.$mac.MAC.EventCallback.Factory.Create$6($.$sdp.SD.Color, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$sdp.SD.Color, this, new ($.$$.S.Action$$($.$sdp.SD.Color))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.ViewModel.Color = __value;
                    }, $Gruozj ??= {"r":65537,"p":[{"n":"__value","p":65561}],"n":"","d":3243708,"h":0,"f":17825794}), this.ViewModel.Color))));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    /*var*/ let settings = this.ViewModel.Device$1.Settings$1;
                    if (settings === null)
                    {
                        settings = new $.$CACm.LCIDLS$1.LEDStripDeviceSettings().$ctor$4();
                    }
                    /*var*/ let palletes = settings.Palletes;
                    /*int*/ let index = 0;
                    for(/*int*/ let i = 0; i < $.trunc($.$CACm.LCIDLS$1.LEDStripDeviceSettings.PalleteSize / 5); i++)
                    {
                        /*var*/ let ii = i;
                        __builder2.OpenElement(14, "div");
                        __builder2.AddAttribute$5(15, "class", "flex flex-center-x");
                        __builder2.SetKey($.$box(ii, $.$$.S.Int32));
                        let $en4 = $.$sl.SL.Enumerable.Take($.$CACm.LCIDLS$1.LEDColor, $.$sl.SL.Enumerable.Skip($.$CACm.LCIDLS$1.LEDColor, palletes, ((ii * 5) | 0)), 5).SCG$IEnumerable$$$GetEnumerator();
                        while ($en4.SC$1$IEnumerator$MoveNext())
                        {
                            let pallete = $en4.SCG$IEnumerator$$$Current;
                            {
                                /*int*/ let mIndex = index++;
                                /*var*/ let p = $.$clone(pallete);
                                /*var*/ let color = $.$sdp.SD.Color.FromArgb$1($.$cast(pallete.R, $.$$.S.Int32), $.$cast(pallete.G, $.$$.S.Int32), $.$cast(pallete.B, $.$$.S.Int32));
                                __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 16);
                                __builder2.AddComponentParameter(17, "Style", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, (() =>
                                {
                                    var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 4);
                                    $handler.AppendLiteral("background-color:#");
                                    $handler.AppendFormatted($.$box(color.R, $.$$.S.Byte), null, "X2");
                                    $handler.AppendFormatted($.$box(color.G, $.$$.S.Byte), null, "X2");
                                    $handler.AppendFormatted($.$box(color.B, $.$$.S.Byte), null, "X2");
                                    $handler.AppendFormatted($.$box(color.A, $.$$.S.Byte), null, "X2");
                                    return $handler.ToStringAndClear                            ();
                                })()));
                                __builder2.AddComponentParameter(18, "Class", "hx-04 wx-04 round bd bdw-2 mgx-2 mgy-1 shadow");
                                __builder2.AddComponentParameter(19, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                {
                                    return this.ViewModel.SetColor(color);
                                }, $KOeLCf ??= {"r":65537,"n":"","d":3243708,"h":0,"f":17825794}))));
                                __builder2.AddComponentParameter(20, "OnLongClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback, $.$mac.MAC.EventCallback.Factory.Create$4(this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                {
                                    return this.ChooseColor(mIndex);
                                }, $mSLtHi ??= {"r":178454529,"n":"","d":3243708,"h":0,"f":17825794}))));
                                __builder2.SetKey($.$box(index, $.$$.S.Int32));
                                __builder2.CloseComponent();
                            }
                        }
                        __builder2.CloseElement();
                    }
                    __builder2.OpenComponent$1($.$macw.MACF.EditForm, 21);
                    __builder2.AddComponentParameter(22, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, $.$CACm.LCIDLV.LEDStripDetailsPage.dummyModel));
                    __builder2.AddAttribute$3(23, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCI$2.InputField, 24);
                            __builder3.AddComponentParameter(25, "Arrangement", "InputFieldArrangement.Vertical");
                            __builder3.AddComponentParameter(26, "Class", "mgx mgt");
                            __builder3.AddComponentParameter(27, "label-class", "text-center");
                            __builder3.AddAttribute$3(28, "Label", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(29, "Speed (");
                                __builder4.AddContent$3(30, $.$box(this.ViewModel.Speed, $.$$.S.Double));
                                __builder4.AddContent$4(31, " %)");
                            }), $AJUERi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":3243708,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(32, "Field", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                $.$CACm._LCIDLVL.TypeInference.CreateInputEditor_0($.$$.S.Double, __builder4, 33, 34, 6n, 35, $.$box(this.ViewModel.Speed, $.$$.S.Double), 36, "0", 37, "100", 38, this.ViewModel.Speed, 39, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Double, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Double, this, new ($.$$.S.Action$$($.$$.S.Double))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return this.ViewModel.Speed = __value;
                                }, $lIsRyc ??= {"r":65537,"p":[{"n":"__value","p":1179649}],"n":"","d":3243708,"h":0,"f":17825794}), this.ViewModel.Speed)), 40, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                {
                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "ViewModel"), "Speed"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                }, $QqzZdl ??= {"r":38797349,"n":"","d":3243708,"h":0,"f":17825794})).Invoke()));
                            }), $eshfoh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":3243708,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(41, "\r\n        ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCI$2.InputField, 42);
                            __builder3.AddComponentParameter(43, "Arrangement", "InputFieldArrangement.Vertical");
                            __builder3.AddComponentParameter(44, "Class", "mgx mgt");
                            __builder3.AddComponentParameter(45, "label-class", "text-center");
                            __builder3.AddAttribute$3(46, "Label", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(47, "Duration (");
                                __builder4.AddContent$3(48, $.$box(this.ViewModel.Duration, $.$$.S.Double));
                                __builder4.AddContent$4(49, " s)");
                            }), $JUqUlk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":3243708,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(50, "Field", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                $.$CACm._LCIDLVL.TypeInference.CreateInputEditor_1($.$$.S.Double, __builder4, 51, 52, 6n, 53, $.$box(this.ViewModel.Speed, $.$$.S.Double), 54, "0", 55, "10", 56, this.ViewModel.Duration, 57, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Double, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Double, this, new ($.$$.S.Action$$($.$$.S.Double))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return this.ViewModel.Duration = __value;
                                }, $MyEcXc ??= {"r":65537,"p":[{"n":"__value","p":1179649}],"n":"","d":3243708,"h":0,"f":17825794}), this.ViewModel.Duration)), 58, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                {
                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "ViewModel"), "Duration"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                }, $RjQqui ??= {"r":38797349,"n":"","d":3243708,"h":0,"f":17825794})).Invoke()));
                            }), $QpmaEj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":3243708,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $EMiadb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":3243708,"h":0,"f":17825794});
                    }), $UoJxLj ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":3243708,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(59, "\r\n    ");
                    $.$CACm._LCIDLVL.TypeInference.CreateDataList_2($.$$.S.String, __builder2, 60, 61, this.ViewModel.Animations, 62, this, 63, true, 64, 5, 65, "true", 66, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.String, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.String))))().$ctor(this,  (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(67, "div");
                            __builder3.AddAttribute$5(68, "class", "text-center row");
                            __builder3.OpenElement(69, "div");
                            __builder3.AddAttribute$5(70, "class", "text-center stack");
                            __builder3.OpenElement(71, "b");
                            __builder3.AddAttribute$5(72, "class", "mgy-a");
                            __builder3.AddContent$4(73, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.String, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.String)).op_Implicit$1(context));
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            if ($.$$.S.String.op_Equality(this.ViewModel.CurrentMode, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.String, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.String)).op_Implicit$1(context)))
                            {
                                __builder3.OpenElement(74, "div");
                                __builder3.AddAttribute$5(75, "class", "col-a");
                                __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.Menu, 76);
                                __builder3.AddAttribute$3(77, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*_*/ _0) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 78);
                                        __builder4.AddAttribute$3(79, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                            {
                                                __builder5.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 80);
                                                __builder5.AddComponentParameter(81, "Class", "hx-02 wx-02 round pd-1 fsz-11 mdi mdi-content-save");
                                                __builder5.AddComponentParameter(82, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                __builder5.AddComponentParameter(83, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this.ViewModel, this.ViewModel.RunAndSave))));
                                                __builder5.CloseComponent();
                                            }, $RfTeDj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":3243708,"h":0,"f":17825794});
                                        }), $eIBOOf ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":3243708,"h":0,"f":17825794}));
                                        __builder4.CloseComponent();
                                        __builder4.AddMarkupContent(84, "\r\n                        ");
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 85);
                                        __builder4.AddAttribute$3(86, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                            {
                                                __builder5.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 87);
                                                __builder5.AddComponentParameter(88, "Class", "hx-02 wx-02 round pd-1 fsz-11 mdi mdi-delete");
                                                __builder5.AddComponentParameter(89, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Fatal));
                                                __builder5.AddComponentParameter(90, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this.ViewModel, this.ViewModel.ClearSaved))));
                                                __builder5.CloseComponent();
                                            }, $PnHgGe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":3243708,"h":0,"f":17825794});
                                        }), $MWnYnc ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":3243708,"h":0,"f":17825794}));
                                        __builder4.CloseComponent();
                                    }, $houIBf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":3243708,"h":0,"f":17825794});
                                }), $EUxhOk ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":3243708,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                                __builder3.CloseElement();
                            }
                            __builder3.CloseElement();
                        }, $IcRJMj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":3243708,"h":0,"f":17825794});
                    }, $PBSfej ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.String, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.String)).$h}],"n":"","d":3243708,"h":0,"f":17825794}));
                }), $EbpTXc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3243708,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17183112892)
            
            //--TRIMMABLE-BOUNDARY-START(25773047484)
            /*object*/ static dummyModel = null;
            //--TRIMMABLE-BOUNDARY-END(25773047484)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<string>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<string>)
            LCFCCD$1$IDataListSelectableController$System$String$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(12888145596)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888145596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888145596)
            
            //--TRIMMABLE-BOUNDARY-START(12888145596)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12888145596)
            
            //--TRIMMABLE-BOUNDARY-START(8593178300)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593178300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(25773047484)
                    this.dummyModel = {  };
                    //--TRIMMABLE-BOUNDARY-END(25773047484)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8593178300)
            
            static $h = 3243708;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$CACm.LCIDLV.LEDStripDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542851260),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362982076,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 3243708,
      "h": 51542851260,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51542851260),
//--TRIMMABLE-BOUNDARY-START(68722720444),
    {
      "p": 3309244,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952916668,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132785852,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 3243708,
      "h": 68722720444,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68722720444)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64427753148),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 3243708,
      "h": 64427753148,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64427753148),
//--TRIMMABLE-BOUNDARY-START(47247883964),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$$.S.String).$h
        }
      ],
      "n": "OnSelected",
      "d": 3243708,
      "h": 47247883964,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47247883964),
//--TRIMMABLE-BOUNDARY-START(21478080188),
    {
      "r": 178454529,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "ChooseColor",
      "d": 3243708,
      "h": 21478080188,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(21478080188),
//--TRIMMABLE-BOUNDARY-START(17183112892),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 3243708,
      "h": 17183112892,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17183112892)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25773047484),
    {
      "t": 131073,
      "n": "dummyModel",
      "d": 3243708,
      "h": 25773047484,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25773047484)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888145596),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3243708,
      "h": 12888145596,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888145596)
  ],
  "h": 3243708
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$$.S.String), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$$.S.String), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDStrip.Views.LEDStripDetailsPage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDStrip${separator}Views${separator}LEDStripDetailsPage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3243708)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(32444)
