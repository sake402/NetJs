
//--TRIMMABLE-BOUNDARY-START(47194)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $AxHbCk;
    let $AKBNLf;
    let $UcgJuj;
    let $vvqOCi;
    let $jOPDdc;
    let $yIxOTj;
    let $FisiDb;
    let $AbJAUc;
    let $TFmZpe;
    let $nYhsJi;
    let $aRqFba;
    let $YUHBBc;
    let $lDouNc;
    let $oSwZAa;
    let $GKmrCi;
    let $CDfgWd;
    let $KKXJZc;
    let $JABGEb;
    let $RnpCSh;
    let $MYhcri;
    let $jTRAQh;
    let $Ofvqzh;
    let $hbvQoh;
    let $JwsnEa;
    let $pbzKZe;
    let $UbvSKg;
    let $ptpWHb;
    let $bvBjpf;
    let $GekTOj;
    let $nsnOBb;
    let $dIguIg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.LoadCell", 
    {
  "h": 47194,
  "f": "LivingThing.Core.IOT.Devices.LoadCell",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.LoadCell",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.LoadCell",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5Mb2FkQ2VsbC5Mb2FkQ2VsbERldmljZSI6IHsNCiAgICAgICJDYXRlZ29yaWVzIjogWyAiU21hcnQgSG9tZSIgXSwNCiAgICAgICJOYW1lIjogIkxvYWRDZWxsIiwNCiAgICAgICJEZXNjcmlwdGlvbiI6ICIiLA0KICAgICAgIkJhbm5lckltYWdlIjogIn4vTG9hZENlbGwvaW1nL2Jhbm5lci5qcGciLA0KICAgICAgIkljb24iOiB7ICJOYW1lIjogIm1kaSBtZGktZWxlY3RyaWMtc3dpdGNoIiB9LA0KICAgICAgIlRoZW1lQ29sb3IiOiAiI2Q3N2JiYSIsDQogICAgICAiRmxhZ3MiOiAiRmVhdHVyZWQsUHVibGlzaGVkIiwNCiAgICAgICJTZWN1cml0aWVzIjogIkNoYWxsZW5nZUhhbmRTaGFrZUF1dGhlbnRpY2F0aW9uUHJvdG9jb2wsQWR2YW5jZWRFbmNyeXB0aW9uU3RhbmRhcmQsRWxsaXB0aWNDdXJ2ZUZpcm13YXJlVXBkYXRlU2lnbmluZyINCiAgICB9DQogIH0NCn0="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1030234)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class LoadCellDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295997530)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295997530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$LGQP.LCIDLMS.LoadCellStatusModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295997530)
            
            static $h = 1030234;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295997530),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1030234,
      "h": 4295997530,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295997530)
  ],
  "h": 1030234
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1030234)
        
        

        //--TRIMMABLE-BOUNDARY-START(768090)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellDeviceModelCustomAttributesProvider`, ($self) => class LoadCellDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295735386)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295735386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295735386)
            
            static $h = 768090;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295735386),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 768090,
      "h": 4295735386,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295735386)
  ],
  "h": 768090
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(768090)
        
        

        //--TRIMMABLE-BOUNDARY-START(1292378)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellDeviceScopeModelCustomAttributesProvider`, ($self) => class LoadCellDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296259674)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296259674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296259674)
            
            static $h = 1292378;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296259674),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1292378,
      "h": 4296259674,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296259674)
  ],
  "h": 1292378
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1292378)
        
        

        //--TRIMMABLE-BOUNDARY-START(112730)
        $asm.$cls(`$LGQP.LCIDL._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295080026)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295080026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$LGQP.LCIDL.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295080026)
            
            static $h = 112730;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295080026),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 112730,
      "h": 4295080026,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295080026)
  ],
  "h": 112730
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(112730)
        
        

        //--TRIMMABLE-BOUNDARY-START(2930778)
        $asm.$cls(`$LGQP.LCIDLS$1.LoadCellDeviceSettingsCustomAttributesProvider`, ($self) => class LoadCellDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297898074)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297898074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297898074)
            
            static $h = 2930778;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297898074),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2930778,
      "h": 4297898074,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297898074)
  ],
  "h": 2930778
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Settings${separator}LoadCellDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2930778)
        
        

        //--TRIMMABLE-BOUNDARY-START(3127386)
        $asm.$cls(`$LGQP.LCIDL.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298094682)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298094682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LGQP.LCIDLM.LoadCellDeviceModelTypeDescriptorBuilder.Register();
                $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$LGQP.LCIDLM.LoadCellDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$LGQP.LCIDLM.LoadCellDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$LGQP.LCIDLM.LoadCellServiceModelTypeDescriptorBuilder.Register();
                $.$LGQP.LCIDLMS.LoadCellStatusModelTypeDescriptorBuilder.Register();
                $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$LGQP.LCIDLS$1.LoadCellDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298094682)
            
            static $h = 3127386;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298094682),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3127386,
      "h": 4298094682,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298094682)
  ],
  "h": 3127386
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3127386)
        
        

        //--TRIMMABLE-BOUNDARY-START(243802)
        $asm.$cls(`$LGQP.LCIDL.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295211098)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295211098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$LGQP.LCIDLM.LoadCellDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$LGQP.LCIDLM.LoadCellDeviceModelCustomAttributesProvider, $.$LGQP.LCIDLM.LoadCellDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModelCustomAttributesProvider, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$LGQP.LCIDLM.LoadCellDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$LGQP.LCIDLM.LoadCellDeviceScopeModelCustomAttributesProvider, $.$LGQP.LCIDLM.LoadCellDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$LGQP.LCIDLM.LoadCellDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$LGQP.LCIDLM.LoadCellDeviceSendDataModelCustomAttributesProvider, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$LGQP.LCIDLM.LoadCellServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$LGQP.LCIDLM.LoadCellServiceModelCustomAttributesProvider, $.$LGQP.LCIDLM.LoadCellServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$LGQP.LCIDLMS.LoadCellStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$LGQP.LCIDLMS.LoadCellStatusModelCustomAttributesProvider, $.$LGQP.LCIDLMS.LoadCellStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettingsCustomAttributesProvider, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$LGQP.LCIDLS$1.LoadCellDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$LGQP.LCIDLS$1.LoadCellDeviceSettingsCustomAttributesProvider, $.$LGQP.LCIDLS$1.LoadCellDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295211098)
            
            static $h = 243802;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295211098),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 243802,
      "h": 4295211098,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295211098)
  ],
  "h": 243802
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(243802)
        
        

        //--TRIMMABLE-BOUNDARY-START(1554522)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellDeviceSendDataModelCustomAttributesProvider`, ($self) => class LoadCellDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296521818)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296521818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceCommandsModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296521818)
            
            static $h = 1554522;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296521818),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1554522,
      "h": 4296521818,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296521818)
  ],
  "h": 1554522
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1554522)
        
        

        //--TRIMMABLE-BOUNDARY-START(1161306)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class LoadCellDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591095898)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591095898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $vvqOCi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1161306,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591095898)
            
            //--TRIMMABLE-BOUNDARY-START(4296128602)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296128602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296128602)
            
            //--TRIMMABLE-BOUNDARY-START(4296128602)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296128602)
            
            static $h = 1161306;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591095898),
    {
      "r": 65537,
      "n": "Register",
      "d": 1161306,
      "h": 8591095898,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591095898)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296128602),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1161306,
      "h": 4296128602,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296128602)
  ],
  "h": 1161306
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1161306)
        
        

        //--TRIMMABLE-BOUNDARY-START(1423450)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellDeviceScopeModelTypeDescriptorBuilder`, ($self) => class LoadCellDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591358042)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591358042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$LGQP.LCIDLM.LoadCellDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$LGQP.LCIDLM.LoadCellDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $FisiDb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1423450,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$LGQP.LCIDLM.LoadCellDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591358042)
            
            //--TRIMMABLE-BOUNDARY-START(4296390746)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296390746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296390746)
            
            //--TRIMMABLE-BOUNDARY-START(4296390746)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296390746)
            
            static $h = 1423450;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591358042),
    {
      "r": 65537,
      "n": "Register",
      "d": 1423450,
      "h": 8591358042,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591358042)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296390746),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1423450,
      "h": 4296390746,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296390746)
  ],
  "h": 1423450
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1423450)
        
        

        //--TRIMMABLE-BOUNDARY-START(1685594)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class LoadCellDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591620186)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591620186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$LGQP.LCIDLM.LoadCellDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$LGQP.LCIDLM.LoadCellDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $AKBNLf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1685594,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$LGQP.LCIDLM.LoadCellDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591620186)
            
            //--TRIMMABLE-BOUNDARY-START(4296652890)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296652890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296652890)
            
            //--TRIMMABLE-BOUNDARY-START(4296652890)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296652890)
            
            static $h = 1685594;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591620186),
    {
      "r": 65537,
      "n": "Register",
      "d": 1685594,
      "h": 8591620186,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591620186)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296652890),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1685594,
      "h": 4296652890,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296652890)
  ],
  "h": 1685594
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1685594)
        
        

        //--TRIMMABLE-BOUNDARY-START(1816666)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellServiceModelCustomAttributesProvider`, ($self) => class LoadCellServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296783962)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296783962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296783962)
            
            static $h = 1816666;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296783962),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1816666,
      "h": 4296783962,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296783962)
  ],
  "h": 1816666
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1816666)
        
        

        //--TRIMMABLE-BOUNDARY-START(2668634)
        $asm.$cls(`$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class LoadCellDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297635930)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297635930)
            
            //--TRIMMABLE-BOUNDARY-START(8592603226)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592603226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Calibration", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Key = "cal";
                            $i3.Order = (20);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $TFmZpe ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2668634,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $nYhsJi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2668634,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592603226)
            
            static $h = 2668634;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592603226),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2668634,
      "h": 8592603226,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592603226)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297635930),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2668634,
      "h": 4297635930,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297635930)
  ],
  "h": 2668634
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Settings${separator}LoadCellDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2668634)
        
        

        //--TRIMMABLE-BOUNDARY-START(2799706)
        $asm.$cls(`$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class LoadCellDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592734298)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592734298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $MYhcri ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2799706,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592734298)
            
            //--TRIMMABLE-BOUNDARY-START(4297767002)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297767002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297767002)
            
            //--TRIMMABLE-BOUNDARY-START(4297767002)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297767002)
            
            static $h = 2799706;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592734298),
    {
      "r": 65537,
      "n": "Register",
      "d": 2799706,
      "h": 8592734298,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592734298)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297767002),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2799706,
      "h": 4297767002,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297767002)
  ],
  "h": 2799706
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Settings${separator}LoadCellDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2799706)
        
        

        //--TRIMMABLE-BOUNDARY-START(2078810)
        $asm.$cls(`$LGQP.LCIDLMS.LoadCellStatusModelCustomAttributesProvider`, ($self) => class LoadCellStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297046106)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297046106)
            
            //--TRIMMABLE-BOUNDARY-START(8592013402)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592013402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$LGQP.LCIDLMS.LoadCellStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Sample", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Weight", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.ConvertType = ($.$$.S.Single.$type);
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Class=1"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$LGQP.LCIDLMS.LoadCellStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $oSwZAa ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2078810,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $GKmrCi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2078810,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592013402)
            
            static $h = 2078810;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592013402),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2078810,
      "h": 8592013402,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592013402)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297046106),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2078810,
      "h": 4297046106,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297046106)
  ],
  "h": 2078810
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.Statuses.LoadCellStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}Statuses${separator}LoadCellStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2078810)
        
        

        //--TRIMMABLE-BOUNDARY-START(2209882)
        $asm.$cls(`$LGQP.LCIDLMS.LoadCellStatusModelTypeDescriptorBuilder`, ($self) => class LoadCellStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592144474)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592144474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$LGQP.LCIDLMS.LoadCellStatusModelTypeDescriptor()
                        const $t1 = $.$LGQP.LCIDLMS.LoadCellStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LoadCell.Models.Statuses.LoadCellStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $UbvSKg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2209882,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$LGQP.LCIDLMS.LoadCellStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592144474)
            
            //--TRIMMABLE-BOUNDARY-START(4297177178)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297177178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297177178)
            
            //--TRIMMABLE-BOUNDARY-START(4297177178)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297177178)
            
            static $h = 2209882;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592144474),
    {
      "r": 65537,
      "n": "Register",
      "d": 2209882,
      "h": 8592144474,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592144474)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297177178),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2209882,
      "h": 4297177178,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297177178)
  ],
  "h": 2209882
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.Statuses.LoadCellStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}Statuses${separator}LoadCellStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2209882)
        
        

        //--TRIMMABLE-BOUNDARY-START(1947738)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellServiceModelTypeDescriptorBuilder`, ($self) => class LoadCellServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591882330)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591882330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$LGQP.LCIDLM.LoadCellServiceModelTypeDescriptor()
                        const $t1 = $.$LGQP.LCIDLM.LoadCellServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $CDfgWd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1947738,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$LGQP.LCIDLM.LoadCellServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591882330)
            
            //--TRIMMABLE-BOUNDARY-START(4296915034)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296915034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296915034)
            
            //--TRIMMABLE-BOUNDARY-START(4296915034)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296915034)
            
            static $h = 1947738;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591882330),
    {
      "r": 65537,
      "n": "Register",
      "d": 1947738,
      "h": 8591882330,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591882330)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296915034),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1947738,
      "h": 4296915034,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296915034)
  ],
  "h": 1947738
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1947738)
        
        

        //--TRIMMABLE-BOUNDARY-START(899162)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellDeviceModelTypeDescriptorBuilder`, ($self) => class LoadCellDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590833754)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590833754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$LGQP.LCIDLM.LoadCellDeviceModelTypeDescriptor()
                        const $t1 = $.$LGQP.LCIDLM.LoadCellDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $JABGEb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":899162,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$LGQP.LCIDLM.LoadCellDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590833754)
            
            //--TRIMMABLE-BOUNDARY-START(4295866458)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295866458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295866458)
            
            //--TRIMMABLE-BOUNDARY-START(4295866458)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295866458)
            
            static $h = 899162;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590833754),
    {
      "r": 65537,
      "n": "Register",
      "d": 899162,
      "h": 8590833754,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590833754)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295866458),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 899162,
      "h": 4295866458,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295866458)
  ],
  "h": 899162
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(899162)
        
        

        //--TRIMMABLE-BOUNDARY-START(3061850)
        $asm.$cls(`$LGQP.LCIDLS$1.LoadCellDeviceSettingsTypeDescriptorBuilder`, ($self) => class LoadCellDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592996442)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592996442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$LGQP.LCIDLS$1.LoadCellDeviceSettingsTypeDescriptor()
                        const $t1 = $.$LGQP.LCIDLS$1.LoadCellDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $JwsnEa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3061850,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$LGQP.LCIDLS$1.LoadCellDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592996442)
            
            //--TRIMMABLE-BOUNDARY-START(4298029146)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298029146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298029146)
            
            //--TRIMMABLE-BOUNDARY-START(4298029146)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298029146)
            
            static $h = 3061850;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592996442),
    {
      "r": 65537,
      "n": "Register",
      "d": 3061850,
      "h": 8592996442,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592996442)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298029146),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3061850,
      "h": 4298029146,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298029146)
  ],
  "h": 3061850
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Settings${separator}LoadCellDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3061850)
        
        

        //--TRIMMABLE-BOUNDARY-START(178266)
        $asm.$cls(`$LGQP.LCIDL.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180047450)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180047450)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295145562)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295145562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295145562)
            
            //--TRIMMABLE-BOUNDARY-START(4295145562)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295145562)
            
            static $h = 178266;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180047450),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885080154,
        "f": 50331649
      },
      "n": "Paths",
      "d": 178266,
      "h": 17180047450,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180047450)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295145562),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 178266,
      "h": 4295145562,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295145562)
  ],
  "h": 178266
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(178266)
        
        

        //--TRIMMABLE-BOUNDARY-START(2275418)
        $asm.$cls(`$LGQP.LCIDL.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17182144602)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$LGQP.LCIDLV$1.LoadCellDeviceDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$LGQP.LCIDLV$1.LoadCellDeviceDetails().$ctor$4();
                    }, $AxHbCk ??= {"r":2752627,"n":"","d":2275418,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17182144602)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4297242714)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297242714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297242714)
            
            //--TRIMMABLE-BOUNDARY-START(4297242714)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297242714)
            
            static $h = 2275418;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182144602),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887177306,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 2275418,
      "h": 17182144602,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182144602)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297242714),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2275418,
      "h": 4297242714,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297242714)
  ],
  "h": 2275418
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2275418)
        
        

        //--TRIMMABLE-BOUNDARY-START(2340954)
        $asm.$cls(`$LGQP.LCIDL.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592275546)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592275546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$LGQP.LCIDL.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$LGQP.LCIDL.LoadCellDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$LGQP.LCIDL.LoadCellDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$LGQP.LCIDL.LoadCellDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$LGQP.LCIDL.LoadCellDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$LGQP.LCIDL.LoadCellDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$LGQP.LCIDL.LoadCellDeviceFamily, x);
                }, $aRqFba ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":2340954,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$LGQP.LCIDL.LoadCellDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$LGQP.LCIDL.LoadCellDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $YUHBBc ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":2340954,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$LGQP.LCIDL.LoadCellDevice)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$LGQP.LCIDL.LoadCellDeviceFamily, x);
                }, $lDouNc ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$LGQP.LCIDL.LoadCellDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":2340954,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$LGQP.LCIDL.LoadCellDevice), $.$LGQP.LCIDLMC.LoadCellDeviceCommands$$($.$LGQP.LCIDL.LoadCellDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$LGQP.LCIDL.LoadCellDevice), $.$LGQP.LCIDLV$1.LoadCellViewRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$LGQP.LCIDLV.LoadCellClientAppViewModel, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592275546)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LGQP.LCIDL.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297308250)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297308250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297308250)
            
            //--TRIMMABLE-BOUNDARY-START(4297308250)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297308250)
            
            static $h = 2340954;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592275546),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2340954,
      "h": 8592275546,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592275546)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297308250),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2340954,
      "h": 4297308250,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297308250)
  ],
  "h": 2340954
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2340954)
        
        

        //--TRIMMABLE-BOUNDARY-START(3782746)
        $asm.$cls(`$LGQP.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298750042)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298750042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298750042)
            
            //--TRIMMABLE-BOUNDARY-START(4298750042)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298750042)
            
            static $h = 3782746;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298750042),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3782746,
      "h": 4298750042,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298750042)
  ],
  "h": 3782746,
  "a": [
    {
      "t": 3717210,
      "c": 4298684506
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3782746)
        
        

        //--TRIMMABLE-BOUNDARY-START(3717210)
        $asm.$cls(`$LGQP.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298684506)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298684506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298684506)
            
            //--TRIMMABLE-BOUNDARY-START(4298684506)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298684506)
            
            static $h = 3717210;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298684506),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3717210,
      "h": 4298684506,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298684506)
  ],
  "h": 3717210
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3717210)
        
        

        //--TRIMMABLE-BOUNDARY-START(2013274)
        $asm.$cls(`$LGQP.LCIDLMS.LoadCellStatusModel`, ($self) => class LoadCellStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(34361751642)
            /*int*/ Sample = 0;
            //--TRIMMABLE-BOUNDARY-END(34361751642)
            
            //--TRIMMABLE-BOUNDARY-START(55836588122)
            /*double*/ Weight = 0;
            //--TRIMMABLE-BOUNDARY-END(55836588122)
            
            //--TRIMMABLE-BOUNDARY-START(12886915162)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886915162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886915162)
            
            //--TRIMMABLE-BOUNDARY-START(12886915162)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886915162)
            
            static $h = 2013274;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361751642),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476849754,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42951686234,
        "f": 83886081
      },
      "n": "Sample",
      "d": 2013274,
      "h": 34361751642,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361751642),
//--TRIMMABLE-BOUNDARY-START(55836588122),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066784346,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51541620826,
        "f": 83886081
      },
      "n": "Weight",
      "d": 2013274,
      "h": 55836588122,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//Class=1"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836588122)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886915162),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2013274,
      "h": 12886915162,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886915162)
  ],
  "h": 2013274
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.Statuses.LoadCellStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}Statuses${separator}LoadCellStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2013274)
        
        

        //--TRIMMABLE-BOUNDARY-START(2144346)
        $asm.$cls(`$LGQP.LCIDLMS.LoadCellStatusModelTypeDescriptor`, ($self) => class LoadCellStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$LGQP.LCIDLMS.LoadCellStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297111642)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297111642);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$LGQP.LCIDLMS.LoadCellStatusModelTypeDescriptor.GenerateProperties($.$LGQP.LCIDLMS.LoadCellStatusModel, this, factory);
                    }, $ptpWHb ??= {"r":65537,"n":"","d":2144346,"h":0,"f":17825794}), 0, "LoadCellStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LoadCell\\Models_Statuses_LoadCellStatusModel_LivingThing.Core.IOT.Devices.LoadCell.Models.Statuses.LoadCellStatusModelTypeDescriptorBuilder.g.cs", "LoadCellStatusModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297111642)
            
            //--TRIMMABLE-BOUNDARY-START(12887046234)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887046234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Sample"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$LGQP.LCIDLMS.LoadCellStatusModel.$type, $.$discardRef(), "Sample", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Sample")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Sample";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.LoadCell.Models.Statuses.LoadCellStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$LGQP.LCIDLMS.LoadCellStatusModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$LGQP.LCIDLMS.LoadCellStatusModel)).Sample);
                        }, $bvBjpf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2144346,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$LGQP.LCIDLMS.LoadCellStatusModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.Sample = value.AsInt();
                        }, $GekTOj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2144346,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Weight"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$LGQP.LCIDLMS.LoadCellStatusModel.$type, $.$discardRef(), "Weight", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Weight")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Weight";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.LoadCell.Models.Statuses.LoadCellStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$LGQP.LCIDLMS.LoadCellStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$LGQP.LCIDLMS.LoadCellStatusModel)).Weight);
                        }, $nsnOBb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2144346,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$LGQP.LCIDLMS.LoadCellStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Weight = value.AsDouble();
                        }, $dIguIg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2144346,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887046234)
            
            //--TRIMMABLE-BOUNDARY-START(17182013530)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LoadCell.Models.Statuses.LoadCellStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182013530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _Sample = _target.Sample;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Sample"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Sample, ($v) => _Sample = $v, $.$$.S.Int32)))
                    {
                        _target.Sample = _Sample;
                    }
                }
                {
                    /*var*/ let _Weight = _target.Weight;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Weight"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Weight, ($v) => _Weight = $v, $.$$.S.Double)))
                    {
                        _target.Weight = _Weight;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182013530)
            
            //--TRIMMABLE-BOUNDARY-START(8592078938)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LoadCell.Models.Statuses.LoadCellStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592078938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$LGQP.LCIDLMS.LoadCellStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$LGQP.LCIDLMS.LoadCellStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLMS.LoadCellStatusModel)))
                {
                    /*var*/ let result = $.$LGQP.LCIDLMS.LoadCellStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLMS.LoadCellStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$LGQP.LCIDLMS.LoadCellStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLMS.LoadCellStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592078938)
            
            static $h = 2144346;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$LGQP.LCIDLMS.LoadCellStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887046234),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2144346,
      "h": 12887046234,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887046234),
//--TRIMMABLE-BOUNDARY-START(17182013530),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2013274,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2144346,
      "h": 17182013530,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182013530),
//--TRIMMABLE-BOUNDARY-START(8592078938),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2013274,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2144346,
      "h": 8592078938,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592078938)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297111642),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2144346,
      "h": 4297111642,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297111642)
  ],
  "h": 2144346
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$LGQP.LCIDLMS.LoadCellStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.Statuses.LoadCellStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}Statuses${separator}LoadCellStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2144346)
        
        

        //--TRIMMABLE-BOUNDARY-START(637018)
        $asm.$cls(`$LGQP.LCIDLMC.LoadCellDeviceCommands<>`, (TDevice) => $asm.$gt(`$LGQP.LCIDLMC.LoadCellDeviceCommands<>`, [TDevice], ($self) => class LoadCellDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12885538906)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12885538906)
            
            //--TRIMMABLE-BOUNDARY-START(17180506202)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel?*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180506202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$LGQP.LCIDLMC.LoadCellDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17180506202)
            
            //--TRIMMABLE-BOUNDARY-START(8590571610)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590571610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590571610)
            
            //--TRIMMABLE-BOUNDARY-START(8590571610)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590571610)
            
            //--TRIMMABLE-BOUNDARY-START(4295604314)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295604314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885538906)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12885538906)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295604314)
            
            static $H = 637018;
            static $h = 637018;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180506202),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17180506202,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180506202)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885538906),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12885538906,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885538906)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590571610),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8590571610,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590571610)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 637018,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.Commands.LoadCellDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}Commands${separator}LoadCellDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(637018)
        
        

        //--TRIMMABLE-BOUNDARY-START(1488986)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellDeviceSendDataModel`, ($self) => class LoadCellDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceCommandsModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296456282)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296456282);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296456282)
            
            //--TRIMMABLE-BOUNDARY-START(4296456282)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296456282)
            
            static $h = 1488986;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandsModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296456282),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1488986,
      "h": 4296456282,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296456282)
  ],
  "h": 1488986
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1488986)
        
        

        //--TRIMMABLE-BOUNDARY-START(964698)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel`, ($self) => class LoadCellDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$LGQP.LCIDLMS.LoadCellStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8590899290)
            /*IEnumerable<IIOTDeviceDataPointModel>? */ GetDataPoints(/*SchemaType*/ schemaType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590899290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (schemaType === 32/*SchemaType.Database*/)
                {
                    return null;
                }
                return super.GetDataPoints(schemaType);
            }
            //--TRIMMABLE-BOUNDARY-END(8590899290)
            
            //--TRIMMABLE-BOUNDARY-START(4295931994)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295931994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295931994)
            
            //--TRIMMABLE-BOUNDARY-START(4295931994)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295931994)
            
            static $h = 964698;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$LGQP.LCIDLMS.LoadCellStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590899290),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceDataPointModel).$h,
      "p": [
        {
          "n": "schemaType",
          "p": 2722134
        }
      ],
      "n": "GetDataPoints",
      "d": 964698,
      "h": 8590899290,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590899290)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295931994),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 964698,
      "h": 4295931994,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295931994)
  ],
  "h": 964698
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(964698)
        
        

        //--TRIMMABLE-BOUNDARY-START(1620058)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellDeviceSendDataModelTypeDescriptor`, ($self) => class LoadCellDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$LGQP.LCIDLM.LoadCellDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296587354)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296587354);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$LGQP.LCIDLM.LoadCellDeviceSendDataModelTypeDescriptor.GenerateProperties($.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, this, factory);
                    }, $UcgJuj ??= {"r":65537,"n":"","d":1620058,"h":0,"f":17825794}), 0, "LoadCellDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LoadCell\\Models_LoadCellDeviceSendDataModel_LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceSendDataModelTypeDescriptorBuilder.g.cs", "LoadCellDeviceSendDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296587354)
            
            //--TRIMMABLE-BOUNDARY-START(12886521946)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886521946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886521946)
            
            //--TRIMMABLE-BOUNDARY-START(17181489242)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181489242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandsModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandsModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181489242)
            
            //--TRIMMABLE-BOUNDARY-START(8591554650)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591554650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$LGQP.LCIDLM.LoadCellDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591554650)
            
            static $h = 1620058;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$LGQP.LCIDLM.LoadCellDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886521946),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1620058,
      "h": 12886521946,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886521946),
//--TRIMMABLE-BOUNDARY-START(17181489242),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1488986,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1620058,
      "h": 17181489242,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181489242),
//--TRIMMABLE-BOUNDARY-START(8591554650),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1488986,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1620058,
      "h": 8591554650,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591554650)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296587354),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1620058,
      "h": 4296587354,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296587354)
  ],
  "h": 1620058
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$LGQP.LCIDLM.LoadCellDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1620058)
        
        

        //--TRIMMABLE-BOUNDARY-START(1095770)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellDeviceReceivedDataModelTypeDescriptor`, ($self) => class LoadCellDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296063066)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296063066);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, this, factory);
                    }, $jOPDdc ??= {"r":65537,"n":"","d":1095770,"h":0,"f":17825794}), 0, "LoadCellDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LoadCell\\Models_LoadCellDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "LoadCellDeviceReceivedDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296063066)
            
            //--TRIMMABLE-BOUNDARY-START(12885997658)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885997658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$LGQP.LCIDLMS.LoadCellStatusModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885997658)
            
            //--TRIMMABLE-BOUNDARY-START(17180964954)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180964954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.LoadCell.Models.Statuses.LoadCellStatusModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$LGQP.LCIDLMS.LoadCellStatusModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$LGQP.LCIDLMS.LoadCellStatusModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180964954)
            
            //--TRIMMABLE-BOUNDARY-START(8591030362)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591030362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591030362)
            
            static $h = 1095770;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885997658),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1095770,
      "h": 12885997658,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885997658),
//--TRIMMABLE-BOUNDARY-START(17180964954),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 964698,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1095770,
      "h": 17180964954,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180964954),
//--TRIMMABLE-BOUNDARY-START(8591030362),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 964698,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1095770,
      "h": 8591030362,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591030362)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296063066),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1095770,
      "h": 4296063066,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296063066)
  ],
  "h": 1095770
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1095770)
        
        

        //--TRIMMABLE-BOUNDARY-START(309338)
        $asm.$cls(`$LGQP.LCIDL.LoadCellDataConverter`, ($self) => class LoadCellDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295276634)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295276634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295276634)
            
            //--TRIMMABLE-BOUNDARY-START(4295276634)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295276634)
            
            static $h = 309338;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295276634),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 309338,
      "h": 4295276634,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295276634)
  ],
  "h": 309338
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.LoadCellDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}LoadCellDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(309338)
        
        

        $asm.$typeProxy("$LGQP.LCIDLM.LoadCellServiceModel", "$LGQP.LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellServiceModel");
        $asm.$typeProxy("$LGQP.LCIDLM.LoadCellDeviceScopeModel", "$LGQP.LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceScopeModel");
        $asm.$typeProxy("$LGQP.LCIDLS$1.LoadCellDeviceSettings", "$LGQP.LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceSettings");
        $asm.$typeProxy("$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings", "$LGQP.LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceHardwareSettings");
        $asm.$typeProxy("$LGQP.LCIDLS.ILoadCellDeviceStatusHandler", "$LGQP.LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellDeviceStatusHandler");
        $asm.$typeProxy("$LGQP.LCIDLS.ILoadCellDeviceHubClient", "$LGQP.LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellDeviceHubClient");
        $asm.$typeProxy("$LGQP.LCIDLS.ILoadCellRemoteService", "$LGQP.LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellRemoteService");
        //--TRIMMABLE-BOUNDARY-START(702554)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellDeviceModel`, ($self) => class LoadCellDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295669850)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295669850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295669850)
            
            //--TRIMMABLE-BOUNDARY-START(4295669850)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295669850)
            
            static $h = 702554;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295669850),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 702554,
      "h": 4295669850,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295669850)
  ],
  "h": 702554
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(702554)
        
        

        //--TRIMMABLE-BOUNDARY-START(2865242)
        $asm.$cls(`$LGQP.LCIDLS$1.LoadCellDeviceSettings`, ($self) => class LoadCellDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $self, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297832538)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297832538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297832538)
            
            //--TRIMMABLE-BOUNDARY-START(4297832538)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297832538)
            
            static $h = 2865242;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297832538),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2865242,
      "h": 4297832538,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297832538)
  ],
  "h": 2865242
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Settings${separator}LoadCellDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2865242)
        
        

        //--TRIMMABLE-BOUNDARY-START(1226842)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellDeviceScopeModel`, ($self) => class LoadCellDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296194138)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296194138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296194138)
            
            //--TRIMMABLE-BOUNDARY-START(4296194138)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296194138)
            
            static $h = 1226842;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296194138),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1226842,
      "h": 4296194138,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296194138)
  ],
  "h": 1226842
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1226842)
        
        

        //--TRIMMABLE-BOUNDARY-START(2537562)
        $asm.$cls(`$LGQP.LCIDLS.ILoadCellRemoteService`, ($self) => class ILoadCellRemoteService
        {
            static $h = 2537562;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2537562
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$LGQP.LCIDLM.LoadCellServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$LGQP.LCIDLM.LoadCellServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$LGQP.LCIDLM.LoadCellServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$LGQP.LCIDLM.LoadCellServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$LGQP.LCIDLM.LoadCellServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$LGQP.LCIDLM.LoadCellServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$LGQP.LCIDLM.LoadCellServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$LGQP.LCIDLM.LoadCellServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Services${separator}ILoadCellRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2537562)
        
        

        //--TRIMMABLE-BOUNDARY-START(2603098)
        $asm.$cls(`$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings`, ($self) => class LoadCellDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(12887504986)
            /*IOTDeviceInternalConfiguration<float>*/ Calibration = null;
            //--TRIMMABLE-BOUNDARY-END(12887504986)
            
            //--TRIMMABLE-BOUNDARY-START(8592537690)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592537690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592537690)
            
            //--TRIMMABLE-BOUNDARY-START(8592537690)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8592537690)
            
            static $h = 2603098;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887504986),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477439578,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30067374170,
        "f": 83886081
      },
      "n": "Calibration",
      "d": 2603098,
      "h": 12887504986,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "cal",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 20,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12887504986)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592537690),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2603098,
      "h": 8592537690,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592537690)
  ],
  "h": 2603098
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Settings${separator}LoadCellDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2603098)
        
        

        //--TRIMMABLE-BOUNDARY-START(2406490)
        $asm.$cls(`$LGQP.LCIDLS.ILoadCellDeviceHubClient`, ($self) => class ILoadCellDeviceHubClient
        {
            static $h = 2406490;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2406490
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Services${separator}ILoadCellDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2406490)
        
        

        //--TRIMMABLE-BOUNDARY-START(2472026)
        $asm.$cls(`$LGQP.LCIDLS.ILoadCellDeviceStatusHandler`, ($self) => class ILoadCellDeviceStatusHandler
        {
            static $h = 2472026;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2472026
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Services${separator}ILoadCellDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2472026)
        
        

        //--TRIMMABLE-BOUNDARY-START(1751130)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellServiceModel`, ($self) => class LoadCellServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296718426)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296718426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296718426)
            
            //--TRIMMABLE-BOUNDARY-START(4296718426)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4296718426)
            
            static $h = 1751130;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296718426),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 1751130,
      "h": 4296718426,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296718426)
  ],
  "h": 1751130
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1751130)
        
        

        //--TRIMMABLE-BOUNDARY-START(571482)
        $asm.$cls(`$LGQP.LCIDL.LoadCellDeviceModelDefinition`, ($self) => class LoadCellDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4295538778)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295538778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295538778)
            
            //--TRIMMABLE-BOUNDARY-START(4295538778)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295538778)
            
            static $h = 571482;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295538778),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 571482,
      "h": 4295538778,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295538778)
  ],
  "h": 571482
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.LoadCellDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}LoadCellDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(571482)
        
        

        //--TRIMMABLE-BOUNDARY-START(1357914)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellDeviceScopeModelTypeDescriptor`, ($self) => class LoadCellDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$LGQP.LCIDLM.LoadCellDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296325210)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296325210);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$LGQP.LCIDLM.LoadCellDeviceScopeModelTypeDescriptor.GenerateProperties($.$LGQP.LCIDLM.LoadCellDeviceScopeModel, this, factory);
                    }, $AbJAUc ??= {"r":65537,"n":"","d":1357914,"h":0,"f":17825794}), 0, "LoadCellDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LoadCell\\Models_LoadCellDeviceScopeModel_LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceScopeModelTypeDescriptorBuilder.g.cs", "LoadCellDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296325210)
            
            //--TRIMMABLE-BOUNDARY-START(12886259802)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886259802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886259802)
            
            //--TRIMMABLE-BOUNDARY-START(17181227098)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181227098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceModel, LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceSettings, LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceSendDataModel, LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellDeviceStatusHandler, LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellDeviceHubClient, LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181227098)
            
            //--TRIMMABLE-BOUNDARY-START(8591292506)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591292506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$LGQP.LCIDLM.LoadCellDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel)))
                {
                    /*var*/ let result = $.$LGQP.LCIDLM.LoadCellDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591292506)
            
            static $h = 1357914;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$LGQP.LCIDLM.LoadCellDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886259802),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1357914,
      "h": 12886259802,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886259802),
//--TRIMMABLE-BOUNDARY-START(17181227098),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1226842,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1357914,
      "h": 17181227098,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181227098),
//--TRIMMABLE-BOUNDARY-START(8591292506),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1226842,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1357914,
      "h": 8591292506,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591292506)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296325210),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1357914,
      "h": 4296325210,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296325210)
  ],
  "h": 1357914
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$LGQP.LCIDLM.LoadCellDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1357914)
        
        

        //--TRIMMABLE-BOUNDARY-START(2734170)
        $asm.$cls(`$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettingsTypeDescriptor`, ($self) => class LoadCellDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297701466)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297701466);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, this, factory);
                    }, $jTRAQh ??= {"r":65537,"n":"","d":2734170,"h":0,"f":17825794}), 0, "LoadCellDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LoadCell\\Settings_LoadCellDeviceHardwareSettings_LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "LoadCellDeviceHardwareSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297701466)
            
            //--TRIMMABLE-BOUNDARY-START(12887636058)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887636058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Calibration"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings.$type, $.$discardRef(), "Calibration", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Calibration")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Calibration";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceHardwareSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single), ($.$cast(target, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings)).Calibration);
                        }, $Ofvqzh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2734170,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Calibration = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single));
                        }, $hbvQoh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2734170,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887636058)
            
            //--TRIMMABLE-BOUNDARY-START(17182603354)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182603354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceModel, LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceSettings, LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceSendDataModel, LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellDeviceStatusHandler, LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellDeviceHubClient, LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).iSmartDeviceHardwareSettings));
                {
                    /*var*/ let _Calibration = _target.Calibration;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Calibration"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Calibration, ($v) => _Calibration = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single))))
                    {
                        _target.Calibration = _Calibration;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182603354)
            
            //--TRIMMABLE-BOUNDARY-START(8592668762)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592668762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592668762)
            
            static $h = 2734170;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887636058),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2734170,
      "h": 12887636058,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887636058),
//--TRIMMABLE-BOUNDARY-START(17182603354),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2603098,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2734170,
      "h": 17182603354,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182603354),
//--TRIMMABLE-BOUNDARY-START(8592668762),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2603098,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2734170,
      "h": 8592668762,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592668762)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297701466),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2734170,
      "h": 4297701466,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297701466)
  ],
  "h": 2734170
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Settings${separator}LoadCellDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2734170)
        
        

        //--TRIMMABLE-BOUNDARY-START(1882202)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellServiceModelTypeDescriptor`, ($self) => class LoadCellServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$LGQP.LCIDLM.LoadCellServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296849498)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296849498);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$LGQP.LCIDLM.LoadCellServiceModelTypeDescriptor.GenerateProperties($.$LGQP.LCIDLM.LoadCellServiceModel, this, factory);
                    }, $KKXJZc ??= {"r":65537,"n":"","d":1882202,"h":0,"f":17825794}), 0, "LoadCellServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LoadCell\\Models_LoadCellServiceModel_LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellServiceModelTypeDescriptorBuilder.g.cs", "LoadCellServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296849498)
            
            //--TRIMMABLE-BOUNDARY-START(12886784090)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886784090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886784090)
            
            //--TRIMMABLE-BOUNDARY-START(17181751386)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181751386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceModel, LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceSettings, LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceSendDataModel, LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellDeviceStatusHandler, LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellDeviceHubClient, LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181751386)
            
            //--TRIMMABLE-BOUNDARY-START(8591816794)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591816794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$LGQP.LCIDLM.LoadCellServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$LGQP.LCIDLM.LoadCellServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLM.LoadCellServiceModel)))
                {
                    /*var*/ let result = $.$LGQP.LCIDLM.LoadCellServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLM.LoadCellServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$LGQP.LCIDLM.LoadCellServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLM.LoadCellServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591816794)
            
            static $h = 1882202;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$LGQP.LCIDLM.LoadCellServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886784090),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1882202,
      "h": 12886784090,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886784090),
//--TRIMMABLE-BOUNDARY-START(17181751386),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1751130,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1882202,
      "h": 17181751386,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181751386),
//--TRIMMABLE-BOUNDARY-START(8591816794),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1751130,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1882202,
      "h": 8591816794,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591816794)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296849498),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1882202,
      "h": 4296849498,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296849498)
  ],
  "h": 1882202
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$LGQP.LCIDLM.LoadCellServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1882202)
        
        

        //--TRIMMABLE-BOUNDARY-START(833626)
        $asm.$cls(`$LGQP.LCIDLM.LoadCellDeviceModelTypeDescriptor`, ($self) => class LoadCellDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$LGQP.LCIDLM.LoadCellDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295800922)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295800922);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$LGQP.LCIDLM.LoadCellDeviceModelTypeDescriptor.GenerateProperties($.$LGQP.LCIDLM.LoadCellDeviceModel, this, factory);
                    }, $RnpCSh ??= {"r":65537,"n":"","d":833626,"h":0,"f":17825794}), 0, "LoadCellDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LoadCell\\Models_LoadCellDeviceModel_LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceModelTypeDescriptorBuilder.g.cs", "LoadCellDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295800922)
            
            //--TRIMMABLE-BOUNDARY-START(12885735514)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885735514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885735514)
            
            //--TRIMMABLE-BOUNDARY-START(17180702810)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180702810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceModel, LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceSettings, LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceSendDataModel, LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellDeviceStatusHandler, LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellDeviceHubClient, LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180702810)
            
            //--TRIMMABLE-BOUNDARY-START(8590768218)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590768218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$LGQP.LCIDLM.LoadCellDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$LGQP.LCIDLM.LoadCellDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLM.LoadCellDeviceModel)))
                {
                    /*var*/ let result = $.$LGQP.LCIDLM.LoadCellDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLM.LoadCellDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$LGQP.LCIDLM.LoadCellDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLM.LoadCellDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590768218)
            
            static $h = 833626;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$LGQP.LCIDLM.LoadCellDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885735514),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 833626,
      "h": 12885735514,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885735514),
//--TRIMMABLE-BOUNDARY-START(17180702810),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 702554,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 833626,
      "h": 17180702810,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180702810),
//--TRIMMABLE-BOUNDARY-START(8590768218),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 702554,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 833626,
      "h": 8590768218,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590768218)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295800922),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 833626,
      "h": 4295800922,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295800922)
  ],
  "h": 833626
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$LGQP.LCIDLM.LoadCellDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Models${separator}LoadCellDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(833626)
        
        

        //--TRIMMABLE-BOUNDARY-START(2996314)
        $asm.$cls(`$LGQP.LCIDLS$1.LoadCellDeviceSettingsTypeDescriptor`, ($self) => class LoadCellDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$LGQP.LCIDLS$1.LoadCellDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297963610)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297963610);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$LGQP.LCIDLS$1.LoadCellDeviceSettingsTypeDescriptor.GenerateProperties($.$LGQP.LCIDLS$1.LoadCellDeviceSettings, this, factory);
                    }, $pbzKZe ??= {"r":65537,"n":"","d":2996314,"h":0,"f":17825794}), 0, "LoadCellDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.LoadCell\\Settings_LoadCellDeviceSettings_LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceSettingsTypeDescriptorBuilder.g.cs", "LoadCellDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297963610)
            
            //--TRIMMABLE-BOUNDARY-START(12887898202)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887898202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887898202)
            
            //--TRIMMABLE-BOUNDARY-START(17182865498)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182865498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceModel, LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceSettings, LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.LoadCell.Models.LoadCellDeviceSendDataModel, LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellDeviceStatusHandler, LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellDeviceHubClient, LivingThing.Core.IOT.Devices.LoadCell.Services.ILoadCellRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService).iSmartDeviceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182865498)
            
            //--TRIMMABLE-BOUNDARY-START(8592930906)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592930906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$LGQP.LCIDLS$1.LoadCellDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings)))
                {
                    /*var*/ let result = $.$LGQP.LCIDLS$1.LoadCellDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592930906)
            
            static $h = 2996314;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$LGQP.LCIDLS$1.LoadCellDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887898202),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2996314,
      "h": 12887898202,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887898202),
//--TRIMMABLE-BOUNDARY-START(17182865498),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2865242,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2996314,
      "h": 17182865498,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182865498),
//--TRIMMABLE-BOUNDARY-START(8592930906),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2865242,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2996314,
      "h": 8592930906,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592930906)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297963610),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2996314,
      "h": 4297963610,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297963610)
  ],
  "h": 2996314
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$LGQP.LCIDLS$1.LoadCellDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Settings.LoadCellDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Settings${separator}LoadCellDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2996314)
        
        

        //--TRIMMABLE-BOUNDARY-START(374874)
        $asm.$cls(`$LGQP.LCIDL.LoadCellDevice`, ($self) => class LoadCellDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$LGQP.LCIDLMS.LoadCellStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4295342170)
            $ctor$2(/*IIOTDeviceFamily<LoadCellDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*LoadCellDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295342170);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295342170)
            
            static $h = 374874;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$LGQP.LCIDLMS.LoadCellStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295342170),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$LGQP.LCIDL.LoadCellDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 702554
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 374874,
      "h": 4295342170,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295342170)
  ],
  "h": 374874
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.LoadCellDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}LoadCellDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(374874)
        
        

        //--TRIMMABLE-BOUNDARY-START(440410)
        $asm.$cls(`$LGQP.LCIDL.LoadCellDeviceDefinition`, ($self) => class LoadCellDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$LGQP.LCIDLMS.LoadCellStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295407706)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295407706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295407706)
            
            //--TRIMMABLE-BOUNDARY-START(4295407706)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295407706)
            
            static $h = 440410;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$LGQP.LCIDLMS.LoadCellStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295407706),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 440410,
      "h": 4295407706,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295407706)
  ],
  "h": 440410
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.LoadCellDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}LoadCellDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(440410)
        
        

        //--TRIMMABLE-BOUNDARY-START(505946)
        $asm.$cls(`$LGQP.LCIDL.LoadCellDeviceFamily`, ($self) => class LoadCellDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4295473242)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<LoadCellDeviceReceivedDataModel, LoadCellDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<LoadCellDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295473242);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295473242)
            
            static $h = 505946;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295473242),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 505946,
      "h": 4295473242,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295473242)
  ],
  "h": 505946
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$LGQP.LCIDL.LoadCellDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$LGQP.LCIDL.LoadCellDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.LoadCellDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}LoadCellDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(505946)
        
        

        //--TRIMMABLE-BOUNDARY-START(3651674)
        $asm.$cls(`$LGQP.LCIDLV$1.LoadCellViewRenderer`, ($self) => class LoadCellViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$$$$$$($.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel))
        {
            //--TRIMMABLE-BOUNDARY-START(4298618970)
            $ctor$2(/*IOTRootViewModel*/ root)
            {
                super.$ctor$1(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298618970);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298618970)
            
            //--TRIMMABLE-BOUNDARY-START(8593586266)
            /*RenderFragment? */ GetView(/*IClientUnitOfWork*/ ui, /*LoadCellDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>?*/ clicked, /*Func<Task>?*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593586266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === 3/*DeviceViewType.Details*/)
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$LGQP.LCIDLV$1.LoadCellDeviceDetails, $.$LGQP.LCIDLV$1.LoadCellDetailsViewModel, new $.$LGQP.LCIDLV$1.LoadCellDetailsViewModel().$ctor$8(this.Root, device.OwnerScope, device), true, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(8593586266)
            
            static $h = 3651674;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$$$$$$($.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593586266),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 374874
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 3651674,
      "h": 8593586266,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8593586266)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298618970),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3651674,
      "h": 4298618970,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298618970)
  ],
  "h": 3651674
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$LGQP.LCIDL.LoadCellDevice), $.$ntej.LCICD$1.IDeviceViewRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Views.LoadCellViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Views${separator}LoadCellViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3651674)
        
        

        //--TRIMMABLE-BOUNDARY-START(3520602)
        $asm.$cls(`$LGQP.LCIDLV$1.LoadCellDetailsViewModel`, ($self) => class LoadCellDetailsViewModel extends $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$$$$$$($.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel))
        {
            //--TRIMMABLE-BOUNDARY-START(4298487898)
            $ctor$8(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*LoadCellDevice*/ device)
            {
                super.$ctor$7(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298487898);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298487898)
            
            static $h = 3520602;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$$$$$$($.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298487898),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 374874
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 3520602,
      "h": 4298487898,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298487898)
  ],
  "h": 3520602
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICDV.IDeviceDetailsViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Views.LoadCellDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Views${separator}LoadCellDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3520602)
        
        

        //--TRIMMABLE-BOUNDARY-START(3586138)
        $asm.$cls(`$LGQP.LCIDLV$1.LoadCellDeviceDetails`, ($self) => class LoadCellDeviceDetails extends $.$hDPm.LCFCC$1.BaseComponent$$($.$LGQP.LCIDLV$1.LoadCellDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(51543193690)
            /*LoadCellDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(51543193690)
            
            //--TRIMMABLE-BOUNDARY-START(34363324506)
            /*string */ get OptimizedComponentName()
            {
                return "loadcelldevicedetails";
            }
            //--TRIMMABLE-BOUNDARY-END(34363324506)
            
            //--TRIMMABLE-BOUNDARY-START(47248226394)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47248226394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$LGQP.LCIDLV$1.LoadCellDetailsViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(47248226394)
            
            //--TRIMMABLE-BOUNDARY-START(12888488026)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888488026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$LGQP.LCIDL.LoadCellDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$LGQP.LCIDL.LoadCellDevice), this.ViewModel));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICD$1.DeviceDetailsFeatures, 479/*DeviceDetailsFeatures.Default*/ & ~256/*DeviceDetailsFeatures.IO*/), $.$ntej.LCICD$1.DeviceDetailsFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    /*var*/ let weight = (this.ViewModel.Device$1.Received?.Status?.Weight ?? null);
                    if (weight !== null)
                    {
                        weight = $.$$.S.Math.Abs$1($.$$.S.Nullable$$($.$$.S.Double).Value$get.call(weight));
                    }
                    __builder2.OpenElement(4, "div");
                    __builder2.AddAttribute$5(5, "class", "text-center pd bg-card mgt");
                    __builder2.AddMarkupContent(6, "<span>Gas Left</span>\r\n        ");
                    __builder2.OpenElement(7, "h1");
                    __builder2.AddAttribute$5(8, "class", "cl-success");
                    /*double?*/ let __ca1__;
                    __builder2.AddContent$4(9, $.$strNN(((__ca1__ = weight) !== null ? $.$$.S.Double.ToString$3.call($.$$.S.Nullable$$($.$$.S.Double).Value$get.call(__ca1__), "#0.0") : null)) + "kg");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                }), $yIxOTj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3586138,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12888488026)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8593520730)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593520730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593520730)
            
            //--TRIMMABLE-BOUNDARY-START(8593520730)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8593520730)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51543193690)
                this.ViewModel = null;
                //--TRIMMABLE-BOUNDARY-END(51543193690)
                
            }
            static $h = 3586138;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$LGQP.LCIDLV$1.LoadCellDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51543193690),
    {
      "p": 3520602,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068357210,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42953259098,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 3586138,
      "h": 51543193690,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51543193690),
//--TRIMMABLE-BOUNDARY-START(34363324506),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478422618,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 3586138,
      "h": 34363324506,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34363324506)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47248226394),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 3586138,
      "h": 47248226394,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47248226394),
//--TRIMMABLE-BOUNDARY-START(12888488026),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 3586138,
      "h": 12888488026,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12888488026)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593520730),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3586138,
      "h": 8593520730,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593520730)
  ],
  "h": 3586138
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.Views.LoadCellDeviceDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}Views${separator}LoadCellDeviceDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3586138)
        
        

        $asm.$typeProxy("$LGQP.LCIDLV.LoadCellClientAppViewModel", "$LGQP.LivingThing.Core.IOT.Devices.LoadCell.ViewModels.LoadCellClientAppViewModel");
        $asm.$typeProxy("$LGQP.LCIDLV.LoadCellClientAppServiceViewModel", "$LGQP.LivingThing.Core.IOT.Devices.LoadCell.ViewModels.LoadCellClientAppServiceViewModel");
        $asm.$typeProxy("$LGQP.LCIDLV.LoadCellClientAppDeviceViewModel", "$LGQP.LivingThing.Core.IOT.Devices.LoadCell.ViewModels.LoadCellClientAppDeviceViewModel");
        //--TRIMMABLE-BOUNDARY-START(3258458)
        $asm.$cls(`$LGQP.LCIDLV.LoadCellClientAppDeviceScopeViewModel`, ($self) => class LoadCellClientAppDeviceScopeViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLV.LoadCellClientAppViewModel, $.$LGQP.LCIDLV.LoadCellClientAppServiceViewModel, $self, $.$LGQP.LCIDLV.LoadCellClientAppDeviceViewModel, $.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298225754)
            $ctor$3(/*LoadCellClientAppServiceViewModel*/ service, /*LoadCellDeviceScopeModel*/ model, /*IEnumerable<LoadCellClientAppDeviceViewModel>*/ devices)
            {
                super.$ctor$3(service, model, devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298225754);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298225754)
            
            static $h = 3258458;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLV.LoadCellClientAppViewModel, $.$LGQP.LCIDLV.LoadCellClientAppServiceViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceScopeViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceViewModel, $.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298225754),
    {
      "p": [
        {
          "n": "service",
          "p": 3389530
        },
        {
          "n": "model",
          "p": 1226842
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$LGQP.LCIDLV.LoadCellClientAppDeviceViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3258458,
      "h": 4298225754,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298225754)
  ],
  "h": 3258458
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$vWqU.LCFCC.IViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTDeviceScopeViewModel$$$($.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceViewModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.ViewModels.LoadCellClientAppDeviceScopeViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}ViewModels${separator}LoadCellClientAppDeviceScopeViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3258458)
        
        

        //--TRIMMABLE-BOUNDARY-START(3455066)
        $asm.$cls(`$LGQP.LCIDLV.LoadCellClientAppViewModel`, ($self) => class LoadCellClientAppViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($self, $.$LGQP.LCIDLV.LoadCellClientAppServiceViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceScopeViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceViewModel, $.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298422362)
            $ctor$5(/*IOTRootViewModel*/ root, /*LoadCellDeviceFamily*/ family, /*IHubConnector<IIOTDeviceHubClientBase<LoadCellDeviceReceivedDataModel, IOTDeviceStatusModel>>*/ hubConnector)
            {
                super.$ctor$5(root, family, $.$$.N.InterfaceVarianceStubHandler.Create(hubConnector, $.$kVHt.LCFCH.IHubConnector$$($.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)), $.$kVHt.LCFCH.IHubConnector$$($.$LGQP.LCIDLS.ILoadCellDeviceHubClient)));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298422362);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298422362)
            
            //--TRIMMABLE-BOUNDARY-START(8593389658)
            /*bool */ get Authorize()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593389658)
            
            //--TRIMMABLE-BOUNDARY-START(21478291546)
            /*LoadCellClientAppServiceViewModel */ GetServiceViewModel(/*LoadCellServiceModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478291546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$LGQP.LCIDLV.LoadCellClientAppServiceViewModel().$ctor$3(this, model);
            }
            //--TRIMMABLE-BOUNDARY-END(21478291546)
            
            static $h = 3455066;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLV.LoadCellClientAppViewModel, $.$LGQP.LCIDLV.LoadCellClientAppServiceViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceScopeViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceViewModel, $.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8593389658),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183324250,
        "f": 50364417
      },
      "n": "Authorize",
      "d": 3455066,
      "h": 8593389658,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8593389658)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21478291546),
    {
      "r": 3389530,
      "p": [
        {
          "n": "model",
          "p": 1751130
        }
      ],
      "n": "GetServiceViewModel",
      "d": 3455066,
      "h": 21478291546,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21478291546)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298422362),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "family",
          "p": 505946
        },
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$($.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3455066,
      "h": 4298422362,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298422362)
  ],
  "h": 3455066
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$ntej.LCICV.IIOTAppViewModel$$($.$LGQP.LCIDLM.LoadCellServiceModel), $.$ntej.LCICV.IIOTApplicationViewModel, $.$vWqU.LCFCC.IServiceViewModel$$($.$LGQP.LCIDLM.LoadCellServiceModel), $.$vWqU.LCFCC.IServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$yleQ.LCFCA.IApplicationService, $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$vWqU.LCFCC.IServiceSubscriptionViewModel$$($.$LGQP.LCIDLM.LoadCellServiceModel), $.$vWqU.LCFCC.IServiceSubscriptionViewModel, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IClientRootService$$($.$LGQP.LCIDLM.LoadCellServiceModel), $.$vWqU.LCFCC.IClientRootService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.ViewModels.LoadCellClientAppViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}ViewModels${separator}LoadCellClientAppViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3455066)
        
        

        //--TRIMMABLE-BOUNDARY-START(3323994)
        $asm.$cls(`$LGQP.LCIDLV.LoadCellClientAppDeviceViewModel`, ($self) => class LoadCellClientAppDeviceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLV.LoadCellClientAppViewModel, $.$LGQP.LCIDLV.LoadCellClientAppServiceViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceScopeViewModel, $self, $.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298291290)
            $ctor$7(/*LoadCellClientAppServiceViewModel*/ service, /*LoadCellDeviceModel*/ model, /*IEnumerable<LoadCellClientAppDeviceScopeViewModel>*/ scopes)
            {
                super.$ctor$7(service, model, scopes);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298291290);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298291290)
            
            static $h = 3323994;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLV.LoadCellClientAppViewModel, $.$LGQP.LCIDLV.LoadCellClientAppServiceViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceScopeViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceViewModel, $.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298291290),
    {
      "p": [
        {
          "n": "service",
          "p": 3389530
        },
        {
          "n": "model",
          "p": 702554
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$LGQP.LCIDLV.LoadCellClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 3323994,
      "h": 4298291290,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298291290)
  ],
  "h": 3323994
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICV.IIOTDeviceViewModel$$$$($.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTDeviceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.ViewModels.LoadCellClientAppDeviceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}ViewModels${separator}LoadCellClientAppDeviceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3323994)
        
        

        //--TRIMMABLE-BOUNDARY-START(3389530)
        $asm.$cls(`$LGQP.LCIDLV.LoadCellClientAppServiceViewModel`, ($self) => class LoadCellClientAppServiceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLV.LoadCellClientAppViewModel, $self, $.$LGQP.LCIDLV.LoadCellClientAppDeviceScopeViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceViewModel, $.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298356826)
            $ctor$3(/*LoadCellClientAppViewModel*/ app, /*LoadCellServiceModel*/ model)
            {
                super.$ctor$3(app, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298356826);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298356826)
            
            //--TRIMMABLE-BOUNDARY-START(12888291418)
            /*LoadCellClientAppDeviceViewModel */ GetDeviceViewModel(/*LoadCellDeviceModel*/ model, /*IEnumerable<LoadCellClientAppDeviceScopeViewModel>*/ scopes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888291418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$LGQP.LCIDLV.LoadCellClientAppDeviceViewModel().$ctor$7(this, model, scopes);
            }
            //--TRIMMABLE-BOUNDARY-END(12888291418)
            
            //--TRIMMABLE-BOUNDARY-START(8593324122)
            /*LoadCellClientAppDeviceScopeViewModel */ GetDeviceScopeViewModel(/*LoadCellDeviceScopeModel*/ model, /*IEnumerable<LoadCellClientAppDeviceViewModel>*/ devices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593324122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$LGQP.LCIDLV.LoadCellClientAppDeviceScopeViewModel().$ctor$3(this, model, devices);
            }
            //--TRIMMABLE-BOUNDARY-END(8593324122)
            
            static $h = 3389530;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLV.LoadCellClientAppViewModel, $.$LGQP.LCIDLV.LoadCellClientAppServiceViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceScopeViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceViewModel, $.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888291418),
    {
      "r": 3323994,
      "p": [
        {
          "n": "model",
          "p": 702554
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$LGQP.LCIDLV.LoadCellClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": "GetDeviceViewModel",
      "d": 3389530,
      "h": 12888291418,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12888291418),
//--TRIMMABLE-BOUNDARY-START(8593324122),
    {
      "r": 3258458,
      "p": [
        {
          "n": "model",
          "p": 1226842
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$LGQP.LCIDLV.LoadCellClientAppDeviceViewModel).$h
        }
      ],
      "n": "GetDeviceScopeViewModel",
      "d": 3389530,
      "h": 8593324122,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8593324122)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298356826),
    {
      "p": [
        {
          "n": "app",
          "p": 3455066
        },
        {
          "n": "model",
          "p": 1751130
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3389530,
      "h": 4298356826,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298356826)
  ],
  "h": 3389530
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTApplicationServiceViewModel$$$$$$$$($.$LGQP.LCIDLM.LoadCellServiceModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceScopeViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceViewModel, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTApplicationServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.ViewModels.LoadCellClientAppServiceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}ViewModels${separator}LoadCellClientAppServiceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3389530)
        
        

        //--TRIMMABLE-BOUNDARY-START(3192922)
        $asm.$cls(`$LGQP.LCIDLV.LoadCellClientAppDefinition`, ($self) => class LoadCellClientAppDefinition extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLV.LoadCellClientAppViewModel, $.$LGQP.LCIDLV.LoadCellClientAppServiceViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceScopeViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceViewModel, $.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298160218)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298160218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298160218)
            
            //--TRIMMABLE-BOUNDARY-START(4298160218)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298160218)
            
            static $h = 3192922;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$LGQP.LCIDLV.LoadCellClientAppViewModel, $.$LGQP.LCIDLV.LoadCellClientAppServiceViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceScopeViewModel, $.$LGQP.LCIDLV.LoadCellClientAppDeviceViewModel, $.$LGQP.LCIDL.LoadCellDevice, $.$LGQP.LCIDLM.LoadCellServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$LGQP.LCIDLM.LoadCellDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$LGQP.LCIDLM.LoadCellDeviceModel, $.$LGQP.LCIDLS$1.LoadCellDeviceSettings, $.$LGQP.LCIDLS$1.LoadCellDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$LGQP.LCIDLM.LoadCellDeviceReceivedDataModel, $.$LGQP.LCIDLM.LoadCellDeviceSendDataModel, $.$LGQP.LCIDLS.ILoadCellDeviceStatusHandler, $.$LGQP.LCIDLS.ILoadCellDeviceHubClient, $.$LGQP.LCIDLS.ILoadCellRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298160218),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3192922,
      "h": 4298160218,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298160218)
  ],
  "h": 3192922
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LoadCell.ViewModels.LoadCellClientAppDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LoadCell${separator}ViewModels${separator}LoadCellClientAppDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3192922)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(47194)
