
//--TRIMMABLE-BOUNDARY-START(10241)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $EwntNh;
    let $EVaAEc;
    let $SXEXmk;
    let $ImkxAi;
    let $UksQze;
    let $FiJXZd;
    let $FHmQuj;
    let $VSIiFg;
    let $UJIzLf;
    let $VOoMdc;
    let $ExPbmh;
    let $iOyWYk;
    let $PmKFfg;
    let $UAqAmb;
    let $LZgcOk;
    let $TXKEbl;
    let $cKlHRe;
    let $IfTIjb;
    let $AkkAjl;
    let $KnreSe;
    let $uIEJHh;
    let $CAaIXh;
    let $ECpnPg;
    let $MNMvVf;
    let $SSNOrf;
    let $ESSoij;
    let $TtiLQj;
    let $XmXyzc;
    let $gziybc;
    let $vuwFfg;
    let $CmbTyh;
    let $kMHhLi;
    let $nohEYb;
    let $bdwpFg;
    let $KawDal;
    let $nRRoAi;
    let $YOJBuc;
    let $ijZbaj;
    let $bGcaFi;
    let $YKBHja;
    let $vxOSle;
    let $QLXQnh;
    let $justuh;
    let $yiboRc;
    let $ssGNDb;
    let $uSZnzb;
    let $UCvsua;
    let $xAgaJe;
    let $BNclma;
    let $ugMDce;
    let $BrfRmk;
    let $nuxIGe;
    let $dEOKxa;
    let $qnrREk;
    let $vtbUij;
    let $WheVTi;
    let $CtWpdc;
    let $mjMXpa;
    let $lfMEri;
    let $TemDpk;
    let $DxOShd;
    let $RiYVOa;
    let $OTAgkc;
    let $PIYDda;
    let $aliZEh;
    let $cdqvzk;
    let $RPzYHk;
    let $VGSnIj;
    let $sOiYnf;
    let $bKYXfi;
    let $qtjmHb;
    let $XyuVyb;
    let $vqHeri;
    let $ltlUgd;
    let $tjNRAg;
    let $cpAwbj;
    let $AAdOvf;
    let $JgnVXc;
    let $vLJwnl;
    let $aYexNe;
    let $QFVzBk;
    let $TabXFg;
    let $fGbNil;
    let $JVBDZf;
    let $vMslhc;
    let $QAWTlh;
    let $hwEAZe;
    let $cfsQfj;
    let $qVKhnj;
    let $lPErui;
    let $lOUrJh;
    let $zFvTcc;
    let $qIOimj;
    let $ZjLGTa;
    let $vORBni;
    let $WrBAkk;
    let $vVvrod;
    let $tMqOBf;
    let $HEmjZj;
    let $JUcDAd;
    let $IEfxrj;
    let $zqILta;
    let $UDnHek;
    let $PRtBTd;
    let $HDmcnk;
    let $eOfxHi;
    let $SoRgLc;
    let $mmZlFj;
    let $JkCJxe;
    let $AheMFe;
    let $mEtWYh;
    let $XIOVOg;
    let $GzInYb;
    let $MgyQOk;
    let $KcYZoe;
    let $gFTpmi;
    let $HFnTYh;
    let $rvWmZa;
    let $buNAqk;
    let $kbXFRd;
    let $VgNcrg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.Logger", 
    {
  "h": 10241,
  "f": "LivingThing.Core.IOT.Devices.Logger",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.Logger",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.Logger",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5Mb2dnZXIuTG9nZ2VyRGV2aWNlIjogew0KICAgICAgIkNhdGVnb3JpZXMiOiBbICJTbWFydCBIb21lIiBdLA0KICAgICAgIk5hbWUiOiAiTG9nZ2VyIiwNCiAgICAgICJEZXNjcmlwdGlvbiI6ICJEYXRhIGxvZ2dlciBmb3IgdmFyaW91cyBhcHBsaWNhdGlvbnMgc3VjaCBhcyBwb3dlciwgbG9naWMgZXZlbnRzLCBhbmFsb2cgdm9sdGFnZXMgYW5kIG1vcmUiLA0KICAgICAgIlVuaXRDb3N0Ijogew0KICAgICAgICAiVmFsdWUiOiAxMDAwMCwNCiAgICAgICAgIlVuaXQiOiAiTmFpcmEiDQogICAgICB9LA0KICAgICAgIkltYWdlcyI6IFsNCiAgICAgIF0sDQogICAgICAiSWNvbiI6IHsgIk5hbWUiOiAibWRpIG1kaS1wb3dlciIgfSwNCiAgICAgICJUaGVtZUNvbG9yIjogIiNkNzliYWEiLA0KICAgICAgIkZsYWdzIjogIkZlYXR1cmVkLFB1Ymxpc2hlZCIsDQogICAgICAiU2VjdXJpdGllcyI6ICJDaGFsbGVuZ2VIYW5kU2hha2VBdXRoZW50aWNhdGlvblByb3RvY29sLEFkdmFuY2VkRW5jcnlwdGlvblN0YW5kYXJkLEVsbGlwdGljQ3VydmVGaXJtd2FyZVVwZGF0ZVNpZ25pbmciLA0KICAgICAgIkZlYXR1cmVzIjogWw0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIkxvZ2dpbmciLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJMb2cgbW9uaXRvcmVkIHZhbHVlcyBpbnRlcm1pdHRlbnRseSIsDQogICAgICAgICAgIkljb24iOiB7ICJJY29uIjogIm1kaSBtZGktbG9nIiB9DQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiTG9uZyB0ZXJtIHN0b3JhZ2UiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJMb2dnZ2VkIHZhbHVlcyBhcmUgc3RvcmVkIGZvciBhIHZlcnkgbG9uZyB0aW1lLiIsDQogICAgICAgICAgIkljb24iOiB7ICJJY29uIjogIm1kaSBtZGktdGltZSIgfQ0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIlNlcnZlciBTeW5jaHJvbml6YXRpb24iLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJMb2dzIGFyZSBzZW50IHRvIGNsb3VkIHNlcnZlcnMgd2hlbiBpbnRlcm5ldCBpcyBhdmFpbGFibGUuIiwNCiAgICAgICAgICAiSWNvbiI6IHsgIkljb24iOiAibWRpIG1kaS1jbG91ZCIgfQ0KICAgICAgICB9DQogICAgICBdLA0KICAgICAgIlVzZUNhc2VzIjogWw0KICAgICAgICB7ICJEZXNjcmlwdGlvbiI6ICJGaWVsZCBtb25pdG9yaW5nIiB9LA0KICAgICAgICB7ICJEZXNjcmlwdGlvbiI6ICJEYXRhIGNvbGxlY3Rpb24gYW5kIGFnZ3JlZ2F0aW9uIiB9LA0KICAgICAgICB7ICJEZXNjcmlwdGlvbiI6ICJTdGF0aXN0aWNhbCBhbmFseXNpcyBvZiBmaWVsZCBkYXRhIiB9DQogICAgICBdDQogICAgfQ0KICB9DQp9"
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2500609)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogModel`, ($self) => class LoggerLogModel extends $.$XBGm.LCICDi.iSmartDeviceLogModel
        {
            //--TRIMMABLE-BOUNDARY-START(12887402497)
            /*LoggerLogType*/ Event = 0;
            //--TRIMMABLE-BOUNDARY-END(12887402497)
            
            //--TRIMMABLE-BOUNDARY-START(25772304385)
            /*double */ GetDataPoint(/*int*/ i)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772304385);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772304385)
            
            //--TRIMMABLE-BOUNDARY-START(8592435201)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592435201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592435201)
            
            //--TRIMMABLE-BOUNDARY-START(8592435201)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592435201)
            
            static $h = 2500609;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceLogModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887402497),
    {
      "p": 3024897,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477337089,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34362238977,
        "f": 83886081
      },
      "n": "Event",
      "d": 2500609,
      "h": 12887402497,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12887402497)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772304385),
    {
      "r": 1179649,
      "p": [
        {
          "n": "i",
          "p": 655361
        }
      ],
      "n": "GetDataPoint",
      "d": 2500609,
      "h": 25772304385,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25772304385)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592435201),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2500609,
      "h": 8592435201,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8592435201)
  ],
  "h": 2500609,
  "a": [
    {
      "t": $.$fPer.LCFCD.PacketBuilderDataTypeAttribute$$($.$IhzR.LCIDLM.LoggerLogTypeProvider).$h,
      "c": Number(BigInt($.$fPer.LCFCD.PacketBuilderDataTypeAttribute$$($.$IhzR.LCIDLM.LoggerLogTypeProvider).$h)|0x100000000n)
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceLog, $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2500609)
        
        

        //--TRIMMABLE-BOUNDARY-START(1517569)
        $asm.$cls(`$IhzR.LCIDLM.LoggerDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class LoggerDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296484865)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296484865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$$($.$IhzR.LCIDLMS.LoggerReceivedStatusModel, $.$IhzR.LCIDLM.LoggerLogModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296484865)
            
            static $h = 1517569;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296484865),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1517569,
      "h": 4296484865,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296484865)
  ],
  "h": 1517569
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1517569)
        
        

        //--TRIMMABLE-BOUNDARY-START(1779713)
        $asm.$cls(`$IhzR.LCIDLM.LoggerDeviceScopeModelCustomAttributesProvider`, ($self) => class LoggerDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296747009)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296747009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296747009)
            
            static $h = 1779713;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296747009),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1779713,
      "h": 4296747009,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296747009)
  ],
  "h": 1779713
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1779713)
        
        

        //--TRIMMABLE-BOUNDARY-START(3549185)
        $asm.$cls(`$IhzR.LCIDLM.LoggerServiceModelCustomAttributesProvider`, ($self) => class LoggerServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298516481)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298516481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298516481)
            
            static $h = 3549185;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298516481),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3549185,
      "h": 4298516481,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298516481)
  ],
  "h": 3549185
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3549185)
        
        

        //--TRIMMABLE-BOUNDARY-START(2041857)
        $asm.$cls(`$IhzR.LCIDLM.LoggerDeviceSendDataModelCustomAttributesProvider`, ($self) => class LoggerDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297009153)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297009153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceCommandsModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297009153)
            
            static $h = 2041857;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297009153),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2041857,
      "h": 4297009153,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297009153)
  ],
  "h": 2041857
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2041857)
        
        

        //--TRIMMABLE-BOUNDARY-START(4073473)
        $asm.$cls(`$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModelCustomAttributesProvider`, ($self) => class LoggerGetInputAnalyticsResponseModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299040769)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299040769)
            
            //--TRIMMABLE-BOUNDARY-START(8594008065)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594008065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Count", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $FiJXZd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4073473,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $FHmQuj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4073473,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594008065)
            
            static $h = 4073473;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594008065),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4073473,
      "h": 8594008065,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594008065)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299040769),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4073473,
      "h": 4299040769,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299040769)
  ],
  "h": 4073473
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetInputAnalyticsResponseModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Statuses${separator}LoggerGetInputAnalyticsResponseModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4073473)
        
        

        //--TRIMMABLE-BOUNDARY-START(2566145)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogModelCustomAttributesProvider`, ($self) => class LoggerLogModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297533441)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297533441)
            
            //--TRIMMABLE-BOUNDARY-START(8592500737)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592500737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$IhzR.LCIDLM.LoggerLogModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(2);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCD.PacketBuilderDataTypeAttribute$$($.$IhzR.LCIDLM.LoggerLogTypeProvider).$type, $.$fPer.LCFCD.PacketBuilderDataTypeAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.PacketBuilderDataTypeAttribute$$($.$IhzR.LCIDLM.LoggerLogTypeProvider)), [(() =>
                        {
                            //new $.$fPer.LCFCD.PacketBuilderDataTypeAttribute$$($.$IhzR.LCIDLM.LoggerLogTypeProvider)()
                            const $t3 = $.$fPer.LCFCD.PacketBuilderDataTypeAttribute$$($.$IhzR.LCIDLM.LoggerLogTypeProvider);
                            const $i3 = new $t3();
                            $i3.$ctor$3();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.PacketBuilderDataTypeAttribute$$($.$IhzR.LCIDLM.LoggerLogTypeProvider)), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t4 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i4 = new $t4();
                        $i4.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i4.set_Item("Event", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (4);
                            $i5.ConvertType = ($.$$.S.Byte.$type);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i4;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$IhzR.LCIDLM.LoggerLogModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $VSIiFg ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2566145,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $UJIzLf ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2566145,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceLogModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592500737)
            
            static $h = 2566145;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592500737),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2566145,
      "h": 8592500737,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592500737)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297533441),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2566145,
      "h": 4297533441,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297533441)
  ],
  "h": 2566145
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2566145)
        
        

        //--TRIMMABLE-BOUNDARY-START(2828289)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogPowerModelCustomAttributesProvider`, ($self) => class LoggerLogPowerModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297795585)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297795585)
            
            //--TRIMMABLE-BOUNDARY-START(8592762881)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592762881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$IhzR.LCIDLM.LoggerLogPowerModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(4, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Title", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((1039), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Description", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((1039), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Icon", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((1039), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Color", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((1039), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$IhzR.LCIDLM.LoggerLogPowerModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $VOoMdc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2828289,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $ExPbmh ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2828289,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$IhzR.LCIDLM.LoggerLogModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592762881)
            
            static $h = 2828289;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592762881),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2828289,
      "h": 8592762881,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592762881)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297795585),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2828289,
      "h": 4297795585,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297795585)
  ],
  "h": 2828289
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogPowerModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogPowerModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2828289)
        
        

        //--TRIMMABLE-BOUNDARY-START(5711873)
        $asm.$cls(`$IhzR.LCIDLS$1.LoggerDeviceSettingsCustomAttributesProvider`, ($self) => class LoggerDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300679169)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300679169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4300679169)
            
            static $h = 5711873;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300679169),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5711873,
      "h": 4300679169,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4300679169)
  ],
  "h": 5711873
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Settings${separator}LoggerDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5711873)
        
        

        //--TRIMMABLE-BOUNDARY-START(206849)
        $asm.$cls(`$IhzR.LCIDL$1._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295174145)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295174145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$IhzR.LCIDL$1.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295174145)
            
            static $h = 206849;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295174145),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 206849,
      "h": 4295174145,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295174145)
  ],
  "h": 206849
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(206849)
        
        

        //--TRIMMABLE-BOUNDARY-START(2304001)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogInputModelCustomAttributesProvider`, ($self) => class LoggerLogInputModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297271297)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297271297)
            
            //--TRIMMABLE-BOUNDARY-START(8592238593)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592238593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$IhzR.LCIDLM.LoggerLogInputModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Title", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((1039), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Icon", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((1039), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Color", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((1039), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$IhzR.LCIDLM.LoggerLogInputModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $iOyWYk ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2304001,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $PmKFfg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2304001,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$IhzR.LCIDLM.LoggerLogModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592238593)
            
            static $h = 2304001;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592238593),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2304001,
      "h": 8592238593,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592238593)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297271297),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2304001,
      "h": 4297271297,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297271297)
  ],
  "h": 2304001
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogInputModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogInputModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2304001)
        
        

        //--TRIMMABLE-BOUNDARY-START(5449729)
        $asm.$cls(`$IhzR.LCIDLS$1.LoggerDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class LoggerDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300417025)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300417025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider$$($.$IhzR.LCIDLS$1.LoggerActions).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4300417025)
            
            static $h = 5449729;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300417025),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5449729,
      "h": 4300417025,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4300417025)
  ],
  "h": 5449729
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Settings${separator}LoggerDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5449729)
        
        

        //--TRIMMABLE-BOUNDARY-START(5187585)
        $asm.$cls(`$IhzR.LCIDLS$1.LoggerActionsCustomAttributesProvider`, ($self) => class LoggerActionsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300154881)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300154881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4300154881)
            
            static $h = 5187585;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300154881),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5187585,
      "h": 4300154881,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4300154881)
  ],
  "h": 5187585
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Settings.LoggerActionsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Settings${separator}LoggerActionsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5187585)
        
        

        //--TRIMMABLE-BOUNDARY-START(1255425)
        $asm.$cls(`$IhzR.LCIDLM.LoggerDeviceModelCustomAttributesProvider`, ($self) => class LoggerDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296222721)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296222721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296222721)
            
            static $h = 1255425;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296222721),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1255425,
      "h": 4296222721,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296222721)
  ],
  "h": 1255425
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1255425)
        
        

        //--TRIMMABLE-BOUNDARY-START(3090433)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogTypeCustomAttributesProvider`, ($self) => class LoggerLogTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298057729)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298057729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298057729)
            
            static $h = 3090433;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298057729),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3090433,
      "h": 4298057729,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298057729)
  ],
  "h": 3090433
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3090433)
        
        

        //--TRIMMABLE-BOUNDARY-START(5318657)
        $asm.$cls(`$IhzR.LCIDLS$1.LoggerBroadcastPeerMessagesCustomAttributesProvider`, ($self) => class LoggerBroadcastPeerMessagesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300285953)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300285953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4300285953)
            
            static $h = 5318657;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300285953),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5318657,
      "h": 4300285953,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4300285953)
  ],
  "h": 5318657
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Settings.LoggerBroadcastPeerMessagesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Settings${separator}LoggerBroadcastPeerMessagesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5318657)
        
        

        //--TRIMMABLE-BOUNDARY-START(4597761)
        $asm.$cls(`$IhzR.LCIDLMS.LoggerReceivedStatusModelCustomAttributesProvider`, ($self) => class LoggerReceivedStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299565057)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299565057)
            
            //--TRIMMABLE-BOUNDARY-START(8594532353)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594532353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$IhzR.LCIDLMS.LoggerReceivedStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(8, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("LogCapacity", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("LogCount", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SyncCount", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("LogType", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (4);
                            $i6.ConvertType = ($.$$.S.Byte.$type);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("UpTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (4);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Voltage", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Order = (4);
                            $i8.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Class=1", "//Quantization=500"], [-1], null);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Usage", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SyncPercent", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$IhzR.LCIDLMS.LoggerReceivedStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $KnreSe ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4597761,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $uIEJHh ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4597761,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594532353)
            
            static $h = 4597761;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594532353),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4597761,
      "h": 8594532353,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594532353)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299565057),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4597761,
      "h": 4299565057,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299565057)
  ],
  "h": 4597761
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Statuses${separator}LoggerReceivedStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4597761)
        
        

        //--TRIMMABLE-BOUNDARY-START(3811329)
        $asm.$cls(`$IhzR.LCIDLM.LoggerStatusModelCustomAttributesProvider`, ($self) => class LoggerStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298778625)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298778625)
            
            //--TRIMMABLE-BOUNDARY-START(8593745921)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593745921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$IhzR.LCIDLM.LoggerStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Power", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Flags = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Input", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Flags = (1);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Voltage", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Flags = (1);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$IhzR.LCIDLM.LoggerStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $TXKEbl ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3811329,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $cKlHRe ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3811329,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICM.IOTDeviceStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593745921)
            
            static $h = 3811329;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593745921),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3811329,
      "h": 8593745921,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593745921)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298778625),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3811329,
      "h": 4298778625,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298778625)
  ],
  "h": 3811329
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3811329)
        
        

        //--TRIMMABLE-BOUNDARY-START(4335617)
        $asm.$cls(`$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelCustomAttributesProvider`, ($self) => class LoggerGetPowerAnalyticsResponseModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299302913)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299302913)
            
            //--TRIMMABLE-BOUNDARY-START(8594270209)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594270209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(5, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("PowerCuts", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.ConvertType = ($.$$.S.UInt16.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("UpTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DownTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("UpTimeSpan", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DownTimeSpan", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $IfTIjb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4335617,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $AkkAjl ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4335617,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594270209)
            
            static $h = 4335617;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594270209),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4335617,
      "h": 8594270209,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594270209)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299302913),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4335617,
      "h": 4299302913,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299302913)
  ],
  "h": 4335617
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetPowerAnalyticsResponseModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Statuses${separator}LoggerGetPowerAnalyticsResponseModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4335617)
        
        

        //--TRIMMABLE-BOUNDARY-START(1124353)
        $asm.$cls(`$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModelTypeDescriptorBuilder`, ($self) => class LoggerGetAnalyticsCommandModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591058945)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591058945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModelTypeDescriptor()
                        const $t1 = $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Logger.Models.Controls.LoggerGetAnalyticsCommandModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $nRRoAi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1124353,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591058945)
            
            //--TRIMMABLE-BOUNDARY-START(4296091649)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296091649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296091649)
            
            //--TRIMMABLE-BOUNDARY-START(4296091649)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296091649)
            
            static $h = 1124353;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591058945),
    {
      "r": 65537,
      "n": "Register",
      "d": 1124353,
      "h": 8591058945,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591058945)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296091649),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1124353,
      "h": 4296091649,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296091649)
  ],
  "h": 1124353
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Controls.LoggerGetAnalyticsCommandModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Controls${separator}LoggerGetAnalyticsCommandModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1124353)
        
        

        //--TRIMMABLE-BOUNDARY-START(337921)
        $asm.$cls(`$IhzR.LCIDL$1.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295305217)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295305217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModelCustomAttributesProvider, $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLM.LoggerDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLM.LoggerDeviceModelCustomAttributesProvider, $.$IhzR.LCIDLM.LoggerDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModelCustomAttributesProvider, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLM.LoggerDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLM.LoggerDeviceScopeModelCustomAttributesProvider, $.$IhzR.LCIDLM.LoggerDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLM.LoggerDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLM.LoggerDeviceSendDataModelCustomAttributesProvider, $.$IhzR.LCIDLM.LoggerDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLM.LoggerLogInputModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLM.LoggerLogInputModelCustomAttributesProvider, $.$IhzR.LCIDLM.LoggerLogInputModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLM.LoggerLogModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLM.LoggerLogModelCustomAttributesProvider, $.$IhzR.LCIDLM.LoggerLogModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLM.LoggerLogPowerModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLM.LoggerLogPowerModelCustomAttributesProvider, $.$IhzR.LCIDLM.LoggerLogPowerModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLM.LoggerLogType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLM.LoggerLogTypeCustomAttributesProvider, $.$IhzR.LCIDLM.LoggerLogTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLM.LoggerLogVoltageModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLM.LoggerLogVoltageModelCustomAttributesProvider, $.$IhzR.LCIDLM.LoggerLogVoltageModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLM.LoggerServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLM.LoggerServiceModelCustomAttributesProvider, $.$IhzR.LCIDLM.LoggerServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModelCustomAttributesProvider, $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelCustomAttributesProvider, $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLMS.LoggerReceivedStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLMS.LoggerReceivedStatusModelCustomAttributesProvider, $.$IhzR.LCIDLMS.LoggerReceivedStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLM.LoggerStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLM.LoggerStatusModelCustomAttributesProvider, $.$IhzR.LCIDLM.LoggerStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLS$1.LoggerBroadcastPeerMessages.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLS$1.LoggerBroadcastPeerMessagesCustomAttributesProvider, $.$IhzR.LCIDLS$1.LoggerBroadcastPeerMessagesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLS$1.LoggerActions.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLS$1.LoggerActionsCustomAttributesProvider, $.$IhzR.LCIDLS$1.LoggerActionsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettingsCustomAttributesProvider, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$IhzR.LCIDLS$1.LoggerDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$IhzR.LCIDLS$1.LoggerDeviceSettingsCustomAttributesProvider, $.$IhzR.LCIDLS$1.LoggerDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295305217)
            
            static $h = 337921;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295305217),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 337921,
      "h": 4295305217,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295305217)
  ],
  "h": 337921
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(337921)
        
        

        //--TRIMMABLE-BOUNDARY-START(403457)
        $asm.$cls(`$IhzR.LCIDL$1.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295370753)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295370753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295370753)
            
            static $h = 403457;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295370753),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 403457,
      "h": 4295370753,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295370753)
  ],
  "h": 403457
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(403457)
        
        

        //--TRIMMABLE-BOUNDARY-START(3287041)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogVoltageModelCustomAttributesProvider`, ($self) => class LoggerLogVoltageModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298254337)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298254337)
            
            //--TRIMMABLE-BOUNDARY-START(8593221633)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593221633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$IhzR.LCIDLM.LoggerLogVoltageModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(4, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Voltage", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (4);
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Class=1"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Title", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((1039), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Icon", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((1039), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Color", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((1039), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$IhzR.LCIDLM.LoggerLogVoltageModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $CAaIXh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3287041,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $ECpnPg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3287041,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$IhzR.LCIDLM.LoggerLogModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593221633)
            
            static $h = 3287041;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593221633),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3287041,
      "h": 8593221633,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593221633)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298254337),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3287041,
      "h": 4298254337,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298254337)
  ],
  "h": 3287041
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogVoltageModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogVoltageModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3287041)
        
        

        //--TRIMMABLE-BOUNDARY-START(2697217)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogModelTypeDescriptorBuilder`, ($self) => class LoggerLogModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592631809)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592631809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$IhzR.LCIDLM.LoggerLogModelTypeDescriptor()
                        const $t1 = $.$IhzR.LCIDLM.LoggerLogModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $MNMvVf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2697217,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$IhzR.LCIDLM.LoggerLogModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592631809)
            
            //--TRIMMABLE-BOUNDARY-START(4297664513)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297664513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297664513)
            
            //--TRIMMABLE-BOUNDARY-START(4297664513)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297664513)
            
            static $h = 2697217;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592631809),
    {
      "r": 65537,
      "n": "Register",
      "d": 2697217,
      "h": 8592631809,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592631809)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297664513),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2697217,
      "h": 4297664513,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297664513)
  ],
  "h": 2697217
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2697217)
        
        

        //--TRIMMABLE-BOUNDARY-START(993281)
        $asm.$cls(`$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModelCustomAttributesProvider`, ($self) => class LoggerGetAnalyticsCommandModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295960577)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295960577)
            
            //--TRIMMABLE-BOUNDARY-START(8590927873)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590927873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("StartTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            $i3.ConvertType = ($.$$.S.UInt32.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("EndTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (4);
                            $i4.ConvertType = ($.$$.S.UInt32.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $UAqAmb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":993281,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $LZgcOk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":993281,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590927873)
            
            static $h = 993281;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590927873),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 993281,
      "h": 8590927873,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590927873)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295960577),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 993281,
      "h": 4295960577,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295960577)
  ],
  "h": 993281
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Controls.LoggerGetAnalyticsCommandModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Controls${separator}LoggerGetAnalyticsCommandModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(993281)
        
        

        //--TRIMMABLE-BOUNDARY-START(3680257)
        $asm.$cls(`$IhzR.LCIDLM.LoggerServiceModelTypeDescriptorBuilder`, ($self) => class LoggerServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593614849)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593614849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$IhzR.LCIDLM.LoggerServiceModelTypeDescriptor()
                        const $t1 = $.$IhzR.LCIDLM.LoggerServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Logger.Models.LoggerServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $vuwFfg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3680257,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$IhzR.LCIDLM.LoggerServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593614849)
            
            //--TRIMMABLE-BOUNDARY-START(4298647553)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298647553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298647553)
            
            //--TRIMMABLE-BOUNDARY-START(4298647553)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298647553)
            
            static $h = 3680257;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593614849),
    {
      "r": 65537,
      "n": "Register",
      "d": 3680257,
      "h": 8593614849,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593614849)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298647553),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3680257,
      "h": 4298647553,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298647553)
  ],
  "h": 3680257
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3680257)
        
        

        //--TRIMMABLE-BOUNDARY-START(5908481)
        $asm.$cls(`$IhzR.LCIDL$1.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4300875777)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300875777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModelTypeDescriptorBuilder.Register();
                $.$IhzR.LCIDLM.LoggerDeviceModelTypeDescriptorBuilder.Register();
                $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$IhzR.LCIDLM.LoggerDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$IhzR.LCIDLM.LoggerDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$IhzR.LCIDLM.LoggerLogInputModelTypeDescriptorBuilder.Register();
                $.$IhzR.LCIDLM.LoggerLogModelTypeDescriptorBuilder.Register();
                $.$IhzR.LCIDLM.LoggerLogPowerModelTypeDescriptorBuilder.Register();
                $.$IhzR.LCIDLM.LoggerLogVoltageModelTypeDescriptorBuilder.Register();
                $.$IhzR.LCIDLM.LoggerServiceModelTypeDescriptorBuilder.Register();
                $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModelTypeDescriptorBuilder.Register();
                $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelTypeDescriptorBuilder.Register();
                $.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptorBuilder.Register();
                $.$IhzR.LCIDLM.LoggerStatusModelTypeDescriptorBuilder.Register();
                $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$IhzR.LCIDLS$1.LoggerDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4300875777)
            
            static $h = 5908481;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300875777),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 5908481,
      "h": 4300875777,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4300875777)
  ],
  "h": 5908481
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5908481)
        
        

        //--TRIMMABLE-BOUNDARY-START(2172929)
        $asm.$cls(`$IhzR.LCIDLM.LoggerDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class LoggerDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592107521)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592107521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$IhzR.LCIDLM.LoggerDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$IhzR.LCIDLM.LoggerDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $XmXyzc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2172929,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$IhzR.LCIDLM.LoggerDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592107521)
            
            //--TRIMMABLE-BOUNDARY-START(4297140225)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297140225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297140225)
            
            //--TRIMMABLE-BOUNDARY-START(4297140225)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297140225)
            
            static $h = 2172929;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592107521),
    {
      "r": 65537,
      "n": "Register",
      "d": 2172929,
      "h": 8592107521,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592107521)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297140225),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2172929,
      "h": 4297140225,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297140225)
  ],
  "h": 2172929
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2172929)
        
        

        //--TRIMMABLE-BOUNDARY-START(1386497)
        $asm.$cls(`$IhzR.LCIDLM.LoggerDeviceModelTypeDescriptorBuilder`, ($self) => class LoggerDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591321089)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591321089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$IhzR.LCIDLM.LoggerDeviceModelTypeDescriptor()
                        const $t1 = $.$IhzR.LCIDLM.LoggerDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $bdwpFg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1386497,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$IhzR.LCIDLM.LoggerDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591321089)
            
            //--TRIMMABLE-BOUNDARY-START(4296353793)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296353793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296353793)
            
            //--TRIMMABLE-BOUNDARY-START(4296353793)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296353793)
            
            static $h = 1386497;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591321089),
    {
      "r": 65537,
      "n": "Register",
      "d": 1386497,
      "h": 8591321089,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591321089)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296353793),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1386497,
      "h": 4296353793,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296353793)
  ],
  "h": 1386497
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1386497)
        
        

        //--TRIMMABLE-BOUNDARY-START(1910785)
        $asm.$cls(`$IhzR.LCIDLM.LoggerDeviceScopeModelTypeDescriptorBuilder`, ($self) => class LoggerDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591845377)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591845377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$IhzR.LCIDLM.LoggerDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$IhzR.LCIDLM.LoggerDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $kMHhLi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1910785,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$IhzR.LCIDLM.LoggerDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591845377)
            
            //--TRIMMABLE-BOUNDARY-START(4296878081)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296878081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296878081)
            
            //--TRIMMABLE-BOUNDARY-START(4296878081)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296878081)
            
            static $h = 1910785;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591845377),
    {
      "r": 65537,
      "n": "Register",
      "d": 1910785,
      "h": 8591845377,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591845377)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296878081),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1910785,
      "h": 4296878081,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296878081)
  ],
  "h": 1910785
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1910785)
        
        

        //--TRIMMABLE-BOUNDARY-START(4466689)
        $asm.$cls(`$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelTypeDescriptorBuilder`, ($self) => class LoggerGetPowerAnalyticsResponseModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594401281)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594401281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelTypeDescriptor()
                        const $t1 = $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetPowerAnalyticsResponseModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $DxOShd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4466689,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594401281)
            
            //--TRIMMABLE-BOUNDARY-START(4299433985)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299433985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299433985)
            
            //--TRIMMABLE-BOUNDARY-START(4299433985)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299433985)
            
            static $h = 4466689;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594401281),
    {
      "r": 65537,
      "n": "Register",
      "d": 4466689,
      "h": 8594401281,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594401281)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299433985),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4466689,
      "h": 4299433985,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299433985)
  ],
  "h": 4466689
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetPowerAnalyticsResponseModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Statuses${separator}LoggerGetPowerAnalyticsResponseModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4466689)
        
        

        //--TRIMMABLE-BOUNDARY-START(2435073)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogInputModelTypeDescriptorBuilder`, ($self) => class LoggerLogInputModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592369665)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592369665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$IhzR.LCIDLM.LoggerLogInputModelTypeDescriptor()
                        const $t1 = $.$IhzR.LCIDLM.LoggerLogInputModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogInputModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $UCvsua ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2435073,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$IhzR.LCIDLM.LoggerLogInputModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592369665)
            
            //--TRIMMABLE-BOUNDARY-START(4297402369)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297402369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297402369)
            
            //--TRIMMABLE-BOUNDARY-START(4297402369)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297402369)
            
            static $h = 2435073;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592369665),
    {
      "r": 65537,
      "n": "Register",
      "d": 2435073,
      "h": 8592369665,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592369665)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297402369),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2435073,
      "h": 4297402369,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297402369)
  ],
  "h": 2435073
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogInputModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogInputModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2435073)
        
        

        //--TRIMMABLE-BOUNDARY-START(3942401)
        $asm.$cls(`$IhzR.LCIDLM.LoggerStatusModelTypeDescriptorBuilder`, ($self) => class LoggerStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593876993)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593876993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$IhzR.LCIDLM.LoggerStatusModelTypeDescriptor()
                        const $t1 = $.$IhzR.LCIDLM.LoggerStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Logger.Models.LoggerStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $dEOKxa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3942401,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$IhzR.LCIDLM.LoggerStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593876993)
            
            //--TRIMMABLE-BOUNDARY-START(4298909697)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298909697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298909697)
            
            //--TRIMMABLE-BOUNDARY-START(4298909697)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298909697)
            
            static $h = 3942401;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593876993),
    {
      "r": 65537,
      "n": "Register",
      "d": 3942401,
      "h": 8593876993,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593876993)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298909697),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3942401,
      "h": 4298909697,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298909697)
  ],
  "h": 3942401
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3942401)
        
        

        //--TRIMMABLE-BOUNDARY-START(5580801)
        $asm.$cls(`$IhzR.LCIDLS$1.LoggerDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class LoggerDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595515393)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595515393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $vxOSle ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5580801,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595515393)
            
            //--TRIMMABLE-BOUNDARY-START(4300548097)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300548097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300548097)
            
            //--TRIMMABLE-BOUNDARY-START(4300548097)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300548097)
            
            static $h = 5580801;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595515393),
    {
      "r": 65537,
      "n": "Register",
      "d": 5580801,
      "h": 8595515393,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595515393)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300548097),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5580801,
      "h": 4300548097,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300548097)
  ],
  "h": 5580801
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Settings${separator}LoggerDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5580801)
        
        

        //--TRIMMABLE-BOUNDARY-START(2959361)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogPowerModelTypeDescriptorBuilder`, ($self) => class LoggerLogPowerModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592893953)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592893953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$IhzR.LCIDLM.LoggerLogPowerModelTypeDescriptor()
                        const $t1 = $.$IhzR.LCIDLM.LoggerLogPowerModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogPowerModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $qtjmHb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2959361,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$IhzR.LCIDLM.LoggerLogPowerModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592893953)
            
            //--TRIMMABLE-BOUNDARY-START(4297926657)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297926657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297926657)
            
            //--TRIMMABLE-BOUNDARY-START(4297926657)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297926657)
            
            static $h = 2959361;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592893953),
    {
      "r": 65537,
      "n": "Register",
      "d": 2959361,
      "h": 8592893953,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592893953)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297926657),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2959361,
      "h": 4297926657,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297926657)
  ],
  "h": 2959361
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogPowerModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogPowerModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2959361)
        
        

        //--TRIMMABLE-BOUNDARY-START(3418113)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogVoltageModelTypeDescriptorBuilder`, ($self) => class LoggerLogVoltageModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593352705)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593352705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$IhzR.LCIDLM.LoggerLogVoltageModelTypeDescriptor()
                        const $t1 = $.$IhzR.LCIDLM.LoggerLogVoltageModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogVoltageModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $JgnVXc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3418113,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$IhzR.LCIDLM.LoggerLogVoltageModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593352705)
            
            //--TRIMMABLE-BOUNDARY-START(4298385409)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298385409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298385409)
            
            //--TRIMMABLE-BOUNDARY-START(4298385409)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298385409)
            
            static $h = 3418113;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593352705),
    {
      "r": 65537,
      "n": "Register",
      "d": 3418113,
      "h": 8593352705,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593352705)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298385409),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3418113,
      "h": 4298385409,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298385409)
  ],
  "h": 3418113
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogVoltageModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogVoltageModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3418113)
        
        

        //--TRIMMABLE-BOUNDARY-START(1648641)
        $asm.$cls(`$IhzR.LCIDLM.LoggerDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class LoggerDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591583233)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591583233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $justuh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1648641,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591583233)
            
            //--TRIMMABLE-BOUNDARY-START(4296615937)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296615937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296615937)
            
            //--TRIMMABLE-BOUNDARY-START(4296615937)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296615937)
            
            static $h = 1648641;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591583233),
    {
      "r": 65537,
      "n": "Register",
      "d": 1648641,
      "h": 8591583233,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591583233)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296615937),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1648641,
      "h": 4296615937,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296615937)
  ],
  "h": 1648641
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1648641)
        
        

        //--TRIMMABLE-BOUNDARY-START(5842945)
        $asm.$cls(`$IhzR.LCIDLS$1.LoggerDeviceSettingsTypeDescriptorBuilder`, ($self) => class LoggerDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595777537)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595777537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$IhzR.LCIDLS$1.LoggerDeviceSettingsTypeDescriptor()
                        const $t1 = $.$IhzR.LCIDLS$1.LoggerDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ssGNDb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5842945,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$IhzR.LCIDLS$1.LoggerDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595777537)
            
            //--TRIMMABLE-BOUNDARY-START(4300810241)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300810241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300810241)
            
            //--TRIMMABLE-BOUNDARY-START(4300810241)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300810241)
            
            static $h = 5842945;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595777537),
    {
      "r": 65537,
      "n": "Register",
      "d": 5842945,
      "h": 8595777537,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595777537)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300810241),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5842945,
      "h": 4300810241,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300810241)
  ],
  "h": 5842945
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Settings${separator}LoggerDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5842945)
        
        

        //--TRIMMABLE-BOUNDARY-START(4204545)
        $asm.$cls(`$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModelTypeDescriptorBuilder`, ($self) => class LoggerGetInputAnalyticsResponseModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594139137)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594139137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModelTypeDescriptor()
                        const $t1 = $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetInputAnalyticsResponseModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $QAWTlh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4204545,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594139137)
            
            //--TRIMMABLE-BOUNDARY-START(4299171841)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299171841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299171841)
            
            //--TRIMMABLE-BOUNDARY-START(4299171841)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299171841)
            
            static $h = 4204545;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594139137),
    {
      "r": 65537,
      "n": "Register",
      "d": 4204545,
      "h": 8594139137,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594139137)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299171841),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4204545,
      "h": 4299171841,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299171841)
  ],
  "h": 4204545
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetInputAnalyticsResponseModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Statuses${separator}LoggerGetInputAnalyticsResponseModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4204545)
        
        

        //--TRIMMABLE-BOUNDARY-START(4728833)
        $asm.$cls(`$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptorBuilder`, ($self) => class LoggerReceivedStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594663425)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594663425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor()
                        const $t1 = $.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $lPErui ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4728833,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$IhzR.LCIDLMS.LoggerReceivedStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594663425)
            
            //--TRIMMABLE-BOUNDARY-START(4299696129)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299696129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299696129)
            
            //--TRIMMABLE-BOUNDARY-START(4299696129)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299696129)
            
            static $h = 4728833;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594663425),
    {
      "r": 65537,
      "n": "Register",
      "d": 4728833,
      "h": 8594663425,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594663425)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299696129),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4728833,
      "h": 4299696129,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299696129)
  ],
  "h": 4728833
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Statuses${separator}LoggerReceivedStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4728833)
        
        

        //--TRIMMABLE-BOUNDARY-START(272385)
        $asm.$cls(`$IhzR.LCIDL$1.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180141569)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180141569)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295239681)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295239681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295239681)
            
            //--TRIMMABLE-BOUNDARY-START(4295239681)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295239681)
            
            static $h = 272385;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180141569),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885174273,
        "f": 50331649
      },
      "n": "Paths",
      "d": 272385,
      "h": 17180141569,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180141569)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295239681),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 272385,
      "h": 4295239681,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295239681)
  ],
  "h": 272385
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(272385)
        
        

        //--TRIMMABLE-BOUNDARY-START(4007937)
        $asm.$cls(`$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel`, ($self) => class LoggerGetInputAnalyticsResponseModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12888909825)
            /*int*/ Count = 0;
            //--TRIMMABLE-BOUNDARY-END(12888909825)
            
            //--TRIMMABLE-BOUNDARY-START(8593942529)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593942529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593942529)
            
            //--TRIMMABLE-BOUNDARY-START(8593942529)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8593942529)
            
            static $h = 4007937;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12888909825),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478844417,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30068779009,
        "f": 83886081
      },
      "n": "Count",
      "d": 4007937,
      "h": 12888909825,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12888909825)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593942529),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4007937,
      "h": 8593942529,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593942529)
  ],
  "h": 4007937
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetInputAnalyticsResponseModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Statuses${separator}LoggerGetInputAnalyticsResponseModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4007937)
        
        

        //--TRIMMABLE-BOUNDARY-START(4270081)
        $asm.$cls(`$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel`, ($self) => class LoggerGetPowerAnalyticsResponseModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(73018714113)
            /*int*/ PowerCuts = 0;
            //--TRIMMABLE-BOUNDARY-END(73018714113)
            
            //--TRIMMABLE-BOUNDARY-START(103083485185)
            /*int*/ UpTime = 0;
            //--TRIMMABLE-BOUNDARY-END(103083485185)
            
            //--TRIMMABLE-BOUNDARY-START(21479106561)
            /*int*/ DownTime = 0;
            //--TRIMMABLE-BOUNDARY-END(21479106561)
            
            //--TRIMMABLE-BOUNDARY-START(107378452481)
            /*TimeSpan */ get UpTimeSpan()
            {
                return new $.$$.S.TimeSpan().$ctor$6(0, 0, this.UpTime);
            }
            //--TRIMMABLE-BOUNDARY-END(107378452481)
            
            //--TRIMMABLE-BOUNDARY-START(25774073857)
            /*TimeSpan */ get DownTimeSpan()
            {
                return new $.$$.S.TimeSpan().$ctor$6(0, 0, this.DownTime);
            }
            //--TRIMMABLE-BOUNDARY-END(25774073857)
            
            //--TRIMMABLE-BOUNDARY-START(17184139265)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184139265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17184139265)
            
            //--TRIMMABLE-BOUNDARY-START(17184139265)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17184139265)
            
            static $h = 4270081;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73018714113),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51543877633,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90198583297,
        "f": 83886081
      },
      "n": "PowerCuts",
      "d": 4270081,
      "h": 73018714113,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73018714113),
//--TRIMMABLE-BOUNDARY-START(103083485185),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60133812225,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98788517889,
        "f": 83886081
      },
      "n": "UpTime",
      "d": 4270081,
      "h": 103083485185,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103083485185),
//--TRIMMABLE-BOUNDARY-START(21479106561),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34364008449,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81608648705,
        "f": 83886081
      },
      "n": "DownTime",
      "d": 4270081,
      "h": 21479106561,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21479106561),
//--TRIMMABLE-BOUNDARY-START(107378452481),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68723746817,
        "f": 50331649
      },
      "n": "UpTimeSpan",
      "d": 4270081,
      "h": 107378452481,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107378452481),
//--TRIMMABLE-BOUNDARY-START(25774073857),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42953943041,
        "f": 50331649
      },
      "n": "DownTimeSpan",
      "d": 4270081,
      "h": 25774073857,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25774073857)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17184139265),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4270081,
      "h": 17184139265,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17184139265)
  ],
  "h": 4270081
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetPowerAnalyticsResponseModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Statuses${separator}LoggerGetPowerAnalyticsResponseModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4270081)
        
        

        //--TRIMMABLE-BOUNDARY-START(3155969)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogTypeProvider`, ($self) => class LoggerLogTypeProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593090561)
            /*Type */ GetType$1(/*PacketBuilder*/ packet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593090561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let type = $.$cast(packet.get_Item$1(((packet.Index + 5) | 0)), $.$IhzR.LCIDLM.LoggerLogType);
                switch(type)
                {
                    case 1/*LoggerLogType.PowerDown*/:
                    case 2/*LoggerLogType.PowerUp*/:
                    return $.$IhzR.LCIDLM.LoggerLogPowerModel.$type;
                    case 4/*LoggerLogType.Input*/:
                    return $.$IhzR.LCIDLM.LoggerLogInputModel.$type;
                    case 3/*LoggerLogType.Voltage*/:
                    return $.$IhzR.LCIDLM.LoggerLogVoltageModel.$type;
                    default:
                    return $.$IhzR.LCIDLM.LoggerLogPowerModel.$type;
                }
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(8593090561)
            
            //--TRIMMABLE-BOUNDARY-START(4315646294)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IPacketBuilderDataTypeProvider.GetType(LivingThing.Core.Frameworks.Common.Data.PacketBuilder)
            LCFCD$IPacketBuilderDataTypeProvider$GetType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4315646294);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetType$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4315646294)
            
            //--TRIMMABLE-BOUNDARY-START(4298123265)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298123265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298123265)
            
            //--TRIMMABLE-BOUNDARY-START(4298123265)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298123265)
            
            static $h = 3155969;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593090561),
    {
      "r": 188547073,
      "p": [
        {
          "n": "packet",
          "p": 31164758
        }
      ],
      "n": "GetType",
      "o": "@$1",
      "d": 3155969,
      "h": 8593090561,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593090561)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298123265),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3155969,
      "h": 4298123265,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298123265)
  ],
  "h": 3155969
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IPacketBuilderDataTypeProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogTypeProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogTypeProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3155969)
        
        

        //--TRIMMABLE-BOUNDARY-START(4859905)
        $asm.$cls(`$IhzR.LCIDL$1.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594794497)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594794497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$IhzR.LCIDL$1.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerStatusModel), $.$IhzR.LCIDL$1.LoggerReceivedDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$XBGm.LCICM.IOTDeviceStatusModel, $.$IhzR.LCIDLM.LoggerStatusModel), $.$IhzR.LCIDL$1.LoggerStatusDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$IhzR.LCIDL$1.LoggerDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$IhzR.LCIDL$1.LoggerDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$IhzR.LCIDL$1.LoggerDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$IhzR.LCIDL$1.LoggerDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IhzR.LCIDL$1.LoggerDeviceFamily, x);
                }, $SXEXmk ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":4859905,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IhzR.LCIDL$1.LoggerDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$IhzR.LCIDL$1.LoggerDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $ImkxAi ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":4859905,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$IhzR.LCIDL$1.LoggerDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IhzR.LCIDL$1.LoggerDeviceFamily, x);
                }, $UksQze ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$IhzR.LCIDL$1.LoggerDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":4859905,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$IhzR.LCIDL$1.LoggerDevice, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$IhzR.LCIDL$1.LoggerDevice, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$IhzR.LCIDL$1.LoggerDevice, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$IhzR.LCIDL$1.LoggerDevice), $.$IhzR.LCIDLMC.LoggerDeviceCommands$$($.$IhzR.LCIDL$1.LoggerDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$IhzR.LCIDL$1.LoggerDevice), $.$IhzR.LCIDLV.LoggerViewRenderer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8594794497)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$IhzR.LCIDL$1.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4299827201)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299827201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299827201)
            
            //--TRIMMABLE-BOUNDARY-START(4299827201)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299827201)
            
            static $h = 4859905;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594794497),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 4859905,
      "h": 8594794497,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594794497)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299827201),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4859905,
      "h": 4299827201,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299827201)
  ],
  "h": 4859905
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4859905)
        
        

        //--TRIMMABLE-BOUNDARY-START(4794369)
        $asm.$cls(`$IhzR.LCIDL$1.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17184663553)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$IhzR.LCIDLV.LoggerDeviceDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$IhzR.LCIDLV.LoggerDeviceDetails().$ctor$4();
                    }, $EwntNh ??= {"r":2752627,"n":"","d":4794369,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$IhzR.LCIDLV.PowerLoggerUptime.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$IhzR.LCIDLV.PowerLoggerUptime().$ctor$5();
                    }, $EVaAEc ??= {"r":2752627,"n":"","d":4794369,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17184663553)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4299761665)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299761665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299761665)
            
            //--TRIMMABLE-BOUNDARY-START(4299761665)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299761665)
            
            static $h = 4794369;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17184663553),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12889696257,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 4794369,
      "h": 17184663553,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17184663553)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299761665),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4794369,
      "h": 4299761665,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299761665)
  ],
  "h": 4794369
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4794369)
        
        

        //--TRIMMABLE-BOUNDARY-START(6301697)
        $asm.$cls(`$IhzR.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4301268993)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301268993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301268993)
            
            //--TRIMMABLE-BOUNDARY-START(4301268993)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4301268993)
            
            static $h = 6301697;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301268993),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 6301697,
      "h": 4301268993,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301268993)
  ],
  "h": 6301697,
  "a": [
    {
      "t": 6236161,
      "c": 4301203457
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6301697)
        
        

        //--TRIMMABLE-BOUNDARY-START(6236161)
        $asm.$cls(`$IhzR.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4301203457)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301203457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301203457)
            
            //--TRIMMABLE-BOUNDARY-START(4301203457)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4301203457)
            
            static $h = 6236161;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301203457),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 6236161,
      "h": 4301203457,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301203457)
  ],
  "h": 6236161
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6236161)
        
        

        //--TRIMMABLE-BOUNDARY-START(927745)
        $asm.$cls(`$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel`, ($self) => class LoggerGetAnalyticsCommandModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(12885829633)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885829633);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885829633)
            
            //--TRIMMABLE-BOUNDARY-START(17180796929)
            $ctor$3(/*DateTime*/ startTime, /*DateTime*/ endTime)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180796929);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.StartTime = startTime;
                    this.EndTime = endTime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180796929)
            
            //--TRIMMABLE-BOUNDARY-START(21475764225)
            /*int */ get Command()
            {
                return ((128 + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(21475764225)
            
            //--TRIMMABLE-BOUNDARY-START(73015371777)
            /*DateTime*/ StartTime;
            //--TRIMMABLE-BOUNDARY-END(73015371777)
            
            //--TRIMMABLE-BOUNDARY-START(25770731521)
            /*DateTime*/ EndTime;
            //--TRIMMABLE-BOUNDARY-END(25770731521)
            
            //--TRIMMABLE-BOUNDARY-START(12885829633)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885829633)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(73015371777)
                this.StartTime = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(73015371777)
                
                //--TRIMMABLE-BOUNDARY-START(25770731521)
                this.EndTime = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(25770731521)
                
            }
            static $h = 927745;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475764225),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360666113,
        "f": 50364417
      },
      "n": "Command",
      "d": 927745,
      "h": 21475764225,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475764225),
//--TRIMMABLE-BOUNDARY-START(73015371777),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540535297,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720404481,
        "f": 83886082
      },
      "n": "StartTime",
      "d": 927745,
      "h": 73015371777,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 720897,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015371777),
//--TRIMMABLE-BOUNDARY-START(25770731521),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950600705,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130469889,
        "f": 83886082
      },
      "n": "EndTime",
      "d": 927745,
      "h": 25770731521,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 720897,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770731521)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885829633),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 927745,
      "h": 12885829633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885829633),
//--TRIMMABLE-BOUNDARY-START(17180796929),
    {
      "p": [
        {
          "n": "startTime",
          "p": 65994753
        },
        {
          "n": "endTime",
          "p": 65994753
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 927745,
      "h": 17180796929,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180796929)
  ],
  "h": 927745
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Controls.LoggerGetAnalyticsCommandModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Controls${separator}LoggerGetAnalyticsCommandModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(927745)
        
        

        //--TRIMMABLE-BOUNDARY-START(4532225)
        $asm.$cls(`$IhzR.LCIDLMS.LoggerReceivedStatusModel`, ($self) => class LoggerReceivedStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(107378714625)
            /*int*/ LogCapacity = 0;
            //--TRIMMABLE-BOUNDARY-END(107378714625)
            
            //--TRIMMABLE-BOUNDARY-START(111673681921)
            /*int*/ LogCount = 0;
            //--TRIMMABLE-BOUNDARY-END(111673681921)
            
            //--TRIMMABLE-BOUNDARY-START(176098191361)
            /*int*/ SyncCount = 0;
            //--TRIMMABLE-BOUNDARY-END(176098191361)
            
            //--TRIMMABLE-BOUNDARY-START(115968649217)
            /*LoggerLogType*/ LogType = 0;
            //--TRIMMABLE-BOUNDARY-END(115968649217)
            
            //--TRIMMABLE-BOUNDARY-START(188983093249)
            /*DateTime?*/ UpTime = null;
            //--TRIMMABLE-BOUNDARY-END(188983093249)
            
            //--TRIMMABLE-BOUNDARY-START(197573027841)
            /*int?*/ Voltage = null;
            //--TRIMMABLE-BOUNDARY-END(197573027841)
            
            //--TRIMMABLE-BOUNDARY-START(193278060545)
            /*double */ get Usage()
            {
                return $.$cast(this.LogCount, $.$$.S.Double) * 100 / this.LogCapacity;
            }
            //--TRIMMABLE-BOUNDARY-END(193278060545)
            
            //--TRIMMABLE-BOUNDARY-START(180393158657)
            /*double */ get SyncPercent()
            {
                return $.$cast(this.SyncCount, $.$$.S.Double) * 100 / this.LogCount;
            }
            //--TRIMMABLE-BOUNDARY-END(180393158657)
            
            //--TRIMMABLE-BOUNDARY-START(34364270593)
            /*void */ CompleteDecodeNotify()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34364270593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LogCount %= this.LogCapacity;
                this.SyncCount %= this.LogCapacity;
            }
            //--TRIMMABLE-BOUNDARY-END(34364270593)
            
            //--TRIMMABLE-BOUNDARY-START(120263616513)
            /*void */ PackTo(/*PacketBuilder*/ packet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120263616513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(120263616513)
            
            //--TRIMMABLE-BOUNDARY-START(184688125953)
            /*void */ UnPackFrom(/*PacketBuilder*/ packet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184688125953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LogCapacity = packet.GetSDWord(-1, 0);
                this.LogCount = packet.GetSDWord(-1, 0);
                this.SyncCount = packet.GetSDWord(-1, 0);
                this.LogType = $.$cast(packet.GetByte(-1), $.$IhzR.LCIDLM.LoggerLogType);
                if (this.LogType === 3/*LoggerLogType.Voltage*/)
                {
                    this.Voltage = packet.GetSDWord(-1, 0);
                }
                else if (this.LogType === 2/*LoggerLogType.PowerUp*/ || this.LogType === 1/*LoggerLogType.PowerDown*/)
                {
                    this.UpTime = $.$fPer.LCFCDC.PackedDateTime.UnPack(packet.GetDWord(-1, 0), 2020);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184688125953)
            
            //--TRIMMABLE-BOUNDARY-START(4311058774)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.ICompleteDecodeNotification.CompleteDecodeNotify()
            LCFCD$ICompleteDecodeNotification$CompleteDecodeNotify()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4311058774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CompleteDecodeNotify(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4311058774)
            
            //--TRIMMABLE-BOUNDARY-START(4315515222)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IPacketBuilder.PackTo(LivingThing.Core.Frameworks.Common.Data.PacketBuilder)
            LCFCD$IPacketBuilder$PackTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4315515222);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PackTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4315515222)
            
            //--TRIMMABLE-BOUNDARY-START(8610482518)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IPacketBuilder.UnPackFrom(LivingThing.Core.Frameworks.Common.Data.PacketBuilder)
            LCFCD$IPacketBuilder$UnPackFrom()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8610482518);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UnPackFrom(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8610482518)
            
            //--TRIMMABLE-BOUNDARY-START(30069303297)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30069303297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30069303297)
            
            //--TRIMMABLE-BOUNDARY-START(30069303297)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(30069303297)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(188983093249)
                this.UpTime = null;
                //--TRIMMABLE-BOUNDARY-END(188983093249)
                
            }
            static $h = 4532225;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107378714625),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42954205185,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128853551105,
        "f": 83886081
      },
      "n": "LogCapacity",
      "d": 4532225,
      "h": 107378714625,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107378714625),
//--TRIMMABLE-BOUNDARY-START(111673681921),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51544139777,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137443485697,
        "f": 83886081
      },
      "n": "LogCount",
      "d": 4532225,
      "h": 111673681921,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111673681921),
//--TRIMMABLE-BOUNDARY-START(176098191361),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68724008961,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154623354881,
        "f": 83886081
      },
      "n": "SyncCount",
      "d": 4532225,
      "h": 176098191361,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176098191361),
//--TRIMMABLE-BOUNDARY-START(115968649217),
    {
      "p": 3024897,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60134074369,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146033420289,
        "f": 83886081
      },
      "n": "LogType",
      "d": 4532225,
      "h": 115968649217,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115968649217),
//--TRIMMABLE-BOUNDARY-START(188983093249),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85903878145,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163213289473,
        "f": 83886081
      },
      "n": "UpTime",
      "d": 4532225,
      "h": 188983093249,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188983093249),
//--TRIMMABLE-BOUNDARY-START(197573027841),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103083747329,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171803224065,
        "f": 83886081
      },
      "n": "Voltage",
      "d": 4532225,
      "h": 197573027841,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "Options",
              "v": [
                "//Class=1",
                "//Quantization=500"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197573027841),
//--TRIMMABLE-BOUNDARY-START(193278060545),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94493812737,
        "f": 50331649
      },
      "n": "Usage",
      "d": 4532225,
      "h": 193278060545,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193278060545),
//--TRIMMABLE-BOUNDARY-START(180393158657),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77313943553,
        "f": 50331649
      },
      "n": "SyncPercent",
      "d": 4532225,
      "h": 180393158657,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180393158657)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34364270593),
    {
      "r": 65537,
      "n": "CompleteDecodeNotify",
      "d": 4532225,
      "h": 34364270593,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34364270593),
//--TRIMMABLE-BOUNDARY-START(120263616513),
    {
      "r": 65537,
      "p": [
        {
          "n": "packet",
          "p": 31164758
        }
      ],
      "n": "PackTo",
      "d": 4532225,
      "h": 120263616513,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120263616513),
//--TRIMMABLE-BOUNDARY-START(184688125953),
    {
      "r": 65537,
      "p": [
        {
          "n": "packet",
          "p": 31164758
        }
      ],
      "n": "UnPackFrom",
      "d": 4532225,
      "h": 184688125953,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184688125953)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30069303297),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4532225,
      "h": 30069303297,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30069303297)
  ],
  "h": 4532225
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder, $.$fPer.LCFCD.ICompleteDecodeNotification, $.$fPer.LCFCD.IPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Statuses${separator}LoggerReceivedStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4532225)
        
        

        //--TRIMMABLE-BOUNDARY-START(3221505)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogVoltageModel`, ($self) => class LoggerLogVoltageModel extends $.$IhzR.LCIDLM.LoggerLogModel
        {
            //--TRIMMABLE-BOUNDARY-START(85902567425)
            /*int*/ Voltage = 0;
            //--TRIMMABLE-BOUNDARY-END(85902567425)
            
            //--TRIMMABLE-BOUNDARY-START(68722698241)
            /*bool */ get IsValid()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(68722698241)
            
            //--TRIMMABLE-BOUNDARY-START(60132763649)
            /*double */ GetDataPoint(/*int*/ i)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132763649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Voltage;
            }
            //--TRIMMABLE-BOUNDARY-END(60132763649)
            
            //--TRIMMABLE-BOUNDARY-START(81607600129)
            /*string */ get Title()
            {
                return "Voltage";
            }
            //--TRIMMABLE-BOUNDARY-END(81607600129)
            
            //--TRIMMABLE-BOUNDARY-START(64427730945)
            /*string */ get Icon()
            {
                return "mdi mdi-database"/*MaterialDesignIconNames.Database*/;
            }
            //--TRIMMABLE-BOUNDARY-END(64427730945)
            
            //--TRIMMABLE-BOUNDARY-START(12888123393)
            /*string */ get Color()
            {
                return "error";
            }
            //--TRIMMABLE-BOUNDARY-END(12888123393)
            
            //--TRIMMABLE-BOUNDARY-START(8593156097)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593156097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593156097)
            
            //--TRIMMABLE-BOUNDARY-START(8593156097)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8593156097)
            
            static $h = 3221505;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$IhzR.LCIDLM.LoggerLogModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85902567425),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837796353,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77312632833,
        "f": 83886081
      },
      "n": "Voltage",
      "d": 3221505,
      "h": 85902567425,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "Options",
              "v": [
                "//Class=1"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85902567425),
//--TRIMMABLE-BOUNDARY-START(68722698241),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657927169,
        "f": 50364417
      },
      "n": "IsValid",
      "d": 3221505,
      "h": 68722698241,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68722698241),
//--TRIMMABLE-BOUNDARY-START(81607600129),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247861761,
        "f": 50364417
      },
      "n": "Title",
      "d": 3221505,
      "h": 81607600129,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81607600129),
//--TRIMMABLE-BOUNDARY-START(64427730945),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067992577,
        "f": 50364417
      },
      "n": "Icon",
      "d": 3221505,
      "h": 64427730945,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64427730945),
//--TRIMMABLE-BOUNDARY-START(12888123393),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478057985,
        "f": 50364417
      },
      "n": "Color",
      "d": 3221505,
      "h": 12888123393,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12888123393)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60132763649),
    {
      "r": 1179649,
      "p": [
        {
          "n": "i",
          "p": 655361
        }
      ],
      "n": "GetDataPoint",
      "d": 3221505,
      "h": 60132763649,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60132763649)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593156097),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3221505,
      "h": 8593156097,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593156097)
  ],
  "h": 3221505
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceLog, $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogVoltageModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogVoltageModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3221505)
        
        

        //--TRIMMABLE-BOUNDARY-START(2762753)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogPowerModel`, ($self) => class LoggerLogPowerModel extends $.$IhzR.LCIDLM.LoggerLogModel
        {
            //--TRIMMABLE-BOUNDARY-START(68722239489)
            /*bool */ get IsValid()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(68722239489)
            
            //--TRIMMABLE-BOUNDARY-START(60132304897)
            /*double */ GetDataPoint(/*int*/ i)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132304897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Event === 1/*LoggerLogType.PowerDown*/ ? 0 : 1;
            }
            //--TRIMMABLE-BOUNDARY-END(60132304897)
            
            //--TRIMMABLE-BOUNDARY-START(73017206785)
            /*string */ get Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837337601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Enum.ToStringT($.$IhzR.LCIDLM.LoggerLogType, $.$$.S.UInt32, this.Event));
            }
            //--TRIMMABLE-BOUNDARY-END(73017206785)
            
            //--TRIMMABLE-BOUNDARY-START(12887664641)
            /*string? */ get Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067533825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(this.Event)
                {
                    case 1/*LoggerLogType.PowerDown*/:
                    return "Power cut";
                    case 2/*LoggerLogType.PowerUp*/:
                    return "Power restored";
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(12887664641)
            
            //--TRIMMABLE-BOUNDARY-START(64427272193)
            /*string? */ get Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657468417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(this.Event)
                {
                    case 1/*LoggerLogType.PowerDown*/:
                    return "mdi mdi-lightbulb-off"/*MaterialDesignIconNames.LightbulbOff*/;
                    case 2/*LoggerLogType.PowerUp*/:
                    return "mdi mdi-lightbulb-on"/*MaterialDesignIconNames.LightbulbOn*/;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(64427272193)
            
            //--TRIMMABLE-BOUNDARY-START(8592697345)
            /*string? */ get Color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477599233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(this.Event)
                {
                    case 1/*LoggerLogType.PowerDown*/:
                    return "error";
                    case 2/*LoggerLogType.PowerUp*/:
                    return "success";
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8592697345)
            
            //--TRIMMABLE-BOUNDARY-START(4297730049)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297730049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297730049)
            
            //--TRIMMABLE-BOUNDARY-START(4297730049)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297730049)
            
            static $h = 2762753;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$IhzR.LCIDLM.LoggerLogModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68722239489),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247403009,
        "f": 50364417
      },
      "n": "IsValid",
      "d": 2762753,
      "h": 68722239489,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68722239489),
//--TRIMMABLE-BOUNDARY-START(73017206785),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837337601,
        "f": 50364417
      },
      "n": "Title",
      "d": 2762753,
      "h": 73017206785,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73017206785),
//--TRIMMABLE-BOUNDARY-START(12887664641),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067533825,
        "f": 50364417
      },
      "n": "Description",
      "d": 2762753,
      "h": 12887664641,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12887664641),
//--TRIMMABLE-BOUNDARY-START(64427272193),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657468417,
        "f": 50364417
      },
      "n": "Icon",
      "d": 2762753,
      "h": 64427272193,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64427272193),
//--TRIMMABLE-BOUNDARY-START(8592697345),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477599233,
        "f": 50364417
      },
      "n": "Color",
      "d": 2762753,
      "h": 8592697345,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8592697345)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60132304897),
    {
      "r": 1179649,
      "p": [
        {
          "n": "i",
          "p": 655361
        }
      ],
      "n": "GetDataPoint",
      "d": 2762753,
      "h": 60132304897,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60132304897)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297730049),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2762753,
      "h": 4297730049,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297730049)
  ],
  "h": 2762753
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceLog, $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogPowerModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogPowerModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2762753)
        
        

        //--TRIMMABLE-BOUNDARY-START(2238465)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogInputModel`, ($self) => class LoggerLogInputModel extends $.$IhzR.LCIDLM.LoggerLogModel
        {
            //--TRIMMABLE-BOUNDARY-START(55836813313)
            /*bool */ get IsValid()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(55836813313)
            
            //--TRIMMABLE-BOUNDARY-START(47246878721)
            /*double */ GetDataPoint(/*int*/ i)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246878721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 1;
            }
            //--TRIMMABLE-BOUNDARY-END(47246878721)
            
            //--TRIMMABLE-BOUNDARY-START(60131780609)
            /*string */ get Title()
            {
                return "Event";
            }
            //--TRIMMABLE-BOUNDARY-END(60131780609)
            
            //--TRIMMABLE-BOUNDARY-START(51541846017)
            /*string */ get Icon()
            {
                return "mdi mdi-database"/*MaterialDesignIconNames.Database*/;
            }
            //--TRIMMABLE-BOUNDARY-END(51541846017)
            
            //--TRIMMABLE-BOUNDARY-START(8592173057)
            /*string */ get Color()
            {
                return "error";
            }
            //--TRIMMABLE-BOUNDARY-END(8592173057)
            
            //--TRIMMABLE-BOUNDARY-START(4297205761)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297205761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297205761)
            
            //--TRIMMABLE-BOUNDARY-START(4297205761)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297205761)
            
            static $h = 2238465;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$IhzR.LCIDLM.LoggerLogModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836813313),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361976833,
        "f": 50364417
      },
      "n": "IsValid",
      "d": 2238465,
      "h": 55836813313,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55836813313),
//--TRIMMABLE-BOUNDARY-START(60131780609),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951911425,
        "f": 50364417
      },
      "n": "Title",
      "d": 2238465,
      "h": 60131780609,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60131780609),
//--TRIMMABLE-BOUNDARY-START(51541846017),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772042241,
        "f": 50364417
      },
      "n": "Icon",
      "d": 2238465,
      "h": 51541846017,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541846017),
//--TRIMMABLE-BOUNDARY-START(8592173057),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182107649,
        "f": 50364417
      },
      "n": "Color",
      "d": 2238465,
      "h": 8592173057,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8592173057)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47246878721),
    {
      "r": 1179649,
      "p": [
        {
          "n": "i",
          "p": 655361
        }
      ],
      "n": "GetDataPoint",
      "d": 2238465,
      "h": 47246878721,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47246878721)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297205761),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2238465,
      "h": 4297205761,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297205761)
  ],
  "h": 2238465
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceLog, $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogInputModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogInputModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2238465)
        
        

        //--TRIMMABLE-BOUNDARY-START(3024897)
        $asm.$str(`$IhzR.LCIDLM.LoggerLogType`, ($self) => class LoggerLogType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Unknown = 0;
            static PowerDown = 1;
            static PowerUp = 2;
            static Voltage = 3;
            static Input = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3024897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "PowerDown": 1n,
                    "PowerUp": 2n,
                    "Voltage": 3n,
                    "Input": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297992193)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297992193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297992193)
            
            //--TRIMMABLE-BOUNDARY-START(4297992193)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297992193)
            
            static $h = 3024897;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21477861377),
    {
      "t": 3024897,
      "n": "Unknown",
      "d": 3024897,
      "h": 21477861377,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477861377),
//--TRIMMABLE-BOUNDARY-START(12887926785),
    {
      "t": 3024897,
      "n": "PowerDown",
      "d": 3024897,
      "h": 12887926785,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887926785),
//--TRIMMABLE-BOUNDARY-START(17182894081),
    {
      "t": 3024897,
      "n": "PowerUp",
      "d": 3024897,
      "h": 17182894081,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182894081),
//--TRIMMABLE-BOUNDARY-START(25772828673),
    {
      "t": 3024897,
      "n": "Voltage",
      "d": 3024897,
      "h": 25772828673,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772828673),
//--TRIMMABLE-BOUNDARY-START(8592959489),
    {
      "t": 3024897,
      "n": "Input",
      "d": 3024897,
      "h": 8592959489,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592959489)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297992193),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3024897,
      "h": 4297992193,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297992193)
  ],
  "h": 3024897
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3024897)
        
        

        //--TRIMMABLE-BOUNDARY-START(5253121)
        $asm.$str(`$IhzR.LCIDLS$1.LoggerBroadcastPeerMessages`, ($self) => class LoggerBroadcastPeerMessages extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static State = 1;
            static ToggleCountDown = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5253121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "State": 1n,
                    "ToggleCountDown": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4300220417)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300220417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300220417)
            
            //--TRIMMABLE-BOUNDARY-START(4300220417)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4300220417)
            
            static $h = 5253121;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8595187713),
    {
      "t": 5253121,
      "n": "None",
      "d": 5253121,
      "h": 8595187713,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8595187713),
//--TRIMMABLE-BOUNDARY-START(12890155009),
    {
      "t": 5253121,
      "n": "State",
      "d": 5253121,
      "h": 12890155009,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890155009),
//--TRIMMABLE-BOUNDARY-START(17185122305),
    {
      "t": 5253121,
      "n": "ToggleCountDown",
      "d": 5253121,
      "h": 17185122305,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17185122305)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300220417),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5253121,
      "h": 4300220417,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300220417)
  ],
  "h": 5253121
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Settings.LoggerBroadcastPeerMessages`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Settings${separator}LoggerBroadcastPeerMessages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5253121)
        
        

        //--TRIMMABLE-BOUNDARY-START(5122049)
        $asm.$str(`$IhzR.LCIDLS$1.LoggerActions`, ($self) => class LoggerActions extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static Off = 0;
            static On = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5122049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Off": 0n,
                    "On": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4300089345)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300089345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300089345)
            
            //--TRIMMABLE-BOUNDARY-START(4300089345)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4300089345)
            
            static $h = 5122049;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8595056641),
    {
      "t": 5122049,
      "n": "Off",
      "d": 5122049,
      "h": 8595056641,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8595056641),
//--TRIMMABLE-BOUNDARY-START(12890023937),
    {
      "t": 5122049,
      "n": "On",
      "d": 5122049,
      "h": 12890023937,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890023937)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300089345),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5122049,
      "h": 4300089345,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300089345)
  ],
  "h": 5122049
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Settings.LoggerActions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Settings${separator}LoggerActions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5122049)
        
        

        //--TRIMMABLE-BOUNDARY-START(141313)
        $asm.$cls(`$IhzR.LCIDL$1._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590075905)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590075905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590075905)
            
            //--TRIMMABLE-BOUNDARY-START(4295108609)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295108609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295108609)
            
            //--TRIMMABLE-BOUNDARY-START(4295108609)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295108609)
            
            static $h = 141313;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590075905),
    {
      "r": 65537,
      "n": "Execute",
      "d": 141313,
      "h": 8590075905,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590075905)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295108609),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 141313,
      "h": 4295108609,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295108609)
  ],
  "h": 141313
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(141313)
        
        

        //--TRIMMABLE-BOUNDARY-START(2631681)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogModelTypeDescriptor`, ($self) => class LoggerLogModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297598977)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297598977);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$IhzR.LCIDLM.LoggerLogModelTypeDescriptor.GenerateProperties($.$IhzR.LCIDLM.LoggerLogModel, this, factory);
                    }, $SSNOrf ??= {"r":65537,"n":"","d":2631681,"h":0,"f":17825794}), 0, "LoggerLogModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\Models_LoggerLogModel_LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogModelTypeDescriptorBuilder.g.cs", "LoggerLogModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297598977)
            
            //--TRIMMABLE-BOUNDARY-START(12887533569)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887533569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Event"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerLogModel.$type, $.$discardRef(), "Event", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Event")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$IhzR.LCIDLM.LoggerLogType, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Event";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$IhzR.LCIDLM.LoggerLogType, ($.$cast(target, $.$IhzR.LCIDLM.LoggerLogModel)).Event);
                        }, $ESSoij ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2631681,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Event = value.AsEnumValue($.$IhzR.LCIDLM.LoggerLogType);
                        }, $TtiLQj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2631681,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceLogModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887533569)
            
            //--TRIMMABLE-BOUNDARY-START(17182500865)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182500865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceLogModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceLogModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceLogModel));
                {
                    /*var*/ let _Event = _target.Event;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Event"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$IhzR.LCIDLM.LoggerLogType));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$IhzR.LCIDLM.LoggerLogType, () => _Event, ($v) => _Event = $v, null, true)))
                    {
                        _target.Event = _Event;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182500865)
            
            //--TRIMMABLE-BOUNDARY-START(8592566273)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592566273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                if (_target === null)
                {
                    return false;
                }
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$IhzR.LCIDLM.LoggerLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerLogModel)))
                {
                    /*var*/ let result = $.$IhzR.LCIDLM.LoggerLogModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerLogModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$IhzR.LCIDLM.LoggerLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerLogModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592566273)
            
            static $h = 2631681;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887533569),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2631681,
      "h": 12887533569,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887533569),
//--TRIMMABLE-BOUNDARY-START(17182500865),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2500609,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2631681,
      "h": 17182500865,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182500865),
//--TRIMMABLE-BOUNDARY-START(8592566273),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2500609,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2631681,
      "h": 8592566273,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592566273)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297598977),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2631681,
      "h": 4297598977,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297598977)
  ],
  "h": 2631681
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$IhzR.LCIDLM.LoggerLogModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2631681)
        
        

        //--TRIMMABLE-BOUNDARY-START(4401153)
        $asm.$cls(`$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelTypeDescriptor`, ($self) => class LoggerGetPowerAnalyticsResponseModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299368449)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299368449);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelTypeDescriptor.GenerateProperties($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel, this, factory);
                    }, $RiYVOa ??= {"r":65537,"n":"","d":4401153,"h":0,"f":17825794}), 0, "LoggerGetPowerAnalyticsResponseModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\Models_Statuses_LoggerGetPowerAnalyticsResponseModel_LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetPowerAnalyticsResponseModelTypeDescriptorBuilder.g.cs", "LoggerGetPowerAnalyticsResponseModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299368449)
            
            //--TRIMMABLE-BOUNDARY-START(12889303041)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889303041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PowerCuts"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel.$type, $.$discardRef(), "PowerCuts", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PowerCuts")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "PowerCuts";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetPowerAnalyticsResponseModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel)).PowerCuts);
                        }, $OTAgkc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4401153,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.PowerCuts = value.AsInt();
                        }, $PIYDda ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4401153,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("UpTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel.$type, $.$discardRef(), "UpTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("UpTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "UpTime";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetPowerAnalyticsResponseModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel)).UpTime);
                        }, $aliZEh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4401153,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.UpTime = value.AsInt();
                        }, $cdqvzk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4401153,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DownTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel.$type, $.$discardRef(), "DownTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DownTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "DownTime";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetPowerAnalyticsResponseModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel)).DownTime);
                        }, $RPzYHk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4401153,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DownTime = value.AsInt();
                        }, $VGSnIj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4401153,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("UpTimeSpan"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel.$type, $.$discardRef(), "UpTimeSpan", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("UpTimeSpan")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.TimeSpan, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "UpTimeSpan";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetPowerAnalyticsResponseModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$11(($.$cast(target, $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel)).UpTimeSpan);
                        }, $sOiYnf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4401153,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DownTimeSpan"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel.$type, $.$discardRef(), "DownTimeSpan", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DownTimeSpan")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.TimeSpan, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "DownTimeSpan";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetPowerAnalyticsResponseModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$11(($.$cast(target, $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel)).DownTimeSpan);
                        }, $bKYXfi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4401153,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12889303041)
            
            //--TRIMMABLE-BOUNDARY-START(17184270337)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetPowerAnalyticsResponseModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184270337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _PowerCuts = _target.PowerCuts;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PowerCuts"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _PowerCuts, ($v) => _PowerCuts = $v, $.$$.S.Int32)))
                    {
                        _target.PowerCuts = _PowerCuts;
                    }
                }
                {
                    /*var*/ let _UpTime = _target.UpTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("UpTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _UpTime, ($v) => _UpTime = $v, $.$$.S.Int32)))
                    {
                        _target.UpTime = _UpTime;
                    }
                }
                {
                    /*var*/ let _DownTime = _target.DownTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DownTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _DownTime, ($v) => _DownTime = $v, $.$$.S.Int32)))
                    {
                        _target.DownTime = _DownTime;
                    }
                }
                {
                    /*var*/ let _UpTimeSpan = _target.UpTimeSpan;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("UpTimeSpan"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.TimeSpan));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.TimeSpan, () => _UpTimeSpan, ($v) => _UpTimeSpan = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _DownTimeSpan = _target.DownTimeSpan;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DownTimeSpan"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.TimeSpan));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.TimeSpan, () => _DownTimeSpan, ($v) => _DownTimeSpan = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184270337)
            
            //--TRIMMABLE-BOUNDARY-START(8594335745)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetPowerAnalyticsResponseModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594335745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel)))
                {
                    /*var*/ let result = $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594335745)
            
            static $h = 4401153;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889303041),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4401153,
      "h": 12889303041,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889303041),
//--TRIMMABLE-BOUNDARY-START(17184270337),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4270081,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4401153,
      "h": 17184270337,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184270337),
//--TRIMMABLE-BOUNDARY-START(8594335745),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4270081,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4401153,
      "h": 8594335745,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594335745)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299368449),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4401153,
      "h": 4299368449,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299368449)
  ],
  "h": 4401153
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetPowerAnalyticsResponseModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Statuses${separator}LoggerGetPowerAnalyticsResponseModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4401153)
        
        

        //--TRIMMABLE-BOUNDARY-START(4139009)
        $asm.$cls(`$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModelTypeDescriptor`, ($self) => class LoggerGetInputAnalyticsResponseModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299106305)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299106305);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModelTypeDescriptor.GenerateProperties($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel, this, factory);
                    }, $hwEAZe ??= {"r":65537,"n":"","d":4139009,"h":0,"f":17825794}), 0, "LoggerGetInputAnalyticsResponseModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\Models_Statuses_LoggerGetInputAnalyticsResponseModel_LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetInputAnalyticsResponseModelTypeDescriptorBuilder.g.cs", "LoggerGetInputAnalyticsResponseModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299106305)
            
            //--TRIMMABLE-BOUNDARY-START(12889040897)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889040897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Count"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel.$type, $.$discardRef(), "Count", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Count")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Count";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetInputAnalyticsResponseModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel)).Count);
                        }, $cfsQfj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4139009,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Count = value.AsInt();
                        }, $qVKhnj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4139009,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12889040897)
            
            //--TRIMMABLE-BOUNDARY-START(17184008193)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetInputAnalyticsResponseModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184008193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Count = _target.Count;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Count"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Count, ($v) => _Count = $v, $.$$.S.Int32)))
                    {
                        _target.Count = _Count;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184008193)
            
            //--TRIMMABLE-BOUNDARY-START(8594073601)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetInputAnalyticsResponseModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594073601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel)))
                {
                    /*var*/ let result = $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594073601)
            
            static $h = 4139009;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889040897),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4139009,
      "h": 12889040897,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889040897),
//--TRIMMABLE-BOUNDARY-START(17184008193),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4007937,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4139009,
      "h": 17184008193,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184008193),
//--TRIMMABLE-BOUNDARY-START(8594073601),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4007937,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4139009,
      "h": 8594073601,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594073601)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299106305),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4139009,
      "h": 4299106305,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299106305)
  ],
  "h": 4139009
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerGetInputAnalyticsResponseModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Statuses${separator}LoggerGetInputAnalyticsResponseModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4139009)
        
        

        //--TRIMMABLE-BOUNDARY-START(1058817)
        $asm.$cls(`$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModelTypeDescriptor`, ($self) => class LoggerGetAnalyticsCommandModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296026113)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296026113);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModelTypeDescriptor.GenerateProperties($.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel, this, factory);
                    }, $YOJBuc ??= {"r":65537,"n":"","d":1058817,"h":0,"f":17825794}), 0, "LoggerGetAnalyticsCommandModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\Models_Commands_LoggerGetAnalyticsCommandModel_LivingThing.Core.IOT.Devices.Logger.Models.Controls.LoggerGetAnalyticsCommandModelTypeDescriptorBuilder.g.cs", "LoggerGetAnalyticsCommandModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296026113)
            
            //--TRIMMABLE-BOUNDARY-START(12885960705)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885960705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("StartTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel.$type, $.$discardRef(), "StartTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("StartTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "StartTime";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Controls.LoggerGetAnalyticsCommandModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel)).StartTime);
                        }, $ijZbaj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1058817,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("EndTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel.$type, $.$discardRef(), "EndTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("EndTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "EndTime";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Controls.LoggerGetAnalyticsCommandModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel)).EndTime);
                        }, $bGcaFi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1058817,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Command";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Controls.LoggerGetAnalyticsCommandModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel)).Command);
                        }, $YKBHja ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1058817,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885960705)
            
            //--TRIMMABLE-BOUNDARY-START(17180928001)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.Controls.LoggerGetAnalyticsCommandModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180928001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _StartTime = _target.StartTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("StartTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _StartTime, ($v) => _StartTime = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _EndTime = _target.EndTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("EndTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _EndTime, ($v) => _EndTime = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180928001)
            
            //--TRIMMABLE-BOUNDARY-START(8590993409)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.Controls.LoggerGetAnalyticsCommandModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590993409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel)))
                {
                    /*var*/ let result = $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590993409)
            
            static $h = 1058817;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885960705),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1058817,
      "h": 12885960705,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885960705),
//--TRIMMABLE-BOUNDARY-START(17180928001),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 927745,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1058817,
      "h": 17180928001,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180928001),
//--TRIMMABLE-BOUNDARY-START(8590993409),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 927745,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1058817,
      "h": 8590993409,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590993409)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296026113),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1058817,
      "h": 4296026113,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296026113)
  ],
  "h": 1058817
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Controls.LoggerGetAnalyticsCommandModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Controls${separator}LoggerGetAnalyticsCommandModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1058817)
        
        

        //--TRIMMABLE-BOUNDARY-START(4663297)
        $asm.$cls(`$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor`, ($self) => class LoggerReceivedStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLMS.LoggerReceivedStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299630593)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299630593);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor.GenerateProperties($.$IhzR.LCIDLMS.LoggerReceivedStatusModel, this, factory);
                    }, $lOUrJh ??= {"r":65537,"n":"","d":4663297,"h":0,"f":17825794}), 0, "LoggerReceivedStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\Models_Statuses_LoggerReceivedStatusModel_LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModelTypeDescriptorBuilder.g.cs", "LoggerReceivedStatusModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299630593)
            
            //--TRIMMABLE-BOUNDARY-START(12889565185)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889565185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LogCapacity"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel.$type, $.$discardRef(), "LogCapacity", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LogCapacity")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "LogCapacity";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel)).LogCapacity);
                        }, $zFvTcc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4663297,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LogCapacity = value.AsInt();
                        }, $qIOimj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4663297,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LogCount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel.$type, $.$discardRef(), "LogCount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LogCount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "LogCount";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel)).LogCount);
                        }, $ZjLGTa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4663297,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LogCount = value.AsInt();
                        }, $vORBni ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4663297,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SyncCount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel.$type, $.$discardRef(), "SyncCount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SyncCount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "SyncCount";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel)).SyncCount);
                        }, $WrBAkk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4663297,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SyncCount = value.AsInt();
                        }, $vVvrod ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4663297,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LogType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel.$type, $.$discardRef(), "LogType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LogType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$IhzR.LCIDLM.LoggerLogType, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "LogType";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$IhzR.LCIDLM.LoggerLogType, ($.$cast(target, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel)).LogType);
                        }, $tMqOBf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4663297,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LogType = value.AsEnumValue($.$IhzR.LCIDLM.LoggerLogType);
                        }, $HEmjZj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4663297,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("UpTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel.$type, $.$discardRef(), "UpTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("UpTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.DateTime), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "UpTime";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.DateTime, ($.$cast(target, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel)).UpTime);
                        }, $JUcDAd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4663297,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.UpTime = value.AsNullableValue($.$$.S.DateTime);
                        }, $IEfxrj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4663297,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Voltage"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel.$type, $.$discardRef(), "Voltage", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Voltage")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.Int32), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Voltage";
                        $i11.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.Int32, ($.$cast(target, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel)).Voltage);
                        }, $zqILta ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4663297,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Voltage = value.AsNullableValue($.$$.S.Int32);
                        }, $UDnHek ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4663297,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Usage"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel.$type, $.$discardRef(), "Usage", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Usage")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Usage";
                        $i13.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel)).Usage);
                        }, $PRtBTd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4663297,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SyncPercent"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel.$type, $.$discardRef(), "SyncPercent", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SyncPercent")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "SyncPercent";
                        $i15.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel)).SyncPercent);
                        }, $HDmcnk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4663297,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889565185)
            
            //--TRIMMABLE-BOUNDARY-START(17184532481)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184532481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _LogCapacity = _target.LogCapacity;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LogCapacity"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _LogCapacity, ($v) => _LogCapacity = $v, $.$$.S.Int32)))
                    {
                        _target.LogCapacity = _LogCapacity;
                    }
                }
                {
                    /*var*/ let _LogCount = _target.LogCount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LogCount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _LogCount, ($v) => _LogCount = $v, $.$$.S.Int32)))
                    {
                        _target.LogCount = _LogCount;
                    }
                }
                {
                    /*var*/ let _SyncCount = _target.SyncCount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SyncCount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _SyncCount, ($v) => _SyncCount = $v, $.$$.S.Int32)))
                    {
                        _target.SyncCount = _SyncCount;
                    }
                }
                {
                    /*var*/ let _LogType = _target.LogType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LogType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$IhzR.LCIDLM.LoggerLogType));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$IhzR.LCIDLM.LoggerLogType, () => _LogType, ($v) => _LogType = $v, null, true)))
                    {
                        _target.LogType = _LogType;
                    }
                }
                {
                    /*var*/ let _UpTime = _target.UpTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("UpTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.DateTime)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.DateTime), () => _UpTime, ($v) => _UpTime = $v, null, true)))
                    {
                        _target.UpTime = $.$clone(_UpTime);
                    }
                }
                {
                    /*var*/ let _Voltage = _target.Voltage;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Voltage"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.Int32)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.Int32), () => _Voltage, ($v) => _Voltage = $v, null, true)))
                    {
                        _target.Voltage = _Voltage;
                    }
                }
                {
                    /*var*/ let _Usage = _target.Usage;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Usage"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Usage, ($v) => _Usage = $v, $.$$.S.Double)))
                    {
                    }
                }
                {
                    /*var*/ let _SyncPercent = _target.SyncPercent;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SyncPercent"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _SyncPercent, ($v) => _SyncPercent = $v, $.$$.S.Double)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184532481)
            
            //--TRIMMABLE-BOUNDARY-START(8594597889)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594597889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$IhzR.LCIDLMS.LoggerReceivedStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel)))
                {
                    /*var*/ let result = $.$IhzR.LCIDLMS.LoggerReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594597889)
            
            static $h = 4663297;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLMS.LoggerReceivedStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889565185),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4663297,
      "h": 12889565185,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889565185),
//--TRIMMABLE-BOUNDARY-START(17184532481),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4532225,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4663297,
      "h": 17184532481,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184532481),
//--TRIMMABLE-BOUNDARY-START(8594597889),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4532225,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4663297,
      "h": 8594597889,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594597889)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299630593),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4663297,
      "h": 4299630593,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299630593)
  ],
  "h": 4663297
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$IhzR.LCIDLMS.LoggerReceivedStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Statuses${separator}LoggerReceivedStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4663297)
        
        

        //--TRIMMABLE-BOUNDARY-START(862209)
        $asm.$cls(`$IhzR.LCIDLMC.LoggerGetAnalyticsCommand`, ($self) => class LoggerGetAnalyticsCommand extends $.$XBGm.LCICDiC.iSmartDeviceCommand$$($.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295829505)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4(null, null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295829505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295829505)
            
            //--TRIMMABLE-BOUNDARY-START(4295829505)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295829505)
            
            static $h = 862209;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceCommand$$($.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295829505),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 862209,
      "h": 4295829505,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295829505)
  ],
  "h": 862209
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Commands.LoggerGetAnalyticsCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Commands${separator}LoggerGetAnalyticsCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(862209)
        
        

        //--TRIMMABLE-BOUNDARY-START(2369537)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogInputModelTypeDescriptor`, ($self) => class LoggerLogInputModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerLogInputModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297336833)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297336833);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$IhzR.LCIDLM.LoggerLogInputModelTypeDescriptor.GenerateProperties($.$IhzR.LCIDLM.LoggerLogInputModel, this, factory);
                    }, $xAgaJe ??= {"r":65537,"n":"","d":2369537,"h":0,"f":17825794}), 0, "LoggerLogInputModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\Models_LoggerLogInputModel_LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogInputModelTypeDescriptorBuilder.g.cs", "LoggerLogInputModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297336833)
            
            //--TRIMMABLE-BOUNDARY-START(12887271425)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887271425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsValid"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerLogInputModel.$type, $.$discardRef(), "IsValid", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsValid")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "IsValid";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogInputModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogInputModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$IhzR.LCIDLM.LoggerLogInputModel)).IsValid);
                        }, $BNclma ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2369537,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Title"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerLogInputModel.$type, $.$discardRef(), "Title", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Title")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Title";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogInputModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogInputModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$IhzR.LCIDLM.LoggerLogInputModel)).Title);
                        }, $ugMDce ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2369537,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Icon"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerLogInputModel.$type, $.$discardRef(), "Icon", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Icon")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Icon";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogInputModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogInputModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$IhzR.LCIDLM.LoggerLogInputModel)).Icon);
                        }, $BrfRmk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2369537,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Color"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerLogInputModel.$type, $.$discardRef(), "Color", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Color")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Color";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogInputModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogInputModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$IhzR.LCIDLM.LoggerLogInputModel)).Color);
                        }, $nuxIGe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2369537,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$IhzR.LCIDLM.LoggerLogModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887271425)
            
            //--TRIMMABLE-BOUNDARY-START(17182238721)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogInputModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182238721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogModel?*/ let targetBase = _target;
                $.$IhzR.LCIDLM.LoggerLogModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$IhzR.LCIDLM.LoggerLogModel));
                {
                    /*var*/ let _IsValid = _target.IsValid;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsValid"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsValid, ($v) => _IsValid = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Title = _target.Title;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Title"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Title, ($v) => _Title = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Icon = _target.Icon;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Icon"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Icon, ($v) => _Icon = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Color = _target.Color;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Color"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Color, ($v) => _Color = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182238721)
            
            //--TRIMMABLE-BOUNDARY-START(8592304129)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogInputModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592304129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$IhzR.LCIDLM.LoggerLogInputModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$IhzR.LCIDLM.LoggerLogInputModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerLogInputModel)))
                {
                    /*var*/ let result = $.$IhzR.LCIDLM.LoggerLogInputModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerLogInputModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$IhzR.LCIDLM.LoggerLogInputModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerLogInputModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592304129)
            
            static $h = 2369537;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerLogInputModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887271425),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2369537,
      "h": 12887271425,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887271425),
//--TRIMMABLE-BOUNDARY-START(17182238721),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2238465,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2369537,
      "h": 17182238721,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182238721),
//--TRIMMABLE-BOUNDARY-START(8592304129),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2238465,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2369537,
      "h": 8592304129,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592304129)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297336833),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2369537,
      "h": 4297336833,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297336833)
  ],
  "h": 2369537
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$IhzR.LCIDLM.LoggerLogInputModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogInputModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogInputModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2369537)
        
        

        //--TRIMMABLE-BOUNDARY-START(2893825)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogPowerModelTypeDescriptor`, ($self) => class LoggerLogPowerModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerLogPowerModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297861121)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297861121);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$IhzR.LCIDLM.LoggerLogPowerModelTypeDescriptor.GenerateProperties($.$IhzR.LCIDLM.LoggerLogPowerModel, this, factory);
                    }, $XyuVyb ??= {"r":65537,"n":"","d":2893825,"h":0,"f":17825794}), 0, "LoggerLogPowerModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\Models_LoggerLogPowerModel_LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogPowerModelTypeDescriptorBuilder.g.cs", "LoggerLogPowerModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297861121)
            
            //--TRIMMABLE-BOUNDARY-START(12887795713)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887795713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsValid"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerLogPowerModel.$type, $.$discardRef(), "IsValid", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsValid")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "IsValid";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogPowerModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogPowerModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$IhzR.LCIDLM.LoggerLogPowerModel)).IsValid);
                        }, $vqHeri ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2893825,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Title"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerLogPowerModel.$type, $.$discardRef(), "Title", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Title")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Title";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogPowerModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogPowerModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$IhzR.LCIDLM.LoggerLogPowerModel)).Title);
                        }, $ltlUgd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2893825,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerLogPowerModel.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Description";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogPowerModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogPowerModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$IhzR.LCIDLM.LoggerLogPowerModel)).Description);
                        }, $tjNRAg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2893825,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Icon"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerLogPowerModel.$type, $.$discardRef(), "Icon", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Icon")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Icon";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogPowerModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogPowerModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$IhzR.LCIDLM.LoggerLogPowerModel)).Icon);
                        }, $cpAwbj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2893825,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Color"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerLogPowerModel.$type, $.$discardRef(), "Color", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Color")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Color";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogPowerModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogPowerModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$IhzR.LCIDLM.LoggerLogPowerModel)).Color);
                        }, $AAdOvf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2893825,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$IhzR.LCIDLM.LoggerLogModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887795713)
            
            //--TRIMMABLE-BOUNDARY-START(17182763009)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogPowerModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182763009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogModel?*/ let targetBase = _target;
                $.$IhzR.LCIDLM.LoggerLogModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$IhzR.LCIDLM.LoggerLogModel));
                {
                    /*var*/ let _IsValid = _target.IsValid;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsValid"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsValid, ($v) => _IsValid = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Title = _target.Title;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Title"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Title, ($v) => _Title = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Icon = _target.Icon;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Icon"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Icon, ($v) => _Icon = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Color = _target.Color;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Color"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Color, ($v) => _Color = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182763009)
            
            //--TRIMMABLE-BOUNDARY-START(8592828417)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogPowerModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592828417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$IhzR.LCIDLM.LoggerLogPowerModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$IhzR.LCIDLM.LoggerLogPowerModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerLogPowerModel)))
                {
                    /*var*/ let result = $.$IhzR.LCIDLM.LoggerLogPowerModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerLogPowerModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$IhzR.LCIDLM.LoggerLogPowerModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerLogPowerModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592828417)
            
            static $h = 2893825;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerLogPowerModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887795713),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2893825,
      "h": 12887795713,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887795713),
//--TRIMMABLE-BOUNDARY-START(17182763009),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2762753,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2893825,
      "h": 17182763009,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182763009),
//--TRIMMABLE-BOUNDARY-START(8592828417),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2762753,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2893825,
      "h": 8592828417,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592828417)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297861121),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2893825,
      "h": 4297861121,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297861121)
  ],
  "h": 2893825
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$IhzR.LCIDLM.LoggerLogPowerModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogPowerModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogPowerModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2893825)
        
        

        //--TRIMMABLE-BOUNDARY-START(3352577)
        $asm.$cls(`$IhzR.LCIDLM.LoggerLogVoltageModelTypeDescriptor`, ($self) => class LoggerLogVoltageModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerLogVoltageModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298319873)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298319873);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$IhzR.LCIDLM.LoggerLogVoltageModelTypeDescriptor.GenerateProperties($.$IhzR.LCIDLM.LoggerLogVoltageModel, this, factory);
                    }, $vLJwnl ??= {"r":65537,"n":"","d":3352577,"h":0,"f":17825794}), 0, "LoggerLogVoltageModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\Models_LoggerLogVoltageModel_LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogVoltageModelTypeDescriptorBuilder.g.cs", "LoggerLogVoltageModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298319873)
            
            //--TRIMMABLE-BOUNDARY-START(12888254465)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888254465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Voltage"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerLogVoltageModel.$type, $.$discardRef(), "Voltage", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Voltage")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Voltage";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogVoltageModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogVoltageModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$IhzR.LCIDLM.LoggerLogVoltageModel)).Voltage);
                        }, $aYexNe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3352577,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogVoltageModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Voltage = value.AsInt();
                        }, $QFVzBk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3352577,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsValid"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerLogVoltageModel.$type, $.$discardRef(), "IsValid", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsValid")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "IsValid";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogVoltageModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogVoltageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$IhzR.LCIDLM.LoggerLogVoltageModel)).IsValid);
                        }, $TabXFg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3352577,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Title"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerLogVoltageModel.$type, $.$discardRef(), "Title", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Title")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Title";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogVoltageModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogVoltageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$IhzR.LCIDLM.LoggerLogVoltageModel)).Title);
                        }, $fGbNil ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3352577,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Icon"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerLogVoltageModel.$type, $.$discardRef(), "Icon", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Icon")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Icon";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogVoltageModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogVoltageModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$IhzR.LCIDLM.LoggerLogVoltageModel)).Icon);
                        }, $JVBDZf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3352577,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Color"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerLogVoltageModel.$type, $.$discardRef(), "Color", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Color")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Color";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogVoltageModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerLogVoltageModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$IhzR.LCIDLM.LoggerLogVoltageModel)).Color);
                        }, $vMslhc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3352577,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$IhzR.LCIDLM.LoggerLogModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888254465)
            
            //--TRIMMABLE-BOUNDARY-START(17183221761)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogVoltageModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183221761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogModel?*/ let targetBase = _target;
                $.$IhzR.LCIDLM.LoggerLogModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$IhzR.LCIDLM.LoggerLogModel));
                {
                    /*var*/ let _Voltage = _target.Voltage;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Voltage"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Voltage, ($v) => _Voltage = $v, $.$$.S.Int32)))
                    {
                        _target.Voltage = _Voltage;
                    }
                }
                {
                    /*var*/ let _IsValid = _target.IsValid;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsValid"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsValid, ($v) => _IsValid = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Title = _target.Title;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Title"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Title, ($v) => _Title = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Icon = _target.Icon;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Icon"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Icon, ($v) => _Icon = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Color = _target.Color;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Color"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Color, ($v) => _Color = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183221761)
            
            //--TRIMMABLE-BOUNDARY-START(8593287169)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogVoltageModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593287169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$IhzR.LCIDLM.LoggerLogVoltageModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$IhzR.LCIDLM.LoggerLogVoltageModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerLogVoltageModel)))
                {
                    /*var*/ let result = $.$IhzR.LCIDLM.LoggerLogVoltageModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerLogVoltageModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$IhzR.LCIDLM.LoggerLogVoltageModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerLogVoltageModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593287169)
            
            static $h = 3352577;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerLogVoltageModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888254465),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3352577,
      "h": 12888254465,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888254465),
//--TRIMMABLE-BOUNDARY-START(17183221761),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3221505,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3352577,
      "h": 17183221761,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183221761),
//--TRIMMABLE-BOUNDARY-START(8593287169),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3221505,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3352577,
      "h": 8593287169,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593287169)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298319873),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3352577,
      "h": 4298319873,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298319873)
  ],
  "h": 3352577
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$IhzR.LCIDLM.LoggerLogVoltageModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogVoltageModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerLogVoltageModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3352577)
        
        

        //--TRIMMABLE-BOUNDARY-START(3745793)
        $asm.$cls(`$IhzR.LCIDLM.LoggerStatusModel`, ($self) => class LoggerStatusModel extends $.$XBGm.LCICM.IOTDeviceStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(51543353345)
            /*LoggerLogPowerModel?*/ Power = null;
            //--TRIMMABLE-BOUNDARY-END(51543353345)
            
            //--TRIMMABLE-BOUNDARY-START(47248386049)
            /*LoggerLogInputModel?*/ Input = null;
            //--TRIMMABLE-BOUNDARY-END(47248386049)
            
            //--TRIMMABLE-BOUNDARY-START(81608124417)
            /*LoggerLogVoltageModel?*/ Voltage = null;
            //--TRIMMABLE-BOUNDARY-END(81608124417)
            
            //--TRIMMABLE-BOUNDARY-START(17183614977)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183614977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183614977)
            
            //--TRIMMABLE-BOUNDARY-START(17183614977)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(17183614977)
            
            static $h = 3745793;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICM.IOTDeviceStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51543353345),
    {
      "p": 2762753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34363484161,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68723222529,
        "f": 83886081
      },
      "n": "Power",
      "d": 3745793,
      "h": 51543353345,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Flags",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51543353345),
//--TRIMMABLE-BOUNDARY-START(47248386049),
    {
      "p": 2238465,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25773549569,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60133287937,
        "f": 83886081
      },
      "n": "Input",
      "d": 3745793,
      "h": 47248386049,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Flags",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47248386049),
//--TRIMMABLE-BOUNDARY-START(81608124417),
    {
      "p": 3221505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42953418753,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77313157121,
        "f": 83886081
      },
      "n": "Voltage",
      "d": 3745793,
      "h": 81608124417,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Flags",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81608124417)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183614977),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3745793,
      "h": 17183614977,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183614977)
  ],
  "h": 3745793
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3745793)
        
        

        //--TRIMMABLE-BOUNDARY-START(796673)
        $asm.$cls(`$IhzR.LCIDLMC.LoggerDeviceCommands<>`, (TDevice) => $asm.$gt(`$IhzR.LCIDLMC.LoggerDeviceCommands<>`, [TDevice], ($self) => class LoggerDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12885698561)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12885698561)
            
            //--TRIMMABLE-BOUNDARY-START(17180665857)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel?*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180665857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$IhzR.LCIDLMC.LoggerDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17180665857)
            
            //--TRIMMABLE-BOUNDARY-START(8590731265)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590731265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590731265)
            
            //--TRIMMABLE-BOUNDARY-START(8590731265)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590731265)
            
            //--TRIMMABLE-BOUNDARY-START(4295763969)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295763969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885698561)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12885698561)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295763969)
            
            static $H = 796673;
            static $h = 796673;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180665857),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17180665857,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180665857)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885698561),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12885698561,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885698561)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590731265),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8590731265,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590731265)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 796673,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.Commands.LoggerDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}Commands${separator}LoggerDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(796673)
        
        

        //--TRIMMABLE-BOUNDARY-START(731137)
        $asm.$cls(`$IhzR.LCIDL$1.LoggerStatusDataConverter`, ($self) => class LoggerStatusDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$($.$IhzR.LCIDLM.LoggerStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295698433)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295698433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295698433)
            
            //--TRIMMABLE-BOUNDARY-START(4295698433)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295698433)
            
            static $h = 731137;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$($.$IhzR.LCIDLM.LoggerStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295698433),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 731137,
      "h": 4295698433,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295698433)
  ],
  "h": 731137
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$XBGm.LCICM.IOTDeviceStatusModel, $.$IhzR.LCIDLM.LoggerStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$XBGm.LCICM.IOTDeviceStatusModel, $.$IhzR.LCIDLM.LoggerStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$IhzR.LCIDLM.LoggerStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.LoggerStatusDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}LoggerStatusDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(731137)
        
        

        //--TRIMMABLE-BOUNDARY-START(3876865)
        $asm.$cls(`$IhzR.LCIDLM.LoggerStatusModelTypeDescriptor`, ($self) => class LoggerStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298844161)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298844161);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$IhzR.LCIDLM.LoggerStatusModelTypeDescriptor.GenerateProperties($.$IhzR.LCIDLM.LoggerStatusModel, this, factory);
                    }, $qnrREk ??= {"r":65537,"n":"","d":3876865,"h":0,"f":17825794}), 0, "LoggerStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\Models_Statuses_LoggerStatusModel_LivingThing.Core.IOT.Devices.Logger.Models.LoggerStatusModelTypeDescriptorBuilder.g.cs", "LoggerStatusModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298844161)
            
            //--TRIMMABLE-BOUNDARY-START(12888778753)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888778753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Power"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerStatusModel.$type, $.$discardRef(), "Power", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Power")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$IhzR.LCIDLM.LoggerLogPowerModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Power";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerStatusModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$IhzR.LCIDLM.LoggerLogPowerModel, ($.$cast(target, $.$IhzR.LCIDLM.LoggerStatusModel)).Power);
                        }, $vtbUij ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3876865,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Power = value.AsReference($.$IhzR.LCIDLM.LoggerLogPowerModel);
                        }, $WheVTi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3876865,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Input"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerStatusModel.$type, $.$discardRef(), "Input", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Input")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$IhzR.LCIDLM.LoggerLogInputModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Input";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$IhzR.LCIDLM.LoggerLogInputModel, ($.$cast(target, $.$IhzR.LCIDLM.LoggerStatusModel)).Input);
                        }, $CtWpdc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3876865,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Input = value.AsReference($.$IhzR.LCIDLM.LoggerLogInputModel);
                        }, $mjMXpa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3876865,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Voltage"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$IhzR.LCIDLM.LoggerStatusModel.$type, $.$discardRef(), "Voltage", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Voltage")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$IhzR.LCIDLM.LoggerLogVoltageModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Voltage";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.Logger.Models.LoggerStatusModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$IhzR.LCIDLM.LoggerLogVoltageModel, ($.$cast(target, $.$IhzR.LCIDLM.LoggerStatusModel)).Voltage);
                        }, $lfMEri ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3876865,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$IhzR.LCIDLM.LoggerStatusModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Voltage = value.AsReference($.$IhzR.LCIDLM.LoggerLogVoltageModel);
                        }, $TemDpk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3876865,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICM.IOTDeviceStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888778753)
            
            //--TRIMMABLE-BOUNDARY-START(17183746049)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183746049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICM.IOTDeviceStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICM.IOTDeviceStatusModel));
                {
                    /*var*/ let _Power = _target.Power;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Power"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$IhzR.LCIDLM.LoggerLogPowerModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Power, ($v) => _Power = $v, $.$IhzR.LCIDLM.LoggerLogPowerModel)))
                    {
                        _target.Power = _Power;
                    }
                }
                {
                    /*var*/ let _Input = _target.Input;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Input"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$IhzR.LCIDLM.LoggerLogInputModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Input, ($v) => _Input = $v, $.$IhzR.LCIDLM.LoggerLogInputModel)))
                    {
                        _target.Input = _Input;
                    }
                }
                {
                    /*var*/ let _Voltage = _target.Voltage;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Voltage"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$IhzR.LCIDLM.LoggerLogVoltageModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Voltage, ($v) => _Voltage = $v, $.$IhzR.LCIDLM.LoggerLogVoltageModel)))
                    {
                        _target.Voltage = _Voltage;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183746049)
            
            //--TRIMMABLE-BOUNDARY-START(8593811457)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593811457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$IhzR.LCIDLM.LoggerStatusModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$IhzR.LCIDLM.LoggerStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerStatusModel)))
                {
                    /*var*/ let result = $.$IhzR.LCIDLM.LoggerStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$IhzR.LCIDLM.LoggerStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593811457)
            
            static $h = 3876865;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888778753),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3876865,
      "h": 12888778753,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888778753),
//--TRIMMABLE-BOUNDARY-START(17183746049),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3745793,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3876865,
      "h": 17183746049,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183746049),
//--TRIMMABLE-BOUNDARY-START(8593811457),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3745793,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3876865,
      "h": 8593811457,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593811457)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298844161),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3876865,
      "h": 4298844161,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298844161)
  ],
  "h": 3876865
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$IhzR.LCIDLM.LoggerStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3876865)
        
        

        //--TRIMMABLE-BOUNDARY-START(1976321)
        $asm.$cls(`$IhzR.LCIDLM.LoggerDeviceSendDataModel`, ($self) => class LoggerDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceCommandsModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296943617)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296943617);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296943617)
            
            //--TRIMMABLE-BOUNDARY-START(4296943617)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296943617)
            
            static $h = 1976321;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandsModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296943617),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1976321,
      "h": 4296943617,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296943617)
  ],
  "h": 1976321
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1976321)
        
        

        //--TRIMMABLE-BOUNDARY-START(2107393)
        $asm.$cls(`$IhzR.LCIDLM.LoggerDeviceSendDataModelTypeDescriptor`, ($self) => class LoggerDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297074689)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297074689);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$IhzR.LCIDLM.LoggerDeviceSendDataModelTypeDescriptor.GenerateProperties($.$IhzR.LCIDLM.LoggerDeviceSendDataModel, this, factory);
                    }, $gziybc ??= {"r":65537,"n":"","d":2107393,"h":0,"f":17825794}), 0, "LoggerDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\Models_LoggerDeviceSendDataModel_LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceSendDataModelTypeDescriptorBuilder.g.cs", "LoggerDeviceSendDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297074689)
            
            //--TRIMMABLE-BOUNDARY-START(12887009281)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887009281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887009281)
            
            //--TRIMMABLE-BOUNDARY-START(17181976577)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181976577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandsModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandsModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181976577)
            
            //--TRIMMABLE-BOUNDARY-START(8592041985)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592041985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$IhzR.LCIDLM.LoggerDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$IhzR.LCIDLM.LoggerDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592041985)
            
            static $h = 2107393;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887009281),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2107393,
      "h": 12887009281,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887009281),
//--TRIMMABLE-BOUNDARY-START(17181976577),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1976321,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2107393,
      "h": 17181976577,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181976577),
//--TRIMMABLE-BOUNDARY-START(8592041985),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1976321,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2107393,
      "h": 8592041985,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592041985)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297074689),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2107393,
      "h": 4297074689,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297074689)
  ],
  "h": 2107393
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$IhzR.LCIDLM.LoggerDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2107393)
        
        

        //--TRIMMABLE-BOUNDARY-START(1452033)
        $asm.$cls(`$IhzR.LCIDLM.LoggerDeviceReceivedDataModel`, ($self) => class LoggerDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$IhzR.LCIDLMS.LoggerReceivedStatusModel, $.$IhzR.LCIDLM.LoggerLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8591386625)
            /*IEnumerable<IIOTDeviceDataPointModel>? */ GetDataPoints(/*SchemaType*/ schemaType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591386625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (schemaType === 32/*SchemaType.Database*/)
                {
                    return null;
                }
                return super.GetDataPoints(schemaType);
            }
            //--TRIMMABLE-BOUNDARY-END(8591386625)
            
            //--TRIMMABLE-BOUNDARY-START(4296419329)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296419329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296419329)
            
            //--TRIMMABLE-BOUNDARY-START(4296419329)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296419329)
            
            static $h = 1452033;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$IhzR.LCIDLMS.LoggerReceivedStatusModel, $.$IhzR.LCIDLM.LoggerLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591386625),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceDataPointModel).$h,
      "p": [
        {
          "n": "schemaType",
          "p": 2722134
        }
      ],
      "n": "GetDataPoints",
      "d": 1452033,
      "h": 8591386625,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591386625)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296419329),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1452033,
      "h": 4296419329,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296419329)
  ],
  "h": 1452033
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1452033)
        
        

        //--TRIMMABLE-BOUNDARY-START(1583105)
        $asm.$cls(`$IhzR.LCIDLM.LoggerDeviceReceivedDataModelTypeDescriptor`, ($self) => class LoggerDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296550401)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296550401);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, this, factory);
                    }, $yiboRc ??= {"r":65537,"n":"","d":1583105,"h":0,"f":17825794}), 0, "LoggerDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\Models_LoggerDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "LoggerDeviceReceivedDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296550401)
            
            //--TRIMMABLE-BOUNDARY-START(12886484993)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886484993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$IhzR.LCIDLMS.LoggerReceivedStatusModel, $.$IhzR.LCIDLM.LoggerLogModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886484993)
            
            //--TRIMMABLE-BOUNDARY-START(17181452289)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181452289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.Logger.Models.Statuses.LoggerReceivedStatusModel, LivingThing.Core.IOT.Devices.Logger.Models.LoggerLogModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$IhzR.LCIDLMS.LoggerReceivedStatusModel, $.$IhzR.LCIDLM.LoggerLogModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$IhzR.LCIDLMS.LoggerReceivedStatusModel, $.$IhzR.LCIDLM.LoggerLogModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181452289)
            
            //--TRIMMABLE-BOUNDARY-START(8591517697)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591517697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591517697)
            
            static $h = 1583105;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886484993),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1583105,
      "h": 12886484993,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886484993),
//--TRIMMABLE-BOUNDARY-START(17181452289),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1452033,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1583105,
      "h": 17181452289,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181452289),
//--TRIMMABLE-BOUNDARY-START(8591517697),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1452033,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1583105,
      "h": 8591517697,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591517697)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296550401),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1583105,
      "h": 4296550401,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296550401)
  ],
  "h": 1583105
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1583105)
        
        

        //--TRIMMABLE-BOUNDARY-START(665601)
        $asm.$cls(`$IhzR.LCIDL$1.LoggerReceivedDataConverter`, ($self) => class LoggerReceivedDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295632897)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295632897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295632897)
            
            //--TRIMMABLE-BOUNDARY-START(4295632897)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295632897)
            
            static $h = 665601;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295632897),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 665601,
      "h": 4295632897,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295632897)
  ],
  "h": 665601
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$IhzR.LCIDLM.LoggerStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.LoggerReceivedDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}LoggerReceivedDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(665601)
        
        

        $asm.$typeProxy("$IhzR.LCIDLM.LoggerServiceModel", "$IhzR.LivingThing.Core.IOT.Devices.Logger.Models.LoggerServiceModel");
        $asm.$typeProxy("$IhzR.LCIDLM.LoggerDeviceModel", "$IhzR.LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceModel");
        $asm.$typeProxy("$IhzR.LCIDLS$1.LoggerDeviceSettings", "$IhzR.LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceSettings");
        $asm.$typeProxy("$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings", "$IhzR.LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceHardwareSettings");
        $asm.$typeProxy("$IhzR.LCIDLS.ILoggerDeviceStatusHandler", "$IhzR.LivingThing.Core.IOT.Devices.Logger.Services.ILoggerDeviceStatusHandler");
        $asm.$typeProxy("$IhzR.LCIDLS.ILoggerDeviceHubClient", "$IhzR.LivingThing.Core.IOT.Devices.Logger.Services.ILoggerDeviceHubClient");
        $asm.$typeProxy("$IhzR.LCIDLS.ILoggerRemoteService", "$IhzR.LivingThing.Core.IOT.Devices.Logger.Services.ILoggerRemoteService");
        //--TRIMMABLE-BOUNDARY-START(1714177)
        $asm.$cls(`$IhzR.LCIDLM.LoggerDeviceScopeModel`, ($self) => class LoggerDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296681473)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296681473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296681473)
            
            //--TRIMMABLE-BOUNDARY-START(4296681473)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296681473)
            
            static $h = 1714177;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296681473),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1714177,
      "h": 4296681473,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296681473)
  ],
  "h": 1714177
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1714177)
        
        

        //--TRIMMABLE-BOUNDARY-START(1189889)
        $asm.$cls(`$IhzR.LCIDLM.LoggerDeviceModel`, ($self) => class LoggerDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296157185)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296157185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296157185)
            
            //--TRIMMABLE-BOUNDARY-START(4296157185)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296157185)
            
            static $h = 1189889;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296157185),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1189889,
      "h": 4296157185,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296157185)
  ],
  "h": 1189889
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1189889)
        
        

        //--TRIMMABLE-BOUNDARY-START(4990977)
        $asm.$cls(`$IhzR.LCIDLS.ILoggerDeviceStatusHandler`, ($self) => class ILoggerDeviceStatusHandler
        {
            static $h = 4990977;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 4990977
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Services.ILoggerDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Services${separator}ILoggerDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4990977)
        
        

        //--TRIMMABLE-BOUNDARY-START(3483649)
        $asm.$cls(`$IhzR.LCIDLM.LoggerServiceModel`, ($self) => class LoggerServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298450945)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298450945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298450945)
            
            //--TRIMMABLE-BOUNDARY-START(4298450945)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4298450945)
            
            static $h = 3483649;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298450945),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 3483649,
      "h": 4298450945,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298450945)
  ],
  "h": 3483649
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3483649)
        
        

        //--TRIMMABLE-BOUNDARY-START(4925441)
        $asm.$cls(`$IhzR.LCIDLS.ILoggerDeviceHubClient`, ($self) => class ILoggerDeviceHubClient
        {
            static $h = 4925441;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 4925441
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Services.ILoggerDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Services${separator}ILoggerDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4925441)
        
        

        //--TRIMMABLE-BOUNDARY-START(5646337)
        $asm.$cls(`$IhzR.LCIDLS$1.LoggerDeviceSettings`, ($self) => class LoggerDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $self, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4300613633)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300613633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300613633)
            
            //--TRIMMABLE-BOUNDARY-START(4300613633)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4300613633)
            
            static $h = 5646337;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300613633),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 5646337,
      "h": 4300613633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300613633)
  ],
  "h": 5646337
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Settings${separator}LoggerDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5646337)
        
        

        //--TRIMMABLE-BOUNDARY-START(5056513)
        $asm.$cls(`$IhzR.LCIDLS.ILoggerRemoteService`, ($self) => class ILoggerRemoteService
        {
            static $h = 5056513;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 5056513
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$IhzR.LCIDLM.LoggerServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$IhzR.LCIDLM.LoggerServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$IhzR.LCIDLM.LoggerServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$IhzR.LCIDLM.LoggerServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$IhzR.LCIDLM.LoggerServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$IhzR.LCIDLM.LoggerServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$IhzR.LCIDLM.LoggerServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$IhzR.LCIDLM.LoggerServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Services.ILoggerRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Services${separator}ILoggerRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5056513)
        
        

        //--TRIMMABLE-BOUNDARY-START(5384193)
        $asm.$cls(`$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings`, ($self) => class LoggerDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).iSmartDeviceHardwareSettings$$($.$IhzR.LCIDLS$1.LoggerActions)
        {
            //--TRIMMABLE-BOUNDARY-START(4300351489)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300351489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300351489)
            
            //--TRIMMABLE-BOUNDARY-START(4300351489)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4300351489)
            
            static $h = 5384193;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).iSmartDeviceHardwareSettings$$($.$IhzR.LCIDLS$1.LoggerActions); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300351489),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5384193,
      "h": 4300351489,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300351489)
  ],
  "h": 5384193
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Settings${separator}LoggerDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5384193)
        
        

        //--TRIMMABLE-BOUNDARY-START(75777)
        $asm.$cls(`$IhzR.LCIDL.LoggerDeviceModelDefinition`, ($self) => class LoggerDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4295043073)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295043073);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295043073)
            
            //--TRIMMABLE-BOUNDARY-START(4295043073)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295043073)
            
            static $h = 75777;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295043073),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 75777,
      "h": 4295043073,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295043073)
  ],
  "h": 75777
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.LEDMatrix.LoggerDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}LEDMatrix${separator}LoggerDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(75777)
        
        

        //--TRIMMABLE-BOUNDARY-START(3614721)
        $asm.$cls(`$IhzR.LCIDLM.LoggerServiceModelTypeDescriptor`, ($self) => class LoggerServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298582017)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298582017);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$IhzR.LCIDLM.LoggerServiceModelTypeDescriptor.GenerateProperties($.$IhzR.LCIDLM.LoggerServiceModel, this, factory);
                    }, $CmbTyh ??= {"r":65537,"n":"","d":3614721,"h":0,"f":17825794}), 0, "LoggerServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\Models_LoggerServiceModel_LivingThing.Core.IOT.Devices.Logger.Models.LoggerServiceModelTypeDescriptorBuilder.g.cs", "LoggerServiceModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298582017)
            
            //--TRIMMABLE-BOUNDARY-START(12888516609)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888516609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888516609)
            
            //--TRIMMABLE-BOUNDARY-START(17183483905)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183483905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Logger.Models.LoggerServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceModel, LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceSettings, LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Devices.Logger.Models.LoggerStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceSendDataModel, LivingThing.Core.IOT.Devices.Logger.Services.ILoggerDeviceStatusHandler, LivingThing.Core.IOT.Devices.Logger.Services.ILoggerDeviceHubClient, LivingThing.Core.IOT.Devices.Logger.Services.ILoggerRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183483905)
            
            //--TRIMMABLE-BOUNDARY-START(8593549313)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593549313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$IhzR.LCIDLM.LoggerServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$IhzR.LCIDLM.LoggerServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerServiceModel)))
                {
                    /*var*/ let result = $.$IhzR.LCIDLM.LoggerServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$IhzR.LCIDLM.LoggerServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593549313)
            
            static $h = 3614721;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888516609),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3614721,
      "h": 12888516609,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888516609),
//--TRIMMABLE-BOUNDARY-START(17183483905),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3483649,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3614721,
      "h": 17183483905,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183483905),
//--TRIMMABLE-BOUNDARY-START(8593549313),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3483649,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3614721,
      "h": 8593549313,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593549313)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298582017),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3614721,
      "h": 4298582017,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298582017)
  ],
  "h": 3614721
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$IhzR.LCIDLM.LoggerServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3614721)
        
        

        //--TRIMMABLE-BOUNDARY-START(1845249)
        $asm.$cls(`$IhzR.LCIDLM.LoggerDeviceScopeModelTypeDescriptor`, ($self) => class LoggerDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296812545)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296812545);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$IhzR.LCIDLM.LoggerDeviceScopeModelTypeDescriptor.GenerateProperties($.$IhzR.LCIDLM.LoggerDeviceScopeModel, this, factory);
                    }, $nohEYb ??= {"r":65537,"n":"","d":1845249,"h":0,"f":17825794}), 0, "LoggerDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\Models_LoggerDeviceScopeModel_LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceScopeModelTypeDescriptorBuilder.g.cs", "LoggerDeviceScopeModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296812545)
            
            //--TRIMMABLE-BOUNDARY-START(12886747137)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886747137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886747137)
            
            //--TRIMMABLE-BOUNDARY-START(17181714433)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181714433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Logger.Models.LoggerServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceModel, LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceSettings, LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Devices.Logger.Models.LoggerStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceSendDataModel, LivingThing.Core.IOT.Devices.Logger.Services.ILoggerDeviceStatusHandler, LivingThing.Core.IOT.Devices.Logger.Services.ILoggerDeviceHubClient, LivingThing.Core.IOT.Devices.Logger.Services.ILoggerRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181714433)
            
            //--TRIMMABLE-BOUNDARY-START(8591779841)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591779841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$IhzR.LCIDLM.LoggerDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerDeviceScopeModel)))
                {
                    /*var*/ let result = $.$IhzR.LCIDLM.LoggerDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591779841)
            
            static $h = 1845249;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886747137),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1845249,
      "h": 12886747137,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886747137),
//--TRIMMABLE-BOUNDARY-START(17181714433),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1714177,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1845249,
      "h": 17181714433,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181714433),
//--TRIMMABLE-BOUNDARY-START(8591779841),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1714177,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1845249,
      "h": 8591779841,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591779841)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296812545),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1845249,
      "h": 4296812545,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296812545)
  ],
  "h": 1845249
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$IhzR.LCIDLM.LoggerDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1845249)
        
        

        //--TRIMMABLE-BOUNDARY-START(1320961)
        $asm.$cls(`$IhzR.LCIDLM.LoggerDeviceModelTypeDescriptor`, ($self) => class LoggerDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296288257)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296288257);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$IhzR.LCIDLM.LoggerDeviceModelTypeDescriptor.GenerateProperties($.$IhzR.LCIDLM.LoggerDeviceModel, this, factory);
                    }, $KawDal ??= {"r":65537,"n":"","d":1320961,"h":0,"f":17825794}), 0, "LoggerDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\Models_LoggerDeviceModel_LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceModelTypeDescriptorBuilder.g.cs", "LoggerDeviceModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296288257)
            
            //--TRIMMABLE-BOUNDARY-START(12886222849)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886222849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886222849)
            
            //--TRIMMABLE-BOUNDARY-START(17181190145)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181190145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Logger.Models.LoggerServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceModel, LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceSettings, LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Devices.Logger.Models.LoggerStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceSendDataModel, LivingThing.Core.IOT.Devices.Logger.Services.ILoggerDeviceStatusHandler, LivingThing.Core.IOT.Devices.Logger.Services.ILoggerDeviceHubClient, LivingThing.Core.IOT.Devices.Logger.Services.ILoggerRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181190145)
            
            //--TRIMMABLE-BOUNDARY-START(8591255553)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591255553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$IhzR.LCIDLM.LoggerDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$IhzR.LCIDLM.LoggerDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerDeviceModel)))
                {
                    /*var*/ let result = $.$IhzR.LCIDLM.LoggerDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$IhzR.LCIDLM.LoggerDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLM.LoggerDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591255553)
            
            static $h = 1320961;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLM.LoggerDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886222849),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1320961,
      "h": 12886222849,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886222849),
//--TRIMMABLE-BOUNDARY-START(17181190145),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1189889,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1320961,
      "h": 17181190145,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181190145),
//--TRIMMABLE-BOUNDARY-START(8591255553),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1189889,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1320961,
      "h": 8591255553,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591255553)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296288257),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1320961,
      "h": 4296288257,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296288257)
  ],
  "h": 1320961
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$IhzR.LCIDLM.LoggerDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Models${separator}LoggerDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1320961)
        
        

        //--TRIMMABLE-BOUNDARY-START(5515265)
        $asm.$cls(`$IhzR.LCIDLS$1.LoggerDeviceHardwareSettingsTypeDescriptor`, ($self) => class LoggerDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4300482561)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300482561);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, this, factory);
                    }, $QLXQnh ??= {"r":65537,"n":"","d":5515265,"h":0,"f":17825794}), 0, "LoggerDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\Settings_LoggerDeviceHardwareSettings_LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "LoggerDeviceHardwareSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300482561)
            
            //--TRIMMABLE-BOUNDARY-START(12890417153)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890417153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor$$($.$IhzR.LCIDLS$1.LoggerActions).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890417153)
            
            //--TRIMMABLE-BOUNDARY-START(17185384449)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185384449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.Logger.Models.LoggerServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceModel, LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceSettings, LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Devices.Logger.Models.LoggerStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceSendDataModel, LivingThing.Core.IOT.Devices.Logger.Services.ILoggerDeviceStatusHandler, LivingThing.Core.IOT.Devices.Logger.Services.ILoggerDeviceHubClient, LivingThing.Core.IOT.Devices.Logger.Services.ILoggerRemoteService>.iSmartDeviceHardwareSettings<LivingThing.Core.IOT.Devices.Logger.Settings.LoggerActions>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor$$($.$IhzR.LCIDLS$1.LoggerActions).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).iSmartDeviceHardwareSettings$$($.$IhzR.LCIDLS$1.LoggerActions)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185384449)
            
            //--TRIMMABLE-BOUNDARY-START(8595449857)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595449857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595449857)
            
            static $h = 5515265;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890417153),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5515265,
      "h": 12890417153,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890417153),
//--TRIMMABLE-BOUNDARY-START(17185384449),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5384193,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5515265,
      "h": 17185384449,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185384449),
//--TRIMMABLE-BOUNDARY-START(8595449857),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5384193,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5515265,
      "h": 8595449857,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595449857)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300482561),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5515265,
      "h": 4300482561,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300482561)
  ],
  "h": 5515265
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Settings${separator}LoggerDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5515265)
        
        

        //--TRIMMABLE-BOUNDARY-START(5777409)
        $asm.$cls(`$IhzR.LCIDLS$1.LoggerDeviceSettingsTypeDescriptor`, ($self) => class LoggerDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLS$1.LoggerDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4300744705)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300744705);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$IhzR.LCIDLS$1.LoggerDeviceSettingsTypeDescriptor.GenerateProperties($.$IhzR.LCIDLS$1.LoggerDeviceSettings, this, factory);
                    }, $uSZnzb ??= {"r":65537,"n":"","d":5777409,"h":0,"f":17825794}), 0, "LoggerDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\Settings_LoggerDeviceSettings_LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceSettingsTypeDescriptorBuilder.g.cs", "LoggerDeviceSettingsTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300744705)
            
            //--TRIMMABLE-BOUNDARY-START(12890679297)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890679297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890679297)
            
            //--TRIMMABLE-BOUNDARY-START(17185646593)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185646593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.Logger.Models.LoggerServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceModel, LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceSettings, LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Devices.Logger.Models.LoggerStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Logger.Models.LoggerDeviceSendDataModel, LivingThing.Core.IOT.Devices.Logger.Services.ILoggerDeviceStatusHandler, LivingThing.Core.IOT.Devices.Logger.Services.ILoggerDeviceHubClient, LivingThing.Core.IOT.Devices.Logger.Services.ILoggerRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService).iSmartDeviceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185646593)
            
            //--TRIMMABLE-BOUNDARY-START(8595712001)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595712001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$IhzR.LCIDLS$1.LoggerDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLS$1.LoggerDeviceSettings)))
                {
                    /*var*/ let result = $.$IhzR.LCIDLS$1.LoggerDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLS$1.LoggerDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$IhzR.LCIDLS$1.LoggerDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595712001)
            
            static $h = 5777409;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$IhzR.LCIDLS$1.LoggerDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890679297),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5777409,
      "h": 12890679297,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890679297),
//--TRIMMABLE-BOUNDARY-START(17185646593),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5646337,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5777409,
      "h": 17185646593,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185646593),
//--TRIMMABLE-BOUNDARY-START(8595712001),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5646337,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5777409,
      "h": 8595712001,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595712001)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300744705),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5777409,
      "h": 4300744705,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300744705)
  ],
  "h": 5777409
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$IhzR.LCIDLS$1.LoggerDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Settings.LoggerDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Settings${separator}LoggerDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5777409)
        
        

        //--TRIMMABLE-BOUNDARY-START(468993)
        $asm.$cls(`$IhzR.LCIDL$1.LoggerDevice`, ($self) => class LoggerDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4295436289)
            $ctor$2(/*IIOTDeviceFamily<LoggerDevice>*/ family, /*IIOTDeviceScope*/ scope, /*LoggerDeviceModel*/ model)
            {
                super.$ctor$3(family, scope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295436289);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295436289)
            
            //--TRIMMABLE-BOUNDARY-START(47245109249)
            /*int */ get SampleDataPoints()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475305473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = this.Received?.Status?.LogType;
                switch($switch1)
                {
                    case 2/*LoggerLogType.PowerUp*/:
                    return 1;
                    case 3/*LoggerLogType.Voltage*/:
                    return 1;
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(47245109249)
            
            //--TRIMMABLE-BOUNDARY-START(25770272769)
            /*string? */ GetDataLabel(/*int*/ i)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770272769);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770272769)
            
            //--TRIMMABLE-BOUNDARY-START(42950141953)
            /*IIOTDeviceReceivedDataModel? */ get ReceivedStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885370881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.ReceivedStatus;
            }
            /*IIOTDeviceReceivedDataModel? */ set ReceivedStatus(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835043841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LoggerDeviceReceivedDataModel?*/ let m = $.$cast(value, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel);
                if (m !== null && m.Status === null)
                {
                    m.Status = (($.$cast(super.ReceivedStatus, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel))?.Status ?? null);
                }
                super.ReceivedStatus = value;
            }
            //--TRIMMABLE-BOUNDARY-END(42950141953)
            
            //--TRIMMABLE-BOUNDARY-START(34360207361)
            /*Task<IEnumerable<LoggerLogModel>> *//*async*/  GetLogs(/*DataFilter*/ filter)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$IhzR.LCIDLM.LoggerLogModel)), $.$$.SCG.IEnumerable$$($.$IhzR.LCIDLM.LoggerLogModel), async ($asnycContext) => 
                {
                    let $t3, $r3;
                    let $t4, $r4;
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360207361);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    var p;
                    let $switch2 = this.Received?.Status?.LogType;
                    switch($switch2)
                    {
                        case 2/*LoggerLogType.PowerUp*/:
                        p = ($t3 = $.$XBGm.LCICDi.iSmartDeviceCommandExtension.GetLogs$2($.$IhzR.LCIDLM.LoggerLogPowerModel, this, filter), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$$.N.InterfaceVarianceStubHandler.Create(p, $.$$.SCG.IEnumerable$$($.$IhzR.LCIDLM.LoggerLogPowerModel), $.$$.SCG.IEnumerable$$($.$IhzR.LCIDLM.LoggerLogModel)));
                        case 4/*LoggerLogType.Input*/:
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$$.N.InterfaceVarianceStubHandler.Create(($t4 = $.$XBGm.LCICDi.iSmartDeviceCommandExtension.GetLogs$2($.$IhzR.LCIDLM.LoggerLogInputModel, this, filter), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4))), $.$$.SCG.IEnumerable$$($.$IhzR.LCIDLM.LoggerLogInputModel), $.$$.SCG.IEnumerable$$($.$IhzR.LCIDLM.LoggerLogModel)));
                        case 3/*LoggerLogType.Voltage*/:
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$$.N.InterfaceVarianceStubHandler.Create(($t5 = $.$XBGm.LCICDi.iSmartDeviceCommandExtension.GetLogs$2($.$IhzR.LCIDLM.LoggerLogVoltageModel, this, filter), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5))), $.$$.SCG.IEnumerable$$($.$IhzR.LCIDLM.LoggerLogVoltageModel), $.$$.SCG.IEnumerable$$($.$IhzR.LCIDLM.LoggerLogModel)));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Empty($.$IhzR.LCIDLM.LoggerLogModel));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34360207361)
            
            //--TRIMMABLE-BOUNDARY-START(38655174657)
            /*Task<LoggerGetPowerAnalyticsResponseModel> *//*async*/  GetPowerAnalytics(/*DateTime*/ startTime, /*DateTime*/ endTime)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel), $.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655174657);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ((this.Received?.Status?.LogType ?? null) === 2/*LoggerLogType.PowerUp*/ || (this.Received?.Status?.LogType ?? null) === 1/*LoggerLogType.PowerDown*/)
                    {
                        let $t6, $r6;
                        /*var*/ let m = ($t6 = $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.SendCommand$2($.$IhzR.LCIDLMC.LoggerGetAnalyticsCommand, $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel, $.$XBGm.LCICDi.iSmartDeviceCommandResponseModel$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel), this, new $.$IhzR.LCIDLMC.LoggerGetAnalyticsCommand().$ctor$5(), new $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel().$ctor$3(startTime, endTime), null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$firstOf((m?.Data ?? null), () => { throw new $.$$.S.ApplicationException().$ctor$8("Error") }));
                    }
                    throw new $.$$.S.InvalidOperationException().$ctor$9();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38655174657)
            
            //--TRIMMABLE-BOUNDARY-START(30065240065)
            /*Task<LoggerGetInputAnalyticsResponseModel> *//*async*/  GetInputAnalytics(/*DateTime*/ startTime, /*DateTime*/ endTime)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel), $.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065240065);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ((this.Received?.Status?.LogType ?? null) === 4/*LoggerLogType.Input*/)
                    {
                        let $t7, $r7;
                        /*var*/ let m = ($t7 = $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.SendCommand$2($.$IhzR.LCIDLMC.LoggerGetAnalyticsCommand, $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel, $.$XBGm.LCICDi.iSmartDeviceCommandResponseModel$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel), this, new $.$IhzR.LCIDLMC.LoggerGetAnalyticsCommand().$ctor$5(), new $.$IhzR.LCIDLMC$1.LoggerGetAnalyticsCommandModel().$ctor$3(startTime, endTime), null), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$firstOf((m?.Data ?? null), () => { throw new $.$$.S.ApplicationException().$ctor$8("Error") }));
                    }
                    throw new $.$$.S.InvalidOperationException().$ctor$9();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30065240065)
            
            static $h = 468993;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDL$1.LoggerDevice, $.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245109249),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475305473,
        "f": 50331649
      },
      "n": "SampleDataPoints",
      "d": 468993,
      "h": 47245109249,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245109249),
//--TRIMMABLE-BOUNDARY-START(42950141953),
    {
      "p": 28415377,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885370881,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835043841,
        "f": 83918849
      },
      "n": "ReceivedStatus",
      "d": 468993,
      "h": 42950141953,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950141953)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770272769),
    {
      "r": 1310721,
      "p": [
        {
          "n": "i",
          "p": 655361
        }
      ],
      "n": "GetDataLabel",
      "d": 468993,
      "h": 25770272769,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770272769),
//--TRIMMABLE-BOUNDARY-START(34360207361),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$IhzR.LCIDLM.LoggerLogModel)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": "GetLogs",
      "d": 468993,
      "h": 34360207361,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(34360207361),
//--TRIMMABLE-BOUNDARY-START(38655174657),
    {
      "r": $.$$.STT.Task$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel).$h,
      "p": [
        {
          "n": "startTime",
          "p": 65994753
        },
        {
          "n": "endTime",
          "p": 65994753
        }
      ],
      "n": "GetPowerAnalytics",
      "d": 468993,
      "h": 38655174657,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(38655174657),
//--TRIMMABLE-BOUNDARY-START(30065240065),
    {
      "r": $.$$.STT.Task$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel).$h,
      "p": [
        {
          "n": "startTime",
          "p": 65994753
        },
        {
          "n": "endTime",
          "p": 65994753
        }
      ],
      "n": "GetInputAnalytics",
      "d": 468993,
      "h": 30065240065,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(30065240065)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295436289),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$IhzR.LCIDL$1.LoggerDevice).$h
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 1189889
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 468993,
      "h": 4295436289,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295436289)
  ],
  "h": 468993
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.LoggerDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}LoggerDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(468993)
        
        

        //--TRIMMABLE-BOUNDARY-START(534529)
        $asm.$cls(`$IhzR.LCIDL$1.LoggerDeviceDefinition`, ($self) => class LoggerDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDL$1.LoggerDevice, $.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295501825)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295501825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295501825)
            
            //--TRIMMABLE-BOUNDARY-START(4295501825)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295501825)
            
            static $h = 534529;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDL$1.LoggerDevice, $.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$IhzR.LCIDLMS.LoggerReceivedStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295501825),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 534529,
      "h": 4295501825,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295501825)
  ],
  "h": 534529
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.LoggerDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}LoggerDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(534529)
        
        

        //--TRIMMABLE-BOUNDARY-START(600065)
        $asm.$cls(`$IhzR.LCIDL$1.LoggerDeviceFamily`, ($self) => class LoggerDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDL$1.LoggerDevice, $.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4295567361)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<LoggerDeviceReceivedDataModel, LoggerDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<LoggerDeviceReceivedDataModel, LoggerStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295567361);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295567361)
            
            //--TRIMMABLE-BOUNDARY-START(8590534657)
            /*Type? */ get DeviceLogType()
            {
                return $.$IhzR.LCIDLM.LoggerLogModel.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8590534657)
            
            static $h = 600065;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$IhzR.LCIDL$1.LoggerDevice, $.$IhzR.LCIDLM.LoggerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$IhzR.LCIDLM.LoggerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$IhzR.LCIDLM.LoggerDeviceModel, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$IhzR.LCIDLM.LoggerStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel, $.$IhzR.LCIDLS.ILoggerDeviceStatusHandler, $.$IhzR.LCIDLS.ILoggerDeviceHubClient, $.$IhzR.LCIDLS.ILoggerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590534657),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180469249,
        "f": 50364417
      },
      "n": "DeviceLogType",
      "d": 600065,
      "h": 8590534657,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8590534657)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295567361),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 600065,
      "h": 4295567361,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295567361)
  ],
  "h": 600065
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$IhzR.LCIDL$1.LoggerDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$IhzR.LCIDL$1.LoggerDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.LoggerDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}LoggerDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(600065)
        
        

        //--TRIMMABLE-BOUNDARY-START(6170625)
        $asm.$cls(`$IhzR.LCIDLV.PowerLoggerUptime`, ($self) => class PowerLoggerUptime extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$IhzR.LCIDL$1.LoggerDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(21481007105)
            /*string */ get OptimizedComponentName()
            {
                return "powerloggeruptime";
            }
            //--TRIMMABLE-BOUNDARY-END(21481007105)
            
            //--TRIMMABLE-BOUNDARY-START(8596105217)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596105217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((this.ViewModel.Received?.Status?.UpTime ?? null) !== null)
                {
                    /*var*/ let span = $.$$.S.DateTime.op_Subtraction$1($.$$.S.DateTime.UtcNow, $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.ViewModel.Received.Status.UpTime));
                    __builder.OpenElement(0, "div");
                    __builder.AddAttribute$5(1, "class", "mgl-a mgy-a flex");
                    __builder.OpenComponent$1($.$hDPm.LCFCCG.SevenSegmentTimeSpan, 2);
                    __builder.AddComponentParameter(3, "Height", "20");
                    __builder.AddComponentParameter(4, "Width", "10");
                    __builder.AddComponentParameter(5, "Span", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.TimeSpan, span));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8596105217)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4301137921)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301137921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301137921)
            
            //--TRIMMABLE-BOUNDARY-START(4301137921)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4301137921)
            
            static $h = 6170625;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$IhzR.LCIDL$1.LoggerDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21481007105),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17186039809,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 6170625,
      "h": 21481007105,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21481007105)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596105217),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 6170625,
      "h": 8596105217,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8596105217)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301137921),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6170625,
      "h": 4301137921,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301137921)
  ],
  "h": 6170625
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Views.PowerLoggerUptime`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Views${separator}PowerLoggerUptime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6170625)
        
        

        //--TRIMMABLE-BOUNDARY-START(6105089)
        $asm.$cls(`$IhzR.LCIDLV.LoggerViewRenderer`, ($self) => class LoggerViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$$($.$IhzR.LCIDL$1.LoggerDevice, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$IhzR.LCIDLM.LoggerStatusModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4301072385)
            $ctor$3(/*IOTRootViewModel*/ root)
            {
                super.$ctor$2(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301072385);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301072385)
            
            //--TRIMMABLE-BOUNDARY-START(8596039681)
            /*RenderFragment? */ GetView(/*IClientUnitOfWork*/ ui, /*LoggerDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>?*/ clicked, /*Func<Task>?*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596039681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === 3/*DeviceViewType.Details*/)
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$IhzR.LCIDLV.LoggerDeviceDetails, $.$IhzR.LCIDLV.LoggerDetailsViewModel, new $.$IhzR.LCIDLV.LoggerDetailsViewModel().$ctor$9(this.Root, device.OwnerScope, device), true, null);
                }
                if (type === 1/*DeviceViewType.MajorStatus*/ && ((device.Received?.Status?.LogType ?? null) === 2/*LoggerLogType.PowerUp*/) || ((device.Received?.Status?.LogType ?? null) === 1/*LoggerLogType.PowerDown*/))
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$IhzR.LCIDLV.PowerLoggerUptime, $.$IhzR.LCIDL$1.LoggerDevice, device, false, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(8596039681)
            
            static $h = 6105089;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$$($.$IhzR.LCIDL$1.LoggerDevice, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$IhzR.LCIDLM.LoggerStatusModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596039681),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 468993
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 6105089,
      "h": 8596039681,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8596039681)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301072385),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 6105089,
      "h": 4301072385,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301072385)
  ],
  "h": 6105089
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$IhzR.LCIDL$1.LoggerDevice), $.$ntej.LCICD$1.IDeviceViewRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Views.LoggerViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Views${separator}LoggerViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6105089)
        
        

        //--TRIMMABLE-BOUNDARY-START(5974017)
        $asm.$cls(`$IhzR.LCIDLV.LoggerDetailsViewModel`, ($self) => class LoggerDetailsViewModel extends $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$$($.$IhzR.LCIDL$1.LoggerDevice, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$IhzR.LCIDLM.LoggerStatusModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4300941313)
            $ctor$9(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*LoggerDevice*/ device)
            {
                super.$ctor$8(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300941313);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300941313)
            
            static $h = 5974017;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$$($.$IhzR.LCIDL$1.LoggerDevice, $.$IhzR.LCIDLS$1.LoggerDeviceSettings, $.$IhzR.LCIDLS$1.LoggerDeviceHardwareSettings, $.$IhzR.LCIDLM.LoggerStatusModel, $.$IhzR.LCIDLM.LoggerDeviceReceivedDataModel, $.$IhzR.LCIDLM.LoggerDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300941313),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 468993
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 5974017,
      "h": 4300941313,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300941313)
  ],
  "h": 5974017
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICDV.IDeviceDetailsViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Views.LoggerDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Views${separator}LoggerDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5974017)
        
        

        //--TRIMMABLE-BOUNDARY-START(6039553)
        $asm.$cls(`$IhzR.LCIDLV.LoggerDeviceDetails`, ($self) => class LoggerDeviceDetails extends $.$hDPm.LCFCC$1.BaseComponent$$($.$IhzR.LCIDLV.LoggerDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(77315450881)
            /*string */ get OptimizedComponentName()
            {
                return "loggerdevicedetails";
            }
            //--TRIMMABLE-BOUNDARY-END(77315450881)
            
            //--TRIMMABLE-BOUNDARY-START(107380221953)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107380221953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$IhzR.LCIDLV.LoggerDetailsViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(107380221953)
            
            //--TRIMMABLE-BOUNDARY-START(64430548993)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64430548993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.JavaScript = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IJavaScriptRunner, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(64430548993)
            
            //--TRIMMABLE-BOUNDARY-START(68725516289)
            /*IJavaScriptRunner*/ JavaScript = null;
            //--TRIMMABLE-BOUNDARY-END(68725516289)
            
            //--TRIMMABLE-BOUNDARY-START(111675189249)
            /*LoggerDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(111675189249)
            
            //--TRIMMABLE-BOUNDARY-START(34365777921)
            /*IPlatformFileManager?*/ fileManager = null;
            //--TRIMMABLE-BOUNDARY-END(34365777921)
            
            //--TRIMMABLE-BOUNDARY-START(85905385473)
            /*Dictionary<DateRange, int>*/ seq = null;
            //--TRIMMABLE-BOUNDARY-END(85905385473)
            
            //--TRIMMABLE-BOUNDARY-START(81610418177)
            /*bool*/ readingLogs = false;
            //--TRIMMABLE-BOUNDARY-END(81610418177)
            
            //--TRIMMABLE-BOUNDARY-START(25775843329)
            /*string?*/ csv = null;
            //--TRIMMABLE-BOUNDARY-END(25775843329)
            
            //--TRIMMABLE-BOUNDARY-START(17185908737)
            /*Task *//*async*/  BeginReadLogs()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17185908737);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.readingLogs)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    /*var*/ let device = this.ViewModel.Device$1;
                    this.readingLogs = true;
                    try
                    {
                        let $t2, $r2;
                        /*var*/ let logCount = ($t2 = $.$XBGm.LCICDi.iSmartDeviceCommandExtension.CountLogs$2(device), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        /*var*/ let pages = $.trunc((((logCount.LogCount + 23) | 0)) / 24);
                        /*var*/ let logs = new ($.$$.SCG.List$$($.$IhzR.LCIDLM.LoggerLogPowerModel))().$ctor$1();
                        for(/*int*/ let i = 0; i < pages; i++)
                        {
                            do
                            {
                                if (this.IsDisposed)
                                {
                                    return $.$$.N.AsyncResolver.Result($asnycContext,);
                                }
                                try
                                {
                                    let $t3, $r3;
                                    /*var*/ let ilogs = ($t3 = device.GetLogs(new $.$fPer.LCFCD.DataFilter().$ctor$18(((i + 1) | 0), 24)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                    logs.AddRange($.$sl.SL.Enumerable.Where($.$IhzR.LCIDLM.LoggerLogPowerModel, $.$sl.SL.Enumerable.Cast($.$IhzR.LCIDLM.LoggerLogPowerModel, ilogs), new ($.$$.S.Func$$$($.$IhzR.LCIDLM.LoggerLogPowerModel, $.$$.S.Boolean))().$ctor(this,  (/**/ t) =>
                                    {
                                        return $.$$.S.DateTime.op_Inequality(t.Time, new $.$$.S.DateTime()) && t.Event !== 0/*LoggerLogType.Unknown*/;
                                    }, $eOfxHi ??= {"r":262145,"p":[{"n":"t","p":2762753}],"n":"","d":6039553,"h":0,"f":17825794})));
                                }
                                catch($e)
                                {
                                    continue;
                                }
                                break;
                            }
                            while(true);
                        }
                        this.csv = $.$$.S.String.Join$5("\r\n", $.$sl.SL.Enumerable.Select$1($.$IhzR.LCIDLM.LoggerLogPowerModel, $.$$.S.String, $.$sl.SL.Enumerable.OrderBy$1($.$IhzR.LCIDLM.LoggerLogPowerModel, $.$$.S.DateTime, logs, new ($.$$.S.Func$$$($.$IhzR.LCIDLM.LoggerLogPowerModel, $.$$.S.DateTime))().$ctor(this,  (/*d*/ d) =>
                        {
                            return d.Time;
                        }, $SoRgLc ??= {"r":65994753,"p":[{"n":"d","p":2762753}],"n":"","d":6039553,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$IhzR.LCIDLM.LoggerLogPowerModel, $.$$.S.String))().$ctor(this,  (/**/ d) =>
                        {
                            return `${$.$strNN(d.Time.ToString())}, ${$.$strNN($.$$.S.Enum.ToStringT($.$IhzR.LCIDLM.LoggerLogType, $.$$.S.UInt32, d.Event))}`;
                        }, $mmZlFj ??= {"r":1310721,"p":[{"n":"d","p":2762753}],"n":"","d":6039553,"h":0,"f":17825794})));
                    }
                    finally
                    {
                        {
                            let $t4, $r4;
                            this.readingLogs = false;
                            ($t4 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Logger\\LoggerDeviceDetails.razor.cs", "BeginReadLogs", 65), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17185908737)
            
            //--TRIMMABLE-BOUNDARY-START(30070810625)
            /*Task *//*async*/  ExportCSV()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30070810625);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let stream = null;
                    try
                    {
                        let $t5, $r5;
                        stream = ($t5 = this.fileManager.LCFCP$IPlatformFileManager$OpenFile("logs.csv", "text/csv", false), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        if (stream !== null)
                        {
                            let $t6, $r6;
                            ($t6 = new $.$$.SI.MemoryStream().$ctor$8($.$$.ST.Encoding.ASCII.GetBytes$8(this.csv)).CopyToAsync$3(stream), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                            stream.Flush();
                            stream.Close();
                        }
                    }
                    finally
                    {
                        stream?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30070810625)
            
            //--TRIMMABLE-BOUNDARY-START(73020483585)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73020483585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.fileManager = $.$mxdi.MED.ServiceProviderServiceExtensions.GetService($.$fPer.LCFCP.IPlatformFileManager, this.UnitOfWork.LCFCI$IClientUnitOfWork$ServiceProvider);
                let $en7 = $.$$.S.Array.GetEnumerator.call($.$fPer.LCFCDC.DateRange.$type.GetEnumValues());
                while ($en7.SC$1$IEnumerator$MoveNext())
                {
                    let _range = $en7.SC$1$IEnumerator$Current;
                    {
                        /*var*/ let range = $.$cast(_range, $.$fPer.LCFCDC.DateRange);
                        this.seq.set_Item(range, 0);
                    }
                }
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(73020483585)
            
            //--TRIMMABLE-BOUNDARY-START(21480876033)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21480876033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$IhzR.LCIDL$1.LoggerDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$IhzR.LCIDL$1.LoggerDevice), this.ViewModel));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(3, "div");
                    __builder2.AddAttribute$5(4, "class", "row mgt pd bg-card");
                    __builder2.OpenElement(5, "div");
                    __builder2.AddAttribute$5(6, "class", "col-a");
                    __builder2.OpenElement(7, "div");
                    __builder2.AddAttribute$5(8, "class", "hx-1 wx-1 round flex bg-card bd bd-primary bdw-5 shadow");
                    __builder2.OpenElement(9, "div");
                    __builder2.AddAttribute$5(10, "class", "mg-a text-center");
                    __builder2.OpenElement(11, "h1");
                    __builder2.AddAttribute$5(12, "class", "mg-0 cl-primary");
                    __builder2.AddContent$3(13, $.$box(this.ViewModel.Device$1.Received.Status.LogCount, $.$$.S.Int32));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(14, "\r\n                        ");
                    __builder2.OpenElement(15, "h3");
                    __builder2.AddAttribute$5(16, "class", "mg-0");
                    __builder2.AddContent$4(17, (() =>
                    {
                        var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(0, 1);
                        $handler.AppendFormatted($.$box(this.ViewModel.Device$1.Received.Status.Usage, $.$$.S.Double), null, "0.##");
                        return $handler.ToStringAndClear                ();
                    })());
                    __builder2.AddContent$4(18, "%");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(19, "\r\n            ");
                    __builder2.OpenElement(20, "div");
                    __builder2.AddAttribute$5(21, "class", "col-10 pdl stack");
                    __builder2.OpenElement(22, "div");
                    __builder2.AddAttribute$5(23, "class", "mgy-a");
                    __builder2.OpenElement(24, "h3");
                    __builder2.AddAttribute$5(25, "class", "mgt-0 mgb-1");
                    __builder2.AddContent$3(26, $.$box(this.ViewModel.Device$1.Received.Status.LogCount, $.$$.S.Int32));
                    __builder2.AddContent$4(27, " logs of ");
                    __builder2.AddContent$3(28, $.$box(this.ViewModel.Device$1.Received.Status.LogCapacity, $.$$.S.Int32));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(29, "\r\n                    ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCP$5.ProgressBar, 30);
                    __builder2.AddComponentParameter(31, "Class", "corner clip");
                    __builder2.AddComponentParameter(32, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                    __builder2.AddComponentParameter(33, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Warning));
                    __builder2.AddComponentParameter(34, "BackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Gray));
                    __builder2.AddComponentParameter(35, "Progress", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, $.$cast(this.ViewModel.Device$1.Received.Status.Usage, $.$$.S.Int32)), $.$$.S.Int32));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(36, "\r\n                    ");
                    __builder2.OpenElement(37, "h3");
                    __builder2.AddAttribute$5(38, "class", "mgt mgb-1");
                    __builder2.AddContent$3(39, $.$box(this.ViewModel.Device$1.Received.Status.SyncCount, $.$$.S.Int32));
                    __builder2.AddContent$4(40, " synched of ");
                    __builder2.AddContent$3(41, $.$box(this.ViewModel.Device$1.Received.Status.LogCount, $.$$.S.Int32));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(42, "\r\n                    ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCP$5.ProgressBar, 43);
                    __builder2.AddComponentParameter(44, "Class", "corner clip");
                    __builder2.AddComponentParameter(45, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                    __builder2.AddComponentParameter(46, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder2.AddComponentParameter(47, "BackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Gray));
                    __builder2.AddComponentParameter(48, "Progress", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, $.$cast(this.ViewModel.Device$1.Received.Status.SyncPercent, $.$$.S.Int32)), $.$$.S.Int32));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    if (this.ViewModel.Device$1.Received.Status.UpTime !== null)
                    {
                        /*var*/ let span = $.$$.S.DateTime.op_Subtraction$1($.$$.S.DateTime.UtcNow, $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.ViewModel.Device$1.Received.Status.UpTime));
                        __builder2.OpenElement(49, "h3");
                        __builder2.AddAttribute$5(50, "class", "mgx mgt-10 mgb-5");
                        __builder2.AddContent$4(51, "Uptime ");
                        __builder2.OpenElement(52, "small");
                        __builder2.AddContent$4(53, "(since ");
                        __builder2.AddContent$4(54, (this.ToLocalTime$1(this.ViewModel.Device$1.Received.Status.UpTime)?.ToString$3("yyyy/MM/dd HH:mm") ?? null));
                        __builder2.AddContent$4(55, ")");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(56, "\r\n            ");
                        __builder2.OpenElement(57, "div");
                        __builder2.AddAttribute$5(58, "class", "pd bg-card stack");
                        __builder2.OpenElement(59, "div");
                        __builder2.AddAttribute$5(60, "class", "mgx-a flex");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCG.SevenSegmentTimeSpan, 61);
                        __builder2.AddComponentParameter(62, "Height", "50");
                        __builder2.AddComponentParameter(63, "Width", "30");
                        __builder2.AddComponentParameter(64, "Span", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.TimeSpan, span));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }
                    __builder2.OpenElement(65, "div");
                    __builder2.AddAttribute$5(66, "class", "flex mgx mgt-10 mgb-5");
                    __builder2.AddMarkupContent(67, "<h3 class=\"mgy-a\">Edge Analytics</h3>");
                    if (this.fileManager !== null)
                    {
                        __builder2.OpenElement(68, "button");
                        __builder2.AddAttribute$5(69, "class", $.$strNN($.$strNN($.$strNN("mgl-a" + " mdi") + " mdi-") + $.$strNN((this.readingLogs ? "loading mdi-spin" : "table"))) + " mgl-a");
                        __builder2.AddAttribute$5(70, "title", "Read Logs");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 71, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.BeginReadLogs)));
                        __builder2.CloseElement();
                        if (this.csv !== null)
                        {
                            __builder2.OpenElement(72, "button");
                            __builder2.AddAttribute$5(73, "class", "mdi mdi-download");
                            __builder2.AddAttribute$5(74, "title", "Download CSV");
                            __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 75, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.ExportCSV)));
                            __builder2.CloseElement();
                        }
                    }
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(76, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tabs, 77);
                    __builder2.AddComponentParameter(78, "Class", "bg-card pdy");
                    __builder2.AddComponentParameter(79, "MenuFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$4.MenuFeatures, 1575140/*MenuFeatures.Default*/ | 65536/*MenuFeatures.Scroll*/), $.$hDPm.LCFCCM$4.MenuFeatures));
                    __builder2.AddAttribute$3(80, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        let $en8 = $.$$.S.Array.GetEnumerator.call($.$fPer.LCFCDC.DateRange.$type.GetEnumValues());
                        while ($en8.SC$1$IEnumerator$MoveNext())
                        {
                            let _range = $en8.SC$1$IEnumerator$Current;
                            {
                                /*var*/ let range = $.$cast(_range, $.$fPer.LCFCDC.DateRange);
                                if (range !== 1/*DateRange.Custom*/ && range !== 0/*DateRange.TillDate*/)
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 81);
                                    __builder3.AddComponentParameter(82, "Class", "pd");
                                    __builder3.AddAttribute$3(83, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*t*/ t) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenElement(84, "span");
                                            __builder4.AddAttribute$5(85, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("nowrap" + " d-block") + " pdx-3") + " pdy-2") + " bg-") + $.$strNN((t.Model.Selected ? "primary" : "secondary"))) + " corner-5");
                                            __builder4.AddContent$4(86, $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$dspc(_range, $.$$.S.Object, ($t) => $t.ToString)));
                                            __builder4.CloseElement();
                                        }, $JkCJxe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":6039553,"h":0,"f":17825794});
                                    }), $AheMFe ??= {"r":6881395,"p":[{"n":"t","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":6039553,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(87, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            /*var*/ let stEnd = $.$fPer.LCFCDC.DateTimeExtension.GetDate(range, true, null);
                                            /*var*/ let startTime = stEnd.Start;
                                            /*var*/ let endTime = stEnd.End;
                                            /*var*/ let duration = $.$$.S.TimeSpan.op_Addition(($.$$.S.DateTime.op_Subtraction$1(endTime, startTime)), $.$$.S.TimeSpan.FromSeconds$2(1n));
                                            if (this.ViewModel.Device$1.Received.Status.LogType === 2/*LoggerLogType.PowerUp*/ || this.ViewModel.Device$1.Received.Status.LogType === 1/*LoggerLogType.PowerDown*/)
                                            {
                                                __builder4.OpenComponent$1($.$hDPm.LCFCCT$3.TaskView$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel), 88);
                                                __builder4.AddComponentParameter(89, "Task", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel), $.$$.S.Func$$($.$$.STT.Task$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel)), $.$$.STT.ValueTask$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel), $.$$.S.Func$$($.$$.STT.ValueTask$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel)), $.$fPer.LCFCR.ReactiveObservable$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel)), $.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel), $.$$.S.Func$$($.$$.STT.Task$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel)), $.$$.STT.ValueTask$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel), $.$$.S.Func$$($.$$.STT.ValueTask$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel)), $.$fPer.LCFCR.ReactiveObservable$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel)).op_Implicit$2(new ($.$$.S.Func$$($.$$.STT.Task$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel)))().$ctor(this, ( () =>
                                                {
                                                    return this.ViewModel.Device$1.GetPowerAnalytics(startTime, endTime);
                                                }), $mEtWYh ??= {"r":$.$$.STT.Task$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel).$h,"n":"","d":6039553,"h":0,"f":17825794}))));
                                                __builder4.AddAttribute$3(90, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel)))().$ctor(this, ( (/*analytics*/ analytics) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                    {
                                                        __builder5.OpenElement(91, "div");
                                                        __builder5.AddAttribute$5(92, "class", "row pdy pos-rel bdb");
                                                        __builder5.AddMarkupContent(93, "<div class=\"col-a stack\"><i class=\"mg-a mdi mdi-flash fsz-25 cl-fatal hx-05 wx-05 bd round bg-card pd shadow mgr d-block flex mgc-a\"></i></div>\r\n                                        ");
                                                        __builder5.OpenElement(94, "div");
                                                        __builder5.AddAttribute$5(95, "class", "col-10 pdl stack");
                                                        __builder5.OpenElement(96, "h3");
                                                        __builder5.AddAttribute$5(97, "class", "mgy-a");
                                                        __builder5.AddContent$3(98, $.$box(analytics.Data.PowerCuts, $.$$.S.Int32));
                                                        __builder5.AddContent$4(99, " power cuts");
                                                        __builder5.CloseElement();
                                                        __builder5.CloseElement();
                                                        __builder5.AddMarkupContent(100, "\r\n                                        ");
                                                        __builder5.OpenElement(101, "div");
                                                        __builder5.AddAttribute$5(102, "class", "pos-abs r-0 t-0");
                                                        __builder5.OpenElement(103, "button");
                                                        __builder5.AddAttribute$5(104, "class", "mdi mdi-refresh bg-transparent");
                                                        __builder5.AddAttribute$7($.$macw.MACW.MouseEventArgs, 105, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                                        {
                                                            return (() =>
                                                            {
                                                                let $t9 = this.seq.get_Item(range);
                                                                this.seq.set_Item(range, $t9 + 1);
                                                                return $t9;
                                                            })();
                                                        }, $XIOVOg ??= {"r":65537,"n":"","d":6039553,"h":0,"f":17825794})));
                                                        __builder5.CloseElement();
                                                        __builder5.CloseElement();
                                                        __builder5.CloseElement();
                                                        __builder5.AddMarkupContent(106, "\r\n                                    ");
                                                        __builder5.OpenElement(107, "div");
                                                        __builder5.AddAttribute$5(108, "class", "row pdy bdb");
                                                        __builder5.AddMarkupContent(109, "<div class=\"col-a stack\"><i class=\"mg-a mdi mdi-lightbulb-on fsz-25 cl-primary hx-05 wx-05 bd round bg-card pd shadow mgr d-block flex mgc-a\"></i></div>\r\n                                        ");
                                                        __builder5.OpenElement(110, "div");
                                                        __builder5.AddAttribute$5(111, "class", "col-10 pdl");
                                                        /*var*/ let uperc = ($.$cast((analytics.Data.UpTimeSpan.TotalSeconds * 100 / duration.TotalSeconds), $.$$.S.Int32));
                                                        __builder5.OpenElement(112, "h3");
                                                        __builder5.AddAttribute$5(113, "class", "mgt-0 mgb");
                                                        __builder5.AddContent$4(114, "Up-Time (");
                                                        __builder5.AddContent$3(115, $.$box(uperc, $.$$.S.Int32));
                                                        __builder5.AddContent$4(116, "%)");
                                                        __builder5.CloseElement();
                                                        __builder5.AddMarkupContent(117, "\r\n                                            ");
                                                        __builder5.OpenElement(118, "span");
                                                        __builder5.AddAttribute$5(119, "class", "d-block mgb-1");
                                                        __builder5.AddContent$4(120, $.$fPer.LCFCDC.DateTimeExtension.DHMS(analytics.Data.UpTimeSpan, 2147483647));
                                                        __builder5.AddContent$4(121, " of ");
                                                        __builder5.AddContent$4(122, $.$fPer.LCFCDC.DateTimeExtension.DHMS(duration, 16/*DateTimeMask.Date*/));
                                                        __builder5.CloseElement();
                                                        __builder5.AddMarkupContent(123, "\r\n                                            ");
                                                        __builder5.OpenComponent$1($.$hDPm.LCFCCP$5.ProgressBar, 124);
                                                        __builder5.AddComponentParameter(125, "Class", "corner clip");
                                                        __builder5.AddComponentParameter(126, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                        __builder5.AddComponentParameter(127, "BackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Gray));
                                                        __builder5.AddComponentParameter(128, "Progress", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, uperc), $.$$.S.Int32));
                                                        __builder5.AddComponentParameter(129, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                                                        __builder5.CloseComponent();
                                                        __builder5.CloseElement();
                                                        __builder5.CloseElement();
                                                        __builder5.AddMarkupContent(130, "\r\n                                    ");
                                                        __builder5.OpenElement(131, "div");
                                                        __builder5.AddAttribute$5(132, "class", "row pdt");
                                                        __builder5.AddMarkupContent(133, "<div class=\"col-a stack\"><i class=\"mg-a mdi mdi-lightbulb-off fsz-25 cl-error hx-05 wx-05 bd round bg-card pd shadow mgr d-block  flex mgc-a\"></i></div>\r\n                                        ");
                                                        __builder5.OpenElement(134, "div");
                                                        __builder5.AddAttribute$5(135, "class", "col-10 pdl");
                                                        /*var*/ let dperc = ($.$cast((analytics.Data.DownTimeSpan.TotalSeconds * 100 / duration.TotalSeconds), $.$$.S.Int32));
                                                        __builder5.OpenElement(136, "h3");
                                                        __builder5.AddAttribute$5(137, "class", "mgt-0 mgb");
                                                        __builder5.AddContent$4(138, "Down-Time (");
                                                        __builder5.AddContent$3(139, $.$box(dperc, $.$$.S.Int32));
                                                        __builder5.AddContent$4(140, "%)");
                                                        __builder5.CloseElement();
                                                        __builder5.AddMarkupContent(141, "\r\n                                            ");
                                                        __builder5.OpenElement(142, "span");
                                                        __builder5.AddAttribute$5(143, "class", "d-block mgb-1");
                                                        __builder5.AddContent$4(144, $.$fPer.LCFCDC.DateTimeExtension.DHMS(analytics.Data.DownTimeSpan, 2147483647));
                                                        __builder5.AddContent$4(145, " of ");
                                                        __builder5.AddContent$4(146, $.$fPer.LCFCDC.DateTimeExtension.DHMS(duration, 16/*DateTimeMask.Date*/));
                                                        __builder5.CloseElement();
                                                        __builder5.AddMarkupContent(147, "\r\n                                            ");
                                                        __builder5.OpenComponent$1($.$hDPm.LCFCCP$5.ProgressBar, 148);
                                                        __builder5.AddComponentParameter(149, "Class", "corner clip");
                                                        __builder5.AddComponentParameter(150, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Error));
                                                        __builder5.AddComponentParameter(151, "BackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Gray));
                                                        __builder5.AddComponentParameter(152, "Progress", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, dperc), $.$$.S.Int32));
                                                        __builder5.AddComponentParameter(153, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                                                        __builder5.CloseComponent();
                                                        __builder5.CloseElement();
                                                        __builder5.CloseElement();
                                                    }, $GzInYb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":6039553,"h":0,"f":17825794});
                                                }), $MgyQOk ??= {"r":6881395,"p":[{"n":"analytics","p":$.$hDPm.LCFCI.ContainerContext$$($.$IhzR.LCIDLMS.LoggerGetPowerAnalyticsResponseModel).$h}],"n":"","d":6039553,"h":0,"f":17825794}));
                                                __builder4.SetKey($.$box(this.seq.get_Item(range), $.$$.S.Int32));
                                                __builder4.CloseComponent();
                                            }
                                            else if (this.ViewModel.Device$1.Received.Status.LogType === 4/*LoggerLogType.Input*/)
                                            {
                                                __builder4.OpenComponent$1($.$hDPm.LCFCCT$3.TaskView$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel), 154);
                                                __builder4.AddComponentParameter(155, "Task", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel), $.$$.S.Func$$($.$$.STT.Task$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel)), $.$$.STT.ValueTask$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel), $.$$.S.Func$$($.$$.STT.ValueTask$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel)), $.$fPer.LCFCR.ReactiveObservable$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel)), $.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel), $.$$.S.Func$$($.$$.STT.Task$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel)), $.$$.STT.ValueTask$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel), $.$$.S.Func$$($.$$.STT.ValueTask$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel)), $.$fPer.LCFCR.ReactiveObservable$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel)).op_Implicit$2(new ($.$$.S.Func$$($.$$.STT.Task$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel)))().$ctor(this, ( () =>
                                                {
                                                    return this.ViewModel.Device$1.GetInputAnalytics(startTime, endTime);
                                                }), $KcYZoe ??= {"r":$.$$.STT.Task$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel).$h,"n":"","d":6039553,"h":0,"f":17825794}))));
                                                __builder4.AddAttribute$3(156, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel)))().$ctor(this, ( (/*analytics*/ analytics) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                    {
                                                        __builder5.OpenElement(157, "div");
                                                        __builder5.AddAttribute$5(158, "class", "row pdb");
                                                        __builder5.AddMarkupContent(159, "<div class=\"col-a stack\"><i class=\"mg-a mdi mdi-flash fsz-40 cl-fatal hx-07 wx-07 bd round bg-card pd shadow mgr d-block flex mgc-a\"></i></div>\r\n                                        ");
                                                        __builder5.OpenElement(160, "div");
                                                        __builder5.AddAttribute$5(161, "class", "col-10 pdl stack");
                                                        __builder5.OpenElement(162, "h3");
                                                        __builder5.AddAttribute$5(163, "class", "mgy-a");
                                                        __builder5.AddContent$3(164, $.$box(analytics.Data.Count, $.$$.S.Int32));
                                                        __builder5.AddContent$4(165, " events");
                                                        __builder5.CloseElement();
                                                        __builder5.CloseElement();
                                                        __builder5.CloseElement();
                                                    }, $gFTpmi ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":6039553,"h":0,"f":17825794});
                                                }), $HFnTYh ??= {"r":6881395,"p":[{"n":"analytics","p":$.$hDPm.LCFCI.ContainerContext$$($.$IhzR.LCIDLMS.LoggerGetInputAnalyticsResponseModel).$h}],"n":"","d":6039553,"h":0,"f":17825794}));
                                                __builder4.CloseComponent();
                                            }
                                        }, $rvWmZa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":6039553,"h":0,"f":17825794});
                                    }), $buNAqk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":6039553,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }
                            }
                        }
                    }), $kbXFRd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":6039553,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $VgNcrg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":6039553,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21480876033)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12890941441)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890941441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12890941441)
            
            //--TRIMMABLE-BOUNDARY-START(12890941441)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12890941441)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(68725516289)
                this.JavaScript = null;
                //--TRIMMABLE-BOUNDARY-END(68725516289)
                
                //--TRIMMABLE-BOUNDARY-START(111675189249)
                this.ViewModel = null;
                //--TRIMMABLE-BOUNDARY-END(111675189249)
                
                //--TRIMMABLE-BOUNDARY-START(85905385473)
                this.seq = new ($.$$.SCG.Dictionary$$$($.$fPer.LCFCDC.DateRange, $.$$.S.Int32))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(85905385473)
                
            }
            static $h = 6039553;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$IhzR.LCIDLV.LoggerDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77315450881),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51545647105,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 6039553,
      "h": 77315450881,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77315450881),
//--TRIMMABLE-BOUNDARY-START(68725516289),
    {
      "p": 64509610,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42955712513,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94495320065,
        "f": 83886081
      },
      "n": "JavaScript",
      "d": 6039553,
      "h": 68725516289,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68725516289),
//--TRIMMABLE-BOUNDARY-START(111675189249),
    {
      "p": 5974017,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60135581697,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103085254657,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 6039553,
      "h": 111675189249,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111675189249)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107380221953),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 6039553,
      "h": 107380221953,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107380221953),
//--TRIMMABLE-BOUNDARY-START(64430548993),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 6039553,
      "h": 64430548993,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64430548993),
//--TRIMMABLE-BOUNDARY-START(17185908737),
    {
      "r": 178454529,
      "n": "BeginReadLogs",
      "d": 6039553,
      "h": 17185908737,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(17185908737),
//--TRIMMABLE-BOUNDARY-START(30070810625),
    {
      "r": 178454529,
      "n": "ExportCSV",
      "d": 6039553,
      "h": 30070810625,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(30070810625),
//--TRIMMABLE-BOUNDARY-START(73020483585),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 6039553,
      "h": 73020483585,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(73020483585),
//--TRIMMABLE-BOUNDARY-START(21480876033),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 6039553,
      "h": 21480876033,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21480876033)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34365777921),
    {
      "t": 53512534,
      "n": "fileManager",
      "d": 6039553,
      "h": 34365777921,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34365777921),
//--TRIMMABLE-BOUNDARY-START(85905385473),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCDC.DateRange, $.$$.S.Int32).$h,
      "n": "seq",
      "d": 6039553,
      "h": 85905385473,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85905385473),
//--TRIMMABLE-BOUNDARY-START(81610418177),
    {
      "t": 262145,
      "n": "readingLogs",
      "d": 6039553,
      "h": 81610418177,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81610418177),
//--TRIMMABLE-BOUNDARY-START(25775843329),
    {
      "t": 1310721,
      "n": "csv",
      "d": 6039553,
      "h": 25775843329,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25775843329)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12890941441),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 6039553,
      "h": 12890941441,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12890941441)
  ],
  "h": 6039553
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Logger.Views.LoggerDeviceDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Logger${separator}Views${separator}LoggerDeviceDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6039553)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(10241)
