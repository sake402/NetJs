
//--TRIMMABLE-BOUNDARY-START(42773)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej, $tKtD) {
    "use strict";
    let _;
    let $ODXwne;
    let $AumIrc;
    let $qQGXSc;
    let $CJAQwb;
    let $DOOsmb;
    let $mcACee;
    let $ICTUIe;
    let $WIXtci;
    let $HwcACc;
    let $RhZmZd;
    let $hIZCej;
    let $fdHGVc;
    let $aDsvzf;
    let $MPeFsc;
    let $ntriTe;
    let $QIKdHb;
    let $oCJQRa;
    let $kClrmg;
    let $dtKFWe;
    let $fPcrQa;
    let $Pwkarg;
    let $czbSBh;
    let $dntDfd;
    let $xLDaqh;
    let $EoFMTh;
    let $qqCCPh;
    let $dTnPwj;
    let $hFZDHk;
    let $feECgh;
    let $gFVQhi;
    let $Zbnazh;
    let $ovVinh;
    let $HnzUnd;
    let $FHzIZf;
    let $edeRLh;
    let $DaqsUf;
    let $zztsCc;
    let $XUiMwc;
    let $eFnxLh;
    let $wDZolh;
    let $KLtwVd;
    let $seVvnk;
    let $VdxNca;
    let $GVzUyg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.MultiVoltmeter", 
    {
  "h": 42773,
  "f": "LivingThing.Core.IOT.Devices.MultiVoltmeter",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.MultiVoltmeter",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.MultiVoltmeter",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5NdWx0aVZvbHRtZXRlci5TbWFydE11bHRpVm9sdG1ldGVyRGV2aWNlIjogew0KICAgICAgIkNhdGVnb3JpZXMiOiBbICJTbWFydCBIb21lIiwgIkRJWSIgXSwNCiAgICAgICJOYW1lIjogIlNtYXJ0IE11bHRpVm9sdG1ldGVyIiwNCiAgICAgICJEZXNjcmlwdGlvbiI6ICJNZWFzdXJlIEFuYWxvZyBWb2x0YWdlcywgc2VuZCB0byBjbG91ZCwgY3JlYXRlIHRocmVzaG9sZCBhbGFybS4iLA0KICAgICAgIkljb24iOiB7ICJOYW1lIjogIm1kaSBtZGktY3VycmVudC1kYyIgfSwNCiAgICAgICJUaGVtZUNvbG9yIjogIiNmZjc1YTAiLA0KICAgICAgIkZsYWdzIjogIlB1Ymxpc2hlZCIsDQogICAgICAiU2VjdXJpdGllcyI6ICJDaGFsbGVuZ2VIYW5kU2hha2VBdXRoZW50aWNhdGlvblByb3RvY29sLEFkdmFuY2VkRW5jcnlwdGlvblN0YW5kYXJkLEVsbGlwdGljQ3VydmVGaXJtd2FyZVVwZGF0ZVNpZ25pbmciDQogICAgfQ0KICB9DQp9"
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2729749)
        $asm.$cls(`$ASam.LCIDMS.ChannelVisuaization`, ($self) => class ChannelVisuaization extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(68722206485)
            /*string*/ Label = null;
            //--TRIMMABLE-BOUNDARY-END(68722206485)
            
            //--TRIMMABLE-BOUNDARY-START(25772533525)
            /*string*/ Converter = null;
            //--TRIMMABLE-BOUNDARY-END(25772533525)
            
            //--TRIMMABLE-BOUNDARY-START(107376912149)
            /*string*/ Unit = null;
            //--TRIMMABLE-BOUNDARY-END(107376912149)
            
            //--TRIMMABLE-BOUNDARY-START(64427239189)
            /*string*/ Icon = null;
            //--TRIMMABLE-BOUNDARY-END(64427239189)
            
            //--TRIMMABLE-BOUNDARY-START(21477566229)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477566229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477566229)
            
            //--TRIMMABLE-BOUNDARY-START(21477566229)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21477566229)
            
            static $h = 2729749;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68722206485),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542337301,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94492010261,
        "f": 83886081
      },
      "n": "Label",
      "d": 2729749,
      "h": 68722206485,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68722206485),
//--TRIMMABLE-BOUNDARY-START(25772533525),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362468117,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77312141077,
        "f": 83886081
      },
      "n": "Converter",
      "d": 2729749,
      "h": 25772533525,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772533525),
//--TRIMMABLE-BOUNDARY-START(107376912149),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132271893,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103081944853,
        "f": 83886081
      },
      "n": "Unit",
      "d": 2729749,
      "h": 107376912149,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107376912149),
//--TRIMMABLE-BOUNDARY-START(64427239189),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952402709,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85902075669,
        "f": 83886081
      },
      "n": "Icon",
      "d": 2729749,
      "h": 64427239189,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 21,
              "t": 47614294
            },
            {
              "n": "OptionsReader",
              "v": 46565718,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64427239189)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477566229),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2729749,
      "h": 21477566229,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477566229)
  ],
  "h": 2729749
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.ChannelVisuaization`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Settings${separator}ChannelVisuaization`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2729749)
        
        

        //--TRIMMABLE-BOUNDARY-START(2008853)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModelCustomAttributesProvider`, ($self) => class SmartMultiVoltmeterDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296976149)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296976149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296976149)
            
            static $h = 2008853;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296976149),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2008853,
      "h": 4296976149,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296976149)
  ],
  "h": 2008853
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2008853)
        
        

        //--TRIMMABLE-BOUNDARY-START(1222421)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterDeviceModelCustomAttributesProvider`, ($self) => class SmartMultiVoltmeterDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296189717)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296189717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296189717)
            
            static $h = 1222421;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296189717),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1222421,
      "h": 4296189717,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296189717)
  ],
  "h": 1222421
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1222421)
        
        

        //--TRIMMABLE-BOUNDARY-START(370453)
        $asm.$cls(`$ASam.LCIDM.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295337749)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295337749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295337749)
            
            static $h = 370453;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295337749),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 370453,
      "h": 4295337749,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295337749)
  ],
  "h": 370453
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(370453)
        
        

        //--TRIMMABLE-BOUNDARY-START(1484565)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class SmartMultiVoltmeterDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296451861)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296451861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$ASam.LCIDMM.SmartMultiVoltmeterADCModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296451861)
            
            static $h = 1484565;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296451861),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1484565,
      "h": 4296451861,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296451861)
  ],
  "h": 1484565
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1484565)
        
        

        //--TRIMMABLE-BOUNDARY-START(2270997)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterServiceModelCustomAttributesProvider`, ($self) => class SmartMultiVoltmeterServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297238293)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297238293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297238293)
            
            static $h = 2270997;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297238293),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2270997,
      "h": 4297238293,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297238293)
  ],
  "h": 2270997
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2270997)
        
        

        //--TRIMMABLE-BOUNDARY-START(1746709)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModelCustomAttributesProvider`, ($self) => class SmartMultiVoltmeterDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296714005)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296714005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296714005)
            
            static $h = 1746709;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296714005),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1746709,
      "h": 4296714005,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296714005)
  ],
  "h": 1746709
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1746709)
        
        

        //--TRIMMABLE-BOUNDARY-START(1615637)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class SmartMultiVoltmeterDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591550229)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591550229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ICTUIe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1615637,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591550229)
            
            //--TRIMMABLE-BOUNDARY-START(4296582933)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296582933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296582933)
            
            //--TRIMMABLE-BOUNDARY-START(4296582933)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296582933)
            
            static $h = 1615637;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591550229),
    {
      "r": 65537,
      "n": "Register",
      "d": 1615637,
      "h": 8591550229,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591550229)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296582933),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1615637,
      "h": 4296582933,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296582933)
  ],
  "h": 1615637
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1615637)
        
        

        //--TRIMMABLE-BOUNDARY-START(2991893)
        $asm.$cls(`$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class SmartMultiVoltmeterDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297959189)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297959189)
            
            //--TRIMMABLE-BOUNDARY-START(8592926485)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592926485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Calibrations", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Key = "vc";
                            $i3.Order = (12);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $AumIrc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2991893,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $qQGXSc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2991893,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592926485)
            
            static $h = 2991893;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592926485),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2991893,
      "h": 8592926485,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592926485)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297959189),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2991893,
      "h": 4297959189,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297959189)
  ],
  "h": 2991893
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Settings${separator}SmartMultiVoltmeterDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2991893)
        
        

        //--TRIMMABLE-BOUNDARY-START(304917)
        $asm.$cls(`$ASam.LCIDM.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295272213)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295272213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ASam.LCIDMM.SmartMultiVoltmeterADCModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ASam.LCIDMM.SmartMultiVoltmeterADCModelCustomAttributesProvider, $.$ASam.LCIDMM.SmartMultiVoltmeterADCModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelCustomAttributesProvider, $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModelCustomAttributesProvider, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModelCustomAttributesProvider, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModelCustomAttributesProvider, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModelCustomAttributesProvider, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModelCustomAttributesProvider, $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ASam.LCIDMS.SmartMultiVoltmeterBroadcastPeerMessages.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ASam.LCIDMS.SmartMultiVoltmeterBroadcastPeerMessagesCustomAttributesProvider, $.$ASam.LCIDMS.SmartMultiVoltmeterBroadcastPeerMessagesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettingsCustomAttributesProvider, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettingsCustomAttributesProvider, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295272213)
            
            static $h = 304917;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295272213),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 304917,
      "h": 4295272213,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295272213)
  ],
  "h": 304917
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(304917)
        
        

        //--TRIMMABLE-BOUNDARY-START(2139925)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class SmartMultiVoltmeterDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592074517)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592074517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $HwcACc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2139925,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592074517)
            
            //--TRIMMABLE-BOUNDARY-START(4297107221)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297107221);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297107221)
            
            //--TRIMMABLE-BOUNDARY-START(4297107221)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297107221)
            
            static $h = 2139925;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592074517),
    {
      "r": 65537,
      "n": "Register",
      "d": 2139925,
      "h": 8592074517,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592074517)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297107221),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2139925,
      "h": 4297107221,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297107221)
  ],
  "h": 2139925
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2139925)
        
        

        //--TRIMMABLE-BOUNDARY-START(1877781)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModelTypeDescriptorBuilder`, ($self) => class SmartMultiVoltmeterDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591812373)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591812373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ntriTe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1877781,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591812373)
            
            //--TRIMMABLE-BOUNDARY-START(4296845077)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296845077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296845077)
            
            //--TRIMMABLE-BOUNDARY-START(4296845077)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296845077)
            
            static $h = 1877781;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591812373),
    {
      "r": 65537,
      "n": "Register",
      "d": 1877781,
      "h": 8591812373,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591812373)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296845077),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1877781,
      "h": 4296845077,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296845077)
  ],
  "h": 1877781
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1877781)
        
        

        //--TRIMMABLE-BOUNDARY-START(173845)
        $asm.$cls(`$ASam.LCIDM._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295141141)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295141141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$ASam.LCIDM.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295141141)
            
            static $h = 173845;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295141141),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 173845,
      "h": 4295141141,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295141141)
  ],
  "h": 173845
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(173845)
        
        

        //--TRIMMABLE-BOUNDARY-START(2860821)
        $asm.$cls(`$ASam.LCIDMS.SmartMultiVoltmeterBroadcastPeerMessagesCustomAttributesProvider`, ($self) => class SmartMultiVoltmeterBroadcastPeerMessagesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297828117)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297828117)
            
            //--TRIMMABLE-BOUNDARY-START(8592795413)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592795413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ASam.LCIDMS.SmartMultiVoltmeterBroadcastPeerMessagesCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ASam.LCIDMS.SmartMultiVoltmeterBroadcastPeerMessagesCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $hIZCej ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2860821,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $fdHGVc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2860821,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592795413)
            
            static $h = 2860821;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592795413),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2860821,
      "h": 8592795413,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592795413)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297828117),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2860821,
      "h": 4297828117,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297828117)
  ],
  "h": 2860821
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterBroadcastPeerMessagesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Settings${separator}SmartMultiVoltmeterBroadcastPeerMessagesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2860821)
        
        

        //--TRIMMABLE-BOUNDARY-START(960277)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelCustomAttributesProvider`, ($self) => class SmartMultiVoltmeterCalibrateCommandModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295927573)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295927573)
            
            //--TRIMMABLE-BOUNDARY-START(8590894869)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590894869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Channel", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            $i3.ConvertType = ($.$$.S.Byte.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Value", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (4);
                            $i4.ConvertType = ($.$$.S.Single.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $aDsvzf ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":960277,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $MPeFsc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":960277,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590894869)
            
            static $h = 960277;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590894869),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 960277,
      "h": 8590894869,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590894869)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295927573),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 960277,
      "h": 4295927573,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295927573)
  ],
  "h": 960277
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterCalibrateCommandModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterCalibrateCommandModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(960277)
        
        

        //--TRIMMABLE-BOUNDARY-START(829205)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterADCModelTypeDescriptorBuilder`, ($self) => class SmartMultiVoltmeterADCModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590763797)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590763797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ASam.LCIDMM.SmartMultiVoltmeterADCModelTypeDescriptor()
                        const $t1 = $.$ASam.LCIDMM.SmartMultiVoltmeterADCModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterADCModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $dntDfd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":829205,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ASam.LCIDMM.SmartMultiVoltmeterADCModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590763797)
            
            //--TRIMMABLE-BOUNDARY-START(4295796501)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295796501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295796501)
            
            //--TRIMMABLE-BOUNDARY-START(4295796501)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295796501)
            
            static $h = 829205;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590763797),
    {
      "r": 65537,
      "n": "Register",
      "d": 829205,
      "h": 8590763797,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590763797)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295796501),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 829205,
      "h": 4295796501,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295796501)
  ],
  "h": 829205
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterADCModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterADCModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(829205)
        
        

        //--TRIMMABLE-BOUNDARY-START(3122965)
        $asm.$cls(`$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593057557)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593057557);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $dtKFWe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3122965,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593057557)
            
            //--TRIMMABLE-BOUNDARY-START(4298090261)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298090261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298090261)
            
            //--TRIMMABLE-BOUNDARY-START(4298090261)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298090261)
            
            static $h = 3122965;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593057557),
    {
      "r": 65537,
      "n": "Register",
      "d": 3122965,
      "h": 8593057557,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593057557)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298090261),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3122965,
      "h": 4298090261,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298090261)
  ],
  "h": 3122965
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Settings${separator}SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3122965)
        
        

        //--TRIMMABLE-BOUNDARY-START(3385109)
        $asm.$cls(`$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettingsTypeDescriptorBuilder`, ($self) => class SmartMultiVoltmeterDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593319701)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593319701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettingsTypeDescriptor()
                        const $t1 = $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $dTnPwj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3385109,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593319701)
            
            //--TRIMMABLE-BOUNDARY-START(4298352405)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298352405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298352405)
            
            //--TRIMMABLE-BOUNDARY-START(4298352405)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298352405)
            
            static $h = 3385109;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593319701),
    {
      "r": 65537,
      "n": "Register",
      "d": 3385109,
      "h": 8593319701,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593319701)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298352405),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3385109,
      "h": 4298352405,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298352405)
  ],
  "h": 3385109
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Settings${separator}SmartMultiVoltmeterDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3385109)
        
        

        //--TRIMMABLE-BOUNDARY-START(2402069)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterServiceModelTypeDescriptorBuilder`, ($self) => class SmartMultiVoltmeterServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592336661)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592336661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModelTypeDescriptor()
                        const $t1 = $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $oCJQRa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2402069,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592336661)
            
            //--TRIMMABLE-BOUNDARY-START(4297369365)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297369365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297369365)
            
            //--TRIMMABLE-BOUNDARY-START(4297369365)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297369365)
            
            static $h = 2402069;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592336661),
    {
      "r": 65537,
      "n": "Register",
      "d": 2402069,
      "h": 8592336661,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592336661)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297369365),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2402069,
      "h": 4297369365,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297369365)
  ],
  "h": 2402069
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2402069)
        
        

        //--TRIMMABLE-BOUNDARY-START(3254037)
        $asm.$cls(`$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettingsCustomAttributesProvider`, ($self) => class SmartMultiVoltmeterDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298221333)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298221333);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298221333)
            
            static $h = 3254037;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298221333),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3254037,
      "h": 4298221333,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298221333)
  ],
  "h": 3254037
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Settings${separator}SmartMultiVoltmeterDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3254037)
        
        

        //--TRIMMABLE-BOUNDARY-START(3778325)
        $asm.$cls(`$ASam.LCIDM.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298745621)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298745621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ASam.LCIDMM.SmartMultiVoltmeterADCModelTypeDescriptorBuilder.Register();
                $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelTypeDescriptorBuilder.Register();
                $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModelTypeDescriptorBuilder.Register();
                $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModelTypeDescriptorBuilder.Register();
                $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298745621)
            
            static $h = 3778325;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298745621),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3778325,
      "h": 4298745621,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298745621)
  ],
  "h": 3778325
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3778325)
        
        

        //--TRIMMABLE-BOUNDARY-START(1353493)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterDeviceModelTypeDescriptorBuilder`, ($self) => class SmartMultiVoltmeterDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591288085)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591288085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModelTypeDescriptor()
                        const $t1 = $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Zbnazh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1353493,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591288085)
            
            //--TRIMMABLE-BOUNDARY-START(4296320789)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296320789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296320789)
            
            //--TRIMMABLE-BOUNDARY-START(4296320789)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296320789)
            
            static $h = 1353493;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591288085),
    {
      "r": 65537,
      "n": "Register",
      "d": 1353493,
      "h": 8591288085,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591288085)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296320789),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1353493,
      "h": 4296320789,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296320789)
  ],
  "h": 1353493
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1353493)
        
        

        //--TRIMMABLE-BOUNDARY-START(1091349)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelTypeDescriptorBuilder`, ($self) => class SmartMultiVoltmeterCalibrateCommandModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591025941)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591025941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelTypeDescriptor()
                        const $t1 = $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterCalibrateCommandModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $XUiMwc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1091349,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591025941)
            
            //--TRIMMABLE-BOUNDARY-START(4296058645)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296058645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296058645)
            
            //--TRIMMABLE-BOUNDARY-START(4296058645)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296058645)
            
            static $h = 1091349;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591025941),
    {
      "r": 65537,
      "n": "Register",
      "d": 1091349,
      "h": 8591025941,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591025941)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296058645),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1091349,
      "h": 4296058645,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296058645)
  ],
  "h": 1091349
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterCalibrateCommandModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterCalibrateCommandModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1091349)
        
        

        //--TRIMMABLE-BOUNDARY-START(698133)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterADCModelCustomAttributesProvider`, ($self) => class SmartMultiVoltmeterADCModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295665429)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295665429)
            
            //--TRIMMABLE-BOUNDARY-START(8590632725)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590632725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ASam.LCIDMM.SmartMultiVoltmeterADCModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Channels", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.ConvertType = ($.$$.S.Single.$type);
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Unit=V"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ASam.LCIDMM.SmartMultiVoltmeterADCModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $DaqsUf ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":698133,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $zztsCc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":698133,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590632725)
            
            static $h = 698133;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590632725),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 698133,
      "h": 8590632725,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590632725)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295665429),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 698133,
      "h": 4295665429,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295665429)
  ],
  "h": 698133
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterADCModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterADCModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(698133)
        
        

        //--TRIMMABLE-BOUNDARY-START(239381)
        $asm.$cls(`$ASam.LCIDM.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180108565)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180108565)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295206677)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295206677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295206677)
            
            //--TRIMMABLE-BOUNDARY-START(4295206677)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295206677)
            
            static $h = 239381;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180108565),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885141269,
        "f": 50331649
      },
      "n": "Paths",
      "d": 239381,
      "h": 17180108565,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180108565)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295206677),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 239381,
      "h": 4295206677,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295206677)
  ],
  "h": 239381
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(239381)
        
        

        //--TRIMMABLE-BOUNDARY-START(2664213)
        $asm.$cls(`$ASam.LCIDM.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592598805)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592598805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$ASam.LCIDM.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ASam.LCIDM.SmartMultiVoltmeterDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$ASam.LCIDM.SmartMultiVoltmeterDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$ASam.LCIDM.SmartMultiVoltmeterDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ASam.LCIDM.SmartMultiVoltmeterDeviceFamily, x);
                }, $CJAQwb ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":2664213,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ASam.LCIDM.SmartMultiVoltmeterDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $DOOsmb ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":2664213,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ASam.LCIDM.SmartMultiVoltmeterDeviceFamily, x);
                }, $mcACee ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":2664213,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice), $.$ASam.LCIDMPC.SmartMultiVoltmeterDeviceCommands, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice), $.$ASam.LCIDMV.SmartMultiVoltmeterViewRenderer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592598805)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ASam.LCIDM.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297631509)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297631509);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297631509)
            
            //--TRIMMABLE-BOUNDARY-START(4297631509)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297631509)
            
            static $h = 2664213;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592598805),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2664213,
      "h": 8592598805,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592598805)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297631509),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2664213,
      "h": 4297631509,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297631509)
  ],
  "h": 2664213
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2664213)
        
        

        //--TRIMMABLE-BOUNDARY-START(2467605)
        $asm.$cls(`$ASam.LCIDM.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17182336789)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$ASam.LCIDMV.SmartMultiVoltmeterDeviceDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$ASam.LCIDMV.SmartMultiVoltmeterDeviceDetails().$ctor$4();
                    }, $ODXwne ??= {"r":2752627,"n":"","d":2467605,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17182336789)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4297434901)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297434901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297434901)
            
            //--TRIMMABLE-BOUNDARY-START(4297434901)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297434901)
            
            static $h = 2467605;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182336789),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887369493,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 2467605,
      "h": 17182336789,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182336789)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297434901),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2467605,
      "h": 4297434901,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297434901)
  ],
  "h": 2467605
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2467605)
        
        

        //--TRIMMABLE-BOUNDARY-START(4106005)
        $asm.$cls(`$ASam.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299073301)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299073301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299073301)
            
            //--TRIMMABLE-BOUNDARY-START(4299073301)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299073301)
            
            static $h = 4106005;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299073301),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4106005,
      "h": 4299073301,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299073301)
  ],
  "h": 4106005,
  "a": [
    {
      "t": 4040469,
      "c": 4299007765
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4106005)
        
        

        //--TRIMMABLE-BOUNDARY-START(4040469)
        $asm.$cls(`$ASam.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299007765)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299007765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299007765)
            
            //--TRIMMABLE-BOUNDARY-START(4299007765)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299007765)
            
            static $h = 4040469;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299007765),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4040469,
      "h": 4299007765,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299007765)
  ],
  "h": 4040469
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4040469)
        
        

        //--TRIMMABLE-BOUNDARY-START(894741)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel`, ($self) => class SmartMultiVoltmeterCalibrateCommandModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(21475731221)
            /*int */ get Command()
            {
                return ((128 + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(21475731221)
            
            //--TRIMMABLE-BOUNDARY-START(17180763925)
            /*int*/ Channel = 0;
            //--TRIMMABLE-BOUNDARY-END(17180763925)
            
            //--TRIMMABLE-BOUNDARY-START(68720371477)
            /*double*/ Value = 0;
            //--TRIMMABLE-BOUNDARY-END(68720371477)
            
            //--TRIMMABLE-BOUNDARY-START(12885796629)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885796629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885796629)
            
            //--TRIMMABLE-BOUNDARY-START(12885796629)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885796629)
            
            static $h = 894741;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475731221),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655600405,
        "f": 50364417
      },
      "n": "Command",
      "d": 894741,
      "h": 21475731221,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475731221),
//--TRIMMABLE-BOUNDARY-START(17180763925),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065665813,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835469589,
        "f": 83886081
      },
      "n": "Channel",
      "d": 894741,
      "h": 17180763925,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180763925),
//--TRIMMABLE-BOUNDARY-START(68720371477),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245534997,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425404181,
        "f": 83886081
      },
      "n": "Value",
      "d": 894741,
      "h": 68720371477,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720371477)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885796629),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 894741,
      "h": 12885796629,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885796629)
  ],
  "h": 894741
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterCalibrateCommandModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterCalibrateCommandModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(894741)
        
        

        //--TRIMMABLE-BOUNDARY-START(632597)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterADCModel`, ($self) => class SmartMultiVoltmeterADCModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(12885534485)
            /*double[]*/ Channels = null;
            //--TRIMMABLE-BOUNDARY-END(12885534485)
            
            //--TRIMMABLE-BOUNDARY-START(8590567189)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590567189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590567189)
            
            //--TRIMMABLE-BOUNDARY-START(8590567189)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590567189)
            
            static $h = 632597;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885534485),
    {
      "p": $.$typeArray($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475469077,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065403669,
        "f": 83886081
      },
      "n": "Channels",
      "d": 632597,
      "h": 12885534485,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "Unit=V"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885534485)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590567189),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 632597,
      "h": 8590567189,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590567189)
  ],
  "h": 632597
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterADCModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterADCModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(632597)
        
        

        //--TRIMMABLE-BOUNDARY-START(2795285)
        $asm.$str(`$ASam.LCIDMS.SmartMultiVoltmeterBroadcastPeerMessages`, ($self) => class SmartMultiVoltmeterBroadcastPeerMessages extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Channels = 255;
            static ChannelOne = 1;
            static ChannelTwo = 2;
            static ChannelThree = 8;
            static ChannelFour = 16;
            static ChannelFive = 32;
            static ChannelSix = 64;
            static ChannelSeven = 128;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2795285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Channels": 255n,
                    "ChannelOne": 1n,
                    "ChannelTwo": 2n,
                    "ChannelThree": 8n,
                    "ChannelFour": 16n,
                    "ChannelFive": 32n,
                    "ChannelSix": 64n,
                    "ChannelSeven": 128n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297762581)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297762581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297762581)
            
            //--TRIMMABLE-BOUNDARY-START(4297762581)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297762581)
            
            static $h = 2795285;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21477631765),
    {
      "t": 2795285,
      "n": "Channels",
      "d": 2795285,
      "h": 21477631765,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477631765),
//--TRIMMABLE-BOUNDARY-START(17182664469),
    {
      "t": 2795285,
      "n": "ChannelOne",
      "d": 2795285,
      "h": 17182664469,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182664469),
//--TRIMMABLE-BOUNDARY-START(38657500949),
    {
      "t": 2795285,
      "n": "ChannelTwo",
      "d": 2795285,
      "h": 38657500949,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38657500949),
//--TRIMMABLE-BOUNDARY-START(34362533653),
    {
      "t": 2795285,
      "n": "ChannelThree",
      "d": 2795285,
      "h": 34362533653,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34362533653),
//--TRIMMABLE-BOUNDARY-START(12887697173),
    {
      "t": 2795285,
      "n": "ChannelFour",
      "d": 2795285,
      "h": 12887697173,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887697173),
//--TRIMMABLE-BOUNDARY-START(8592729877),
    {
      "t": 2795285,
      "n": "ChannelFive",
      "d": 2795285,
      "h": 8592729877,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592729877),
//--TRIMMABLE-BOUNDARY-START(30067566357),
    {
      "t": 2795285,
      "n": "ChannelSix",
      "d": 2795285,
      "h": 30067566357,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30067566357),
//--TRIMMABLE-BOUNDARY-START(25772599061),
    {
      "t": 2795285,
      "n": "ChannelSeven",
      "d": 2795285,
      "h": 25772599061,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772599061)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297762581),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2795285,
      "h": 4297762581,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297762581)
  ],
  "h": 2795285,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterBroadcastPeerMessages`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Settings${separator}SmartMultiVoltmeterBroadcastPeerMessages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2795285)
        
        

        //--TRIMMABLE-BOUNDARY-START(108309)
        $asm.$cls(`$ASam.LCIDM._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590042901)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590042901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590042901)
            
            //--TRIMMABLE-BOUNDARY-START(4295075605)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295075605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295075605)
            
            //--TRIMMABLE-BOUNDARY-START(4295075605)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295075605)
            
            static $h = 108309;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590042901),
    {
      "r": 65537,
      "n": "Execute",
      "d": 108309,
      "h": 8590042901,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590042901)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295075605),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 108309,
      "h": 4295075605,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295075605)
  ],
  "h": 108309
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(108309)
        
        

        //--TRIMMABLE-BOUNDARY-START(763669)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterADCModelTypeDescriptor`, ($self) => class SmartMultiVoltmeterADCModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterADCModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295730965)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295730965);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ASam.LCIDMM.SmartMultiVoltmeterADCModelTypeDescriptor.GenerateProperties($.$ASam.LCIDMM.SmartMultiVoltmeterADCModel, this, factory);
                    }, $xLDaqh ??= {"r":65537,"n":"","d":763669,"h":0,"f":17825794}), 0, "SmartMultiVoltmeterADCModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.MultiVoltmeter\\Models_SmartMultiVoltmeterADCModel_LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterADCModelTypeDescriptorBuilder.g.cs", "SmartMultiVoltmeterADCModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295730965)
            
            //--TRIMMABLE-BOUNDARY-START(12885665557)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885665557);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Channels"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ASam.LCIDMM.SmartMultiVoltmeterADCModel.$type, $.$discardRef(), "Channels", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Channels")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.Double), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Channels";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterADCModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ASam.LCIDMM.SmartMultiVoltmeterADCModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.Double), ($.$cast(target, $.$ASam.LCIDMM.SmartMultiVoltmeterADCModel)).Channels);
                        }, $EoFMTh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":763669,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ASam.LCIDMM.SmartMultiVoltmeterADCModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Channels = value.AsReference($.$typeArray($.$$.S.Double));
                        }, $qqCCPh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":763669,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885665557)
            
            //--TRIMMABLE-BOUNDARY-START(17180632853)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterADCModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180632853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _Channels = _target.Channels;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Channels"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.Double)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.Double), $.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.Double), $.$$.S.Double, property, $.$ref(() => _Channels, ($v) => _Channels = $v, $.$typeArray($.$$.S.Double))))
                    {
                        _target.Channels = _Channels;
                        if (_Channels !== null)
                        {
                            let $i6 = 0;
                            let $arr6 = _Channels;
                            while ($i6 < $arr6.length)
                            {
                                let item = $arr6[$i6++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.Double)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.Double), $.$$.S.Double, property, $.$ref(() => _Channels, ($v) => _Channels = $v, $.$typeArray($.$$.S.Double)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180632853)
            
            //--TRIMMABLE-BOUNDARY-START(8590698261)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterADCModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590698261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ASam.LCIDMM.SmartMultiVoltmeterADCModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ASam.LCIDMM.SmartMultiVoltmeterADCModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterADCModel)))
                {
                    /*var*/ let result = $.$ASam.LCIDMM.SmartMultiVoltmeterADCModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterADCModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ASam.LCIDMM.SmartMultiVoltmeterADCModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterADCModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590698261)
            
            static $h = 763669;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterADCModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885665557),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 763669,
      "h": 12885665557,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885665557),
//--TRIMMABLE-BOUNDARY-START(17180632853),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 632597,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 763669,
      "h": 17180632853,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180632853),
//--TRIMMABLE-BOUNDARY-START(8590698261),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 632597,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 763669,
      "h": 8590698261,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590698261)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295730965),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 763669,
      "h": 4295730965,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295730965)
  ],
  "h": 763669
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterADCModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterADCModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterADCModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(763669)
        
        

        //--TRIMMABLE-BOUNDARY-START(1025813)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelTypeDescriptor`, ($self) => class SmartMultiVoltmeterCalibrateCommandModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295993109)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295993109);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelTypeDescriptor.GenerateProperties($.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel, this, factory);
                    }, $eFnxLh ??= {"r":65537,"n":"","d":1025813,"h":0,"f":17825794}), 0, "SmartMultiVoltmeterCalibrateCommandModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.MultiVoltmeter\\Models_SmartMultiVoltmeterCalibrateCommandModel_LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterCalibrateCommandModelTypeDescriptorBuilder.g.cs", "SmartMultiVoltmeterCalibrateCommandModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295993109)
            
            //--TRIMMABLE-BOUNDARY-START(12885927701)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885927701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Channel"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel.$type, $.$discardRef(), "Channel", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Channel")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Channel";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterCalibrateCommandModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel)).Channel);
                        }, $wDZolh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1025813,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Channel = value.AsInt();
                        }, $KLtwVd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1025813,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Value"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel.$type, $.$discardRef(), "Value", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Value")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Value";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterCalibrateCommandModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel)).Value);
                        }, $seVvnk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1025813,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Value = value.AsDouble();
                        }, $VdxNca ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1025813,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Command";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterCalibrateCommandModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel)).Command);
                        }, $GVzUyg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1025813,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885927701)
            
            //--TRIMMABLE-BOUNDARY-START(17180894997)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterCalibrateCommandModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180894997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Channel = _target.Channel;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Channel"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Channel, ($v) => _Channel = $v, $.$$.S.Int32)))
                    {
                        _target.Channel = _Channel;
                    }
                }
                {
                    /*var*/ let _Value = _target.Value;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Value"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Value, ($v) => _Value = $v, $.$$.S.Double)))
                    {
                        _target.Value = _Value;
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180894997)
            
            //--TRIMMABLE-BOUNDARY-START(8590960405)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterCalibrateCommandModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590960405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel)))
                {
                    /*var*/ let result = $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590960405)
            
            static $h = 1025813;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885927701),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1025813,
      "h": 12885927701,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885927701),
//--TRIMMABLE-BOUNDARY-START(17180894997),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 894741,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1025813,
      "h": 17180894997,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180894997),
//--TRIMMABLE-BOUNDARY-START(8590960405),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 894741,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1025813,
      "h": 8590960405,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590960405)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295993109),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1025813,
      "h": 4295993109,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295993109)
  ],
  "h": 1025813
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterCalibrateCommandModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterCalibrateCommandModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1025813)
        
        

        //--TRIMMABLE-BOUNDARY-START(1943317)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel`, ($self) => class SmartMultiVoltmeterDeviceSendDataModel extends $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296910613)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296910613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296910613)
            
            //--TRIMMABLE-BOUNDARY-START(4296910613)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296910613)
            
            static $h = 1943317;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296910613),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1943317,
      "h": 4296910613,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296910613)
  ],
  "h": 1943317
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1943317)
        
        

        //--TRIMMABLE-BOUNDARY-START(2598677)
        $asm.$cls(`$ASam.LCIDMPCV.SmartMultiVoltmeterCalibrateCommand`, ($self) => class SmartMultiVoltmeterCalibrateCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297565973)
            $ctor$6()
            {
                super.$ctor$5("Calibrate", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297565973);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297565973)
            
            //--TRIMMABLE-BOUNDARY-START(17182467861)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-cogs"/*MaterialDesignIconNames.Cogs*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17182467861)
            
            //--TRIMMABLE-BOUNDARY-START(4297565973)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4297565973)
            
            static $h = 2598677;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$ASam.LCIDMM.SmartMultiVoltmeterCalibrateCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182467861),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887500565,
        "f": 50364417
      },
      "n": "Icon",
      "d": 2598677,
      "h": 17182467861,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17182467861)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297565973),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2598677,
      "h": 4297565973,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297565973)
  ],
  "h": 2598677
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Protocol.Commands.Variants.SmartMultiVoltmeterCalibrateCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Protocol${separator}Commands${separator}Variants${separator}SmartMultiVoltmeterCalibrateCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2598677)
        
        

        //--TRIMMABLE-BOUNDARY-START(2074389)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModelTypeDescriptor`, ($self) => class SmartMultiVoltmeterDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297041685)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297041685);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModelTypeDescriptor.GenerateProperties($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, this, factory);
                    }, $RhZmZd ??= {"r":65537,"n":"","d":2074389,"h":0,"f":17825794}), 0, "SmartMultiVoltmeterDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.MultiVoltmeter\\Models_SmartMultiVoltmeterDeviceSendDataModel_LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceSendDataModelTypeDescriptorBuilder.g.cs", "SmartMultiVoltmeterDeviceSendDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297041685)
            
            //--TRIMMABLE-BOUNDARY-START(12886976277)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886976277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886976277)
            
            //--TRIMMABLE-BOUNDARY-START(17181943573)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181943573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceSendDataModel?*/ let targetBase = _target;
                $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181943573)
            
            //--TRIMMABLE-BOUNDARY-START(8592008981)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592008981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592008981)
            
            static $h = 2074389;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886976277),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2074389,
      "h": 12886976277,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886976277),
//--TRIMMABLE-BOUNDARY-START(17181943573),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1943317,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2074389,
      "h": 17181943573,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181943573),
//--TRIMMABLE-BOUNDARY-START(8592008981),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1943317,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2074389,
      "h": 8592008981,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592008981)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297041685),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2074389,
      "h": 4297041685,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297041685)
  ],
  "h": 2074389
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2074389)
        
        

        //--TRIMMABLE-BOUNDARY-START(1419029)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel`, ($self) => class SmartMultiVoltmeterDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$ASam.LCIDMM.SmartMultiVoltmeterADCModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8591353621)
            /*double */ Evaluate(/*string*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591353621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    /*var*/ let interpreter = new $.$HnZw.D.Interpreter().$ctor$1();
                    const $t1 = this.Status;
                    const $t2 = this.Status;
                    const $t3 = this.Status;
                    const $t4 = this.Status;
                    return interpreter.Eval$2($.$$.S.Double, expression, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$HnZw.D.Parameter), [ new $.$HnZw.D.Parameter().$ctor$2("a0", $.$box($.$$.S.Int32.op_GreaterThan($.$ifnn($t1, ($t) => $t.Channels.length), 0) ? $.$$.System.Array.$ReadT1.call(this.Status.Channels, 0) : 0, $.$$.S.Double)), new $.$HnZw.D.Parameter().$ctor$2("a1", $.$box($.$$.S.Int32.op_GreaterThan($.$ifnn($t2, ($t) => $t.Channels.length), 1) ? $.$$.System.Array.$ReadT1.call(this.Status.Channels, 1) : 0, $.$$.S.Double)), new $.$HnZw.D.Parameter().$ctor$2("a2", $.$box($.$$.S.Int32.op_GreaterThan($.$ifnn($t3, ($t) => $t.Channels.length), 2) ? $.$$.System.Array.$ReadT1.call(this.Status.Channels, 2) : 0, $.$$.S.Double)), new $.$HnZw.D.Parameter().$ctor$2("a3", $.$box($.$$.S.Int32.op_GreaterThan($.$ifnn($t4, ($t) => $t.Channels.length), 3) ? $.$$.System.Array.$ReadT1.call(this.Status.Channels, 3) : 0, $.$$.S.Double)) ], null, null));
                }
                catch($e)
                {
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(8591353621)
            
            //--TRIMMABLE-BOUNDARY-START(4296386325)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296386325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296386325)
            
            //--TRIMMABLE-BOUNDARY-START(4296386325)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296386325)
            
            static $h = 1419029;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$ASam.LCIDMM.SmartMultiVoltmeterADCModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591353621),
    {
      "r": 1179649,
      "p": [
        {
          "n": "expression",
          "p": 1310721
        }
      ],
      "n": "Evaluate",
      "d": 1419029,
      "h": 8591353621,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591353621)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296386325),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1419029,
      "h": 4296386325,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296386325)
  ],
  "h": 1419029
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1419029)
        
        

        //--TRIMMABLE-BOUNDARY-START(1550101)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModelTypeDescriptor`, ($self) => class SmartMultiVoltmeterDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296517397)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296517397);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, this, factory);
                    }, $WIXtci ??= {"r":65537,"n":"","d":1550101,"h":0,"f":17825794}), 0, "SmartMultiVoltmeterDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.MultiVoltmeter\\Models_SmartMultiVoltmeterDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "SmartMultiVoltmeterDeviceReceivedDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296517397)
            
            //--TRIMMABLE-BOUNDARY-START(12886451989)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886451989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterADCModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886451989)
            
            //--TRIMMABLE-BOUNDARY-START(17181419285)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181419285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterADCModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterADCModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$ASam.LCIDMM.SmartMultiVoltmeterADCModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181419285)
            
            //--TRIMMABLE-BOUNDARY-START(8591484693)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591484693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591484693)
            
            static $h = 1550101;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886451989),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1550101,
      "h": 12886451989,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886451989),
//--TRIMMABLE-BOUNDARY-START(17181419285),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1419029,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1550101,
      "h": 17181419285,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181419285),
//--TRIMMABLE-BOUNDARY-START(8591484693),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1419029,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1550101,
      "h": 8591484693,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591484693)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296517397),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1550101,
      "h": 4296517397,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296517397)
  ],
  "h": 1550101
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1550101)
        
        

        //--TRIMMABLE-BOUNDARY-START(3450645)
        $asm.$cls(`$ASam.LCIDM.SmartMultiVoltmeterDataConverter`, ($self) => class SmartMultiVoltmeterDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298417941)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298417941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298417941)
            
            //--TRIMMABLE-BOUNDARY-START(4298417941)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298417941)
            
            static $h = 3450645;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298417941),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3450645,
      "h": 4298417941,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298417941)
  ],
  "h": 3450645
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.SmartMultiVoltmeterDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}SmartMultiVoltmeterDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3450645)
        
        

        $asm.$typeProxy("$ASam.LCIDMM.SmartMultiVoltmeterServiceModel", "$ASam.LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterServiceModel");
        $asm.$typeProxy("$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel", "$ASam.LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceModel");
        $asm.$typeProxy("$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings", "$ASam.LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceSettings");
        $asm.$typeProxy("$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings", "$ASam.LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceHardwareSettings");
        $asm.$typeProxy("$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler", "$ASam.LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterDeviceStatusHandler");
        $asm.$typeProxy("$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient", "$ASam.LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterDeviceHubClient");
        $asm.$typeProxy("$ASam.LCIDM.ISmartMultiVoltmeterRemoteService", "$ASam.LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterRemoteService");
        //--TRIMMABLE-BOUNDARY-START(1681173)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel`, ($self) => class SmartMultiVoltmeterDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296648469)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296648469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296648469)
            
            //--TRIMMABLE-BOUNDARY-START(4296648469)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296648469)
            
            static $h = 1681173;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296648469),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1681173,
      "h": 4296648469,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296648469)
  ],
  "h": 1681173
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1681173)
        
        

        //--TRIMMABLE-BOUNDARY-START(2205461)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterServiceModel`, ($self) => class SmartMultiVoltmeterServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297172757)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297172757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297172757)
            
            //--TRIMMABLE-BOUNDARY-START(4297172757)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4297172757)
            
            static $h = 2205461;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297172757),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 2205461,
      "h": 4297172757,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297172757)
  ],
  "h": 2205461
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2205461)
        
        

        //--TRIMMABLE-BOUNDARY-START(1156885)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel`, ($self) => class SmartMultiVoltmeterDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296124181)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296124181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296124181)
            
            //--TRIMMABLE-BOUNDARY-START(4296124181)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296124181)
            
            static $h = 1156885;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296124181),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1156885,
      "h": 4296124181,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296124181)
  ],
  "h": 1156885
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1156885)
        
        

        //--TRIMMABLE-BOUNDARY-START(567061)
        $asm.$cls(`$ASam.LCIDM.ISmartMultiVoltmeterRemoteService`, ($self) => class ISmartMultiVoltmeterRemoteService
        {
            static $h = 567061;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 567061
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}ISmartMultiVoltmeterRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(567061)
        
        

        //--TRIMMABLE-BOUNDARY-START(435989)
        $asm.$cls(`$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient`, ($self) => class ISmartMultiVoltmeterDeviceHubClient
        {
            static $h = 435989;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 435989
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}ISmartMultiVoltmeterDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(435989)
        
        

        //--TRIMMABLE-BOUNDARY-START(501525)
        $asm.$cls(`$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler`, ($self) => class ISmartMultiVoltmeterDeviceStatusHandler
        {
            static $h = 501525;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 501525
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}ISmartMultiVoltmeterDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(501525)
        
        

        //--TRIMMABLE-BOUNDARY-START(2926357)
        $asm.$cls(`$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings`, ($self) => class SmartMultiVoltmeterDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(12887828245)
            /*IOTDeviceInternalConfigurations<float>*/ Calibrations = null;
            //--TRIMMABLE-BOUNDARY-END(12887828245)
            
            //--TRIMMABLE-BOUNDARY-START(8592860949)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592860949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592860949)
            
            //--TRIMMABLE-BOUNDARY-START(8592860949)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8592860949)
            
            static $h = 2926357;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887828245),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$$.S.Single).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477762837,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30067697429,
        "f": 83886081
      },
      "n": "Calibrations",
      "d": 2926357,
      "h": 12887828245,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "vc",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 12,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12887828245)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592860949),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2926357,
      "h": 8592860949,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592860949)
  ],
  "h": 2926357
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Settings${separator}SmartMultiVoltmeterDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2926357)
        
        

        //--TRIMMABLE-BOUNDARY-START(3188501)
        $asm.$cls(`$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings`, ($self) => class SmartMultiVoltmeterDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $self, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(12888090389)
            /*ChannelVisuaization[]*/ Channels = null;
            //--TRIMMABLE-BOUNDARY-END(12888090389)
            
            //--TRIMMABLE-BOUNDARY-START(8593123093)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593123093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593123093)
            
            //--TRIMMABLE-BOUNDARY-START(8593123093)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8593123093)
            
            static $h = 3188501;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12888090389),
    {
      "p": $.$typeArray($.$ASam.LCIDMS.ChannelVisuaization).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478024981,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30067959573,
        "f": 83886081
      },
      "n": "Channels",
      "d": 3188501,
      "h": 12888090389,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12888090389)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593123093),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3188501,
      "h": 8593123093,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593123093)
  ],
  "h": 3188501
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Settings${separator}SmartMultiVoltmeterDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3188501)
        
        

        //--TRIMMABLE-BOUNDARY-START(3712789)
        $asm.$cls(`$ASam.LCIDM.SmartMultiVoltmeterDeviceModelDefinition`, ($self) => class SmartMultiVoltmeterDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4298680085)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298680085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298680085)
            
            //--TRIMMABLE-BOUNDARY-START(4298680085)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298680085)
            
            static $h = 3712789;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298680085),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3712789,
      "h": 4298680085,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298680085)
  ],
  "h": 3712789
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.SmartMultiVoltmeterDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}SmartMultiVoltmeterDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3712789)
        
        

        //--TRIMMABLE-BOUNDARY-START(1812245)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModelTypeDescriptor`, ($self) => class SmartMultiVoltmeterDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296779541)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296779541);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModelTypeDescriptor.GenerateProperties($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, this, factory);
                    }, $QIKdHb ??= {"r":65537,"n":"","d":1812245,"h":0,"f":17825794}), 0, "SmartMultiVoltmeterDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.MultiVoltmeter\\Models_SmartMultiVoltmeterDeviceScopeModel_LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceScopeModelTypeDescriptorBuilder.g.cs", "SmartMultiVoltmeterDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296779541)
            
            //--TRIMMABLE-BOUNDARY-START(12886714133)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886714133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886714133)
            
            //--TRIMMABLE-BOUNDARY-START(17181681429)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181681429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceSettings, LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceSendDataModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterDeviceStatusHandler, LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterDeviceHubClient, LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181681429)
            
            //--TRIMMABLE-BOUNDARY-START(8591746837)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591746837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel)))
                {
                    /*var*/ let result = $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591746837)
            
            static $h = 1812245;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886714133),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1812245,
      "h": 12886714133,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886714133),
//--TRIMMABLE-BOUNDARY-START(17181681429),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1681173,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1812245,
      "h": 17181681429,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181681429),
//--TRIMMABLE-BOUNDARY-START(8591746837),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1681173,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1812245,
      "h": 8591746837,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591746837)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296779541),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1812245,
      "h": 4296779541,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296779541)
  ],
  "h": 1812245
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1812245)
        
        

        //--TRIMMABLE-BOUNDARY-START(3057429)
        $asm.$cls(`$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptor`, ($self) => class SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298024725)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298024725);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, this, factory);
                    }, $fPcrQa ??= {"r":65537,"n":"","d":3057429,"h":0,"f":17825794}), 0, "SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.MultiVoltmeter\\Settings_SmartMultiVoltmeterDeviceHardwareSettings_LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298024725)
            
            //--TRIMMABLE-BOUNDARY-START(12887959317)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887959317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Calibrations"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings.$type, $.$discardRef(), "Calibrations", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Calibrations")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$$.S.Single), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Calibrations";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceHardwareSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$$.S.Single), ($.$cast(target, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings)).Calibrations);
                        }, $Pwkarg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3057429,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Calibrations = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$$.S.Single));
                        }, $czbSBh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3057429,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887959317)
            
            //--TRIMMABLE-BOUNDARY-START(17182926613)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182926613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceSettings, LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceSendDataModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterDeviceStatusHandler, LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterDeviceHubClient, LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).iSmartDeviceHardwareSettings));
                {
                    /*var*/ let _Calibrations = _target.Calibrations;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Calibrations"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$$.S.Single)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Calibrations, ($v) => _Calibrations = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$$.S.Single))))
                    {
                        _target.Calibrations = _Calibrations;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182926613)
            
            //--TRIMMABLE-BOUNDARY-START(8592992021)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592992021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592992021)
            
            static $h = 3057429;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887959317),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3057429,
      "h": 12887959317,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887959317),
//--TRIMMABLE-BOUNDARY-START(17182926613),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2926357,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3057429,
      "h": 17182926613,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182926613),
//--TRIMMABLE-BOUNDARY-START(8592992021),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2926357,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3057429,
      "h": 8592992021,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592992021)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298024725),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3057429,
      "h": 4298024725,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298024725)
  ],
  "h": 3057429
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Settings${separator}SmartMultiVoltmeterDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3057429)
        
        

        //--TRIMMABLE-BOUNDARY-START(2336533)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterServiceModelTypeDescriptor`, ($self) => class SmartMultiVoltmeterServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297303829)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297303829);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModelTypeDescriptor.GenerateProperties($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, this, factory);
                    }, $kClrmg ??= {"r":65537,"n":"","d":2336533,"h":0,"f":17825794}), 0, "SmartMultiVoltmeterServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.MultiVoltmeter\\Models_SmartMultiVoltmeterServiceModel_LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterServiceModelTypeDescriptorBuilder.g.cs", "SmartMultiVoltmeterServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297303829)
            
            //--TRIMMABLE-BOUNDARY-START(12887238421)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887238421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887238421)
            
            //--TRIMMABLE-BOUNDARY-START(17182205717)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182205717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceSettings, LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceSendDataModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterDeviceStatusHandler, LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterDeviceHubClient, LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182205717)
            
            //--TRIMMABLE-BOUNDARY-START(8592271125)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592271125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel)))
                {
                    /*var*/ let result = $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592271125)
            
            static $h = 2336533;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887238421),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2336533,
      "h": 12887238421,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887238421),
//--TRIMMABLE-BOUNDARY-START(17182205717),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2205461,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2336533,
      "h": 17182205717,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182205717),
//--TRIMMABLE-BOUNDARY-START(8592271125),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2205461,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2336533,
      "h": 8592271125,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592271125)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297303829),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2336533,
      "h": 4297303829,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297303829)
  ],
  "h": 2336533
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2336533)
        
        

        //--TRIMMABLE-BOUNDARY-START(3319573)
        $asm.$cls(`$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettingsTypeDescriptor`, ($self) => class SmartMultiVoltmeterDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298286869)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298286869);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettingsTypeDescriptor.GenerateProperties($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, this, factory);
                    }, $hFZDHk ??= {"r":65537,"n":"","d":3319573,"h":0,"f":17825794}), 0, "SmartMultiVoltmeterDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.MultiVoltmeter\\Settings_SmartMultiVoltmeterDeviceSettings_LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceSettingsTypeDescriptorBuilder.g.cs", "SmartMultiVoltmeterDeviceSettingsTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298286869)
            
            //--TRIMMABLE-BOUNDARY-START(12888221461)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888221461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Channels"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings.$type, $.$discardRef(), "Channels", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Channels")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$ASam.LCIDMS.ChannelVisuaization), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Channels";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$ASam.LCIDMS.ChannelVisuaization), ($.$cast(target, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings)).Channels);
                        }, $feECgh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3319573,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Channels = value.AsReference($.$typeArray($.$ASam.LCIDMS.ChannelVisuaization));
                        }, $gFVQhi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3319573,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888221461)
            
            //--TRIMMABLE-BOUNDARY-START(17183188757)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183188757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceSettings, LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceSendDataModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterDeviceStatusHandler, LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterDeviceHubClient, LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).iSmartDeviceSettings));
                {
                    /*var*/ let _Channels = _target.Channels;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Channels"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$ASam.LCIDMS.ChannelVisuaization)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$ASam.LCIDMS.ChannelVisuaization), $.$ASam.LCIDMS.ChannelVisuaization));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$ASam.LCIDMS.ChannelVisuaization), $.$ASam.LCIDMS.ChannelVisuaization, property, $.$ref(() => _Channels, ($v) => _Channels = $v, $.$typeArray($.$ASam.LCIDMS.ChannelVisuaization))))
                    {
                        _target.Channels = _Channels;
                        if (_Channels !== null)
                        {
                            let $i6 = 0;
                            let $arr6 = _Channels;
                            while ($i6 < $arr6.length)
                            {
                                let item = $arr6[$i6++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$ASam.LCIDMS.ChannelVisuaization)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$ASam.LCIDMS.ChannelVisuaization), $.$ASam.LCIDMS.ChannelVisuaization, property, $.$ref(() => _Channels, ($v) => _Channels = $v, $.$typeArray($.$ASam.LCIDMS.ChannelVisuaization)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183188757)
            
            //--TRIMMABLE-BOUNDARY-START(8593254165)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593254165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings)))
                {
                    /*var*/ let result = $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593254165)
            
            static $h = 3319573;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888221461),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3319573,
      "h": 12888221461,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888221461),
//--TRIMMABLE-BOUNDARY-START(17183188757),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3188501,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3319573,
      "h": 17183188757,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183188757),
//--TRIMMABLE-BOUNDARY-START(8593254165),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3188501,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3319573,
      "h": 8593254165,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593254165)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298286869),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3319573,
      "h": 4298286869,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298286869)
  ],
  "h": 3319573
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Settings${separator}SmartMultiVoltmeterDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3319573)
        
        

        //--TRIMMABLE-BOUNDARY-START(1287957)
        $asm.$cls(`$ASam.LCIDMM.SmartMultiVoltmeterDeviceModelTypeDescriptor`, ($self) => class SmartMultiVoltmeterDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296255253)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296255253);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModelTypeDescriptor.GenerateProperties($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, this, factory);
                    }, $ovVinh ??= {"r":65537,"n":"","d":1287957,"h":0,"f":17825794}), 0, "SmartMultiVoltmeterDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.MultiVoltmeter\\Models_SmartMultiVoltmeterDeviceModel_LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceModelTypeDescriptorBuilder.g.cs", "SmartMultiVoltmeterDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296255253)
            
            //--TRIMMABLE-BOUNDARY-START(12886189845)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886189845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886189845)
            
            //--TRIMMABLE-BOUNDARY-START(17181157141)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181157141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceSettings, LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceSendDataModel, LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterDeviceStatusHandler, LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterDeviceHubClient, LivingThing.Core.IOT.Devices.MultiVoltmeter.ISmartMultiVoltmeterRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181157141)
            
            //--TRIMMABLE-BOUNDARY-START(8591222549)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591222549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel)))
                {
                    /*var*/ let result = $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591222549)
            
            static $h = 1287957;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886189845),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1287957,
      "h": 12886189845,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886189845),
//--TRIMMABLE-BOUNDARY-START(17181157141),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1156885,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1287957,
      "h": 17181157141,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181157141),
//--TRIMMABLE-BOUNDARY-START(8591222549),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1156885,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1287957,
      "h": 8591222549,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591222549)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296255253),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1287957,
      "h": 4296255253,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296255253)
  ],
  "h": 1287957
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Models${separator}SmartMultiVoltmeterDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1287957)
        
        

        //--TRIMMABLE-BOUNDARY-START(3516181)
        $asm.$cls(`$ASam.LCIDM.SmartMultiVoltmeterDevice`, ($self) => class SmartMultiVoltmeterDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$ASam.LCIDMM.SmartMultiVoltmeterADCModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4298483477)
            $ctor$2(/*IIOTDeviceFamily<SmartMultiVoltmeterDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*SmartMultiVoltmeterDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298483477);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298483477)
            
            //--TRIMMABLE-BOUNDARY-START(8593450773)
            /*string? */ Channel(/*ChannelVisuaization*/ channel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593450773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceReceivedDataModel?*/ let __ca1__;
                return _ = ((__ca1__ = this.Received) !== null ? $.$$.S.Double.ToString.call(__ca1__.Evaluate(channel.Converter)) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(8593450773)
            
            //--TRIMMABLE-BOUNDARY-START(21478352661)
            /*string? */ get StatusText()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183385365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterDeviceReceivedDataModel?*/ let __ca2__;
                /*LivingThing.Core.IOT.Devices.MultiVoltmeter.Models.SmartMultiVoltmeterADCModel?*/ let __ca3__;
                /*double[]*/ let __ca4__;
                /*var*/ let s = ((__ca2__ = this.Received) !== null ? ((__ca3__ = __ca2__.Status) !== null ? ((__ca4__ = __ca3__.Channels) !== null ? $.$$.S.Double.ToString$3.call($.$$.System.Array.$ReadT1.call(__ca4__, 0), "0.##") : null) : null) : null);
                if (s === null)
                {
                    return null;
                }
                return $.$strNN(s) + "V";
            }
            //--TRIMMABLE-BOUNDARY-END(21478352661)
            
            static $h = 3516181;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice, $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$ASam.LCIDMM.SmartMultiVoltmeterADCModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21478352661),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183385365,
        "f": 50364417
      },
      "n": "StatusText",
      "d": 3516181,
      "h": 21478352661,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21478352661)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593450773),
    {
      "r": 1310721,
      "p": [
        {
          "n": "channel",
          "p": 2729749
        }
      ],
      "n": "Channel",
      "d": 3516181,
      "h": 8593450773,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593450773)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298483477),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 1156885
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3516181,
      "h": 4298483477,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298483477)
  ],
  "h": 3516181
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.SmartMultiVoltmeterDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}SmartMultiVoltmeterDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3516181)
        
        

        //--TRIMMABLE-BOUNDARY-START(3581717)
        $asm.$cls(`$ASam.LCIDM.SmartMultiVoltmeterDeviceDefinition`, ($self) => class SmartMultiVoltmeterDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice, $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$ASam.LCIDMM.SmartMultiVoltmeterADCModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298549013)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298549013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298549013)
            
            //--TRIMMABLE-BOUNDARY-START(4298549013)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298549013)
            
            static $h = 3581717;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice, $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$ASam.LCIDMM.SmartMultiVoltmeterADCModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298549013),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3581717,
      "h": 4298549013,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298549013)
  ],
  "h": 3581717
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.SmartMultiVoltmeterDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}SmartMultiVoltmeterDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3581717)
        
        

        //--TRIMMABLE-BOUNDARY-START(3647253)
        $asm.$cls(`$ASam.LCIDM.SmartMultiVoltmeterDeviceFamily`, ($self) => class SmartMultiVoltmeterDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice, $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4298614549)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<SmartMultiVoltmeterDeviceReceivedDataModel, SmartMultiVoltmeterDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<SmartMultiVoltmeterDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298614549);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298614549)
            
            //--TRIMMABLE-BOUNDARY-START(8593581845)
            /*Type */ get DeviceBroadcastSendMessageEnumType()
            {
                return $.$ASam.LCIDMS.SmartMultiVoltmeterBroadcastPeerMessages.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8593581845)
            
            //--TRIMMABLE-BOUNDARY-START(30068418325)
            /*string */ get Name()
            {
                return "MultiVoltmeter";
            }
            //--TRIMMABLE-BOUNDARY-END(30068418325)
            
            static $h = 3647253;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice, $.$ASam.LCIDMM.SmartMultiVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceModel, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceStatusHandler, $.$ASam.LCIDM.ISmartMultiVoltmeterDeviceHubClient, $.$ASam.LCIDM.ISmartMultiVoltmeterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8593581845),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183516437,
        "f": 50364417
      },
      "n": "DeviceBroadcastSendMessageEnumType",
      "d": 3647253,
      "h": 8593581845,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8593581845),
//--TRIMMABLE-BOUNDARY-START(30068418325),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25773451029,
        "f": 50364417
      },
      "n": "Name",
      "d": 3647253,
      "h": 30068418325,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30068418325)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298614549),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3647253,
      "h": 4298614549,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298614549)
  ],
  "h": 3647253
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.SmartMultiVoltmeterDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}SmartMultiVoltmeterDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3647253)
        
        

        //--TRIMMABLE-BOUNDARY-START(3974933)
        $asm.$cls(`$ASam.LCIDMV.SmartMultiVoltmeterViewRenderer`, ($self) => class SmartMultiVoltmeterViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298942229)
            $ctor$3(/*IOTRootViewModel*/ root)
            {
                super.$ctor$2(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298942229);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298942229)
            
            //--TRIMMABLE-BOUNDARY-START(8593909525)
            /*RenderFragment */ GetView(/*IClientUnitOfWork*/ ui, /*SmartMultiVoltmeterDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>*/ clicked, /*Func<Task>*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593909525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.SmartMultiVoltmeterDeviceSettings*/ let __ca1__;
                /*LivingThing.Core.IOT.Devices.MultiVoltmeter.Settings.ChannelVisuaization[]*/ let __ca2__;
                if (type === 3/*DeviceViewType.Details*/ && (((__ca1__ = device.Settings$1) !== null ? ((__ca2__ = __ca1__.Channels) !== null ? $.$sl.SL.Enumerable.Any$1($.$ASam.LCIDMS.ChannelVisuaization, __ca2__) : false) : false)))
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$ASam.LCIDMV.SmartMultiVoltmeterDeviceDetails, $.$ASam.LCIDMV.SmartMultiVoltmeterDetailsViewModel, new $.$ASam.LCIDMV.SmartMultiVoltmeterDetailsViewModel().$ctor$9(this.Root, device.OwnerScope, device), true, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(8593909525)
            
            static $h = 3974933;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593909525),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 3516181
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 3974933,
      "h": 8593909525,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8593909525)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298942229),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3974933,
      "h": 4298942229,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298942229)
  ],
  "h": 3974933
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice), $.$ntej.LCICD$1.IDeviceViewRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Views.SmartMultiVoltmeterViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Views${separator}SmartMultiVoltmeterViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3974933)
        
        

        //--TRIMMABLE-BOUNDARY-START(2533141)
        $asm.$cls(`$ASam.LCIDMPC.SmartMultiVoltmeterDeviceCommands`, ($self) => class SmartMultiVoltmeterDeviceCommands extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12887435029)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12887435029)
            
            //--TRIMMABLE-BOUNDARY-START(17182402325)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182402325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$ASam.LCIDMPC.SmartMultiVoltmeterDeviceCommands.commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17182402325)
            
            //--TRIMMABLE-BOUNDARY-START(8592467733)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592467733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592467733)
            
            //--TRIMMABLE-BOUNDARY-START(8592467733)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8592467733)
            
            //--TRIMMABLE-BOUNDARY-START(4297500437)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297500437);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12887435029)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [new $.$ASam.LCIDMPCV.SmartMultiVoltmeterCalibrateCommand().$ctor$6()], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12887435029)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297500437)
            
            static $h = 2533141;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182402325),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": 2533141,
      "h": 17182402325,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17182402325)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887435029),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": 2533141,
      "h": 12887435029,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12887435029)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592467733),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2533141,
      "h": 8592467733,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592467733)
  ],
  "h": 2533141
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Protocol.Commands.SmartMultiVoltmeterDeviceCommands`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Protocol${separator}Commands${separator}SmartMultiVoltmeterDeviceCommands`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2533141)
        
        

        //--TRIMMABLE-BOUNDARY-START(3843861)
        $asm.$cls(`$ASam.LCIDMV.SmartMultiVoltmeterDetailsViewModel`, ($self) => class SmartMultiVoltmeterDetailsViewModel extends $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298811157)
            $ctor$9(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*SmartMultiVoltmeterDevice*/ device)
            {
                super.$ctor$8(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298811157);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298811157)
            
            static $h = 3843861;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings, $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceHardwareSettings, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceReceivedDataModel, $.$ASam.LCIDMM.SmartMultiVoltmeterDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298811157),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 3516181
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 3843861,
      "h": 4298811157,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298811157)
  ],
  "h": 3843861
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICDV.IDeviceDetailsViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Views.SmartMultiVoltmeterDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Views${separator}SmartMultiVoltmeterDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3843861)
        
        

        //--TRIMMABLE-BOUNDARY-START(3909397)
        $asm.$cls(`$ASam.LCIDMV.SmartMultiVoltmeterDeviceDetails`, ($self) => class SmartMultiVoltmeterDeviceDetails extends $.$hDPm.LCFCC$1.BaseComponent$$($.$ASam.LCIDMV.SmartMultiVoltmeterDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(68723386133)
            /*SmartMultiVoltmeterDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(68723386133)
            
            //--TRIMMABLE-BOUNDARY-START(17183778581)
            /*PageBuilderMode*/ builderMode = 0;
            //--TRIMMABLE-BOUNDARY-END(17183778581)
            
            //--TRIMMABLE-BOUNDARY-START(60133451541)
            /*void */ ToggleBuilder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60133451541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.builderMode === 0/*PageBuilderMode.Read*/)
                {
                    this.builderMode = 1/*PageBuilderMode.EditDragDrop*/;
                }
                else 
                {
                    this.builderMode = 0/*PageBuilderMode.Read*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60133451541)
            
            //--TRIMMABLE-BOUNDARY-START(25773713173)
            /*Task *//*async*/  EditCard(/*ChannelVisuaization*/ channel)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25773713173);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = $.$hDPm.LCFCI.ViewPresenterExtensions.Form($.$hDPm.LCFCI.ViewConfiguration, $.$ASam.LCIDMS.ChannelVisuaization, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPage, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Edit Channel", false), null, channel, null, null, 0, 4131, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = this.ViewModel.Device$1.UpdateAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25773713173)
            
            //--TRIMMABLE-BOUNDARY-START(12888811285)
            /*Task */ AddCard()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888811285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ChannelVisuaization*/ let channel = new $.$ASam.LCIDMS.ChannelVisuaization().$ctor$1();
                this.ViewModel.Device$1.Model$1.Settings.Channels = $.$sl.SL.Enumerable.ToArray($.$ASam.LCIDMS.ChannelVisuaization, $.$sl.SL.Enumerable.Concat($.$ASam.LCIDMS.ChannelVisuaization, this.ViewModel.Device$1.Model$1.Settings.Channels, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$ASam.LCIDMS.ChannelVisuaization), [channel], null, null)));
                return this.EditCard(channel);
            }
            //--TRIMMABLE-BOUNDARY-END(12888811285)
            
            //--TRIMMABLE-BOUNDARY-START(47248549653)
            /*string */ get OptimizedComponentName()
            {
                return "smartmultivoltmeterdevicedetails";
            }
            //--TRIMMABLE-BOUNDARY-END(47248549653)
            
            //--TRIMMABLE-BOUNDARY-START(64428418837)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64428418837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch3 = parameter.Name;
                switch($switch3)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$ASam.LCIDMV.SmartMultiVoltmeterDetailsViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(64428418837)
            
            //--TRIMMABLE-BOUNDARY-START(21478745877)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478745877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$ASam.LCIDM.SmartMultiVoltmeterDevice), this.ViewModel));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenElement(3, "FloatingButtonPage");
                    __builder2.OpenElement(4, "ChildContent");
                    __builder2.OpenElement(5, "div");
                    __builder2.AddAttribute$5(6, "class", "row responsive");
                    this.ViewModel.Device$1.Model$1.Settings ??= new $.$ASam.LCIDMS.SmartMultiVoltmeterDeviceSettings().$ctor$4();
                    this.ViewModel.Device$1.Model$1.Settings.Channels ??= $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$ASam.LCIDMS.ChannelVisuaization), null, [0], null);
                    let $i4 = 0;
                    let $arr4 = this.ViewModel.Device$1.Model$1.Settings.Channels;
                    while ($i4 < $arr4.length)
                    {
                        let channel = $arr4[$i4++];
                        /*var*/ let _channel = channel;
                        __builder2.OpenElement(7, "div");
                        __builder2.AddAttribute$5(8, "class", "miwx-15");
                        __builder2.SetKey(_channel);
                        __builder2.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 9);
                        __builder2.AddComponentParameter(10, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 21/*CardFeatures.Default*/ & ~2/*CardFeatures.Corner*/), $.$hDPm.LCFCCC$1.CardFeatures));
                        __builder2.AddComponentParameter(11, "Class", "text-center");
                        __builder2.AddComponentParameter(12, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                        {
                            return this.EditCard(_channel);
                        }, $HnzUnd ??= {"r":178454529,"n":"","d":3909397,"h":0,"f":17825794})));
                        __builder2.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                        {
                            __builder3.OpenElement(14, "i");
                            __builder3.AddAttribute$5(15, "class", `fsz-100 mdi ${$.$strNN((_channel.Icon ?? "mdi-image"))} mgx-a d-block`);
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(16, "\r\n                            ");
                            __builder3.OpenElement(17, "h2");
                            __builder3.AddAttribute$5(18, "class", "mgb-0 mgt-1");
                            __builder3.AddContent$4(19, (() =>
                            {
                                var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(0, 1);
                                $handler.AppendFormatted($.$box(this.ViewModel.Device$1.Channel(_channel), $.$$.S.String), null, "f");
                                return $handler.ToStringAndClear                        ();
                            })());
                            __builder3.AddContent$4(20, _channel.Unit);
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(21, "\r\n                            ");
                            __builder3.OpenElement(22, "span");
                            __builder3.AddContent$4(23, _channel.Label);
                            __builder3.CloseElement();
                        }), $FHzIZf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":3909397,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(24, "\r\n        ");
                    __builder2.OpenElement(25, "Buttons");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 26);
                    __builder2.AddComponentParameter(27, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mdi ${$.$strNN((this.builderMode === 0/*PageBuilderMode.Read*/ ? "mdi-pencil" : "mdi-check"))} mg round shadow hx-05 wx-05 fsz-35`));
                    __builder2.AddComponentParameter(28, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder2.AddComponentParameter(29, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToggleBuilder))));
                    __builder2.AddComponentParameter(30, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                }), $edeRLh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3909397,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21478745877)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8593843989)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593843989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593843989)
            
            //--TRIMMABLE-BOUNDARY-START(8593843989)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8593843989)
            
            static $h = 3909397;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$ASam.LCIDMV.SmartMultiVoltmeterDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68723386133),
    {
      "p": 3843861,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42953582357,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55838484245,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 3909397,
      "h": 68723386133,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68723386133),
//--TRIMMABLE-BOUNDARY-START(47248549653),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34363647765,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 3909397,
      "h": 47248549653,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47248549653)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60133451541),
    {
      "r": 65537,
      "n": "ToggleBuilder",
      "d": 3909397,
      "h": 60133451541,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60133451541),
//--TRIMMABLE-BOUNDARY-START(25773713173),
    {
      "r": 178454529,
      "p": [
        {
          "n": "channel",
          "p": 2729749
        }
      ],
      "n": "EditCard",
      "d": 3909397,
      "h": 25773713173,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(25773713173),
//--TRIMMABLE-BOUNDARY-START(12888811285),
    {
      "r": 178454529,
      "n": "AddCard",
      "d": 3909397,
      "h": 12888811285,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12888811285),
//--TRIMMABLE-BOUNDARY-START(64428418837),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 3909397,
      "h": 64428418837,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64428418837),
//--TRIMMABLE-BOUNDARY-START(21478745877),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 3909397,
      "h": 21478745877,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21478745877)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17183778581),
    {
      "t": 66606762,
      "n": "builderMode",
      "d": 3909397,
      "h": 17183778581,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17183778581)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593843989),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3909397,
      "h": 8593843989,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593843989)
  ],
  "h": 3909397
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.MultiVoltmeter.Views.SmartMultiVoltmeterDeviceDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}MultiVoltmeter${separator}Views${separator}SmartMultiVoltmeterDeviceDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3909397)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor", "NetJs.LivingThing.Core.IOT.Devices.SerialBridge"));
})();
//--TRIMMABLE-BOUNDARY-END(42773)
