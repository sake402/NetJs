
//--TRIMMABLE-BOUNDARY-START(61133)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $HnZw, $mep, $meca, $mxdi, $mexla, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $meo, $mecm, $mecga, $mec, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $fXpo, $zHIt, $uvJL, $KuVO, $lOHy, $kVHt, $UrvY, $vWqU, $JRhp, $DJRY, $tUcV, $nYKj, $AvdQ, $bMcF, $XBGm, $NXre) {
    "use strict";
    let _;
    let $NgmEdk;
    let $BsKzej;
    let $rKPRuh;
    let $pRFhgh;
    let $gOZSNb;
    let $mkuaUe;
    let $XnZVUj;
    let $KoHDyb;
    let $iCtgUh;
    let $KjhxNi;
    let $yGKeGh;
    let $asCgrd;
    let $XMpRde;
    let $tHeVLj;
    let $kLNFfc;
    let $eKYLDk;
    let $DhSoBg;
    let $lIaitg;
    let $dVqDvj;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.PowerBeacon", 
    {
  "h": 61133,
  "f": "LivingThing.Core.IOT.Devices.PowerBeacon",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.PowerBeacon",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.PowerBeacon",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5Qb3dlckJlYWNvbi5Qb3dlckJlYWNvbkRldmljZSI6IHsNCiAgICAgICJDYXRlZ29yaWVzIjogWyAiU21hcnQgSG9tZSIgXSwNCiAgICAgICJOYW1lIjogIlBvd2VyQmVhY29uIiwNCiAgICAgICJEZXNjcmlwdGlvbiI6ICJEZXRlY3QgQUMgcG93ZXIgYXZhaWxhYmlsaXR5IGluIGEgc3RhdGlvbi9ob21lIiwNCiAgICAgICJCYW5uZXJJbWFnZSI6ICJ\u002BL1Bvd2VyQmVhY29uL2ltZy9iYW5uZXIuanBnIiwNCiAgICAgICJVbml0Q29zdCI6IHsNCiAgICAgICAgIlZhbHVlIjogNDAwMCwNCiAgICAgICAgIlVuaXQiOiAiTmFpcmEiDQogICAgICB9LA0KICAgICAgIkltYWdlcyI6IFsNCiAgICAgIF0sDQogICAgICAiSWNvbiI6IHsgIk5hbWUiOiAibWRpIG1kaS1lbGVjdHJpYy1zd2l0Y2giIH0sDQogICAgICAiVGhlbWVDb2xvciI6ICIjZDc3YmJhIiwNCiAgICAgICJGbGFncyI6ICJGZWF0dXJlZCxQdWJsaXNoZWQiLA0KICAgICAgIlNlY3VyaXRpZXMiOiAiQ2hhbGxlbmdlSGFuZFNoYWtlQXV0aGVudGljYXRpb25Qcm90b2NvbCxBZHZhbmNlZEVuY3J5cHRpb25TdGFuZGFyZCxFbGxpcHRpY0N1cnZlRmlybXdhcmVVcGRhdGVTaWduaW5nIiwNCiAgICAgICJTdGF0dXNOYW1lcyI6ICJTdGF0dXMuU3RhdHVzLFN0YXR1cy5Db3VudERvd24iDQogICAgfQ0KICB9DQp9"
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(388813)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconDeviceModelCustomAttributesProvider`, ($self) => class PowerBeaconDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295356109)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295356109);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295356109)
            
            static $h = 388813;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295356109),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 388813,
      "h": 4295356109,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295356109)
  ],
  "h": 388813
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(388813)
        
        

        //--TRIMMABLE-BOUNDARY-START(3010253)
        $asm.$cls(`$PSrA.LCIDPS$1.PowerBeaconDeviceSettingsCustomAttributesProvider`, ($self) => class PowerBeaconDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297977549)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297977549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297977549)
            
            static $h = 3010253;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297977549),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3010253,
      "h": 4297977549,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297977549)
  ],
  "h": 3010253
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Settings${separator}PowerBeaconDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3010253)
        
        

        //--TRIMMABLE-BOUNDARY-START(913101)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconDeviceScopeModelCustomAttributesProvider`, ($self) => class PowerBeaconDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295880397)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295880397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295880397)
            
            static $h = 913101;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295880397),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 913101,
      "h": 4295880397,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295880397)
  ],
  "h": 913101
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(913101)
        
        

        //--TRIMMABLE-BOUNDARY-START(1437389)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconServiceModelCustomAttributesProvider`, ($self) => class PowerBeaconServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296404685)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296404685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296404685)
            
            static $h = 1437389;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296404685),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1437389,
      "h": 4296404685,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296404685)
  ],
  "h": 1437389
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1437389)
        
        

        //--TRIMMABLE-BOUNDARY-START(1175245)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconDeviceSendDataModelCustomAttributesProvider`, ($self) => class PowerBeaconDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296142541)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296142541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceCommandsModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296142541)
            
            static $h = 1175245;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296142541),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1175245,
      "h": 4296142541,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296142541)
  ],
  "h": 1175245
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1175245)
        
        

        //--TRIMMABLE-BOUNDARY-START(2617037)
        $asm.$cls(`$PSrA.LCIDPS$1.PowerBeaconBroadcastPeerMessagesCustomAttributesProvider`, ($self) => class PowerBeaconBroadcastPeerMessagesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297584333)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297584333);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297584333)
            
            static $h = 2617037;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297584333),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2617037,
      "h": 4297584333,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297584333)
  ],
  "h": 2617037
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconBroadcastPeerMessagesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Settings${separator}PowerBeaconBroadcastPeerMessagesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2617037)
        
        

        //--TRIMMABLE-BOUNDARY-START(192205)
        $asm.$cls(`$PSrA.LCIDP.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295159501)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295159501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PSrA.LCIDPM.PowerBeaconDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PSrA.LCIDPM.PowerBeaconDeviceModelCustomAttributesProvider, $.$PSrA.LCIDPM.PowerBeaconDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModelCustomAttributesProvider, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PSrA.LCIDPM.PowerBeaconDeviceScopeModelCustomAttributesProvider, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModelCustomAttributesProvider, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PSrA.LCIDPM.PowerBeaconServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PSrA.LCIDPM.PowerBeaconServiceModelCustomAttributesProvider, $.$PSrA.LCIDPM.PowerBeaconServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PSrA.LCIDPMS.PowerBeaconStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PSrA.LCIDPMS.PowerBeaconStatusModelCustomAttributesProvider, $.$PSrA.LCIDPMS.PowerBeaconStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PSrA.LCIDPS$1.PowerBeaconBroadcastPeerMessages.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PSrA.LCIDPS$1.PowerBeaconBroadcastPeerMessagesCustomAttributesProvider, $.$PSrA.LCIDPS$1.PowerBeaconBroadcastPeerMessagesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettingsCustomAttributesProvider, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$PSrA.LCIDPS$1.PowerBeaconDeviceSettingsCustomAttributesProvider, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295159501)
            
            static $h = 192205;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295159501),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 192205,
      "h": 4295159501,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295159501)
  ],
  "h": 192205
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(192205)
        
        

        //--TRIMMABLE-BOUNDARY-START(1699533)
        $asm.$cls(`$PSrA.LCIDPMS.PowerBeaconStatusModelCustomAttributesProvider`, ($self) => class PowerBeaconStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296666829)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296666829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296666829)
            
            static $h = 1699533;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296666829),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1699533,
      "h": 4296666829,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296666829)
  ],
  "h": 1699533
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.Statuses.PowerBeaconStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}Statuses${separator}PowerBeaconStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1699533)
        
        

        //--TRIMMABLE-BOUNDARY-START(257741)
        $asm.$cls(`$PSrA.LCIDP.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295225037)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295225037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295225037)
            
            static $h = 257741;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295225037),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 257741,
      "h": 4295225037,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295225037)
  ],
  "h": 257741
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(257741)
        
        

        //--TRIMMABLE-BOUNDARY-START(1306317)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class PowerBeaconDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591240909)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591240909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $pRFhgh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1306317,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591240909)
            
            //--TRIMMABLE-BOUNDARY-START(4296273613)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296273613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296273613)
            
            //--TRIMMABLE-BOUNDARY-START(4296273613)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296273613)
            
            static $h = 1306317;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591240909),
    {
      "r": 65537,
      "n": "Register",
      "d": 1306317,
      "h": 8591240909,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591240909)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296273613),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1306317,
      "h": 4296273613,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296273613)
  ],
  "h": 1306317
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1306317)
        
        

        //--TRIMMABLE-BOUNDARY-START(650957)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class PowerBeaconDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295618253)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295618253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$PSrA.LCIDPMS.PowerBeaconStatusModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295618253)
            
            static $h = 650957;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295618253),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 650957,
      "h": 4295618253,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295618253)
  ],
  "h": 650957
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(650957)
        
        

        //--TRIMMABLE-BOUNDARY-START(1830605)
        $asm.$cls(`$PSrA.LCIDPMS.PowerBeaconStatusModelTypeDescriptorBuilder`, ($self) => class PowerBeaconStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591765197)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591765197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PSrA.LCIDPMS.PowerBeaconStatusModelTypeDescriptor()
                        const $t1 = $.$PSrA.LCIDPMS.PowerBeaconStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.PowerBeacon.Models.Statuses.PowerBeaconStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $mkuaUe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1830605,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PSrA.LCIDPMS.PowerBeaconStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591765197)
            
            //--TRIMMABLE-BOUNDARY-START(4296797901)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296797901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296797901)
            
            //--TRIMMABLE-BOUNDARY-START(4296797901)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296797901)
            
            static $h = 1830605;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591765197),
    {
      "r": 65537,
      "n": "Register",
      "d": 1830605,
      "h": 8591765197,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591765197)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296797901),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1830605,
      "h": 4296797901,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296797901)
  ],
  "h": 1830605
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.Statuses.PowerBeaconStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}Statuses${separator}PowerBeaconStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1830605)
        
        

        //--TRIMMABLE-BOUNDARY-START(782029)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class PowerBeaconDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590716621)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590716621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $KoHDyb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":782029,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590716621)
            
            //--TRIMMABLE-BOUNDARY-START(4295749325)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295749325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295749325)
            
            //--TRIMMABLE-BOUNDARY-START(4295749325)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295749325)
            
            static $h = 782029;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590716621),
    {
      "r": 65537,
      "n": "Register",
      "d": 782029,
      "h": 8590716621,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590716621)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295749325),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 782029,
      "h": 4295749325,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295749325)
  ],
  "h": 782029
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(782029)
        
        

        //--TRIMMABLE-BOUNDARY-START(1568461)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconServiceModelTypeDescriptorBuilder`, ($self) => class PowerBeaconServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591503053)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591503053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PSrA.LCIDPM.PowerBeaconServiceModelTypeDescriptor()
                        const $t1 = $.$PSrA.LCIDPM.PowerBeaconServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $KjhxNi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1568461,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PSrA.LCIDPM.PowerBeaconServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591503053)
            
            //--TRIMMABLE-BOUNDARY-START(4296535757)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296535757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296535757)
            
            //--TRIMMABLE-BOUNDARY-START(4296535757)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296535757)
            
            static $h = 1568461;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591503053),
    {
      "r": 65537,
      "n": "Register",
      "d": 1568461,
      "h": 8591503053,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591503053)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296535757),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1568461,
      "h": 4296535757,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296535757)
  ],
  "h": 1568461
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1568461)
        
        

        //--TRIMMABLE-BOUNDARY-START(2748109)
        $asm.$cls(`$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class PowerBeaconDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297715405)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297715405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297715405)
            
            static $h = 2748109;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297715405),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2748109,
      "h": 4297715405,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297715405)
  ],
  "h": 2748109
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Settings${separator}PowerBeaconDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2748109)
        
        

        //--TRIMMABLE-BOUNDARY-START(3206861)
        $asm.$cls(`$PSrA.LCIDP.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298174157)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298174157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PSrA.LCIDPM.PowerBeaconDeviceModelTypeDescriptorBuilder.Register();
                $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$PSrA.LCIDPM.PowerBeaconServiceModelTypeDescriptorBuilder.Register();
                $.$PSrA.LCIDPMS.PowerBeaconStatusModelTypeDescriptorBuilder.Register();
                $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298174157)
            
            static $h = 3206861;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298174157),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3206861,
      "h": 4298174157,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298174157)
  ],
  "h": 3206861
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3206861)
        
        

        //--TRIMMABLE-BOUNDARY-START(2879181)
        $asm.$cls(`$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class PowerBeaconDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592813773)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592813773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $asCgrd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2879181,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592813773)
            
            //--TRIMMABLE-BOUNDARY-START(4297846477)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297846477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297846477)
            
            //--TRIMMABLE-BOUNDARY-START(4297846477)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297846477)
            
            static $h = 2879181;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592813773),
    {
      "r": 65537,
      "n": "Register",
      "d": 2879181,
      "h": 8592813773,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592813773)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297846477),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2879181,
      "h": 4297846477,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297846477)
  ],
  "h": 2879181
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Settings${separator}PowerBeaconDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2879181)
        
        

        //--TRIMMABLE-BOUNDARY-START(3141325)
        $asm.$cls(`$PSrA.LCIDPS$1.PowerBeaconDeviceSettingsTypeDescriptorBuilder`, ($self) => class PowerBeaconDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593075917)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593075917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettingsTypeDescriptor()
                        const $t1 = $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $tHeVLj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3141325,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593075917)
            
            //--TRIMMABLE-BOUNDARY-START(4298108621)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298108621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298108621)
            
            //--TRIMMABLE-BOUNDARY-START(4298108621)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298108621)
            
            static $h = 3141325;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593075917),
    {
      "r": 65537,
      "n": "Register",
      "d": 3141325,
      "h": 8593075917,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593075917)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298108621),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3141325,
      "h": 4298108621,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298108621)
  ],
  "h": 3141325
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Settings${separator}PowerBeaconDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3141325)
        
        

        //--TRIMMABLE-BOUNDARY-START(519885)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconDeviceModelTypeDescriptorBuilder`, ($self) => class PowerBeaconDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590454477)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590454477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PSrA.LCIDPM.PowerBeaconDeviceModelTypeDescriptor()
                        const $t1 = $.$PSrA.LCIDPM.PowerBeaconDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $eKYLDk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":519885,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PSrA.LCIDPM.PowerBeaconDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590454477)
            
            //--TRIMMABLE-BOUNDARY-START(4295487181)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295487181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295487181)
            
            //--TRIMMABLE-BOUNDARY-START(4295487181)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295487181)
            
            static $h = 519885;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590454477),
    {
      "r": 65537,
      "n": "Register",
      "d": 519885,
      "h": 8590454477,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590454477)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295487181),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 519885,
      "h": 4295487181,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295487181)
  ],
  "h": 519885
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(519885)
        
        

        //--TRIMMABLE-BOUNDARY-START(1044173)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconDeviceScopeModelTypeDescriptorBuilder`, ($self) => class PowerBeaconDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590978765)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590978765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $lIaitg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1044173,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590978765)
            
            //--TRIMMABLE-BOUNDARY-START(4296011469)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296011469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296011469)
            
            //--TRIMMABLE-BOUNDARY-START(4296011469)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296011469)
            
            static $h = 1044173;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590978765),
    {
      "r": 65537,
      "n": "Register",
      "d": 1044173,
      "h": 8590978765,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590978765)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296011469),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1044173,
      "h": 4296011469,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296011469)
  ],
  "h": 1044173
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1044173)
        
        

        //--TRIMMABLE-BOUNDARY-START(126669)
        $asm.$cls(`$PSrA.LCIDP.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17179995853)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17179995853)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295093965)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295093965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295093965)
            
            //--TRIMMABLE-BOUNDARY-START(4295093965)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295093965)
            
            static $h = 126669;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17179995853),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885028557,
        "f": 50331649
      },
      "n": "Paths",
      "d": 126669,
      "h": 17179995853,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17179995853)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295093965),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 126669,
      "h": 4295093965,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295093965)
  ],
  "h": 126669
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(126669)
        
        

        //--TRIMMABLE-BOUNDARY-START(2289357)
        $asm.$cls(`$PSrA.LCIDP.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592223949)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592223949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return;
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$PSrA.LCIDP.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$PSrA.LCIDP.PowerBeaconDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$PSrA.LCIDP.PowerBeaconDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$PSrA.LCIDP.PowerBeaconDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$PSrA.LCIDP.PowerBeaconDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$PSrA.LCIDP.PowerBeaconDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PSrA.LCIDP.PowerBeaconDeviceFamily, x);
                }, $NgmEdk ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":2289357,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PSrA.LCIDP.PowerBeaconDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$PSrA.LCIDP.PowerBeaconDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $BsKzej ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":2289357,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$PSrA.LCIDP.PowerBeaconDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PSrA.LCIDP.PowerBeaconDeviceFamily, x);
                }, $rKPRuh ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$PSrA.LCIDP.PowerBeaconDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":2289357,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$PSrA.LCIDP.PowerBeaconDevice, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$PSrA.LCIDP.PowerBeaconDevice, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$PSrA.LCIDP.PowerBeaconDevice, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$PSrA.LCIDP.PowerBeaconDevice), $.$PSrA.LCIDPPC.PowerBeaconDeviceCommands$$($.$PSrA.LCIDP.PowerBeaconDevice), services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592223949)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PSrA.LCIDP.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297256653)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297256653);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297256653)
            
            //--TRIMMABLE-BOUNDARY-START(4297256653)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297256653)
            
            static $h = 2289357;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592223949),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2289357,
      "h": 8592223949,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592223949)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297256653),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2289357,
      "h": 4297256653,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297256653)
  ],
  "h": 2289357
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2289357)
        
        

        //--TRIMMABLE-BOUNDARY-START(1633997)
        $asm.$cls(`$PSrA.LCIDPMS.PowerBeaconStatusModel`, ($self) => class PowerBeaconStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296601293)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296601293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296601293)
            
            //--TRIMMABLE-BOUNDARY-START(4296601293)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296601293)
            
            static $h = 1633997;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296601293),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1633997,
      "h": 4296601293,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296601293)
  ],
  "h": 1633997
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.Statuses.PowerBeaconStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}Statuses${separator}PowerBeaconStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1633997)
        
        

        //--TRIMMABLE-BOUNDARY-START(2551501)
        $asm.$str(`$PSrA.LCIDPS$1.PowerBeaconBroadcastPeerMessages`, ($self) => class PowerBeaconBroadcastPeerMessages extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static RunTime = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2551501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "RunTime": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297518797)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297518797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297518797)
            
            //--TRIMMABLE-BOUNDARY-START(4297518797)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297518797)
            
            static $h = 2551501;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592486093),
    {
      "t": 2551501,
      "n": "None",
      "d": 2551501,
      "h": 8592486093,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592486093),
//--TRIMMABLE-BOUNDARY-START(12887453389),
    {
      "t": 2551501,
      "n": "RunTime",
      "d": 2551501,
      "h": 12887453389,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887453389)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297518797),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2551501,
      "h": 4297518797,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297518797)
  ],
  "h": 2551501
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconBroadcastPeerMessages`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Settings${separator}PowerBeaconBroadcastPeerMessages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2551501)
        
        

        //--TRIMMABLE-BOUNDARY-START(1765069)
        $asm.$cls(`$PSrA.LCIDPMS.PowerBeaconStatusModelTypeDescriptor`, ($self) => class PowerBeaconStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PSrA.LCIDPMS.PowerBeaconStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296732365)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296732365);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PSrA.LCIDPMS.PowerBeaconStatusModelTypeDescriptor.GenerateProperties($.$PSrA.LCIDPMS.PowerBeaconStatusModel, this, factory);
                    }, $XnZVUj ??= {"r":65537,"n":"","d":1765069,"h":0,"f":17825794}), 0, "PowerBeaconStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.PowerBeacon\\Models_Statuses_PowerBeaconStatusModel_LivingThing.Core.IOT.Devices.PowerBeacon.Models.Statuses.PowerBeaconStatusModelTypeDescriptorBuilder.g.cs", "PowerBeaconStatusModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296732365)
            
            //--TRIMMABLE-BOUNDARY-START(12886666957)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886666957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886666957)
            
            //--TRIMMABLE-BOUNDARY-START(17181634253)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.PowerBeacon.Models.Statuses.PowerBeaconStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181634253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181634253)
            
            //--TRIMMABLE-BOUNDARY-START(8591699661)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.PowerBeacon.Models.Statuses.PowerBeaconStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591699661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PSrA.LCIDPMS.PowerBeaconStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PSrA.LCIDPMS.PowerBeaconStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPMS.PowerBeaconStatusModel)))
                {
                    /*var*/ let result = $.$PSrA.LCIDPMS.PowerBeaconStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPMS.PowerBeaconStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PSrA.LCIDPMS.PowerBeaconStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPMS.PowerBeaconStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591699661)
            
            static $h = 1765069;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PSrA.LCIDPMS.PowerBeaconStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886666957),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1765069,
      "h": 12886666957,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886666957),
//--TRIMMABLE-BOUNDARY-START(17181634253),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1633997,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1765069,
      "h": 17181634253,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181634253),
//--TRIMMABLE-BOUNDARY-START(8591699661),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1633997,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1765069,
      "h": 8591699661,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591699661)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296732365),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1765069,
      "h": 4296732365,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296732365)
  ],
  "h": 1765069
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PSrA.LCIDPMS.PowerBeaconStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.Statuses.PowerBeaconStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}Statuses${separator}PowerBeaconStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1765069)
        
        

        //--TRIMMABLE-BOUNDARY-START(2223821)
        $asm.$cls(`$PSrA.LCIDPPC.PowerBeaconDeviceCommands<>`, (TDevice) => $asm.$gt(`$PSrA.LCIDPPC.PowerBeaconDeviceCommands<>`, [TDevice], ($self) => class PowerBeaconDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12887125709)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12887125709)
            
            //--TRIMMABLE-BOUNDARY-START(17182093005)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182093005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$PSrA.LCIDPPC.PowerBeaconDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17182093005)
            
            //--TRIMMABLE-BOUNDARY-START(8592158413)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592158413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592158413)
            
            //--TRIMMABLE-BOUNDARY-START(8592158413)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8592158413)
            
            //--TRIMMABLE-BOUNDARY-START(4297191117)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297191117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12887125709)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12887125709)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297191117)
            
            static $H = 2223821;
            static $h = 2223821;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182093005),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17182093005,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17182093005)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887125709),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12887125709,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12887125709)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592158413),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8592158413,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592158413)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 2223821,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Protocol.Commands.PowerBeaconDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Protocol${separator}Commands${separator}PowerBeaconDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2223821)
        
        

        //--TRIMMABLE-BOUNDARY-START(1109709)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel`, ($self) => class PowerBeaconDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceCommandsModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296077005)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296077005);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296077005)
            
            //--TRIMMABLE-BOUNDARY-START(4296077005)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296077005)
            
            static $h = 1109709;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandsModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296077005),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1109709,
      "h": 4296077005,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296077005)
  ],
  "h": 1109709
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1109709)
        
        

        //--TRIMMABLE-BOUNDARY-START(585421)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel`, ($self) => class PowerBeaconDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$PSrA.LCIDPMS.PowerBeaconStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295552717)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295552717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295552717)
            
            //--TRIMMABLE-BOUNDARY-START(4295552717)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295552717)
            
            static $h = 585421;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$PSrA.LCIDPMS.PowerBeaconStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295552717),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 585421,
      "h": 4295552717,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295552717)
  ],
  "h": 585421
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(585421)
        
        

        //--TRIMMABLE-BOUNDARY-START(1240781)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconDeviceSendDataModelTypeDescriptor`, ($self) => class PowerBeaconDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296208077)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296208077);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModelTypeDescriptor.GenerateProperties($.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, this, factory);
                    }, $gOZSNb ??= {"r":65537,"n":"","d":1240781,"h":0,"f":17825794}), 0, "PowerBeaconDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.PowerBeacon\\Models_PowerBeaconDeviceSendDataModel_LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceSendDataModelTypeDescriptorBuilder.g.cs", "PowerBeaconDeviceSendDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296208077)
            
            //--TRIMMABLE-BOUNDARY-START(12886142669)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886142669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886142669)
            
            //--TRIMMABLE-BOUNDARY-START(17181109965)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181109965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandsModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandsModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181109965)
            
            //--TRIMMABLE-BOUNDARY-START(8591175373)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591175373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591175373)
            
            static $h = 1240781;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886142669),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1240781,
      "h": 12886142669,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886142669),
//--TRIMMABLE-BOUNDARY-START(17181109965),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1109709,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1240781,
      "h": 17181109965,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181109965),
//--TRIMMABLE-BOUNDARY-START(8591175373),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1109709,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1240781,
      "h": 8591175373,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591175373)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296208077),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1240781,
      "h": 4296208077,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296208077)
  ],
  "h": 1240781
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1240781)
        
        

        //--TRIMMABLE-BOUNDARY-START(716493)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModelTypeDescriptor`, ($self) => class PowerBeaconDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295683789)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295683789);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, this, factory);
                    }, $iCtgUh ??= {"r":65537,"n":"","d":716493,"h":0,"f":17825794}), 0, "PowerBeaconDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.PowerBeacon\\Models_PowerBeaconDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "PowerBeaconDeviceReceivedDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295683789)
            
            //--TRIMMABLE-BOUNDARY-START(12885618381)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885618381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$PSrA.LCIDPMS.PowerBeaconStatusModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885618381)
            
            //--TRIMMABLE-BOUNDARY-START(17180585677)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180585677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.PowerBeacon.Models.Statuses.PowerBeaconStatusModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$PSrA.LCIDPMS.PowerBeaconStatusModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$PSrA.LCIDPMS.PowerBeaconStatusModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180585677)
            
            //--TRIMMABLE-BOUNDARY-START(8590651085)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590651085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590651085)
            
            static $h = 716493;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885618381),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 716493,
      "h": 12885618381,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885618381),
//--TRIMMABLE-BOUNDARY-START(17180585677),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 585421,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 716493,
      "h": 17180585677,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180585677),
//--TRIMMABLE-BOUNDARY-START(8590651085),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 585421,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 716493,
      "h": 8590651085,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590651085)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295683789),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 716493,
      "h": 4295683789,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295683789)
  ],
  "h": 716493
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(716493)
        
        

        //--TRIMMABLE-BOUNDARY-START(1896141)
        $asm.$cls(`$PSrA.LCIDP.PowerBeaconDataConverter`, ($self) => class PowerBeaconDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296863437)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296863437);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296863437)
            
            //--TRIMMABLE-BOUNDARY-START(4296863437)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296863437)
            
            static $h = 1896141;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296863437),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1896141,
      "h": 4296863437,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296863437)
  ],
  "h": 1896141
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.PowerBeaconDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}PowerBeaconDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1896141)
        
        

        $asm.$typeProxy("$PSrA.LCIDPM.PowerBeaconServiceModel", "$PSrA.LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconServiceModel");
        $asm.$typeProxy("$PSrA.LCIDPM.PowerBeaconDeviceModel", "$PSrA.LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceModel");
        $asm.$typeProxy("$PSrA.LCIDPS$1.PowerBeaconDeviceSettings", "$PSrA.LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceSettings");
        $asm.$typeProxy("$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings", "$PSrA.LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceHardwareSettings");
        $asm.$typeProxy("$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler", "$PSrA.LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconDeviceStatusHandler");
        $asm.$typeProxy("$PSrA.LCIDPS.IPowerBeaconDeviceHubClient", "$PSrA.LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconDeviceHubClient");
        $asm.$typeProxy("$PSrA.LCIDPS.IPowerBeaconRemoteService", "$PSrA.LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconRemoteService");
        //--TRIMMABLE-BOUNDARY-START(847565)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconDeviceScopeModel`, ($self) => class PowerBeaconDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295814861)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295814861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295814861)
            
            //--TRIMMABLE-BOUNDARY-START(4295814861)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295814861)
            
            static $h = 847565;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295814861),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 847565,
      "h": 4295814861,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295814861)
  ],
  "h": 847565
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(847565)
        
        

        //--TRIMMABLE-BOUNDARY-START(323277)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconDeviceModel`, ($self) => class PowerBeaconDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295290573)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295290573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295290573)
            
            //--TRIMMABLE-BOUNDARY-START(4295290573)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295290573)
            
            static $h = 323277;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295290573),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 323277,
      "h": 4295290573,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295290573)
  ],
  "h": 323277
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(323277)
        
        

        //--TRIMMABLE-BOUNDARY-START(1371853)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconServiceModel`, ($self) => class PowerBeaconServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296339149)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296339149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296339149)
            
            //--TRIMMABLE-BOUNDARY-START(4296339149)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4296339149)
            
            static $h = 1371853;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296339149),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 1371853,
      "h": 4296339149,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296339149)
  ],
  "h": 1371853
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1371853)
        
        

        //--TRIMMABLE-BOUNDARY-START(2944717)
        $asm.$cls(`$PSrA.LCIDPS$1.PowerBeaconDeviceSettings`, ($self) => class PowerBeaconDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $self, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297912013)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297912013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297912013)
            
            //--TRIMMABLE-BOUNDARY-START(4297912013)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297912013)
            
            static $h = 2944717;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297912013),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2944717,
      "h": 4297912013,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297912013)
  ],
  "h": 2944717
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Settings${separator}PowerBeaconDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2944717)
        
        

        //--TRIMMABLE-BOUNDARY-START(2485965)
        $asm.$cls(`$PSrA.LCIDPS.IPowerBeaconRemoteService`, ($self) => class IPowerBeaconRemoteService
        {
            static $h = 2485965;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2485965
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$PSrA.LCIDPM.PowerBeaconServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$PSrA.LCIDPM.PowerBeaconServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$PSrA.LCIDPM.PowerBeaconServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$PSrA.LCIDPM.PowerBeaconServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$PSrA.LCIDPM.PowerBeaconServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$PSrA.LCIDPM.PowerBeaconServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$PSrA.LCIDPM.PowerBeaconServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$PSrA.LCIDPM.PowerBeaconServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Services${separator}IPowerBeaconRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2485965)
        
        

        //--TRIMMABLE-BOUNDARY-START(2420429)
        $asm.$cls(`$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler`, ($self) => class IPowerBeaconDeviceStatusHandler
        {
            static $h = 2420429;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2420429
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Services${separator}IPowerBeaconDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2420429)
        
        

        //--TRIMMABLE-BOUNDARY-START(2354893)
        $asm.$cls(`$PSrA.LCIDPS.IPowerBeaconDeviceHubClient`, ($self) => class IPowerBeaconDeviceHubClient
        {
            static $h = 2354893;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2354893
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Services${separator}IPowerBeaconDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2354893)
        
        

        //--TRIMMABLE-BOUNDARY-START(2682573)
        $asm.$cls(`$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings`, ($self) => class PowerBeaconDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297649869)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297649869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297649869)
            
            //--TRIMMABLE-BOUNDARY-START(4297649869)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297649869)
            
            static $h = 2682573;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297649869),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2682573,
      "h": 4297649869,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297649869)
  ],
  "h": 2682573
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Settings${separator}PowerBeaconDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2682573)
        
        

        //--TRIMMABLE-BOUNDARY-START(2158285)
        $asm.$cls(`$PSrA.LCIDP.PowerBeaconDeviceModelDefinition`, ($self) => class PowerBeaconDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4297125581)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297125581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297125581)
            
            //--TRIMMABLE-BOUNDARY-START(4297125581)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297125581)
            
            static $h = 2158285;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297125581),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2158285,
      "h": 4297125581,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297125581)
  ],
  "h": 2158285
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.PowerBeaconDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}PowerBeaconDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2158285)
        
        

        //--TRIMMABLE-BOUNDARY-START(1502925)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconServiceModelTypeDescriptor`, ($self) => class PowerBeaconServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PSrA.LCIDPM.PowerBeaconServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296470221)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296470221);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PSrA.LCIDPM.PowerBeaconServiceModelTypeDescriptor.GenerateProperties($.$PSrA.LCIDPM.PowerBeaconServiceModel, this, factory);
                    }, $yGKeGh ??= {"r":65537,"n":"","d":1502925,"h":0,"f":17825794}), 0, "PowerBeaconServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.PowerBeacon\\Models_PowerBeaconServiceModel_LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconServiceModelTypeDescriptorBuilder.g.cs", "PowerBeaconServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296470221)
            
            //--TRIMMABLE-BOUNDARY-START(12886404813)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886404813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886404813)
            
            //--TRIMMABLE-BOUNDARY-START(17181372109)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181372109);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceModel, LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceSettings, LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceSendDataModel, LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconDeviceStatusHandler, LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconDeviceHubClient, LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181372109)
            
            //--TRIMMABLE-BOUNDARY-START(8591437517)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591437517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PSrA.LCIDPM.PowerBeaconServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PSrA.LCIDPM.PowerBeaconServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPM.PowerBeaconServiceModel)))
                {
                    /*var*/ let result = $.$PSrA.LCIDPM.PowerBeaconServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPM.PowerBeaconServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PSrA.LCIDPM.PowerBeaconServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPM.PowerBeaconServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591437517)
            
            static $h = 1502925;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PSrA.LCIDPM.PowerBeaconServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886404813),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1502925,
      "h": 12886404813,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886404813),
//--TRIMMABLE-BOUNDARY-START(17181372109),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1371853,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1502925,
      "h": 17181372109,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181372109),
//--TRIMMABLE-BOUNDARY-START(8591437517),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1371853,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1502925,
      "h": 8591437517,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591437517)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296470221),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1502925,
      "h": 4296470221,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296470221)
  ],
  "h": 1502925
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PSrA.LCIDPM.PowerBeaconServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1502925)
        
        

        //--TRIMMABLE-BOUNDARY-START(2813645)
        $asm.$cls(`$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettingsTypeDescriptor`, ($self) => class PowerBeaconDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297780941)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297780941);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, this, factory);
                    }, $XMpRde ??= {"r":65537,"n":"","d":2813645,"h":0,"f":17825794}), 0, "PowerBeaconDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.PowerBeacon\\Settings_PowerBeaconDeviceHardwareSettings_LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "PowerBeaconDeviceHardwareSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297780941)
            
            //--TRIMMABLE-BOUNDARY-START(12887715533)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887715533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887715533)
            
            //--TRIMMABLE-BOUNDARY-START(17182682829)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182682829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceModel, LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceSettings, LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceSendDataModel, LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconDeviceStatusHandler, LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconDeviceHubClient, LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).iSmartDeviceHardwareSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182682829)
            
            //--TRIMMABLE-BOUNDARY-START(8592748237)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592748237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592748237)
            
            static $h = 2813645;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887715533),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2813645,
      "h": 12887715533,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887715533),
//--TRIMMABLE-BOUNDARY-START(17182682829),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2682573,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2813645,
      "h": 17182682829,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182682829),
//--TRIMMABLE-BOUNDARY-START(8592748237),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2682573,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2813645,
      "h": 8592748237,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592748237)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297780941),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2813645,
      "h": 4297780941,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297780941)
  ],
  "h": 2813645
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Settings${separator}PowerBeaconDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2813645)
        
        

        //--TRIMMABLE-BOUNDARY-START(454349)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconDeviceModelTypeDescriptor`, ($self) => class PowerBeaconDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PSrA.LCIDPM.PowerBeaconDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295421645)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295421645);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PSrA.LCIDPM.PowerBeaconDeviceModelTypeDescriptor.GenerateProperties($.$PSrA.LCIDPM.PowerBeaconDeviceModel, this, factory);
                    }, $DhSoBg ??= {"r":65537,"n":"","d":454349,"h":0,"f":17825794}), 0, "PowerBeaconDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.PowerBeacon\\Models_PowerBeaconDeviceModel_LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceModelTypeDescriptorBuilder.g.cs", "PowerBeaconDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295421645)
            
            //--TRIMMABLE-BOUNDARY-START(12885356237)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885356237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885356237)
            
            //--TRIMMABLE-BOUNDARY-START(17180323533)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180323533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceModel, LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceSettings, LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceSendDataModel, LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconDeviceStatusHandler, LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconDeviceHubClient, LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180323533)
            
            //--TRIMMABLE-BOUNDARY-START(8590388941)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590388941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PSrA.LCIDPM.PowerBeaconDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPM.PowerBeaconDeviceModel)))
                {
                    /*var*/ let result = $.$PSrA.LCIDPM.PowerBeaconDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPM.PowerBeaconDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPM.PowerBeaconDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590388941)
            
            static $h = 454349;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PSrA.LCIDPM.PowerBeaconDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885356237),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 454349,
      "h": 12885356237,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885356237),
//--TRIMMABLE-BOUNDARY-START(17180323533),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 323277,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 454349,
      "h": 17180323533,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180323533),
//--TRIMMABLE-BOUNDARY-START(8590388941),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 323277,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 454349,
      "h": 8590388941,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590388941)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295421645),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 454349,
      "h": 4295421645,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295421645)
  ],
  "h": 454349
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PSrA.LCIDPM.PowerBeaconDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(454349)
        
        

        //--TRIMMABLE-BOUNDARY-START(3075789)
        $asm.$cls(`$PSrA.LCIDPS$1.PowerBeaconDeviceSettingsTypeDescriptor`, ($self) => class PowerBeaconDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298043085)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298043085);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettingsTypeDescriptor.GenerateProperties($.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, this, factory);
                    }, $kLNFfc ??= {"r":65537,"n":"","d":3075789,"h":0,"f":17825794}), 0, "PowerBeaconDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.PowerBeacon\\Settings_PowerBeaconDeviceSettings_LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceSettingsTypeDescriptorBuilder.g.cs", "PowerBeaconDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298043085)
            
            //--TRIMMABLE-BOUNDARY-START(12887977677)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887977677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887977677)
            
            //--TRIMMABLE-BOUNDARY-START(17182944973)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182944973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceModel, LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceSettings, LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceSendDataModel, LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconDeviceStatusHandler, LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconDeviceHubClient, LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).iSmartDeviceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182944973)
            
            //--TRIMMABLE-BOUNDARY-START(8593010381)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593010381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings)))
                {
                    /*var*/ let result = $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593010381)
            
            static $h = 3075789;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887977677),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3075789,
      "h": 12887977677,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887977677),
//--TRIMMABLE-BOUNDARY-START(17182944973),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2944717,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3075789,
      "h": 17182944973,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182944973),
//--TRIMMABLE-BOUNDARY-START(8593010381),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2944717,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3075789,
      "h": 8593010381,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593010381)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298043085),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3075789,
      "h": 4298043085,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298043085)
  ],
  "h": 3075789
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Settings${separator}PowerBeaconDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3075789)
        
        

        //--TRIMMABLE-BOUNDARY-START(978637)
        $asm.$cls(`$PSrA.LCIDPM.PowerBeaconDeviceScopeModelTypeDescriptor`, ($self) => class PowerBeaconDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295945933)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295945933);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModelTypeDescriptor.GenerateProperties($.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, this, factory);
                    }, $dVqDvj ??= {"r":65537,"n":"","d":978637,"h":0,"f":17825794}), 0, "PowerBeaconDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.PowerBeacon\\Models_PowerBeaconDeviceScopeModel_LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceScopeModelTypeDescriptorBuilder.g.cs", "PowerBeaconDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295945933)
            
            //--TRIMMABLE-BOUNDARY-START(12885880525)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885880525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885880525)
            
            //--TRIMMABLE-BOUNDARY-START(17180847821)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180847821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceModel, LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceSettings, LivingThing.Core.IOT.Devices.PowerBeacon.Settings.PowerBeaconDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceSendDataModel, LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconDeviceStatusHandler, LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconDeviceHubClient, LivingThing.Core.IOT.Devices.PowerBeacon.Services.IPowerBeaconRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180847821)
            
            //--TRIMMABLE-BOUNDARY-START(8590913229)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590913229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel)))
                {
                    /*var*/ let result = $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590913229)
            
            static $h = 978637;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885880525),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 978637,
      "h": 12885880525,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885880525),
//--TRIMMABLE-BOUNDARY-START(17180847821),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 847565,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 978637,
      "h": 17180847821,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180847821),
//--TRIMMABLE-BOUNDARY-START(8590913229),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 847565,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 978637,
      "h": 8590913229,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590913229)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295945933),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 978637,
      "h": 4295945933,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295945933)
  ],
  "h": 978637
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.Models.PowerBeaconDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}Models${separator}PowerBeaconDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(978637)
        
        

        //--TRIMMABLE-BOUNDARY-START(1961677)
        $asm.$cls(`$PSrA.LCIDP.PowerBeaconDevice`, ($self) => class PowerBeaconDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$PSrA.LCIDPMS.PowerBeaconStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4296928973)
            $ctor$2(/*IIOTDeviceFamily<PowerBeaconDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*PowerBeaconDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296928973);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296928973)
            
            static $h = 1961677;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDP.PowerBeaconDevice, $.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$PSrA.LCIDPMS.PowerBeaconStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296928973),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$PSrA.LCIDP.PowerBeaconDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 323277
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1961677,
      "h": 4296928973,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296928973)
  ],
  "h": 1961677
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.PowerBeaconDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}PowerBeaconDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1961677)
        
        

        //--TRIMMABLE-BOUNDARY-START(2027213)
        $asm.$cls(`$PSrA.LCIDP.PowerBeaconDeviceDefinition`, ($self) => class PowerBeaconDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDP.PowerBeaconDevice, $.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$PSrA.LCIDPMS.PowerBeaconStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296994509)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296994509);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296994509)
            
            //--TRIMMABLE-BOUNDARY-START(4296994509)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296994509)
            
            static $h = 2027213;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDP.PowerBeaconDevice, $.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$PSrA.LCIDPMS.PowerBeaconStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296994509),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2027213,
      "h": 4296994509,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296994509)
  ],
  "h": 2027213
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.PowerBeaconDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}PowerBeaconDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2027213)
        
        

        //--TRIMMABLE-BOUNDARY-START(2092749)
        $asm.$cls(`$PSrA.LCIDP.PowerBeaconDeviceFamily`, ($self) => class PowerBeaconDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDP.PowerBeaconDevice, $.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4297060045)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<PowerBeaconDeviceReceivedDataModel, PowerBeaconDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<PowerBeaconDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297060045);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297060045)
            
            //--TRIMMABLE-BOUNDARY-START(8592027341)
            /*Type */ get DeviceBroadcastSendMessageEnumType()
            {
                return $.$PSrA.LCIDPS$1.PowerBeaconBroadcastPeerMessages.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8592027341)
            
            static $h = 2092749;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$PSrA.LCIDP.PowerBeaconDevice, $.$PSrA.LCIDPM.PowerBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$PSrA.LCIDPM.PowerBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$PSrA.LCIDPM.PowerBeaconDeviceModel, $.$PSrA.LCIDPS$1.PowerBeaconDeviceSettings, $.$PSrA.LCIDPS$1.PowerBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel, $.$PSrA.LCIDPS.IPowerBeaconDeviceStatusHandler, $.$PSrA.LCIDPS.IPowerBeaconDeviceHubClient, $.$PSrA.LCIDPS.IPowerBeaconRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8592027341),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181961933,
        "f": 50364417
      },
      "n": "DeviceBroadcastSendMessageEnumType",
      "d": 2092749,
      "h": 8592027341,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592027341)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297060045),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$PSrA.LCIDPM.PowerBeaconDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$PSrA.LCIDPM.PowerBeaconDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2092749,
      "h": 4297060045,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297060045)
  ],
  "h": 2092749
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$PSrA.LCIDP.PowerBeaconDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$PSrA.LCIDP.PowerBeaconDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.PowerBeacon.PowerBeaconDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}PowerBeacon${separator}PowerBeaconDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2092749)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.DynamicExpresso.Core", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Devices"));
})();
//--TRIMMABLE-BOUNDARY-END(61133)
