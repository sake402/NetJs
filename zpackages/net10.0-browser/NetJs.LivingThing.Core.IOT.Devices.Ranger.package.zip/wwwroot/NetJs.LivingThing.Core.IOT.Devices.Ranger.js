
//--TRIMMABLE-BOUNDARY-START(60216)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej, $NzWm) {
    "use strict";
    let _;
    let $AtEwCd;
    let $xDzWMk;
    let $dcHyAh;
    let $yYnXQg;
    let $cJglXh;
    let $oheuHc;
    let $NecJyj;
    let $SEOotd;
    let $zcdFqe;
    let $dgwTBa;
    let $SvpoOe;
    let $nQxogi;
    let $rVLpJf;
    let $PNtaKg;
    let $nggNpe;
    let $KlmTlg;
    let $nYopSi;
    let $PMiNMk;
    let $Jvsnrj;
    let $dvzAuk;
    let $KxJeVb;
    let $OhUiji;
    let $bEjPBh;
    let $REFrDg;
    let $JUBGij;
    let $kMXgIk;
    let $cpMYci;
    let $XLJUld;
    let $nlLGge;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.Ranger", 
    {
  "h": 60216,
  "f": "LivingThing.Core.IOT.Devices.Ranger",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.Ranger",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.Ranger",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5SYW5nZXIuUmFuZ2VyRGV2aWNlIjogew0KICAgICAgIkNhdGVnb3JpZXMiOiBbICJTZW5zb3JzIiwgIlRhbmtUYWxrcyIgXSwNCiAgICAgICJOYW1lIjogIlJhbmdlciIsDQogICAgICAiQWxpYXMiOiBbICJSYW5nZXIiIF0sDQogICAgICAiSWNvbiI6IHsgIk5hbWUiOiAibWRpIG1kaS1ydWxlciIgfSwNCiAgICAgICJUaGVtZUNvbG9yIjogIiM3NjQyOGEiLA0KICAgICAgIkRlc2NyaXB0aW9uIjogIk1lYXN1cmUgaGVpZ2h0IG9mIGxpcXVpZCBpbiBhIHRhbmssIGZyb20gdGhlIHRvcCBsaWQuIE1lYXN1cmUgdGhlIGRpc3RhbmNlIGZyb20gYSByZWZlcmVuY2UgcG9pbnQgdG8gYW4gb2JzdGFjbGUuIiwNCiAgICAgICJCYW5uZXJJbWFnZSI6ICJ\u002BL2ltZy9kZXZpY2UuanBnIiwNCiAgICAgICJTdGF0dXNOYW1lcyI6ICIuTW9kZWwuU3RhdHVzLlN0YXR1cy5IZWlnaHQsLk1vZGVsLlN0YXR1cy5TdGF0dXMuVGVtcGVyYXR1cmUsLk1vZGVsLlN0YXR1cy5TdGF0dXMuQmF0dGVyeSIsDQogICAgICAiU2VjdXJpdGllcyI6ICJDaGFsbGVuZ2VIYW5kU2hha2VBdXRoZW50aWNhdGlvblByb3RvY29sLEFkdmFuY2VkRW5jcnlwdGlvblN0YW5kYXJkLEVsbGlwdGljQ3VydmVGaXJtd2FyZVVwZGF0ZVNpZ25pbmciDQogICAgfQ0KICB9DQp9"
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(3337016)
        $asm.$cls(`$wDws.LCIDRS$2.RangerDeviceStatesCustomAttributesProvider`, ($self) => class RangerDeviceStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298304312)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298304312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$3.IOTDeviceStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298304312)
            
            static $h = 3337016;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298304312),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3337016,
      "h": 4298304312,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298304312)
  ],
  "h": 3337016
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.States.RangerDeviceStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}States${separator}RangerDeviceStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3337016)
        
        

        //--TRIMMABLE-BOUNDARY-START(584504)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceModelCustomAttributesProvider`, ($self) => class RangerDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295551800)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295551800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295551800)
            
            static $h = 584504;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295551800),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 584504,
      "h": 4295551800,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295551800)
  ],
  "h": 584504
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(584504)
        
        

        //--TRIMMABLE-BOUNDARY-START(322360)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceCommandModelCustomAttributesProvider`, ($self) => class RangerDeviceCommandModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295289656)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295289656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICM.IOTDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295289656)
            
            static $h = 322360;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295289656),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 322360,
      "h": 4295289656,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295289656)
  ],
  "h": 322360
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceCommandModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceCommandModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(322360)
        
        

        //--TRIMMABLE-BOUNDARY-START(846648)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class RangerDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295813944)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295813944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$XBGm.LCICMGR.RangerReceivedStatusModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295813944)
            
            static $h = 846648;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295813944),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 846648,
      "h": 4295813944,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295813944)
  ],
  "h": 846648
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(846648)
        
        

        //--TRIMMABLE-BOUNDARY-START(1370936)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceSendDataModelCustomAttributesProvider`, ($self) => class RangerDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296338232)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296338232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceSendDataModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296338232)
            
            static $h = 1370936;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296338232),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1370936,
      "h": 4296338232,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296338232)
  ],
  "h": 1370936
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1370936)
        
        

        //--TRIMMABLE-BOUNDARY-START(1895224)
        $asm.$cls(`$wDws.LCIDRM.RangerServiceModelCustomAttributesProvider`, ($self) => class RangerServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296862520)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296862520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296862520)
            
            static $h = 1895224;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296862520),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1895224,
      "h": 4296862520,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296862520)
  ],
  "h": 1895224
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1895224)
        
        

        //--TRIMMABLE-BOUNDARY-START(2812728)
        $asm.$cls(`$wDws.LCIDRS$1.RangerDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class RangerDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297780024)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297780024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297780024)
            
            static $h = 2812728;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297780024),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2812728,
      "h": 4297780024,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297780024)
  ],
  "h": 2812728
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Settings${separator}RangerDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2812728)
        
        

        //--TRIMMABLE-BOUNDARY-START(453432)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceCommandModelTypeDescriptorBuilder`, ($self) => class RangerDeviceCommandModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590388024)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590388024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$wDws.LCIDRM.RangerDeviceCommandModelTypeDescriptor()
                        const $t1 = $.$wDws.LCIDRM.RangerDeviceCommandModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceCommandModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $AtEwCd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":453432,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$wDws.LCIDRM.RangerDeviceCommandModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590388024)
            
            //--TRIMMABLE-BOUNDARY-START(4295420728)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295420728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295420728)
            
            //--TRIMMABLE-BOUNDARY-START(4295420728)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295420728)
            
            static $h = 453432;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590388024),
    {
      "r": 65537,
      "n": "Register",
      "d": 453432,
      "h": 8590388024,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590388024)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295420728),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 453432,
      "h": 4295420728,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295420728)
  ],
  "h": 453432
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceCommandModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceCommandModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(453432)
        
        

        //--TRIMMABLE-BOUNDARY-START(1633080)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceStatusModelCustomAttributesProvider`, ($self) => class RangerDeviceStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296600376)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296600376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICM.IOTDeviceStatusModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296600376)
            
            static $h = 1633080;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296600376),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1633080,
      "h": 4296600376,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296600376)
  ],
  "h": 1633080
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1633080)
        
        

        //--TRIMMABLE-BOUNDARY-START(3074872)
        $asm.$cls(`$wDws.LCIDRS$1.RangerDeviceSettingsCustomAttributesProvider`, ($self) => class RangerDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298042168)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298042168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298042168)
            
            static $h = 3074872;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298042168),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3074872,
      "h": 4298042168,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298042168)
  ],
  "h": 3074872
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Settings${separator}RangerDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3074872)
        
        

        //--TRIMMABLE-BOUNDARY-START(1108792)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceScopeModelCustomAttributesProvider`, ($self) => class RangerDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296076088)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296076088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296076088)
            
            static $h = 1108792;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296076088),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1108792,
      "h": 4296076088,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296076088)
  ],
  "h": 1108792
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1108792)
        
        

        //--TRIMMABLE-BOUNDARY-START(977720)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class RangerDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590912312)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590912312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$wDws.LCIDRM.RangerDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$wDws.LCIDRM.RangerDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $dcHyAh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":977720,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$wDws.LCIDRM.RangerDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590912312)
            
            //--TRIMMABLE-BOUNDARY-START(4295945016)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295945016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295945016)
            
            //--TRIMMABLE-BOUNDARY-START(4295945016)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295945016)
            
            static $h = 977720;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590912312),
    {
      "r": 65537,
      "n": "Register",
      "d": 977720,
      "h": 8590912312,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590912312)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295945016),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 977720,
      "h": 4295945016,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295945016)
  ],
  "h": 977720
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(977720)
        
        

        //--TRIMMABLE-BOUNDARY-START(191288)
        $asm.$cls(`$wDws.LCIDR.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295158584)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295158584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$wDws.LCIDRM.RangerDeviceCommandModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$wDws.LCIDRM.RangerDeviceCommandModelCustomAttributesProvider, $.$wDws.LCIDRM.RangerDeviceCommandModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$wDws.LCIDRM.RangerDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$wDws.LCIDRM.RangerDeviceModelCustomAttributesProvider, $.$wDws.LCIDRM.RangerDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$wDws.LCIDRM.RangerDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$wDws.LCIDRM.RangerDeviceReceivedDataModelCustomAttributesProvider, $.$wDws.LCIDRM.RangerDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$wDws.LCIDRM.RangerDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$wDws.LCIDRM.RangerDeviceScopeModelCustomAttributesProvider, $.$wDws.LCIDRM.RangerDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$wDws.LCIDRM.RangerDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$wDws.LCIDRM.RangerDeviceSendDataModelCustomAttributesProvider, $.$wDws.LCIDRM.RangerDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$wDws.LCIDRM.RangerServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$wDws.LCIDRM.RangerServiceModelCustomAttributesProvider, $.$wDws.LCIDRM.RangerServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$wDws.LCIDRS$1.RangerDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$wDws.LCIDRS$1.RangerDeviceHardwareSettingsCustomAttributesProvider, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$wDws.LCIDRS$1.RangerDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$wDws.LCIDRS$1.RangerDeviceSettingsCustomAttributesProvider, $.$wDws.LCIDRS$1.RangerDeviceSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$wDws.LCIDRM.RangerDeviceStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$wDws.LCIDRM.RangerDeviceStatusModelCustomAttributesProvider, $.$wDws.LCIDRM.RangerDeviceStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$wDws.LCIDRS$2.RangerDeviceStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$wDws.LCIDRS$2.RangerDeviceStatesCustomAttributesProvider, $.$wDws.LCIDRS$2.RangerDeviceStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295158584)
            
            static $h = 191288;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295158584),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 191288,
      "h": 4295158584,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295158584)
  ],
  "h": 191288
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(191288)
        
        

        //--TRIMMABLE-BOUNDARY-START(715576)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceModelTypeDescriptorBuilder`, ($self) => class RangerDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590650168)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590650168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$wDws.LCIDRM.RangerDeviceModelTypeDescriptor()
                        const $t1 = $.$wDws.LCIDRM.RangerDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $NecJyj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":715576,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$wDws.LCIDRM.RangerDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590650168)
            
            //--TRIMMABLE-BOUNDARY-START(4295682872)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295682872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295682872)
            
            //--TRIMMABLE-BOUNDARY-START(4295682872)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295682872)
            
            static $h = 715576;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590650168),
    {
      "r": 65537,
      "n": "Register",
      "d": 715576,
      "h": 8590650168,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590650168)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295682872),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 715576,
      "h": 4295682872,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295682872)
  ],
  "h": 715576
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(715576)
        
        

        //--TRIMMABLE-BOUNDARY-START(3533624)
        $asm.$cls(`$wDws.LCIDR.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298500920)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298500920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$wDws.LCIDRM.RangerDeviceCommandModelTypeDescriptorBuilder.Register();
                $.$wDws.LCIDRM.RangerDeviceModelTypeDescriptorBuilder.Register();
                $.$wDws.LCIDRM.RangerDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$wDws.LCIDRM.RangerDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$wDws.LCIDRM.RangerDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$wDws.LCIDRM.RangerServiceModelTypeDescriptorBuilder.Register();
                $.$wDws.LCIDRS$1.RangerDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$wDws.LCIDRS$1.RangerDeviceSettingsTypeDescriptorBuilder.Register();
                $.$wDws.LCIDRM.RangerDeviceStatusModelTypeDescriptorBuilder.Register();
                $.$wDws.LCIDRS$2.RangerDeviceStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298500920)
            
            static $h = 3533624;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298500920),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3533624,
      "h": 4298500920,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298500920)
  ],
  "h": 3533624
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3533624)
        
        

        //--TRIMMABLE-BOUNDARY-START(3468088)
        $asm.$cls(`$wDws.LCIDRS$2.RangerDeviceStatesTypeDescriptorBuilder`, ($self) => class RangerDeviceStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593402680)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593402680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$wDws.LCIDRS$2.RangerDeviceStatesTypeDescriptor()
                        const $t1 = $.$wDws.LCIDRS$2.RangerDeviceStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Ranger.States.RangerDeviceStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $cJglXh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3468088,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$wDws.LCIDRS$2.RangerDeviceStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593402680)
            
            //--TRIMMABLE-BOUNDARY-START(4298435384)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298435384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298435384)
            
            //--TRIMMABLE-BOUNDARY-START(4298435384)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298435384)
            
            static $h = 3468088;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593402680),
    {
      "r": 65537,
      "n": "Register",
      "d": 3468088,
      "h": 8593402680,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593402680)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298435384),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3468088,
      "h": 4298435384,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298435384)
  ],
  "h": 3468088
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.States.RangerDeviceStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}States${separator}RangerDeviceStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3468088)
        
        

        //--TRIMMABLE-BOUNDARY-START(2026296)
        $asm.$cls(`$wDws.LCIDRM.RangerServiceModelTypeDescriptorBuilder`, ($self) => class RangerServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591960888)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591960888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$wDws.LCIDRM.RangerServiceModelTypeDescriptor()
                        const $t1 = $.$wDws.LCIDRM.RangerServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Ranger.Models.RangerServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $zcdFqe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2026296,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$wDws.LCIDRM.RangerServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591960888)
            
            //--TRIMMABLE-BOUNDARY-START(4296993592)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296993592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296993592)
            
            //--TRIMMABLE-BOUNDARY-START(4296993592)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296993592)
            
            static $h = 2026296;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591960888),
    {
      "r": 65537,
      "n": "Register",
      "d": 2026296,
      "h": 8591960888,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591960888)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296993592),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2026296,
      "h": 4296993592,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296993592)
  ],
  "h": 2026296
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2026296)
        
        

        //--TRIMMABLE-BOUNDARY-START(3205944)
        $asm.$cls(`$wDws.LCIDRS$1.RangerDeviceSettingsTypeDescriptorBuilder`, ($self) => class RangerDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593140536)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593140536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$wDws.LCIDRS$1.RangerDeviceSettingsTypeDescriptor()
                        const $t1 = $.$wDws.LCIDRS$1.RangerDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $rVLpJf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3205944,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$wDws.LCIDRS$1.RangerDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593140536)
            
            //--TRIMMABLE-BOUNDARY-START(4298173240)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298173240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298173240)
            
            //--TRIMMABLE-BOUNDARY-START(4298173240)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298173240)
            
            static $h = 3205944;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593140536),
    {
      "r": 65537,
      "n": "Register",
      "d": 3205944,
      "h": 8593140536,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593140536)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298173240),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3205944,
      "h": 4298173240,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298173240)
  ],
  "h": 3205944
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Settings${separator}RangerDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3205944)
        
        

        //--TRIMMABLE-BOUNDARY-START(1239864)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceScopeModelTypeDescriptorBuilder`, ($self) => class RangerDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591174456)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591174456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$wDws.LCIDRM.RangerDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$wDws.LCIDRM.RangerDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $SvpoOe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1239864,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$wDws.LCIDRM.RangerDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591174456)
            
            //--TRIMMABLE-BOUNDARY-START(4296207160)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296207160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296207160)
            
            //--TRIMMABLE-BOUNDARY-START(4296207160)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296207160)
            
            static $h = 1239864;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591174456),
    {
      "r": 65537,
      "n": "Register",
      "d": 1239864,
      "h": 8591174456,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591174456)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296207160),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1239864,
      "h": 4296207160,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296207160)
  ],
  "h": 1239864
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1239864)
        
        

        //--TRIMMABLE-BOUNDARY-START(1764152)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceStatusModelTypeDescriptorBuilder`, ($self) => class RangerDeviceStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591698744)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591698744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$wDws.LCIDRM.RangerDeviceStatusModelTypeDescriptor()
                        const $t1 = $.$wDws.LCIDRM.RangerDeviceStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $nggNpe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1764152,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$wDws.LCIDRM.RangerDeviceStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591698744)
            
            //--TRIMMABLE-BOUNDARY-START(4296731448)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296731448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296731448)
            
            //--TRIMMABLE-BOUNDARY-START(4296731448)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296731448)
            
            static $h = 1764152;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591698744),
    {
      "r": 65537,
      "n": "Register",
      "d": 1764152,
      "h": 8591698744,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591698744)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296731448),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1764152,
      "h": 4296731448,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296731448)
  ],
  "h": 1764152
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1764152)
        
        

        //--TRIMMABLE-BOUNDARY-START(2943800)
        $asm.$cls(`$wDws.LCIDRS$1.RangerDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class RangerDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592878392)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592878392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$wDws.LCIDRS$1.RangerDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$wDws.LCIDRS$1.RangerDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Jvsnrj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2943800,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$wDws.LCIDRS$1.RangerDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592878392)
            
            //--TRIMMABLE-BOUNDARY-START(4297911096)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297911096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297911096)
            
            //--TRIMMABLE-BOUNDARY-START(4297911096)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297911096)
            
            static $h = 2943800;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592878392),
    {
      "r": 65537,
      "n": "Register",
      "d": 2943800,
      "h": 8592878392,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592878392)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297911096),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2943800,
      "h": 4297911096,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297911096)
  ],
  "h": 2943800
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Settings${separator}RangerDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2943800)
        
        

        //--TRIMMABLE-BOUNDARY-START(1502008)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class RangerDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591436600)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591436600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$wDws.LCIDRM.RangerDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$wDws.LCIDRM.RangerDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $KxJeVb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1502008,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$wDws.LCIDRM.RangerDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591436600)
            
            //--TRIMMABLE-BOUNDARY-START(4296469304)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296469304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296469304)
            
            //--TRIMMABLE-BOUNDARY-START(4296469304)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296469304)
            
            static $h = 1502008;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591436600),
    {
      "r": 65537,
      "n": "Register",
      "d": 1502008,
      "h": 8591436600,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591436600)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296469304),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1502008,
      "h": 4296469304,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296469304)
  ],
  "h": 1502008
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1502008)
        
        

        //--TRIMMABLE-BOUNDARY-START(125752)
        $asm.$cls(`$wDws.LCIDR.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17179994936)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17179994936)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295093048)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295093048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295093048)
            
            //--TRIMMABLE-BOUNDARY-START(4295093048)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295093048)
            
            static $h = 125752;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17179994936),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885027640,
        "f": 50331649
      },
      "n": "Paths",
      "d": 125752,
      "h": 17179994936,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17179994936)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295093048),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 125752,
      "h": 4295093048,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295093048)
  ],
  "h": 125752
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(125752)
        
        

        //--TRIMMABLE-BOUNDARY-START(2485048)
        $asm.$cls(`$wDws.LCIDR.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592419640)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592419640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$wDws.LCIDR.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceStatusModel), $.$wDws.LCIDR.RangerDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$wDws.LCIDR.RangerDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$wDws.LCIDR.RangerDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$NzWm.LCIDGM$1.IGatewayModBusDeviceConfiguration$$($.$wDws.LCIDR.RangerDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$wDws.LCIDR.RangerDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$wDws.LCIDR.RangerDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$wDws.LCIDR.RangerDeviceFamily, x);
                }, $bEjPBh ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":2485048,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$wDws.LCIDR.RangerDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$wDws.LCIDR.RangerDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $REFrDg ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":2485048,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$wDws.LCIDR.RangerDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$wDws.LCIDR.RangerDeviceFamily, x);
                }, $JUBGij ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$wDws.LCIDR.RangerDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":2485048,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$NzWm.LCIDGM$1.IGatewayModBusDeviceConfiguration$$($.$wDws.LCIDR.RangerDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$wDws.LCIDR.RangerDeviceFamily, x);
                }, $kMXgIk ??= {"r":$.$NzWm.LCIDGM$1.IGatewayModBusDeviceConfiguration$$($.$wDws.LCIDR.RangerDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":2485048,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fPer.LCFCD.IDefaultValuesProvider$$($.$NzWm.LCIDGC.ModBusInputRegisterConfiguration), $.$NzWm.LCIDGS.GatewayChannelledDeviceModBusConfigurationProvider$$($.$wDws.LCIDR.RangerDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler$$($.$fPer.LCFCDM.Length), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$wDws.LCIDR.RangerDeviceStatusHandler, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$wDws.LCIDRS.IRangerDeviceStatusHandler))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$wDws.LCIDR.RangerDeviceStatusHandler, x);
                }, $cpMYci ??= {"r":2616120,"p":[{"n":"x","p":327718}],"n":"","d":2485048,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$wDws.LCIDR.RangerDeviceStatusHandler, x);
                }, $XLJUld ??= {"r":$.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":2485048,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler$$($.$fPer.LCFCDM.Length)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$wDws.LCIDR.RangerDeviceStatusHandler, x);
                }, $nlLGge ??= {"r":$.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler$$($.$fPer.LCFCDM.Length).$h,"p":[{"n":"x","p":327718}],"n":"","d":2485048,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel), $.$XBGm.LCICPB.BinaryPacketProtocol$$$$($.$wDws.LCIDR.RangerDevice, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICPB.BinaryPacketProtocolDecoder$$$($.$wDws.LCIDR.RangerDevice, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICPB.BinaryPacketProtocolEncoder$$$($.$wDws.LCIDR.RangerDevice, $.$wDws.LCIDRM.RangerDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICPB.BinaryPacketProtocolCommands$$($.$wDws.LCIDR.RangerDevice), services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592419640)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wDws.LCIDR.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297452344)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297452344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297452344)
            
            //--TRIMMABLE-BOUNDARY-START(4297452344)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297452344)
            
            static $h = 2485048;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592419640),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2485048,
      "h": 8592419640,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592419640)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297452344),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2485048,
      "h": 4297452344,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297452344)
  ],
  "h": 2485048
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2485048)
        
        

        //--TRIMMABLE-BOUNDARY-START(1305400)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceSendDataModel`, ($self) => class RangerDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceSendDataModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296272696)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296272696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296272696)
            
            //--TRIMMABLE-BOUNDARY-START(4296272696)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296272696)
            
            static $h = 1305400;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceSendDataModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296272696),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1305400,
      "h": 4296272696,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296272696)
  ],
  "h": 1305400
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1305400)
        
        

        //--TRIMMABLE-BOUNDARY-START(3271480)
        $asm.$cls(`$wDws.LCIDRS$2.RangerDeviceStates`, ($self) => class RangerDeviceStates extends $.$XBGm.LCICS$3.IOTDeviceStates
        {
            //--TRIMMABLE-BOUNDARY-START(4298238776)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298238776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298238776)
            
            //--TRIMMABLE-BOUNDARY-START(4298238776)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4298238776)
            
            static $h = 3271480;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$3.IOTDeviceStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298238776),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3271480,
      "h": 4298238776,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298238776)
  ],
  "h": 3271480
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.States.RangerDeviceStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}States${separator}RangerDeviceStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3271480)
        
        

        //--TRIMMABLE-BOUNDARY-START(256824)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceCommandModel`, ($self) => class RangerDeviceCommandModel extends $.$XBGm.LCICM.IOTDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295224120)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295224120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295224120)
            
            //--TRIMMABLE-BOUNDARY-START(4295224120)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295224120)
            
            static $h = 256824;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICM.IOTDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295224120),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 256824,
      "h": 4295224120,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295224120)
  ],
  "h": 256824
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceCommandModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceCommandModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(256824)
        
        

        //--TRIMMABLE-BOUNDARY-START(1567544)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceStatusModel`, ($self) => class RangerDeviceStatusModel extends $.$XBGm.LCICM.IOTDeviceStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(30066338616)
            /*RangerReceivedStatusModel*/ Status = null;
            //--TRIMMABLE-BOUNDARY-END(30066338616)
            
            //--TRIMMABLE-BOUNDARY-START(8591502136)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591502136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591502136)
            
            //--TRIMMABLE-BOUNDARY-START(8591502136)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8591502136)
            
            static $h = 1567544;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICM.IOTDeviceStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066338616),
    {
      "p": 34051473,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181436728,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25771371320,
        "f": 83886081
      },
      "n": "Status",
      "d": 1567544,
      "h": 30066338616,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066338616)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591502136),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1567544,
      "h": 8591502136,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591502136)
  ],
  "h": 1567544
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1567544)
        
        

        //--TRIMMABLE-BOUNDARY-START(1436472)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceSendDataModelTypeDescriptor`, ($self) => class RangerDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296403768)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296403768);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$wDws.LCIDRM.RangerDeviceSendDataModelTypeDescriptor.GenerateProperties($.$wDws.LCIDRM.RangerDeviceSendDataModel, this, factory);
                    }, $OhUiji ??= {"r":65537,"n":"","d":1436472,"h":0,"f":17825794}), 0, "RangerDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Ranger\\Models_RangerDeviceSendDataModel_LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceSendDataModelTypeDescriptorBuilder.g.cs", "RangerDeviceSendDataModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296403768)
            
            //--TRIMMABLE-BOUNDARY-START(12886338360)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886338360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886338360)
            
            //--TRIMMABLE-BOUNDARY-START(17181305656)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181305656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceSendDataModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceSendDataModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181305656)
            
            //--TRIMMABLE-BOUNDARY-START(8591371064)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591371064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$wDws.LCIDRM.RangerDeviceSendDataModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$wDws.LCIDRM.RangerDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$wDws.LCIDRM.RangerDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$wDws.LCIDRM.RangerDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591371064)
            
            static $h = 1436472;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886338360),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1436472,
      "h": 12886338360,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886338360),
//--TRIMMABLE-BOUNDARY-START(17181305656),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1305400,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1436472,
      "h": 17181305656,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181305656),
//--TRIMMABLE-BOUNDARY-START(8591371064),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1305400,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1436472,
      "h": 8591371064,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591371064)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296403768),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1436472,
      "h": 4296403768,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296403768)
  ],
  "h": 1436472
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1436472)
        
        

        //--TRIMMABLE-BOUNDARY-START(3402552)
        $asm.$cls(`$wDws.LCIDRS$2.RangerDeviceStatesTypeDescriptor`, ($self) => class RangerDeviceStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRS$2.RangerDeviceStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4298369848)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298369848);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$wDws.LCIDRS$2.RangerDeviceStatesTypeDescriptor.GenerateProperties($.$wDws.LCIDRS$2.RangerDeviceStates, this, factory);
                    }, $oheuHc ??= {"r":65537,"n":"","d":3402552,"h":0,"f":17825794}), 0, "RangerDeviceStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Ranger\\States_RangerDeviceStates_LivingThing.Core.IOT.Devices.Ranger.States.RangerDeviceStatesTypeDescriptorBuilder.g.cs", "RangerDeviceStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298369848)
            
            //--TRIMMABLE-BOUNDARY-START(12888304440)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888304440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$3.IOTDeviceStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888304440)
            
            //--TRIMMABLE-BOUNDARY-START(17183271736)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.States.RangerDeviceStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183271736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.States.IOTDeviceStates?*/ let targetBase = _target;
                $.$XBGm.LCICS$3.IOTDeviceStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$3.IOTDeviceStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183271736)
            
            //--TRIMMABLE-BOUNDARY-START(8593337144)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.States.RangerDeviceStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593337144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$wDws.LCIDRS$2.RangerDeviceStates().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$wDws.LCIDRS$2.RangerDeviceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRS$2.RangerDeviceStates)))
                {
                    /*var*/ let result = $.$wDws.LCIDRS$2.RangerDeviceStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRS$2.RangerDeviceStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$wDws.LCIDRS$2.RangerDeviceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRS$2.RangerDeviceStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593337144)
            
            static $h = 3402552;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRS$2.RangerDeviceStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888304440),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3402552,
      "h": 12888304440,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888304440),
//--TRIMMABLE-BOUNDARY-START(17183271736),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3271480,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3402552,
      "h": 17183271736,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183271736),
//--TRIMMABLE-BOUNDARY-START(8593337144),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3271480,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3402552,
      "h": 8593337144,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593337144)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298369848),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3402552,
      "h": 4298369848,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298369848)
  ],
  "h": 3402552
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$wDws.LCIDRS$2.RangerDeviceStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.States.RangerDeviceStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}States${separator}RangerDeviceStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3402552)
        
        

        //--TRIMMABLE-BOUNDARY-START(387896)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceCommandModelTypeDescriptor`, ($self) => class RangerDeviceCommandModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295355192)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295355192);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$wDws.LCIDRM.RangerDeviceCommandModelTypeDescriptor.GenerateProperties($.$wDws.LCIDRM.RangerDeviceCommandModel, this, factory);
                    }, $xDzWMk ??= {"r":65537,"n":"","d":387896,"h":0,"f":17825794}), 0, "RangerDeviceCommandModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Ranger\\Models_RangerDeviceCommandModel_LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceCommandModelTypeDescriptorBuilder.g.cs", "RangerDeviceCommandModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295355192)
            
            //--TRIMMABLE-BOUNDARY-START(12885289784)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885289784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICM.IOTDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885289784)
            
            //--TRIMMABLE-BOUNDARY-START(17180257080)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceCommandModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180257080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICM.IOTDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICM.IOTDeviceCommandModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180257080)
            
            //--TRIMMABLE-BOUNDARY-START(8590322488)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceCommandModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590322488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$wDws.LCIDRM.RangerDeviceCommandModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$wDws.LCIDRM.RangerDeviceCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceCommandModel)))
                {
                    /*var*/ let result = $.$wDws.LCIDRM.RangerDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceCommandModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$wDws.LCIDRM.RangerDeviceCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceCommandModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590322488)
            
            static $h = 387896;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885289784),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 387896,
      "h": 12885289784,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885289784),
//--TRIMMABLE-BOUNDARY-START(17180257080),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 256824,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 387896,
      "h": 17180257080,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180257080),
//--TRIMMABLE-BOUNDARY-START(8590322488),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 256824,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 387896,
      "h": 8590322488,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590322488)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295355192),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 387896,
      "h": 4295355192,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295355192)
  ],
  "h": 387896
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceCommandModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceCommandModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceCommandModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(387896)
        
        

        //--TRIMMABLE-BOUNDARY-START(1698616)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceStatusModelTypeDescriptor`, ($self) => class RangerDeviceStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296665912)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296665912);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$wDws.LCIDRM.RangerDeviceStatusModelTypeDescriptor.GenerateProperties($.$wDws.LCIDRM.RangerDeviceStatusModel, this, factory);
                    }, $KlmTlg ??= {"r":65537,"n":"","d":1698616,"h":0,"f":17825794}), 0, "RangerDeviceStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Ranger\\Settings_RangerDeviceStatusModel_LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceStatusModelTypeDescriptorBuilder.g.cs", "RangerDeviceStatusModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296665912)
            
            //--TRIMMABLE-BOUNDARY-START(12886600504)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886600504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Status"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$wDws.LCIDRM.RangerDeviceStatusModel.$type, $.$discardRef(), "Status", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Status")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICMGR.RangerReceivedStatusModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Status";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$wDws.LCIDRM.RangerDeviceStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICMGR.RangerReceivedStatusModel, ($.$cast(target, $.$wDws.LCIDRM.RangerDeviceStatusModel)).Status);
                        }, $nYopSi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1698616,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$wDws.LCIDRM.RangerDeviceStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Status = value.AsReference($.$XBGm.LCICMGR.RangerReceivedStatusModel);
                        }, $PMiNMk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1698616,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICM.IOTDeviceStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886600504)
            
            //--TRIMMABLE-BOUNDARY-START(17181567800)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181567800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICM.IOTDeviceStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICM.IOTDeviceStatusModel));
                {
                    /*var*/ let _Status = _target.Status;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Status"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICMGR.RangerReceivedStatusModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Status, ($v) => _Status = $v, $.$XBGm.LCICMGR.RangerReceivedStatusModel)))
                    {
                        _target.Status = _Status;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181567800)
            
            //--TRIMMABLE-BOUNDARY-START(8591633208)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591633208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$wDws.LCIDRM.RangerDeviceStatusModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$wDws.LCIDRM.RangerDeviceStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceStatusModel)))
                {
                    /*var*/ let result = $.$wDws.LCIDRM.RangerDeviceStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$wDws.LCIDRM.RangerDeviceStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591633208)
            
            static $h = 1698616;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886600504),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1698616,
      "h": 12886600504,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886600504),
//--TRIMMABLE-BOUNDARY-START(17181567800),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1567544,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1698616,
      "h": 17181567800,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181567800),
//--TRIMMABLE-BOUNDARY-START(8591633208),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1567544,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1698616,
      "h": 8591633208,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591633208)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296665912),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1698616,
      "h": 4296665912,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296665912)
  ],
  "h": 1698616
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1698616)
        
        

        //--TRIMMABLE-BOUNDARY-START(781112)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceReceivedDataModel`, ($self) => class RangerDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$XBGm.LCICMGR.RangerReceivedStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295748408)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295748408);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295748408)
            
            //--TRIMMABLE-BOUNDARY-START(4295748408)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295748408)
            
            static $h = 781112;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$XBGm.LCICMGR.RangerReceivedStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295748408),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 781112,
      "h": 4295748408,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295748408)
  ],
  "h": 781112
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(781112)
        
        

        //--TRIMMABLE-BOUNDARY-START(912184)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceReceivedDataModelTypeDescriptor`, ($self) => class RangerDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295879480)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295879480);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$wDws.LCIDRM.RangerDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$wDws.LCIDRM.RangerDeviceReceivedDataModel, this, factory);
                    }, $yYnXQg ??= {"r":65537,"n":"","d":912184,"h":0,"f":17825794}), 0, "RangerDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Ranger\\Models_RangerDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "RangerDeviceReceivedDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295879480)
            
            //--TRIMMABLE-BOUNDARY-START(12885814072)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885814072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$XBGm.LCICMGR.RangerReceivedStatusModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885814072)
            
            //--TRIMMABLE-BOUNDARY-START(17180781368)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180781368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Common.Models.Gauges.Range.RangerReceivedStatusModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$XBGm.LCICMGR.RangerReceivedStatusModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$XBGm.LCICMGR.RangerReceivedStatusModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180781368)
            
            //--TRIMMABLE-BOUNDARY-START(8590846776)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590846776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$wDws.LCIDRM.RangerDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$wDws.LCIDRM.RangerDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590846776)
            
            static $h = 912184;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885814072),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 912184,
      "h": 12885814072,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885814072),
//--TRIMMABLE-BOUNDARY-START(17180781368),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 781112,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 912184,
      "h": 17180781368,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180781368),
//--TRIMMABLE-BOUNDARY-START(8590846776),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 781112,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 912184,
      "h": 8590846776,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590846776)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295879480),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 912184,
      "h": 4295879480,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295879480)
  ],
  "h": 912184
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(912184)
        
        

        //--TRIMMABLE-BOUNDARY-START(2091832)
        $asm.$cls(`$wDws.LCIDR.RangerDataConverter`, ($self) => class RangerDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297059128)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297059128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297059128)
            
            //--TRIMMABLE-BOUNDARY-START(4297059128)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297059128)
            
            static $h = 2091832;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297059128),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2091832,
      "h": 4297059128,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297059128)
  ],
  "h": 2091832
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$wDws.LCIDRM.RangerDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.RangerDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}RangerDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2091832)
        
        

        $asm.$typeProxy("$wDws.LCIDRM.RangerServiceModel", "$wDws.LivingThing.Core.IOT.Devices.Ranger.Models.RangerServiceModel");
        $asm.$typeProxy("$wDws.LCIDRM.RangerDeviceModel", "$wDws.LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceModel");
        $asm.$typeProxy("$wDws.LCIDRS$1.RangerDeviceSettings", "$wDws.LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceSettings");
        $asm.$typeProxy("$wDws.LCIDRS$1.RangerDeviceHardwareSettings", "$wDws.LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceHardwareSettings");
        $asm.$typeProxy("$wDws.LCIDRS.IRangerDeviceStatusHandler", "$wDws.LivingThing.Core.IOT.Devices.Ranger.Services.IRangerDeviceStatusHandler");
        $asm.$typeProxy("$wDws.LCIDRS.IRangerDeviceHubClient", "$wDws.LivingThing.Core.IOT.Devices.Ranger.Services.IRangerDeviceHubClient");
        $asm.$typeProxy("$wDws.LCIDRS.IRangerRemoteService", "$wDws.LivingThing.Core.IOT.Devices.Ranger.Services.IRangerRemoteService");
        //--TRIMMABLE-BOUNDARY-START(1043256)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceScopeModel`, ($self) => class RangerDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296010552)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296010552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296010552)
            
            //--TRIMMABLE-BOUNDARY-START(4296010552)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296010552)
            
            static $h = 1043256;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296010552),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1043256,
      "h": 4296010552,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296010552)
  ],
  "h": 1043256
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1043256)
        
        

        //--TRIMMABLE-BOUNDARY-START(1829688)
        $asm.$cls(`$wDws.LCIDRM.RangerServiceModel`, ($self) => class RangerServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296796984)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296796984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296796984)
            
            //--TRIMMABLE-BOUNDARY-START(4296796984)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4296796984)
            
            static $h = 1829688;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296796984),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 1829688,
      "h": 4296796984,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296796984)
  ],
  "h": 1829688
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1829688)
        
        

        //--TRIMMABLE-BOUNDARY-START(2550584)
        $asm.$cls(`$wDws.LCIDRS.IRangerDeviceHubClient`, ($self) => class IRangerDeviceHubClient
        {
            static $h = 2550584;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2550584
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Services.IRangerDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Services${separator}IRangerDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2550584)
        
        

        //--TRIMMABLE-BOUNDARY-START(518968)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceModel`, ($self) => class RangerDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295486264)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295486264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295486264)
            
            //--TRIMMABLE-BOUNDARY-START(4295486264)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295486264)
            
            static $h = 518968;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295486264),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 518968,
      "h": 4295486264,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295486264)
  ],
  "h": 518968
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(518968)
        
        

        //--TRIMMABLE-BOUNDARY-START(3009336)
        $asm.$cls(`$wDws.LCIDRS$1.RangerDeviceSettings`, ($self) => class RangerDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $self, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297976632)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297976632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297976632)
            
            //--TRIMMABLE-BOUNDARY-START(4297976632)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297976632)
            
            static $h = 3009336;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297976632),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3009336,
      "h": 4297976632,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297976632)
  ],
  "h": 3009336
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Settings${separator}RangerDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3009336)
        
        

        //--TRIMMABLE-BOUNDARY-START(2681656)
        $asm.$cls(`$wDws.LCIDRS.IRangerRemoteService`, ($self) => class IRangerRemoteService
        {
            static $h = 2681656;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2681656
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$wDws.LCIDRM.RangerServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$wDws.LCIDRM.RangerServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$wDws.LCIDRM.RangerServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$wDws.LCIDRM.RangerServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$wDws.LCIDRM.RangerServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$wDws.LCIDRM.RangerServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$wDws.LCIDRM.RangerServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$wDws.LCIDRM.RangerServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Services.IRangerRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Services${separator}IRangerRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2681656)
        
        

        //--TRIMMABLE-BOUNDARY-START(2747192)
        $asm.$cls(`$wDws.LCIDRS$1.RangerDeviceHardwareSettings`, ($self) => class RangerDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297714488)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297714488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297714488)
            
            //--TRIMMABLE-BOUNDARY-START(4297714488)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297714488)
            
            static $h = 2747192;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297714488),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2747192,
      "h": 4297714488,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297714488)
  ],
  "h": 2747192
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Settings${separator}RangerDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2747192)
        
        

        //--TRIMMABLE-BOUNDARY-START(2616120)
        $asm.$cls(`$wDws.LCIDRS.IRangerDeviceStatusHandler`, ($self) => class IRangerDeviceStatusHandler
        {
            static $h = 2616120;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2616120
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Services.IRangerDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Services${separator}IRangerDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2616120)
        
        

        //--TRIMMABLE-BOUNDARY-START(2353976)
        $asm.$cls(`$wDws.LCIDR.RangerDeviceModelDefinition`, ($self) => class RangerDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4297321272)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297321272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297321272)
            
            //--TRIMMABLE-BOUNDARY-START(4297321272)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297321272)
            
            static $h = 2353976;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297321272),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2353976,
      "h": 4297321272,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297321272)
  ],
  "h": 2353976
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.RangerDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}RangerDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2353976)
        
        

        //--TRIMMABLE-BOUNDARY-START(650040)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceModelTypeDescriptor`, ($self) => class RangerDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295617336)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295617336);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$wDws.LCIDRM.RangerDeviceModelTypeDescriptor.GenerateProperties($.$wDws.LCIDRM.RangerDeviceModel, this, factory);
                    }, $SEOotd ??= {"r":65537,"n":"","d":650040,"h":0,"f":17825794}), 0, "RangerDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Ranger\\Models_RangerDeviceModel_LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceModelTypeDescriptorBuilder.g.cs", "RangerDeviceModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295617336)
            
            //--TRIMMABLE-BOUNDARY-START(12885551928)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885551928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885551928)
            
            //--TRIMMABLE-BOUNDARY-START(17180519224)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180519224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Ranger.Models.RangerServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceModel, LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceSettings, LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceSendDataModel, LivingThing.Core.IOT.Devices.Ranger.Services.IRangerDeviceStatusHandler, LivingThing.Core.IOT.Devices.Ranger.Services.IRangerDeviceHubClient, LivingThing.Core.IOT.Devices.Ranger.Services.IRangerRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180519224)
            
            //--TRIMMABLE-BOUNDARY-START(8590584632)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590584632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$wDws.LCIDRM.RangerDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$wDws.LCIDRM.RangerDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceModel)))
                {
                    /*var*/ let result = $.$wDws.LCIDRM.RangerDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$wDws.LCIDRM.RangerDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590584632)
            
            static $h = 650040;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885551928),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 650040,
      "h": 12885551928,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885551928),
//--TRIMMABLE-BOUNDARY-START(17180519224),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 518968,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 650040,
      "h": 17180519224,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180519224),
//--TRIMMABLE-BOUNDARY-START(8590584632),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 518968,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 650040,
      "h": 8590584632,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590584632)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295617336),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 650040,
      "h": 4295617336,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295617336)
  ],
  "h": 650040
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(650040)
        
        

        //--TRIMMABLE-BOUNDARY-START(1960760)
        $asm.$cls(`$wDws.LCIDRM.RangerServiceModelTypeDescriptor`, ($self) => class RangerServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRM.RangerServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296928056)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296928056);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$wDws.LCIDRM.RangerServiceModelTypeDescriptor.GenerateProperties($.$wDws.LCIDRM.RangerServiceModel, this, factory);
                    }, $dgwTBa ??= {"r":65537,"n":"","d":1960760,"h":0,"f":17825794}), 0, "RangerServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Ranger\\Models_RangerServiceModel_LivingThing.Core.IOT.Devices.Ranger.Models.RangerServiceModelTypeDescriptorBuilder.g.cs", "RangerServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296928056)
            
            //--TRIMMABLE-BOUNDARY-START(12886862648)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886862648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886862648)
            
            //--TRIMMABLE-BOUNDARY-START(17181829944)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Models.RangerServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181829944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Ranger.Models.RangerServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceModel, LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceSettings, LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceSendDataModel, LivingThing.Core.IOT.Devices.Ranger.Services.IRangerDeviceStatusHandler, LivingThing.Core.IOT.Devices.Ranger.Services.IRangerDeviceHubClient, LivingThing.Core.IOT.Devices.Ranger.Services.IRangerRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181829944)
            
            //--TRIMMABLE-BOUNDARY-START(8591895352)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Models.RangerServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591895352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$wDws.LCIDRM.RangerServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$wDws.LCIDRM.RangerServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerServiceModel)))
                {
                    /*var*/ let result = $.$wDws.LCIDRM.RangerServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$wDws.LCIDRM.RangerServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591895352)
            
            static $h = 1960760;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRM.RangerServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886862648),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1960760,
      "h": 12886862648,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886862648),
//--TRIMMABLE-BOUNDARY-START(17181829944),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1829688,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1960760,
      "h": 17181829944,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181829944),
//--TRIMMABLE-BOUNDARY-START(8591895352),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1829688,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1960760,
      "h": 8591895352,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591895352)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296928056),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1960760,
      "h": 4296928056,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296928056)
  ],
  "h": 1960760
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$wDws.LCIDRM.RangerServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1960760)
        
        

        //--TRIMMABLE-BOUNDARY-START(1174328)
        $asm.$cls(`$wDws.LCIDRM.RangerDeviceScopeModelTypeDescriptor`, ($self) => class RangerDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296141624)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296141624);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$wDws.LCIDRM.RangerDeviceScopeModelTypeDescriptor.GenerateProperties($.$wDws.LCIDRM.RangerDeviceScopeModel, this, factory);
                    }, $nQxogi ??= {"r":65537,"n":"","d":1174328,"h":0,"f":17825794}), 0, "RangerDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Ranger\\Models_RangerDeviceScopeModel_LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceScopeModelTypeDescriptorBuilder.g.cs", "RangerDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296141624)
            
            //--TRIMMABLE-BOUNDARY-START(12886076216)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886076216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886076216)
            
            //--TRIMMABLE-BOUNDARY-START(17181043512)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181043512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Ranger.Models.RangerServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceModel, LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceSettings, LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceSendDataModel, LivingThing.Core.IOT.Devices.Ranger.Services.IRangerDeviceStatusHandler, LivingThing.Core.IOT.Devices.Ranger.Services.IRangerDeviceHubClient, LivingThing.Core.IOT.Devices.Ranger.Services.IRangerRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181043512)
            
            //--TRIMMABLE-BOUNDARY-START(8591108920)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591108920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$wDws.LCIDRM.RangerDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$wDws.LCIDRM.RangerDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceScopeModel)))
                {
                    /*var*/ let result = $.$wDws.LCIDRM.RangerDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$wDws.LCIDRM.RangerDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRM.RangerDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591108920)
            
            static $h = 1174328;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886076216),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1174328,
      "h": 12886076216,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886076216),
//--TRIMMABLE-BOUNDARY-START(17181043512),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1043256,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1174328,
      "h": 17181043512,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181043512),
//--TRIMMABLE-BOUNDARY-START(8591108920),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1043256,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1174328,
      "h": 8591108920,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591108920)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296141624),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1174328,
      "h": 4296141624,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296141624)
  ],
  "h": 1174328
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$wDws.LCIDRM.RangerDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Models${separator}RangerDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1174328)
        
        

        //--TRIMMABLE-BOUNDARY-START(3140408)
        $asm.$cls(`$wDws.LCIDRS$1.RangerDeviceSettingsTypeDescriptor`, ($self) => class RangerDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRS$1.RangerDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298107704)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298107704);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$wDws.LCIDRS$1.RangerDeviceSettingsTypeDescriptor.GenerateProperties($.$wDws.LCIDRS$1.RangerDeviceSettings, this, factory);
                    }, $PNtaKg ??= {"r":65537,"n":"","d":3140408,"h":0,"f":17825794}), 0, "RangerDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Ranger\\Settings_RangerDeviceSettings_LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceSettingsTypeDescriptorBuilder.g.cs", "RangerDeviceSettingsTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298107704)
            
            //--TRIMMABLE-BOUNDARY-START(12888042296)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888042296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888042296)
            
            //--TRIMMABLE-BOUNDARY-START(17183009592)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183009592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.Ranger.Models.RangerServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceModel, LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceSettings, LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceSendDataModel, LivingThing.Core.IOT.Devices.Ranger.Services.IRangerDeviceStatusHandler, LivingThing.Core.IOT.Devices.Ranger.Services.IRangerDeviceHubClient, LivingThing.Core.IOT.Devices.Ranger.Services.IRangerRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).iSmartDeviceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183009592)
            
            //--TRIMMABLE-BOUNDARY-START(8593075000)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593075000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$wDws.LCIDRS$1.RangerDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$wDws.LCIDRS$1.RangerDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRS$1.RangerDeviceSettings)))
                {
                    /*var*/ let result = $.$wDws.LCIDRS$1.RangerDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRS$1.RangerDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$wDws.LCIDRS$1.RangerDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRS$1.RangerDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593075000)
            
            static $h = 3140408;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRS$1.RangerDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888042296),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3140408,
      "h": 12888042296,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888042296),
//--TRIMMABLE-BOUNDARY-START(17183009592),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3009336,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3140408,
      "h": 17183009592,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183009592),
//--TRIMMABLE-BOUNDARY-START(8593075000),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3009336,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3140408,
      "h": 8593075000,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593075000)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298107704),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3140408,
      "h": 4298107704,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298107704)
  ],
  "h": 3140408
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$wDws.LCIDRS$1.RangerDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Settings${separator}RangerDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3140408)
        
        

        //--TRIMMABLE-BOUNDARY-START(2878264)
        $asm.$cls(`$wDws.LCIDRS$1.RangerDeviceHardwareSettingsTypeDescriptor`, ($self) => class RangerDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRS$1.RangerDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297845560)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297845560);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$wDws.LCIDRS$1.RangerDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, this, factory);
                    }, $dvzAuk ??= {"r":65537,"n":"","d":2878264,"h":0,"f":17825794}), 0, "RangerDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Ranger\\Settings_RangerDeviceHardwareSettings_LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "RangerDeviceHardwareSettingsTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297845560)
            
            //--TRIMMABLE-BOUNDARY-START(12887780152)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887780152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887780152)
            
            //--TRIMMABLE-BOUNDARY-START(17182747448)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182747448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.Ranger.Models.RangerServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceModel, LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceSettings, LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceSendDataModel, LivingThing.Core.IOT.Devices.Ranger.Services.IRangerDeviceStatusHandler, LivingThing.Core.IOT.Devices.Ranger.Services.IRangerDeviceHubClient, LivingThing.Core.IOT.Devices.Ranger.Services.IRangerRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).iSmartDeviceHardwareSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182747448)
            
            //--TRIMMABLE-BOUNDARY-START(8592812856)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592812856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$wDws.LCIDRS$1.RangerDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592812856)
            
            static $h = 2878264;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$wDws.LCIDRS$1.RangerDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887780152),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2878264,
      "h": 12887780152,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887780152),
//--TRIMMABLE-BOUNDARY-START(17182747448),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2747192,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2878264,
      "h": 17182747448,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182747448),
//--TRIMMABLE-BOUNDARY-START(8592812856),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2747192,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2878264,
      "h": 8592812856,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592812856)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297845560),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2878264,
      "h": 4297845560,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297845560)
  ],
  "h": 2878264
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$wDws.LCIDRS$1.RangerDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.Settings.RangerDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}Settings${separator}RangerDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2878264)
        
        

        //--TRIMMABLE-BOUNDARY-START(2419512)
        $asm.$cls(`$wDws.LCIDR.RangerDeviceStatusHandler`, ($self) => class RangerDeviceStatusHandler extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592354104)
            /*IIOTDeviceProvider*/ deviceProvider = null;
            //--TRIMMABLE-BOUNDARY-END(8592354104)
            
            //--TRIMMABLE-BOUNDARY-START(4297386808)
            $ctor$1(/*IIOTDeviceProvider*/ deviceProvider)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297386808);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.deviceProvider = deviceProvider;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297386808)
            
            //--TRIMMABLE-BOUNDARY-START(12887321400)
            /*Task *//*async*/  Handle(/*GatewayNotification<Length>*/ notification, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887321400);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let device = $.$as(($t1 = this.deviceProvider.LCICI$IIOTDeviceProvider$GetAsync(notification.TargetId), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))), $.$wDws.LCIDR.RangerDevice);
                    if (device !== null)
                    {
                        device.Received = (() =>
                        {
                            //new $.$wDws.LCIDRM.RangerDeviceReceivedDataModel()
                            const $t2 = $.$wDws.LCIDRM.RangerDeviceReceivedDataModel;
                            const $i2 = new $t2();
                            $i2.$ctor$4();
                            $i2.Status = (() =>
                            {
                                //new $.$XBGm.LCICMGR.RangerReceivedStatusModel()
                                const $t3 = $.$XBGm.LCICMGR.RangerReceivedStatusModel;
                                const $i3 = new $t3();
                                $i3.$ctor$2();
                                $i3.Height = $.$fPer.LCFCDM.Length.op_Implicit(notification.Model);
                                $i3.Battery = notification.GetExtra($.$fPer.LCFCDM.Voltage).V;
                                $i3.Temperature = notification.GetExtra($.$fPer.LCFCDM.Temperature).Celcius;
                                return $i3;
                            })();
                            return $i2;
                        })();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12887321400)
            
            //--TRIMMABLE-BOUNDARY-START(17182288696)
            /*Task */ HandleConnected(/*IConnectionClient*/ client, /*object?*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182288696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(17182288696)
            
            //--TRIMMABLE-BOUNDARY-START(21477255992)
            /*Task */ HandleDisconnected(/*IConnectionClient*/ client, /*object?*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477255992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(21477255992)
            
            //--TRIMMABLE-BOUNDARY-START(25772223288)
            /*Task<RangerDeviceSendDataModel?> */ HandleReceived(/*IConnectionMessage*/ message, /*RangerDeviceReceivedDataModel*/ status, /*object?*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772223288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$wDws.LCIDRM.RangerDeviceSendDataModel, null);
            }
            //--TRIMMABLE-BOUNDARY-END(25772223288)
            
            //--TRIMMABLE-BOUNDARY-START(4323972497)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceStatusHandler<LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceSendDataModel>.HandleReceived(LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage, LivingThing.Core.IOT.Devices.Ranger.Models.RangerDeviceReceivedDataModel, object?)
            LCICI$IIOTDeviceStatusHandler$$$$HandleReceived()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4323972497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleReceived(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4323972497)
            
            //--TRIMMABLE-BOUNDARY-START(8616056209)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceConnectionStatusHandler.HandleConnected(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, object?)
            LCICI$IIOTDeviceConnectionStatusHandler$HandleConnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8616056209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleConnected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8616056209)
            
            //--TRIMMABLE-BOUNDARY-START(12911023505)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceConnectionStatusHandler.HandleDisconnected(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, object?)
            LCICI$IIOTDeviceConnectionStatusHandler$HandleDisconnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12911023505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleDisconnected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12911023505)
            
            //--TRIMMABLE-BOUNDARY-START(4295315818)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mediator.INotificationHandler<LivingThing.Core.IOT.Devices.Gateway.Services.GatewayNotification<LivingThing.Core.Frameworks.Common.Data.Measurements.Length>>.Handle(LivingThing.Core.IOT.Devices.Gateway.Services.GatewayNotification<LivingThing.Core.Frameworks.Common.Data.Measurements.Length>, System.Threading.CancellationToken)
            [`LCFCM$INotificationHandler$LivingThing$Core$IOT$Devices$Gateway$Services$GatewayNotification$LivingThing$Core$Frameworks$Common$Data$Measurements$Length$$Handle`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295315818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Handle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295315818)
            
            static $h = 2419512;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887321400),
    {
      "r": 178454529,
      "p": [
        {
          "n": "notification",
          "p": $.$NzWm.LCIDGS.GatewayNotification$$($.$fPer.LCFCDM.Length).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Handle",
      "d": 2419512,
      "h": 12887321400,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(12887321400),
//--TRIMMABLE-BOUNDARY-START(17182288696),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "arg",
          "p": 131073
        }
      ],
      "n": "HandleConnected",
      "d": 2419512,
      "h": 17182288696,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182288696),
//--TRIMMABLE-BOUNDARY-START(21477255992),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "arg",
          "p": 131073
        }
      ],
      "n": "HandleDisconnected",
      "d": 2419512,
      "h": 21477255992,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477255992),
//--TRIMMABLE-BOUNDARY-START(25772223288),
    {
      "r": $.$$.STT.Task$$($.$wDws.LCIDRM.RangerDeviceSendDataModel).$h,
      "p": [
        {
          "n": "message",
          "p": 1961646
        },
        {
          "n": "status",
          "p": 781112
        },
        {
          "n": "arg",
          "p": 131073
        }
      ],
      "n": "HandleReceived",
      "d": 2419512,
      "h": 25772223288,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772223288)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592354104),
    {
      "t": 28153233,
      "n": "deviceProvider",
      "d": 2419512,
      "h": 8592354104,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592354104)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297386808),
    {
      "p": [
        {
          "n": "deviceProvider",
          "p": 28153233
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2419512,
      "h": 4297386808,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297386808)
  ],
  "h": 2419512
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver, $.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler$$($.$fPer.LCFCDM.Length), $.$tUcV.LCFCM.INotificationHandler$$($.$NzWm.LCIDGS.GatewayNotification$$($.$fPer.LCFCDM.Length)), $.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.RangerDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}RangerDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2419512)
        
        

        //--TRIMMABLE-BOUNDARY-START(2157368)
        $asm.$cls(`$wDws.LCIDR.RangerDevice`, ($self) => class RangerDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$XBGm.LCICMGR.RangerReceivedStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4297124664)
            $ctor$2(/*IIOTDeviceFamily<RangerDevice>*/ family, /*IIOTDeviceScope*/ scope, /*RangerDeviceModel*/ model)
            {
                super.$ctor$3(family, scope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297124664);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297124664)
            
            static $h = 2157368;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDR.RangerDevice, $.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$XBGm.LCICMGR.RangerReceivedStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297124664),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$wDws.LCIDR.RangerDevice).$h
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 518968
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2157368,
      "h": 4297124664,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297124664)
  ],
  "h": 2157368
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.RangerDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}RangerDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2157368)
        
        

        //--TRIMMABLE-BOUNDARY-START(2222904)
        $asm.$cls(`$wDws.LCIDR.RangerDeviceDefinition`, ($self) => class RangerDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDR.RangerDevice, $.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$XBGm.LCICMGR.RangerReceivedStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297190200)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297190200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297190200)
            
            //--TRIMMABLE-BOUNDARY-START(4297190200)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297190200)
            
            static $h = 2222904;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDR.RangerDevice, $.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$XBGm.LCICMGR.RangerReceivedStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297190200),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2222904,
      "h": 4297190200,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297190200)
  ],
  "h": 2222904
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.RangerDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}RangerDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2222904)
        
        

        //--TRIMMABLE-BOUNDARY-START(2288440)
        $asm.$cls(`$wDws.LCIDR.RangerDeviceFamily`, ($self) => class RangerDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDR.RangerDevice, $.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4297255736)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<RangerDeviceReceivedDataModel, RangerDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<RangerDeviceReceivedDataModel, RangerDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297255736);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297255736)
            
            //--TRIMMABLE-BOUNDARY-START(12887190328)
            /*IIOTDeviceFamilyFeatures */ get Features()
            {
                return super.Features | 1/*IIOTDeviceFamilyFeatures.NoDatabase*/;
            }
            //--TRIMMABLE-BOUNDARY-END(12887190328)
            
            //--TRIMMABLE-BOUNDARY-START(81606667064)
            /*GatewayDeviceModBusType */ get Type()
            {
                return 2/*GatewayDeviceModBusType.InputRegister*/;
            }
            //--TRIMMABLE-BOUNDARY-END(81606667064)
            
            //--TRIMMABLE-BOUNDARY-START(8592223032)
            /*byte */ get BusAddress()
            {
                return 1;
            }
            //--TRIMMABLE-BOUNDARY-END(8592223032)
            
            //--TRIMMABLE-BOUNDARY-START(73016732472)
            /*ushort */ get RegisterAddress()
            {
                return 35541;
            }
            //--TRIMMABLE-BOUNDARY-END(73016732472)
            
            //--TRIMMABLE-BOUNDARY-START(68721765176)
            /*string */ get Key()
            {
                return "rgf1";
            }
            //--TRIMMABLE-BOUNDARY-END(68721765176)
            
            //--TRIMMABLE-BOUNDARY-START(77311699768)
            /*byte */ get RegisterCount()
            {
                return 7;
            }
            //--TRIMMABLE-BOUNDARY-END(77311699768)
            
            //--TRIMMABLE-BOUNDARY-START(38666696255)
            //Generated interface implemetation for LivingThing.Core.IOT.Devices.Gateway.Models.IGatewayModBusDeviceConfiguration.Type.get
            get LCIDGM$1$IGatewayModBusDeviceConfiguration$Type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51551598143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Type;
            }
            //--TRIMMABLE-BOUNDARY-END(38666696255)
            
            //--TRIMMABLE-BOUNDARY-START(12896892479)
            //Generated interface implemetation for LivingThing.Core.IOT.Devices.Gateway.Models.IGatewayModBusDeviceConfiguration.BusAddress.get
            get LCIDGM$1$IGatewayModBusDeviceConfiguration$BusAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4306957887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BusAddress;
            }
            //--TRIMMABLE-BOUNDARY-END(12896892479)
            
            //--TRIMMABLE-BOUNDARY-START(21486827071)
            //Generated interface implemetation for LivingThing.Core.IOT.Devices.Gateway.Models.IGatewayModBusDeviceConfiguration.RegisterAddress.get
            get LCIDGM$1$IGatewayModBusDeviceConfiguration$RegisterAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42961663551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisterAddress;
            }
            //--TRIMMABLE-BOUNDARY-END(21486827071)
            
            //--TRIMMABLE-BOUNDARY-START(30076761663)
            //Generated interface implemetation for LivingThing.Core.IOT.Devices.Gateway.Models.IGatewayModBusDeviceConfiguration.RegisterCount.get
            get LCIDGM$1$IGatewayModBusDeviceConfiguration$RegisterCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47256630847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisterCount;
            }
            //--TRIMMABLE-BOUNDARY-END(30076761663)
            
            //--TRIMMABLE-BOUNDARY-START(8601859647)
            //Generated interface implemetation for LivingThing.Core.IOT.Devices.Gateway.Models.IGatewayDeviceConfiguration.Key.get
            get LCIDGM$1$IGatewayDeviceConfiguration$Key()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12896826943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Key;
            }
            //--TRIMMABLE-BOUNDARY-END(8601859647)
            
            static $h = 2288440;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$wDws.LCIDR.RangerDevice, $.$wDws.LCIDRM.RangerServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$wDws.LCIDRM.RangerDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$wDws.LCIDRM.RangerDeviceModel, $.$wDws.LCIDRS$1.RangerDeviceSettings, $.$wDws.LCIDRS$1.RangerDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$wDws.LCIDRM.RangerDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel, $.$wDws.LCIDRS.IRangerDeviceStatusHandler, $.$wDws.LCIDRS.IRangerDeviceHubClient, $.$wDws.LCIDRS.IRangerRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887190328),
    {
      "p": 26842513,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067059512,
        "f": 50364417
      },
      "n": "Features",
      "d": 2288440,
      "h": 12887190328,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12887190328),
//--TRIMMABLE-BOUNDARY-START(81606667064),
    {
      "p": 5830207,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426797880,
        "f": 50331649
      },
      "n": "Type",
      "d": 2288440,
      "h": 81606667064,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606667064),
//--TRIMMABLE-BOUNDARY-START(8592223032),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477124920,
        "f": 50331649
      },
      "n": "BusAddress",
      "d": 2288440,
      "h": 8592223032,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8592223032),
//--TRIMMABLE-BOUNDARY-START(73016732472),
    {
      "p": 589825,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246928696,
        "f": 50331649
      },
      "n": "RegisterAddress",
      "d": 2288440,
      "h": 73016732472,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016732472),
//--TRIMMABLE-BOUNDARY-START(68721765176),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656994104,
        "f": 50331649
      },
      "n": "Key",
      "d": 2288440,
      "h": 68721765176,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721765176),
//--TRIMMABLE-BOUNDARY-START(77311699768),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836863288,
        "f": 50331649
      },
      "n": "RegisterCount",
      "d": 2288440,
      "h": 77311699768,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311699768)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297255736),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$wDws.LCIDRM.RangerDeviceReceivedDataModel, $.$wDws.LCIDRM.RangerDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2288440,
      "h": 4297255736,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297255736)
  ],
  "h": 2288440
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$wDws.LCIDR.RangerDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$wDws.LCIDR.RangerDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$NzWm.LCIDGM$1.IGatewayModBusDeviceConfiguration$$($.$wDws.LCIDR.RangerDevice), $.$NzWm.LCIDGM$1.IGatewayModBusDeviceConfiguration, $.$NzWm.LCIDGM$1.IGatewayDeviceConfiguration ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Ranger.RangerDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Ranger${separator}RangerDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2288440)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor", "NetJs.LivingThing.Core.IOT.Devices.Gateway"));
})();
//--TRIMMABLE-BOUNDARY-END(60216)
