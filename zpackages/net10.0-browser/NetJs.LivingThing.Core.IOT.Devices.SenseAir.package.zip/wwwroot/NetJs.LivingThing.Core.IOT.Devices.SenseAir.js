
//--TRIMMABLE-BOUNDARY-START(58948)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $pOHODb;
    let $FBrXfd;
    let $ZfJSbg;
    let $WgBWEi;
    let $ZNGala;
    let $HavyMb;
    let $nzQTUc;
    let $nfwIgc;
    let $AMUFNb;
    let $hByaOh;
    let $agAoYd;
    let $TAudUf;
    let $WfpBPk;
    let $wtMbcj;
    let $qxfhWi;
    let $BTQxTf;
    let $tSIBcg;
    let $LJGWnk;
    let $OorUTe;
    let $PdTgMb;
    let $Vcxqik;
    let $cSolaj;
    let $seIbNa;
    let $PgtjYj;
    let $mkGDnb;
    let $NsmKPg;
    let $bJuMle;
    let $tEtQRd;
    let $XuMuGd;
    let $jBCgcg;
    let $UJeUKg;
    let $JeHdnd;
    let $fBapFi;
    let $qXZmjh;
    let $IpQjjc;
    let $hESwVk;
    let $dCrcsb;
    let $IkxOOb;
    let $amaged;
    let $AjvKPk;
    let $utLvVd;
    let $xLlWwc;
    let $mYSOof;
    let $dPvmlb;
    let $qwxkgl;
    let $bDWhLi;
    let $umQcnj;
    let $AlJlMg;
    let $agnEbg;
    let $tliwhd;
    let $ilVMhi;
    let $YPWebk;
    let $fVWUlj;
    let $BdkOHh;
    let $FPKNmh;
    let $KAylwi;
    let $tfvosf;
    let $PJvQHf;
    let $yiuuLb;
    let $Wbwecc;
    let $TjLafl;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.SenseAir", 
    {
  "h": 58948,
  "f": "LivingThing.Core.IOT.Devices.SenseAir",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.SenseAir",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.SenseAir",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5TZW5zZUFpci5TZW5zZUFpckRldmljZSI6IHsNCiAgICAgICJDYXRlZ29yaWVzIjogWyAiU21hcnQgSG9tZSIgXSwNCiAgICAgICJOYW1lIjogIlNlbnNlIEFpciIsDQogICAgICAiRGVzY3JpcHRpb24iOiAiQWlyIHF1YWxpdHkgbW9uaXRvciwgZGV0ZWN0IGltcHVyaXRpZXMgaW4gdGhlIGFpciIsDQogICAgICAiSWNvbiI6IHsgIk5hbWUiOiAibWRpIG1kaS1mYW4iIH0sDQogICAgICAiVGhlbWVDb2xvciI6ICIjZDk1NzYzIiwNCiAgICAgICJGbGFncyI6ICJGZWF0dXJlZCxQdWJsaXNoZWQiLA0KICAgICAgIkJhbm5lckltYWdlIjogIn4vU2Vuc2VBaXIvaW1nL2Jhbm5lci5qcGciLA0KICAgICAgIlNlY3VyaXRpZXMiOiAiQ2hhbGxlbmdlSGFuZFNoYWtlQXV0aGVudGljYXRpb25Qcm90b2NvbCxBZHZhbmNlZEVuY3J5cHRpb25TdGFuZGFyZCxFbGxpcHRpY0N1cnZlRmlybXdhcmVVcGRhdGVTaWduaW5nIiwNCiAgICAgICJTdGF0dXNOYW1lcyI6ICJTdGF0dXMuU3RhdHVzLFN0YXR1cy5SZWFsUG93ZXIsU3RhdHVzLlZvbHRhZ2UiDQogICAgfQ0KICB9DQp9"
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2352708)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirLogTypeCustomAttributesProvider`, ($self) => class SenseAirLogTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297320004)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297320004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297320004)
            
            static $h = 2352708;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297320004),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2352708,
      "h": 4297320004,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297320004)
  ],
  "h": 2352708
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirLogTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirLogTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2352708)
        
        

        //--TRIMMABLE-BOUNDARY-START(1304132)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class SenseAirDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296271428)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296271428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$dRGn.LCIDSMS.SenseAirStatusModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296271428)
            
            static $h = 1304132;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296271428),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1304132,
      "h": 4296271428,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296271428)
  ],
  "h": 1304132
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1304132)
        
        

        //--TRIMMABLE-BOUNDARY-START(190020)
        $asm.$cls(`$dRGn.LCIDS._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295157316)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295157316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$dRGn.LCIDS.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295157316)
            
            static $h = 190020;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295157316),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 190020,
      "h": 4295157316,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295157316)
  ],
  "h": 190020
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(190020)
        
        

        //--TRIMMABLE-BOUNDARY-START(4253252)
        $asm.$cls(`$dRGn.LCIDSS$1.SenseAirDeviceSettingsCustomAttributesProvider`, ($self) => class SenseAirDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299220548)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299220548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299220548)
            
            static $h = 4253252;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299220548),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4253252,
      "h": 4299220548,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299220548)
  ],
  "h": 4253252
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Settings${separator}SenseAirDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4253252)
        
        

        //--TRIMMABLE-BOUNDARY-START(3401284)
        $asm.$cls(`$dRGn.LCIDS.SenseAirDeviceBroadcastMessageCustomAttributesProvider`, ($self) => class SenseAirDeviceBroadcastMessageCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298368580)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298368580)
            
            //--TRIMMABLE-BOUNDARY-START(8593335876)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593335876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$dRGn.LCIDS.SenseAirDeviceBroadcastMessageCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$dRGn.LCIDS.SenseAirDeviceBroadcastMessageCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $ZfJSbg ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3401284,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $WgBWEi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3401284,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593335876)
            
            static $h = 3401284;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593335876),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3401284,
      "h": 8593335876,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593335876)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298368580),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3401284,
      "h": 4298368580,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298368580)
  ],
  "h": 3401284
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.SenseAirDeviceBroadcastMessageCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}SenseAirDeviceBroadcastMessageCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3401284)
        
        

        //--TRIMMABLE-BOUNDARY-START(1566276)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirDeviceScopeModelCustomAttributesProvider`, ($self) => class SenseAirDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296533572)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296533572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296533572)
            
            static $h = 1566276;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296533572),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1566276,
      "h": 4296533572,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296533572)
  ],
  "h": 1566276
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1566276)
        
        

        //--TRIMMABLE-BOUNDARY-START(1828420)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirDeviceSendDataModelCustomAttributesProvider`, ($self) => class SenseAirDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296795716)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296795716)
            
            //--TRIMMABLE-BOUNDARY-START(8591763012)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591763012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$dRGn.LCIDSM.SenseAirDeviceSendDataModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("OnOff", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (13432);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$dRGn.LCIDSM.SenseAirDeviceSendDataModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $pOHODb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1828420,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $FBrXfd ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1828420,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandsModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591763012)
            
            static $h = 1828420;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591763012),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1828420,
      "h": 8591763012,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591763012)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296795716),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1828420,
      "h": 4296795716,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296795716)
  ],
  "h": 1828420
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1828420)
        
        

        //--TRIMMABLE-BOUNDARY-START(2483780)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirServiceModelCustomAttributesProvider`, ($self) => class SenseAirServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297451076)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297451076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297451076)
            
            static $h = 2483780;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297451076),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2483780,
      "h": 4297451076,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297451076)
  ],
  "h": 2483780
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2483780)
        
        

        //--TRIMMABLE-BOUNDARY-START(517700)
        $asm.$cls(`$dRGn.LCIDSMC.SenseAirControlOnOffModelCustomAttributesProvider`, ($self) => class SenseAirControlOnOffModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295484996)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295484996)
            
            //--TRIMMABLE-BOUNDARY-START(8590452292)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590452292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$dRGn.LCIDSMC.SenseAirControlOnOffModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("On", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("LogTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (4);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$dRGn.LCIDSMC.SenseAirControlOnOffModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $nfwIgc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":517700,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $AMUFNb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":517700,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590452292)
            
            static $h = 517700;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590452292),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 517700,
      "h": 8590452292,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590452292)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295484996),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 517700,
      "h": 4295484996,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295484996)
  ],
  "h": 517700
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.Controls.SenseAirControlOnOffModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}Controls${separator}SenseAirControlOnOffModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(517700)
        
        

        //--TRIMMABLE-BOUNDARY-START(910916)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirControlTypeCustomAttributesProvider`, ($self) => class SenseAirControlTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295878212)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295878212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295878212)
            
            static $h = 910916;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295878212),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 910916,
      "h": 4295878212,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295878212)
  ],
  "h": 910916
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirControlTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirControlTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(910916)
        
        

        //--TRIMMABLE-BOUNDARY-START(4449860)
        $asm.$cls(`$dRGn.LCIDS.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4299417156)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299417156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$dRGn.LCIDSMC.SenseAirControlOnOffModelTypeDescriptorBuilder.Register();
                $.$dRGn.LCIDSM.SenseAirDeviceModelTypeDescriptorBuilder.Register();
                $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$dRGn.LCIDSM.SenseAirDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$dRGn.LCIDSM.SenseAirDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$dRGn.LCIDSM.SenseAirLogModelTypeDescriptorBuilder.Register();
                $.$dRGn.LCIDSM.SenseAirServiceModelTypeDescriptorBuilder.Register();
                $.$dRGn.LCIDSMS.SenseAirStatusModelTypeDescriptorBuilder.Register();
                $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$dRGn.LCIDSS$1.SenseAirDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4299417156)
            
            static $h = 4449860;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299417156),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 4449860,
      "h": 4299417156,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4299417156)
  ],
  "h": 4449860
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4449860)
        
        

        //--TRIMMABLE-BOUNDARY-START(1041988)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirDeviceModelCustomAttributesProvider`, ($self) => class SenseAirDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296009284)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296009284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296009284)
            
            static $h = 1041988;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296009284),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1041988,
      "h": 4296009284,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296009284)
  ],
  "h": 1041988
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1041988)
        
        

        //--TRIMMABLE-BOUNDARY-START(2745924)
        $asm.$cls(`$dRGn.LCIDSMS.SenseAirStatusModelCustomAttributesProvider`, ($self) => class SenseAirStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297713220)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297713220)
            
            //--TRIMMABLE-BOUNDARY-START(8592680516)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592680516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$dRGn.LCIDSMS.SenseAirStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("AirQuality", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.ConvertType = ($.$$.S.Single.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Temperature", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.ConvertType = ($.$$.S.Single.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Humidity", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3);
                            $i5.ConvertType = ($.$$.S.Single.$type);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$dRGn.LCIDSMS.SenseAirStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $agAoYd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2745924,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $TAudUf ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2745924,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592680516)
            
            static $h = 2745924;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592680516),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2745924,
      "h": 8592680516,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592680516)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297713220),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2745924,
      "h": 4297713220,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297713220)
  ],
  "h": 2745924
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}Statuses${separator}SenseAirStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2745924)
        
        

        //--TRIMMABLE-BOUNDARY-START(1697348)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirDeviceScopeModelTypeDescriptorBuilder`, ($self) => class SenseAirDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591631940)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591631940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dRGn.LCIDSM.SenseAirDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$dRGn.LCIDSM.SenseAirDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $WfpBPk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1697348,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dRGn.LCIDSM.SenseAirDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591631940)
            
            //--TRIMMABLE-BOUNDARY-START(4296664644)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296664644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296664644)
            
            //--TRIMMABLE-BOUNDARY-START(4296664644)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296664644)
            
            static $h = 1697348;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591631940),
    {
      "r": 65537,
      "n": "Register",
      "d": 1697348,
      "h": 8591631940,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591631940)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296664644),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1697348,
      "h": 4296664644,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296664644)
  ],
  "h": 1697348
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1697348)
        
        

        //--TRIMMABLE-BOUNDARY-START(1959492)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class SenseAirDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591894084)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591894084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dRGn.LCIDSM.SenseAirDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$dRGn.LCIDSM.SenseAirDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $tSIBcg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1959492,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dRGn.LCIDSM.SenseAirDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591894084)
            
            //--TRIMMABLE-BOUNDARY-START(4296926788)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296926788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296926788)
            
            //--TRIMMABLE-BOUNDARY-START(4296926788)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296926788)
            
            static $h = 1959492;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591894084),
    {
      "r": 65537,
      "n": "Register",
      "d": 1959492,
      "h": 8591894084,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591894084)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296926788),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1959492,
      "h": 4296926788,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296926788)
  ],
  "h": 1959492
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1959492)
        
        

        //--TRIMMABLE-BOUNDARY-START(321092)
        $asm.$cls(`$dRGn.LCIDS.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295288388)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295288388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRGn.LCIDSMC.SenseAirControlOnOffModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRGn.LCIDSMC.SenseAirControlOnOffModelCustomAttributesProvider, $.$dRGn.LCIDSMC.SenseAirControlOnOffModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRGn.LCIDSM.SenseAirBroadcastActionType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRGn.LCIDSM.SenseAirBroadcastActionTypeCustomAttributesProvider, $.$dRGn.LCIDSM.SenseAirBroadcastActionTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRGn.LCIDSM.SenseAirDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRGn.LCIDSM.SenseAirDeviceModelCustomAttributesProvider, $.$dRGn.LCIDSM.SenseAirDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModelCustomAttributesProvider, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRGn.LCIDSM.SenseAirDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRGn.LCIDSM.SenseAirDeviceScopeModelCustomAttributesProvider, $.$dRGn.LCIDSM.SenseAirDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRGn.LCIDSM.SenseAirControlType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRGn.LCIDSM.SenseAirControlTypeCustomAttributesProvider, $.$dRGn.LCIDSM.SenseAirControlTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRGn.LCIDSM.SenseAirDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRGn.LCIDSM.SenseAirDeviceSendDataModelCustomAttributesProvider, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRGn.LCIDSM.SenseAirLogType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRGn.LCIDSM.SenseAirLogTypeCustomAttributesProvider, $.$dRGn.LCIDSM.SenseAirLogTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRGn.LCIDSM.SenseAirLogModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRGn.LCIDSM.SenseAirLogModelCustomAttributesProvider, $.$dRGn.LCIDSM.SenseAirLogModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRGn.LCIDSM.SenseAirServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRGn.LCIDSM.SenseAirServiceModelCustomAttributesProvider, $.$dRGn.LCIDSM.SenseAirServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRGn.LCIDSMS.SenseAirStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRGn.LCIDSMS.SenseAirStatusModelCustomAttributesProvider, $.$dRGn.LCIDSMS.SenseAirStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRGn.LCIDS.SenseAirDeviceBroadcastMessage.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRGn.LCIDS.SenseAirDeviceBroadcastMessageCustomAttributesProvider, $.$dRGn.LCIDS.SenseAirDeviceBroadcastMessageCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettingsCustomAttributesProvider, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$dRGn.LCIDSS$1.SenseAirDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$dRGn.LCIDSS$1.SenseAirDeviceSettingsCustomAttributesProvider, $.$dRGn.LCIDSS$1.SenseAirDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295288388)
            
            static $h = 321092;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295288388),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 321092,
      "h": 4295288388,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295288388)
  ],
  "h": 321092
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(321092)
        
        

        //--TRIMMABLE-BOUNDARY-START(1173060)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirDeviceModelTypeDescriptorBuilder`, ($self) => class SenseAirDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591107652)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591107652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dRGn.LCIDSM.SenseAirDeviceModelTypeDescriptor()
                        const $t1 = $.$dRGn.LCIDSM.SenseAirDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $qxfhWi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1173060,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dRGn.LCIDSM.SenseAirDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591107652)
            
            //--TRIMMABLE-BOUNDARY-START(4296140356)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296140356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296140356)
            
            //--TRIMMABLE-BOUNDARY-START(4296140356)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296140356)
            
            static $h = 1173060;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591107652),
    {
      "r": 65537,
      "n": "Register",
      "d": 1173060,
      "h": 8591107652,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591107652)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296140356),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1173060,
      "h": 4296140356,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296140356)
  ],
  "h": 1173060
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1173060)
        
        

        //--TRIMMABLE-BOUNDARY-START(4122180)
        $asm.$cls(`$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class SenseAirDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594056772)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594056772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $mkGDnb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4122180,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594056772)
            
            //--TRIMMABLE-BOUNDARY-START(4299089476)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299089476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299089476)
            
            //--TRIMMABLE-BOUNDARY-START(4299089476)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299089476)
            
            static $h = 4122180;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594056772),
    {
      "r": 65537,
      "n": "Register",
      "d": 4122180,
      "h": 8594056772,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594056772)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299089476),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4122180,
      "h": 4299089476,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299089476)
  ],
  "h": 4122180
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Settings${separator}SenseAirDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4122180)
        
        

        //--TRIMMABLE-BOUNDARY-START(386628)
        $asm.$cls(`$dRGn.LCIDS.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295353924)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295353924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295353924)
            
            static $h = 386628;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295353924),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 386628,
      "h": 4295353924,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295353924)
  ],
  "h": 386628
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(386628)
        
        

        //--TRIMMABLE-BOUNDARY-START(2614852)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirServiceModelTypeDescriptorBuilder`, ($self) => class SenseAirServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592549444)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592549444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dRGn.LCIDSM.SenseAirServiceModelTypeDescriptor()
                        const $t1 = $.$dRGn.LCIDSM.SenseAirServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Vcxqik ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2614852,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dRGn.LCIDSM.SenseAirServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592549444)
            
            //--TRIMMABLE-BOUNDARY-START(4297582148)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297582148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297582148)
            
            //--TRIMMABLE-BOUNDARY-START(4297582148)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297582148)
            
            static $h = 2614852;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592549444),
    {
      "r": 65537,
      "n": "Register",
      "d": 2614852,
      "h": 8592549444,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592549444)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297582148),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2614852,
      "h": 4297582148,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297582148)
  ],
  "h": 2614852
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2614852)
        
        

        //--TRIMMABLE-BOUNDARY-START(2876996)
        $asm.$cls(`$dRGn.LCIDSMS.SenseAirStatusModelTypeDescriptorBuilder`, ($self) => class SenseAirStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592811588)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592811588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dRGn.LCIDSMS.SenseAirStatusModelTypeDescriptor()
                        const $t1 = $.$dRGn.LCIDSMS.SenseAirStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $xLlWwc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2876996,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dRGn.LCIDSMS.SenseAirStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592811588)
            
            //--TRIMMABLE-BOUNDARY-START(4297844292)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297844292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297844292)
            
            //--TRIMMABLE-BOUNDARY-START(4297844292)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297844292)
            
            static $h = 2876996;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592811588),
    {
      "r": 65537,
      "n": "Register",
      "d": 2876996,
      "h": 8592811588,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592811588)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297844292),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2876996,
      "h": 4297844292,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297844292)
  ],
  "h": 2876996
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}Statuses${separator}SenseAirStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2876996)
        
        

        //--TRIMMABLE-BOUNDARY-START(2221636)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirLogModelTypeDescriptorBuilder`, ($self) => class SenseAirLogModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592156228)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592156228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dRGn.LCIDSM.SenseAirLogModelTypeDescriptor()
                        const $t1 = $.$dRGn.LCIDSM.SenseAirLogModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirLogModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $tliwhd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2221636,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dRGn.LCIDSM.SenseAirLogModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592156228)
            
            //--TRIMMABLE-BOUNDARY-START(4297188932)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297188932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297188932)
            
            //--TRIMMABLE-BOUNDARY-START(4297188932)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297188932)
            
            static $h = 2221636;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592156228),
    {
      "r": 65537,
      "n": "Register",
      "d": 2221636,
      "h": 8592156228,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592156228)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297188932),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2221636,
      "h": 4297188932,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297188932)
  ],
  "h": 2221636
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirLogModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirLogModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2221636)
        
        

        //--TRIMMABLE-BOUNDARY-START(2090564)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirLogModelCustomAttributesProvider`, ($self) => class SenseAirLogModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297057860)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297057860)
            
            //--TRIMMABLE-BOUNDARY-START(8592025156)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592025156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$dRGn.LCIDSM.SenseAirLogModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Type", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Time", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.ConvertType = ($.$$.S.UInt32.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Value", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$dRGn.LCIDSM.SenseAirLogModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $seIbNa ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2090564,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $PgtjYj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2090564,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592025156)
            
            static $h = 2090564;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592025156),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2090564,
      "h": 8592025156,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592025156)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297057860),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2090564,
      "h": 4297057860,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297057860)
  ],
  "h": 2090564
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirLogModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirLogModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2090564)
        
        

        //--TRIMMABLE-BOUNDARY-START(648772)
        $asm.$cls(`$dRGn.LCIDSMC.SenseAirControlOnOffModelTypeDescriptorBuilder`, ($self) => class SenseAirControlOnOffModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590583364)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590583364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dRGn.LCIDSMC.SenseAirControlOnOffModelTypeDescriptor()
                        const $t1 = $.$dRGn.LCIDSMC.SenseAirControlOnOffModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SenseAir.Models.Controls.SenseAirControlOnOffModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $IpQjjc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":648772,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dRGn.LCIDSMC.SenseAirControlOnOffModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590583364)
            
            //--TRIMMABLE-BOUNDARY-START(4295616068)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295616068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295616068)
            
            //--TRIMMABLE-BOUNDARY-START(4295616068)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295616068)
            
            static $h = 648772;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590583364),
    {
      "r": 65537,
      "n": "Register",
      "d": 648772,
      "h": 8590583364,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590583364)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295616068),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 648772,
      "h": 4295616068,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295616068)
  ],
  "h": 648772
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.Controls.SenseAirControlOnOffModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}Controls${separator}SenseAirControlOnOffModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(648772)
        
        

        //--TRIMMABLE-BOUNDARY-START(1435204)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class SenseAirDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591369796)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591369796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $XuMuGd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1435204,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591369796)
            
            //--TRIMMABLE-BOUNDARY-START(4296402500)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296402500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296402500)
            
            //--TRIMMABLE-BOUNDARY-START(4296402500)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296402500)
            
            static $h = 1435204;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591369796),
    {
      "r": 65537,
      "n": "Register",
      "d": 1435204,
      "h": 8591369796,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591369796)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296402500),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1435204,
      "h": 4296402500,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296402500)
  ],
  "h": 1435204
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1435204)
        
        

        //--TRIMMABLE-BOUNDARY-START(4384324)
        $asm.$cls(`$dRGn.LCIDSS$1.SenseAirDeviceSettingsTypeDescriptorBuilder`, ($self) => class SenseAirDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594318916)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594318916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$dRGn.LCIDSS$1.SenseAirDeviceSettingsTypeDescriptor()
                        const $t1 = $.$dRGn.LCIDSS$1.SenseAirDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $UJeUKg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4384324,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$dRGn.LCIDSS$1.SenseAirDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594318916)
            
            //--TRIMMABLE-BOUNDARY-START(4299351620)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299351620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299351620)
            
            //--TRIMMABLE-BOUNDARY-START(4299351620)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299351620)
            
            static $h = 4384324;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594318916),
    {
      "r": 65537,
      "n": "Register",
      "d": 4384324,
      "h": 8594318916,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594318916)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299351620),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4384324,
      "h": 4299351620,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299351620)
  ],
  "h": 4384324
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Settings${separator}SenseAirDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4384324)
        
        

        //--TRIMMABLE-BOUNDARY-START(3991108)
        $asm.$cls(`$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class SenseAirDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298958404)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298958404)
            
            //--TRIMMABLE-BOUNDARY-START(8593925700)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593925700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Automate", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Key = "gla";
                            $i3.Order = (256);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $fBapFi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3991108,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $qXZmjh ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3991108,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593925700)
            
            static $h = 3991108;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593925700),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3991108,
      "h": 8593925700,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593925700)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298958404),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3991108,
      "h": 4298958404,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298958404)
  ],
  "h": 3991108
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Settings${separator}SenseAirDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3991108)
        
        

        //--TRIMMABLE-BOUNDARY-START(779844)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirBroadcastActionTypeCustomAttributesProvider`, ($self) => class SenseAirBroadcastActionTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295747140)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295747140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295747140)
            
            static $h = 779844;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295747140),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 779844,
      "h": 4295747140,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295747140)
  ],
  "h": 779844
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirBroadcastActionTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirBroadcastActionTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(779844)
        
        

        //--TRIMMABLE-BOUNDARY-START(3270212)
        $asm.$cls(`$dRGn.LCIDS.SenseAirDeviceBroadcastAction`, ($self) => class SenseAirDeviceBroadcastAction extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30068041284)
            /*iSmartDeviceLogic*/ State = 0;
            //--TRIMMABLE-BOUNDARY-END(30068041284)
            
            //--TRIMMABLE-BOUNDARY-START(8593204804)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593204804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593204804)
            
            //--TRIMMABLE-BOUNDARY-START(8593204804)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8593204804)
            
            static $h = 3270212;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30068041284),
    {
      "p": 17733009,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183139396,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25773073988,
        "f": 83886081
      },
      "n": "State",
      "d": 3270212,
      "h": 30068041284,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30068041284)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593204804),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3270212,
      "h": 8593204804,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593204804)
  ],
  "h": 3270212
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.SenseAirDeviceBroadcastAction`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}SenseAirDeviceBroadcastAction`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3270212)
        
        

        //--TRIMMABLE-BOUNDARY-START(255556)
        $asm.$cls(`$dRGn.LCIDS.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180124740)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180124740)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295222852)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295222852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295222852)
            
            //--TRIMMABLE-BOUNDARY-START(4295222852)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295222852)
            
            static $h = 255556;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180124740),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885157444,
        "f": 50331649
      },
      "n": "Paths",
      "d": 255556,
      "h": 17180124740,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180124740)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295222852),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 255556,
      "h": 4295222852,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295222852)
  ],
  "h": 255556
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(255556)
        
        

        //--TRIMMABLE-BOUNDARY-START(3663428)
        $asm.$cls(`$dRGn.LCIDS.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593598020)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593598020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$dRGn.LCIDS.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$dRGn.LCIDS.SenseAirDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$dRGn.LCIDS.SenseAirDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$dRGn.LCIDS.SenseAirDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$dRGn.LCIDS.SenseAirDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$dRGn.LCIDS.SenseAirDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$dRGn.LCIDS.SenseAirDeviceFamily, x);
                }, $ZNGala ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":3663428,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$dRGn.LCIDS.SenseAirDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$dRGn.LCIDS.SenseAirDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $HavyMb ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":3663428,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$dRGn.LCIDS.SenseAirDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$dRGn.LCIDS.SenseAirDeviceFamily, x);
                }, $nzQTUc ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$dRGn.LCIDS.SenseAirDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":3663428,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$dRGn.LCIDS.SenseAirDevice, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$dRGn.LCIDS.SenseAirDevice, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$dRGn.LCIDS.SenseAirDevice, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$dRGn.LCIDS.SenseAirDevice), $.$dRGn.LCIDSPC.SenseAirDeviceCommands$$($.$dRGn.LCIDS.SenseAirDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$dRGn.LCIDS.SenseAirDevice), $.$dRGn.LCIDSV.SenseAirViewRenderer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8593598020)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$dRGn.LCIDS.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298630724)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298630724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298630724)
            
            //--TRIMMABLE-BOUNDARY-START(4298630724)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298630724)
            
            static $h = 3663428;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593598020),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3663428,
      "h": 8593598020,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593598020)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298630724),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3663428,
      "h": 4298630724,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298630724)
  ],
  "h": 3663428
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3663428)
        
        

        //--TRIMMABLE-BOUNDARY-START(2025028)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirLogModel`, ($self) => class SenseAirLogModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(115966142020)
            /*SenseAirLogType*/ Type = 0;
            //--TRIMMABLE-BOUNDARY-END(115966142020)
            
            //--TRIMMABLE-BOUNDARY-START(107376207428)
            /*DateTime*/ Time;
            //--TRIMMABLE-BOUNDARY-END(107376207428)
            
            //--TRIMMABLE-BOUNDARY-START(120261109316)
            /*int*/ Value = 0;
            //--TRIMMABLE-BOUNDARY-END(120261109316)
            
            //--TRIMMABLE-BOUNDARY-START(111671174724)
            /*string */ get Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836599876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Enum.ToStringT($.$dRGn.LCIDSM.SenseAirLogType, $.$$.S.Byte, this.Type));
            }
            //--TRIMMABLE-BOUNDARY-END(111671174724)
            
            //--TRIMMABLE-BOUNDARY-START(21476861508)
            /*string */ get Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066796100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(this.Type)
                {
                    case 1/*SenseAirLogType.ChangedState*/:
                    return this.Value > 0 ? "Was turned on" : "Wast turned off";
                    case 2/*SenseAirLogType.SetCountdown*/:
                    return `Set countdown for ${$.$strNN(this.Value)}s`;
                    case 3/*SenseAirLogType.CountdownTimeout*/:
                    return `${$.$strNN((this.Value > 0 ? "ON" : "OFF"))} at countdown timeout`;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(21476861508)
            
            //--TRIMMABLE-BOUNDARY-START(77311436356)
            /*string */ get Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656730692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(this.Type)
                {
                    case 1/*SenseAirLogType.ChangedState*/:
                    return this.Value > 0 ? "mdi mdi-electric-switch-closed"/*MaterialDesignIconNames.ElectricSwitchClosed*/ : "mdi mdi-electric-switch"/*MaterialDesignIconNames.ElectricSwitch*/;
                    case 2/*SenseAirLogType.SetCountdown*/:
                    return "mdi mdi-counter"/*MaterialDesignIconNames.Counter*/;
                    case 3/*SenseAirLogType.CountdownTimeout*/:
                    return "mdi mdi-alarm-bell"/*MaterialDesignIconNames.AlarmBell*/;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(77311436356)
            
            //--TRIMMABLE-BOUNDARY-START(17181894212)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181894212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181894212)
            
            //--TRIMMABLE-BOUNDARY-START(17181894212)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17181894212)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(107376207428)
                this.Time = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(107376207428)
                
            }
            static $h = 2025028;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115966142020),
    {
      "p": 2287172,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426534468,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94491305540,
        "f": 83886081
      },
      "n": "Type",
      "d": 2025028,
      "h": 115966142020,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115966142020),
//--TRIMMABLE-BOUNDARY-START(107376207428),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246665284,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85901370948,
        "f": 83886081
      },
      "n": "Time",
      "d": 2025028,
      "h": 107376207428,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 720897,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107376207428),
//--TRIMMABLE-BOUNDARY-START(120261109316),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016469060,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103081240132,
        "f": 83886081
      },
      "n": "Value",
      "d": 2025028,
      "h": 120261109316,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120261109316),
//--TRIMMABLE-BOUNDARY-START(111671174724),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836599876,
        "f": 50331649
      },
      "n": "Title",
      "d": 2025028,
      "h": 111671174724,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111671174724),
//--TRIMMABLE-BOUNDARY-START(21476861508),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066796100,
        "f": 50331649
      },
      "n": "Description",
      "d": 2025028,
      "h": 21476861508,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476861508),
//--TRIMMABLE-BOUNDARY-START(77311436356),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656730692,
        "f": 50331649
      },
      "n": "Icon",
      "d": 2025028,
      "h": 77311436356,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311436356)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181894212),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2025028,
      "h": 17181894212,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181894212)
  ],
  "h": 2025028
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirLogModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirLogModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2025028)
        
        

        //--TRIMMABLE-BOUNDARY-START(2942532)
        $asm.$cls(`$dRGn.LCIDS.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17182811716)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$dRGn.LCIDSV.SenseAirDeviceDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$dRGn.LCIDSV.SenseAirDeviceDetails().$ctor$4();
                    }, $hByaOh ??= {"r":2752627,"n":"","d":2942532,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17182811716)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4297909828)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297909828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297909828)
            
            //--TRIMMABLE-BOUNDARY-START(4297909828)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297909828)
            
            static $h = 2942532;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182811716),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887844420,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 2942532,
      "h": 17182811716,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182811716)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297909828),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2942532,
      "h": 4297909828,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297909828)
  ],
  "h": 2942532
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2942532)
        
        

        //--TRIMMABLE-BOUNDARY-START(4712004)
        $asm.$cls(`$dRGn.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299679300)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299679300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299679300)
            
            //--TRIMMABLE-BOUNDARY-START(4299679300)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299679300)
            
            static $h = 4712004;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299679300),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4712004,
      "h": 4299679300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299679300)
  ],
  "h": 4712004
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4712004)
        
        

        //--TRIMMABLE-BOUNDARY-START(4777540)
        $asm.$cls(`$dRGn.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299744836)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299744836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299744836)
            
            //--TRIMMABLE-BOUNDARY-START(4299744836)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299744836)
            
            static $h = 4777540;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299744836),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4777540,
      "h": 4299744836,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299744836)
  ],
  "h": 4777540,
  "a": [
    {
      "t": 4712004,
      "c": 4299679300
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4777540)
        
        

        //--TRIMMABLE-BOUNDARY-START(452164)
        $asm.$cls(`$dRGn.LCIDSMC.SenseAirControlOnOffModel`, ($self) => class SenseAirControlOnOffModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(12885354052)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885354052);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885354052)
            
            //--TRIMMABLE-BOUNDARY-START(17180321348)
            $ctor$3(/*bool*/ on)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180321348);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.On = on;
                    this.LogTime = $.$fPer.LCFCDC.PackedDateTime.Pack($.$$.S.DateTime.UtcNow, 2020);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180321348)
            
            //--TRIMMABLE-BOUNDARY-START(21475288644)
            /*int */ get Command()
            {
                return ((128 + 3) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(21475288644)
            
            //--TRIMMABLE-BOUNDARY-START(55835027012)
            /*bool*/ On = false;
            //--TRIMMABLE-BOUNDARY-END(55835027012)
            
            //--TRIMMABLE-BOUNDARY-START(51540059716)
            /*uint*/ LogTime = 0;
            //--TRIMMABLE-BOUNDARY-END(51540059716)
            
            //--TRIMMABLE-BOUNDARY-START(12885354052)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885354052)
            
            static $h = 452164;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475288644),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065223236,
        "f": 50364417
      },
      "n": "Command",
      "d": 452164,
      "h": 21475288644,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475288644),
//--TRIMMABLE-BOUNDARY-START(55835027012),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245092420,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014896196,
        "f": 83886081
      },
      "n": "On",
      "d": 452164,
      "h": 55835027012,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835027012),
//--TRIMMABLE-BOUNDARY-START(51540059716),
    {
      "p": 720897,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655157828,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424961604,
        "f": 83886081
      },
      "n": "LogTime",
      "d": 452164,
      "h": 51540059716,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540059716)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885354052),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 452164,
      "h": 12885354052,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885354052),
//--TRIMMABLE-BOUNDARY-START(17180321348),
    {
      "p": [
        {
          "n": "on",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 452164,
      "h": 17180321348,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180321348)
  ],
  "h": 452164
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.Controls.SenseAirControlOnOffModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}Controls${separator}SenseAirControlOnOffModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(452164)
        
        

        //--TRIMMABLE-BOUNDARY-START(2680388)
        $asm.$cls(`$dRGn.LCIDSMS.SenseAirStatusModel`, ($self) => class SenseAirStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(21477516868)
            /*double*/ AirQuality = 0;
            //--TRIMMABLE-BOUNDARY-END(21477516868)
            
            //--TRIMMABLE-BOUNDARY-START(81607059012)
            /*double*/ Temperature = 0;
            //--TRIMMABLE-BOUNDARY-END(81607059012)
            
            //--TRIMMABLE-BOUNDARY-START(51542287940)
            /*double*/ Humidity = 0;
            //--TRIMMABLE-BOUNDARY-END(51542287940)
            
            //--TRIMMABLE-BOUNDARY-START(17182549572)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182549572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182549572)
            
            //--TRIMMABLE-BOUNDARY-START(17182549572)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17182549572)
            
            static $h = 2680388;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477516868),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067451460,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132222532,
        "f": 83886081
      },
      "n": "AirQuality",
      "d": 2680388,
      "h": 21477516868,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21477516868),
//--TRIMMABLE-BOUNDARY-START(81607059012),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247320644,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77312091716,
        "f": 83886081
      },
      "n": "Temperature",
      "d": 2680388,
      "h": 81607059012,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81607059012),
//--TRIMMABLE-BOUNDARY-START(51542287940),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657386052,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68722157124,
        "f": 83886081
      },
      "n": "Humidity",
      "d": 2680388,
      "h": 51542287940,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51542287940)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182549572),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2680388,
      "h": 17182549572,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182549572)
  ],
  "h": 2680388
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}Statuses${separator}SenseAirStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2680388)
        
        

        //--TRIMMABLE-BOUNDARY-START(714308)
        $asm.$str(`$dRGn.LCIDSM.SenseAirBroadcastActionType`, ($self) => class SenseAirBroadcastActionType extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static Off = 0;
            static On = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(714308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Off": 0n,
                    "On": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295681604)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295681604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295681604)
            
            //--TRIMMABLE-BOUNDARY-START(4295681604)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295681604)
            
            static $h = 714308;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590648900),
    {
      "t": 714308,
      "n": "Off",
      "d": 714308,
      "h": 8590648900,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590648900),
//--TRIMMABLE-BOUNDARY-START(12885616196),
    {
      "t": 714308,
      "n": "On",
      "d": 714308,
      "h": 12885616196,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885616196)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295681604),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 714308,
      "h": 4295681604,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295681604)
  ],
  "h": 714308
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirBroadcastActionType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirBroadcastActionType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(714308)
        
        

        //--TRIMMABLE-BOUNDARY-START(3335748)
        $asm.$str(`$dRGn.LCIDS.SenseAirDeviceBroadcastMessage`, ($self) => class SenseAirDeviceBroadcastMessage extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Impurity = 0;
            static Temperature = 1;
            static Humidity = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3335748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Impurity": 0n,
                    "Temperature": 1n,
                    "Humidity": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298303044)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298303044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298303044)
            
            //--TRIMMABLE-BOUNDARY-START(4298303044)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298303044)
            
            static $h = 3335748;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12888237636),
    {
      "t": 3335748,
      "n": "Impurity",
      "d": 3335748,
      "h": 12888237636,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888237636),
//--TRIMMABLE-BOUNDARY-START(17183204932),
    {
      "t": 3335748,
      "n": "Temperature",
      "d": 3335748,
      "h": 17183204932,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183204932),
//--TRIMMABLE-BOUNDARY-START(8593270340),
    {
      "t": 3335748,
      "n": "Humidity",
      "d": 3335748,
      "h": 8593270340,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593270340)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298303044),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3335748,
      "h": 4298303044,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298303044)
  ],
  "h": 3335748,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.SenseAirDeviceBroadcastMessage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}SenseAirDeviceBroadcastMessage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3335748)
        
        

        //--TRIMMABLE-BOUNDARY-START(845380)
        $asm.$str(`$dRGn.LCIDSM.SenseAirControlType`, ($self) => class SenseAirControlType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static SetOnOff = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(845380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "SetOnOff": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295812676)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295812676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295812676)
            
            //--TRIMMABLE-BOUNDARY-START(4295812676)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295812676)
            
            static $h = 845380;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590779972),
    {
      "t": 845380,
      "n": "None",
      "d": 845380,
      "h": 8590779972,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590779972),
//--TRIMMABLE-BOUNDARY-START(12885747268),
    {
      "t": 845380,
      "n": "SetOnOff",
      "d": 845380,
      "h": 12885747268,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885747268)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295812676),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 845380,
      "h": 4295812676,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295812676)
  ],
  "h": 845380
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirControlType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirControlType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(845380)
        
        

        //--TRIMMABLE-BOUNDARY-START(2287172)
        $asm.$str(`$dRGn.LCIDSM.SenseAirLogType`, ($self) => class SenseAirLogType extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static None = 0;
            static ChangedState = 1;
            static SetCountdown = 2;
            static CountdownTimeout = 3;
            static Power = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2287172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "ChangedState": 1n,
                    "SetCountdown": 2n,
                    "CountdownTimeout": 3n,
                    "Power": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297254468)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297254468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297254468)
            
            //--TRIMMABLE-BOUNDARY-START(4297254468)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297254468)
            
            static $h = 2287172;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182156356),
    {
      "t": 2287172,
      "n": "None",
      "d": 2287172,
      "h": 17182156356,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182156356),
//--TRIMMABLE-BOUNDARY-START(8592221764),
    {
      "t": 2287172,
      "n": "ChangedState",
      "d": 2287172,
      "h": 8592221764,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592221764),
//--TRIMMABLE-BOUNDARY-START(25772090948),
    {
      "t": 2287172,
      "n": "SetCountdown",
      "d": 2287172,
      "h": 25772090948,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772090948),
//--TRIMMABLE-BOUNDARY-START(12887189060),
    {
      "t": 2287172,
      "n": "CountdownTimeout",
      "d": 2287172,
      "h": 12887189060,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887189060),
//--TRIMMABLE-BOUNDARY-START(21477123652),
    {
      "t": 2287172,
      "n": "Power",
      "d": 2287172,
      "h": 21477123652,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477123652)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297254468),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2287172,
      "h": 4297254468,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297254468)
  ],
  "h": 2287172
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirLogType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirLogType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2287172)
        
        

        //--TRIMMABLE-BOUNDARY-START(124484)
        $asm.$cls(`$dRGn.LCIDS._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590059076)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590059076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590059076)
            
            //--TRIMMABLE-BOUNDARY-START(4295091780)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295091780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295091780)
            
            //--TRIMMABLE-BOUNDARY-START(4295091780)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295091780)
            
            static $h = 124484;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590059076),
    {
      "r": 65537,
      "n": "Execute",
      "d": 124484,
      "h": 8590059076,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590059076)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295091780),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 124484,
      "h": 4295091780,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295091780)
  ],
  "h": 124484
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(124484)
        
        

        //--TRIMMABLE-BOUNDARY-START(2156100)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirLogModelTypeDescriptor`, ($self) => class SenseAirLogModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSM.SenseAirLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297123396)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297123396);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dRGn.LCIDSM.SenseAirLogModelTypeDescriptor.GenerateProperties($.$dRGn.LCIDSM.SenseAirLogModel, this, factory);
                    }, $ilVMhi ??= {"r":65537,"n":"","d":2156100,"h":0,"f":17825794}), 0, "SenseAirLogModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SenseAir\\Models_SenseAirLogModel_LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirLogModelTypeDescriptorBuilder.g.cs", "SenseAirLogModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297123396)
            
            //--TRIMMABLE-BOUNDARY-START(12887057988)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887057988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRGn.LCIDSM.SenseAirLogModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$dRGn.LCIDSM.SenseAirLogType, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirLogModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSM.SenseAirLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$dRGn.LCIDSM.SenseAirLogType, ($.$cast(target, $.$dRGn.LCIDSM.SenseAirLogModel)).Type);
                        }, $YPWebk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2156100,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSM.SenseAirLogModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Type = value.AsEnumValue($.$dRGn.LCIDSM.SenseAirLogType);
                        }, $fVWUlj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2156100,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Time"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRGn.LCIDSM.SenseAirLogModel.$type, $.$discardRef(), "Time", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Time")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Time";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirLogModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSM.SenseAirLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$dRGn.LCIDSM.SenseAirLogModel)).Time);
                        }, $BdkOHh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2156100,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSM.SenseAirLogModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Time = value.AsDateTime();
                        }, $FPKNmh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2156100,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Value"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRGn.LCIDSM.SenseAirLogModel.$type, $.$discardRef(), "Value", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Value")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Value";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirLogModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSM.SenseAirLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$dRGn.LCIDSM.SenseAirLogModel)).Value);
                        }, $KAylwi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2156100,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSM.SenseAirLogModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Value = value.AsInt();
                        }, $tfvosf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2156100,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Title"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRGn.LCIDSM.SenseAirLogModel.$type, $.$discardRef(), "Title", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Title")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Title";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirLogModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSM.SenseAirLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$dRGn.LCIDSM.SenseAirLogModel)).Title);
                        }, $PJvQHf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2156100,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRGn.LCIDSM.SenseAirLogModel.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Description";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirLogModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSM.SenseAirLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$dRGn.LCIDSM.SenseAirLogModel)).Description);
                        }, $yiuuLb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2156100,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Icon"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRGn.LCIDSM.SenseAirLogModel.$type, $.$discardRef(), "Icon", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Icon")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Icon";
                        $i11.DelaredOn = "LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirLogModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSM.SenseAirLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$dRGn.LCIDSM.SenseAirLogModel)).Icon);
                        }, $Wbwecc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2156100,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887057988)
            
            //--TRIMMABLE-BOUNDARY-START(17182025284)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirLogModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182025284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$dRGn.LCIDSM.SenseAirLogType));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$dRGn.LCIDSM.SenseAirLogType, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                        _target.Type = _Type;
                    }
                }
                {
                    /*var*/ let _Time = _target.Time;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Time"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _Time, ($v) => _Time = $v, null, true)))
                    {
                        _target.Time = _Time;
                    }
                }
                {
                    /*var*/ let _Value = _target.Value;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Value"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Value, ($v) => _Value = $v, $.$$.S.Int32)))
                    {
                        _target.Value = _Value;
                    }
                }
                {
                    /*var*/ let _Title = _target.Title;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Title"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Title, ($v) => _Title = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Icon = _target.Icon;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Icon"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Icon, ($v) => _Icon = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182025284)
            
            //--TRIMMABLE-BOUNDARY-START(8592090692)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirLogModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592090692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dRGn.LCIDSM.SenseAirLogModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dRGn.LCIDSM.SenseAirLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirLogModel)))
                {
                    /*var*/ let result = $.$dRGn.LCIDSM.SenseAirLogModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirLogModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dRGn.LCIDSM.SenseAirLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirLogModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592090692)
            
            static $h = 2156100;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSM.SenseAirLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887057988),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2156100,
      "h": 12887057988,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887057988),
//--TRIMMABLE-BOUNDARY-START(17182025284),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2025028,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2156100,
      "h": 17182025284,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182025284),
//--TRIMMABLE-BOUNDARY-START(8592090692),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2025028,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2156100,
      "h": 8592090692,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592090692)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297123396),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2156100,
      "h": 4297123396,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297123396)
  ],
  "h": 2156100
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dRGn.LCIDSM.SenseAirLogModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirLogModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirLogModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2156100)
        
        

        //--TRIMMABLE-BOUNDARY-START(2811460)
        $asm.$cls(`$dRGn.LCIDSMS.SenseAirStatusModelTypeDescriptor`, ($self) => class SenseAirStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSMS.SenseAirStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297778756)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297778756);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dRGn.LCIDSMS.SenseAirStatusModelTypeDescriptor.GenerateProperties($.$dRGn.LCIDSMS.SenseAirStatusModel, this, factory);
                    }, $mYSOof ??= {"r":65537,"n":"","d":2811460,"h":0,"f":17825794}), 0, "SenseAirStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SenseAir\\Models_Statuses_SenseAirStatusModel_LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModelTypeDescriptorBuilder.g.cs", "SenseAirStatusModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297778756)
            
            //--TRIMMABLE-BOUNDARY-START(12887713348)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887713348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AirQuality"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRGn.LCIDSMS.SenseAirStatusModel.$type, $.$discardRef(), "AirQuality", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AirQuality")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "AirQuality";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSMS.SenseAirStatusModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$dRGn.LCIDSMS.SenseAirStatusModel)).AirQuality);
                        }, $dPvmlb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2811460,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSMS.SenseAirStatusModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.AirQuality = value.AsDouble();
                        }, $qwxkgl ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2811460,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Temperature"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRGn.LCIDSMS.SenseAirStatusModel.$type, $.$discardRef(), "Temperature", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Temperature")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Temperature";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSMS.SenseAirStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$dRGn.LCIDSMS.SenseAirStatusModel)).Temperature);
                        }, $bDWhLi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2811460,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSMS.SenseAirStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Temperature = value.AsDouble();
                        }, $umQcnj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2811460,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Humidity"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRGn.LCIDSMS.SenseAirStatusModel.$type, $.$discardRef(), "Humidity", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Humidity")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Humidity";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSMS.SenseAirStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$dRGn.LCIDSMS.SenseAirStatusModel)).Humidity);
                        }, $AlJlMg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2811460,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSMS.SenseAirStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.Humidity = value.AsDouble();
                        }, $agnEbg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2811460,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887713348)
            
            //--TRIMMABLE-BOUNDARY-START(17182680644)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182680644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _AirQuality = _target.AirQuality;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AirQuality"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _AirQuality, ($v) => _AirQuality = $v, $.$$.S.Double)))
                    {
                        _target.AirQuality = _AirQuality;
                    }
                }
                {
                    /*var*/ let _Temperature = _target.Temperature;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Temperature"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Temperature, ($v) => _Temperature = $v, $.$$.S.Double)))
                    {
                        _target.Temperature = _Temperature;
                    }
                }
                {
                    /*var*/ let _Humidity = _target.Humidity;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Humidity"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Humidity, ($v) => _Humidity = $v, $.$$.S.Double)))
                    {
                        _target.Humidity = _Humidity;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182680644)
            
            //--TRIMMABLE-BOUNDARY-START(8592746052)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592746052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dRGn.LCIDSMS.SenseAirStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dRGn.LCIDSMS.SenseAirStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSMS.SenseAirStatusModel)))
                {
                    /*var*/ let result = $.$dRGn.LCIDSMS.SenseAirStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSMS.SenseAirStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dRGn.LCIDSMS.SenseAirStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSMS.SenseAirStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592746052)
            
            static $h = 2811460;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSMS.SenseAirStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887713348),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2811460,
      "h": 12887713348,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887713348),
//--TRIMMABLE-BOUNDARY-START(17182680644),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2680388,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2811460,
      "h": 17182680644,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182680644),
//--TRIMMABLE-BOUNDARY-START(8592746052),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2680388,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2811460,
      "h": 8592746052,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592746052)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297778756),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2811460,
      "h": 4297778756,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297778756)
  ],
  "h": 2811460
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dRGn.LCIDSMS.SenseAirStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}Statuses${separator}SenseAirStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2811460)
        
        

        //--TRIMMABLE-BOUNDARY-START(583236)
        $asm.$cls(`$dRGn.LCIDSMC.SenseAirControlOnOffModelTypeDescriptor`, ($self) => class SenseAirControlOnOffModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSMC.SenseAirControlOnOffModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295550532)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295550532);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dRGn.LCIDSMC.SenseAirControlOnOffModelTypeDescriptor.GenerateProperties($.$dRGn.LCIDSMC.SenseAirControlOnOffModel, this, factory);
                    }, $hESwVk ??= {"r":65537,"n":"","d":583236,"h":0,"f":17825794}), 0, "SenseAirControlOnOffModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SenseAir\\Models_Controls_SenseAirControlOnOffModel_LivingThing.Core.IOT.Devices.SenseAir.Models.Controls.SenseAirControlOnOffModelTypeDescriptorBuilder.g.cs", "SenseAirControlOnOffModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295550532)
            
            //--TRIMMABLE-BOUNDARY-START(12885485124)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885485124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("On"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRGn.LCIDSMC.SenseAirControlOnOffModel.$type, $.$discardRef(), "On", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("On")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "On";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.SenseAir.Models.Controls.SenseAirControlOnOffModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSMC.SenseAirControlOnOffModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$dRGn.LCIDSMC.SenseAirControlOnOffModel)).On);
                        }, $dCrcsb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":583236,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSMC.SenseAirControlOnOffModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.On = value.AsBool();
                        }, $IkxOOb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":583236,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LogTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRGn.LCIDSMC.SenseAirControlOnOffModel.$type, $.$discardRef(), "LogTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LogTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.UInt32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "LogTime";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.SenseAir.Models.Controls.SenseAirControlOnOffModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSMC.SenseAirControlOnOffModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$13(($.$cast(target, $.$dRGn.LCIDSMC.SenseAirControlOnOffModel)).LogTime);
                        }, $amaged ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":583236,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSMC.SenseAirControlOnOffModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.LogTime = value.AsUInt();
                        }, $AjvKPk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":583236,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRGn.LCIDSMC.SenseAirControlOnOffModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Command";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.SenseAir.Models.Controls.SenseAirControlOnOffModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSMC.SenseAirControlOnOffModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$dRGn.LCIDSMC.SenseAirControlOnOffModel)).Command);
                        }, $utLvVd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":583236,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885485124)
            
            //--TRIMMABLE-BOUNDARY-START(17180452420)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Models.Controls.SenseAirControlOnOffModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180452420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _On = _target.On;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("On"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _On, ($v) => _On = $v, null, true)))
                    {
                        _target.On = _On;
                    }
                }
                {
                    /*var*/ let _LogTime = _target.LogTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LogTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.UInt32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.UInt32, property, $.$ref(() => _LogTime, ($v) => _LogTime = $v, $.$$.S.UInt32)))
                    {
                        _target.LogTime = _LogTime;
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180452420)
            
            //--TRIMMABLE-BOUNDARY-START(8590517828)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Models.Controls.SenseAirControlOnOffModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590517828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dRGn.LCIDSMC.SenseAirControlOnOffModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dRGn.LCIDSMC.SenseAirControlOnOffModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSMC.SenseAirControlOnOffModel)))
                {
                    /*var*/ let result = $.$dRGn.LCIDSMC.SenseAirControlOnOffModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSMC.SenseAirControlOnOffModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dRGn.LCIDSMC.SenseAirControlOnOffModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSMC.SenseAirControlOnOffModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590517828)
            
            static $h = 583236;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSMC.SenseAirControlOnOffModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885485124),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 583236,
      "h": 12885485124,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885485124),
//--TRIMMABLE-BOUNDARY-START(17180452420),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 452164,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 583236,
      "h": 17180452420,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180452420),
//--TRIMMABLE-BOUNDARY-START(8590517828),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 452164,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 583236,
      "h": 8590517828,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590517828)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295550532),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 583236,
      "h": 4295550532,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295550532)
  ],
  "h": 583236
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dRGn.LCIDSMC.SenseAirControlOnOffModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.Controls.SenseAirControlOnOffModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}Controls${separator}SenseAirControlOnOffModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(583236)
        
        

        //--TRIMMABLE-BOUNDARY-START(3008068)
        $asm.$cls(`$dRGn.LCIDSPC.SenseAirDeviceCommands<>`, (TDevice) => $asm.$gt(`$dRGn.LCIDSPC.SenseAirDeviceCommands<>`, [TDevice], ($self) => class SenseAirDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12887909956)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12887909956)
            
            //--TRIMMABLE-BOUNDARY-START(17182877252)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182877252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$dRGn.LCIDSPC.SenseAirDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17182877252)
            
            //--TRIMMABLE-BOUNDARY-START(8592942660)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592942660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592942660)
            
            //--TRIMMABLE-BOUNDARY-START(8592942660)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8592942660)
            
            //--TRIMMABLE-BOUNDARY-START(4297975364)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297975364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12887909956)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [new $.$dRGn.LCIDSPCV.SenseAirOnOffCommand().$ctor$6()], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12887909956)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297975364)
            
            static $H = 3008068;
            static $h = 3008068;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182877252),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17182877252,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17182877252)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887909956),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12887909956,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12887909956)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592942660),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8592942660,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592942660)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 3008068,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Protocol.Commands.SenseAirDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Protocol${separator}Commands${separator}SenseAirDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3008068)
        
        

        //--TRIMMABLE-BOUNDARY-START(3073604)
        $asm.$cls(`$dRGn.LCIDSPCV.SenseAirOnOffCommand`, ($self) => class SenseAirOnOffCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$dRGn.LCIDSMC.SenseAirControlOnOffModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298040900)
            $ctor$6()
            {
                super.$ctor$5("On/Off", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298040900);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298040900)
            
            //--TRIMMABLE-BOUNDARY-START(17182942788)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-electric-switch"/*MaterialDesignIconNames.ElectricSwitch*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17182942788)
            
            //--TRIMMABLE-BOUNDARY-START(4298040900)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4298040900)
            
            static $h = 3073604;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$dRGn.LCIDSMC.SenseAirControlOnOffModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182942788),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887975492,
        "f": 50364417
      },
      "n": "Icon",
      "d": 3073604,
      "h": 17182942788,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17182942788)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298040900),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 3073604,
      "h": 4298040900,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298040900)
  ],
  "h": 3073604
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Protocol.Commands.Variants.SenseAirOnOffCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Protocol${separator}Commands${separator}Variants${separator}SenseAirOnOffCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3073604)
        
        

        //--TRIMMABLE-BOUNDARY-START(1762884)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirDeviceSendDataModel`, ($self) => class SenseAirDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceCommandsModel
        {
            //--TRIMMABLE-BOUNDARY-START(8591697476)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591697476);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591697476)
            
            //--TRIMMABLE-BOUNDARY-START(12886664772)
            $ctor$5(/*SenseAirControlOnOffModel*/ onOff)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886664772);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.OnOff = onOff;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886664772)
            
            //--TRIMMABLE-BOUNDARY-START(25771566660)
            /*SenseAirControlOnOffModel?*/ OnOff = null;
            //--TRIMMABLE-BOUNDARY-END(25771566660)
            
            //--TRIMMABLE-BOUNDARY-START(8591697476)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8591697476)
            
            static $h = 1762884;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandsModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771566660),
    {
      "p": 452164,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476599364,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34361501252,
        "f": 83886081
      },
      "n": "OnOff",
      "d": 1762884,
      "h": 25771566660,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 13432,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771566660)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591697476),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1762884,
      "h": 8591697476,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591697476),
//--TRIMMABLE-BOUNDARY-START(12886664772),
    {
      "p": [
        {
          "n": "onOff",
          "p": 452164
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1762884,
      "h": 12886664772,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886664772)
  ],
  "h": 1762884
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1762884)
        
        

        //--TRIMMABLE-BOUNDARY-START(1238596)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel`, ($self) => class SenseAirDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$dRGn.LCIDSMS.SenseAirStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296205892)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296205892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296205892)
            
            //--TRIMMABLE-BOUNDARY-START(4296205892)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296205892)
            
            static $h = 1238596;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$dRGn.LCIDSMS.SenseAirStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296205892),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1238596,
      "h": 4296205892,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296205892)
  ],
  "h": 1238596
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1238596)
        
        

        //--TRIMMABLE-BOUNDARY-START(1893956)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirDeviceSendDataModelTypeDescriptor`, ($self) => class SenseAirDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSM.SenseAirDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296861252)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296861252);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dRGn.LCIDSM.SenseAirDeviceSendDataModelTypeDescriptor.GenerateProperties($.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, this, factory);
                    }, $LJGWnk ??= {"r":65537,"n":"","d":1893956,"h":0,"f":17825794}), 0, "SenseAirDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SenseAir\\Models_SenseAirDeviceSendDataModel_LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceSendDataModelTypeDescriptorBuilder.g.cs", "SenseAirDeviceSendDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296861252)
            
            //--TRIMMABLE-BOUNDARY-START(12886795844)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886795844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("OnOff"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel.$type, $.$discardRef(), "OnOff", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("OnOff")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$dRGn.LCIDSMC.SenseAirControlOnOffModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "OnOff";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceSendDataModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSM.SenseAirDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$dRGn.LCIDSMC.SenseAirControlOnOffModel, ($.$cast(target, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel)).OnOff);
                        }, $OorUTe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1893956,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSM.SenseAirDeviceSendDataModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.OnOff = value.AsReference($.$dRGn.LCIDSMC.SenseAirControlOnOffModel);
                        }, $PdTgMb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1893956,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886795844)
            
            //--TRIMMABLE-BOUNDARY-START(17181763140)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181763140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandsModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandsModel));
                {
                    /*var*/ let _OnOff = _target.OnOff;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("OnOff"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$dRGn.LCIDSMC.SenseAirControlOnOffModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _OnOff, ($v) => _OnOff = $v, $.$dRGn.LCIDSMC.SenseAirControlOnOffModel)))
                    {
                        _target.OnOff = _OnOff;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181763140)
            
            //--TRIMMABLE-BOUNDARY-START(8591828548)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591828548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$dRGn.LCIDSM.SenseAirDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591828548)
            
            static $h = 1893956;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSM.SenseAirDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886795844),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1893956,
      "h": 12886795844,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886795844),
//--TRIMMABLE-BOUNDARY-START(17181763140),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1762884,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1893956,
      "h": 17181763140,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181763140),
//--TRIMMABLE-BOUNDARY-START(8591828548),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1762884,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1893956,
      "h": 8591828548,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591828548)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296861252),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1893956,
      "h": 4296861252,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296861252)
  ],
  "h": 1893956
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dRGn.LCIDSM.SenseAirDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1893956)
        
        

        //--TRIMMABLE-BOUNDARY-START(1369668)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirDeviceReceivedDataModelTypeDescriptor`, ($self) => class SenseAirDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296336964)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296336964);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, this, factory);
                    }, $jBCgcg ??= {"r":65537,"n":"","d":1369668,"h":0,"f":17825794}), 0, "SenseAirDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SenseAir\\Models_SenseAirDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "SenseAirDeviceReceivedDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296336964)
            
            //--TRIMMABLE-BOUNDARY-START(12886271556)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886271556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$dRGn.LCIDSMS.SenseAirStatusModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886271556)
            
            //--TRIMMABLE-BOUNDARY-START(17181238852)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181238852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$dRGn.LCIDSMS.SenseAirStatusModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$dRGn.LCIDSMS.SenseAirStatusModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181238852)
            
            //--TRIMMABLE-BOUNDARY-START(8591304260)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591304260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591304260)
            
            static $h = 1369668;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886271556),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1369668,
      "h": 12886271556,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886271556),
//--TRIMMABLE-BOUNDARY-START(17181238852),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1238596,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1369668,
      "h": 17181238852,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181238852),
//--TRIMMABLE-BOUNDARY-START(8591304260),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1238596,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1369668,
      "h": 8591304260,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591304260)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296336964),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1369668,
      "h": 4296336964,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296336964)
  ],
  "h": 1369668
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1369668)
        
        

        //--TRIMMABLE-BOUNDARY-START(3139140)
        $asm.$cls(`$dRGn.LCIDS.SenseAirDataConverter`, ($self) => class SenseAirDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298106436)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298106436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298106436)
            
            //--TRIMMABLE-BOUNDARY-START(4298106436)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298106436)
            
            static $h = 3139140;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298106436),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3139140,
      "h": 4298106436,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298106436)
  ],
  "h": 3139140
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.SenseAirDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}SenseAirDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3139140)
        
        

        $asm.$typeProxy("$dRGn.LCIDSM.SenseAirDeviceScopeModel", "$dRGn.LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceScopeModel");
        $asm.$typeProxy("$dRGn.LCIDSM.SenseAirDeviceModel", "$dRGn.LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceModel");
        $asm.$typeProxy("$dRGn.LCIDSS$1.SenseAirDeviceSettings", "$dRGn.LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceSettings");
        $asm.$typeProxy("$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings", "$dRGn.LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceHardwareSettings");
        $asm.$typeProxy("$dRGn.LCIDSS.ISenseAirDeviceStatusHandler", "$dRGn.LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirDeviceStatusHandler");
        $asm.$typeProxy("$dRGn.LCIDSS.ISenseAirDeviceHubClient", "$dRGn.LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirDeviceHubClient");
        $asm.$typeProxy("$dRGn.LCIDSS.ISenseAirRemoteService", "$dRGn.LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirRemoteService");
        //--TRIMMABLE-BOUNDARY-START(2418244)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirServiceModel`, ($self) => class SenseAirServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297385540)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297385540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297385540)
            
            //--TRIMMABLE-BOUNDARY-START(4297385540)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4297385540)
            
            static $h = 2418244;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297385540),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 2418244,
      "h": 4297385540,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297385540)
  ],
  "h": 2418244
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2418244)
        
        

        //--TRIMMABLE-BOUNDARY-START(1500740)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirDeviceScopeModel`, ($self) => class SenseAirDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296468036)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296468036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296468036)
            
            //--TRIMMABLE-BOUNDARY-START(4296468036)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296468036)
            
            static $h = 1500740;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296468036),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1500740,
      "h": 4296468036,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296468036)
  ],
  "h": 1500740
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1500740)
        
        

        //--TRIMMABLE-BOUNDARY-START(976452)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirDeviceModel`, ($self) => class SenseAirDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295943748)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295943748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295943748)
            
            //--TRIMMABLE-BOUNDARY-START(4295943748)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295943748)
            
            static $h = 976452;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295943748),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 976452,
      "h": 4295943748,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295943748)
  ],
  "h": 976452
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(976452)
        
        

        //--TRIMMABLE-BOUNDARY-START(3794500)
        $asm.$cls(`$dRGn.LCIDSS.ISenseAirDeviceStatusHandler`, ($self) => class ISenseAirDeviceStatusHandler
        {
            static $h = 3794500;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3794500
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Services${separator}ISenseAirDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3794500)
        
        

        //--TRIMMABLE-BOUNDARY-START(4187716)
        $asm.$cls(`$dRGn.LCIDSS$1.SenseAirDeviceSettings`, ($self) => class SenseAirDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $self, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4299155012)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299155012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299155012)
            
            //--TRIMMABLE-BOUNDARY-START(4299155012)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4299155012)
            
            static $h = 4187716;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299155012),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4187716,
      "h": 4299155012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299155012)
  ],
  "h": 4187716
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Settings${separator}SenseAirDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4187716)
        
        

        //--TRIMMABLE-BOUNDARY-START(3728964)
        $asm.$cls(`$dRGn.LCIDSS.ISenseAirDeviceHubClient`, ($self) => class ISenseAirDeviceHubClient
        {
            static $h = 3728964;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3728964
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Services${separator}ISenseAirDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3728964)
        
        

        //--TRIMMABLE-BOUNDARY-START(3860036)
        $asm.$cls(`$dRGn.LCIDSS.ISenseAirRemoteService`, ($self) => class ISenseAirRemoteService
        {
            static $h = 3860036;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3860036
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$dRGn.LCIDSM.SenseAirServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$dRGn.LCIDSM.SenseAirServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$dRGn.LCIDSM.SenseAirServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$dRGn.LCIDSM.SenseAirServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$dRGn.LCIDSM.SenseAirServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$dRGn.LCIDSM.SenseAirServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$dRGn.LCIDSM.SenseAirServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$dRGn.LCIDSM.SenseAirServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Services${separator}ISenseAirRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3860036)
        
        

        //--TRIMMABLE-BOUNDARY-START(3925572)
        $asm.$cls(`$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings`, ($self) => class SenseAirDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(12888827460)
            /*bool*/ Automate = false;
            //--TRIMMABLE-BOUNDARY-END(12888827460)
            
            //--TRIMMABLE-BOUNDARY-START(8593860164)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593860164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593860164)
            
            //--TRIMMABLE-BOUNDARY-START(8593860164)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8593860164)
            
            static $h = 3925572;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12888827460),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478762052,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30068696644,
        "f": 83886081
      },
      "n": "Automate",
      "d": 3925572,
      "h": 12888827460,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "gla",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 256,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12888827460)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593860164),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3925572,
      "h": 8593860164,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593860164)
  ],
  "h": 3925572
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Settings${separator}SenseAirDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3925572)
        
        

        //--TRIMMABLE-BOUNDARY-START(3597892)
        $asm.$cls(`$dRGn.LCIDS.SenseAirDeviceModelDefinition`, ($self) => class SenseAirDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4298565188)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298565188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298565188)
            
            //--TRIMMABLE-BOUNDARY-START(4298565188)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298565188)
            
            static $h = 3597892;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298565188),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3597892,
      "h": 4298565188,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298565188)
  ],
  "h": 3597892
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.SenseAirDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}SenseAirDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3597892)
        
        

        //--TRIMMABLE-BOUNDARY-START(1631812)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirDeviceScopeModelTypeDescriptor`, ($self) => class SenseAirDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSM.SenseAirDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296599108)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296599108);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dRGn.LCIDSM.SenseAirDeviceScopeModelTypeDescriptor.GenerateProperties($.$dRGn.LCIDSM.SenseAirDeviceScopeModel, this, factory);
                    }, $wtMbcj ??= {"r":65537,"n":"","d":1631812,"h":0,"f":17825794}), 0, "SenseAirDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SenseAir\\Models_SenseAirDeviceScopeModel_LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceScopeModelTypeDescriptorBuilder.g.cs", "SenseAirDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296599108)
            
            //--TRIMMABLE-BOUNDARY-START(12886533700)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886533700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886533700)
            
            //--TRIMMABLE-BOUNDARY-START(17181500996)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181500996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceModel, LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceSettings, LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceSendDataModel, LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirDeviceStatusHandler, LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirDeviceHubClient, LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181500996)
            
            //--TRIMMABLE-BOUNDARY-START(8591566404)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591566404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dRGn.LCIDSM.SenseAirDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel)))
                {
                    /*var*/ let result = $.$dRGn.LCIDSM.SenseAirDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591566404)
            
            static $h = 1631812;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSM.SenseAirDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886533700),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1631812,
      "h": 12886533700,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886533700),
//--TRIMMABLE-BOUNDARY-START(17181500996),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1500740,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1631812,
      "h": 17181500996,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181500996),
//--TRIMMABLE-BOUNDARY-START(8591566404),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1500740,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1631812,
      "h": 8591566404,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591566404)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296599108),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1631812,
      "h": 4296599108,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296599108)
  ],
  "h": 1631812
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dRGn.LCIDSM.SenseAirDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1631812)
        
        

        //--TRIMMABLE-BOUNDARY-START(1107524)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirDeviceModelTypeDescriptor`, ($self) => class SenseAirDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSM.SenseAirDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296074820)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296074820);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dRGn.LCIDSM.SenseAirDeviceModelTypeDescriptor.GenerateProperties($.$dRGn.LCIDSM.SenseAirDeviceModel, this, factory);
                    }, $BTQxTf ??= {"r":65537,"n":"","d":1107524,"h":0,"f":17825794}), 0, "SenseAirDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SenseAir\\Models_SenseAirDeviceModel_LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceModelTypeDescriptorBuilder.g.cs", "SenseAirDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296074820)
            
            //--TRIMMABLE-BOUNDARY-START(12886009412)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886009412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886009412)
            
            //--TRIMMABLE-BOUNDARY-START(17180976708)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180976708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceModel, LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceSettings, LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceSendDataModel, LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirDeviceStatusHandler, LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirDeviceHubClient, LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180976708)
            
            //--TRIMMABLE-BOUNDARY-START(8591042116)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591042116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dRGn.LCIDSM.SenseAirDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dRGn.LCIDSM.SenseAirDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirDeviceModel)))
                {
                    /*var*/ let result = $.$dRGn.LCIDSM.SenseAirDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dRGn.LCIDSM.SenseAirDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591042116)
            
            static $h = 1107524;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSM.SenseAirDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886009412),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1107524,
      "h": 12886009412,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886009412),
//--TRIMMABLE-BOUNDARY-START(17180976708),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 976452,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1107524,
      "h": 17180976708,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180976708),
//--TRIMMABLE-BOUNDARY-START(8591042116),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 976452,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1107524,
      "h": 8591042116,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591042116)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296074820),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1107524,
      "h": 4296074820,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296074820)
  ],
  "h": 1107524
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dRGn.LCIDSM.SenseAirDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1107524)
        
        

        //--TRIMMABLE-BOUNDARY-START(4056644)
        $asm.$cls(`$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettingsTypeDescriptor`, ($self) => class SenseAirDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299023940)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299023940);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, this, factory);
                    }, $NsmKPg ??= {"r":65537,"n":"","d":4056644,"h":0,"f":17825794}), 0, "SenseAirDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SenseAir\\Settings_SenseAirDeviceHardwareSettings_LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "SenseAirDeviceHardwareSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299023940)
            
            //--TRIMMABLE-BOUNDARY-START(12888958532)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888958532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Automate"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings.$type, $.$discardRef(), "Automate", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Automate")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Automate";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceHardwareSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings)).Automate);
                        }, $bJuMle ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4056644,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Automate = value.AsBool();
                        }, $tEtQRd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4056644,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888958532)
            
            //--TRIMMABLE-BOUNDARY-START(17183925828)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183925828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceModel, LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceSettings, LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceSendDataModel, LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirDeviceStatusHandler, LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirDeviceHubClient, LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).iSmartDeviceHardwareSettings));
                {
                    /*var*/ let _Automate = _target.Automate;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Automate"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _Automate, ($v) => _Automate = $v, null, true)))
                    {
                        _target.Automate = _Automate;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183925828)
            
            //--TRIMMABLE-BOUNDARY-START(8593991236)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593991236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593991236)
            
            static $h = 4056644;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888958532),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4056644,
      "h": 12888958532,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888958532),
//--TRIMMABLE-BOUNDARY-START(17183925828),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3925572,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4056644,
      "h": 17183925828,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183925828),
//--TRIMMABLE-BOUNDARY-START(8593991236),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3925572,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4056644,
      "h": 8593991236,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593991236)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299023940),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4056644,
      "h": 4299023940,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299023940)
  ],
  "h": 4056644
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Settings${separator}SenseAirDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4056644)
        
        

        //--TRIMMABLE-BOUNDARY-START(2549316)
        $asm.$cls(`$dRGn.LCIDSM.SenseAirServiceModelTypeDescriptor`, ($self) => class SenseAirServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSM.SenseAirServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297516612)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297516612);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dRGn.LCIDSM.SenseAirServiceModelTypeDescriptor.GenerateProperties($.$dRGn.LCIDSM.SenseAirServiceModel, this, factory);
                    }, $cSolaj ??= {"r":65537,"n":"","d":2549316,"h":0,"f":17825794}), 0, "SenseAirServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SenseAir\\Models_SenseAirServiceModel_LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirServiceModelTypeDescriptorBuilder.g.cs", "SenseAirServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297516612)
            
            //--TRIMMABLE-BOUNDARY-START(12887451204)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887451204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887451204)
            
            //--TRIMMABLE-BOUNDARY-START(17182418500)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182418500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceModel, LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceSettings, LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceSendDataModel, LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirDeviceStatusHandler, LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirDeviceHubClient, LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182418500)
            
            //--TRIMMABLE-BOUNDARY-START(8592483908)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592483908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dRGn.LCIDSM.SenseAirServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dRGn.LCIDSM.SenseAirServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirServiceModel)))
                {
                    /*var*/ let result = $.$dRGn.LCIDSM.SenseAirServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dRGn.LCIDSM.SenseAirServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSM.SenseAirServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592483908)
            
            static $h = 2549316;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSM.SenseAirServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887451204),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2549316,
      "h": 12887451204,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887451204),
//--TRIMMABLE-BOUNDARY-START(17182418500),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2418244,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2549316,
      "h": 17182418500,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182418500),
//--TRIMMABLE-BOUNDARY-START(8592483908),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2418244,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2549316,
      "h": 8592483908,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592483908)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297516612),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2549316,
      "h": 4297516612,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297516612)
  ],
  "h": 2549316
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dRGn.LCIDSM.SenseAirServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Models${separator}SenseAirServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2549316)
        
        

        //--TRIMMABLE-BOUNDARY-START(4318788)
        $asm.$cls(`$dRGn.LCIDSS$1.SenseAirDeviceSettingsTypeDescriptor`, ($self) => class SenseAirDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSS$1.SenseAirDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299286084)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299286084);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$dRGn.LCIDSS$1.SenseAirDeviceSettingsTypeDescriptor.GenerateProperties($.$dRGn.LCIDSS$1.SenseAirDeviceSettings, this, factory);
                    }, $JeHdnd ??= {"r":65537,"n":"","d":4318788,"h":0,"f":17825794}), 0, "SenseAirDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SenseAir\\Settings_SenseAirDeviceSettings_LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceSettingsTypeDescriptorBuilder.g.cs", "SenseAirDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299286084)
            
            //--TRIMMABLE-BOUNDARY-START(12889220676)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889220676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889220676)
            
            //--TRIMMABLE-BOUNDARY-START(17184187972)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184187972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceModel, LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceSettings, LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceSendDataModel, LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirDeviceStatusHandler, LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirDeviceHubClient, LivingThing.Core.IOT.Devices.SenseAir.Services.ISenseAirRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService).iSmartDeviceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184187972)
            
            //--TRIMMABLE-BOUNDARY-START(8594253380)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594253380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$dRGn.LCIDSS$1.SenseAirDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings)))
                {
                    /*var*/ let result = $.$dRGn.LCIDSS$1.SenseAirDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594253380)
            
            static $h = 4318788;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$dRGn.LCIDSS$1.SenseAirDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889220676),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4318788,
      "h": 12889220676,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889220676),
//--TRIMMABLE-BOUNDARY-START(17184187972),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4187716,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4318788,
      "h": 17184187972,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184187972),
//--TRIMMABLE-BOUNDARY-START(8594253380),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4187716,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4318788,
      "h": 8594253380,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594253380)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299286084),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4318788,
      "h": 4299286084,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299286084)
  ],
  "h": 4318788
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$dRGn.LCIDSS$1.SenseAirDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Settings.SenseAirDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Settings${separator}SenseAirDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4318788)
        
        

        //--TRIMMABLE-BOUNDARY-START(3204676)
        $asm.$cls(`$dRGn.LCIDS.SenseAirDevice`, ($self) => class SenseAirDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$dRGn.LCIDSMS.SenseAirStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4298171972)
            $ctor$2(/*IIOTDeviceFamily<SenseAirDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*SenseAirDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298171972);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298171972)
            
            //--TRIMMABLE-BOUNDARY-START(47247844932)
            /*IconDescriptor */ get Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067975748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let icon = super.Icon;
                return (() =>
                {
                    //new $.$fPer.LCFC.IconDescriptor()
                    const $t1 = $.$fPer.LCFC.IconDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Icon = $.$XBGm.LCIC.UtilityExtension.MaterialIcon(this.Model$1.DeviceType, this.Detected);
                    $i1.Theme = $.$with(icon.Theme, ($clone) =>
                    {
                        $clone.ForegroundColor = this.Detected ? "FFFF00" : icon.Theme.ForegroundColor;
                    });
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(47247844932)
            
            //--TRIMMABLE-BOUNDARY-START(42952877636)
            /*IconDescriptor */ GetControlOutputDisplay(/*int*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952877636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(input)
                {
                    case 0:
                    return (() =>
                    {
                        //new $.$fPer.LCFC.IconDescriptor()
                        const $t3 = $.$fPer.LCFC.IconDescriptor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Icon = $.$XBGm.LCICDi.iSmartDeviceCommandExtension.GetControlOutputIOState(this, 0) === true ? $.$strNN("mdi mdi-valve-open"/*MaterialDesignIconNames.ValveOpen*/) + " cl-warning" : "mdi mdi-valve-closed"/*MaterialDesignIconNames.ValveClosed*/;
                        return $i3;
                    })();
                    case 1:
                    return (() =>
                    {
                        //new $.$fPer.LCFC.IconDescriptor()
                        const $t4 = $.$fPer.LCFC.IconDescriptor;
                        const $i4 = new $t4();
                        $i4.$ctor$2();
                        $i4.Icon = $.$XBGm.LCICDi.iSmartDeviceCommandExtension.GetControlOutputIOState(this, 1) === true ? $.$strNN("mdi mdi-fan"/*MaterialDesignIconNames.Fan*/) + " cl-warning" : "mdi mdi-fan-off"/*MaterialDesignIconNames.FanOff*/;
                        return $i4;
                    })();
                }
                return super.GetControlOutputDisplay(input);
            }
            //--TRIMMABLE-BOUNDARY-END(42952877636)
            
            //--TRIMMABLE-BOUNDARY-START(12888106564)
            /*bool */ get Detected()
            {
                return (this.Received?.Status?.AirQuality ?? null) < 0.8;
            }
            //--TRIMMABLE-BOUNDARY-END(12888106564)
            
            //--TRIMMABLE-BOUNDARY-START(60132746820)
            /*string */ get StatusText()
            {
                return (this.Received?.Status?.AirQuality ?? null) === null ? "" : this.Received.Status.AirQuality > 0.8 ? "OK" : "GAS";
            }
            //--TRIMMABLE-BOUNDARY-END(60132746820)
            
            //--TRIMMABLE-BOUNDARY-START(51542812228)
            /*Task */ SetOnOff(/*bool*/ on)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542812228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$dRGn.LCIDSPCV.SenseAirOnOffCommand, $.$dRGn.LCIDSMC.SenseAirControlOnOffModel, this, new $.$dRGn.LCIDSPCV.SenseAirOnOffCommand().$ctor$6(), new $.$dRGn.LCIDSMC.SenseAirControlOnOffModel().$ctor$3(on));
            }
            //--TRIMMABLE-BOUNDARY-END(51542812228)
            
            //--TRIMMABLE-BOUNDARY-START(8593139268)
            /*Task */ Clicked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593139268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetOnOff(true);
            }
            //--TRIMMABLE-BOUNDARY-END(8593139268)
            
            //--TRIMMABLE-BOUNDARY-START(55837779524)
            /*void */ SetStatus(/*bool*/ enable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837779524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetOnOff(enable);
            }
            //--TRIMMABLE-BOUNDARY-END(55837779524)
            
            static $h = 3204676;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDS.SenseAirDevice, $.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$dRGn.LCIDSMS.SenseAirStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47247844932),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067975748,
        "f": 50364417
      },
      "n": "Icon",
      "d": 3204676,
      "h": 47247844932,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47247844932),
//--TRIMMABLE-BOUNDARY-START(12888106564),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478041156,
        "f": 50331649
      },
      "n": "Detected",
      "d": 3204676,
      "h": 12888106564,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12888106564),
//--TRIMMABLE-BOUNDARY-START(60132746820),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657910340,
        "f": 50364417
      },
      "n": "StatusText",
      "d": 3204676,
      "h": 60132746820,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60132746820)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42952877636),
    {
      "r": 46238038,
      "p": [
        {
          "n": "input",
          "p": 655361
        }
      ],
      "n": "GetControlOutputDisplay",
      "d": 3204676,
      "h": 42952877636,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42952877636),
//--TRIMMABLE-BOUNDARY-START(51542812228),
    {
      "r": 178454529,
      "p": [
        {
          "n": "on",
          "p": 262145
        }
      ],
      "n": "SetOnOff",
      "d": 3204676,
      "h": 51542812228,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51542812228),
//--TRIMMABLE-BOUNDARY-START(8593139268),
    {
      "r": 178454529,
      "n": "Clicked",
      "d": 3204676,
      "h": 8593139268,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8593139268),
//--TRIMMABLE-BOUNDARY-START(55837779524),
    {
      "r": 65537,
      "p": [
        {
          "n": "enable",
          "p": 262145
        }
      ],
      "n": "SetStatus",
      "d": 3204676,
      "h": 55837779524,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55837779524)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298171972),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$dRGn.LCIDS.SenseAirDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 976452
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3204676,
      "h": 4298171972,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298171972)
  ],
  "h": 3204676
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.SenseAirDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}SenseAirDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3204676)
        
        

        //--TRIMMABLE-BOUNDARY-START(3466820)
        $asm.$cls(`$dRGn.LCIDS.SenseAirDeviceDefinition`, ($self) => class SenseAirDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDS.SenseAirDevice, $.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$dRGn.LCIDSMS.SenseAirStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298434116)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298434116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298434116)
            
            //--TRIMMABLE-BOUNDARY-START(4298434116)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298434116)
            
            static $h = 3466820;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDS.SenseAirDevice, $.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$dRGn.LCIDSMS.SenseAirStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298434116),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3466820,
      "h": 4298434116,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298434116)
  ],
  "h": 3466820
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.SenseAirDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}SenseAirDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3466820)
        
        

        //--TRIMMABLE-BOUNDARY-START(3532356)
        $asm.$cls(`$dRGn.LCIDS.SenseAirDeviceFamily`, ($self) => class SenseAirDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDS.SenseAirDevice, $.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4298499652)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<SenseAirDeviceReceivedDataModel, SenseAirDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<SenseAirDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298499652);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298499652)
            
            //--TRIMMABLE-BOUNDARY-START(8593466948)
            /*Type */ get DeviceBroadcastSendMessageEnumType()
            {
                return $.$dRGn.LCIDS.SenseAirDeviceBroadcastMessage.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8593466948)
            
            static $h = 3532356;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$dRGn.LCIDS.SenseAirDevice, $.$dRGn.LCIDSM.SenseAirServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$dRGn.LCIDSM.SenseAirDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$dRGn.LCIDSM.SenseAirDeviceModel, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel, $.$dRGn.LCIDSS.ISenseAirDeviceStatusHandler, $.$dRGn.LCIDSS.ISenseAirDeviceHubClient, $.$dRGn.LCIDSS.ISenseAirRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8593466948),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183401540,
        "f": 50364417
      },
      "n": "DeviceBroadcastSendMessageEnumType",
      "d": 3532356,
      "h": 8593466948,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8593466948)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298499652),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3532356,
      "h": 4298499652,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298499652)
  ],
  "h": 3532356
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$dRGn.LCIDS.SenseAirDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$dRGn.LCIDS.SenseAirDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.SenseAirDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}SenseAirDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3532356)
        
        

        //--TRIMMABLE-BOUNDARY-START(4646468)
        $asm.$cls(`$dRGn.LCIDSV.SenseAirViewRenderer`, ($self) => class SenseAirViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$dRGn.LCIDS.SenseAirDevice, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299613764)
            $ctor$3(/*IOTRootViewModel*/ root)
            {
                super.$ctor$2(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299613764);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299613764)
            
            //--TRIMMABLE-BOUNDARY-START(8594581060)
            /*RenderFragment */ GetView(/*IClientUnitOfWork*/ ui, /*SenseAirDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>*/ clicked, /*Func<Task>*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594581060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === 3/*DeviceViewType.Details*/)
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$dRGn.LCIDSV.SenseAirDeviceDetails, $.$dRGn.LCIDSV.SenseAirDetailsViewModel, new $.$dRGn.LCIDSV.SenseAirDetailsViewModel().$ctor$9(this.Root, device.OwnerScope, device), true, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(8594581060)
            
            static $h = 4646468;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$dRGn.LCIDS.SenseAirDevice, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594581060),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 3204676
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 4646468,
      "h": 8594581060,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8594581060)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299613764),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4646468,
      "h": 4299613764,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299613764)
  ],
  "h": 4646468
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$dRGn.LCIDS.SenseAirDevice), $.$ntej.LCICD$1.IDeviceViewRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Views.SenseAirViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Views${separator}SenseAirViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4646468)
        
        

        //--TRIMMABLE-BOUNDARY-START(4515396)
        $asm.$cls(`$dRGn.LCIDSV.SenseAirDetailsViewModel`, ($self) => class SenseAirDetailsViewModel extends $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$dRGn.LCIDS.SenseAirDevice, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299482692)
            $ctor$9(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*SenseAirDevice*/ device)
            {
                super.$ctor$8(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299482692);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299482692)
            
            //--TRIMMABLE-BOUNDARY-START(34364253764)
            /*void */ OnPropertyChanged$1(/*object*/ sender, /*PropertyChangedEventArgs*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34364253764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (sender === this.Device$1 && (args.PropertyName === "Status" || args.PropertyName === "ReceivedStatus"))
                {
                    this.RaisePropertyChanged$1("ButtonText");
                }
                super.OnPropertyChanged$1(sender, args);
            }
            //--TRIMMABLE-BOUNDARY-END(34364253764)
            
            //--TRIMMABLE-BOUNDARY-START(42954188356)
            /*string */ get Title()
            {
                return `${$.$strNN(this.Device$1.Model$1.Name)} (Smart SenseAir)`;
            }
            //--TRIMMABLE-BOUNDARY-END(42954188356)
            
            //--TRIMMABLE-BOUNDARY-START(8594449988)
            /*string */ get ButtonText()
            {
                return this.Device$1.Detected ? "ALM" : "OK";
            }
            //--TRIMMABLE-BOUNDARY-END(8594449988)
            
            //--TRIMMABLE-BOUNDARY-START(12889417284)
            /*Task *//*async*/  Click()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12889417284);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t1, $r1;
                        ($t1 = this.Device$1.Clicked(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    }
                    catch($e)
                    {
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12889417284)
            
            //--TRIMMABLE-BOUNDARY-START(38659221060)
            /*Task */ Restart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38659221060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    $.$XBGm.LCICDi.iSmartDeviceCommandExtension.Reset$2(this.Device$1);
                }
                catch($e)
                {
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(38659221060)
            
            static $h = 4515396;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$dRGn.LCIDS.SenseAirDevice, $.$dRGn.LCIDSS$1.SenseAirDeviceSettings, $.$dRGn.LCIDSS$1.SenseAirDeviceHardwareSettings, $.$dRGn.LCIDSM.SenseAirDeviceReceivedDataModel, $.$dRGn.LCIDSM.SenseAirDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42954188356),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069286468,
        "f": 50331649
      },
      "n": "Title",
      "d": 4515396,
      "h": 42954188356,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42954188356),
//--TRIMMABLE-BOUNDARY-START(8594449988),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479351876,
        "f": 50331649
      },
      "n": "ButtonText",
      "d": 4515396,
      "h": 8594449988,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8594449988)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34364253764),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "args",
          "p": 1310738
        }
      ],
      "n": "OnPropertyChanged",
      "o": "@$1",
      "d": 4515396,
      "h": 34364253764,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34364253764),
//--TRIMMABLE-BOUNDARY-START(12889417284),
    {
      "r": 178454529,
      "n": "Click",
      "d": 4515396,
      "h": 12889417284,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(12889417284),
//--TRIMMABLE-BOUNDARY-START(38659221060),
    {
      "r": 178454529,
      "n": "Restart",
      "d": 4515396,
      "h": 38659221060,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38659221060)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299482692),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 3204676
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 4515396,
      "h": 4299482692,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299482692)
  ],
  "h": 4515396
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICDV.IDeviceDetailsViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Views.SenseAirDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Views${separator}SenseAirDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4515396)
        
        

        //--TRIMMABLE-BOUNDARY-START(4580932)
        $asm.$cls(`$dRGn.LCIDSV.SenseAirDeviceDetails`, ($self) => class SenseAirDeviceDetails extends $.$hDPm.LCFCC$1.BaseComponent$$($.$dRGn.LCIDSV.SenseAirDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(51544188484)
            /*SenseAirDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(51544188484)
            
            //--TRIMMABLE-BOUNDARY-START(55839155780)
            /*int*/ which = 0;
            //--TRIMMABLE-BOUNDARY-END(55839155780)
            
            //--TRIMMABLE-BOUNDARY-START(34364319300)
            /*string */ get OptimizedComponentName()
            {
                return "senseairdevicedetails";
            }
            //--TRIMMABLE-BOUNDARY-END(34364319300)
            
            //--TRIMMABLE-BOUNDARY-START(47249221188)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47249221188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$dRGn.LCIDSV.SenseAirDetailsViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(47249221188)
            
            //--TRIMMABLE-BOUNDARY-START(12889482820)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889482820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$dRGn.LCIDS.SenseAirDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$dRGn.LCIDS.SenseAirDevice), this.ViewModel));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(3, "div");
                    __builder2.AddAttribute$5(4, "class", "mgx-a");
                    __builder2.AddMarkupContent(5, "<div class=\"hx-07 bg-success corner-b-5 wf pd-6\"></div>\r\n        ");
                    __builder2.OpenElement(6, "div");
                    __builder2.AddAttribute$5(7, "class", "pd-6 corner-t-5 bg-card");
                    __builder2.OpenElement(8, "div");
                    __builder2.AddAttribute$5(9, "class", "shadow wf bg-card mgt--23 pd-4 corner-2");
                    __builder2.OpenElement(10, "div");
                    __builder2.AddAttribute$5(11, "class", "flex flex-spacebetween");
                    __builder2.OpenElement(12, "div");
                    __builder2.AddAttribute$5(13, "class", "mgt--3");
                    __builder2.OpenElement(14, "p");
                    __builder2.AddAttribute$5(15, "class", "fsz--11 op-7 mgb-1");
                    __builder2.AddContent$3(16, $.$$.S.DateTime.Now);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(17, "\r\n                        ");
                    __builder2.AddMarkupContent(18, "<h4 class=\"mgt-0\">Sunny</h4>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(19, "\r\n                    <i class=\"mdi mdi-sun-compass fsz--28 cl-success\"></i>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(20, "\r\n                ");
                    __builder2.OpenElement(21, "div");
                    __builder2.AddAttribute$5(22, "class", "flex row text-center");
                    __builder2.OpenElement(23, "div");
                    __builder2.AddAttribute$5(24, "class", "mgt--5");
                    __builder2.OpenElement(25, "h2");
                    __builder2.AddAttribute$5(26, "class", "cl-success");
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel?*/ let __ca1__;
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel?*/ let __ca2__;
                    __builder2.AddContent$4(27, ((__ca1__ = this.ViewModel.Device$1.Received) !== null ? ((__ca2__ = __ca1__.Status) !== null ? $.$$.S.Double.ToString$3.call(__ca2__.AirQuality, "0.00") : null) : null));
                    __builder2.AddContent$4(28, "%");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(29, "\r\n                        ");
                    __builder2.AddMarkupContent(30, "<p class=\"fsz--9 op-7 mgt--5\">Air Quality</p>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(31, "\r\n                    ");
                    __builder2.OpenElement(32, "div");
                    __builder2.AddAttribute$5(33, "class", "mgt--5");
                    __builder2.OpenElement(34, "h2");
                    __builder2.AddAttribute$5(35, "class", "cl-success");
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel?*/ let __ca3__;
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel?*/ let __ca4__;
                    __builder2.AddContent$4(36, ((__ca3__ = this.ViewModel.Device$1.Received) !== null ? ((__ca4__ = __ca3__.Status) !== null ? $.$$.S.Double.ToString$3.call(__ca4__.Temperature, "0.00") : null) : null));
                    __builder2.AddMarkupContent(37, "\u00B0C");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(38, "\r\n                        ");
                    __builder2.AddMarkupContent(39, "<p class=\"fsz--9 op-7 mgt--5\">Temperature</p>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(40, "\r\n                    ");
                    __builder2.OpenElement(41, "div");
                    __builder2.AddAttribute$5(42, "class", "mgt--5");
                    __builder2.OpenElement(43, "h2");
                    __builder2.AddAttribute$5(44, "class", "cl-success");
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel?*/ let __ca10__;
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel?*/ let __ca11__;
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel?*/ let __ca12__;
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel?*/ let __ca5__;
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel?*/ let __ca6__;
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel?*/ let __ca7__;
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel?*/ let __ca8__;
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel?*/ let __ca9__;
                    __builder2.AddContent$4(45, ((__ca5__ = this.ViewModel.Device$1.Received) !== null ? ((__ca6__ = __ca5__.Status) !== null ? $.$$.S.Double.ToString$3.call(__ca6__.Humidity, "0.00") : null) : null));
                    __builder2.AddContent$4(46, "%");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(47, "\r\n                        ");
                    __builder2.AddMarkupContent(48, "<p class=\"fsz--9 op-7 mgt--5\">Humidity</p>");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(49, "\r\n            ");
                    __builder2.OpenElement(50, "div");
                    __builder2.AddAttribute$5(51, "class", "row responsive");
                    __builder2.OpenElement(52, "div");
                    __builder2.AddAttribute$5(53, "class", "flex");
                    __builder2.OpenElement(54, "div");
                    __builder2.AddAttribute$5(55, "class", "mg-a");
                    __builder2.OpenElement(56, "div");
                    __builder2.AddAttribute$5(57, "class", "bg-card round mgt-14");
                    __builder2.OpenElement(58, "svg");
                    __builder2.AddAttribute$5(59, "width", "284");
                    __builder2.AddAttribute$5(60, "height", "234");
                    __builder2.AddAttribute$5(61, "viewBox", "0 0 284 234");
                    __builder2.AddAttribute$5(62, "fill", "none");
                    __builder2.AddAttribute$5(63, "xmlns", "http://www.w3.org/2000/svg");
                    __builder2.OpenElement(64, "g");
                    __builder2.AddAttribute$5(65, "clip-path", "url(#clip0_101_2)");
                    __builder2.AddMarkupContent(66, "<g filter=\"url(#filter0_f_101_2)\"><path d=\"M210.4 84.0848C213.228 82.1279 217.128 82.8242 218.88 85.784C228.85 102.632 232.932 122.392 230.364 141.92C227.797 161.448 218.747 179.482 204.761 193.181C202.304 195.587 198.357 195.252 196.13 192.63V192.63C193.904 190.009 194.245 186.096 196.674 183.661C208.318 171.985 215.852 156.76 218.016 140.297C220.18 123.834 216.838 107.179 208.607 92.89C206.89 89.9098 207.572 86.0417 210.4 84.0848V84.0848Z\" fill=\"#77FF95\"></path></g>\r\n                                    ");
                    __builder2.AddMarkupContent(67, "<g filter=\"url(#filter1_d_101_2)\"><path d=\"M210.4 84.0848C213.228 82.1279 217.128 82.8242 218.88 85.784C228.85 102.632 232.932 122.392 230.364 141.92C227.797 161.448 218.747 179.482 204.761 193.181C202.304 195.587 198.357 195.252 196.13 192.63V192.63C193.904 190.009 194.245 186.096 196.674 183.661C208.318 171.985 215.852 156.76 218.016 140.297C220.18 123.834 216.838 107.179 208.607 92.89C206.89 89.9098 207.572 86.0417 210.4 84.0848V84.0848Z\" fill=\"#77FF95\" fill-opacity=\"0.25\" shape-rendering=\"crispEdges\"></path></g>\r\n                                    ");
                    __builder2.AddMarkupContent(68, "<g filter=\"url(#filter2_f_101_2)\"><path d=\"M87.9603 192.103C85.7289 194.806 81.7103 195.205 79.1716 192.787C64.7202 179.027 55.2368 160.777 52.3394 140.911C49.442 121.045 53.3178 100.847 63.2369 83.5324C64.9795 80.4905 68.9445 79.7248 71.8551 81.6785V81.6785C74.7658 83.6323 75.516 87.5648 73.8093 90.6269C65.6261 105.308 62.4589 122.331 64.9015 139.079C67.3441 155.827 75.2415 171.236 87.2772 182.969C89.7874 185.416 90.1917 189.399 87.9603 192.103V192.103Z\" fill=\"#FF7777\"></path></g>\r\n                                    ");
                    __builder2.AddMarkupContent(69, "<g filter=\"url(#filter3_d_101_2)\"><path d=\"M87.9603 192.103C85.7289 194.806 81.7103 195.205 79.1716 192.787C64.7202 179.027 55.2368 160.777 52.3394 140.911C49.442 121.045 53.3178 100.847 63.237 83.5323C64.9795 80.4904 68.9445 79.7247 71.8552 81.6784V81.6784C74.7659 83.6322 75.5161 87.5648 73.8093 90.6268C65.6261 105.308 62.4589 122.331 64.9015 139.079C67.3441 155.827 75.2415 171.236 87.2772 182.969C89.7874 185.416 90.1917 189.399 87.9603 192.103V192.103Z\" fill=\"#FF7777\" fill-opacity=\"0.25\" shape-rendering=\"crispEdges\"></path></g>\r\n                                    ");
                    __builder2.AddMarkupContent(70, "<g filter=\"url(#filter4_f_101_2)\"><path d=\"M71.2886 82.5339C68.354 80.6163 67.512 76.6668 69.6329 73.8755C77.5088 63.5102 87.5689 54.9672 99.1285 48.8702C112.564 41.7841 127.582 38.2353 142.767 38.5583C157.953 38.8813 172.807 43.0655 185.928 50.7166C197.218 57.2996 206.906 66.2627 214.334 76.9535C216.334 79.8324 215.325 83.7425 212.311 85.5337V85.5337C209.298 87.3248 205.424 86.3158 203.39 83.4605C197.086 74.6113 188.961 67.1804 179.533 61.6834C168.274 55.118 155.528 51.5276 142.497 51.2504C129.466 50.9732 116.58 54.0184 105.051 60.099C95.3985 65.1902 86.9643 72.2689 80.2901 80.842C78.1366 83.6082 74.2232 84.4516 71.2886 82.5339V82.5339Z\" fill=\"#7B88FF\"></path></g>\r\n                                    ");
                    __builder2.AddMarkupContent(71, "<g filter=\"url(#filter5_d_101_2)\"><path d=\"M71.2886 82.5339C68.354 80.6163 67.512 76.6668 69.6329 73.8755C77.5088 63.5102 87.5689 54.9672 99.1285 48.8702C112.564 41.7841 127.582 38.2353 142.767 38.5583C157.953 38.8813 172.807 43.0655 185.928 50.7166C197.218 57.2996 206.906 66.2627 214.334 76.9535C216.334 79.8324 215.325 83.7425 212.311 85.5337V85.5337C209.298 87.3248 205.424 86.3158 203.39 83.4605C197.086 74.6113 188.961 67.1804 179.533 61.6834C168.274 55.118 155.528 51.5276 142.497 51.2504C129.466 50.9732 116.58 54.0184 105.051 60.099C95.3985 65.1902 86.9643 72.2689 80.2901 80.842C78.1366 83.6082 74.2232 84.4516 71.2886 82.5339V82.5339Z\" fill=\"#7B88FF\" fill-opacity=\"0.25\" shape-rendering=\"crispEdges\"></path></g>\r\n                                    ");
                    __builder2.AddMarkupContent(72, "<g filter=\"url(#filter6_dd_101_2)\"><circle cx=\"140.564\" cy=\"127.721\" r=\"62.1381\" transform=\"rotate(-2.1696 140.564 127.721)\" fill=\"#F8F8F8\"></circle></g>\r\n                                    <path d=\"M191.119 59.8454C191.171 61.216 190.207 62.1564 189.222 62.1937C188.238 62.231 187.205 61.3663 187.153 59.9957C187.101 58.625 188.065 57.6847 189.05 57.6474C190.034 57.6101 191.067 58.4748 191.119 59.8454Z\" stroke=\"white\" stroke-width=\"3\"></path>\r\n                                    <path d=\"M177.939 75.4907L180.012 74.6073L179.74 76.8444L177.939 75.4907Z\" stroke=\"white\" stroke-width=\"3\"></path>\r\n                                    ");
                    __builder2.OpenElement(73, "text");
                    __builder2.AddAttribute$5(74, "x", "140");
                    __builder2.AddAttribute$5(75, "y", "143");
                    __builder2.AddAttribute$5(76, "fill", "black");
                    __builder2.AddAttribute$5(77, "class", "fsz-40");
                    __builder2.AddAttribute$5(78, "text-anchor", "middle");
                    switch(this.which)
                    {
                        case 0:
                        __builder2.AddContent$4(79, ((__ca7__ = this.ViewModel.Device$1.Received) !== null ? ((__ca8__ = __ca7__.Status) !== null ? $.$$.S.Double.ToString$3.call(__ca8__.AirQuality, "0.0") : null) : null));
                        __builder2.AddContent$4(80, "%");
                        break;
                        case 1:
                        __builder2.AddContent$4(81, ((__ca9__ = this.ViewModel.Device$1.Received) !== null ? ((__ca10__ = __ca9__.Status) !== null ? $.$$.S.Double.ToString$3.call(__ca10__.Temperature, "0") : null) : null));
                        __builder2.AddMarkupContent(82, "\u00B0C");
                        break;
                        case 2:
                        __builder2.AddContent$4(83, ((__ca11__ = this.ViewModel.Device$1.Received) !== null ? ((__ca12__ = __ca11__.Status) !== null ? $.$$.S.Double.ToString$3.call(__ca12__.Humidity, "0") : null) : null));
                        __builder2.AddContent$4(84, "%");
                        break;
                    }
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(85, "\r\n                                ");
                    __builder2.AddMarkupContent(86, "<defs><filter id=\"filter0_f_101_2\" x=\"162.641\" y=\"50.9819\" width=\"100.473\" height=\"175.824\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\"><feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"></feFlood>\r\n                                        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"BackgroundImageFix\" result=\"shape\"></feBlend>\r\n                                        <feGaussianBlur stdDeviation=\"16\" result=\"effect1_foregroundBlur_101_2\"></feGaussianBlur></filter>\r\n                                    <filter id=\"filter1_d_101_2\" x=\"150.641\" y=\"38.9819\" width=\"132.473\" height=\"207.824\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\"><feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"></feFlood>\r\n                                        <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\" result=\"hardAlpha\"></feColorMatrix>\r\n                                        <feMorphology radius=\"16\" operator=\"dilate\" in=\"SourceAlpha\" result=\"effect1_dropShadow_101_2\"></feMorphology>\r\n                                        <feOffset dx=\"4\" dy=\"4\"></feOffset>\r\n                                        <feGaussianBlur stdDeviation=\"16\"></feGaussianBlur>\r\n                                        <feComposite in2=\"hardAlpha\" operator=\"out\"></feComposite>\r\n                                        <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 1 0 0 0 0 0.0999999 0 0 0 0.5 0\"></feColorMatrix>\r\n                                        <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow_101_2\"></feBlend>\r\n                                        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow_101_2\" result=\"shape\"></feBlend></filter>\r\n                                    <filter id=\"filter2_f_101_2\" x=\"19.4026\" y=\"48.6043\" width=\"102.018\" height=\"177.783\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\"><feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"></feFlood>\r\n                                        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"BackgroundImageFix\" result=\"shape\"></feBlend>\r\n                                        <feGaussianBlur stdDeviation=\"16\" result=\"effect1_foregroundBlur_101_2\"></feGaussianBlur></filter>\r\n                                    <filter id=\"filter3_d_101_2\" x=\"7.40259\" y=\"36.6042\" width=\"134.018\" height=\"209.783\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\"><feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"></feFlood>\r\n                                        <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\" result=\"hardAlpha\"></feColorMatrix>\r\n                                        <feMorphology radius=\"16\" operator=\"dilate\" in=\"SourceAlpha\" result=\"effect1_dropShadow_101_2\"></feMorphology>\r\n                                        <feOffset dx=\"4\" dy=\"4\"></feOffset>\r\n                                        <feGaussianBlur stdDeviation=\"16\"></feGaussianBlur>\r\n                                        <feComposite in2=\"hardAlpha\" operator=\"out\"></feComposite>\r\n                                        <feColorMatrix type=\"matrix\" values=\"0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5 0\"></feColorMatrix>\r\n                                        <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow_101_2\"></feBlend>\r\n                                        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow_101_2\" result=\"shape\"></feBlend></filter>\r\n                                    <filter id=\"filter4_f_101_2\" x=\"36.4509\" y=\"6.53809\" width=\"210.92\" height=\"111.889\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\"><feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"></feFlood>\r\n                                        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"BackgroundImageFix\" result=\"shape\"></feBlend>\r\n                                        <feGaussianBlur stdDeviation=\"16\" result=\"effect1_foregroundBlur_101_2\"></feGaussianBlur></filter>\r\n                                    <filter id=\"filter5_d_101_2\" x=\"24.4509\" y=\"-5.46191\" width=\"242.92\" height=\"143.889\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\"><feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"></feFlood>\r\n                                        <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\" result=\"hardAlpha\"></feColorMatrix>\r\n                                        <feMorphology radius=\"16\" operator=\"dilate\" in=\"SourceAlpha\" result=\"effect1_dropShadow_101_2\"></feMorphology>\r\n                                        <feOffset dx=\"4\" dy=\"4\"></feOffset>\r\n                                        <feGaussianBlur stdDeviation=\"16\"></feGaussianBlur>\r\n                                        <feComposite in2=\"hardAlpha\" operator=\"out\"></feComposite>\r\n                                        <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0.1625 0 0 0 0 0.24625 0 0 0 0 1 0 0 0 0.5 0\"></feColorMatrix>\r\n                                        <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow_101_2\"></feBlend>\r\n                                        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow_101_2\" result=\"shape\"></feBlend></filter>\r\n                                    <filter id=\"filter6_dd_101_2\" x=\"50.4248\" y=\"37.5819\" width=\"180.278\" height=\"180.278\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\"><feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"></feFlood>\r\n                                        <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\" result=\"hardAlpha\"></feColorMatrix>\r\n                                        <feMorphology radius=\"10\" operator=\"dilate\" in=\"SourceAlpha\" result=\"effect1_dropShadow_101_2\"></feMorphology>\r\n                                        <feOffset dx=\"2\" dy=\"2\"></feOffset>\r\n                                        <feGaussianBlur stdDeviation=\"8\"></feGaussianBlur>\r\n                                        <feComposite in2=\"hardAlpha\" operator=\"out\"></feComposite>\r\n                                        <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.03 0\"></feColorMatrix>\r\n                                        <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow_101_2\"></feBlend>\r\n                                        <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\" result=\"hardAlpha\"></feColorMatrix>\r\n                                        <feMorphology radius=\"10\" operator=\"dilate\" in=\"SourceAlpha\" result=\"effect2_dropShadow_101_2\"></feMorphology>\r\n                                        <feOffset dx=\"-2\" dy=\"-2\"></feOffset>\r\n                                        <feGaussianBlur stdDeviation=\"8\"></feGaussianBlur>\r\n                                        <feComposite in2=\"hardAlpha\" operator=\"out\"></feComposite>\r\n                                        <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.03 0\"></feColorMatrix>\r\n                                        <feBlend mode=\"normal\" in2=\"effect1_dropShadow_101_2\" result=\"effect2_dropShadow_101_2\"></feBlend>\r\n                                        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect2_dropShadow_101_2\" result=\"shape\"></feBlend></filter>\r\n                                    <clipPath id=\"clip0_101_2\"><rect width=\"284\" height=\"234\" fill=\"white\"></rect></clipPath></defs>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(87, "\r\n                            ");
                    __builder2.OpenElement(88, "p");
                    __builder2.AddAttribute$5(89, "class", "op-7 mgt--5");
                    __builder2.AddAttribute$5(90, "style", "margin-left:100px");
                    switch(this.which)
                    {
                        case 0:
                        __builder2.AddContent$4(91, "Air Quality");
                        break;
                        case 1:
                        __builder2.AddContent$4(92, "Temperature");
                        break;
                        case 2:
                        __builder2.AddContent$4(93, "Humidity");
                        break;
                    }
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(94, "\r\n            ");
                    __builder2.OpenElement(95, "div");
                    __builder2.AddAttribute$5(96, "class", "mgt-8 mgb-10");
                    __builder2.OpenElement(97, "div");
                    __builder2.AddAttribute$5(98, "class", "flex");
                    __builder2.OpenElement(99, "div");
                    __builder2.AddAttribute$5(100, "class", "mg-a");
                    __builder2.OpenElement(101, "div");
                    __builder2.AddAttribute$5(102, "class", "flex");
                    __builder2.OpenElement(103, "div");
                    __builder2.OpenElement(104, "div");
                    __builder2.OpenElement(105, "svg");
                    __builder2.AddAttribute$5(106, "width", "109");
                    __builder2.AddAttribute$5(107, "height", "90");
                    __builder2.AddAttribute$5(108, "viewBox", "0 0 109 90");
                    __builder2.AddAttribute$5(109, "fill", "none");
                    __builder2.AddAttribute$5(110, "xmlns", "http://www.w3.org/2000/svg");
                    __builder2.AddMarkupContent(111, "<g filter=\"url(#filter0_f_104_85)\"><path d=\"M30.6419 75.8517C29.6356 76.9811 27.8965 77.0873 26.8413 76.0035C23.9514 73.035 21.5539 69.6162 19.7457 65.8754C17.5397 61.3114 16.2542 56.3576 15.9626 51.2968C15.6711 46.236 16.3792 41.1674 18.0465 36.3802C19.4131 32.4566 21.4021 28.785 23.9321 25.5043C24.8558 24.3065 26.5956 24.2123 27.7249 25.2186V25.2186C28.8542 26.2249 28.9438 27.9499 28.0342 29.1584C25.9751 31.8944 24.3493 34.9377 23.2194 38.1819C21.7887 42.2897 21.181 46.6391 21.4312 50.9818C21.6814 55.3244 22.7845 59.5753 24.6775 63.4916C26.1725 66.5846 28.137 69.421 30.4967 71.9024C31.5391 72.9986 31.6482 74.7224 30.6419 75.8517V75.8517Z\" fill=\"#FF6D6D\" fill-opacity=\"0.25\"></path></g>\r\n                                        <path d=\"M30.6419 75.8517C29.6356 76.9811 27.8964 77.0873 26.8413 76.0035C22.0413 71.0732 18.6342 64.9357 16.9968 58.2183C15.1427 50.6116 15.6454 42.621 18.4383 35.3067C21.2313 27.9924 26.1823 21.7004 32.6345 17.2654C39.0867 12.8305 46.7349 10.4625 54.5643 10.4755C62.3936 10.4885 70.0339 12.8821 76.4713 17.3384C82.9087 21.7948 87.8387 28.1033 90.6073 35.4269C93.3758 42.7504 93.852 50.7427 91.9725 58.3431C90.3127 65.055 86.8852 71.1811 82.0689 76.0954C81.0101 77.1757 79.2713 77.0637 78.2688 75.9311V75.9311C77.2662 74.7984 77.3812 73.0749 78.4272 71.9822C82.418 67.8134 85.262 62.6613 86.655 57.0282C88.2678 50.5063 87.8592 43.6481 85.4835 37.3638C83.1079 31.0795 78.8774 25.6662 73.3535 21.8422C67.8296 18.0182 61.2735 15.9643 54.5551 15.9531C47.8368 15.942 41.2739 17.974 35.7373 21.7796C30.2007 25.5851 25.9522 30.9844 23.5556 37.2607C21.159 43.5371 20.7276 50.3938 22.3187 56.9211C23.6929 62.5587 26.5197 67.7204 30.4966 71.9024C31.539 72.9985 31.6482 74.7224 30.6419 75.8517V75.8517Z\" fill=\"#FF6D6D\" fill-opacity=\"0.25\"></path>\r\n                                        ");
                    __builder2.AddMarkupContent(112, "<g filter=\"url(#filter1_dd_104_85)\"><circle cx=\"54.3451\" cy=\"48.9219\" r=\"26.7121\" fill=\"#F8F8F8\"></circle></g>\r\n                                        ");
                    __builder2.AddMarkupContent(113, "<mask id=\"path-4-inside-1_104_85\" fill=\"white\"><ellipse cx=\"76.452\" cy=\"20.5979\" rx=\"1.38166\" ry=\"1.61194\"></ellipse></mask>\r\n                                        <path d=\"M74.8336 20.5979C74.8336 20.3549 74.9173 20.0583 75.1512 19.7854C75.3905 19.5061 75.8411 19.2099 76.452 19.2099V25.2099C79.2891 25.2099 80.8336 22.6945 80.8336 20.5979H74.8336ZM76.452 19.2099C77.0629 19.2099 77.5134 19.5061 77.7528 19.7854C77.9867 20.0583 78.0703 20.3549 78.0703 20.5979H72.0703C72.0703 22.6945 73.6148 25.2099 76.452 25.2099V19.2099ZM78.0703 20.5979C78.0703 20.8409 77.9867 21.1376 77.7528 21.4105C77.5134 21.6897 77.0629 21.986 76.452 21.986V15.986C73.6148 15.986 72.0703 18.5013 72.0703 20.5979H78.0703ZM76.452 21.986C75.8411 21.986 75.3905 21.6897 75.1512 21.4105C74.9173 21.1376 74.8336 20.8409 74.8336 20.5979H80.8336C80.8336 18.5013 79.2891 15.986 76.452 15.986V21.986Z\" fill=\"white\" mask=\"url(#path-4-inside-1_104_85)\"></path>\r\n                                        ");
                    __builder2.AddMarkupContent(114, "<mask id=\"path-6-inside-2_104_85\" fill=\"white\"><path d=\"M73.0674 25.6899L72.5595 28.864L70.0647 26.8371L73.0674 25.6899Z\"></path></mask>\r\n                                        <path d=\"M73.0674 25.6899L76.0297 26.1639L76.8506 21.033L71.9967 22.8875L73.0674 25.6899ZM72.5595 28.864L70.6679 31.1924L74.7009 34.4688L75.5218 29.3379L72.5595 28.864ZM70.0647 26.8371L68.994 24.0347L64.14 25.8892L68.173 29.1656L70.0647 26.8371ZM70.105 25.216L69.5972 28.39L75.5218 29.3379L76.0297 26.1639L70.105 25.216ZM74.4512 26.5355L71.9563 24.5087L68.173 29.1656L70.6679 31.1924L74.4512 26.5355ZM71.1354 29.6396L74.1381 28.4924L71.9967 22.8875L68.994 24.0347L71.1354 29.6396Z\" fill=\"white\" mask=\"url(#path-6-inside-2_104_85)\"></path>\r\n                                        ");
                    __builder2.OpenElement(115, "text");
                    __builder2.AddAttribute$5(116, "x", "54");
                    __builder2.AddAttribute$5(117, "y", "57");
                    __builder2.AddAttribute$5(118, "fill", "black");
                    __builder2.AddAttribute$5(119, "class", "fsz-20");
                    __builder2.AddAttribute$5(120, "text-anchor", "middle");
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel?*/ let __ca13__;
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel?*/ let __ca14__;
                    __builder2.AddContent$4(121, ((__ca13__ = this.ViewModel.Device$1.Received) !== null ? ((__ca14__ = __ca13__.Status) !== null ? $.$$.S.Double.ToString$3.call(__ca14__.AirQuality, "0.0") : null) : null));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(122, "\r\n                                        ");
                    __builder2.AddMarkupContent(123, "<defs><filter id=\"filter0_f_104_85\" x=\"-16.1013\" y=\"-7.47124\" width=\"79.4419\" height=\"116.232\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\"><feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"></feFlood>\r\n                                                <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"BackgroundImageFix\" result=\"shape\"></feBlend>\r\n                                                <feGaussianBlur stdDeviation=\"16\" result=\"effect1_foregroundBlur_104_85\"></feGaussianBlur></filter>\r\n                                            <filter id=\"filter1_dd_104_85\" x=\"-0.366943\" y=\"-5.79015\" width=\"109.424\" height=\"109.424\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\"><feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"></feFlood>\r\n                                                <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\" result=\"hardAlpha\"></feColorMatrix>\r\n                                                <feMorphology radius=\"10\" operator=\"dilate\" in=\"SourceAlpha\" result=\"effect1_dropShadow_104_85\"></feMorphology>\r\n                                                <feOffset dx=\"2\" dy=\"2\"></feOffset>\r\n                                                <feGaussianBlur stdDeviation=\"8\"></feGaussianBlur>\r\n                                                <feComposite in2=\"hardAlpha\" operator=\"out\"></feComposite>\r\n                                                <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.03 0\"></feColorMatrix>\r\n                                                <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow_104_85\"></feBlend>\r\n                                                <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\" result=\"hardAlpha\"></feColorMatrix>\r\n                                                <feMorphology radius=\"10\" operator=\"dilate\" in=\"SourceAlpha\" result=\"effect2_dropShadow_104_85\"></feMorphology>\r\n                                                <feOffset dx=\"-2\" dy=\"-2\"></feOffset>\r\n                                                <feGaussianBlur stdDeviation=\"8\"></feGaussianBlur>\r\n                                                <feComposite in2=\"hardAlpha\" operator=\"out\"></feComposite>\r\n                                                <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.03 0\"></feColorMatrix>\r\n                                                <feBlend mode=\"normal\" in2=\"effect1_dropShadow_104_85\" result=\"effect2_dropShadow_104_85\"></feBlend>\r\n                                                <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect2_dropShadow_104_85\" result=\"shape\"></feBlend></filter></defs>");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(124, "\r\n                                ");
                    __builder2.AddMarkupContent(125, "<p class=\"fsz--9 op-7 mgt-0 text-center\">Air Quality</p>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(126, "\r\n                            ");
                    __builder2.OpenElement(127, "div");
                    __builder2.OpenElement(128, "div");
                    __builder2.OpenElement(129, "svg");
                    __builder2.AddAttribute$5(130, "width", "109");
                    __builder2.AddAttribute$5(131, "height", "90");
                    __builder2.AddAttribute$5(132, "viewBox", "0 0 109 90");
                    __builder2.AddAttribute$5(133, "fill", "none");
                    __builder2.AddAttribute$5(134, "xmlns", "http://www.w3.org/2000/svg");
                    __builder2.AddMarkupContent(135, "<path d=\"M34.5865 80.5599C33.7466 81.8179 32.0389 82.1643 30.8437 81.2373C25.1631 76.832 20.8102 70.9147 18.3012 64.1395C15.4743 56.5059 15.1329 48.1741 17.326 40.3348C19.519 32.4956 24.1341 25.5503 30.5117 20.4917C36.8892 15.433 44.7027 12.52 52.8353 12.169C60.968 11.8179 69.0034 14.0468 75.7931 18.5371C82.5828 23.0274 87.7793 29.5492 90.6396 37.1703C93.5 44.7914 93.8779 53.1217 91.7193 60.9705C89.8034 67.9366 85.9765 74.207 80.6967 79.0854C79.5858 80.112 77.8546 79.914 76.9094 78.733V78.733C75.9642 77.5521 76.1644 75.8364 77.2632 74.7969C81.6471 70.6498 84.8283 65.37 86.4377 59.5179C88.29 52.7829 87.9658 45.6347 85.5113 39.0951C83.0568 32.5554 78.5978 26.9591 72.7716 23.106C66.9453 19.2529 60.0501 17.3403 53.0715 17.6415C46.093 17.9427 39.3882 20.4424 33.9157 24.7832C28.4431 29.124 24.4829 35.0837 22.6011 41.8106C20.7193 48.5374 21.0122 55.6869 23.4379 62.2373C25.5456 67.9289 29.1699 72.9149 33.8949 76.6689C35.0792 77.6098 35.4264 79.3019 34.5865 80.5599V80.5599Z\" fill=\"#7B88FF\" fill-opacity=\"0.25\"></path>\r\n                                        ");
                    __builder2.AddMarkupContent(136, "<g filter=\"url(#filter0_dd_104_65)\"><circle cx=\"54.3451\" cy=\"50.5795\" r=\"26.7121\" fill=\"#F8F8F8\"></circle></g>\r\n                                        ");
                    __builder2.AddMarkupContent(137, "<mask id=\"path-3-inside-1_104_65\" fill=\"white\"><ellipse cx=\"76.452\" cy=\"22.2555\" rx=\"1.38166\" ry=\"1.61194\"></ellipse></mask>\r\n                                        <path d=\"M74.8336 22.2555C74.8336 22.0125 74.9173 21.7159 75.1512 21.443C75.3905 21.1637 75.8411 20.8675 76.452 20.8675V26.8675C79.2891 26.8675 80.8336 24.3521 80.8336 22.2555H74.8336ZM76.452 20.8675C77.0629 20.8675 77.5134 21.1637 77.7528 21.443C77.9867 21.7159 78.0703 22.0125 78.0703 22.2555H72.0703C72.0703 24.3521 73.6148 26.8675 76.452 26.8675V20.8675ZM78.0703 22.2555C78.0703 22.4985 77.9867 22.7952 77.7528 23.0681C77.5134 23.3473 77.0629 23.6436 76.452 23.6436V17.6436C73.6148 17.6436 72.0703 20.1589 72.0703 22.2555H78.0703ZM76.452 23.6436C75.8411 23.6436 75.3905 23.3473 75.1512 23.0681C74.9173 22.7952 74.8336 22.4985 74.8336 22.2555H80.8336C80.8336 20.1589 79.2891 17.6436 76.452 17.6436V23.6436Z\" fill=\"white\" mask=\"url(#path-3-inside-1_104_65)\"></path>\r\n                                        ");
                    __builder2.AddMarkupContent(138, "<mask id=\"path-5-inside-2_104_65\" fill=\"white\"><path d=\"M73.0674 27.3476L72.5595 30.5216L70.0647 28.4948L73.0674 27.3476Z\"></path></mask>\r\n                                        ");
                    __builder2.OpenElement(139, "text");
                    __builder2.AddAttribute$5(140, "x", "54");
                    __builder2.AddAttribute$5(141, "y", "57");
                    __builder2.AddAttribute$5(142, "fill", "black");
                    __builder2.AddAttribute$5(143, "class", "fsz-20");
                    __builder2.AddAttribute$5(144, "text-anchor", "middle");
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel?*/ let __ca15__;
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel?*/ let __ca16__;
                    __builder2.AddContent$4(145, ((__ca15__ = this.ViewModel.Device$1.Received) !== null ? ((__ca16__ = __ca15__.Status) !== null ? $.$$.S.Double.ToString$3.call(__ca16__.Temperature, "0") : null) : null));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(146, "\r\n                                        ");
                    __builder2.AddMarkupContent(147, "<defs><filter id=\"filter0_dd_104_65\" x=\"-0.366943\" y=\"-4.13254\" width=\"109.424\" height=\"109.424\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\"><feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"></feFlood>\r\n                                                <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\" result=\"hardAlpha\"></feColorMatrix>\r\n                                                <feMorphology radius=\"10\" operator=\"dilate\" in=\"SourceAlpha\" result=\"effect1_dropShadow_104_65\"></feMorphology>\r\n                                                <feOffset dx=\"2\" dy=\"2\"></feOffset>\r\n                                                <feGaussianBlur stdDeviation=\"8\"></feGaussianBlur>\r\n                                                <feComposite in2=\"hardAlpha\" operator=\"out\"></feComposite>\r\n                                                <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.03 0\"></feColorMatrix>\r\n                                                <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow_104_65\"></feBlend>\r\n                                                <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\" result=\"hardAlpha\"></feColorMatrix>\r\n                                                <feMorphology radius=\"10\" operator=\"dilate\" in=\"SourceAlpha\" result=\"effect2_dropShadow_104_65\"></feMorphology>\r\n                                                <feOffset dx=\"-2\" dy=\"-2\"></feOffset>\r\n                                                <feGaussianBlur stdDeviation=\"8\"></feGaussianBlur>\r\n                                                <feComposite in2=\"hardAlpha\" operator=\"out\"></feComposite>\r\n                                                <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.03 0\"></feColorMatrix>\r\n                                                <feBlend mode=\"normal\" in2=\"effect1_dropShadow_104_65\" result=\"effect2_dropShadow_104_65\"></feBlend>\r\n                                                <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect2_dropShadow_104_65\" result=\"shape\"></feBlend></filter></defs>");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(148, "\r\n                                ");
                    __builder2.AddMarkupContent(149, "<p class=\"fsz--9 op-7 mgt-0 text-center\">Temperature</p>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(150, "\r\n                            ");
                    __builder2.OpenElement(151, "div");
                    __builder2.OpenElement(152, "div");
                    __builder2.OpenElement(153, "svg");
                    __builder2.AddAttribute$5(154, "width", "109");
                    __builder2.AddAttribute$5(155, "height", "90");
                    __builder2.AddAttribute$5(156, "viewBox", "0 0 109 90");
                    __builder2.AddAttribute$5(157, "fill", "none");
                    __builder2.AddAttribute$5(158, "xmlns", "http://www.w3.org/2000/svg");
                    __builder2.AddMarkupContent(159, "<g filter=\"url(#filter0_f_104_64)\"><path d=\"M84.7427 28.2259C86.0183 27.413 87.7208 27.7839 88.4413 29.1139C92.5425 36.6845 94.0074 45.437 92.554 53.9766C91.1006 62.5163 86.8228 70.2914 80.4481 76.079C79.3281 77.0957 77.5988 76.8826 76.664 75.6935C75.7291 74.5043 75.9443 72.7904 77.0522 71.7605C82.3642 66.8229 85.9287 60.2568 87.154 53.0576C88.3793 45.8583 87.1875 38.4828 83.8081 32.0659C83.1032 30.7275 83.4671 29.0389 84.7427 28.2259Z\" fill=\"#77FF95\"></path></g>\r\n                                        <path d=\"M33.494 76.5665C32.608 77.7925 30.8887 78.0753 29.7286 77.1047C24.1639 72.4486 20.0089 66.3044 17.7674 59.3649C15.2445 51.5542 15.277 43.1427 17.8602 35.3518C20.4433 27.5609 25.4426 20.7962 32.1321 16.04C38.8217 11.2838 46.8531 8.78373 55.0602 8.90286C63.2674 9.02199 71.2229 11.7541 77.7715 16.7024C84.3202 21.6508 89.121 28.5578 91.477 36.4204C93.8329 44.283 93.6212 52.6919 90.8727 60.426C88.4307 67.2976 84.0991 73.3186 78.4017 77.8112C77.2139 78.7478 75.5035 78.4152 74.6534 77.164C73.8034 75.9128 74.137 74.218 75.3137 73.2675C80.0529 69.4395 83.6594 64.3655 85.7113 58.5918C88.0698 51.9552 88.2514 44.7395 86.2298 37.9926C84.2082 31.2457 80.0886 25.3189 74.4692 21.0727C68.8498 16.8266 62.0232 14.4821 54.9807 14.3799C47.9382 14.2777 41.0465 16.423 35.3062 20.5043C29.566 24.5855 25.2761 30.3903 23.0595 37.0757C20.8429 43.761 20.815 50.9789 22.9799 57.6812C24.8633 63.5121 28.321 68.6886 32.9472 72.6526C34.0958 73.6368 34.38 75.3406 33.494 76.5665Z\" fill=\"#77FF95\" fill-opacity=\"0.25\"></path>\r\n                                        ");
                    __builder2.AddMarkupContent(160, "<g filter=\"url(#filter1_dd_104_64)\"><circle cx=\"54.3451\" cy=\"47.3453\" r=\"26.7121\" fill=\"#F8F8F8\"></circle></g>\r\n                                        ");
                    __builder2.AddMarkupContent(161, "<mask id=\"path-4-inside-1_104_64\" fill=\"white\"><ellipse cx=\"76.452\" cy=\"19.0213\" rx=\"1.38166\" ry=\"1.61194\"></ellipse></mask>\r\n                                        <path d=\"M74.8336 19.0213C74.8336 18.7783 74.9173 18.4816 75.1512 18.2087C75.3905 17.9295 75.8411 17.6332 76.452 17.6332V23.6332C79.2891 23.6332 80.8336 21.1178 80.8336 19.0213H74.8336ZM76.452 17.6332C77.0629 17.6332 77.5134 17.9295 77.7528 18.2087C77.9867 18.4816 78.0703 18.7783 78.0703 19.0213H72.0703C72.0703 21.1178 73.6148 23.6332 76.452 23.6332V17.6332ZM78.0703 19.0213C78.0703 19.2643 77.9867 19.5609 77.7528 19.8338C77.5134 20.113 77.0629 20.4093 76.452 20.4093V14.4093C73.6148 14.4093 72.0703 16.9247 72.0703 19.0213H78.0703ZM76.452 20.4093C75.8411 20.4093 75.3905 20.113 75.1512 19.8338C74.9173 19.5609 74.8336 19.2643 74.8336 19.0213H80.8336C80.8336 16.9247 79.2891 14.4093 76.452 14.4093V20.4093Z\" fill=\"white\" mask=\"url(#path-4-inside-1_104_64)\"></path>\r\n                                        ");
                    __builder2.AddMarkupContent(162, "<mask id=\"path-6-inside-2_104_64\" fill=\"white\"><path d=\"M73.0674 24.1133L72.5595 27.2873L70.0647 25.2605L73.0674 24.1133Z\"></path></mask>\r\n                                        ");
                    __builder2.OpenElement(163, "text");
                    __builder2.AddAttribute$5(164, "x", "54");
                    __builder2.AddAttribute$5(165, "y", "57");
                    __builder2.AddAttribute$5(166, "fill", "black");
                    __builder2.AddAttribute$5(167, "class", "fsz-20");
                    __builder2.AddAttribute$5(168, "text-anchor", "middle");
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.SenseAirDeviceReceivedDataModel?*/ let __ca17__;
                    /*LivingThing.Core.IOT.Devices.SenseAir.Models.Statuses.SenseAirStatusModel?*/ let __ca18__;
                    __builder2.AddContent$4(169, ((__ca17__ = this.ViewModel.Device$1.Received) !== null ? ((__ca18__ = __ca17__.Status) !== null ? $.$$.S.Double.ToString$3.call(__ca18__.Humidity, "0") : null) : null));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(170, "\r\n                                        ");
                    __builder2.AddMarkupContent(171, "<defs><filter id=\"filter0_f_104_64\" x=\"44.0754\" y=\"-4.20232\" width=\"81.0259\" height=\"112.931\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\"><feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"></feFlood>\r\n                                                <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"BackgroundImageFix\" result=\"shape\"></feBlend>\r\n                                                <feGaussianBlur stdDeviation=\"16\" result=\"effect1_foregroundBlur_104_64\"></feGaussianBlur></filter>\r\n                                            <filter id=\"filter1_dd_104_64\" x=\"-0.366943\" y=\"-7.36681\" width=\"109.424\" height=\"109.424\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\"><feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"></feFlood>\r\n                                                <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\" result=\"hardAlpha\"></feColorMatrix>\r\n                                                <feMorphology radius=\"10\" operator=\"dilate\" in=\"SourceAlpha\" result=\"effect1_dropShadow_104_64\"></feMorphology>\r\n                                                <feOffset dx=\"2\" dy=\"2\"></feOffset>\r\n                                                <feGaussianBlur stdDeviation=\"8\"></feGaussianBlur>\r\n                                                <feComposite in2=\"hardAlpha\" operator=\"out\"></feComposite>\r\n                                                <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.03 0\"></feColorMatrix>\r\n                                                <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow_104_64\"></feBlend>\r\n                                                <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\" result=\"hardAlpha\"></feColorMatrix>\r\n                                                <feMorphology radius=\"10\" operator=\"dilate\" in=\"SourceAlpha\" result=\"effect2_dropShadow_104_64\"></feMorphology>\r\n                                                <feOffset dx=\"-2\" dy=\"-2\"></feOffset>\r\n                                                <feGaussianBlur stdDeviation=\"8\"></feGaussianBlur>\r\n                                                <feComposite in2=\"hardAlpha\" operator=\"out\"></feComposite>\r\n                                                <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.03 0\"></feColorMatrix>\r\n                                                <feBlend mode=\"normal\" in2=\"effect1_dropShadow_104_64\" result=\"effect2_dropShadow_104_64\"></feBlend>\r\n                                                <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect2_dropShadow_104_64\" result=\"shape\"></feBlend></filter></defs>");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(172, "\r\n                                ");
                    __builder2.AddMarkupContent(173, "<p class=\"fsz--9 op-7 mgt-0 text-center\">Humidity</p>");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                }), $TjLafl ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":4580932,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12889482820)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8594515524)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594515524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594515524)
            
            //--TRIMMABLE-BOUNDARY-START(8594515524)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8594515524)
            
            static $h = 4580932;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$dRGn.LCIDSV.SenseAirDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51544188484),
    {
      "p": 4515396,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069352004,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42954253892,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 4580932,
      "h": 51544188484,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51544188484),
//--TRIMMABLE-BOUNDARY-START(34364319300),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479417412,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 4580932,
      "h": 34364319300,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34364319300)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47249221188),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 4580932,
      "h": 47249221188,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47249221188),
//--TRIMMABLE-BOUNDARY-START(12889482820),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 4580932,
      "h": 12889482820,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12889482820)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55839155780),
    {
      "t": 655361,
      "n": "which",
      "d": 4580932,
      "h": 55839155780,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55839155780)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594515524),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4580932,
      "h": 8594515524,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594515524)
  ],
  "h": 4580932
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SenseAir.Views.SenseAirDeviceDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SenseAir${separator}Views${separator}SenseAirDeviceDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4580932)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(58948)
