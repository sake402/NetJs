
//--TRIMMABLE-BOUNDARY-START(32549)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $HnZw, $mep, $meca, $mxdi, $mexla, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $meo, $mecm, $mecga, $mec, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $fXpo, $zHIt, $uvJL, $KuVO, $lOHy, $kVHt, $UrvY, $vWqU, $JRhp, $DJRY, $tUcV, $nYKj, $AvdQ, $bMcF, $XBGm, $NXre) {
    "use strict";
    let _;
    let $OBwQmg;
    let $lIFHse;
    let $rdhySe;
    let $wHIiCh;
    let $TunfNg;
    let $LbDyVc;
    let $OMtrqh;
    let $lxyCHk;
    let $CJgZDf;
    let $DbpQYd;
    let $QHywZf;
    let $hBIdye;
    let $vywebe;
    let $LVQbAb;
    let $ZHBoqh;
    let $VCNqid;
    let $qeuLYj;
    let $YTOKyk;
    let $uVcxri;
    let $PTQWPj;
    let $FnFxNi;
    let $mwuSog;
    let $xeppDf;
    let $CoPfXk;
    let $bsFDzk;
    let $UCEYRd;
    let $AiUWdb;
    let $dgdCKc;
    let $CezHnf;
    let $wKrByj;
    let $lSojCe;
    let $yVYCog;
    let $RvzCoh;
    let $pZDGcd;
    let $Hemhhb;
    let $lWyVma;
    let $ypenCk;
    let $NemaBa;
    let $VXVMFj;
    let $zwufPc;
    let $ALgkke;
    let $FerxVb;
    let $YSVAAb;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.SerialBridge", 
    {
  "h": 32549,
  "f": "LivingThing.Core.IOT.Devices.SerialBridge",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.SerialBridge",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.SerialBridge",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5TZXJpYWxCcmlkZ2UuU2VyaWFsQnJpZGdlRGV2aWNlIjogew0KICAgICAgIkNhdGVnb3JpZXMiOiBbICJTbWFydCBIb21lIiwgIkRJWSIgXSwNCiAgICAgICJOYW1lIjogIlNlcmlhbCBCcmlkZ2UiLA0KICAgICAgIkRlc2NyaXB0aW9uIjogIkNvbm5lY3RzIGN1c3RvbSBkZXZpY2VzIHRvIGNsb3VkIG92ZXIgc2VyaWFsIHdpcmUuIiwNCiAgICAgICJJY29uIjogeyAiTmFtZSI6ICJtZGkgbWRpLWRldmljZXMiIH0sDQogICAgICAiVGhlbWVDb2xvciI6ICIjMzc5NDZlIiwNCiAgICAgICJGbGFncyI6ICJQdWJsaXNoZWQiLA0KICAgICAgIlNlY3VyaXRpZXMiOiAiQ2hhbGxlbmdlSGFuZFNoYWtlQXV0aGVudGljYXRpb25Qcm90b2NvbCxBZHZhbmNlZEVuY3J5cHRpb25TdGFuZGFyZCxFbGxpcHRpY0N1cnZlRmlybXdhcmVVcGRhdGVTaWduaW5nIg0KICAgIH0NCiAgfQ0KfQ=="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(163621)
        $asm.$cls(`$tKtD.LCIDSC.SerialBridgeTargetCommandModelCustomAttributesProvider`, ($self) => class SerialBridgeTargetCommandModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295130917)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295130917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295130917)
            
            static $h = 163621;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295130917),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 163621,
      "h": 4295130917,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295130917)
  ],
  "h": 163621
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Commands.SerialBridgeTargetCommandModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Commands${separator}SerialBridgeTargetCommandModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(163621)
        
        

        //--TRIMMABLE-BOUNDARY-START(1670949)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelCustomAttributesProvider`, ($self) => class SerialBridgeDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296638245)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296638245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceSendDataModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296638245)
            
            static $h = 1670949;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296638245),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1670949,
      "h": 4296638245,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296638245)
  ],
  "h": 1670949
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1670949)
        
        

        //--TRIMMABLE-BOUNDARY-START(3309349)
        $asm.$cls(`$tKtD.LCIDSS$1.SerialBridgeDeviceSettingsCustomAttributesProvider`, ($self) => class SerialBridgeDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298276645)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298276645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298276645)
            
            static $h = 3309349;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298276645),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3309349,
      "h": 4298276645,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298276645)
  ],
  "h": 3309349
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Settings${separator}SerialBridgeDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3309349)
        
        

        //--TRIMMABLE-BOUNDARY-START(950053)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelCustomAttributesProvider<>`, (TStatus) => $asm.$gt(`$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelCustomAttributesProvider<>`, [TStatus], ($self) => class SerialBridgeDeviceReceivedDataModelCustomAttributesProvider$$
        {
            //--TRIMMABLE-BOUNDARY-START(4295917349)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295917349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$(TStatus).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295917349)
            
            static $H = 950053;
            static $h = 950053;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295917349),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": this.$h,
      "H": 4295917349,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295917349)
  ],
  "s": [
    {
      "h": TStatus?.$h??1572864,
      "n": "TStatus",
      "c": [23434641
      ]
    }
  ],
  "r": 1,
  "H": 950053,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModelCustomAttributesProvider<${TStatus?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceReceivedDataModelCustomAttributesProvider$${TStatus?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(950053)
        
        

        //--TRIMMABLE-BOUNDARY-START(1408805)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceScopeModelCustomAttributesProvider`, ($self) => class SerialBridgeDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296376101)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296376101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296376101)
            
            static $h = 1408805;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296376101),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1408805,
      "h": 4296376101,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296376101)
  ],
  "h": 1408805
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1408805)
        
        

        //--TRIMMABLE-BOUNDARY-START(3047205)
        $asm.$cls(`$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class SerialBridgeDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298014501)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298014501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298014501)
            
            static $h = 3047205;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298014501),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3047205,
      "h": 4298014501,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298014501)
  ],
  "h": 3047205
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Settings${separator}SerialBridgeDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3047205)
        
        

        //--TRIMMABLE-BOUNDARY-START(1015589)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelCustomAttributesProviderRegistrar1`, ($self) => class SerialBridgeDeviceReceivedDataModelCustomAttributesProviderRegistrar1
        {
            //--TRIMMABLE-BOUNDARY-START(4295982885)
            static /*void */ AddGeneratedFastAttributesOfSerialBridgeDeviceReceivedDataModel(TStatus, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295982885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$(TStatus).$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelCustomAttributesProvider$$(TStatus), $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelCustomAttributesProvider$$(TStatus).GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295982885)
            
            static $h = 1015589;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295982885),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TStatus"
      ],
      "n": "AddGeneratedFastAttributesOfSerialBridgeDeviceReceivedDataModel",
      "d": 1015589,
      "h": 4295982885,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(4295982885)
  ],
  "h": 1015589
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModelCustomAttributesProviderRegistrar1`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceReceivedDataModelCustomAttributesProviderRegistrar1`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1015589)
        
        

        //--TRIMMABLE-BOUNDARY-START(1933093)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeServiceModelCustomAttributesProvider`, ($self) => class SerialBridgeServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296900389)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296900389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296900389)
            
            static $h = 1933093;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296900389),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1933093,
      "h": 4296900389,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296900389)
  ],
  "h": 1933093
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1933093)
        
        

        //--TRIMMABLE-BOUNDARY-START(884517)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class SerialBridgeDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295851813)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295851813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$tKtD.LCIDSM.SerialBridgeStatusModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295851813)
            
            static $h = 884517;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295851813),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 884517,
      "h": 4295851813,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295851813)
  ],
  "h": 884517
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(884517)
        
        

        //--TRIMMABLE-BOUNDARY-START(556837)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceModelCustomAttributesProvider`, ($self) => class SerialBridgeDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295524133)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295524133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295524133)
            
            static $h = 556837;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295524133),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 556837,
      "h": 4295524133,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295524133)
  ],
  "h": 556837
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(556837)
        
        

        //--TRIMMABLE-BOUNDARY-START(2195237)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeStatusModelCustomAttributesProvider`, ($self) => class SerialBridgeStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297162533)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297162533)
            
            //--TRIMMABLE-BOUNDARY-START(8592129829)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592129829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$tKtD.LCIDSM.SerialBridgeStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Data", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$tKtD.LCIDSM.SerialBridgeStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $wHIiCh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2195237,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $TunfNg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2195237,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592129829)
            
            static $h = 2195237;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592129829),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2195237,
      "h": 8592129829,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592129829)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297162533),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2195237,
      "h": 4297162533,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297162533)
  ],
  "h": 2195237
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2195237)
        
        

        //--TRIMMABLE-BOUNDARY-START(1212197)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class SerialBridgeDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591146789)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591146789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $LbDyVc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1212197,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591146789)
            
            //--TRIMMABLE-BOUNDARY-START(4296179493)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296179493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296179493)
            
            //--TRIMMABLE-BOUNDARY-START(4296179493)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296179493)
            
            static $h = 1212197;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591146789),
    {
      "r": 65537,
      "n": "Register",
      "d": 1212197,
      "h": 8591146789,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591146789)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296179493),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1212197,
      "h": 4296179493,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296179493)
  ],
  "h": 1212197
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1212197)
        
        

        //--TRIMMABLE-BOUNDARY-START(1539877)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceScopeModelTypeDescriptorBuilder`, ($self) => class SerialBridgeDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591474469)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591474469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $CJgZDf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1539877,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591474469)
            
            //--TRIMMABLE-BOUNDARY-START(4296507173)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296507173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296507173)
            
            //--TRIMMABLE-BOUNDARY-START(4296507173)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296507173)
            
            static $h = 1539877;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591474469),
    {
      "r": 65537,
      "n": "Register",
      "d": 1539877,
      "h": 8591474469,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591474469)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296507173),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1539877,
      "h": 4296507173,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296507173)
  ],
  "h": 1539877
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1539877)
        
        

        //--TRIMMABLE-BOUNDARY-START(294693)
        $asm.$cls(`$tKtD.LCIDSC.SerialBridgeTargetCommandModelTypeDescriptorBuilder`, ($self) => class SerialBridgeTargetCommandModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590229285)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590229285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$tKtD.LCIDSC.SerialBridgeTargetCommandModelTypeDescriptor()
                        const $t1 = $.$tKtD.LCIDSC.SerialBridgeTargetCommandModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridge.Commands.SerialBridgeTargetCommandModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ZHBoqh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":294693,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$tKtD.LCIDSC.SerialBridgeTargetCommandModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590229285)
            
            //--TRIMMABLE-BOUNDARY-START(4295261989)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295261989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295261989)
            
            //--TRIMMABLE-BOUNDARY-START(4295261989)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295261989)
            
            static $h = 294693;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590229285),
    {
      "r": 65537,
      "n": "Register",
      "d": 294693,
      "h": 8590229285,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590229285)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295261989),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 294693,
      "h": 4295261989,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295261989)
  ],
  "h": 294693
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Commands.SerialBridgeTargetCommandModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Commands${separator}SerialBridgeTargetCommandModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(294693)
        
        

        //--TRIMMABLE-BOUNDARY-START(425765)
        $asm.$cls(`$tKtD.LCIDS.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295393061)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295393061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tKtD.LCIDSC.SerialBridgeTargetCommandModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tKtD.LCIDSC.SerialBridgeTargetCommandModelCustomAttributesProvider, $.$tKtD.LCIDSC.SerialBridgeTargetCommandModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tKtD.LCIDSM.SerialBridgeDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tKtD.LCIDSM.SerialBridgeDeviceModelCustomAttributesProvider, $.$tKtD.LCIDSM.SerialBridgeDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tKtD.LCIDSM.SerialBridgeStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tKtD.LCIDSM.SerialBridgeStatusModelCustomAttributesProvider, $.$tKtD.LCIDSM.SerialBridgeStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelCustomAttributesProvider, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tKtD.LCIDSM.SerialBridgeDeviceScopeModelCustomAttributesProvider, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelCustomAttributesProvider, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tKtD.LCIDSM.SerialBridgeServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tKtD.LCIDSM.SerialBridgeServiceModelCustomAttributesProvider, $.$tKtD.LCIDSM.SerialBridgeServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsCustomAttributesProvider, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tKtD.LCIDSS$1.SerialBridgeDeviceSettingsCustomAttributesProvider, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295393061)
            
            static $h = 425765;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295393061),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 425765,
      "h": 4295393061,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295393061)
  ],
  "h": 425765
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(425765)
        
        

        //--TRIMMABLE-BOUNDARY-START(3440421)
        $asm.$cls(`$tKtD.LCIDSS$1.SerialBridgeDeviceSettingsTypeDescriptorBuilder`, ($self) => class SerialBridgeDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593375013)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593375013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettingsTypeDescriptor()
                        const $t1 = $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $vywebe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3440421,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593375013)
            
            //--TRIMMABLE-BOUNDARY-START(4298407717)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298407717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298407717)
            
            //--TRIMMABLE-BOUNDARY-START(4298407717)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298407717)
            
            static $h = 3440421;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593375013),
    {
      "r": 65537,
      "n": "Register",
      "d": 3440421,
      "h": 8593375013,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593375013)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298407717),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3440421,
      "h": 4298407717,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298407717)
  ],
  "h": 3440421
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Settings${separator}SerialBridgeDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3440421)
        
        

        //--TRIMMABLE-BOUNDARY-START(3178277)
        $asm.$cls(`$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class SerialBridgeDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593112869)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593112869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $dgdCKc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3178277,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593112869)
            
            //--TRIMMABLE-BOUNDARY-START(4298145573)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298145573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298145573)
            
            //--TRIMMABLE-BOUNDARY-START(4298145573)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298145573)
            
            static $h = 3178277;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593112869),
    {
      "r": 65537,
      "n": "Register",
      "d": 3178277,
      "h": 8593112869,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593112869)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298145573),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3178277,
      "h": 4298145573,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298145573)
  ],
  "h": 3178277
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Settings${separator}SerialBridgeDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3178277)
        
        

        //--TRIMMABLE-BOUNDARY-START(1277733)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptorBuilder<>`, (TStatus) => $asm.$gt(`$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptorBuilder<>`, [TStatus], ($self) => class SerialBridgeDeviceReceivedDataModelTypeDescriptorBuilder$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591212325)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591212325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptor$$(TStatus)()
                        const $t1 = $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptor$$(TStatus);
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModel<TStatus>");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $QHywZf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$(TStatus).$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591212325)
            
            //--TRIMMABLE-BOUNDARY-START(4296245029)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296245029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296245029)
            
            //--TRIMMABLE-BOUNDARY-START(4296245029)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296245029)
            
            static $H = 1277733;
            static $h = 1277733;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591212325),
    {
      "r": 65537,
      "n": "Register",
      "d": this.$h,
      "H": 8591212325,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591212325)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296245029),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4296245029,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296245029)
  ],
  "s": [
    {
      "h": TStatus?.$h??1572864,
      "n": "TStatus",
      "c": [23434641
      ]
    }
  ],
  "r": 1,
  "H": 1277733,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModelTypeDescriptorBuilder<${TStatus?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceReceivedDataModelTypeDescriptorBuilder$${TStatus?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1277733)
        
        

        //--TRIMMABLE-BOUNDARY-START(2326309)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeStatusModelTypeDescriptorBuilder`, ($self) => class SerialBridgeStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592260901)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592260901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$tKtD.LCIDSM.SerialBridgeStatusModelTypeDescriptor()
                        const $t1 = $.$tKtD.LCIDSM.SerialBridgeStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $mwuSog ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2326309,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$tKtD.LCIDSM.SerialBridgeStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592260901)
            
            //--TRIMMABLE-BOUNDARY-START(4297293605)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297293605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297293605)
            
            //--TRIMMABLE-BOUNDARY-START(4297293605)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297293605)
            
            static $h = 2326309;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592260901),
    {
      "r": 65537,
      "n": "Register",
      "d": 2326309,
      "h": 8592260901,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592260901)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297293605),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2326309,
      "h": 4297293605,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297293605)
  ],
  "h": 2326309
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2326309)
        
        

        //--TRIMMABLE-BOUNDARY-START(3505957)
        $asm.$cls(`$tKtD.LCIDS.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298473253)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298473253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$tKtD.LCIDSC.SerialBridgeTargetCommandModelTypeDescriptorBuilder.Register();
                $.$tKtD.LCIDSM.SerialBridgeDeviceModelTypeDescriptorBuilder.Register();
                $.$tKtD.LCIDSM.SerialBridgeStatusModelTypeDescriptorBuilder.Register();
                $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$fPer.LCFCD$1.SystemTypeDescriptor.RegisterLazyTypeDescriptorRegistrar($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$().$type, new ($.$$.S.Action$$($.$typeArray($.$$.S.Type)))().$ctor(this,  (/*types*/ types) =>
                {
                    return $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptorBuilder$$().$type.MakeGenericType(types).GetMethod$9("Register", 8/*System.Reflection.BindingFlags.Static*/ | 16/*System.Reflection.BindingFlags.Public*/).Invoke(null, null);
                }, $lxyCHk ??= {"r":65537,"p":[{"n":"types","p":$.$typeArray($.$$.S.Type).$h}],"n":"","d":3505957,"h":0,"f":17825794}));
                $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$tKtD.LCIDSM.SerialBridgeServiceModelTypeDescriptorBuilder.Register();
                $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298473253)
            
            static $h = 3505957;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298473253),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3505957,
      "h": 4298473253,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298473253)
  ],
  "h": 3505957
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3505957)
        
        

        //--TRIMMABLE-BOUNDARY-START(1802021)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class SerialBridgeDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591736613)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591736613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $YTOKyk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1802021,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591736613)
            
            //--TRIMMABLE-BOUNDARY-START(4296769317)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296769317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296769317)
            
            //--TRIMMABLE-BOUNDARY-START(4296769317)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296769317)
            
            static $h = 1802021;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591736613),
    {
      "r": 65537,
      "n": "Register",
      "d": 1802021,
      "h": 8591736613,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591736613)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296769317),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1802021,
      "h": 4296769317,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296769317)
  ],
  "h": 1802021
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1802021)
        
        

        //--TRIMMABLE-BOUNDARY-START(687909)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceModelTypeDescriptorBuilder`, ($self) => class SerialBridgeDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590622501)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590622501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$tKtD.LCIDSM.SerialBridgeDeviceModelTypeDescriptor()
                        const $t1 = $.$tKtD.LCIDSM.SerialBridgeDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $PTQWPj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":687909,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$tKtD.LCIDSM.SerialBridgeDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590622501)
            
            //--TRIMMABLE-BOUNDARY-START(4295655205)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295655205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295655205)
            
            //--TRIMMABLE-BOUNDARY-START(4295655205)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295655205)
            
            static $h = 687909;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590622501),
    {
      "r": 65537,
      "n": "Register",
      "d": 687909,
      "h": 8590622501,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590622501)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295655205),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 687909,
      "h": 4295655205,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295655205)
  ],
  "h": 687909
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(687909)
        
        

        //--TRIMMABLE-BOUNDARY-START(2064165)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeServiceModelTypeDescriptorBuilder`, ($self) => class SerialBridgeServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591998757)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591998757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$tKtD.LCIDSM.SerialBridgeServiceModelTypeDescriptor()
                        const $t1 = $.$tKtD.LCIDSM.SerialBridgeServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $UCEYRd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2064165,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$tKtD.LCIDSM.SerialBridgeServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591998757)
            
            //--TRIMMABLE-BOUNDARY-START(4297031461)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297031461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297031461)
            
            //--TRIMMABLE-BOUNDARY-START(4297031461)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297031461)
            
            static $h = 2064165;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591998757),
    {
      "r": 65537,
      "n": "Register",
      "d": 2064165,
      "h": 8591998757,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591998757)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297031461),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2064165,
      "h": 4297031461,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297031461)
  ],
  "h": 2064165
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2064165)
        
        

        //--TRIMMABLE-BOUNDARY-START(360229)
        $asm.$cls(`$tKtD.LCIDS.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180229413)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180229413)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295327525)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295327525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295327525)
            
            //--TRIMMABLE-BOUNDARY-START(4295327525)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295327525)
            
            static $h = 360229;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180229413),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885262117,
        "f": 50331649
      },
      "n": "Paths",
      "d": 360229,
      "h": 17180229413,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180229413)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295327525),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 360229,
      "h": 4295327525,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295327525)
  ],
  "h": 360229
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(360229)
        
        

        //--TRIMMABLE-BOUNDARY-START(2719525)
        $asm.$cls(`$tKtD.LCIDS.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592654117)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592654117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$tKtD.LCIDS.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$tKtD.LCIDS.SerialBridgeDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$tKtD.LCIDS.SerialBridgeDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$tKtD.LCIDS.SerialBridgeDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$tKtD.LCIDS.SerialBridgeDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$tKtD.LCIDS.SerialBridgeDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$tKtD.LCIDS.SerialBridgeDeviceFamily, x);
                }, $OBwQmg ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":2719525,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$tKtD.LCIDS.SerialBridgeDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$tKtD.LCIDS.SerialBridgeDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $lIFHse ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":2719525,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$tKtD.LCIDS.SerialBridgeDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$tKtD.LCIDS.SerialBridgeDeviceFamily, x);
                }, $rdhySe ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$tKtD.LCIDS.SerialBridgeDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":2719525,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel), $.$XBGm.LCICPB.BinaryPacketProtocol$$$$($.$tKtD.LCIDS.SerialBridgeDevice, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICPB.BinaryPacketProtocolDecoder$$$($.$tKtD.LCIDS.SerialBridgeDevice, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICPB.BinaryPacketProtocolEncoder$$$($.$tKtD.LCIDS.SerialBridgeDevice, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICPB.BinaryPacketProtocolCommands$$($.$tKtD.LCIDS.SerialBridgeDevice), services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592654117)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$tKtD.LCIDS.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297686821)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297686821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297686821)
            
            //--TRIMMABLE-BOUNDARY-START(4297686821)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297686821)
            
            static $h = 2719525;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592654117),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2719525,
      "h": 8592654117,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592654117)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297686821),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2719525,
      "h": 4297686821,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297686821)
  ],
  "h": 2719525
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2719525)
        
        

        //--TRIMMABLE-BOUNDARY-START(2129701)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeStatusModel`, ($self) => class SerialBridgeStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(12887031589)
            /*byte[]?*/ Data = null;
            //--TRIMMABLE-BOUNDARY-END(12887031589)
            
            //--TRIMMABLE-BOUNDARY-START(8592064293)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592064293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592064293)
            
            //--TRIMMABLE-BOUNDARY-START(8592064293)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592064293)
            
            static $h = 2129701;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887031589),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476966181,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066900773,
        "f": 83886081
      },
      "n": "Data",
      "d": 2129701,
      "h": 12887031589,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12887031589)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592064293),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2129701,
      "h": 8592064293,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592064293)
  ],
  "h": 2129701
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2129701)
        
        

        //--TRIMMABLE-BOUNDARY-START(98085)
        $asm.$cls(`$tKtD.LCIDSC.SerialBridgeTargetCommandModel`, ($self) => class SerialBridgeTargetCommandModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(8590032677)
            /*int */ get Command()
            {
                return ((128 + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(8590032677)
            
            //--TRIMMABLE-BOUNDARY-START(21474934565)
            /*void */ PackTo(/*PacketBuilder*/ packet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474934565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                packet.Push$11($.$cast(this.Header, $.$$.S.UInt16), 0);
                packet.Push$1($.$cast(this.Command, $.$$.S.Byte));
            }
            //--TRIMMABLE-BOUNDARY-END(21474934565)
            
            //--TRIMMABLE-BOUNDARY-START(25769901861)
            /*void */ UnPackFrom(/*PacketBuilder*/ packet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769901861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25769901861)
            
            //--TRIMMABLE-BOUNDARY-START(4315515222)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IPacketBuilder.PackTo(LivingThing.Core.Frameworks.Common.Data.PacketBuilder)
            LCFCD$IPacketBuilder$PackTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4315515222);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PackTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4315515222)
            
            //--TRIMMABLE-BOUNDARY-START(8610482518)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IPacketBuilder.UnPackFrom(LivingThing.Core.Frameworks.Common.Data.PacketBuilder)
            LCFCD$IPacketBuilder$UnPackFrom()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8610482518);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UnPackFrom(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8610482518)
            
            //--TRIMMABLE-BOUNDARY-START(4295065381)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295065381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295065381)
            
            //--TRIMMABLE-BOUNDARY-START(4295065381)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295065381)
            
            static $h = 98085;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590032677),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17179967269,
        "f": 50364417
      },
      "n": "Command",
      "d": 98085,
      "h": 8590032677,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8590032677)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21474934565),
    {
      "r": 65537,
      "p": [
        {
          "n": "packet",
          "p": 31164758
        }
      ],
      "n": "PackTo",
      "d": 98085,
      "h": 21474934565,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21474934565),
//--TRIMMABLE-BOUNDARY-START(25769901861),
    {
      "r": 65537,
      "p": [
        {
          "n": "packet",
          "p": 31164758
        }
      ],
      "n": "UnPackFrom",
      "d": 98085,
      "h": 25769901861,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25769901861)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295065381),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 98085,
      "h": 4295065381,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295065381)
  ],
  "h": 98085
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Commands.SerialBridgeTargetCommandModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Commands${separator}SerialBridgeTargetCommandModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(98085)
        
        

        //--TRIMMABLE-BOUNDARY-START(1605413)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel`, ($self) => class SerialBridgeDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceSendDataModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296572709)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296572709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296572709)
            
            //--TRIMMABLE-BOUNDARY-START(4296572709)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296572709)
            
            static $h = 1605413;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceSendDataModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296572709),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1605413,
      "h": 4296572709,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296572709)
  ],
  "h": 1605413
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1605413)
        
        

        //--TRIMMABLE-BOUNDARY-START(2260773)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeStatusModelTypeDescriptor`, ($self) => class SerialBridgeStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297228069)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297228069);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$tKtD.LCIDSM.SerialBridgeStatusModelTypeDescriptor.GenerateProperties($.$tKtD.LCIDSM.SerialBridgeStatusModel, this, factory);
                    }, $xeppDf ??= {"r":65537,"n":"","d":2260773,"h":0,"f":17825794}), 0, "SerialBridgeStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridge\\Models_SerialBridgeDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeStatusModelTypeDescriptorBuilder.g.cs", "SerialBridgeStatusModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297228069)
            
            //--TRIMMABLE-BOUNDARY-START(12887162661)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887162661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Data"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$tKtD.LCIDSM.SerialBridgeStatusModel.$type, $.$discardRef(), "Data", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Data")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.Byte), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Data";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSM.SerialBridgeStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.Byte), ($.$cast(target, $.$tKtD.LCIDSM.SerialBridgeStatusModel)).Data);
                        }, $CoPfXk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2260773,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSM.SerialBridgeStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Data = value.AsReference($.$typeArray($.$$.S.Byte));
                        }, $bsFDzk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2260773,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887162661)
            
            //--TRIMMABLE-BOUNDARY-START(17182129957)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182129957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _Data = _target.Data;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Data"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.Byte)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.Byte), $.$$.S.Byte));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.Byte), $.$$.S.Byte, property, $.$ref(() => _Data, ($v) => _Data = $v, $.$typeArray($.$$.S.Byte))))
                    {
                        _target.Data = _Data;
                        if (_Data !== null)
                        {
                            let $i6 = 0;
                            let $arr6 = _Data;
                            while ($i6 < $arr6.length)
                            {
                                let item = $arr6[$i6++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.Byte)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.Byte), $.$$.S.Byte, property, $.$ref(() => _Data, ($v) => _Data = $v, $.$typeArray($.$$.S.Byte)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182129957)
            
            //--TRIMMABLE-BOUNDARY-START(8592195365)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592195365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$tKtD.LCIDSM.SerialBridgeStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$tKtD.LCIDSM.SerialBridgeStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeStatusModel)))
                {
                    /*var*/ let result = $.$tKtD.LCIDSM.SerialBridgeStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$tKtD.LCIDSM.SerialBridgeStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592195365)
            
            static $h = 2260773;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887162661),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2260773,
      "h": 12887162661,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887162661),
//--TRIMMABLE-BOUNDARY-START(17182129957),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2129701,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2260773,
      "h": 17182129957,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182129957),
//--TRIMMABLE-BOUNDARY-START(8592195365),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2129701,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2260773,
      "h": 8592195365,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592195365)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297228069),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2260773,
      "h": 4297228069,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297228069)
  ],
  "h": 2260773
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2260773)
        
        

        //--TRIMMABLE-BOUNDARY-START(229157)
        $asm.$cls(`$tKtD.LCIDSC.SerialBridgeTargetCommandModelTypeDescriptor`, ($self) => class SerialBridgeTargetCommandModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSC.SerialBridgeTargetCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295196453)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295196453);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$tKtD.LCIDSC.SerialBridgeTargetCommandModelTypeDescriptor.GenerateProperties($.$tKtD.LCIDSC.SerialBridgeTargetCommandModel, this, factory);
                    }, $VCNqid ??= {"r":65537,"n":"","d":229157,"h":0,"f":17825794}), 0, "SerialBridgeTargetCommandModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridge\\Commands_SerialBridgeTargetCommandModel_LivingThing.Core.IOT.Devices.SerialBridge.Commands.SerialBridgeTargetCommandModelTypeDescriptorBuilder.g.cs", "SerialBridgeTargetCommandModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295196453)
            
            //--TRIMMABLE-BOUNDARY-START(12885131045)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885131045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$tKtD.LCIDSC.SerialBridgeTargetCommandModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Command";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.SerialBridge.Commands.SerialBridgeTargetCommandModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSC.SerialBridgeTargetCommandModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$tKtD.LCIDSC.SerialBridgeTargetCommandModel)).Command);
                        }, $qeuLYj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":229157,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885131045)
            
            //--TRIMMABLE-BOUNDARY-START(17180098341)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Commands.SerialBridgeTargetCommandModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180098341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180098341)
            
            //--TRIMMABLE-BOUNDARY-START(8590163749)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Commands.SerialBridgeTargetCommandModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590163749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$tKtD.LCIDSC.SerialBridgeTargetCommandModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$tKtD.LCIDSC.SerialBridgeTargetCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSC.SerialBridgeTargetCommandModel)))
                {
                    /*var*/ let result = $.$tKtD.LCIDSC.SerialBridgeTargetCommandModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSC.SerialBridgeTargetCommandModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$tKtD.LCIDSC.SerialBridgeTargetCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSC.SerialBridgeTargetCommandModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590163749)
            
            static $h = 229157;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSC.SerialBridgeTargetCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885131045),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 229157,
      "h": 12885131045,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885131045),
//--TRIMMABLE-BOUNDARY-START(17180098341),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 98085,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 229157,
      "h": 17180098341,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180098341),
//--TRIMMABLE-BOUNDARY-START(8590163749),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 98085,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 229157,
      "h": 8590163749,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590163749)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295196453),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 229157,
      "h": 4295196453,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295196453)
  ],
  "h": 229157
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$tKtD.LCIDSC.SerialBridgeTargetCommandModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Commands.SerialBridgeTargetCommandModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Commands${separator}SerialBridgeTargetCommandModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(229157)
        
        

        //--TRIMMABLE-BOUNDARY-START(1736485)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelTypeDescriptor`, ($self) => class SerialBridgeDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296703781)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296703781);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelTypeDescriptor.GenerateProperties($.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, this, factory);
                    }, $uVcxri ??= {"r":65537,"n":"","d":1736485,"h":0,"f":17825794}), 0, "SerialBridgeDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridge\\Models_SerialBridgeDeviceSendDataModel_LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceSendDataModelTypeDescriptorBuilder.g.cs", "SerialBridgeDeviceSendDataModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296703781)
            
            //--TRIMMABLE-BOUNDARY-START(12886638373)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886638373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886638373)
            
            //--TRIMMABLE-BOUNDARY-START(17181605669)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181605669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceSendDataModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceSendDataModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181605669)
            
            //--TRIMMABLE-BOUNDARY-START(8591671077)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591671077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591671077)
            
            static $h = 1736485;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886638373),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1736485,
      "h": 12886638373,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886638373),
//--TRIMMABLE-BOUNDARY-START(17181605669),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1605413,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1736485,
      "h": 17181605669,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181605669),
//--TRIMMABLE-BOUNDARY-START(8591671077),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1605413,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1736485,
      "h": 8591671077,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591671077)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296703781),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1736485,
      "h": 4296703781,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296703781)
  ],
  "h": 1736485
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1736485)
        
        

        //--TRIMMABLE-BOUNDARY-START(818981)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel<>`, (TStatus) => $asm.$gt(`$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel<>`, [TStatus], ($self) => class SerialBridgeDeviceReceivedDataModel$$ extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$(TStatus)
        {
            //--TRIMMABLE-BOUNDARY-START(4295786277)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295786277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295786277)
            
            //--TRIMMABLE-BOUNDARY-START(4295786277)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295786277)
            
            static $H = 818981;
            static $h = 818981;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$(TStatus); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295786277),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 4295786277,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295786277)
  ],
  "s": [
    {
      "h": TStatus?.$h??1572864,
      "n": "TStatus",
      "c": [23434641
      ]
    }
  ],
  "r": 1,
  "H": 818981,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModel<${TStatus?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceReceivedDataModel$${TStatus?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(818981)
        
        

        //--TRIMMABLE-BOUNDARY-START(753445)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel`, ($self) => class SerialBridgeDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$tKtD.LCIDSM.SerialBridgeStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8590688037)
            /*TData? */ GetStatus(TData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590688037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((this.Status?.Data ?? null) === null)
                {
                    return $.$default(TData);
                }
                /*var*/ let packetBuilder = new $.$fPer.LCFCD.PacketBuilder().$ctor$1(this.Status.Data);
                return packetBuilder.Get(TData, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590688037)
            
            //--TRIMMABLE-BOUNDARY-START(4295720741)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295720741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295720741)
            
            //--TRIMMABLE-BOUNDARY-START(4295720741)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295720741)
            
            static $h = 753445;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$tKtD.LCIDSM.SerialBridgeStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590688037),
    {
      "r": (TData) => TData.$h,
      "g": [
        "TData"
      ],
      "n": "GetStatus",
      "d": 753445,
      "h": 8590688037,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(8590688037)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295720741),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 753445,
      "h": 4295720741,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295720741)
  ],
  "h": 753445
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(753445)
        
        

        //--TRIMMABLE-BOUNDARY-START(1146661)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptor<>`, (TStatus) => $asm.$gt(`$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptor<>`, [TStatus], ($self) => class SerialBridgeDeviceReceivedDataModelTypeDescriptor$$ extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$(TStatus))
        {
            //--TRIMMABLE-BOUNDARY-START(4296113957)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296113957);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptor$$(TStatus).GenerateProperties($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$(TStatus), this, factory);
                    }, $hBIdye ??= {"r":65537,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), 0, "SerialBridgeDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridge\\Models_SerialBridgeDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModel_TStatus_TypeDescriptorBuilder.g.cs", "SerialBridgeDeviceReceivedDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296113957)
            
            //--TRIMMABLE-BOUNDARY-START(12886048549)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886048549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$(TStatus).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886048549)
            
            //--TRIMMABLE-BOUNDARY-START(17181015845)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModel<TStatus>*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181015845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<TStatus>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$(TStatus).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$(TStatus)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181015845)
            
            //--TRIMMABLE-BOUNDARY-START(8591081253)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModel<TStatus>?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591081253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new ($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$(TStatus))().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$(TStatus), null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$(TStatus))))
                {
                    /*var*/ let result = $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptor$$(TStatus).VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$(TStatus)));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$(TStatus), null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$(TStatus)));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591081253)
            
            static $H = 1146661;
            static $h = 1146661;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$(TStatus)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886048549),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": this.$h,
      "H": 12886048549,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886048549),
//--TRIMMABLE-BOUNDARY-START(17181015845),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$(TStatus).$h,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": this.$h,
      "H": 17181015845,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181015845),
//--TRIMMABLE-BOUNDARY-START(8591081253),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$(TStatus).$h,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": this.$h,
      "H": 8591081253,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591081253)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296113957),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4296113957,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296113957)
  ],
  "s": [
    {
      "h": TStatus?.$h??1572864,
      "n": "TStatus",
      "c": [23434641
      ]
    }
  ],
  "r": 1,
  "H": 1146661,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$(TStatus)), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModelTypeDescriptor<${TStatus?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceReceivedDataModelTypeDescriptor$${TStatus?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1146661)
        
        

        //--TRIMMABLE-BOUNDARY-START(1081125)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptor`, ($self) => class SerialBridgeDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296048421)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296048421);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, this, factory);
                    }, $OMtrqh ??= {"r":65537,"n":"","d":1081125,"h":0,"f":17825794}), 0, "SerialBridgeDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridge\\Models_SerialBridgeDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "SerialBridgeDeviceReceivedDataModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296048421)
            
            //--TRIMMABLE-BOUNDARY-START(12885983013)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885983013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeStatusModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885983013)
            
            //--TRIMMABLE-BOUNDARY-START(17180950309)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180950309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeStatusModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeStatusModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$tKtD.LCIDSM.SerialBridgeStatusModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180950309)
            
            //--TRIMMABLE-BOUNDARY-START(8591015717)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591015717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591015717)
            
            static $h = 1081125;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885983013),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1081125,
      "h": 12885983013,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885983013),
//--TRIMMABLE-BOUNDARY-START(17180950309),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 753445,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1081125,
      "h": 17180950309,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180950309),
//--TRIMMABLE-BOUNDARY-START(8591015717),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 753445,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1081125,
      "h": 8591015717,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591015717)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296048421),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1081125,
      "h": 4296048421,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296048421)
  ],
  "h": 1081125
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1081125)
        
        

        //--TRIMMABLE-BOUNDARY-START(2391845)
        $asm.$cls(`$tKtD.LCIDS.SerialBridgeDataConverter`, ($self) => class SerialBridgeDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297359141)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297359141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297359141)
            
            //--TRIMMABLE-BOUNDARY-START(4297359141)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297359141)
            
            static $h = 2391845;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297359141),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2391845,
      "h": 4297359141,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297359141)
  ],
  "h": 2391845
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.SerialBridgeDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}SerialBridgeDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2391845)
        
        

        $asm.$typeProxy("$tKtD.LCIDSM.SerialBridgeServiceModel", "$tKtD.LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeServiceModel");
        $asm.$typeProxy("$tKtD.LCIDSM.SerialBridgeDeviceModel", "$tKtD.LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceModel");
        $asm.$typeProxy("$tKtD.LCIDSS$1.SerialBridgeDeviceSettings", "$tKtD.LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceSettings");
        $asm.$typeProxy("$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings", "$tKtD.LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings");
        $asm.$typeProxy("$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler", "$tKtD.LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeDeviceStatusHandler");
        $asm.$typeProxy("$tKtD.LCIDSS.ISerialBridgeDeviceHubClient", "$tKtD.LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeDeviceHubClient");
        $asm.$typeProxy("$tKtD.LCIDSS.ISerialBridgeRemoteService", "$tKtD.LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeRemoteService");
        //--TRIMMABLE-BOUNDARY-START(1343269)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceScopeModel`, ($self) => class SerialBridgeDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296310565)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296310565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296310565)
            
            //--TRIMMABLE-BOUNDARY-START(4296310565)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296310565)
            
            static $h = 1343269;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296310565),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1343269,
      "h": 4296310565,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296310565)
  ],
  "h": 1343269
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1343269)
        
        

        //--TRIMMABLE-BOUNDARY-START(491301)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceModel`, ($self) => class SerialBridgeDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295458597)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295458597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295458597)
            
            //--TRIMMABLE-BOUNDARY-START(4295458597)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295458597)
            
            static $h = 491301;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295458597),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 491301,
      "h": 4295458597,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295458597)
  ],
  "h": 491301
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(491301)
        
        

        //--TRIMMABLE-BOUNDARY-START(2981669)
        $asm.$cls(`$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings`, ($self) => class SerialBridgeDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(115967098661)
            /*IOTDeviceInternalConfiguration<uint>*/ Preamble = null;
            //--TRIMMABLE-BOUNDARY-END(115967098661)
            
            //--TRIMMABLE-BOUNDARY-START(120262065957)
            /*IOTDeviceInternalConfiguration<byte>*/ PreambleLength = null;
            //--TRIMMABLE-BOUNDARY-END(120262065957)
            
            //--TRIMMABLE-BOUNDARY-START(38657687333)
            /*IOTDeviceInternalConfiguration<uint>*/ BaudRate = null;
            //--TRIMMABLE-BOUNDARY-END(38657687333)
            
            //--TRIMMABLE-BOUNDARY-START(42952654629)
            /*IOTDeviceInternalConfiguration<byte>*/ Bits = null;
            //--TRIMMABLE-BOUNDARY-END(42952654629)
            
            //--TRIMMABLE-BOUNDARY-START(184686575397)
            /*IOTDeviceInternalConfiguration<byte>*/ StopBits = null;
            //--TRIMMABLE-BOUNDARY-END(184686575397)
            
            //--TRIMMABLE-BOUNDARY-START(111672131365)
            /*IOTDeviceInternalConfiguration<byte>*/ Parity = null;
            //--TRIMMABLE-BOUNDARY-END(111672131365)
            
            //--TRIMMABLE-BOUNDARY-START(47247621925)
            /*IOTDeviceInternalConfiguration<string>*/ FamilyName = null;
            //--TRIMMABLE-BOUNDARY-END(47247621925)
            
            //--TRIMMABLE-BOUNDARY-START(34362720037)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362720037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34362720037)
            
            //--TRIMMABLE-BOUNDARY-START(34362720037)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(34362720037)
            
            static $h = 2981669;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115967098661),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90197294885,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163211738917,
        "f": 83886081
      },
      "n": "Preamble",
      "d": 2981669,
      "h": 115967098661,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115967098661),
//--TRIMMABLE-BOUNDARY-START(120262065957),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98787229477,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171801673509,
        "f": 83886081
      },
      "n": "PreambleLength",
      "d": 2981669,
      "h": 120262065957,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120262065957),
//--TRIMMABLE-BOUNDARY-START(38657687333),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837556517,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128852000549,
        "f": 83886081
      },
      "n": "BaudRate",
      "d": 2981669,
      "h": 38657687333,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657687333),
//--TRIMMABLE-BOUNDARY-START(42952654629),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427491109,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137441935141,
        "f": 83886081
      },
      "n": "Bits",
      "d": 2981669,
      "h": 42952654629,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952654629),
//--TRIMMABLE-BOUNDARY-START(184686575397),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107377164069,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180391608101,
        "f": 83886081
      },
      "n": "StopBits",
      "d": 2981669,
      "h": 184686575397,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184686575397),
//--TRIMMABLE-BOUNDARY-START(111672131365),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81607360293,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154621804325,
        "f": 83886081
      },
      "n": "Parity",
      "d": 2981669,
      "h": 111672131365,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111672131365),
//--TRIMMABLE-BOUNDARY-START(47247621925),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73017425701,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146031869733,
        "f": 83886081
      },
      "n": "FamilyName",
      "d": 2981669,
      "h": 47247621925,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247621925)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34362720037),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2981669,
      "h": 34362720037,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362720037)
  ],
  "h": 2981669
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Settings${separator}SerialBridgeDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2981669)
        
        

        //--TRIMMABLE-BOUNDARY-START(2785061)
        $asm.$cls(`$tKtD.LCIDSS.ISerialBridgeDeviceHubClient`, ($self) => class ISerialBridgeDeviceHubClient
        {
            static $h = 2785061;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2785061
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Services${separator}ISerialBridgeDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2785061)
        
        

        //--TRIMMABLE-BOUNDARY-START(1867557)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeServiceModel`, ($self) => class SerialBridgeServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296834853)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296834853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296834853)
            
            //--TRIMMABLE-BOUNDARY-START(4296834853)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4296834853)
            
            static $h = 1867557;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296834853),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 1867557,
      "h": 4296834853,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296834853)
  ],
  "h": 1867557
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1867557)
        
        

        //--TRIMMABLE-BOUNDARY-START(2850597)
        $asm.$cls(`$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler`, ($self) => class ISerialBridgeDeviceStatusHandler
        {
            static $h = 2850597;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2850597
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Services${separator}ISerialBridgeDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2850597)
        
        

        //--TRIMMABLE-BOUNDARY-START(3243813)
        $asm.$cls(`$tKtD.LCIDSS$1.SerialBridgeDeviceSettings`, ($self) => class SerialBridgeDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $self, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4298211109)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298211109);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298211109)
            
            //--TRIMMABLE-BOUNDARY-START(4298211109)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4298211109)
            
            static $h = 3243813;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298211109),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3243813,
      "h": 4298211109,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298211109)
  ],
  "h": 3243813
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Settings${separator}SerialBridgeDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3243813)
        
        

        //--TRIMMABLE-BOUNDARY-START(2916133)
        $asm.$cls(`$tKtD.LCIDSS.ISerialBridgeRemoteService`, ($self) => class ISerialBridgeRemoteService
        {
            static $h = 2916133;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2916133
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$tKtD.LCIDSM.SerialBridgeServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$tKtD.LCIDSM.SerialBridgeServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$tKtD.LCIDSM.SerialBridgeServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$tKtD.LCIDSM.SerialBridgeServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$tKtD.LCIDSM.SerialBridgeServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$tKtD.LCIDSM.SerialBridgeServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$tKtD.LCIDSM.SerialBridgeServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$tKtD.LCIDSM.SerialBridgeServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Services${separator}ISerialBridgeRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2916133)
        
        

        //--TRIMMABLE-BOUNDARY-START(2653989)
        $asm.$cls(`$tKtD.LCIDS.SerialBridgeDeviceModelDefinition`, ($self) => class SerialBridgeDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4297621285)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297621285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297621285)
            
            //--TRIMMABLE-BOUNDARY-START(4297621285)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297621285)
            
            static $h = 2653989;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297621285),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2653989,
      "h": 4297621285,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297621285)
  ],
  "h": 2653989
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.SerialBridgeDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}SerialBridgeDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2653989)
        
        

        //--TRIMMABLE-BOUNDARY-START(1474341)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceScopeModelTypeDescriptor`, ($self) => class SerialBridgeDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296441637)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296441637);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModelTypeDescriptor.GenerateProperties($.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, this, factory);
                    }, $DbpQYd ??= {"r":65537,"n":"","d":1474341,"h":0,"f":17825794}), 0, "SerialBridgeDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridge\\Models_SerialBridgeDeviceScopeModel_LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceScopeModelTypeDescriptorBuilder.g.cs", "SerialBridgeDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296441637)
            
            //--TRIMMABLE-BOUNDARY-START(12886376229)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886376229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886376229)
            
            //--TRIMMABLE-BOUNDARY-START(17181343525)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181343525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceModel, LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceSettings, LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceSendDataModel, LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeDeviceStatusHandler, LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeDeviceHubClient, LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181343525)
            
            //--TRIMMABLE-BOUNDARY-START(8591408933)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591408933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel)))
                {
                    /*var*/ let result = $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591408933)
            
            static $h = 1474341;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886376229),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1474341,
      "h": 12886376229,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886376229),
//--TRIMMABLE-BOUNDARY-START(17181343525),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1343269,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1474341,
      "h": 17181343525,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181343525),
//--TRIMMABLE-BOUNDARY-START(8591408933),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1343269,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1474341,
      "h": 8591408933,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591408933)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296441637),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1474341,
      "h": 4296441637,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296441637)
  ],
  "h": 1474341
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1474341)
        
        

        //--TRIMMABLE-BOUNDARY-START(3374885)
        $asm.$cls(`$tKtD.LCIDSS$1.SerialBridgeDeviceSettingsTypeDescriptor`, ($self) => class SerialBridgeDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298342181)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298342181);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettingsTypeDescriptor.GenerateProperties($.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, this, factory);
                    }, $LVQbAb ??= {"r":65537,"n":"","d":3374885,"h":0,"f":17825794}), 0, "SerialBridgeDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridge\\Settings_SerialBridgeDeviceSettings_LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceSettingsTypeDescriptorBuilder.g.cs", "SerialBridgeDeviceSettingsTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298342181)
            
            //--TRIMMABLE-BOUNDARY-START(12888276773)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888276773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888276773)
            
            //--TRIMMABLE-BOUNDARY-START(17183244069)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183244069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceModel, LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceSettings, LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceSendDataModel, LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeDeviceStatusHandler, LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeDeviceHubClient, LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).iSmartDeviceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183244069)
            
            //--TRIMMABLE-BOUNDARY-START(8593309477)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593309477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings)))
                {
                    /*var*/ let result = $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593309477)
            
            static $h = 3374885;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888276773),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3374885,
      "h": 12888276773,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888276773),
//--TRIMMABLE-BOUNDARY-START(17183244069),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3243813,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3374885,
      "h": 17183244069,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183244069),
//--TRIMMABLE-BOUNDARY-START(8593309477),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3243813,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3374885,
      "h": 8593309477,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593309477)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298342181),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3374885,
      "h": 4298342181,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298342181)
  ],
  "h": 3374885
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Settings${separator}SerialBridgeDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3374885)
        
        

        //--TRIMMABLE-BOUNDARY-START(3112741)
        $asm.$cls(`$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor`, ($self) => class SerialBridgeDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298080037)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298080037);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, this, factory);
                    }, $CezHnf ??= {"r":65537,"n":"","d":3112741,"h":0,"f":17825794}), 0, "SerialBridgeDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridge\\Settings_SerialBridgeDeviceHardwareSettings_LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "SerialBridgeDeviceHardwareSettingsTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298080037)
            
            //--TRIMMABLE-BOUNDARY-START(12888014629)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888014629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Preamble"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings.$type, $.$discardRef(), "Preamble", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Preamble")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt32), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Preamble";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt32), ($.$cast(target, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings)).Preamble);
                        }, $wKrByj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3112741,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Preamble = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt32));
                        }, $lSojCe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3112741,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PreambleLength"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings.$type, $.$discardRef(), "PreambleLength", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PreambleLength")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "PreambleLength";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte), ($.$cast(target, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings)).PreambleLength);
                        }, $yVYCog ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3112741,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PreambleLength = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte));
                        }, $RvzCoh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3112741,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BaudRate"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings.$type, $.$discardRef(), "BaudRate", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BaudRate")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt32), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "BaudRate";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt32), ($.$cast(target, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings)).BaudRate);
                        }, $pZDGcd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3112741,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.BaudRate = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt32));
                        }, $Hemhhb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3112741,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Bits"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings.$type, $.$discardRef(), "Bits", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Bits")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Bits";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte), ($.$cast(target, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings)).Bits);
                        }, $lWyVma ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3112741,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Bits = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte));
                        }, $ypenCk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3112741,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("StopBits"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings.$type, $.$discardRef(), "StopBits", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("StopBits")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "StopBits";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte), ($.$cast(target, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings)).StopBits);
                        }, $NemaBa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3112741,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.StopBits = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte));
                        }, $VXVMFj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3112741,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Parity"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings.$type, $.$discardRef(), "Parity", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Parity")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Parity";
                        $i11.DelaredOn = "LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte), ($.$cast(target, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings)).Parity);
                        }, $zwufPc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3112741,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Parity = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte));
                        }, $ALgkke ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3112741,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FamilyName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings.$type, $.$discardRef(), "FamilyName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FamilyName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "FamilyName";
                        $i13.DelaredOn = "LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), ($.$cast(target, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings)).FamilyName);
                        }, $FerxVb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3112741,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.FamilyName = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String));
                        }, $YSVAAb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3112741,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888014629)
            
            //--TRIMMABLE-BOUNDARY-START(17182981925)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182981925);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceModel, LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceSettings, LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceSendDataModel, LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeDeviceStatusHandler, LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeDeviceHubClient, LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).iSmartDeviceHardwareSettings));
                {
                    /*var*/ let _Preamble = _target.Preamble;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Preamble"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt32)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Preamble, ($v) => _Preamble = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt32))))
                    {
                        _target.Preamble = _Preamble;
                    }
                }
                {
                    /*var*/ let _PreambleLength = _target.PreambleLength;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PreambleLength"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _PreambleLength, ($v) => _PreambleLength = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte))))
                    {
                        _target.PreambleLength = _PreambleLength;
                    }
                }
                {
                    /*var*/ let _BaudRate = _target.BaudRate;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BaudRate"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt32)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _BaudRate, ($v) => _BaudRate = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.UInt32))))
                    {
                        _target.BaudRate = _BaudRate;
                    }
                }
                {
                    /*var*/ let _Bits = _target.Bits;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Bits"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Bits, ($v) => _Bits = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte))))
                    {
                        _target.Bits = _Bits;
                    }
                }
                {
                    /*var*/ let _StopBits = _target.StopBits;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("StopBits"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _StopBits, ($v) => _StopBits = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte))))
                    {
                        _target.StopBits = _StopBits;
                    }
                }
                {
                    /*var*/ let _Parity = _target.Parity;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Parity"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Parity, ($v) => _Parity = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte))))
                    {
                        _target.Parity = _Parity;
                    }
                }
                {
                    /*var*/ let _FamilyName = _target.FamilyName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FamilyName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _FamilyName, ($v) => _FamilyName = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String))))
                    {
                        _target.FamilyName = _FamilyName;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182981925)
            
            //--TRIMMABLE-BOUNDARY-START(8593047333)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593047333);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593047333)
            
            static $h = 3112741;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888014629),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3112741,
      "h": 12888014629,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888014629),
//--TRIMMABLE-BOUNDARY-START(17182981925),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2981669,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3112741,
      "h": 17182981925,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182981925),
//--TRIMMABLE-BOUNDARY-START(8593047333),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2981669,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3112741,
      "h": 8593047333,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593047333)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298080037),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3112741,
      "h": 4298080037,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298080037)
  ],
  "h": 3112741
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Settings${separator}SerialBridgeDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3112741)
        
        

        //--TRIMMABLE-BOUNDARY-START(1998629)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeServiceModelTypeDescriptor`, ($self) => class SerialBridgeServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296965925)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296965925);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$tKtD.LCIDSM.SerialBridgeServiceModelTypeDescriptor.GenerateProperties($.$tKtD.LCIDSM.SerialBridgeServiceModel, this, factory);
                    }, $AiUWdb ??= {"r":65537,"n":"","d":1998629,"h":0,"f":17825794}), 0, "SerialBridgeServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridge\\Models_SerialBridgeServiceModel_LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeServiceModelTypeDescriptorBuilder.g.cs", "SerialBridgeServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296965925)
            
            //--TRIMMABLE-BOUNDARY-START(12886900517)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886900517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886900517)
            
            //--TRIMMABLE-BOUNDARY-START(17181867813)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181867813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceModel, LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceSettings, LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceSendDataModel, LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeDeviceStatusHandler, LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeDeviceHubClient, LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181867813)
            
            //--TRIMMABLE-BOUNDARY-START(8591933221)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591933221);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$tKtD.LCIDSM.SerialBridgeServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$tKtD.LCIDSM.SerialBridgeServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeServiceModel)))
                {
                    /*var*/ let result = $.$tKtD.LCIDSM.SerialBridgeServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$tKtD.LCIDSM.SerialBridgeServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591933221)
            
            static $h = 1998629;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886900517),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1998629,
      "h": 12886900517,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886900517),
//--TRIMMABLE-BOUNDARY-START(17181867813),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1867557,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1998629,
      "h": 17181867813,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181867813),
//--TRIMMABLE-BOUNDARY-START(8591933221),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1867557,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1998629,
      "h": 8591933221,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591933221)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296965925),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1998629,
      "h": 4296965925,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296965925)
  ],
  "h": 1998629
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1998629)
        
        

        //--TRIMMABLE-BOUNDARY-START(622373)
        $asm.$cls(`$tKtD.LCIDSM.SerialBridgeDeviceModelTypeDescriptor`, ($self) => class SerialBridgeDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295589669)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295589669);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$tKtD.LCIDSM.SerialBridgeDeviceModelTypeDescriptor.GenerateProperties($.$tKtD.LCIDSM.SerialBridgeDeviceModel, this, factory);
                    }, $FnFxNi ??= {"r":65537,"n":"","d":622373,"h":0,"f":17825794}), 0, "SerialBridgeDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridge\\Models_SerialBridgeDeviceModel_LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceModelTypeDescriptorBuilder.g.cs", "SerialBridgeDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295589669)
            
            //--TRIMMABLE-BOUNDARY-START(12885524261)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885524261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885524261)
            
            //--TRIMMABLE-BOUNDARY-START(17180491557)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180491557);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceModel, LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceSettings, LivingThing.Core.IOT.Devices.SerialBridge.Settings.SerialBridgeDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceSendDataModel, LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeDeviceStatusHandler, LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeDeviceHubClient, LivingThing.Core.IOT.Devices.SerialBridge.Services.ISerialBridgeRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180491557)
            
            //--TRIMMABLE-BOUNDARY-START(8590556965)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590556965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$tKtD.LCIDSM.SerialBridgeDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceModel)))
                {
                    /*var*/ let result = $.$tKtD.LCIDSM.SerialBridgeDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590556965)
            
            static $h = 622373;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885524261),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 622373,
      "h": 12885524261,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885524261),
//--TRIMMABLE-BOUNDARY-START(17180491557),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 491301,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 622373,
      "h": 17180491557,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180491557),
//--TRIMMABLE-BOUNDARY-START(8590556965),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 491301,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 622373,
      "h": 8590556965,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590556965)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295589669),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 622373,
      "h": 4295589669,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295589669)
  ],
  "h": 622373
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$tKtD.LCIDSM.SerialBridgeDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}Models${separator}SerialBridgeDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(622373)
        
        

        //--TRIMMABLE-BOUNDARY-START(2457381)
        $asm.$cls(`$tKtD.LCIDS.SerialBridgeDevice`, ($self) => class SerialBridgeDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$tKtD.LCIDSM.SerialBridgeStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4297424677)
            $ctor$2(/*IIOTDeviceFamily<SerialBridgeDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*SerialBridgeDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297424677);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297424677)
            
            static $h = 2457381;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDS.SerialBridgeDevice, $.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$tKtD.LCIDSM.SerialBridgeStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297424677),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$tKtD.LCIDS.SerialBridgeDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 491301
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2457381,
      "h": 4297424677,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297424677)
  ],
  "h": 2457381
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.SerialBridgeDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}SerialBridgeDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2457381)
        
        

        //--TRIMMABLE-BOUNDARY-START(2522917)
        $asm.$cls(`$tKtD.LCIDS.SerialBridgeDeviceDefinition`, ($self) => class SerialBridgeDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDS.SerialBridgeDevice, $.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$tKtD.LCIDSM.SerialBridgeStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297490213)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297490213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297490213)
            
            //--TRIMMABLE-BOUNDARY-START(4297490213)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297490213)
            
            static $h = 2522917;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDS.SerialBridgeDevice, $.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$tKtD.LCIDSM.SerialBridgeStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297490213),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2522917,
      "h": 4297490213,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297490213)
  ],
  "h": 2522917
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.SerialBridgeDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}SerialBridgeDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2522917)
        
        

        //--TRIMMABLE-BOUNDARY-START(2588453)
        $asm.$cls(`$tKtD.LCIDS.SerialBridgeDeviceFamily`, ($self) => class SerialBridgeDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDS.SerialBridgeDevice, $.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4297555749)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<SerialBridgeDeviceReceivedDataModel, SerialBridgeDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<SerialBridgeDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297555749);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297555749)
            
            static $h = 2588453;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$tKtD.LCIDS.SerialBridgeDevice, $.$tKtD.LCIDSM.SerialBridgeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$tKtD.LCIDSM.SerialBridgeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$tKtD.LCIDSM.SerialBridgeDeviceModel, $.$tKtD.LCIDSS$1.SerialBridgeDeviceSettings, $.$tKtD.LCIDSS$1.SerialBridgeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel, $.$tKtD.LCIDSS.ISerialBridgeDeviceStatusHandler, $.$tKtD.LCIDSS.ISerialBridgeDeviceHubClient, $.$tKtD.LCIDSS.ISerialBridgeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297555749),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2588453,
      "h": 4297555749,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297555749)
  ],
  "h": 2588453
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$tKtD.LCIDS.SerialBridgeDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$tKtD.LCIDS.SerialBridgeDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridge.SerialBridgeDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridge${separator}SerialBridgeDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2588453)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.DynamicExpresso.Core", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Devices"));
})();
//--TRIMMABLE-BOUNDARY-END(32549)
