
//--TRIMMABLE-BOUNDARY-START(33766)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej, $tKtD) {
    "use strict";
    let _;
    let $EBijwi;
    let $hshYEc;
    let $LTpHYj;
    let $mMtNqk;
    let $FVzFzc;
    let $JgIqKb;
    let $ivnHjf;
    let $HmdCYg;
    let $ubQjkh;
    let $zjnYOe;
    let $Lakyad;
    let $BISbQh;
    let $AUHWtb;
    let $ldAmad;
    let $uvZiNj;
    let $TxWcUd;
    let $ZZwWYi;
    let $XKWfni;
    let $gUrrHe;
    let $bUoNdc;
    let $SNvQUi;
    let $YRzble;
    let $jcDZyg;
    let $ISzFka;
    let $IJnRbl;
    let $ArdHSe;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver", 
    {
  "h": 33766,
  "f": "LivingThing.Core.IOT.Devices.SerialBridgeChangeOver",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.SerialBridgeChangeOver",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.SerialBridgeChangeOver",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5TZXJpYWxCcmlkZ2VDaGFuZ2VPdmVyLkNoYW5nZU92ZXJEZXZpY2UiOiB7DQogICAgICAiQ2F0ZWdvcmllcyI6IFsgIlNtYXJ0IEhvbWUiIF0sDQogICAgICAiTmFtZSI6ICJBdXRvbWF0aWMgQ2hhbmdlT3ZlciIsDQogICAgICAiRGVzY3JpcHRpb24iOiAiQXV0b21hdGVzIGNoYW5naW5nIGZyb20geW91ciB1dGlsaXR5IHN1cHBseSB0byB5b3VyIGdlbmVyYXRvciBzdXBwbHkuIiwNCiAgICAgICJUaGVtZUNvbG9yIjogIiNkZjcxMjYiLA0KICAgICAgIkZsYWdzIjogIlB1Ymxpc2hlZCIsDQogICAgICAiQmFubmVySW1hZ2UiOiAifi9DaGFuZ2VPdmVyL2ltZy9iYW5uZXIuanBnIiwNCiAgICAgICJTdGF0dXNOYW1lcyI6ICJEZXZpY2UuU3RhdHVzLlN0YXR1cy5HZW5lcmF0b3JTdGF0ZSxEZXZpY2UuU3RhdHVzLlN0YXR1cy5HZW5lcmF0b3IsRGV2aWNlLlN0YXR1cy5TdGF0dXMuR3JpZCIsDQogICAgICAiQ2xpY2tDb21tYW5kIjogew0KICAgICAgICAiTmFtZSI6ICJTdGFydCINCiAgICAgIH0sDQogICAgICAiSWNvbiI6IHsgIk5hbWUiOiAibWRpIG1kaS1lbmdpbmUiIH0sDQogICAgICAiU2VjdXJpdGllcyI6ICJDaGFsbGVuZ2VIYW5kU2hha2VBdXRoZW50aWNhdGlvblByb3RvY29sLEFkdmFuY2VkRW5jcnlwdGlvblN0YW5kYXJkLEVsbGlwdGljQ3VydmVGaXJtd2FyZVVwZGF0ZVNpZ25pbmciLA0KICAgICAgIlVuaXRDb3N0Ijogew0KICAgICAgICAiVmFsdWUiOiAxMDAwMCwNCiAgICAgICAgIlVuaXQiOiAiTmFpcmEiDQogICAgICB9LA0KICAgICAgIlZhcmlhbnRzIjogWw0KICAgICAgICB7DQogICAgICAgICAgIk5hbWUiOiAiNDBBIiwNCiAgICAgICAgICAiQ29zdCI6IHsNCiAgICAgICAgICAgICJWYWx1ZSI6IDEwMDAwLA0KICAgICAgICAgICAgIlVuaXQiOiAiTmFpcmEiDQogICAgICAgICAgfQ0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIk5hbWUiOiAiMTIwQSIsDQogICAgICAgICAgIkNvc3QiOiB7DQogICAgICAgICAgICAiVmFsdWUiOiA0MDAwMCwNCiAgICAgICAgICAgICJVbml0IjogIk5haXJhIg0KICAgICAgICAgIH0NCiAgICAgICAgfQ0KICAgICAgXQ0KICAgIH0NCiAgfQ0KfQ=="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1082342)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class ChangeOverDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296049638)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296049638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelCustomAttributesProvider$$($.$gKEB.LCIDSM.ChangeOverStatus).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296049638)
            
            static $h = 1082342;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296049638),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1082342,
      "h": 4296049638,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296049638)
  ],
  "h": 1082342
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1082342)
        
        

        //--TRIMMABLE-BOUNDARY-START(1868774)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverKeyControlCustomAttributesProvider`, ($self) => class ChangeOverKeyControlCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296836070)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296836070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296836070)
            
            static $h = 1868774;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296836070),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1868774,
      "h": 4296836070,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296836070)
  ],
  "h": 1868774
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverKeyControlCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverKeyControlCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1868774)
        
        

        //--TRIMMABLE-BOUNDARY-START(820198)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverDeviceModelCustomAttributesProvider`, ($self) => class ChangeOverDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295787494)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295787494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295787494)
            
            static $h = 820198;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295787494),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 820198,
      "h": 4295787494,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295787494)
  ],
  "h": 820198
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(820198)
        
        

        //--TRIMMABLE-BOUNDARY-START(3900390)
        $asm.$cls(`$gKEB.LCIDSS$1.ChangeOverDeviceSettingsCustomAttributesProvider`, ($self) => class ChangeOverDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298867686)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298867686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298867686)
            
            static $h = 3900390;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298867686),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3900390,
      "h": 4298867686,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298867686)
  ],
  "h": 3900390
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Settings${separator}ChangeOverDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3900390)
        
        

        //--TRIMMABLE-BOUNDARY-START(1999846)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverPhaseCustomAttributesProvider`, ($self) => class ChangeOverPhaseCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296967142)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296967142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296967142)
            
            static $h = 1999846;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296967142),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1999846,
      "h": 4296967142,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296967142)
  ],
  "h": 1999846
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverPhaseCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverPhaseCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1999846)
        
        

        //--TRIMMABLE-BOUNDARY-START(623590)
        $asm.$cls(`$gKEB.LCIDS.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295590886)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295590886);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$gKEB.LCIDSM.ChangeOverDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$gKEB.LCIDSM.ChangeOverDeviceModelCustomAttributesProvider, $.$gKEB.LCIDSM.ChangeOverDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$gKEB.LCIDSM.ChangeOverPhase.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$gKEB.LCIDSM.ChangeOverPhaseCustomAttributesProvider, $.$gKEB.LCIDSM.ChangeOverPhaseCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$gKEB.LCIDSM.ChangeOverState.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$gKEB.LCIDSM.ChangeOverStateCustomAttributesProvider, $.$gKEB.LCIDSM.ChangeOverStateCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModelCustomAttributesProvider, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$gKEB.LCIDSM.ChangeOverDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$gKEB.LCIDSM.ChangeOverDeviceScopeModelCustomAttributesProvider, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$gKEB.LCIDSM.ChangeOverDeviceSendDataModelCustomAttributesProvider, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$gKEB.LCIDSM.ChangeOverKeyControl.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$gKEB.LCIDSM.ChangeOverKeyControlCustomAttributesProvider, $.$gKEB.LCIDSM.ChangeOverKeyControlCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$gKEB.LCIDSM.ChangeOverServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$gKEB.LCIDSM.ChangeOverServiceModelCustomAttributesProvider, $.$gKEB.LCIDSM.ChangeOverServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$gKEB.LCIDSPC.ChangeOverCountDownCommandModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$gKEB.LCIDSPC.ChangeOverCountDownCommandModelCustomAttributesProvider, $.$gKEB.LCIDSPC.ChangeOverCountDownCommandModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$gKEB.LCIDSPC.ChangeOverKeyCommandModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$gKEB.LCIDSPC.ChangeOverKeyCommandModelCustomAttributesProvider, $.$gKEB.LCIDSPC.ChangeOverKeyCommandModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettingsCustomAttributesProvider, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$gKEB.LCIDSS$1.ChangeOverDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$gKEB.LCIDSS$1.ChangeOverDeviceSettingsCustomAttributesProvider, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295590886)
            
            static $h = 623590;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295590886),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 623590,
      "h": 4295590886,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295590886)
  ],
  "h": 623590
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(623590)
        
        

        //--TRIMMABLE-BOUNDARY-START(2393062)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverStateCustomAttributesProvider`, ($self) => class ChangeOverStateCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297360358)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297360358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297360358)
            
            static $h = 2393062;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297360358),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2393062,
      "h": 4297360358,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297360358)
  ],
  "h": 2393062
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverStateCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverStateCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2393062)
        
        

        //--TRIMMABLE-BOUNDARY-START(689126)
        $asm.$cls(`$gKEB.LCIDS.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295656422)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295656422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295656422)
            
            static $h = 689126;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295656422),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 689126,
      "h": 4295656422,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295656422)
  ],
  "h": 689126
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(689126)
        
        

        //--TRIMMABLE-BOUNDARY-START(164838)
        $asm.$cls(`$gKEB.LCIDS._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295132134)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295132134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$gKEB.LCIDS.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295132134)
            
            static $h = 164838;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295132134),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 164838,
      "h": 4295132134,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295132134)
  ],
  "h": 164838
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(164838)
        
        

        //--TRIMMABLE-BOUNDARY-START(1344486)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverDeviceScopeModelCustomAttributesProvider`, ($self) => class ChangeOverDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296311782)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296311782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296311782)
            
            static $h = 1344486;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296311782),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1344486,
      "h": 4296311782,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296311782)
  ],
  "h": 1344486
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1344486)
        
        

        //--TRIMMABLE-BOUNDARY-START(2130918)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverServiceModelCustomAttributesProvider`, ($self) => class ChangeOverServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297098214)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297098214);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297098214)
            
            static $h = 2130918;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297098214),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2130918,
      "h": 4297098214,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297098214)
  ],
  "h": 2130918
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2130918)
        
        

        //--TRIMMABLE-BOUNDARY-START(4096998)
        $asm.$cls(`$gKEB.LCIDS.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4299064294)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299064294);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$gKEB.LCIDSM.ChangeOverDeviceModelTypeDescriptorBuilder.Register();
                $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$gKEB.LCIDSM.ChangeOverDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$gKEB.LCIDSM.ChangeOverServiceModelTypeDescriptorBuilder.Register();
                $.$gKEB.LCIDSPC.ChangeOverCountDownCommandModelTypeDescriptorBuilder.Register();
                $.$gKEB.LCIDSPC.ChangeOverKeyCommandModelTypeDescriptorBuilder.Register();
                $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$gKEB.LCIDSS$1.ChangeOverDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4299064294)
            
            static $h = 4096998;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299064294),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 4096998,
      "h": 4299064294,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4299064294)
  ],
  "h": 4096998
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4096998)
        
        

        //--TRIMMABLE-BOUNDARY-START(2720742)
        $asm.$cls(`$gKEB.LCIDSPC.ChangeOverCountDownCommandModelCustomAttributesProvider`, ($self) => class ChangeOverCountDownCommandModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297688038)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297688038);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$tKtD.LCIDSC.SerialBridgeTargetCommandModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297688038)
            
            static $h = 2720742;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297688038),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2720742,
      "h": 4297688038,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297688038)
  ],
  "h": 2720742
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverCountDownCommandModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Protocol${separator}Commands${separator}ChangeOverCountDownCommandModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2720742)
        
        

        //--TRIMMABLE-BOUNDARY-START(3638246)
        $asm.$cls(`$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class ChangeOverDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298605542)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298605542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider$$($.$gKEB.LCIDSM.ChangeOverKeyControl).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298605542)
            
            static $h = 3638246;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298605542),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3638246,
      "h": 4298605542,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298605542)
  ],
  "h": 3638246
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Settings${separator}ChangeOverDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3638246)
        
        

        //--TRIMMABLE-BOUNDARY-START(1737702)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class ChangeOverDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591672294)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591672294);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $hshYEc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1737702,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591672294)
            
            //--TRIMMABLE-BOUNDARY-START(4296704998)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296704998);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296704998)
            
            //--TRIMMABLE-BOUNDARY-START(4296704998)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296704998)
            
            static $h = 1737702;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591672294),
    {
      "r": 65537,
      "n": "Register",
      "d": 1737702,
      "h": 8591672294,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591672294)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296704998),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1737702,
      "h": 4296704998,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296704998)
  ],
  "h": 1737702
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1737702)
        
        

        //--TRIMMABLE-BOUNDARY-START(3245030)
        $asm.$cls(`$gKEB.LCIDSPC.ChangeOverKeyCommandModelTypeDescriptorBuilder`, ($self) => class ChangeOverKeyCommandModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593179622)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593179622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$gKEB.LCIDSPC.ChangeOverKeyCommandModelTypeDescriptor()
                        const $t1 = $.$gKEB.LCIDSPC.ChangeOverKeyCommandModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverKeyCommandModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $mMtNqk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3245030,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$gKEB.LCIDSPC.ChangeOverKeyCommandModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593179622)
            
            //--TRIMMABLE-BOUNDARY-START(4298212326)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298212326);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298212326)
            
            //--TRIMMABLE-BOUNDARY-START(4298212326)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298212326)
            
            static $h = 3245030;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593179622),
    {
      "r": 65537,
      "n": "Register",
      "d": 3245030,
      "h": 8593179622,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593179622)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298212326),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3245030,
      "h": 4298212326,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298212326)
  ],
  "h": 3245030
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverKeyCommandModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Protocol${separator}Commands${separator}ChangeOverKeyCommandModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3245030)
        
        

        //--TRIMMABLE-BOUNDARY-START(2261990)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverServiceModelTypeDescriptorBuilder`, ($self) => class ChangeOverServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592196582)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592196582);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$gKEB.LCIDSM.ChangeOverServiceModelTypeDescriptor()
                        const $t1 = $.$gKEB.LCIDSM.ChangeOverServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $JgIqKb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2261990,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$gKEB.LCIDSM.ChangeOverServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592196582)
            
            //--TRIMMABLE-BOUNDARY-START(4297229286)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297229286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297229286)
            
            //--TRIMMABLE-BOUNDARY-START(4297229286)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297229286)
            
            static $h = 2261990;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592196582),
    {
      "r": 65537,
      "n": "Register",
      "d": 2261990,
      "h": 8592196582,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592196582)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297229286),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2261990,
      "h": 4297229286,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297229286)
  ],
  "h": 2261990
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2261990)
        
        

        //--TRIMMABLE-BOUNDARY-START(4031462)
        $asm.$cls(`$gKEB.LCIDSS$1.ChangeOverDeviceSettingsTypeDescriptorBuilder`, ($self) => class ChangeOverDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593966054)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593966054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$gKEB.LCIDSS$1.ChangeOverDeviceSettingsTypeDescriptor()
                        const $t1 = $.$gKEB.LCIDSS$1.ChangeOverDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $HmdCYg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4031462,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$gKEB.LCIDSS$1.ChangeOverDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593966054)
            
            //--TRIMMABLE-BOUNDARY-START(4298998758)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298998758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298998758)
            
            //--TRIMMABLE-BOUNDARY-START(4298998758)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298998758)
            
            static $h = 4031462;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593966054),
    {
      "r": 65537,
      "n": "Register",
      "d": 4031462,
      "h": 8593966054,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593966054)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298998758),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4031462,
      "h": 4298998758,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298998758)
  ],
  "h": 4031462
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Settings${separator}ChangeOverDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4031462)
        
        

        //--TRIMMABLE-BOUNDARY-START(1606630)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverDeviceSendDataModelCustomAttributesProvider`, ($self) => class ChangeOverDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296573926)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296573926);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296573926)
            
            static $h = 1606630;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296573926),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1606630,
      "h": 4296573926,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296573926)
  ],
  "h": 1606630
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1606630)
        
        

        //--TRIMMABLE-BOUNDARY-START(3113958)
        $asm.$cls(`$gKEB.LCIDSPC.ChangeOverKeyCommandModelCustomAttributesProvider`, ($self) => class ChangeOverKeyCommandModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298081254)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298081254);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$tKtD.LCIDSC.SerialBridgeTargetCommandModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298081254)
            
            static $h = 3113958;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298081254),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3113958,
      "h": 4298081254,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298081254)
  ],
  "h": 3113958
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverKeyCommandModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Protocol${separator}Commands${separator}ChangeOverKeyCommandModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3113958)
        
        

        //--TRIMMABLE-BOUNDARY-START(2851814)
        $asm.$cls(`$gKEB.LCIDSPC.ChangeOverCountDownCommandModelTypeDescriptorBuilder`, ($self) => class ChangeOverCountDownCommandModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592786406)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592786406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$gKEB.LCIDSPC.ChangeOverCountDownCommandModelTypeDescriptor()
                        const $t1 = $.$gKEB.LCIDSPC.ChangeOverCountDownCommandModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverCountDownCommandModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $zjnYOe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2851814,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$gKEB.LCIDSPC.ChangeOverCountDownCommandModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592786406)
            
            //--TRIMMABLE-BOUNDARY-START(4297819110)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297819110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297819110)
            
            //--TRIMMABLE-BOUNDARY-START(4297819110)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297819110)
            
            static $h = 2851814;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592786406),
    {
      "r": 65537,
      "n": "Register",
      "d": 2851814,
      "h": 8592786406,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592786406)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297819110),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2851814,
      "h": 4297819110,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297819110)
  ],
  "h": 2851814
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverCountDownCommandModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Protocol${separator}Commands${separator}ChangeOverCountDownCommandModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2851814)
        
        

        //--TRIMMABLE-BOUNDARY-START(1475558)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverDeviceScopeModelTypeDescriptorBuilder`, ($self) => class ChangeOverDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591410150)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591410150);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$gKEB.LCIDSM.ChangeOverDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$gKEB.LCIDSM.ChangeOverDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $gUrrHe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1475558,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$gKEB.LCIDSM.ChangeOverDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591410150)
            
            //--TRIMMABLE-BOUNDARY-START(4296442854)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296442854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296442854)
            
            //--TRIMMABLE-BOUNDARY-START(4296442854)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296442854)
            
            static $h = 1475558;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591410150),
    {
      "r": 65537,
      "n": "Register",
      "d": 1475558,
      "h": 8591410150,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591410150)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296442854),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1475558,
      "h": 4296442854,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296442854)
  ],
  "h": 1475558
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1475558)
        
        

        //--TRIMMABLE-BOUNDARY-START(1213414)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class ChangeOverDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591148006)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591148006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $BISbQh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1213414,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591148006)
            
            //--TRIMMABLE-BOUNDARY-START(4296180710)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296180710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296180710)
            
            //--TRIMMABLE-BOUNDARY-START(4296180710)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296180710)
            
            static $h = 1213414;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591148006),
    {
      "r": 65537,
      "n": "Register",
      "d": 1213414,
      "h": 8591148006,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591148006)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296180710),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1213414,
      "h": 4296180710,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296180710)
  ],
  "h": 1213414
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1213414)
        
        

        //--TRIMMABLE-BOUNDARY-START(3769318)
        $asm.$cls(`$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class ChangeOverDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593703910)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593703910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $SNvQUi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3769318,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593703910)
            
            //--TRIMMABLE-BOUNDARY-START(4298736614)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298736614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298736614)
            
            //--TRIMMABLE-BOUNDARY-START(4298736614)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298736614)
            
            static $h = 3769318;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593703910),
    {
      "r": 65537,
      "n": "Register",
      "d": 3769318,
      "h": 8593703910,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593703910)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298736614),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3769318,
      "h": 4298736614,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298736614)
  ],
  "h": 3769318
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Settings${separator}ChangeOverDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3769318)
        
        

        //--TRIMMABLE-BOUNDARY-START(951270)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverDeviceModelTypeDescriptorBuilder`, ($self) => class ChangeOverDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590885862)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590885862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$gKEB.LCIDSM.ChangeOverDeviceModelTypeDescriptor()
                        const $t1 = $.$gKEB.LCIDSM.ChangeOverDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $jcDZyg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":951270,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$gKEB.LCIDSM.ChangeOverDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590885862)
            
            //--TRIMMABLE-BOUNDARY-START(4295918566)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295918566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295918566)
            
            //--TRIMMABLE-BOUNDARY-START(4295918566)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295918566)
            
            static $h = 951270;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590885862),
    {
      "r": 65537,
      "n": "Register",
      "d": 951270,
      "h": 8590885862,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590885862)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295918566),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 951270,
      "h": 4295918566,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295918566)
  ],
  "h": 951270
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(951270)
        
        

        //--TRIMMABLE-BOUNDARY-START(558054)
        $asm.$cls(`$gKEB.LCIDS.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180427238)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180427238)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295525350)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295525350);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295525350)
            
            //--TRIMMABLE-BOUNDARY-START(4295525350)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295525350)
            
            static $h = 558054;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180427238),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885459942,
        "f": 50331649
      },
      "n": "Paths",
      "d": 558054,
      "h": 17180427238,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180427238)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295525350),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 558054,
      "h": 4295525350,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295525350)
  ],
  "h": 558054
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(558054)
        
        

        //--TRIMMABLE-BOUNDARY-START(2524134)
        $asm.$cls(`$gKEB.LCIDS.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17182393318)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$gKEB.LCIDSV.ChangeOverDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$gKEB.LCIDSV.ChangeOverDetails().$ctor$4();
                    }, $EBijwi ??= {"r":2752627,"n":"","d":2524134,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17182393318)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4297491430)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297491430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297491430)
            
            //--TRIMMABLE-BOUNDARY-START(4297491430)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297491430)
            
            static $h = 2524134;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182393318),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887426022,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 2524134,
      "h": 17182393318,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182393318)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297491430),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2524134,
      "h": 4297491430,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297491430)
  ],
  "h": 2524134
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2524134)
        
        

        //--TRIMMABLE-BOUNDARY-START(3310566)
        $asm.$cls(`$gKEB.LCIDS.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593245158)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593245158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$gKEB.LCIDS.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$gKEB.LCIDS.ChangeOverDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$gKEB.LCIDS.ChangeOverDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$gKEB.LCIDS.ChangeOverDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$gKEB.LCIDS.ChangeOverDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$gKEB.LCIDS.ChangeOverDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$gKEB.LCIDS.ChangeOverDeviceFamily, x);
                }, $ldAmad ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":3310566,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$gKEB.LCIDS.ChangeOverDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$gKEB.LCIDS.ChangeOverDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $uvZiNj ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":3310566,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$gKEB.LCIDS.ChangeOverDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$gKEB.LCIDS.ChangeOverDeviceFamily, x);
                }, $TxWcUd ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$gKEB.LCIDS.ChangeOverDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":3310566,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$gKEB.LCIDS.ChangeOverDevice, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$gKEB.LCIDS.ChangeOverDevice, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$gKEB.LCIDS.ChangeOverDevice, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$gKEB.LCIDS.ChangeOverDevice), $.$gKEB.LCIDSPC.ChangeOverDeviceCommands$$($.$gKEB.LCIDS.ChangeOverDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$gKEB.LCIDS.ChangeOverDevice), $.$gKEB.LCIDSV.ChangeOverViewRenderer, services);
                $.$fPer.LCFCD.DataConverter.Register($.$gKEB.LCIDSM.ChangeOverKeyControl, $.$typeArray($.$$.S.Byte), new ($.$$.S.Func$$$($.$gKEB.LCIDSM.ChangeOverKeyControl, $.$typeArray($.$$.S.Byte)))().$ctor(this,  (/**/ key) =>
                {
                    return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [170, 1, $.$cast(key, $.$$.S.Byte), 0, $.$cast((((((256 - 1) | 0) - $.$cast(key, $.$$.S.Byte)) | 0)), $.$$.S.Byte)], [-1], null);
                }, $ZZwWYi ??= {"r":$.$typeArray($.$$.S.Byte).$h,"p":[{"n":"key","p":1803238}],"n":"","d":3310566,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$typeArray($.$$.S.Byte), $.$gKEB.LCIDSM.ChangeOverKeyControl))().$ctor(this,  (/*b*/ b) =>
                {
                    return b.length > 2 ? $.$cast($.$$.System.Array.$ReadT1.call(b, 2), $.$gKEB.LCIDSM.ChangeOverKeyControl) : 0/*ChangeOverKeyControl.None*/;
                }, $XKWfni ??= {"r":1803238,"p":[{"n":"b","p":$.$typeArray($.$$.S.Byte).$h}],"n":"","d":3310566,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8593245158)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$gKEB.LCIDS.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298277862)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298277862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298277862)
            
            //--TRIMMABLE-BOUNDARY-START(4298277862)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298277862)
            
            static $h = 3310566;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593245158),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3310566,
      "h": 8593245158,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593245158)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298277862),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3310566,
      "h": 4298277862,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298277862)
  ],
  "h": 3310566
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3310566)
        
        

        //--TRIMMABLE-BOUNDARY-START(4424678)
        $asm.$cls(`$gKEB.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299391974)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299391974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299391974)
            
            //--TRIMMABLE-BOUNDARY-START(4299391974)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299391974)
            
            static $h = 4424678;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299391974),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4424678,
      "h": 4299391974,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299391974)
  ],
  "h": 4424678,
  "a": [
    {
      "t": 4359142,
      "c": 4299326438
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4424678)
        
        

        //--TRIMMABLE-BOUNDARY-START(4359142)
        $asm.$cls(`$gKEB.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299326438)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299326438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299326438)
            
            //--TRIMMABLE-BOUNDARY-START(4299326438)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299326438)
            
            static $h = 4359142;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299326438),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4359142,
      "h": 4299326438,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299326438)
  ],
  "h": 4359142
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4359142)
        
        

        //--TRIMMABLE-BOUNDARY-START(2458598)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverStatus`, ($self) => class ChangeOverStatus extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(94491739110)
            /*bool*/ GenValidating = false;
            //--TRIMMABLE-BOUNDARY-END(94491739110)
            
            //--TRIMMABLE-BOUNDARY-START(219045790694)
            /*bool*/ GridValidating = false;
            //--TRIMMABLE-BOUNDARY-END(219045790694)
            
            //--TRIMMABLE-BOUNDARY-START(90196771814)
            /*bool*/ GenValidated = false;
            //--TRIMMABLE-BOUNDARY-END(90196771814)
            
            //--TRIMMABLE-BOUNDARY-START(214750823398)
            /*bool*/ GridValidated = false;
            //--TRIMMABLE-BOUNDARY-END(214750823398)
            
            //--TRIMMABLE-BOUNDARY-START(68721935334)
            /*bool*/ CanDoAuto = false;
            //--TRIMMABLE-BOUNDARY-END(68721935334)
            
            //--TRIMMABLE-BOUNDARY-START(73016902630)
            /*ChangeOverPhase*/ CurrentPhase = 0;
            //--TRIMMABLE-BOUNDARY-END(73016902630)
            
            //--TRIMMABLE-BOUNDARY-START(85901804518)
            /*int*/ GenStartAttempt = 0;
            //--TRIMMABLE-BOUNDARY-END(85901804518)
            
            //--TRIMMABLE-BOUNDARY-START(55837033446)
            /*int*/ AutoShutdown = 0;
            //--TRIMMABLE-BOUNDARY-END(55837033446)
            
            //--TRIMMABLE-BOUNDARY-START(81606837222)
            /*ChangeOverState*/ GeneratorState = 0;
            //--TRIMMABLE-BOUNDARY-END(81606837222)
            
            //--TRIMMABLE-BOUNDARY-START(210455856102)
            /*int*/ Grid = 0;
            //--TRIMMABLE-BOUNDARY-END(210455856102)
            
            //--TRIMMABLE-BOUNDARY-START(77311869926)
            /*int*/ Generator = 0;
            //--TRIMMABLE-BOUNDARY-END(77311869926)
            
            //--TRIMMABLE-BOUNDARY-START(60132000742)
            /*int */ get AutoShutdownHour()
            {
                return $.trunc(this.AutoShutdown / 60);
            }
            //--TRIMMABLE-BOUNDARY-END(60132000742)
            
            //--TRIMMABLE-BOUNDARY-START(64426968038)
            /*int */ get AutoShutdownMinutes()
            {
                return this.AutoShutdown % 60;
            }
            //--TRIMMABLE-BOUNDARY-END(64426968038)
            
            //--TRIMMABLE-BOUNDARY-START(223340757990)
            /*void */ PackTo(/*PacketBuilder*/ packet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340757990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(223340757990)
            
            //--TRIMMABLE-BOUNDARY-START(322125005798)
            /*void */ UnPackFrom(/*PacketBuilder*/ packet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322125005798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                packet.GetByte(-1);
                /*int*/ let flags = packet.GetByte(-1);
                this.GenValidating = (flags & (1 << 0)) !== 0;
                this.GridValidating = (flags & (1 << 1)) !== 0;
                this.GenValidated = (flags & (1 << 2)) !== 0;
                this.GridValidated = (flags & (1 << 3)) !== 0;
                this.CanDoAuto = (flags & (1 << 4)) !== 0;
                this.CurrentPhase = $.$cast(((flags & (3 << 4)) >> 4), $.$gKEB.LCIDSM.ChangeOverPhase);
                this.GenStartAttempt = packet.GetByte(-1);
                this.AutoShutdown = packet.GetWord(-1, 0);
                this.GeneratorState = $.$cast(packet.GetByte(-1), $.$gKEB.LCIDSM.ChangeOverState);
                this.Grid = packet.GetWord(-1, 0);
                this.Generator = packet.GetWord(-1, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(322125005798)
            
            //--TRIMMABLE-BOUNDARY-START(4315515222)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IPacketBuilder.PackTo(LivingThing.Core.Frameworks.Common.Data.PacketBuilder)
            LCFCD$IPacketBuilder$PackTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4315515222);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PackTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4315515222)
            
            //--TRIMMABLE-BOUNDARY-START(8610482518)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IPacketBuilder.UnPackFrom(LivingThing.Core.Frameworks.Common.Data.PacketBuilder)
            LCFCD$IPacketBuilder$UnPackFrom()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8610482518);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UnPackFrom(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8610482518)
            
            //--TRIMMABLE-BOUNDARY-START(51542066150)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542066150);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51542066150)
            
            //--TRIMMABLE-BOUNDARY-START(51542066150)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(51542066150)
            
            static $h = 2458598;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94491739110),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180391085030,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292060234726,
        "f": 83886081
      },
      "n": "GenValidating",
      "d": 2458598,
      "h": 94491739110,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94491739110),
//--TRIMMABLE-BOUNDARY-START(219045790694),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206160888806,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317830038502,
        "f": 83886081
      },
      "n": "GridValidating",
      "d": 2458598,
      "h": 219045790694,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219045790694),
//--TRIMMABLE-BOUNDARY-START(90196771814),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171801150438,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283470300134,
        "f": 83886081
      },
      "n": "GenValidated",
      "d": 2458598,
      "h": 90196771814,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196771814),
//--TRIMMABLE-BOUNDARY-START(214750823398),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197570954214,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309240103910,
        "f": 83886081
      },
      "n": "GridValidated",
      "d": 2458598,
      "h": 214750823398,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214750823398),
//--TRIMMABLE-BOUNDARY-START(68721935334),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128851477478,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240520627174,
        "f": 83886081
      },
      "n": "CanDoAuto",
      "d": 2458598,
      "h": 68721935334,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721935334),
//--TRIMMABLE-BOUNDARY-START(73016902630),
    {
      "p": 1934310,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137441412070,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249110561766,
        "f": 83886081
      },
      "n": "CurrentPhase",
      "d": 2458598,
      "h": 73016902630,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016902630),
//--TRIMMABLE-BOUNDARY-START(85901804518),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163211215846,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274880365542,
        "f": 83886081
      },
      "n": "GenStartAttempt",
      "d": 2458598,
      "h": 85901804518,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85901804518),
//--TRIMMABLE-BOUNDARY-START(55837033446),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081673702,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231930692582,
        "f": 83886081
      },
      "n": "AutoShutdown",
      "d": 2458598,
      "h": 55837033446,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55837033446),
//--TRIMMABLE-BOUNDARY-START(81606837222),
    {
      "p": 2327526,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154621281254,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266290430950,
        "f": 83886081
      },
      "n": "GeneratorState",
      "d": 2458598,
      "h": 81606837222,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606837222),
//--TRIMMABLE-BOUNDARY-START(210455856102),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188981019622,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300650169318,
        "f": 83886081
      },
      "n": "Grid",
      "d": 2458598,
      "h": 210455856102,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "Unit=V",
                "Icon=CoatRack"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210455856102),
//--TRIMMABLE-BOUNDARY-START(77311869926),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146031346662,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257700496358,
        "f": 83886081
      },
      "n": "Generator",
      "d": 2458598,
      "h": 77311869926,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "Unit=V",
                "Icon=Engine"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77311869926),
//--TRIMMABLE-BOUNDARY-START(60132000742),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671608294,
        "f": 50331649
      },
      "n": "AutoShutdownHour",
      "d": 2458598,
      "h": 60132000742,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60132000742),
//--TRIMMABLE-BOUNDARY-START(64426968038),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120261542886,
        "f": 50331649
      },
      "n": "AutoShutdownMinutes",
      "d": 2458598,
      "h": 64426968038,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426968038)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(223340757990),
    {
      "r": 65537,
      "p": [
        {
          "n": "packet",
          "p": 31164758
        }
      ],
      "n": "PackTo",
      "d": 2458598,
      "h": 223340757990,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(223340757990),
//--TRIMMABLE-BOUNDARY-START(322125005798),
    {
      "r": 65537,
      "p": [
        {
          "n": "packet",
          "p": 31164758
        }
      ],
      "n": "UnPackFrom",
      "d": 2458598,
      "h": 322125005798,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(322125005798)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51542066150),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2458598,
      "h": 51542066150,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51542066150)
  ],
  "h": 2458598
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverStatus`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverStatus`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2458598)
        
        

        //--TRIMMABLE-BOUNDARY-START(1803238)
        $asm.$str(`$gKEB.LCIDSM.ChangeOverKeyControl`, ($self) => class ChangeOverKeyControl extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Start = 1;
            static Stop = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1803238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Start": 1n,
                    "Stop": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296770534)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296770534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296770534)
            
            //--TRIMMABLE-BOUNDARY-START(4296770534)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296770534)
            
            static $h = 1803238;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591737830),
    {
      "t": 1803238,
      "n": "None",
      "d": 1803238,
      "h": 8591737830,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591737830),
//--TRIMMABLE-BOUNDARY-START(12886705126),
    {
      "t": 1803238,
      "n": "Start",
      "d": 1803238,
      "h": 12886705126,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886705126),
//--TRIMMABLE-BOUNDARY-START(17181672422),
    {
      "t": 1803238,
      "n": "Stop",
      "d": 1803238,
      "h": 17181672422,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181672422)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296770534),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1803238,
      "h": 4296770534,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296770534)
  ],
  "h": 1803238
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverKeyControl`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverKeyControl`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1803238)
        
        

        //--TRIMMABLE-BOUNDARY-START(1934310)
        $asm.$str(`$gKEB.LCIDSM.ChangeOverPhase`, ($self) => class ChangeOverPhase extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static None = 0;
            static Grid = 1;
            static Generator = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1934310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Grid": 1n,
                    "Generator": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296901606)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296901606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296901606)
            
            //--TRIMMABLE-BOUNDARY-START(4296901606)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296901606)
            
            static $h = 1934310;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181803494),
    {
      "t": 1934310,
      "n": "None",
      "d": 1934310,
      "h": 17181803494,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181803494),
//--TRIMMABLE-BOUNDARY-START(12886836198),
    {
      "t": 1934310,
      "n": "Grid",
      "d": 1934310,
      "h": 12886836198,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886836198),
//--TRIMMABLE-BOUNDARY-START(8591868902),
    {
      "t": 1934310,
      "n": "Generator",
      "d": 1934310,
      "h": 8591868902,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591868902)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296901606),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1934310,
      "h": 4296901606,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296901606)
  ],
  "h": 1934310
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverPhase`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverPhase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1934310)
        
        

        //--TRIMMABLE-BOUNDARY-START(2327526)
        $asm.$str(`$gKEB.LCIDSM.ChangeOverState`, ($self) => class ChangeOverState extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static OFF = 0;
            static STARTING = 1;
            static RESTARTING = 2;
            static RUNNING = 3;
            static IDLE = 4;
            static STOPPING = 5;
            static STOPPED = 6;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2327526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "OFF": 0n,
                    "STARTING": 1n,
                    "RESTARTING": 2n,
                    "RUNNING": 3n,
                    "IDLE": 4n,
                    "STOPPING": 5n,
                    "STOPPED": 6n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297294822)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297294822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297294822)
            
            //--TRIMMABLE-BOUNDARY-START(4297294822)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297294822)
            
            static $h = 2327526;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887229414),
    {
      "t": 2327526,
      "n": "OFF",
      "d": 2327526,
      "h": 12887229414,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887229414),
//--TRIMMABLE-BOUNDARY-START(25772131302),
    {
      "t": 2327526,
      "n": "STARTING",
      "d": 2327526,
      "h": 25772131302,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772131302),
//--TRIMMABLE-BOUNDARY-START(17182196710),
    {
      "t": 2327526,
      "n": "RESTARTING",
      "d": 2327526,
      "h": 17182196710,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182196710),
//--TRIMMABLE-BOUNDARY-START(21477164006),
    {
      "t": 2327526,
      "n": "RUNNING",
      "d": 2327526,
      "h": 21477164006,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477164006),
//--TRIMMABLE-BOUNDARY-START(8592262118),
    {
      "t": 2327526,
      "n": "IDLE",
      "d": 2327526,
      "h": 8592262118,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592262118),
//--TRIMMABLE-BOUNDARY-START(34362065894),
    {
      "t": 2327526,
      "n": "STOPPING",
      "d": 2327526,
      "h": 34362065894,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34362065894),
//--TRIMMABLE-BOUNDARY-START(30067098598),
    {
      "t": 2327526,
      "n": "STOPPED",
      "d": 2327526,
      "h": 30067098598,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30067098598)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297294822),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2327526,
      "h": 4297294822,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297294822)
  ],
  "h": 2327526
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2327526)
        
        

        //--TRIMMABLE-BOUNDARY-START(99302)
        $asm.$cls(`$gKEB.LCIDS._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590033894)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590033894);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590033894)
            
            //--TRIMMABLE-BOUNDARY-START(4295066598)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295066598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295066598)
            
            //--TRIMMABLE-BOUNDARY-START(4295066598)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295066598)
            
            static $h = 99302;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590033894),
    {
      "r": 65537,
      "n": "Execute",
      "d": 99302,
      "h": 8590033894,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590033894)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295066598),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 99302,
      "h": 4295066598,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295066598)
  ],
  "h": 99302
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(99302)
        
        

        //--TRIMMABLE-BOUNDARY-START(2655206)
        $asm.$cls(`$gKEB.LCIDSPC.ChangeOverCountDownCommandModel`, ($self) => class ChangeOverCountDownCommandModel extends $.$tKtD.LCIDSC.SerialBridgeTargetCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(12887557094)
            /*int*/ count = 0;
            //--TRIMMABLE-BOUNDARY-END(12887557094)
            
            //--TRIMMABLE-BOUNDARY-START(4297622502)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297622502);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297622502)
            
            //--TRIMMABLE-BOUNDARY-START(8592589798)
            $ctor$4(/*int*/ count)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592589798);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.count = count;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592589798)
            
            //--TRIMMABLE-BOUNDARY-START(17182524390)
            /*void */ PackTo(/*PacketBuilder*/ packet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182524390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.PackTo(packet);
                packet.Push$1(170);
                packet.Push$1(2);
                packet.Push$11($.$cast(this.count, $.$$.S.UInt16), 0);
                packet.Push$1($.$cast((((((((256 - 2) | 0) - ($.$cast(this.count, $.$$.S.Byte))) | 0) - ($.$cast((this.count >> 8), $.$$.S.Byte))) | 0)), $.$$.S.Byte));
            }
            //--TRIMMABLE-BOUNDARY-END(17182524390)
            
            //--TRIMMABLE-BOUNDARY-START(4297622502)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297622502)
            
            static $h = 2655206;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$tKtD.LCIDSC.SerialBridgeTargetCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182524390),
    {
      "r": 65537,
      "p": [
        {
          "n": "packet",
          "p": 31164758
        }
      ],
      "n": "PackTo",
      "d": 2655206,
      "h": 17182524390,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17182524390)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887557094),
    {
      "t": 655361,
      "n": "count",
      "d": 2655206,
      "h": 12887557094,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887557094)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297622502),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2655206,
      "h": 4297622502,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297622502),
//--TRIMMABLE-BOUNDARY-START(8592589798),
    {
      "p": [
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2655206,
      "h": 8592589798,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592589798)
  ],
  "h": 2655206
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverCountDownCommandModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Protocol${separator}Commands${separator}ChangeOverCountDownCommandModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2655206)
        
        

        //--TRIMMABLE-BOUNDARY-START(3048422)
        $asm.$cls(`$gKEB.LCIDSPC.ChangeOverKeyCommandModel`, ($self) => class ChangeOverKeyCommandModel extends $.$tKtD.LCIDSC.SerialBridgeTargetCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(17182917606)
            /*ChangeOverKeyControl*/ keys$1 = 0;
            //--TRIMMABLE-BOUNDARY-END(17182917606)
            
            //--TRIMMABLE-BOUNDARY-START(4298015718)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298015718);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298015718)
            
            //--TRIMMABLE-BOUNDARY-START(8592983014)
            $ctor$4(/*ChangeOverKeyControl*/ keys)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592983014);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.keys$1 = keys;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592983014)
            
            //--TRIMMABLE-BOUNDARY-START(21477884902)
            static /*void */ PackKeyCommand(/*ChangeOverKeyControl*/ keys, /*PacketBuilder*/ packet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477884902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                packet.Push$1(170);
                packet.Push$1(1);
                /*byte*/ let ikey = $.$cast(keys, $.$$.S.Byte);
                packet.Push$1(ikey);
                packet.Push$1(0);
                packet.Push$1($.$cast((((((256 - 1) | 0) - ikey) | 0)), $.$$.S.Byte));
            }
            //--TRIMMABLE-BOUNDARY-END(21477884902)
            
            //--TRIMMABLE-BOUNDARY-START(12887950310)
            static /*ChangeOverKeyControl */ GetKeyFromCommand(/*byte[]*/ packet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887950310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast($.$$.System.Array.$ReadT1.call(packet, 2), $.$gKEB.LCIDSM.ChangeOverKeyControl);
            }
            //--TRIMMABLE-BOUNDARY-END(12887950310)
            
            //--TRIMMABLE-BOUNDARY-START(25772852198)
            /*void */ PackTo(/*PacketBuilder*/ packet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772852198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.PackTo(packet);
                $.$gKEB.LCIDSPC.ChangeOverKeyCommandModel.PackKeyCommand(this.keys$1, packet);
            }
            //--TRIMMABLE-BOUNDARY-END(25772852198)
            
            //--TRIMMABLE-BOUNDARY-START(4298015718)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298015718)
            
            static $h = 3048422;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$tKtD.LCIDSC.SerialBridgeTargetCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477884902),
    {
      "r": 65537,
      "p": [
        {
          "n": "keys",
          "p": 1803238
        },
        {
          "n": "packet",
          "p": 31164758
        }
      ],
      "n": "PackKeyCommand",
      "d": 3048422,
      "h": 21477884902,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477884902),
//--TRIMMABLE-BOUNDARY-START(12887950310),
    {
      "r": 1803238,
      "p": [
        {
          "n": "packet",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "GetKeyFromCommand",
      "d": 3048422,
      "h": 12887950310,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887950310),
//--TRIMMABLE-BOUNDARY-START(25772852198),
    {
      "r": 65537,
      "p": [
        {
          "n": "packet",
          "p": 31164758
        }
      ],
      "n": "PackTo",
      "d": 3048422,
      "h": 25772852198,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25772852198)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182917606),
    {
      "t": 1803238,
      "n": "keys",
      "o": "@$1",
      "d": 3048422,
      "h": 17182917606,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182917606)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298015718),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3048422,
      "h": 4298015718,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298015718),
//--TRIMMABLE-BOUNDARY-START(8592983014),
    {
      "p": [
        {
          "n": "keys",
          "p": 1803238
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3048422,
      "h": 8592983014,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592983014)
  ],
  "h": 3048422
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverKeyCommandModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Protocol${separator}Commands${separator}ChangeOverKeyCommandModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3048422)
        
        

        //--TRIMMABLE-BOUNDARY-START(1541094)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverDeviceSendDataModel`, ($self) => class ChangeOverDeviceSendDataModel extends $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296508390)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296508390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296508390)
            
            //--TRIMMABLE-BOUNDARY-START(4296508390)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296508390)
            
            static $h = 1541094;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296508390),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1541094,
      "h": 4296508390,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296508390)
  ],
  "h": 1541094
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1541094)
        
        

        //--TRIMMABLE-BOUNDARY-START(2917350)
        $asm.$cls(`$gKEB.LCIDSPC.ChangeOverDeviceCommands<>`, (TDevice) => $asm.$gt(`$gKEB.LCIDSPC.ChangeOverDeviceCommands<>`, [TDevice], ($self) => class ChangeOverDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12887819238)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12887819238)
            
            //--TRIMMABLE-BOUNDARY-START(17182786534)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182786534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$gKEB.LCIDSPC.ChangeOverDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17182786534)
            
            //--TRIMMABLE-BOUNDARY-START(8592851942)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592851942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592851942)
            
            //--TRIMMABLE-BOUNDARY-START(8592851942)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8592851942)
            
            //--TRIMMABLE-BOUNDARY-START(4297884646)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297884646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12887819238)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [new $.$gKEB.LCIDSPC.ChangeOverKeyCommand().$ctor$5(), new $.$gKEB.LCIDSPC.ChangeOverCountDownCommand().$ctor$6()], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12887819238)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297884646)
            
            static $H = 2917350;
            static $h = 2917350;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182786534),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17182786534,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17182786534)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887819238),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12887819238,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12887819238)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592851942),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8592851942,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592851942)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 2917350,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Protocol${separator}Commands${separator}ChangeOverDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2917350)
        
        

        //--TRIMMABLE-BOUNDARY-START(3179494)
        $asm.$cls(`$gKEB.LCIDSPC.ChangeOverKeyCommandModelTypeDescriptor`, ($self) => class ChangeOverKeyCommandModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSPC.ChangeOverKeyCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298146790)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298146790);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$gKEB.LCIDSPC.ChangeOverKeyCommandModelTypeDescriptor.GenerateProperties($.$gKEB.LCIDSPC.ChangeOverKeyCommandModel, this, factory);
                    }, $FVzFzc ??= {"r":65537,"n":"","d":3179494,"h":0,"f":17825794}), 0, "ChangeOverKeyCommandModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver\\Protocol_Commands_ChangeOverKeyCommandModel_LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverKeyCommandModelTypeDescriptorBuilder.g.cs", "ChangeOverKeyCommandModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298146790)
            
            //--TRIMMABLE-BOUNDARY-START(12888081382)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888081382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$tKtD.LCIDSC.SerialBridgeTargetCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888081382)
            
            //--TRIMMABLE-BOUNDARY-START(17183048678)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverKeyCommandModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183048678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Devices.SerialBridge.Commands.SerialBridgeTargetCommandModel?*/ let targetBase = _target;
                $.$tKtD.LCIDSC.SerialBridgeTargetCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$tKtD.LCIDSC.SerialBridgeTargetCommandModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183048678)
            
            //--TRIMMABLE-BOUNDARY-START(8593114086)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverKeyCommandModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593114086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$gKEB.LCIDSPC.ChangeOverKeyCommandModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$gKEB.LCIDSPC.ChangeOverKeyCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSPC.ChangeOverKeyCommandModel)))
                {
                    /*var*/ let result = $.$gKEB.LCIDSPC.ChangeOverKeyCommandModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSPC.ChangeOverKeyCommandModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$gKEB.LCIDSPC.ChangeOverKeyCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSPC.ChangeOverKeyCommandModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593114086)
            
            static $h = 3179494;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSPC.ChangeOverKeyCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888081382),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3179494,
      "h": 12888081382,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888081382),
//--TRIMMABLE-BOUNDARY-START(17183048678),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3048422,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3179494,
      "h": 17183048678,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183048678),
//--TRIMMABLE-BOUNDARY-START(8593114086),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3048422,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3179494,
      "h": 8593114086,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593114086)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298146790),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3179494,
      "h": 4298146790,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298146790)
  ],
  "h": 3179494
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$gKEB.LCIDSPC.ChangeOverKeyCommandModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverKeyCommandModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Protocol${separator}Commands${separator}ChangeOverKeyCommandModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3179494)
        
        

        //--TRIMMABLE-BOUNDARY-START(2786278)
        $asm.$cls(`$gKEB.LCIDSPC.ChangeOverCountDownCommandModelTypeDescriptor`, ($self) => class ChangeOverCountDownCommandModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSPC.ChangeOverCountDownCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297753574)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297753574);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$gKEB.LCIDSPC.ChangeOverCountDownCommandModelTypeDescriptor.GenerateProperties($.$gKEB.LCIDSPC.ChangeOverCountDownCommandModel, this, factory);
                    }, $Lakyad ??= {"r":65537,"n":"","d":2786278,"h":0,"f":17825794}), 0, "ChangeOverCountDownCommandModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver\\Protocol_Commands_ChangeOverCountDownCommandModel_LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverCountDownCommandModelTypeDescriptorBuilder.g.cs", "ChangeOverCountDownCommandModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297753574)
            
            //--TRIMMABLE-BOUNDARY-START(12887688166)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887688166);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$tKtD.LCIDSC.SerialBridgeTargetCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887688166)
            
            //--TRIMMABLE-BOUNDARY-START(17182655462)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverCountDownCommandModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182655462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Devices.SerialBridge.Commands.SerialBridgeTargetCommandModel?*/ let targetBase = _target;
                $.$tKtD.LCIDSC.SerialBridgeTargetCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$tKtD.LCIDSC.SerialBridgeTargetCommandModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182655462)
            
            //--TRIMMABLE-BOUNDARY-START(8592720870)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverCountDownCommandModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592720870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$gKEB.LCIDSPC.ChangeOverCountDownCommandModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$gKEB.LCIDSPC.ChangeOverCountDownCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSPC.ChangeOverCountDownCommandModel)))
                {
                    /*var*/ let result = $.$gKEB.LCIDSPC.ChangeOverCountDownCommandModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSPC.ChangeOverCountDownCommandModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$gKEB.LCIDSPC.ChangeOverCountDownCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSPC.ChangeOverCountDownCommandModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592720870)
            
            static $h = 2786278;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSPC.ChangeOverCountDownCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887688166),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2786278,
      "h": 12887688166,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887688166),
//--TRIMMABLE-BOUNDARY-START(17182655462),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2655206,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2786278,
      "h": 17182655462,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182655462),
//--TRIMMABLE-BOUNDARY-START(8592720870),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2655206,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2786278,
      "h": 8592720870,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592720870)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297753574),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2786278,
      "h": 4297753574,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297753574)
  ],
  "h": 2786278
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$gKEB.LCIDSPC.ChangeOverCountDownCommandModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverCountDownCommandModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Protocol${separator}Commands${separator}ChangeOverCountDownCommandModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2786278)
        
        

        //--TRIMMABLE-BOUNDARY-START(2982886)
        $asm.$cls(`$gKEB.LCIDSPC.ChangeOverKeyCommand`, ($self) => class ChangeOverKeyCommand extends $.$XBGm.LCICDiC.iSmartDeviceCommand$$($.$gKEB.LCIDSPC.ChangeOverKeyCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297950182)
            $ctor$5()
            {
                super.$ctor$4("Keys", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297950182);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297950182)
            
            //--TRIMMABLE-BOUNDARY-START(17182852070)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-switch"/*MaterialDesignIconNames.Switch*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17182852070)
            
            //--TRIMMABLE-BOUNDARY-START(4297950182)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4297950182)
            
            static $h = 2982886;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceCommand$$($.$gKEB.LCIDSPC.ChangeOverKeyCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182852070),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887884774,
        "f": 50364417
      },
      "n": "Icon",
      "d": 2982886,
      "h": 17182852070,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17182852070)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297950182),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2982886,
      "h": 4297950182,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297950182)
  ],
  "h": 2982886
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverKeyCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Protocol${separator}Commands${separator}ChangeOverKeyCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2982886)
        
        

        //--TRIMMABLE-BOUNDARY-START(2589670)
        $asm.$cls(`$gKEB.LCIDSPC.ChangeOverCountDownCommand`, ($self) => class ChangeOverCountDownCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$gKEB.LCIDSPC.ChangeOverCountDownCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297556966)
            $ctor$6()
            {
                super.$ctor$5("CountDown", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297556966);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297556966)
            
            //--TRIMMABLE-BOUNDARY-START(17182458854)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-counter"/*MaterialDesignIconNames.Counter*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17182458854)
            
            //--TRIMMABLE-BOUNDARY-START(4297556966)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4297556966)
            
            static $h = 2589670;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$gKEB.LCIDSPC.ChangeOverCountDownCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182458854),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887491558,
        "f": 50364417
      },
      "n": "Icon",
      "d": 2589670,
      "h": 17182458854,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17182458854)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297556966),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2589670,
      "h": 4297556966,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297556966)
  ],
  "h": 2589670
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Protocol.Commands.ChangeOverCountDownCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Protocol${separator}Commands${separator}ChangeOverCountDownCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2589670)
        
        

        //--TRIMMABLE-BOUNDARY-START(1672166)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverDeviceSendDataModelTypeDescriptor`, ($self) => class ChangeOverDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296639462)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296639462);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModelTypeDescriptor.GenerateProperties($.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, this, factory);
                    }, $LTpHYj ??= {"r":65537,"n":"","d":1672166,"h":0,"f":17825794}), 0, "ChangeOverDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver\\Models_ChangeOverDeviceSendDataModel_LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceSendDataModelTypeDescriptorBuilder.g.cs", "ChangeOverDeviceSendDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296639462)
            
            //--TRIMMABLE-BOUNDARY-START(12886574054)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886574054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886574054)
            
            //--TRIMMABLE-BOUNDARY-START(17181541350)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181541350);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceSendDataModel?*/ let targetBase = _target;
                $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181541350)
            
            //--TRIMMABLE-BOUNDARY-START(8591606758)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591606758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591606758)
            
            static $h = 1672166;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886574054),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1672166,
      "h": 12886574054,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886574054),
//--TRIMMABLE-BOUNDARY-START(17181541350),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1541094,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1672166,
      "h": 17181541350,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181541350),
//--TRIMMABLE-BOUNDARY-START(8591606758),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1541094,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1672166,
      "h": 8591606758,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591606758)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296639462),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1672166,
      "h": 4296639462,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296639462)
  ],
  "h": 1672166
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1672166)
        
        

        //--TRIMMABLE-BOUNDARY-START(1016806)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel`, ($self) => class ChangeOverDeviceReceivedDataModel extends $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$($.$gKEB.LCIDSM.ChangeOverStatus)
        {
            //--TRIMMABLE-BOUNDARY-START(4295984102)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295984102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295984102)
            
            //--TRIMMABLE-BOUNDARY-START(4295984102)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295984102)
            
            static $h = 1016806;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$($.$gKEB.LCIDSM.ChangeOverStatus); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295984102),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1016806,
      "h": 4295984102,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295984102)
  ],
  "h": 1016806
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1016806)
        
        

        //--TRIMMABLE-BOUNDARY-START(1147878)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModelTypeDescriptor`, ($self) => class ChangeOverDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296115174)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296115174);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, this, factory);
                    }, $AUHWtb ??= {"r":65537,"n":"","d":1147878,"h":0,"f":17825794}), 0, "ChangeOverDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver\\Models_ChangeOverDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "ChangeOverDeviceReceivedDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296115174)
            
            //--TRIMMABLE-BOUNDARY-START(12886049766)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886049766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverStatus).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886049766)
            
            //--TRIMMABLE-BOUNDARY-START(17181017062)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181017062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverStatus>?*/ let targetBase = _target;
                $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverStatus).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$($.$gKEB.LCIDSM.ChangeOverStatus)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181017062)
            
            //--TRIMMABLE-BOUNDARY-START(8591082470)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591082470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591082470)
            
            static $h = 1147878;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886049766),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1147878,
      "h": 12886049766,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886049766),
//--TRIMMABLE-BOUNDARY-START(17181017062),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1016806,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1147878,
      "h": 17181017062,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181017062),
//--TRIMMABLE-BOUNDARY-START(8591082470),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1016806,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1147878,
      "h": 8591082470,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591082470)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296115174),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1147878,
      "h": 4296115174,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296115174)
  ],
  "h": 1147878
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1147878)
        
        

        //--TRIMMABLE-BOUNDARY-START(230374)
        $asm.$cls(`$gKEB.LCIDS.ChangeOverDataConverter`, ($self) => class ChangeOverDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295197670)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295197670);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295197670)
            
            //--TRIMMABLE-BOUNDARY-START(4295197670)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295197670)
            
            static $h = 230374;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295197670),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 230374,
      "h": 4295197670,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295197670)
  ],
  "h": 230374
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.ChangeOverDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}ChangeOverDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(230374)
        
        

        $asm.$typeProxy("$gKEB.LCIDSM.ChangeOverServiceModel", "$gKEB.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverServiceModel");
        $asm.$typeProxy("$gKEB.LCIDSM.ChangeOverDeviceModel", "$gKEB.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceModel");
        $asm.$typeProxy("$gKEB.LCIDSS$1.ChangeOverDeviceSettings", "$gKEB.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceSettings");
        $asm.$typeProxy("$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings", "$gKEB.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceHardwareSettings");
        $asm.$typeProxy("$gKEB.LCIDSS.IChangeOverDeviceStatusHandler", "$gKEB.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverDeviceStatusHandler");
        $asm.$typeProxy("$gKEB.LCIDSS.IChangeOverDeviceHubClient", "$gKEB.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverDeviceHubClient");
        $asm.$typeProxy("$gKEB.LCIDSS.IChangeOverRemoteService", "$gKEB.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverRemoteService");
        //--TRIMMABLE-BOUNDARY-START(1278950)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverDeviceScopeModel`, ($self) => class ChangeOverDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296246246)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296246246);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296246246)
            
            //--TRIMMABLE-BOUNDARY-START(4296246246)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296246246)
            
            static $h = 1278950;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296246246),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1278950,
      "h": 4296246246,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296246246)
  ],
  "h": 1278950
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1278950)
        
        

        //--TRIMMABLE-BOUNDARY-START(754662)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverDeviceModel`, ($self) => class ChangeOverDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295721958)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295721958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295721958)
            
            //--TRIMMABLE-BOUNDARY-START(4295721958)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295721958)
            
            static $h = 754662;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295721958),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 754662,
      "h": 4295721958,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295721958)
  ],
  "h": 754662
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(754662)
        
        

        //--TRIMMABLE-BOUNDARY-START(2065382)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverServiceModel`, ($self) => class ChangeOverServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297032678)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297032678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297032678)
            
            //--TRIMMABLE-BOUNDARY-START(4297032678)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4297032678)
            
            static $h = 2065382;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297032678),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 2065382,
      "h": 4297032678,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297032678)
  ],
  "h": 2065382
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2065382)
        
        

        //--TRIMMABLE-BOUNDARY-START(3376102)
        $asm.$cls(`$gKEB.LCIDSS.IChangeOverDeviceHubClient`, ($self) => class IChangeOverDeviceHubClient
        {
            static $h = 3376102;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3376102
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Services${separator}IChangeOverDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3376102)
        
        

        //--TRIMMABLE-BOUNDARY-START(3834854)
        $asm.$cls(`$gKEB.LCIDSS$1.ChangeOverDeviceSettings`, ($self) => class ChangeOverDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $self, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4298802150)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298802150);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298802150)
            
            //--TRIMMABLE-BOUNDARY-START(4298802150)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4298802150)
            
            static $h = 3834854;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298802150),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3834854,
      "h": 4298802150,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298802150)
  ],
  "h": 3834854
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Settings${separator}ChangeOverDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3834854)
        
        

        //--TRIMMABLE-BOUNDARY-START(3507174)
        $asm.$cls(`$gKEB.LCIDSS.IChangeOverRemoteService`, ($self) => class IChangeOverRemoteService
        {
            static $h = 3507174;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3507174
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$gKEB.LCIDSM.ChangeOverServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$gKEB.LCIDSM.ChangeOverServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$gKEB.LCIDSM.ChangeOverServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$gKEB.LCIDSM.ChangeOverServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$gKEB.LCIDSM.ChangeOverServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$gKEB.LCIDSM.ChangeOverServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$gKEB.LCIDSM.ChangeOverServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$gKEB.LCIDSM.ChangeOverServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Services${separator}IChangeOverRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3507174)
        
        

        //--TRIMMABLE-BOUNDARY-START(3572710)
        $asm.$cls(`$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings`, ($self) => class ChangeOverDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).iSmartDeviceHardwareSettings$$($.$gKEB.LCIDSM.ChangeOverKeyControl)
        {
            //--TRIMMABLE-BOUNDARY-START(4298540006)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298540006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298540006)
            
            //--TRIMMABLE-BOUNDARY-START(4298540006)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298540006)
            
            static $h = 3572710;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).iSmartDeviceHardwareSettings$$($.$gKEB.LCIDSM.ChangeOverKeyControl); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298540006),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3572710,
      "h": 4298540006,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298540006)
  ],
  "h": 3572710
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Settings${separator}ChangeOverDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3572710)
        
        

        //--TRIMMABLE-BOUNDARY-START(3441638)
        $asm.$cls(`$gKEB.LCIDSS.IChangeOverDeviceStatusHandler`, ($self) => class IChangeOverDeviceStatusHandler
        {
            static $h = 3441638;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3441638
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Services${separator}IChangeOverDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3441638)
        
        

        //--TRIMMABLE-BOUNDARY-START(492518)
        $asm.$cls(`$gKEB.LCIDS.ChangeOverDeviceModelDefinition`, ($self) => class ChangeOverDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4295459814)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295459814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295459814)
            
            //--TRIMMABLE-BOUNDARY-START(4295459814)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295459814)
            
            static $h = 492518;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295459814),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 492518,
      "h": 4295459814,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295459814)
  ],
  "h": 492518
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.ChangeOverDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}ChangeOverDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(492518)
        
        

        //--TRIMMABLE-BOUNDARY-START(2196454)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverServiceModelTypeDescriptor`, ($self) => class ChangeOverServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297163750)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297163750);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$gKEB.LCIDSM.ChangeOverServiceModelTypeDescriptor.GenerateProperties($.$gKEB.LCIDSM.ChangeOverServiceModel, this, factory);
                    }, $ivnHjf ??= {"r":65537,"n":"","d":2196454,"h":0,"f":17825794}), 0, "ChangeOverServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver\\Models_ChangeOverServiceModel_LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverServiceModelTypeDescriptorBuilder.g.cs", "ChangeOverServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297163750)
            
            //--TRIMMABLE-BOUNDARY-START(12887098342)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887098342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887098342)
            
            //--TRIMMABLE-BOUNDARY-START(17182065638)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182065638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceSettings, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceSendDataModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverDeviceStatusHandler, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverDeviceHubClient, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182065638)
            
            //--TRIMMABLE-BOUNDARY-START(8592131046)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592131046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$gKEB.LCIDSM.ChangeOverServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$gKEB.LCIDSM.ChangeOverServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSM.ChangeOverServiceModel)))
                {
                    /*var*/ let result = $.$gKEB.LCIDSM.ChangeOverServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSM.ChangeOverServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$gKEB.LCIDSM.ChangeOverServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSM.ChangeOverServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592131046)
            
            static $h = 2196454;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887098342),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2196454,
      "h": 12887098342,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887098342),
//--TRIMMABLE-BOUNDARY-START(17182065638),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2065382,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2196454,
      "h": 17182065638,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182065638),
//--TRIMMABLE-BOUNDARY-START(8592131046),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2065382,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2196454,
      "h": 8592131046,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592131046)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297163750),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2196454,
      "h": 4297163750,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297163750)
  ],
  "h": 2196454
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2196454)
        
        

        //--TRIMMABLE-BOUNDARY-START(3965926)
        $asm.$cls(`$gKEB.LCIDSS$1.ChangeOverDeviceSettingsTypeDescriptor`, ($self) => class ChangeOverDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSS$1.ChangeOverDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298933222)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298933222);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$gKEB.LCIDSS$1.ChangeOverDeviceSettingsTypeDescriptor.GenerateProperties($.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, this, factory);
                    }, $ubQjkh ??= {"r":65537,"n":"","d":3965926,"h":0,"f":17825794}), 0, "ChangeOverDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver\\Settings_ChangeOverDeviceSettings_LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceSettingsTypeDescriptorBuilder.g.cs", "ChangeOverDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298933222)
            
            //--TRIMMABLE-BOUNDARY-START(12888867814)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888867814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888867814)
            
            //--TRIMMABLE-BOUNDARY-START(17183835110)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183835110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceSettings, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceSendDataModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverDeviceStatusHandler, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverDeviceHubClient, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).iSmartDeviceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183835110)
            
            //--TRIMMABLE-BOUNDARY-START(8593900518)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593900518);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings)))
                {
                    /*var*/ let result = $.$gKEB.LCIDSS$1.ChangeOverDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593900518)
            
            static $h = 3965926;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSS$1.ChangeOverDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888867814),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3965926,
      "h": 12888867814,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888867814),
//--TRIMMABLE-BOUNDARY-START(17183835110),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3834854,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3965926,
      "h": 17183835110,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183835110),
//--TRIMMABLE-BOUNDARY-START(8593900518),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3834854,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3965926,
      "h": 8593900518,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593900518)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298933222),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3965926,
      "h": 4298933222,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298933222)
  ],
  "h": 3965926
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$gKEB.LCIDSS$1.ChangeOverDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Settings${separator}ChangeOverDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3965926)
        
        

        //--TRIMMABLE-BOUNDARY-START(1410022)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverDeviceScopeModelTypeDescriptor`, ($self) => class ChangeOverDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296377318)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296377318);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$gKEB.LCIDSM.ChangeOverDeviceScopeModelTypeDescriptor.GenerateProperties($.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, this, factory);
                    }, $bUoNdc ??= {"r":65537,"n":"","d":1410022,"h":0,"f":17825794}), 0, "ChangeOverDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver\\Models_ChangeOverDeviceScopeModel_LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceScopeModelTypeDescriptorBuilder.g.cs", "ChangeOverDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296377318)
            
            //--TRIMMABLE-BOUNDARY-START(12886311910)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886311910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886311910)
            
            //--TRIMMABLE-BOUNDARY-START(17181279206)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181279206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceSettings, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceSendDataModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverDeviceStatusHandler, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverDeviceHubClient, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181279206)
            
            //--TRIMMABLE-BOUNDARY-START(8591344614)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591344614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel)))
                {
                    /*var*/ let result = $.$gKEB.LCIDSM.ChangeOverDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591344614)
            
            static $h = 1410022;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886311910),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1410022,
      "h": 12886311910,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886311910),
//--TRIMMABLE-BOUNDARY-START(17181279206),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1278950,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1410022,
      "h": 17181279206,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181279206),
//--TRIMMABLE-BOUNDARY-START(8591344614),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1278950,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1410022,
      "h": 8591344614,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591344614)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296377318),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1410022,
      "h": 4296377318,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296377318)
  ],
  "h": 1410022
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1410022)
        
        

        //--TRIMMABLE-BOUNDARY-START(3703782)
        $asm.$cls(`$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettingsTypeDescriptor`, ($self) => class ChangeOverDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298671078)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298671078);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, this, factory);
                    }, $YRzble ??= {"r":65537,"n":"","d":3703782,"h":0,"f":17825794}), 0, "ChangeOverDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver\\Settings_ChangeOverDeviceHardwareSettings_LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "ChangeOverDeviceHardwareSettingsTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298671078)
            
            //--TRIMMABLE-BOUNDARY-START(12888605670)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888605670);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverKeyControl).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888605670)
            
            //--TRIMMABLE-BOUNDARY-START(17183572966)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183572966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceSettings, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceSendDataModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverDeviceStatusHandler, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverDeviceHubClient, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverRemoteService>.iSmartDeviceHardwareSettings<LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverKeyControl>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverKeyControl).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).iSmartDeviceHardwareSettings$$($.$gKEB.LCIDSM.ChangeOverKeyControl)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183572966)
            
            //--TRIMMABLE-BOUNDARY-START(8593638374)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593638374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593638374)
            
            static $h = 3703782;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888605670),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3703782,
      "h": 12888605670,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888605670),
//--TRIMMABLE-BOUNDARY-START(17183572966),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3572710,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3703782,
      "h": 17183572966,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183572966),
//--TRIMMABLE-BOUNDARY-START(8593638374),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3572710,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3703782,
      "h": 8593638374,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593638374)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298671078),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3703782,
      "h": 4298671078,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298671078)
  ],
  "h": 3703782
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Settings${separator}ChangeOverDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3703782)
        
        

        //--TRIMMABLE-BOUNDARY-START(885734)
        $asm.$cls(`$gKEB.LCIDSM.ChangeOverDeviceModelTypeDescriptor`, ($self) => class ChangeOverDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295853030)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295853030);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$gKEB.LCIDSM.ChangeOverDeviceModelTypeDescriptor.GenerateProperties($.$gKEB.LCIDSM.ChangeOverDeviceModel, this, factory);
                    }, $ISzFka ??= {"r":65537,"n":"","d":885734,"h":0,"f":17825794}), 0, "ChangeOverDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeChangeOver\\Models_ChangeOverDeviceModel_LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceModelTypeDescriptorBuilder.g.cs", "ChangeOverDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295853030)
            
            //--TRIMMABLE-BOUNDARY-START(12885787622)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885787622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885787622)
            
            //--TRIMMABLE-BOUNDARY-START(17180754918)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180754918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceSettings, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Settings.ChangeOverDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceSendDataModel, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverDeviceStatusHandler, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverDeviceHubClient, LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Services.IChangeOverRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180754918)
            
            //--TRIMMABLE-BOUNDARY-START(8590820326)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590820326);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$gKEB.LCIDSM.ChangeOverDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$gKEB.LCIDSM.ChangeOverDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSM.ChangeOverDeviceModel)))
                {
                    /*var*/ let result = $.$gKEB.LCIDSM.ChangeOverDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSM.ChangeOverDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$gKEB.LCIDSM.ChangeOverDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$gKEB.LCIDSM.ChangeOverDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590820326)
            
            static $h = 885734;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885787622),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 885734,
      "h": 12885787622,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885787622),
//--TRIMMABLE-BOUNDARY-START(17180754918),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 754662,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 885734,
      "h": 17180754918,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180754918),
//--TRIMMABLE-BOUNDARY-START(8590820326),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 754662,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 885734,
      "h": 8590820326,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590820326)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295853030),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 885734,
      "h": 4295853030,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295853030)
  ],
  "h": 885734
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$gKEB.LCIDSM.ChangeOverDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Models.ChangeOverDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Models${separator}ChangeOverDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(885734)
        
        

        //--TRIMMABLE-BOUNDARY-START(295910)
        $asm.$cls(`$gKEB.LCIDS.ChangeOverDevice`, ($self) => class ChangeOverDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$gKEB.LCIDSM.ChangeOverStatus).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4295263206)
            $ctor$2(/*IIOTDeviceFamily<ChangeOverDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*ChangeOverDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295263206);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295263206)
            
            //--TRIMMABLE-BOUNDARY-START(17180165094)
            /*IconDescriptor */ get Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885197798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let icon = super.Icon;
                /*bool*/ let on = (this.Received?.Status.GeneratorState ?? null) === 3/*ChangeOverState.RUNNING*/;
                return (() =>
                {
                    //new $.$fPer.LCFC.IconDescriptor()
                    const $t1 = $.$fPer.LCFC.IconDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Icon = $.$XBGm.LCIC.UtilityExtension.MaterialIcon(this.Model$1.DeviceType, on);
                    $i1.Theme = $.$with(icon.Theme, ($clone) =>
                    {
                        $clone.ForegroundColor = on ? "FFFF00" : icon.Theme.ForegroundColor;
                    });
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(17180165094)
            
            //--TRIMMABLE-BOUNDARY-START(21475132390)
            /*Task */ Start()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475132390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$gKEB.LCIDSPC.ChangeOverKeyCommand, $.$gKEB.LCIDSPC.ChangeOverKeyCommandModel, this, new $.$gKEB.LCIDSPC.ChangeOverKeyCommand().$ctor$5(), new $.$gKEB.LCIDSPC.ChangeOverKeyCommandModel().$ctor$4(1/*ChangeOverKeyControl.Start*/));
            }
            //--TRIMMABLE-BOUNDARY-END(21475132390)
            
            //--TRIMMABLE-BOUNDARY-START(25770099686)
            /*Task */ Stop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770099686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$gKEB.LCIDSPC.ChangeOverKeyCommand, $.$gKEB.LCIDSPC.ChangeOverKeyCommandModel, this, new $.$gKEB.LCIDSPC.ChangeOverKeyCommand().$ctor$5(), new $.$gKEB.LCIDSPC.ChangeOverKeyCommandModel().$ctor$4(2/*ChangeOverKeyControl.Stop*/));
            }
            //--TRIMMABLE-BOUNDARY-END(25770099686)
            
            //--TRIMMABLE-BOUNDARY-START(30065066982)
            /*Task */ Time(/*int*/ minutes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065066982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$gKEB.LCIDSPC.ChangeOverCountDownCommand, $.$gKEB.LCIDSPC.ChangeOverCountDownCommandModel, this, new $.$gKEB.LCIDSPC.ChangeOverCountDownCommand().$ctor$6(), new $.$gKEB.LCIDSPC.ChangeOverCountDownCommandModel().$ctor$4(minutes));
            }
            //--TRIMMABLE-BOUNDARY-END(30065066982)
            
            static $h = 295910;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDS.ChangeOverDevice, $.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$gKEB.LCIDSM.ChangeOverStatus).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180165094),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885197798,
        "f": 50364417
      },
      "n": "Icon",
      "d": 295910,
      "h": 17180165094,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180165094)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475132390),
    {
      "r": 178454529,
      "n": "Start",
      "d": 295910,
      "h": 21475132390,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475132390),
//--TRIMMABLE-BOUNDARY-START(25770099686),
    {
      "r": 178454529,
      "n": "Stop",
      "d": 295910,
      "h": 25770099686,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770099686),
//--TRIMMABLE-BOUNDARY-START(30065066982),
    {
      "r": 178454529,
      "p": [
        {
          "n": "minutes",
          "p": 655361
        }
      ],
      "n": "Time",
      "d": 295910,
      "h": 30065066982,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065066982)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295263206),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$gKEB.LCIDS.ChangeOverDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 754662
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 295910,
      "h": 4295263206,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295263206)
  ],
  "h": 295910
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.ChangeOverDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}ChangeOverDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(295910)
        
        

        //--TRIMMABLE-BOUNDARY-START(361446)
        $asm.$cls(`$gKEB.LCIDS.ChangeOverDeviceDefinition`, ($self) => class ChangeOverDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDS.ChangeOverDevice, $.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$gKEB.LCIDSM.ChangeOverStatus)
        {
            //--TRIMMABLE-BOUNDARY-START(4295328742)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295328742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295328742)
            
            //--TRIMMABLE-BOUNDARY-START(4295328742)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295328742)
            
            static $h = 361446;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDS.ChangeOverDevice, $.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$gKEB.LCIDSM.ChangeOverStatus); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295328742),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 361446,
      "h": 4295328742,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295328742)
  ],
  "h": 361446
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.ChangeOverDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}ChangeOverDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(361446)
        
        

        //--TRIMMABLE-BOUNDARY-START(426982)
        $asm.$cls(`$gKEB.LCIDS.ChangeOverDeviceFamily`, ($self) => class ChangeOverDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDS.ChangeOverDevice, $.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4295394278)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<ChangeOverDeviceReceivedDataModel, ChangeOverDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<ChangeOverDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295394278);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295394278)
            
            //--TRIMMABLE-BOUNDARY-START(12885328870)
            /*Type */ get DeviceScheduleDataType()
            {
                return $.$gKEB.LCIDSM.ChangeOverKeyControl.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(12885328870)
            
            //--TRIMMABLE-BOUNDARY-START(8590361574)
            /*Type */ get DeviceBroadcastReceiveActionType()
            {
                return $.$gKEB.LCIDSM.ChangeOverKeyControl.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8590361574)
            
            static $h = 426982;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$gKEB.LCIDS.ChangeOverDevice, $.$gKEB.LCIDSM.ChangeOverServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$gKEB.LCIDSM.ChangeOverDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$gKEB.LCIDSM.ChangeOverDeviceModel, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel, $.$gKEB.LCIDSS.IChangeOverDeviceStatusHandler, $.$gKEB.LCIDSS.IChangeOverDeviceHubClient, $.$gKEB.LCIDSS.IChangeOverRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885328870),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065198054,
        "f": 50364417
      },
      "n": "DeviceScheduleDataType",
      "d": 426982,
      "h": 12885328870,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12885328870),
//--TRIMMABLE-BOUNDARY-START(8590361574),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475263462,
        "f": 50364417
      },
      "n": "DeviceBroadcastReceiveActionType",
      "d": 426982,
      "h": 8590361574,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8590361574)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295394278),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 426982,
      "h": 4295394278,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295394278)
  ],
  "h": 426982
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$gKEB.LCIDS.ChangeOverDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$gKEB.LCIDS.ChangeOverDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.ChangeOverDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}ChangeOverDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(426982)
        
        

        //--TRIMMABLE-BOUNDARY-START(4293606)
        $asm.$cls(`$gKEB.LCIDSV.ChangeOverViewRenderer`, ($self) => class ChangeOverViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$gKEB.LCIDS.ChangeOverDevice, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299260902)
            $ctor$3(/*IOTRootViewModel*/ root)
            {
                super.$ctor$2(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299260902);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299260902)
            
            //--TRIMMABLE-BOUNDARY-START(8594228198)
            /*RenderFragment */ GetView(/*IClientUnitOfWork*/ ui, /*ChangeOverDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>*/ clicked, /*Func<Task>*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594228198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === 3/*DeviceViewType.Details*/)
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$gKEB.LCIDSV.ChangeOverDetails, $.$gKEB.LCIDSV.ChangeOverDetailsViewModel, new $.$gKEB.LCIDSV.ChangeOverDetailsViewModel().$ctor$9(this.Root, device.OwnerScope, device), true, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(8594228198)
            
            static $h = 4293606;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$gKEB.LCIDS.ChangeOverDevice, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594228198),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 295910
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 4293606,
      "h": 8594228198,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8594228198)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299260902),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4293606,
      "h": 4299260902,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299260902)
  ],
  "h": 4293606
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$gKEB.LCIDS.ChangeOverDevice), $.$ntej.LCICD$1.IDeviceViewRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Views.ChangeOverViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Views${separator}ChangeOverViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4293606)
        
        

        //--TRIMMABLE-BOUNDARY-START(4228070)
        $asm.$cls(`$gKEB.LCIDSV.ChangeOverDetailsViewModel`, ($self) => class ChangeOverDetailsViewModel extends $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$gKEB.LCIDS.ChangeOverDevice, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299195366)
            $ctor$9(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*ChangeOverDevice*/ device)
            {
                super.$ctor$8(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299195366);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299195366)
            
            static $h = 4228070;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$gKEB.LCIDS.ChangeOverDevice, $.$gKEB.LCIDSS$1.ChangeOverDeviceSettings, $.$gKEB.LCIDSS$1.ChangeOverDeviceHardwareSettings, $.$gKEB.LCIDSM.ChangeOverDeviceReceivedDataModel, $.$gKEB.LCIDSM.ChangeOverDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299195366),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 295910
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 4228070,
      "h": 4299195366,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299195366)
  ],
  "h": 4228070
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICDV.IDeviceDetailsViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Views.ChangeOverDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Views${separator}ChangeOverDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4228070)
        
        

        //--TRIMMABLE-BOUNDARY-START(4162534)
        $asm.$cls(`$gKEB.LCIDSV.ChangeOverDetails`, ($self) => class ChangeOverDetails extends $.$hDPm.LCFCC$1.BaseComponent$$($.$gKEB.LCIDSV.ChangeOverDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(42953835494)
            /*string */ get OptimizedComponentName()
            {
                return "changeoverdetails";
            }
            //--TRIMMABLE-BOUNDARY-END(42953835494)
            
            //--TRIMMABLE-BOUNDARY-START(77313573862)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77313573862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$gKEB.LCIDSV.ChangeOverDetailsViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(77313573862)
            
            //--TRIMMABLE-BOUNDARY-START(81608541158)
            /*ChangeOverDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(81608541158)
            
            //--TRIMMABLE-BOUNDARY-START(73018606566)
            /*DateTime */ get Time()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068933606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.DateTime.MinValue;
            }
            /*DateTime */ set Time(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51543770086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = this.ViewModel.Device$1.Time($.$fPer.LCFCDC.DateTimeExtension.CountDownMinutes(value));
            }
            //--TRIMMABLE-BOUNDARY-END(73018606566)
            
            //--TRIMMABLE-BOUNDARY-START(64428671974)
            /*Task *//*async*/  Start()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64428671974);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t2, $r2;
                        ($t2 = this.ViewModel.Device$1.Start(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                    catch($e)
                    {
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64428671974)
            
            //--TRIMMABLE-BOUNDARY-START(68723639270)
            /*Task *//*async*/  Stop()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68723639270);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t3, $r3;
                        ($t3 = this.ViewModel.Device$1.Stop(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                    catch($e)
                    {
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68723639270)
            
            //--TRIMMABLE-BOUNDARY-START(12889064422)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889064422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$gKEB.LCIDS.ChangeOverDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$gKEB.LCIDS.ChangeOverDevice), this.ViewModel));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenElement(3, "div");
                    __builder2.AddAttribute$5(4, "class", "pd");
                    __builder2.OpenElement(5, "div");
                    __builder2.AddAttribute$5(6, "class", "flex flex-center-x mgx-a mawx-5");
                    __builder2.OpenElement(7, "div");
                    __builder2.OpenComponent$1($.$ntej.LCICS$2.CircularTextCard, 8);
                    __builder2.AddComponentParameter(9, "Text", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `${$.$strNN(((this.ViewModel.Device$1.Received?.Status?.Grid ?? null) ?? 0))}V`));
                    __builder2.AddComponentParameter(10, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mgx-15${$.$strNN(((this.ViewModel.Device$1.Received?.Status?.CurrentPhase ?? null) === 1/*ChangeOverPhase.Grid*/ ? " bd-primary bdw-3" : ""))}`));
                    __builder2.AddComponentParameter(11, "ContentClass", "c-block text-center mdi mdi-coat-rack");
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(12, "\r\n            ");
                    __builder2.OpenElement(13, "div");
                    __builder2.OpenComponent$1($.$ntej.LCICS$2.CircularTextCard, 14);
                    __builder2.AddComponentParameter(15, "Text", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `${$.$strNN(((this.ViewModel.Device$1.Received?.Status?.Generator ?? null) ?? 0))}V`));
                    __builder2.AddComponentParameter(16, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mgx-15${$.$strNN(((this.ViewModel.Device$1.Received?.Status?.CurrentPhase ?? null) === 2/*ChangeOverPhase.Generator*/ ? " bd-primary bdw-3" : ""))}`));
                    __builder2.AddComponentParameter(17, "ContentClass", "c-block text-center mdi mdi-engine");
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(18, "\r\n        ");
                    __builder2.OpenElement(19, "div");
                    __builder2.AddMarkupContent(20, "<h3 class=\"mgb-0 text-center\">Shutdown Timer</h3>\r\n            ");
                    __builder2.OpenElement(21, "div");
                    __builder2.AddAttribute$5(22, "class", "flex flex-center-x");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCG.SevenSegments, 23);
                    __builder2.AddComponentParameter(24, "Digits", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 2), $.$$.S.Int32));
                    __builder2.AddComponentParameter(25, "Number", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Double, (this.ViewModel.Device$1.Received?.Status?.AutoShutdownHour ?? null) ?? 0), $.$$.S.Double));
                    __builder2.AddComponentParameter(26, "Height", "90");
                    __builder2.AddComponentParameter(27, "Width", "50");
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(28, "\r\n                ");
                    __builder2.AddMarkupContent(29, "<h3>hr</h3>\r\n                ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCG.SevenSegments, 30);
                    __builder2.AddComponentParameter(31, "Digits", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 2), $.$$.S.Int32));
                    __builder2.AddComponentParameter(32, "Number", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Double, (this.ViewModel.Device$1.Received?.Status?.AutoShutdownMinutes ?? null) ?? 0), $.$$.S.Double));
                    __builder2.AddComponentParameter(33, "Height", "90");
                    __builder2.AddComponentParameter(34, "Width", "50");
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(35, "\r\n                ");
                    __builder2.AddMarkupContent(36, "<h3>min</h3>");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(37, "\r\n        ");
                    __builder2.OpenElement(38, "div");
                    __builder2.AddAttribute$5(39, "class", "flex flex-center-x mgt mgx-a mawx-5");
                    __builder2.OpenComponent$1($.$ntej.LCICD$1.DeviceOnOffButton, 40);
                    __builder2.AddComponentParameter(41, "Device", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$XBGm.LCICI.IIOTDevice, this.ViewModel.Device$1));
                    __builder2.AddComponentParameter(42, "OnClick", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback, $.$mac.MAC.EventCallback.Factory.Create$4(this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Start))));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(43, "\r\n        ");
                    __builder2.OpenElement(44, "div");
                    __builder2.AddAttribute$5(45, "class", "flex flex-center-x mgt");
                    __builder2.OpenElement(46, "div");
                    __builder2.AddAttribute$5(47, "Class", "pos-rel mgx-15");
                    __builder2.OpenElement(48, "input");
                    __builder2.AddAttribute$5(49, "type", "time");
                    __builder2.AddAttribute$5(50, "style", "opacity:0;position:absolute;top:0;bottom:0;left:0;right:0;z-index:2");
                    __builder2.AddAttribute$5(51, "value", $.$mac.MAC.BindConverter.FormatValue$4(this.Time, "HH:mm:ss", $.$$.SG.CultureInfo.InvariantCulture));
                    __builder2.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 52, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$4($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.DateTime))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.Time = __value;
                    }, $IJnRbl ??= {"r":65537,"p":[{"n":"__value","p":65994753}],"n":"","d":4162534,"h":0,"f":17825794}), this.Time, "HH:mm:ss", $.$$.SG.CultureInfo.InvariantCulture));
                    __builder2.SetUpdatesAttributeName("value");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(53, "\r\n                ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 54);
                    __builder2.AddComponentParameter(55, "Class", "hx-07 wx-07 mdi mdi-counter round fsz-40");
                    __builder2.AddComponentParameter(56, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Info));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(57, "\r\n                ");
                    __builder2.AddMarkupContent(58, "<div class=\"text-center\">Time Off</div>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(59, "\r\n            ");
                    __builder2.OpenElement(60, "div");
                    __builder2.AddAttribute$5(61, "class", "mgx-15");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 62);
                    __builder2.AddComponentParameter(63, "Class", "hx-07 wx-07 mdi mdi-engine-off round  fsz-40");
                    __builder2.AddComponentParameter(64, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Error));
                    __builder2.AddComponentParameter(65, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Stop))));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(66, "\r\n                ");
                    __builder2.AddMarkupContent(67, "<div class=\"text-center\">Off Now</div>");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                }), $ArdHSe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":4162534,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12889064422)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8594097126)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594097126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594097126)
            
            //--TRIMMABLE-BOUNDARY-START(8594097126)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8594097126)
            
            static $h = 4162534;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$gKEB.LCIDSV.ChangeOverDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42953835494),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478999014,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 4162534,
      "h": 42953835494,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42953835494),
//--TRIMMABLE-BOUNDARY-START(81608541158),
    {
      "p": 4228070,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38658868198,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60133704678,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 4162534,
      "h": 81608541158,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81608541158),
//--TRIMMABLE-BOUNDARY-START(73018606566),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068933606,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51543770086,
        "f": 83886082
      },
      "n": "Time",
      "d": 4162534,
      "h": 73018606566,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(73018606566)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77313573862),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 4162534,
      "h": 77313573862,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77313573862),
//--TRIMMABLE-BOUNDARY-START(64428671974),
    {
      "r": 178454529,
      "n": "Start",
      "d": 4162534,
      "h": 64428671974,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(64428671974),
//--TRIMMABLE-BOUNDARY-START(68723639270),
    {
      "r": 178454529,
      "n": "Stop",
      "d": 4162534,
      "h": 68723639270,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(68723639270),
//--TRIMMABLE-BOUNDARY-START(12889064422),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 4162534,
      "h": 12889064422,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12889064422)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594097126),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4162534,
      "h": 8594097126,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594097126)
  ],
  "h": 4162534
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeChangeOver.Views.ChangeOverDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeChangeOver${separator}Views${separator}ChangeOverDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4162534)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor", "NetJs.LivingThing.Core.IOT.Devices.SerialBridge"));
})();
//--TRIMMABLE-BOUNDARY-END(33766)
