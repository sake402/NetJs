
//--TRIMMABLE-BOUNDARY-START(32261)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej, $tKtD) {
    "use strict";
    let _;
    let $YquMnk;
    let $sCgwRk;
    let $uaSHsf;
    let $tpzVDi;
    let $KTlAwc;
    let $MaSNWf;
    let $UNMiVk;
    let $PikQxc;
    let $RUjXgi;
    let $pBThml;
    let $zItlLd;
    let $ZgSUmk;
    let $wcxqjb;
    let $nhwQCk;
    let $xXQqqk;
    let $qBjrkc;
    let $WALVVj;
    let $qKtBVe;
    let $JGiDbb;
    let $sVohlj;
    let $sXVvPc;
    let $KRxLKc;
    let $oUHkff;
    let $lSIKkf;
    let $NfCEve;
    let $VBINNj;
    let $Lopemj;
    let $XfaFpf;
    let $fLDZvg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter", 
    {
  "h": 32261,
  "f": "LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5TZXJpYWxCcmlkZ2VWb2x0bWV0ZXIuU21hcnRWb2x0bWV0ZXJEZXZpY2UiOiB7DQogICAgICAiQ2F0ZWdvcmllcyI6IFsgIlNtYXJ0IEhvbWUiLCAiRElZIiBdLA0KICAgICAgIk5hbWUiOiAiU2VyaWFsQnJpZGdlVm9sdG1ldGVyIiwNCiAgICAgICJEZXNjcmlwdGlvbiI6ICJNZWFzdXJlIEFuYWxvZyBWb2x0YWdlcy4iLA0KICAgICAgIkljb24iOiB7ICJOYW1lIjogIm1kaSBtZGktY3VycmVudC1kYyIgfSwNCiAgICAgICJUaGVtZUNvbG9yIjogIiNmZjc1YTAiLA0KICAgICAgImZGbGFncyI6ICJQdWJsaXNoZWQiLA0KICAgICAgIlNlY3VyaXRpZXMiOiAiQ2hhbGxlbmdlSGFuZFNoYWtlQXV0aGVudGljYXRpb25Qcm90b2NvbCxBZHZhbmNlZEVuY3J5cHRpb25TdGFuZGFyZCxFbGxpcHRpY0N1cnZlRmlybXdhcmVVcGRhdGVTaWduaW5nIg0KICAgIH0NCiAgfQ0KfQ=="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1080837)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class SmartVoltmeterDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296048133)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296048133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelCustomAttributesProvider$$($.$nGxw.LCIDSM.FourChannelADCModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296048133)
            
            static $h = 1080837;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296048133),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1080837,
      "h": 4296048133,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296048133)
  ],
  "h": 1080837
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1080837)
        
        

        //--TRIMMABLE-BOUNDARY-START(2653701)
        $asm.$cls(`$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class SmartVoltmeterDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297620997)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297620997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297620997)
            
            static $h = 2653701;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297620997),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2653701,
      "h": 4297620997,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297620997)
  ],
  "h": 2653701
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Settings${separator}SmartVoltmeterDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2653701)
        
        

        //--TRIMMABLE-BOUNDARY-START(1342981)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModelCustomAttributesProvider`, ($self) => class SmartVoltmeterDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296310277)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296310277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296310277)
            
            static $h = 1342981;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296310277),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1342981,
      "h": 4296310277,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296310277)
  ],
  "h": 1342981
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1342981)
        
        

        //--TRIMMABLE-BOUNDARY-START(2522629)
        $asm.$cls(`$nGxw.LCIDSS$1.SmartVoltmeterBroadcastPeerMessagesCustomAttributesProvider`, ($self) => class SmartVoltmeterBroadcastPeerMessagesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297489925)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297489925);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297489925)
            
            static $h = 2522629;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297489925),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2522629,
      "h": 4297489925,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297489925)
  ],
  "h": 2522629
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterBroadcastPeerMessagesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Settings${separator}SmartVoltmeterBroadcastPeerMessagesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2522629)
        
        

        //--TRIMMABLE-BOUNDARY-START(294405)
        $asm.$cls(`$nGxw.LCIDS.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295261701)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295261701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$nGxw.LCIDSM.FourChannelADCModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$nGxw.LCIDSM.FourChannelADCModelCustomAttributesProvider, $.$nGxw.LCIDSM.FourChannelADCModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$nGxw.LCIDSM.SmartVoltmeterDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$nGxw.LCIDSM.SmartVoltmeterDeviceModelCustomAttributesProvider, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModelCustomAttributesProvider, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModelCustomAttributesProvider, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModelCustomAttributesProvider, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$nGxw.LCIDSM.SmartVoltmeterServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$nGxw.LCIDSM.SmartVoltmeterServiceModelCustomAttributesProvider, $.$nGxw.LCIDSM.SmartVoltmeterServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettingsCustomAttributesProvider, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$nGxw.LCIDSS$1.SmartVoltmeterBroadcastPeerMessages.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$nGxw.LCIDSS$1.SmartVoltmeterBroadcastPeerMessagesCustomAttributesProvider, $.$nGxw.LCIDSS$1.SmartVoltmeterBroadcastPeerMessagesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettingsCustomAttributesProvider, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295261701)
            
            static $h = 294405;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295261701),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 294405,
      "h": 4295261701,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295261701)
  ],
  "h": 294405
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(294405)
        
        

        //--TRIMMABLE-BOUNDARY-START(2915845)
        $asm.$cls(`$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettingsCustomAttributesProvider`, ($self) => class SmartVoltmeterDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297883141)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297883141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297883141)
            
            static $h = 2915845;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297883141),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2915845,
      "h": 4297883141,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297883141)
  ],
  "h": 2915845
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Settings${separator}SmartVoltmeterDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2915845)
        
        

        //--TRIMMABLE-BOUNDARY-START(818693)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterDeviceModelCustomAttributesProvider`, ($self) => class SmartVoltmeterDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295785989)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295785989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295785989)
            
            static $h = 818693;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295785989),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 818693,
      "h": 4295785989,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295785989)
  ],
  "h": 818693
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(818693)
        
        

        //--TRIMMABLE-BOUNDARY-START(359941)
        $asm.$cls(`$nGxw.LCIDS.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295327237)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295327237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295327237)
            
            static $h = 359941;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295327237),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 359941,
      "h": 4295327237,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295327237)
  ],
  "h": 359941
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(359941)
        
        

        //--TRIMMABLE-BOUNDARY-START(3440133)
        $asm.$cls(`$nGxw.LCIDS.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298407429)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298407429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$nGxw.LCIDSM.FourChannelADCModelTypeDescriptorBuilder.Register();
                $.$nGxw.LCIDSM.SmartVoltmeterDeviceModelTypeDescriptorBuilder.Register();
                $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$nGxw.LCIDSM.SmartVoltmeterServiceModelTypeDescriptorBuilder.Register();
                $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298407429)
            
            static $h = 3440133;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298407429),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3440133,
      "h": 4298407429,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298407429)
  ],
  "h": 3440133
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3440133)
        
        

        //--TRIMMABLE-BOUNDARY-START(1211909)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class SmartVoltmeterDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591146501)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591146501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $UNMiVk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1211909,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591146501)
            
            //--TRIMMABLE-BOUNDARY-START(4296179205)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296179205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296179205)
            
            //--TRIMMABLE-BOUNDARY-START(4296179205)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296179205)
            
            static $h = 1211909;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591146501),
    {
      "r": 65537,
      "n": "Register",
      "d": 1211909,
      "h": 8591146501,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591146501)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296179205),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1211909,
      "h": 4296179205,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296179205)
  ],
  "h": 1211909
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1211909)
        
        

        //--TRIMMABLE-BOUNDARY-START(1736197)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class SmartVoltmeterDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591670789)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591670789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $KTlAwc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1736197,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591670789)
            
            //--TRIMMABLE-BOUNDARY-START(4296703493)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296703493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296703493)
            
            //--TRIMMABLE-BOUNDARY-START(4296703493)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296703493)
            
            static $h = 1736197;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591670789),
    {
      "r": 65537,
      "n": "Register",
      "d": 1736197,
      "h": 8591670789,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591670789)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296703493),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1736197,
      "h": 4296703493,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296703493)
  ],
  "h": 1736197
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1736197)
        
        

        //--TRIMMABLE-BOUNDARY-START(2391557)
        $asm.$cls(`$nGxw.LCIDSS$1.ChannelVisuaization`, ($self) => class ChannelVisuaization extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(68721868293)
            /*string?*/ Label = null;
            //--TRIMMABLE-BOUNDARY-END(68721868293)
            
            //--TRIMMABLE-BOUNDARY-START(25772195333)
            /*string?*/ Converter = null;
            //--TRIMMABLE-BOUNDARY-END(25772195333)
            
            //--TRIMMABLE-BOUNDARY-START(107376573957)
            /*string?*/ Unit = null;
            //--TRIMMABLE-BOUNDARY-END(107376573957)
            
            //--TRIMMABLE-BOUNDARY-START(64426900997)
            /*string?*/ Icon = null;
            //--TRIMMABLE-BOUNDARY-END(64426900997)
            
            //--TRIMMABLE-BOUNDARY-START(21477228037)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477228037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477228037)
            
            //--TRIMMABLE-BOUNDARY-START(21477228037)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21477228037)
            
            static $h = 2391557;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68721868293),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541999109,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94491672069,
        "f": 83886081
      },
      "n": "Label",
      "d": 2391557,
      "h": 68721868293,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721868293),
//--TRIMMABLE-BOUNDARY-START(25772195333),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362129925,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77311802885,
        "f": 83886081
      },
      "n": "Converter",
      "d": 2391557,
      "h": 25772195333,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772195333),
//--TRIMMABLE-BOUNDARY-START(107376573957),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131933701,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103081606661,
        "f": 83886081
      },
      "n": "Unit",
      "d": 2391557,
      "h": 107376573957,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107376573957),
//--TRIMMABLE-BOUNDARY-START(64426900997),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952064517,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85901737477,
        "f": 83886081
      },
      "n": "Icon",
      "d": 2391557,
      "h": 64426900997,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 21,
              "t": 47614294
            },
            {
              "n": "OptionsReader",
              "v": 46565718,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64426900997)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477228037),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2391557,
      "h": 21477228037,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477228037)
  ],
  "h": 2391557
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.ChannelVisuaization`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Settings${separator}ChannelVisuaization`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2391557)
        
        

        //--TRIMMABLE-BOUNDARY-START(163333)
        $asm.$cls(`$nGxw.LCIDS._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295130629)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295130629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$nGxw.LCIDS.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295130629)
            
            static $h = 163333;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295130629),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 163333,
      "h": 4295130629,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295130629)
  ],
  "h": 163333
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(163333)
        
        

        //--TRIMMABLE-BOUNDARY-START(1867269)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterServiceModelCustomAttributesProvider`, ($self) => class SmartVoltmeterServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296834565)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296834565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296834565)
            
            static $h = 1867269;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296834565),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1867269,
      "h": 4296834565,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296834565)
  ],
  "h": 1867269
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1867269)
        
        

        //--TRIMMABLE-BOUNDARY-START(556549)
        $asm.$cls(`$nGxw.LCIDSM.FourChannelADCModelCustomAttributesProvider`, ($self) => class FourChannelADCModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295523845)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295523845)
            
            //--TRIMMABLE-BOUNDARY-START(8590491141)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590491141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$nGxw.LCIDSM.FourChannelADCModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Channels", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.Size = (4);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$nGxw.LCIDSM.FourChannelADCModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $RUjXgi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":556549,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $pBThml ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":556549,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590491141)
            
            static $h = 556549;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590491141),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 556549,
      "h": 8590491141,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590491141)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295523845),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 556549,
      "h": 4295523845,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295523845)
  ],
  "h": 556549
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.FourChannelADCModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}FourChannelADCModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(556549)
        
        

        //--TRIMMABLE-BOUNDARY-START(1998341)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterServiceModelTypeDescriptorBuilder`, ($self) => class SmartVoltmeterServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591932933)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591932933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$nGxw.LCIDSM.SmartVoltmeterServiceModelTypeDescriptor()
                        const $t1 = $.$nGxw.LCIDSM.SmartVoltmeterServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $zItlLd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1998341,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$nGxw.LCIDSM.SmartVoltmeterServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591932933)
            
            //--TRIMMABLE-BOUNDARY-START(4296965637)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296965637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296965637)
            
            //--TRIMMABLE-BOUNDARY-START(4296965637)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296965637)
            
            static $h = 1998341;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591932933),
    {
      "r": 65537,
      "n": "Register",
      "d": 1998341,
      "h": 8591932933,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591932933)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296965637),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1998341,
      "h": 4296965637,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296965637)
  ],
  "h": 1998341
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1998341)
        
        

        //--TRIMMABLE-BOUNDARY-START(1605125)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModelCustomAttributesProvider`, ($self) => class SmartVoltmeterDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296572421)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296572421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296572421)
            
            static $h = 1605125;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296572421),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1605125,
      "h": 4296572421,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296572421)
  ],
  "h": 1605125
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1605125)
        
        

        //--TRIMMABLE-BOUNDARY-START(2784773)
        $asm.$cls(`$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class SmartVoltmeterDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592719365)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592719365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $wcxqjb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2784773,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592719365)
            
            //--TRIMMABLE-BOUNDARY-START(4297752069)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297752069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297752069)
            
            //--TRIMMABLE-BOUNDARY-START(4297752069)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297752069)
            
            static $h = 2784773;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592719365),
    {
      "r": 65537,
      "n": "Register",
      "d": 2784773,
      "h": 8592719365,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592719365)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297752069),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2784773,
      "h": 4297752069,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297752069)
  ],
  "h": 2784773
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Settings${separator}SmartVoltmeterDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2784773)
        
        

        //--TRIMMABLE-BOUNDARY-START(687621)
        $asm.$cls(`$nGxw.LCIDSM.FourChannelADCModelTypeDescriptorBuilder`, ($self) => class FourChannelADCModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590622213)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590622213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$nGxw.LCIDSM.FourChannelADCModelTypeDescriptor()
                        const $t1 = $.$nGxw.LCIDSM.FourChannelADCModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.FourChannelADCModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $JGiDbb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":687621,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$nGxw.LCIDSM.FourChannelADCModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590622213)
            
            //--TRIMMABLE-BOUNDARY-START(4295654917)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295654917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295654917)
            
            //--TRIMMABLE-BOUNDARY-START(4295654917)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295654917)
            
            static $h = 687621;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590622213),
    {
      "r": 65537,
      "n": "Register",
      "d": 687621,
      "h": 8590622213,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590622213)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295654917),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 687621,
      "h": 4295654917,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295654917)
  ],
  "h": 687621
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.FourChannelADCModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}FourChannelADCModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(687621)
        
        

        //--TRIMMABLE-BOUNDARY-START(949765)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterDeviceModelTypeDescriptorBuilder`, ($self) => class SmartVoltmeterDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590884357)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590884357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$nGxw.LCIDSM.SmartVoltmeterDeviceModelTypeDescriptor()
                        const $t1 = $.$nGxw.LCIDSM.SmartVoltmeterDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $xXQqqk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":949765,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$nGxw.LCIDSM.SmartVoltmeterDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590884357)
            
            //--TRIMMABLE-BOUNDARY-START(4295917061)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295917061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295917061)
            
            //--TRIMMABLE-BOUNDARY-START(4295917061)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295917061)
            
            static $h = 949765;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590884357),
    {
      "r": 65537,
      "n": "Register",
      "d": 949765,
      "h": 8590884357,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590884357)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295917061),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 949765,
      "h": 4295917061,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295917061)
  ],
  "h": 949765
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(949765)
        
        

        //--TRIMMABLE-BOUNDARY-START(1474053)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModelTypeDescriptorBuilder`, ($self) => class SmartVoltmeterDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591408645)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591408645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $WALVVj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1474053,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591408645)
            
            //--TRIMMABLE-BOUNDARY-START(4296441349)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296441349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296441349)
            
            //--TRIMMABLE-BOUNDARY-START(4296441349)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296441349)
            
            static $h = 1474053;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591408645),
    {
      "r": 65537,
      "n": "Register",
      "d": 1474053,
      "h": 8591408645,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591408645)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296441349),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1474053,
      "h": 4296441349,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296441349)
  ],
  "h": 1474053
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1474053)
        
        

        //--TRIMMABLE-BOUNDARY-START(3046917)
        $asm.$cls(`$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettingsTypeDescriptorBuilder`, ($self) => class SmartVoltmeterDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592981509)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592981509);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettingsTypeDescriptor()
                        const $t1 = $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $oUHkff ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3046917,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592981509)
            
            //--TRIMMABLE-BOUNDARY-START(4298014213)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298014213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298014213)
            
            //--TRIMMABLE-BOUNDARY-START(4298014213)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298014213)
            
            static $h = 3046917;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592981509),
    {
      "r": 65537,
      "n": "Register",
      "d": 3046917,
      "h": 8592981509,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592981509)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298014213),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3046917,
      "h": 4298014213,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298014213)
  ],
  "h": 3046917
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Settings${separator}SmartVoltmeterDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3046917)
        
        

        //--TRIMMABLE-BOUNDARY-START(228869)
        $asm.$cls(`$nGxw.LCIDS.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180098053)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180098053)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295196165)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295196165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295196165)
            
            //--TRIMMABLE-BOUNDARY-START(4295196165)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295196165)
            
            static $h = 228869;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180098053),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885130757,
        "f": 50331649
      },
      "n": "Paths",
      "d": 228869,
      "h": 17180098053,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180098053)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295196165),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 228869,
      "h": 4295196165,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295196165)
  ],
  "h": 228869
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(228869)
        
        

        //--TRIMMABLE-BOUNDARY-START(425477)
        $asm.$cls(`$nGxw.LCIDSM.ADCChannel`, ($self) => class ADCChannel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475261957)
            /*double*/ DC = 0;
            //--TRIMMABLE-BOUNDARY-END(21475261957)
            
            //--TRIMMABLE-BOUNDARY-START(17180294661)
            /*double*/ AC = 0;
            //--TRIMMABLE-BOUNDARY-END(17180294661)
            
            //--TRIMMABLE-BOUNDARY-START(12885327365)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885327365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885327365)
            
            //--TRIMMABLE-BOUNDARY-START(12885327365)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885327365)
            
            static $h = 425477;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475261957),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655131141,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835000325,
        "f": 83886081
      },
      "n": "DC",
      "d": 425477,
      "h": 21475261957,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "Unit=mV"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475261957),
//--TRIMMABLE-BOUNDARY-START(17180294661),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065196549,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245065733,
        "f": 83886081
      },
      "n": "AC",
      "d": 425477,
      "h": 17180294661,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "Unit=mV"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180294661)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885327365),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 425477,
      "h": 12885327365,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885327365)
  ],
  "h": 425477
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.ADCChannel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}ADCChannel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(425477)
        
        

        //--TRIMMABLE-BOUNDARY-START(2129413)
        $asm.$cls(`$nGxw.LCIDS.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592064005)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592064005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$nGxw.LCIDS.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$nGxw.LCIDS.SmartVoltmeterDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$nGxw.LCIDS.SmartVoltmeterDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$nGxw.LCIDS.SmartVoltmeterDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$nGxw.LCIDS.SmartVoltmeterDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$nGxw.LCIDS.SmartVoltmeterDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$nGxw.LCIDS.SmartVoltmeterDeviceFamily, x);
                }, $sCgwRk ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":2129413,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$nGxw.LCIDS.SmartVoltmeterDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$nGxw.LCIDS.SmartVoltmeterDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $uaSHsf ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":2129413,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$nGxw.LCIDS.SmartVoltmeterDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$nGxw.LCIDS.SmartVoltmeterDeviceFamily, x);
                }, $tpzVDi ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$nGxw.LCIDS.SmartVoltmeterDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":2129413,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$nGxw.LCIDS.SmartVoltmeterDevice, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$nGxw.LCIDS.SmartVoltmeterDevice, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$nGxw.LCIDS.SmartVoltmeterDevice, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$nGxw.LCIDS.SmartVoltmeterDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$nGxw.LCIDS.SmartVoltmeterDevice), $.$nGxw.LCIDSV.SmartVoltmeterViewRenderer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592064005)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$nGxw.LCIDS.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297096709)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297096709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297096709)
            
            //--TRIMMABLE-BOUNDARY-START(4297096709)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297096709)
            
            static $h = 2129413;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592064005),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2129413,
      "h": 8592064005,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592064005)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297096709),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2129413,
      "h": 4297096709,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297096709)
  ],
  "h": 2129413
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2129413)
        
        

        //--TRIMMABLE-BOUNDARY-START(2063877)
        $asm.$cls(`$nGxw.LCIDS.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181933061)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$nGxw.LCIDSV.SmartVoltmeterDeviceDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$nGxw.LCIDSV.SmartVoltmeterDeviceDetails().$ctor$4();
                    }, $YquMnk ??= {"r":2752627,"n":"","d":2063877,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17181933061)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4297031173)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297031173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297031173)
            
            //--TRIMMABLE-BOUNDARY-START(4297031173)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297031173)
            
            static $h = 2063877;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181933061),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886965765,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 2063877,
      "h": 17181933061,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181933061)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297031173),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2063877,
      "h": 4297031173,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297031173)
  ],
  "h": 2063877
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2063877)
        
        

        //--TRIMMABLE-BOUNDARY-START(3767813)
        $asm.$cls(`$nGxw.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298735109)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298735109);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298735109)
            
            //--TRIMMABLE-BOUNDARY-START(4298735109)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298735109)
            
            static $h = 3767813;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298735109),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3767813,
      "h": 4298735109,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298735109)
  ],
  "h": 3767813,
  "a": [
    {
      "t": 3702277,
      "c": 4298669573
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3767813)
        
        

        //--TRIMMABLE-BOUNDARY-START(3702277)
        $asm.$cls(`$nGxw.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298669573)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298669573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298669573)
            
            //--TRIMMABLE-BOUNDARY-START(4298669573)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298669573)
            
            static $h = 3702277;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298669573),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3702277,
      "h": 4298669573,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298669573)
  ],
  "h": 3702277
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3702277)
        
        

        //--TRIMMABLE-BOUNDARY-START(491013)
        $asm.$cls(`$nGxw.LCIDSM.FourChannelADCModel`, ($self) => class FourChannelADCModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(12885392901)
            /*ADCChannel[]*/ Channels = null;
            //--TRIMMABLE-BOUNDARY-END(12885392901)
            
            //--TRIMMABLE-BOUNDARY-START(8590425605)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590425605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590425605)
            
            //--TRIMMABLE-BOUNDARY-START(8590425605)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590425605)
            
            static $h = 491013;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885392901),
    {
      "p": $.$typeArray($.$nGxw.LCIDSM.ADCChannel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475327493,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065262085,
        "f": 83886081
      },
      "n": "Channels",
      "d": 491013,
      "h": 12885392901,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "Size",
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885392901)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590425605),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 491013,
      "h": 8590425605,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590425605)
  ],
  "h": 491013
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.FourChannelADCModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}FourChannelADCModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(491013)
        
        

        //--TRIMMABLE-BOUNDARY-START(2457093)
        $asm.$str(`$nGxw.LCIDSS$1.SmartVoltmeterBroadcastPeerMessages`, ($self) => class SmartVoltmeterBroadcastPeerMessages extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static ChannelOne = 1;
            static ChannelTwo = 2;
            static ChannelThree = 3;
            static ChannelFour = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2457093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "ChannelOne": 1n,
                    "ChannelTwo": 2n,
                    "ChannelThree": 3n,
                    "ChannelFour": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297424389)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297424389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297424389)
            
            //--TRIMMABLE-BOUNDARY-START(4297424389)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297424389)
            
            static $h = 2457093;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25772260869),
    {
      "t": 2457093,
      "n": "None",
      "d": 2457093,
      "h": 25772260869,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772260869),
//--TRIMMABLE-BOUNDARY-START(12887358981),
    {
      "t": 2457093,
      "n": "ChannelOne",
      "d": 2457093,
      "h": 12887358981,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887358981),
//--TRIMMABLE-BOUNDARY-START(21477293573),
    {
      "t": 2457093,
      "n": "ChannelTwo",
      "d": 2457093,
      "h": 21477293573,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477293573),
//--TRIMMABLE-BOUNDARY-START(17182326277),
    {
      "t": 2457093,
      "n": "ChannelThree",
      "d": 2457093,
      "h": 17182326277,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182326277),
//--TRIMMABLE-BOUNDARY-START(8592391685),
    {
      "t": 2457093,
      "n": "ChannelFour",
      "d": 2457093,
      "h": 8592391685,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592391685)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297424389),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2457093,
      "h": 4297424389,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297424389)
  ],
  "h": 2457093
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterBroadcastPeerMessages`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Settings${separator}SmartVoltmeterBroadcastPeerMessages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2457093)
        
        

        //--TRIMMABLE-BOUNDARY-START(97797)
        $asm.$cls(`$nGxw.LCIDS._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590032389)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590032389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590032389)
            
            //--TRIMMABLE-BOUNDARY-START(4295065093)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295065093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295065093)
            
            //--TRIMMABLE-BOUNDARY-START(4295065093)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295065093)
            
            static $h = 97797;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590032389),
    {
      "r": 65537,
      "n": "Execute",
      "d": 97797,
      "h": 8590032389,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590032389)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295065093),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 97797,
      "h": 4295065093,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295065093)
  ],
  "h": 97797
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(97797)
        
        

        //--TRIMMABLE-BOUNDARY-START(622085)
        $asm.$cls(`$nGxw.LCIDSM.FourChannelADCModelTypeDescriptor`, ($self) => class FourChannelADCModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$nGxw.LCIDSM.FourChannelADCModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295589381)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295589381);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$nGxw.LCIDSM.FourChannelADCModelTypeDescriptor.GenerateProperties($.$nGxw.LCIDSM.FourChannelADCModel, this, factory);
                    }, $sVohlj ??= {"r":65537,"n":"","d":622085,"h":0,"f":17825794}), 0, "FourChannelADCModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter\\Models_FourChannelADCModel_LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.FourChannelADCModelTypeDescriptorBuilder.g.cs", "FourChannelADCModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295589381)
            
            //--TRIMMABLE-BOUNDARY-START(12885523973)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885523973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Channels"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$nGxw.LCIDSM.FourChannelADCModel.$type, $.$discardRef(), "Channels", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Channels")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$nGxw.LCIDSM.ADCChannel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Channels";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.FourChannelADCModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$nGxw.LCIDSM.FourChannelADCModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$nGxw.LCIDSM.ADCChannel), ($.$cast(target, $.$nGxw.LCIDSM.FourChannelADCModel)).Channels);
                        }, $sXVvPc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":622085,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$nGxw.LCIDSM.FourChannelADCModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Channels = value.AsReference($.$typeArray($.$nGxw.LCIDSM.ADCChannel));
                        }, $KRxLKc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":622085,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885523973)
            
            //--TRIMMABLE-BOUNDARY-START(17180491269)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.FourChannelADCModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180491269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _Channels = _target.Channels;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Channels"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$nGxw.LCIDSM.ADCChannel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$nGxw.LCIDSM.ADCChannel), $.$nGxw.LCIDSM.ADCChannel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$nGxw.LCIDSM.ADCChannel), $.$nGxw.LCIDSM.ADCChannel, property, $.$ref(() => _Channels, ($v) => _Channels = $v, $.$typeArray($.$nGxw.LCIDSM.ADCChannel))))
                    {
                        _target.Channels = _Channels;
                        if (_Channels !== null)
                        {
                            let $i6 = 0;
                            let $arr6 = _Channels;
                            while ($i6 < $arr6.length)
                            {
                                let item = $arr6[$i6++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$nGxw.LCIDSM.ADCChannel)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$nGxw.LCIDSM.ADCChannel), $.$nGxw.LCIDSM.ADCChannel, property, $.$ref(() => _Channels, ($v) => _Channels = $v, $.$typeArray($.$nGxw.LCIDSM.ADCChannel)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180491269)
            
            //--TRIMMABLE-BOUNDARY-START(8590556677)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.FourChannelADCModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590556677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$nGxw.LCIDSM.FourChannelADCModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$nGxw.LCIDSM.FourChannelADCModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.FourChannelADCModel)))
                {
                    /*var*/ let result = $.$nGxw.LCIDSM.FourChannelADCModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.FourChannelADCModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$nGxw.LCIDSM.FourChannelADCModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.FourChannelADCModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590556677)
            
            static $h = 622085;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$nGxw.LCIDSM.FourChannelADCModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885523973),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 622085,
      "h": 12885523973,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885523973),
//--TRIMMABLE-BOUNDARY-START(17180491269),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 491013,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 622085,
      "h": 17180491269,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180491269),
//--TRIMMABLE-BOUNDARY-START(8590556677),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 491013,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 622085,
      "h": 8590556677,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590556677)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295589381),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 622085,
      "h": 4295589381,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295589381)
  ],
  "h": 622085
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$nGxw.LCIDSM.FourChannelADCModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.FourChannelADCModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}FourChannelADCModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(622085)
        
        

        //--TRIMMABLE-BOUNDARY-START(1539589)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel`, ($self) => class SmartVoltmeterDeviceSendDataModel extends $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296506885)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296506885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296506885)
            
            //--TRIMMABLE-BOUNDARY-START(4296506885)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296506885)
            
            static $h = 1539589;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296506885),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1539589,
      "h": 4296506885,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296506885)
  ],
  "h": 1539589
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1539589)
        
        

        //--TRIMMABLE-BOUNDARY-START(1670661)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModelTypeDescriptor`, ($self) => class SmartVoltmeterDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296637957)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296637957);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModelTypeDescriptor.GenerateProperties($.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, this, factory);
                    }, $MaSNWf ??= {"r":65537,"n":"","d":1670661,"h":0,"f":17825794}), 0, "SmartVoltmeterDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter\\Models_SmartVoltmeterDeviceSendDataModel_LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceSendDataModelTypeDescriptorBuilder.g.cs", "SmartVoltmeterDeviceSendDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296637957)
            
            //--TRIMMABLE-BOUNDARY-START(12886572549)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886572549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886572549)
            
            //--TRIMMABLE-BOUNDARY-START(17181539845)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181539845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceSendDataModel?*/ let targetBase = _target;
                $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceSendDataModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181539845)
            
            //--TRIMMABLE-BOUNDARY-START(8591605253)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591605253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591605253)
            
            static $h = 1670661;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886572549),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1670661,
      "h": 12886572549,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886572549),
//--TRIMMABLE-BOUNDARY-START(17181539845),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1539589,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1670661,
      "h": 17181539845,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181539845),
//--TRIMMABLE-BOUNDARY-START(8591605253),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1539589,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1670661,
      "h": 8591605253,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591605253)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296637957),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1670661,
      "h": 4296637957,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296637957)
  ],
  "h": 1670661
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1670661)
        
        

        //--TRIMMABLE-BOUNDARY-START(1015301)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel`, ($self) => class SmartVoltmeterDeviceReceivedDataModel extends $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$($.$nGxw.LCIDSM.FourChannelADCModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8590949893)
            /*double */ Evaluate(/*string*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590949893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    /*var*/ let interpreter = new $.$HnZw.D.Interpreter().$ctor$1();
                    const $t1 = this.Status;
                    const $t2 = this.Status;
                    const $t3 = this.Status;
                    const $t4 = this.Status;
                    return interpreter.Eval$2($.$$.S.Double, expression, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$HnZw.D.Parameter), [ new $.$HnZw.D.Parameter().$ctor$2("a0", $.$$.S.Int32.op_GreaterThan($.$ifnn($t1, ($t) => $t.Channels.length), 0) ? $.$$.System.Array.$ReadT1.call(this.Status.Channels, 0) : $.$box(0, $.$$.S.Int32)), new $.$HnZw.D.Parameter().$ctor$2("a1", $.$$.S.Int32.op_GreaterThan($.$ifnn($t2, ($t) => $t.Channels.length), 1) ? $.$$.System.Array.$ReadT1.call(this.Status.Channels, 1) : $.$box(0, $.$$.S.Int32)), new $.$HnZw.D.Parameter().$ctor$2("a2", $.$$.S.Int32.op_GreaterThan($.$ifnn($t3, ($t) => $t.Channels.length), 2) ? $.$$.System.Array.$ReadT1.call(this.Status.Channels, 2) : $.$box(0, $.$$.S.Int32)), new $.$HnZw.D.Parameter().$ctor$2("a3", $.$$.S.Int32.op_GreaterThan($.$ifnn($t4, ($t) => $t.Channels.length), 3) ? $.$$.System.Array.$ReadT1.call(this.Status.Channels, 3) : $.$box(0, $.$$.S.Int32)) ], null, null));
                }
                catch($e)
                {
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(8590949893)
            
            //--TRIMMABLE-BOUNDARY-START(4295982597)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295982597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295982597)
            
            //--TRIMMABLE-BOUNDARY-START(4295982597)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295982597)
            
            static $h = 1015301;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$($.$nGxw.LCIDSM.FourChannelADCModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590949893),
    {
      "r": 1179649,
      "p": [
        {
          "n": "expression",
          "p": 1310721
        }
      ],
      "n": "Evaluate",
      "d": 1015301,
      "h": 8590949893,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590949893)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295982597),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1015301,
      "h": 4295982597,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295982597)
  ],
  "h": 1015301
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1015301)
        
        

        //--TRIMMABLE-BOUNDARY-START(1146373)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModelTypeDescriptor`, ($self) => class SmartVoltmeterDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296113669)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296113669);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, this, factory);
                    }, $PikQxc ??= {"r":65537,"n":"","d":1146373,"h":0,"f":17825794}), 0, "SmartVoltmeterDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter\\Models_SmartVoltmeterDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "SmartVoltmeterDeviceReceivedDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296113669)
            
            //--TRIMMABLE-BOUNDARY-START(12886048261)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886048261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptor$$($.$nGxw.LCIDSM.FourChannelADCModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886048261)
            
            //--TRIMMABLE-BOUNDARY-START(17181015557)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181015557);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Devices.SerialBridge.Models.SerialBridgeDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.FourChannelADCModel>?*/ let targetBase = _target;
                $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModelTypeDescriptor$$($.$nGxw.LCIDSM.FourChannelADCModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$tKtD.LCIDSM.SerialBridgeDeviceReceivedDataModel$$($.$nGxw.LCIDSM.FourChannelADCModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181015557)
            
            //--TRIMMABLE-BOUNDARY-START(8591080965)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591080965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591080965)
            
            static $h = 1146373;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886048261),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1146373,
      "h": 12886048261,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886048261),
//--TRIMMABLE-BOUNDARY-START(17181015557),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1015301,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1146373,
      "h": 17181015557,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181015557),
//--TRIMMABLE-BOUNDARY-START(8591080965),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1015301,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1146373,
      "h": 8591080965,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591080965)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296113669),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1146373,
      "h": 4296113669,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296113669)
  ],
  "h": 1146373
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1146373)
        
        

        //--TRIMMABLE-BOUNDARY-START(3112453)
        $asm.$cls(`$nGxw.LCIDS.SmartVoltmeterDataConverter`, ($self) => class SmartVoltmeterDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298079749)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298079749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298079749)
            
            //--TRIMMABLE-BOUNDARY-START(4298079749)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298079749)
            
            static $h = 3112453;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298079749),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3112453,
      "h": 4298079749,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298079749)
  ],
  "h": 3112453
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.SmartVoltmeterDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}SmartVoltmeterDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3112453)
        
        

        //--TRIMMABLE-BOUNDARY-START(2194949)
        $asm.$cls(`$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient`, ($self) => class ISmartVoltmeterDeviceHubClient
        {
            static $h = 2194949;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2194949
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Services${separator}ISmartVoltmeterDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2194949)
        
        

        //--TRIMMABLE-BOUNDARY-START(2326021)
        $asm.$cls(`$nGxw.LCIDSS.ISmartVoltmeterRemoteService`, ($self) => class ISmartVoltmeterRemoteService
        {
            static $h = 2326021;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2326021
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Services${separator}ISmartVoltmeterRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2326021)
        
        

        $asm.$typeProxy("$nGxw.LCIDSM.SmartVoltmeterServiceModel", "$nGxw.LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterServiceModel");
        $asm.$typeProxy("$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel", "$nGxw.LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceScopeModel");
        $asm.$typeProxy("$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings", "$nGxw.LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceSettings");
        $asm.$typeProxy("$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings", "$nGxw.LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceHardwareSettings");
        $asm.$typeProxy("$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler", "$nGxw.LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterDeviceStatusHandler");
        //--TRIMMABLE-BOUNDARY-START(753157)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterDeviceModel`, ($self) => class SmartVoltmeterDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295720453)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295720453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295720453)
            
            //--TRIMMABLE-BOUNDARY-START(4295720453)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295720453)
            
            static $h = 753157;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295720453),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 753157,
      "h": 4295720453,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295720453)
  ],
  "h": 753157
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(753157)
        
        

        //--TRIMMABLE-BOUNDARY-START(2260485)
        $asm.$cls(`$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler`, ($self) => class ISmartVoltmeterDeviceStatusHandler
        {
            static $h = 2260485;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2260485
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Services${separator}ISmartVoltmeterDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2260485)
        
        

        //--TRIMMABLE-BOUNDARY-START(1801733)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterServiceModel`, ($self) => class SmartVoltmeterServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296769029)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296769029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296769029)
            
            //--TRIMMABLE-BOUNDARY-START(4296769029)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4296769029)
            
            static $h = 1801733;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296769029),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 1801733,
      "h": 4296769029,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296769029)
  ],
  "h": 1801733
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1801733)
        
        

        //--TRIMMABLE-BOUNDARY-START(2588165)
        $asm.$cls(`$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings`, ($self) => class SmartVoltmeterDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297555461)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297555461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297555461)
            
            //--TRIMMABLE-BOUNDARY-START(4297555461)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297555461)
            
            static $h = 2588165;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297555461),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2588165,
      "h": 4297555461,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297555461)
  ],
  "h": 2588165
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Settings${separator}SmartVoltmeterDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2588165)
        
        

        //--TRIMMABLE-BOUNDARY-START(1277445)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel`, ($self) => class SmartVoltmeterDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296244741)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296244741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296244741)
            
            //--TRIMMABLE-BOUNDARY-START(4296244741)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296244741)
            
            static $h = 1277445;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296244741),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1277445,
      "h": 4296244741,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296244741)
  ],
  "h": 1277445
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1277445)
        
        

        //--TRIMMABLE-BOUNDARY-START(2850309)
        $asm.$cls(`$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings`, ($self) => class SmartVoltmeterDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $self, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(12887752197)
            /*ChannelVisuaization[]?*/ Channels = null;
            //--TRIMMABLE-BOUNDARY-END(12887752197)
            
            //--TRIMMABLE-BOUNDARY-START(8592784901)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592784901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592784901)
            
            //--TRIMMABLE-BOUNDARY-START(8592784901)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8592784901)
            
            static $h = 2850309;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887752197),
    {
      "p": $.$typeArray($.$nGxw.LCIDSS$1.ChannelVisuaization).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477686789,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30067621381,
        "f": 83886081
      },
      "n": "Channels",
      "d": 2850309,
      "h": 12887752197,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12887752197)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592784901),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2850309,
      "h": 8592784901,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592784901)
  ],
  "h": 2850309
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Settings${separator}SmartVoltmeterDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2850309)
        
        

        //--TRIMMABLE-BOUNDARY-START(3374597)
        $asm.$cls(`$nGxw.LCIDS.SmartVoltmeterDeviceModelDefinition`, ($self) => class SmartVoltmeterDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4298341893)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298341893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298341893)
            
            //--TRIMMABLE-BOUNDARY-START(4298341893)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298341893)
            
            static $h = 3374597;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298341893),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3374597,
      "h": 4298341893,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298341893)
  ],
  "h": 3374597
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.SmartVoltmeterDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}SmartVoltmeterDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3374597)
        
        

        //--TRIMMABLE-BOUNDARY-START(1932805)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterServiceModelTypeDescriptor`, ($self) => class SmartVoltmeterServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296900101)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296900101);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$nGxw.LCIDSM.SmartVoltmeterServiceModelTypeDescriptor.GenerateProperties($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, this, factory);
                    }, $ZgSUmk ??= {"r":65537,"n":"","d":1932805,"h":0,"f":17825794}), 0, "SmartVoltmeterServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter\\Models_SmartVoltmeterServiceModel_LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterServiceModelTypeDescriptorBuilder.g.cs", "SmartVoltmeterServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296900101)
            
            //--TRIMMABLE-BOUNDARY-START(12886834693)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886834693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886834693)
            
            //--TRIMMABLE-BOUNDARY-START(17181801989)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181801989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceSettings, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceSendDataModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterDeviceStatusHandler, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterDeviceHubClient, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181801989)
            
            //--TRIMMABLE-BOUNDARY-START(8591867397)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591867397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$nGxw.LCIDSM.SmartVoltmeterServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$nGxw.LCIDSM.SmartVoltmeterServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.SmartVoltmeterServiceModel)))
                {
                    /*var*/ let result = $.$nGxw.LCIDSM.SmartVoltmeterServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.SmartVoltmeterServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$nGxw.LCIDSM.SmartVoltmeterServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.SmartVoltmeterServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591867397)
            
            static $h = 1932805;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886834693),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1932805,
      "h": 12886834693,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886834693),
//--TRIMMABLE-BOUNDARY-START(17181801989),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1801733,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1932805,
      "h": 17181801989,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181801989),
//--TRIMMABLE-BOUNDARY-START(8591867397),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1801733,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1932805,
      "h": 8591867397,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591867397)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296900101),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1932805,
      "h": 4296900101,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296900101)
  ],
  "h": 1932805
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1932805)
        
        

        //--TRIMMABLE-BOUNDARY-START(2719237)
        $asm.$cls(`$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettingsTypeDescriptor`, ($self) => class SmartVoltmeterDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297686533)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297686533);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, this, factory);
                    }, $nhwQCk ??= {"r":65537,"n":"","d":2719237,"h":0,"f":17825794}), 0, "SmartVoltmeterDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter\\Settings_SmartVoltmeterDeviceHardwareSettings_LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "SmartVoltmeterDeviceHardwareSettingsTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297686533)
            
            //--TRIMMABLE-BOUNDARY-START(12887621125)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887621125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887621125)
            
            //--TRIMMABLE-BOUNDARY-START(17182588421)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182588421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceSettings, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceSendDataModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterDeviceStatusHandler, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterDeviceHubClient, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).iSmartDeviceHardwareSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182588421)
            
            //--TRIMMABLE-BOUNDARY-START(8592653829)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592653829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592653829)
            
            static $h = 2719237;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887621125),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2719237,
      "h": 12887621125,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887621125),
//--TRIMMABLE-BOUNDARY-START(17182588421),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2588165,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2719237,
      "h": 17182588421,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182588421),
//--TRIMMABLE-BOUNDARY-START(8592653829),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2588165,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2719237,
      "h": 8592653829,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592653829)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297686533),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2719237,
      "h": 4297686533,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297686533)
  ],
  "h": 2719237
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Settings${separator}SmartVoltmeterDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2719237)
        
        

        //--TRIMMABLE-BOUNDARY-START(884229)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterDeviceModelTypeDescriptor`, ($self) => class SmartVoltmeterDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295851525)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295851525);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$nGxw.LCIDSM.SmartVoltmeterDeviceModelTypeDescriptor.GenerateProperties($.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, this, factory);
                    }, $qBjrkc ??= {"r":65537,"n":"","d":884229,"h":0,"f":17825794}), 0, "SmartVoltmeterDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter\\Models_SmartVoltmeterDeviceModel_LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceModelTypeDescriptorBuilder.g.cs", "SmartVoltmeterDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295851525)
            
            //--TRIMMABLE-BOUNDARY-START(12885786117)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885786117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885786117)
            
            //--TRIMMABLE-BOUNDARY-START(17180753413)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180753413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceSettings, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceSendDataModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterDeviceStatusHandler, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterDeviceHubClient, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180753413)
            
            //--TRIMMABLE-BOUNDARY-START(8590818821)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590818821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel)))
                {
                    /*var*/ let result = $.$nGxw.LCIDSM.SmartVoltmeterDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590818821)
            
            static $h = 884229;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885786117),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 884229,
      "h": 12885786117,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885786117),
//--TRIMMABLE-BOUNDARY-START(17180753413),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 753157,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 884229,
      "h": 17180753413,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180753413),
//--TRIMMABLE-BOUNDARY-START(8590818821),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 753157,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 884229,
      "h": 8590818821,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590818821)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295851525),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 884229,
      "h": 4295851525,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295851525)
  ],
  "h": 884229
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(884229)
        
        

        //--TRIMMABLE-BOUNDARY-START(1408517)
        $asm.$cls(`$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModelTypeDescriptor`, ($self) => class SmartVoltmeterDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296375813)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296375813);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModelTypeDescriptor.GenerateProperties($.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, this, factory);
                    }, $qKtBVe ??= {"r":65537,"n":"","d":1408517,"h":0,"f":17825794}), 0, "SmartVoltmeterDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter\\Models_SmartVoltmeterDeviceScopeModel_LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceScopeModelTypeDescriptorBuilder.g.cs", "SmartVoltmeterDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296375813)
            
            //--TRIMMABLE-BOUNDARY-START(12886310405)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886310405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886310405)
            
            //--TRIMMABLE-BOUNDARY-START(17181277701)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181277701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceSettings, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceSendDataModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterDeviceStatusHandler, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterDeviceHubClient, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181277701)
            
            //--TRIMMABLE-BOUNDARY-START(8591343109)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591343109);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel)))
                {
                    /*var*/ let result = $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591343109)
            
            static $h = 1408517;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886310405),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1408517,
      "h": 12886310405,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886310405),
//--TRIMMABLE-BOUNDARY-START(17181277701),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1277445,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1408517,
      "h": 17181277701,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181277701),
//--TRIMMABLE-BOUNDARY-START(8591343109),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1277445,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1408517,
      "h": 8591343109,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591343109)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296375813),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1408517,
      "h": 4296375813,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296375813)
  ],
  "h": 1408517
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Models${separator}SmartVoltmeterDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1408517)
        
        

        //--TRIMMABLE-BOUNDARY-START(2981381)
        $asm.$cls(`$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettingsTypeDescriptor`, ($self) => class SmartVoltmeterDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297948677)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297948677);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettingsTypeDescriptor.GenerateProperties($.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, this, factory);
                    }, $lSIKkf ??= {"r":65537,"n":"","d":2981381,"h":0,"f":17825794}), 0, "SmartVoltmeterDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter\\Settings_SmartVoltmeterDeviceSettings_LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceSettingsTypeDescriptorBuilder.g.cs", "SmartVoltmeterDeviceSettingsTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297948677)
            
            //--TRIMMABLE-BOUNDARY-START(12887883269)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887883269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Channels"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings.$type, $.$discardRef(), "Channels", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Channels")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$nGxw.LCIDSS$1.ChannelVisuaization), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Channels";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$nGxw.LCIDSS$1.ChannelVisuaization), ($.$cast(target, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings)).Channels);
                        }, $NfCEve ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2981381,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Channels = value.AsReference($.$typeArray($.$nGxw.LCIDSS$1.ChannelVisuaization));
                        }, $VBINNj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2981381,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887883269)
            
            //--TRIMMABLE-BOUNDARY-START(17182850565)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182850565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceSettings, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceSendDataModel, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterDeviceStatusHandler, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterDeviceHubClient, LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Services.ISmartVoltmeterRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService).iSmartDeviceSettings));
                {
                    /*var*/ let _Channels = _target.Channels;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Channels"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$nGxw.LCIDSS$1.ChannelVisuaization)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$nGxw.LCIDSS$1.ChannelVisuaization), $.$nGxw.LCIDSS$1.ChannelVisuaization));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$nGxw.LCIDSS$1.ChannelVisuaization), $.$nGxw.LCIDSS$1.ChannelVisuaization, property, $.$ref(() => _Channels, ($v) => _Channels = $v, $.$typeArray($.$nGxw.LCIDSS$1.ChannelVisuaization))))
                    {
                        _target.Channels = _Channels;
                        if (_Channels !== null)
                        {
                            let $i6 = 0;
                            let $arr6 = _Channels;
                            while ($i6 < $arr6.length)
                            {
                                let item = $arr6[$i6++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$nGxw.LCIDSS$1.ChannelVisuaization)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$nGxw.LCIDSS$1.ChannelVisuaization), $.$nGxw.LCIDSS$1.ChannelVisuaization, property, $.$ref(() => _Channels, ($v) => _Channels = $v, $.$typeArray($.$nGxw.LCIDSS$1.ChannelVisuaization)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182850565)
            
            //--TRIMMABLE-BOUNDARY-START(8592915973)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592915973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings)))
                {
                    /*var*/ let result = $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592915973)
            
            static $h = 2981381;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887883269),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2981381,
      "h": 12887883269,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887883269),
//--TRIMMABLE-BOUNDARY-START(17182850565),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2850309,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2981381,
      "h": 17182850565,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182850565),
//--TRIMMABLE-BOUNDARY-START(8592915973),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2850309,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2981381,
      "h": 8592915973,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592915973)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297948677),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2981381,
      "h": 4297948677,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297948677)
  ],
  "h": 2981381
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Settings${separator}SmartVoltmeterDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2981381)
        
        

        //--TRIMMABLE-BOUNDARY-START(3177989)
        $asm.$cls(`$nGxw.LCIDS.SmartVoltmeterDevice`, ($self) => class SmartVoltmeterDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$nGxw.LCIDSM.FourChannelADCModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4298145285)
            $ctor$2(/*IIOTDeviceFamily<SmartVoltmeterDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*SmartVoltmeterDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298145285);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298145285)
            
            //--TRIMMABLE-BOUNDARY-START(8593112581)
            /*string */ Channel(/*ChannelVisuaization*/ channel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593112581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Models.SmartVoltmeterDeviceReceivedDataModel?*/ let __ca1__;
                return _ = ((__ca1__ = this.Received) !== null ? $.$$.S.Double.ToString.call(__ca1__.Evaluate(channel.Converter)) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(8593112581)
            
            static $h = 3177989;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDS.SmartVoltmeterDevice, $.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$nGxw.LCIDSM.FourChannelADCModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593112581),
    {
      "r": 1310721,
      "p": [
        {
          "n": "channel",
          "p": 2391557
        }
      ],
      "n": "Channel",
      "d": 3177989,
      "h": 8593112581,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593112581)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298145285),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$nGxw.LCIDS.SmartVoltmeterDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 753157
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3177989,
      "h": 4298145285,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298145285)
  ],
  "h": 3177989
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.SmartVoltmeterDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}SmartVoltmeterDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3177989)
        
        

        //--TRIMMABLE-BOUNDARY-START(3243525)
        $asm.$cls(`$nGxw.LCIDS.SmartVoltmeterDeviceDefinition`, ($self) => class SmartVoltmeterDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDS.SmartVoltmeterDevice, $.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$nGxw.LCIDSM.FourChannelADCModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298210821)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298210821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298210821)
            
            //--TRIMMABLE-BOUNDARY-START(4298210821)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298210821)
            
            static $h = 3243525;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDS.SmartVoltmeterDevice, $.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$nGxw.LCIDSM.FourChannelADCModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298210821),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3243525,
      "h": 4298210821,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298210821)
  ],
  "h": 3243525
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.SmartVoltmeterDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}SmartVoltmeterDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3243525)
        
        

        //--TRIMMABLE-BOUNDARY-START(3309061)
        $asm.$cls(`$nGxw.LCIDS.SmartVoltmeterDeviceFamily`, ($self) => class SmartVoltmeterDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDS.SmartVoltmeterDevice, $.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4298276357)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<SmartVoltmeterDeviceReceivedDataModel, SmartVoltmeterDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<SmartVoltmeterDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298276357);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298276357)
            
            //--TRIMMABLE-BOUNDARY-START(8593243653)
            /*Type */ get DeviceBroadcastSendMessageEnumType()
            {
                return $.$nGxw.LCIDSS$1.SmartVoltmeterBroadcastPeerMessages.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8593243653)
            
            static $h = 3309061;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$nGxw.LCIDS.SmartVoltmeterDevice, $.$nGxw.LCIDSM.SmartVoltmeterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$nGxw.LCIDSM.SmartVoltmeterDeviceModel, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceStatusHandler, $.$nGxw.LCIDSS.ISmartVoltmeterDeviceHubClient, $.$nGxw.LCIDSS.ISmartVoltmeterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8593243653),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183178245,
        "f": 50364417
      },
      "n": "DeviceBroadcastSendMessageEnumType",
      "d": 3309061,
      "h": 8593243653,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8593243653)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298276357),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3309061,
      "h": 4298276357,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298276357)
  ],
  "h": 3309061
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$nGxw.LCIDS.SmartVoltmeterDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$nGxw.LCIDS.SmartVoltmeterDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.SmartVoltmeterDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}SmartVoltmeterDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3309061)
        
        

        //--TRIMMABLE-BOUNDARY-START(3636741)
        $asm.$cls(`$nGxw.LCIDSV.SmartVoltmeterViewRenderer`, ($self) => class SmartVoltmeterViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$nGxw.LCIDS.SmartVoltmeterDevice, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298604037)
            $ctor$3(/*IOTRootViewModel*/ root)
            {
                super.$ctor$2(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298604037);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298604037)
            
            //--TRIMMABLE-BOUNDARY-START(8593571333)
            /*RenderFragment? */ GetView(/*IClientUnitOfWork*/ ui, /*SmartVoltmeterDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>?*/ clicked, /*Func<Task>?*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593571333);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.SmartVoltmeterDeviceSettings*/ let __ca1__;
                /*LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Settings.ChannelVisuaization[]?*/ let __ca2__;
                if (type === 3/*DeviceViewType.Details*/ && (((__ca1__ = device.Settings$1) !== null ? ((__ca2__ = __ca1__.Channels) !== null ? $.$sl.SL.Enumerable.Any$1($.$nGxw.LCIDSS$1.ChannelVisuaization, __ca2__) : false) : false)))
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$nGxw.LCIDSV.SmartVoltmeterDeviceDetails, $.$nGxw.LCIDSV.SmartVoltmeterDetailsViewModel, new $.$nGxw.LCIDSV.SmartVoltmeterDetailsViewModel().$ctor$9(this.Root, device.OwnerScope, device), true, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(8593571333)
            
            static $h = 3636741;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$nGxw.LCIDS.SmartVoltmeterDevice, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593571333),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 3177989
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 3636741,
      "h": 8593571333,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8593571333)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298604037),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3636741,
      "h": 4298604037,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298604037)
  ],
  "h": 3636741
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$nGxw.LCIDS.SmartVoltmeterDevice), $.$ntej.LCICD$1.IDeviceViewRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Views.SmartVoltmeterViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Views${separator}SmartVoltmeterViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3636741)
        
        

        //--TRIMMABLE-BOUNDARY-START(3505669)
        $asm.$cls(`$nGxw.LCIDSV.SmartVoltmeterDetailsViewModel`, ($self) => class SmartVoltmeterDetailsViewModel extends $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$nGxw.LCIDS.SmartVoltmeterDevice, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298472965)
            $ctor$9(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*SmartVoltmeterDevice*/ device)
            {
                super.$ctor$8(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298472965);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298472965)
            
            static $h = 3505669;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$nGxw.LCIDS.SmartVoltmeterDevice, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings, $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceHardwareSettings, $.$nGxw.LCIDSM.SmartVoltmeterDeviceReceivedDataModel, $.$nGxw.LCIDSM.SmartVoltmeterDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298472965),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 3177989
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 3505669,
      "h": 4298472965,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298472965)
  ],
  "h": 3505669
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICDV.IDeviceDetailsViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Views.SmartVoltmeterDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Views${separator}SmartVoltmeterDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3505669)
        
        

        //--TRIMMABLE-BOUNDARY-START(3571205)
        $asm.$cls(`$nGxw.LCIDSV.SmartVoltmeterDeviceDetails`, ($self) => class SmartVoltmeterDeviceDetails extends $.$hDPm.LCFCC$1.BaseComponent$$($.$nGxw.LCIDSV.SmartVoltmeterDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(47248211461)
            /*string */ get OptimizedComponentName()
            {
                return "smartvoltmeterdevicedetails";
            }
            //--TRIMMABLE-BOUNDARY-END(47248211461)
            
            //--TRIMMABLE-BOUNDARY-START(64428080645)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64428080645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$nGxw.LCIDSV.SmartVoltmeterDetailsViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(64428080645)
            
            //--TRIMMABLE-BOUNDARY-START(68723047941)
            /*SmartVoltmeterDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(68723047941)
            
            //--TRIMMABLE-BOUNDARY-START(17183440389)
            /*PageBuilderMode*/ builderMode = 0;
            //--TRIMMABLE-BOUNDARY-END(17183440389)
            
            //--TRIMMABLE-BOUNDARY-START(60133113349)
            /*void */ ToggleBuilder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60133113349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.builderMode === 0/*PageBuilderMode.Read*/)
                {
                    this.builderMode = 1/*PageBuilderMode.EditDragDrop*/;
                }
                else 
                {
                    this.builderMode = 0/*PageBuilderMode.Read*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60133113349)
            
            //--TRIMMABLE-BOUNDARY-START(25773374981)
            /*Task *//*async*/  EditCard(/*ChannelVisuaization*/ channel)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25773374981);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.Form($.$hDPm.LCFCI.ViewConfiguration, $.$nGxw.LCIDSS$1.ChannelVisuaization, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPage, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Edit Channel", false), null, channel, null, null, 0, 4131, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    ($t3 = this.ViewModel.Device$1.UpdateAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25773374981)
            
            //--TRIMMABLE-BOUNDARY-START(12888473093)
            /*Task */ AddCard()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888473093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ChannelVisuaization*/ let channel = new $.$nGxw.LCIDSS$1.ChannelVisuaization().$ctor$1();
                this.ViewModel.Device$1.Model$1.Settings.Channels = $.$sl.SL.Enumerable.ToArray($.$nGxw.LCIDSS$1.ChannelVisuaization, $.$sl.SL.Enumerable.Concat($.$nGxw.LCIDSS$1.ChannelVisuaization, this.ViewModel.Device$1.Model$1.Settings.Channels, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$nGxw.LCIDSS$1.ChannelVisuaization), [channel], null, null)));
                return this.EditCard(channel);
            }
            //--TRIMMABLE-BOUNDARY-END(12888473093)
            
            //--TRIMMABLE-BOUNDARY-START(21478407685)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478407685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$nGxw.LCIDS.SmartVoltmeterDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$nGxw.LCIDS.SmartVoltmeterDevice), this.ViewModel));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenElement(3, "FloatingButtonPage");
                    __builder2.OpenElement(4, "ChildContent");
                    __builder2.OpenElement(5, "div");
                    __builder2.AddAttribute$5(6, "class", "row responsive");
                    this.ViewModel.Device$1.Model$1.Settings ??= new $.$nGxw.LCIDSS$1.SmartVoltmeterDeviceSettings().$ctor$4();
                    this.ViewModel.Device$1.Model$1.Settings.Channels ??= $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$nGxw.LCIDSS$1.ChannelVisuaization), null, [0], null);
                    let $i4 = 0;
                    let $arr4 = this.ViewModel.Device$1.Model$1.Settings.Channels;
                    while ($i4 < $arr4.length)
                    {
                        let channel = $arr4[$i4++];
                        /*var*/ let _channel = channel;
                        __builder2.OpenElement(7, "div");
                        __builder2.AddAttribute$5(8, "class", "miwx-15");
                        __builder2.SetKey(_channel);
                        __builder2.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 9);
                        __builder2.AddComponentParameter(10, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 21/*CardFeatures.Default*/ & ~2/*CardFeatures.Corner*/), $.$hDPm.LCFCCC$1.CardFeatures));
                        __builder2.AddComponentParameter(11, "Class", "text-center");
                        __builder2.AddComponentParameter(12, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                        {
                            return this.EditCard(_channel);
                        }, $Lopemj ??= {"r":178454529,"n":"","d":3571205,"h":0,"f":17825794})));
                        __builder2.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                        {
                            __builder3.OpenElement(14, "i");
                            __builder3.AddAttribute$5(15, "class", `fsz-100 mdi ${$.$strNN((_channel.Icon ?? "mdi-image"))} mgx-a d-block`);
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(16, "\r\n                            ");
                            __builder3.OpenElement(17, "h2");
                            __builder3.AddAttribute$5(18, "class", "mgb-0 mgt-1");
                            __builder3.AddContent$4(19, (() =>
                            {
                                var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(0, 1);
                                $handler.AppendFormatted($.$box(this.ViewModel.Device$1.Channel(_channel), $.$$.S.String), null, "f");
                                return $handler.ToStringAndClear                        ();
                            })());
                            __builder3.AddContent$4(20, _channel.Unit);
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(21, "\r\n                            ");
                            __builder3.OpenElement(22, "span");
                            __builder3.AddContent$4(23, _channel.Label);
                            __builder3.CloseElement();
                        }), $XfaFpf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":3571205,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(24, "\r\n        ");
                    __builder2.OpenElement(25, "Buttons");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 26);
                    __builder2.AddComponentParameter(27, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mdi ${$.$strNN((this.builderMode === 0/*PageBuilderMode.Read*/ ? "mdi-pencil" : "mdi-check"))} mg round shadow hx-05 wx-05 fsz-35`));
                    __builder2.AddComponentParameter(28, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder2.AddComponentParameter(29, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToggleBuilder))));
                    __builder2.AddComponentParameter(30, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                }), $fLDZvg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3571205,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21478407685)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8593505797)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593505797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593505797)
            
            //--TRIMMABLE-BOUNDARY-START(8593505797)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8593505797)
            
            static $h = 3571205;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$nGxw.LCIDSV.SmartVoltmeterDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47248211461),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34363309573,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 3571205,
      "h": 47248211461,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47248211461),
//--TRIMMABLE-BOUNDARY-START(68723047941),
    {
      "p": 3505669,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42953244165,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55838146053,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 3571205,
      "h": 68723047941,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68723047941)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64428080645),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 3571205,
      "h": 64428080645,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64428080645),
//--TRIMMABLE-BOUNDARY-START(60133113349),
    {
      "r": 65537,
      "n": "ToggleBuilder",
      "d": 3571205,
      "h": 60133113349,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60133113349),
//--TRIMMABLE-BOUNDARY-START(25773374981),
    {
      "r": 178454529,
      "p": [
        {
          "n": "channel",
          "p": 2391557
        }
      ],
      "n": "EditCard",
      "d": 3571205,
      "h": 25773374981,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(25773374981),
//--TRIMMABLE-BOUNDARY-START(12888473093),
    {
      "r": 178454529,
      "n": "AddCard",
      "d": 3571205,
      "h": 12888473093,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12888473093),
//--TRIMMABLE-BOUNDARY-START(21478407685),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 3571205,
      "h": 21478407685,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21478407685)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17183440389),
    {
      "t": 66606762,
      "n": "builderMode",
      "d": 3571205,
      "h": 17183440389,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17183440389)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593505797),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3571205,
      "h": 8593505797,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593505797)
  ],
  "h": 3571205
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SerialBridgeVoltmeter.Views.SmartVoltmeterDeviceDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SerialBridgeVoltmeter${separator}Views${separator}SmartVoltmeterDeviceDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3571205)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor", "NetJs.LivingThing.Core.IOT.Devices.SerialBridge"));
})();
//--TRIMMABLE-BOUNDARY-END(32261)
