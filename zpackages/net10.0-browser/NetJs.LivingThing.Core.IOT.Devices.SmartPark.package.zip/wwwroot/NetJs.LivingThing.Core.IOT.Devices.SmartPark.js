
//--TRIMMABLE-BOUNDARY-START(50491)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $GJuEOf;
    let $eAsRXh;
    let $aHqGYa;
    let $xJLQNi;
    let $wGRYol;
    let $gTSbpg;
    let $ZCjxBf;
    let $TVZgah;
    let $TQzmyf;
    let $kJFsFe;
    let $tLtsYf;
    let $tFeCxc;
    let $VNlzze;
    let $nrAkeh;
    let $xmgalj;
    let $jnXWsf;
    let $jYmbUj;
    let $oVCcKg;
    let $CErlYk;
    let $xtHudf;
    let $eNcWUk;
    let $qKnRgf;
    let $phuemg;
    let $fRxdle;
    let $eNDZDb;
    let $ohpuhj;
    let $SMWqAd;
    let $bHtRgj;
    let $aaDqjd;
    let $HThDIj;
    let $CIDfwf;
    let $dDEZHj;
    let $XqcAie;
    let $JMtpMj;
    let $TONSwk;
    let $RJDXla;
    let $yfMMdc;
    let $DsvWfl;
    let $KXZpda;
    let $Cwudii;
    let $xjFZwc;
    let $haRqNf;
    let $YHTQTd;
    let $dkJOui;
    let $qzSyGa;
    let $KgVbgh;
    let $TVUjGe;
    let $tiKzwd;
    let $cFbMgb;
    let $iKjQkd;
    let $Ulawei;
    let $uFxppi;
    let $CxKyEb;
    let $cmuIjg;
    let $NlxKna;
    let $SxdGEh;
    let $VITKRi;
    let $iqRVub;
    let $wbBulg;
    let $HhtcIg;
    let $krTWRd;
    let $iPqQTk;
    let $xGxxMb;
    let $qTFkob;
    let $apUyjg;
    let $RuJoeb;
    let $pgargg;
    let $gVpfik;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.SmartPark", 
    {
  "h": 50491,
  "f": "LivingThing.Core.IOT.Devices.SmartPark",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.SmartPark",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.SmartPark",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5TbWFydFBhcmsuU21hcnRQYXJrRGV2aWNlIjogew0KICAgICAgIkNhdGVnb3JpZXMiOiBbICJTbWFydCBIb21lIiBdLA0KICAgICAgIk5hbWUiOiAiU21hcnRQYXJrIiwNCiAgICAgICJJY29uIjogeyAiTmFtZSI6ICJtZGkgbWRpLXBvd2VyIiB9LA0KICAgICAgIlRoZW1lQ29sb3IiOiAiI2Q5NTc2MyIsDQogICAgICAiZkZsYWdzIjogIkZlYXR1cmVkLFB1Ymxpc2hlZCIsDQogICAgICAiQmFubmVySW1hZ2UiOiAifi9TbWFydFBhcmsvaW1nL2Jhbm5lci5qcGciLA0KICAgICAgIlNlY3VyaXRpZXMiOiAiQ2hhbGxlbmdlSGFuZFNoYWtlQXV0aGVudGljYXRpb25Qcm90b2NvbCxBZHZhbmNlZEVuY3J5cHRpb25TdGFuZGFyZCxFbGxpcHRpY0N1cnZlRmlybXdhcmVVcGRhdGVTaWduaW5nIg0KICAgIH0NCiAgfQ0KfQ=="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(836923)
        $asm.$cls(`$pgHg.LCIDSMC.SmartParkCheckInResponseModelCustomAttributesProvider`, ($self) => class SmartParkCheckInResponseModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295804219)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295804219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceCommandResponseModelCustomAttributesProvider$$($.$pgHg.LCIDSMC.SmartParkCheckInResponseData).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295804219)
            
            static $h = 836923;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295804219),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 836923,
      "h": 4295804219,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295804219)
  ],
  "h": 836923
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInResponseModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Controls${separator}SmartParkCheckInResponseModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(836923)
        
        

        //--TRIMMABLE-BOUNDARY-START(2147643)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkDeviceScopeModelCustomAttributesProvider`, ($self) => class SmartParkDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297114939)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297114939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297114939)
            
            static $h = 2147643;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297114939),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2147643,
      "h": 4297114939,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297114939)
  ],
  "h": 2147643
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2147643)
        
        

        //--TRIMMABLE-BOUNDARY-START(1885499)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class SmartParkDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296852795)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296852795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$pgHg.LCIDSMS.SmartParkPowerStatusModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296852795)
            
            static $h = 1885499;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296852795),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1885499,
      "h": 4296852795,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296852795)
  ],
  "h": 1885499
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1885499)
        
        

        //--TRIMMABLE-BOUNDARY-START(378171)
        $asm.$cls(`$pgHg.LCIDS.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295345467)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295345467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295345467)
            
            static $h = 378171;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295345467),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 378171,
      "h": 4295345467,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295345467)
  ],
  "h": 378171
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(378171)
        
        

        //--TRIMMABLE-BOUNDARY-START(2934075)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkLogTypeCustomAttributesProvider`, ($self) => class SmartParkLogTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297901371)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297901371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297901371)
            
            static $h = 2934075;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297901371),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2934075,
      "h": 4297901371,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297901371)
  ],
  "h": 2934075
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkLogTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkLogTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2934075)
        
        

        //--TRIMMABLE-BOUNDARY-START(4113723)
        $asm.$cls(`$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class SmartParkDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299081019)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299081019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299081019)
            
            static $h = 4113723;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299081019),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4113723,
      "h": 4299081019,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299081019)
  ],
  "h": 4113723
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Settings${separator}SmartParkDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4113723)
        
        

        //--TRIMMABLE-BOUNDARY-START(1492283)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkControlTypeCustomAttributesProvider`, ($self) => class SmartParkControlTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296459579)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296459579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296459579)
            
            static $h = 1492283;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296459579),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1492283,
      "h": 4296459579,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296459579)
  ],
  "h": 1492283
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkControlTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkControlTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1492283)
        
        

        //--TRIMMABLE-BOUNDARY-START(1623355)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkDeviceModelCustomAttributesProvider`, ($self) => class SmartParkDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296590651)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296590651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296590651)
            
            static $h = 1623355;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296590651),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1623355,
      "h": 4296590651,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296590651)
  ],
  "h": 1623355
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1623355)
        
        

        //--TRIMMABLE-BOUNDARY-START(509243)
        $asm.$cls(`$pgHg.LCIDSMC.SmartParkCheckInRequestModelCustomAttributesProvider`, ($self) => class SmartParkCheckInRequestModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295476539)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295476539)
            
            //--TRIMMABLE-BOUNDARY-START(8590443835)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590443835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$pgHg.LCIDSMC.SmartParkCheckInRequestModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Card", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            $i3.ConvertType = ($.$$.S.Byte.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$pgHg.LCIDSMC.SmartParkCheckInRequestModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $eAsRXh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":509243,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $aHqGYa ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":509243,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590443835)
            
            static $h = 509243;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590443835),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 509243,
      "h": 8590443835,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590443835)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295476539),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 509243,
      "h": 4295476539,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295476539)
  ],
  "h": 509243
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInRequestModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Controls${separator}SmartParkCheckInRequestModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(509243)
        
        

        //--TRIMMABLE-BOUNDARY-START(181563)
        $asm.$cls(`$pgHg.LCIDS._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295148859)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295148859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$pgHg.LCIDS.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295148859)
            
            static $h = 181563;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295148859),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 181563,
      "h": 4295148859,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295148859)
  ],
  "h": 181563
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(181563)
        
        

        //--TRIMMABLE-BOUNDARY-START(3065147)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkServiceModelCustomAttributesProvider`, ($self) => class SmartParkServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298032443)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298032443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298032443)
            
            static $h = 3065147;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298032443),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3065147,
      "h": 4298032443,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298032443)
  ],
  "h": 3065147
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3065147)
        
        

        //--TRIMMABLE-BOUNDARY-START(1361211)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkBroadcastActionTypeCustomAttributesProvider`, ($self) => class SmartParkBroadcastActionTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296328507)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296328507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296328507)
            
            static $h = 1361211;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296328507),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1361211,
      "h": 4296328507,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296328507)
  ],
  "h": 1361211
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkBroadcastActionTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkBroadcastActionTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1361211)
        
        

        //--TRIMMABLE-BOUNDARY-START(3327291)
        $asm.$cls(`$pgHg.LCIDSMS.SmartParkPowerStatusModelCustomAttributesProvider`, ($self) => class SmartParkPowerStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298294587)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298294587)
            
            //--TRIMMABLE-BOUNDARY-START(8593261883)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593261883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$pgHg.LCIDSMS.SmartParkPowerStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Status", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.ConvertType = ($.$$.S.Byte.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Balance", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.ConvertType = ($.$$.S.UInt16.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Ids", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$pgHg.LCIDSMS.SmartParkPowerStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $kJFsFe ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3327291,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $tLtsYf ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3327291,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593261883)
            
            static $h = 3327291;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593261883),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3327291,
      "h": 8593261883,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593261883)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298294587),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3327291,
      "h": 4298294587,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298294587)
  ],
  "h": 3327291
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Statuses.SmartParkPowerStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Statuses${separator}SmartParkPowerStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3327291)
        
        

        //--TRIMMABLE-BOUNDARY-START(2671931)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkLogModelCustomAttributesProvider`, ($self) => class SmartParkLogModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297639227)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297639227)
            
            //--TRIMMABLE-BOUNDARY-START(8592606523)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592606523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$pgHg.LCIDSM.SmartParkLogModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Type", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Time", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.ConvertType = ($.$$.S.UInt32.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Value", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$pgHg.LCIDSM.SmartParkLogModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $xJLQNi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2671931,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $wGRYol ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2671931,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592606523)
            
            static $h = 2671931;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592606523),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2671931,
      "h": 8592606523,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592606523)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297639227),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2671931,
      "h": 4297639227,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297639227)
  ],
  "h": 2671931
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkLogModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkLogModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2671931)
        
        

        //--TRIMMABLE-BOUNDARY-START(2278715)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkDeviceScopeModelTypeDescriptorBuilder`, ($self) => class SmartParkDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592213307)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592213307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$pgHg.LCIDSM.SmartParkDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$pgHg.LCIDSM.SmartParkDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $gTSbpg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2278715,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$pgHg.LCIDSM.SmartParkDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592213307)
            
            //--TRIMMABLE-BOUNDARY-START(4297246011)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297246011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297246011)
            
            //--TRIMMABLE-BOUNDARY-START(4297246011)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297246011)
            
            static $h = 2278715;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592213307),
    {
      "r": 65537,
      "n": "Register",
      "d": 2278715,
      "h": 8592213307,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592213307)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297246011),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2278715,
      "h": 4297246011,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297246011)
  ],
  "h": 2278715
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2278715)
        
        

        //--TRIMMABLE-BOUNDARY-START(312635)
        $asm.$cls(`$pgHg.LCIDS.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295279931)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295279931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$pgHg.LCIDSMC.SmartParkCheckInRequestModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$pgHg.LCIDSMC.SmartParkCheckInRequestModelCustomAttributesProvider, $.$pgHg.LCIDSMC.SmartParkCheckInRequestModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$pgHg.LCIDSMC.SmartParkCheckInResponseModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$pgHg.LCIDSMC.SmartParkCheckInResponseModelCustomAttributesProvider, $.$pgHg.LCIDSMC.SmartParkCheckInResponseModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$pgHg.LCIDSMC.SmartParkTopupModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$pgHg.LCIDSMC.SmartParkTopupModelCustomAttributesProvider, $.$pgHg.LCIDSMC.SmartParkTopupModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$pgHg.LCIDSM.SmartParkBroadcastActionType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$pgHg.LCIDSM.SmartParkBroadcastActionTypeCustomAttributesProvider, $.$pgHg.LCIDSM.SmartParkBroadcastActionTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$pgHg.LCIDSM.SmartParkDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$pgHg.LCIDSM.SmartParkDeviceModelCustomAttributesProvider, $.$pgHg.LCIDSM.SmartParkDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModelCustomAttributesProvider, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$pgHg.LCIDSM.SmartParkDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$pgHg.LCIDSM.SmartParkDeviceScopeModelCustomAttributesProvider, $.$pgHg.LCIDSM.SmartParkDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$pgHg.LCIDSM.SmartParkControlType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$pgHg.LCIDSM.SmartParkControlTypeCustomAttributesProvider, $.$pgHg.LCIDSM.SmartParkControlTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$pgHg.LCIDSM.SmartParkDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$pgHg.LCIDSM.SmartParkDeviceSendDataModelCustomAttributesProvider, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$pgHg.LCIDSM.SmartParkLogType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$pgHg.LCIDSM.SmartParkLogTypeCustomAttributesProvider, $.$pgHg.LCIDSM.SmartParkLogTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$pgHg.LCIDSM.SmartParkLogModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$pgHg.LCIDSM.SmartParkLogModelCustomAttributesProvider, $.$pgHg.LCIDSM.SmartParkLogModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$pgHg.LCIDSM.SmartParkServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$pgHg.LCIDSM.SmartParkServiceModelCustomAttributesProvider, $.$pgHg.LCIDSM.SmartParkServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$pgHg.LCIDSMS.SmartParkPowerStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$pgHg.LCIDSMS.SmartParkPowerStatusModelCustomAttributesProvider, $.$pgHg.LCIDSMS.SmartParkPowerStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettingsCustomAttributesProvider, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$pgHg.LCIDSS$1.SmartParkDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$pgHg.LCIDSS$1.SmartParkDeviceSettingsCustomAttributesProvider, $.$pgHg.LCIDSS$1.SmartParkDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295279931)
            
            static $h = 312635;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295279931),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 312635,
      "h": 4295279931,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295279931)
  ],
  "h": 312635
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(312635)
        
        

        //--TRIMMABLE-BOUNDARY-START(2409787)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkDeviceSendDataModelCustomAttributesProvider`, ($self) => class SmartParkDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297377083)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297377083)
            
            //--TRIMMABLE-BOUNDARY-START(8592344379)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592344379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$pgHg.LCIDSM.SmartParkDeviceSendDataModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("OnOff", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (13432);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$pgHg.LCIDSM.SmartParkDeviceSendDataModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $TVZgah ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2409787,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $TQzmyf ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2409787,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandsModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592344379)
            
            static $h = 2409787;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592344379),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2409787,
      "h": 8592344379,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592344379)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297377083),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2409787,
      "h": 4297377083,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297377083)
  ],
  "h": 2409787
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2409787)
        
        

        //--TRIMMABLE-BOUNDARY-START(3196219)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkServiceModelTypeDescriptorBuilder`, ($self) => class SmartParkServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593130811)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593130811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$pgHg.LCIDSM.SmartParkServiceModelTypeDescriptor()
                        const $t1 = $.$pgHg.LCIDSM.SmartParkServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $xmgalj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3196219,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$pgHg.LCIDSM.SmartParkServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593130811)
            
            //--TRIMMABLE-BOUNDARY-START(4298163515)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298163515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298163515)
            
            //--TRIMMABLE-BOUNDARY-START(4298163515)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298163515)
            
            static $h = 3196219;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593130811),
    {
      "r": 65537,
      "n": "Register",
      "d": 3196219,
      "h": 8593130811,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593130811)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298163515),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3196219,
      "h": 4298163515,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298163515)
  ],
  "h": 3196219
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3196219)
        
        

        //--TRIMMABLE-BOUNDARY-START(1099067)
        $asm.$cls(`$pgHg.LCIDSMC.SmartParkTopupModelCustomAttributesProvider`, ($self) => class SmartParkTopupModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296066363)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296066363)
            
            //--TRIMMABLE-BOUNDARY-START(8591033659)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591033659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$pgHg.LCIDSMC.SmartParkTopupModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Card", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            $i3.ConvertType = ($.$$.S.Byte.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Amount", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (4);
                            $i4.ConvertType = ($.$$.S.Byte.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$pgHg.LCIDSMC.SmartParkTopupModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $jYmbUj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1099067,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $oVCcKg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1099067,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591033659)
            
            static $h = 1099067;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591033659),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1099067,
      "h": 8591033659,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591033659)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296066363),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1099067,
      "h": 4296066363,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296066363)
  ],
  "h": 1099067
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkTopupModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Controls${separator}SmartParkTopupModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1099067)
        
        

        //--TRIMMABLE-BOUNDARY-START(1230139)
        $asm.$cls(`$pgHg.LCIDSMC.SmartParkTopupModelTypeDescriptorBuilder`, ($self) => class SmartParkTopupModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591164731)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591164731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$pgHg.LCIDSMC.SmartParkTopupModelTypeDescriptor()
                        const $t1 = $.$pgHg.LCIDSMC.SmartParkTopupModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkTopupModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $XqcAie ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1230139,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$pgHg.LCIDSMC.SmartParkTopupModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591164731)
            
            //--TRIMMABLE-BOUNDARY-START(4296197435)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296197435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296197435)
            
            //--TRIMMABLE-BOUNDARY-START(4296197435)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296197435)
            
            static $h = 1230139;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591164731),
    {
      "r": 65537,
      "n": "Register",
      "d": 1230139,
      "h": 8591164731,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591164731)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296197435),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1230139,
      "h": 4296197435,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296197435)
  ],
  "h": 1230139
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkTopupModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Controls${separator}SmartParkTopupModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1230139)
        
        

        //--TRIMMABLE-BOUNDARY-START(2016571)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class SmartParkDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591951163)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591951163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $CErlYk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2016571,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591951163)
            
            //--TRIMMABLE-BOUNDARY-START(4296983867)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296983867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296983867)
            
            //--TRIMMABLE-BOUNDARY-START(4296983867)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296983867)
            
            static $h = 2016571;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591951163),
    {
      "r": 65537,
      "n": "Register",
      "d": 2016571,
      "h": 8591951163,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591951163)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296983867),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2016571,
      "h": 4296983867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296983867)
  ],
  "h": 2016571
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2016571)
        
        

        //--TRIMMABLE-BOUNDARY-START(3458363)
        $asm.$cls(`$pgHg.LCIDSMS.SmartParkPowerStatusModelTypeDescriptorBuilder`, ($self) => class SmartParkPowerStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593392955)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593392955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$pgHg.LCIDSMS.SmartParkPowerStatusModelTypeDescriptor()
                        const $t1 = $.$pgHg.LCIDSMS.SmartParkPowerStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SmartPark.Models.Statuses.SmartParkPowerStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $YHTQTd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3458363,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$pgHg.LCIDSMS.SmartParkPowerStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593392955)
            
            //--TRIMMABLE-BOUNDARY-START(4298425659)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298425659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298425659)
            
            //--TRIMMABLE-BOUNDARY-START(4298425659)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298425659)
            
            static $h = 3458363;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593392955),
    {
      "r": 65537,
      "n": "Register",
      "d": 3458363,
      "h": 8593392955,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593392955)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298425659),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3458363,
      "h": 4298425659,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298425659)
  ],
  "h": 3458363
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Statuses.SmartParkPowerStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Statuses${separator}SmartParkPowerStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3458363)
        
        

        //--TRIMMABLE-BOUNDARY-START(4375867)
        $asm.$cls(`$pgHg.LCIDSS$1.SmartParkDeviceSettingsCustomAttributesProvider`, ($self) => class SmartParkDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299343163)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299343163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299343163)
            
            static $h = 4375867;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299343163),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4375867,
      "h": 4299343163,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299343163)
  ],
  "h": 4375867
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Settings${separator}SmartParkDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4375867)
        
        

        //--TRIMMABLE-BOUNDARY-START(4506939)
        $asm.$cls(`$pgHg.LCIDSS$1.SmartParkDeviceSettingsTypeDescriptorBuilder`, ($self) => class SmartParkDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594441531)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594441531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$pgHg.LCIDSS$1.SmartParkDeviceSettingsTypeDescriptor()
                        const $t1 = $.$pgHg.LCIDSS$1.SmartParkDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $eNDZDb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4506939,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$pgHg.LCIDSS$1.SmartParkDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594441531)
            
            //--TRIMMABLE-BOUNDARY-START(4299474235)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299474235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299474235)
            
            //--TRIMMABLE-BOUNDARY-START(4299474235)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299474235)
            
            static $h = 4506939;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594441531),
    {
      "r": 65537,
      "n": "Register",
      "d": 4506939,
      "h": 8594441531,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594441531)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299474235),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4506939,
      "h": 4299474235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299474235)
  ],
  "h": 4506939
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Settings${separator}SmartParkDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4506939)
        
        

        //--TRIMMABLE-BOUNDARY-START(2540859)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class SmartParkDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592475451)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592475451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$pgHg.LCIDSM.SmartParkDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$pgHg.LCIDSM.SmartParkDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $eNcWUk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2540859,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$pgHg.LCIDSM.SmartParkDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592475451)
            
            //--TRIMMABLE-BOUNDARY-START(4297508155)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297508155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297508155)
            
            //--TRIMMABLE-BOUNDARY-START(4297508155)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297508155)
            
            static $h = 2540859;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592475451),
    {
      "r": 65537,
      "n": "Register",
      "d": 2540859,
      "h": 8592475451,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592475451)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297508155),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2540859,
      "h": 4297508155,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297508155)
  ],
  "h": 2540859
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2540859)
        
        

        //--TRIMMABLE-BOUNDARY-START(967995)
        $asm.$cls(`$pgHg.LCIDSMC.SmartParkCheckInResponseModelTypeDescriptorBuilder`, ($self) => class SmartParkCheckInResponseModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590902587)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590902587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$pgHg.LCIDSMC.SmartParkCheckInResponseModelTypeDescriptor()
                        const $t1 = $.$pgHg.LCIDSMC.SmartParkCheckInResponseModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInResponseModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $aaDqjd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":967995,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$pgHg.LCIDSMC.SmartParkCheckInResponseModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590902587)
            
            //--TRIMMABLE-BOUNDARY-START(4295935291)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295935291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295935291)
            
            //--TRIMMABLE-BOUNDARY-START(4295935291)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295935291)
            
            static $h = 967995;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590902587),
    {
      "r": 65537,
      "n": "Register",
      "d": 967995,
      "h": 8590902587,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590902587)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295935291),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 967995,
      "h": 4295935291,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295935291)
  ],
  "h": 967995
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInResponseModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Controls${separator}SmartParkCheckInResponseModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(967995)
        
        

        //--TRIMMABLE-BOUNDARY-START(4244795)
        $asm.$cls(`$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class SmartParkDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594179387)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594179387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $CIDfwf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4244795,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594179387)
            
            //--TRIMMABLE-BOUNDARY-START(4299212091)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299212091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299212091)
            
            //--TRIMMABLE-BOUNDARY-START(4299212091)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299212091)
            
            static $h = 4244795;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594179387),
    {
      "r": 65537,
      "n": "Register",
      "d": 4244795,
      "h": 8594179387,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594179387)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299212091),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4244795,
      "h": 4299212091,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299212091)
  ],
  "h": 4244795
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Settings${separator}SmartParkDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4244795)
        
        

        //--TRIMMABLE-BOUNDARY-START(2803003)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkLogModelTypeDescriptorBuilder`, ($self) => class SmartParkLogModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592737595)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592737595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$pgHg.LCIDSM.SmartParkLogModelTypeDescriptor()
                        const $t1 = $.$pgHg.LCIDSM.SmartParkLogModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkLogModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $iqRVub ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2803003,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$pgHg.LCIDSM.SmartParkLogModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592737595)
            
            //--TRIMMABLE-BOUNDARY-START(4297770299)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297770299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297770299)
            
            //--TRIMMABLE-BOUNDARY-START(4297770299)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297770299)
            
            static $h = 2803003;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592737595),
    {
      "r": 65537,
      "n": "Register",
      "d": 2803003,
      "h": 8592737595,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592737595)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297770299),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2803003,
      "h": 4297770299,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297770299)
  ],
  "h": 2803003
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkLogModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkLogModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2803003)
        
        

        //--TRIMMABLE-BOUNDARY-START(640315)
        $asm.$cls(`$pgHg.LCIDSMC.SmartParkCheckInRequestModelTypeDescriptorBuilder`, ($self) => class SmartParkCheckInRequestModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590574907)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590574907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$pgHg.LCIDSMC.SmartParkCheckInRequestModelTypeDescriptor()
                        const $t1 = $.$pgHg.LCIDSMC.SmartParkCheckInRequestModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInRequestModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $CxKyEb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":640315,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$pgHg.LCIDSMC.SmartParkCheckInRequestModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590574907)
            
            //--TRIMMABLE-BOUNDARY-START(4295607611)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295607611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295607611)
            
            //--TRIMMABLE-BOUNDARY-START(4295607611)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295607611)
            
            static $h = 640315;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590574907),
    {
      "r": 65537,
      "n": "Register",
      "d": 640315,
      "h": 8590574907,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590574907)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295607611),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 640315,
      "h": 4295607611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295607611)
  ],
  "h": 640315
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInRequestModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Controls${separator}SmartParkCheckInRequestModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(640315)
        
        

        //--TRIMMABLE-BOUNDARY-START(1754427)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkDeviceModelTypeDescriptorBuilder`, ($self) => class SmartParkDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591689019)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591689019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$pgHg.LCIDSM.SmartParkDeviceModelTypeDescriptor()
                        const $t1 = $.$pgHg.LCIDSM.SmartParkDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Ulawei ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1754427,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$pgHg.LCIDSM.SmartParkDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591689019)
            
            //--TRIMMABLE-BOUNDARY-START(4296721723)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296721723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296721723)
            
            //--TRIMMABLE-BOUNDARY-START(4296721723)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296721723)
            
            static $h = 1754427;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591689019),
    {
      "r": 65537,
      "n": "Register",
      "d": 1754427,
      "h": 8591689019,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591689019)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296721723),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1754427,
      "h": 4296721723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296721723)
  ],
  "h": 1754427
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1754427)
        
        

        //--TRIMMABLE-BOUNDARY-START(4900155)
        $asm.$cls(`$pgHg.LCIDS.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4299867451)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299867451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$pgHg.LCIDSMC.SmartParkCheckInRequestModelTypeDescriptorBuilder.Register();
                $.$pgHg.LCIDSMC.SmartParkCheckInResponseModelTypeDescriptorBuilder.Register();
                $.$pgHg.LCIDSMC.SmartParkTopupModelTypeDescriptorBuilder.Register();
                $.$pgHg.LCIDSM.SmartParkDeviceModelTypeDescriptorBuilder.Register();
                $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$pgHg.LCIDSM.SmartParkDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$pgHg.LCIDSM.SmartParkDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$pgHg.LCIDSM.SmartParkLogModelTypeDescriptorBuilder.Register();
                $.$pgHg.LCIDSM.SmartParkServiceModelTypeDescriptorBuilder.Register();
                $.$pgHg.LCIDSMS.SmartParkPowerStatusModelTypeDescriptorBuilder.Register();
                $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$pgHg.LCIDSS$1.SmartParkDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4299867451)
            
            static $h = 4900155;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299867451),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 4900155,
      "h": 4299867451,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4299867451)
  ],
  "h": 4900155
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4900155)
        
        

        //--TRIMMABLE-BOUNDARY-START(247099)
        $asm.$cls(`$pgHg.LCIDS.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180116283)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180116283)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295214395)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295214395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295214395)
            
            //--TRIMMABLE-BOUNDARY-START(4295214395)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295214395)
            
            static $h = 247099;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180116283),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885148987,
        "f": 50331649
      },
      "n": "Paths",
      "d": 247099,
      "h": 17180116283,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180116283)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295214395),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 247099,
      "h": 4295214395,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295214395)
  ],
  "h": 247099
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(247099)
        
        

        //--TRIMMABLE-BOUNDARY-START(2606395)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkLogModel`, ($self) => class SmartParkLogModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(115966723387)
            /*SmartParkLogType*/ Type = 0;
            //--TRIMMABLE-BOUNDARY-END(115966723387)
            
            //--TRIMMABLE-BOUNDARY-START(107376788795)
            /*DateTime*/ Time;
            //--TRIMMABLE-BOUNDARY-END(107376788795)
            
            //--TRIMMABLE-BOUNDARY-START(120261690683)
            /*int*/ Value = 0;
            //--TRIMMABLE-BOUNDARY-END(120261690683)
            
            //--TRIMMABLE-BOUNDARY-START(111671756091)
            /*string */ get Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837181243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Enum.ToStringT($.$pgHg.LCIDSM.SmartParkLogType, $.$$.S.Byte, this.Type));
            }
            //--TRIMMABLE-BOUNDARY-END(111671756091)
            
            //--TRIMMABLE-BOUNDARY-START(21477442875)
            /*string */ get Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067377467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(this.Type)
                {
                    case 1/*SmartParkLogType.ChangedState*/:
                    return this.Value > 0 ? "Was turned on" : "Wast turned off";
                    case 2/*SmartParkLogType.SetCountdown*/:
                    return `Set countdown for ${$.$strNN(this.Value)}s`;
                    case 3/*SmartParkLogType.CountdownTimeout*/:
                    return `${$.$strNN((this.Value > 0 ? "ON" : "OFF"))} at countdown timeout`;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(21477442875)
            
            //--TRIMMABLE-BOUNDARY-START(77312017723)
            /*string */ get Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657312059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(this.Type)
                {
                    case 1/*SmartParkLogType.ChangedState*/:
                    return this.Value > 0 ? "mdi mdi-electric-switch-closed"/*MaterialDesignIconNames.ElectricSwitchClosed*/ : "mdi mdi-electric-switch"/*MaterialDesignIconNames.ElectricSwitch*/;
                    case 2/*SmartParkLogType.SetCountdown*/:
                    return "mdi mdi-counter"/*MaterialDesignIconNames.Counter*/;
                    case 3/*SmartParkLogType.CountdownTimeout*/:
                    return "mdi mdi-alarm-bell"/*MaterialDesignIconNames.AlarmBell*/;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(77312017723)
            
            //--TRIMMABLE-BOUNDARY-START(17182475579)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182475579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182475579)
            
            //--TRIMMABLE-BOUNDARY-START(17182475579)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17182475579)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(107376788795)
                this.Time = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(107376788795)
                
            }
            static $h = 2606395;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115966723387),
    {
      "p": 2868539,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427115835,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94491886907,
        "f": 83886081
      },
      "n": "Type",
      "d": 2606395,
      "h": 115966723387,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115966723387),
//--TRIMMABLE-BOUNDARY-START(107376788795),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247246651,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85901952315,
        "f": 83886081
      },
      "n": "Time",
      "d": 2606395,
      "h": 107376788795,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 720897,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107376788795),
//--TRIMMABLE-BOUNDARY-START(120261690683),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73017050427,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103081821499,
        "f": 83886081
      },
      "n": "Value",
      "d": 2606395,
      "h": 120261690683,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120261690683),
//--TRIMMABLE-BOUNDARY-START(111671756091),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837181243,
        "f": 50331649
      },
      "n": "Title",
      "d": 2606395,
      "h": 111671756091,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111671756091),
//--TRIMMABLE-BOUNDARY-START(21477442875),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067377467,
        "f": 50331649
      },
      "n": "Description",
      "d": 2606395,
      "h": 21477442875,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477442875),
//--TRIMMABLE-BOUNDARY-START(77312017723),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657312059,
        "f": 50331649
      },
      "n": "Icon",
      "d": 2606395,
      "h": 77312017723,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77312017723)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182475579),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2606395,
      "h": 17182475579,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182475579)
  ],
  "h": 2606395
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkLogModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkLogModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2606395)
        
        

        //--TRIMMABLE-BOUNDARY-START(3523899)
        $asm.$cls(`$pgHg.LCIDS.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17183393083)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$pgHg.LCIDSV.SmartParkDeviceDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$pgHg.LCIDSV.SmartParkDeviceDetails().$ctor$4();
                    }, $GJuEOf ??= {"r":2752627,"n":"","d":3523899,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17183393083)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4298491195)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298491195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298491195)
            
            //--TRIMMABLE-BOUNDARY-START(4298491195)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298491195)
            
            static $h = 3523899;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183393083),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888425787,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 3523899,
      "h": 17183393083,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17183393083)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298491195),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3523899,
      "h": 4298491195,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298491195)
  ],
  "h": 3523899
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3523899)
        
        

        //--TRIMMABLE-BOUNDARY-START(3786043)
        $asm.$cls(`$pgHg.LCIDS.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593720635)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593720635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$pgHg.LCIDS.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$pgHg.LCIDS.SmartParkDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$pgHg.LCIDS.SmartParkDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$pgHg.LCIDS.SmartParkDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$pgHg.LCIDS.SmartParkDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$pgHg.LCIDS.SmartParkDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pgHg.LCIDS.SmartParkDeviceFamily, x);
                }, $tFeCxc ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":3786043,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pgHg.LCIDS.SmartParkDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$pgHg.LCIDS.SmartParkDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $VNlzze ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":3786043,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$pgHg.LCIDS.SmartParkDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pgHg.LCIDS.SmartParkDeviceFamily, x);
                }, $nrAkeh ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$pgHg.LCIDS.SmartParkDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":3786043,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$pgHg.LCIDS.SmartParkDevice, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$pgHg.LCIDS.SmartParkDevice, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$pgHg.LCIDS.SmartParkDevice, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$pgHg.LCIDS.SmartParkDevice), $.$pgHg.LCIDSPC.SmartParkDeviceCommands$$($.$pgHg.LCIDS.SmartParkDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$pgHg.LCIDS.SmartParkDevice), $.$pgHg.LCIDSV.SmartParkViewRenderer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8593720635)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$pgHg.LCIDS.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298753339)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298753339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298753339)
            
            //--TRIMMABLE-BOUNDARY-START(4298753339)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298753339)
            
            static $h = 3786043;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593720635),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3786043,
      "h": 8593720635,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593720635)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298753339),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3786043,
      "h": 4298753339,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298753339)
  ],
  "h": 3786043
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3786043)
        
        

        //--TRIMMABLE-BOUNDARY-START(705851)
        $asm.$cls(`$pgHg.LCIDSMC.SmartParkCheckInResponseData`, ($self) => class SmartParkCheckInResponseData extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885607739)
            /*int*/ Code = 0;
            //--TRIMMABLE-BOUNDARY-END(12885607739)
            
            //--TRIMMABLE-BOUNDARY-START(8590640443)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590640443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590640443)
            
            //--TRIMMABLE-BOUNDARY-START(8590640443)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590640443)
            
            static $h = 705851;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885607739),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475542331,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065476923,
        "f": 83886081
      },
      "n": "Code",
      "d": 705851,
      "h": 12885607739,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885607739)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590640443),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 705851,
      "h": 8590640443,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590640443)
  ],
  "h": 705851
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInResponseData`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Controls${separator}SmartParkCheckInResponseData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(705851)
        
        

        //--TRIMMABLE-BOUNDARY-START(5227835)
        $asm.$cls(`$pgHg.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4300195131)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300195131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300195131)
            
            //--TRIMMABLE-BOUNDARY-START(4300195131)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4300195131)
            
            static $h = 5227835;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300195131),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5227835,
      "h": 4300195131,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300195131)
  ],
  "h": 5227835,
  "a": [
    {
      "t": 5162299,
      "c": 4300129595
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5227835)
        
        

        //--TRIMMABLE-BOUNDARY-START(5162299)
        $asm.$cls(`$pgHg.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4300129595)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300129595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300129595)
            
            //--TRIMMABLE-BOUNDARY-START(4300129595)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4300129595)
            
            static $h = 5162299;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300129595),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5162299,
      "h": 4300129595,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300129595)
  ],
  "h": 5162299
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5162299)
        
        

        //--TRIMMABLE-BOUNDARY-START(1033531)
        $asm.$cls(`$pgHg.LCIDSMC.SmartParkTopupModel`, ($self) => class SmartParkTopupModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(25770837307)
            /*int */ get Command()
            {
                return ((128 + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(25770837307)
            
            //--TRIMMABLE-BOUNDARY-START(21475870011)
            /*int*/ Card = 0;
            //--TRIMMABLE-BOUNDARY-END(21475870011)
            
            //--TRIMMABLE-BOUNDARY-START(17180902715)
            /*int*/ Amount = 0;
            //--TRIMMABLE-BOUNDARY-END(17180902715)
            
            //--TRIMMABLE-BOUNDARY-START(12885935419)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885935419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885935419)
            
            //--TRIMMABLE-BOUNDARY-START(12885935419)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885935419)
            
            static $h = 1033531;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770837307),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540641083,
        "f": 50364417
      },
      "n": "Command",
      "d": 1033531,
      "h": 25770837307,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770837307),
//--TRIMMABLE-BOUNDARY-START(21475870011),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950706491,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720510267,
        "f": 83886081
      },
      "n": "Card",
      "d": 1033531,
      "h": 21475870011,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475870011),
//--TRIMMABLE-BOUNDARY-START(17180902715),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360771899,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130575675,
        "f": 83886081
      },
      "n": "Amount",
      "d": 1033531,
      "h": 17180902715,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180902715)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885935419),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1033531,
      "h": 12885935419,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885935419)
  ],
  "h": 1033531
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkTopupModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Controls${separator}SmartParkTopupModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1033531)
        
        

        //--TRIMMABLE-BOUNDARY-START(3261755)
        $asm.$cls(`$pgHg.LCIDSMS.SmartParkPowerStatusModel`, ($self) => class SmartParkPowerStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(81607640379)
            /*int*/ Status = 0;
            //--TRIMMABLE-BOUNDARY-END(81607640379)
            
            //--TRIMMABLE-BOUNDARY-START(21478098235)
            /*int[]*/ Balance = null;
            //--TRIMMABLE-BOUNDARY-END(21478098235)
            
            //--TRIMMABLE-BOUNDARY-START(51542869307)
            /*string[]*/ Ids = null;
            //--TRIMMABLE-BOUNDARY-END(51542869307)
            
            //--TRIMMABLE-BOUNDARY-START(17183130939)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183130939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183130939)
            
            //--TRIMMABLE-BOUNDARY-START(17183130939)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17183130939)
            
            static $h = 3261755;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81607640379),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247902011,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77312673083,
        "f": 83886081
      },
      "n": "Status",
      "d": 3261755,
      "h": 81607640379,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81607640379),
//--TRIMMABLE-BOUNDARY-START(21478098235),
    {
      "p": $.$typeArray($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068032827,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132803899,
        "f": 83886081
      },
      "n": "Balance",
      "d": 3261755,
      "h": 21478098235,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21478098235),
//--TRIMMABLE-BOUNDARY-START(51542869307),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657967419,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68722738491,
        "f": 83886081
      },
      "n": "Ids",
      "d": 3261755,
      "h": 51542869307,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51542869307)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183130939),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3261755,
      "h": 17183130939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183130939)
  ],
  "h": 3261755
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Statuses.SmartParkPowerStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Statuses${separator}SmartParkPowerStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3261755)
        
        

        //--TRIMMABLE-BOUNDARY-START(443707)
        $asm.$cls(`$pgHg.LCIDSMC.SmartParkCheckInRequestModel`, ($self) => class SmartParkCheckInRequestModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(17180312891)
            /*int */ get Command()
            {
                return ((128 + 2) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(17180312891)
            
            //--TRIMMABLE-BOUNDARY-START(12885345595)
            /*int*/ Card = 0;
            //--TRIMMABLE-BOUNDARY-END(12885345595)
            
            //--TRIMMABLE-BOUNDARY-START(8590378299)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590378299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590378299)
            
            //--TRIMMABLE-BOUNDARY-START(8590378299)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590378299)
            
            static $h = 443707;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180312891),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360182075,
        "f": 50364417
      },
      "n": "Command",
      "d": 443707,
      "h": 17180312891,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180312891),
//--TRIMMABLE-BOUNDARY-START(12885345595),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770247483,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950116667,
        "f": 83886081
      },
      "n": "Card",
      "d": 443707,
      "h": 12885345595,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885345595)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590378299),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 443707,
      "h": 8590378299,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590378299)
  ],
  "h": 443707
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInRequestModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Controls${separator}SmartParkCheckInRequestModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(443707)
        
        

        //--TRIMMABLE-BOUNDARY-START(1295675)
        $asm.$str(`$pgHg.LCIDSM.SmartParkBroadcastActionType`, ($self) => class SmartParkBroadcastActionType extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static Off = 0;
            static On = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1295675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Off": 0n,
                    "On": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296262971)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296262971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296262971)
            
            //--TRIMMABLE-BOUNDARY-START(4296262971)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296262971)
            
            static $h = 1295675;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591230267),
    {
      "t": 1295675,
      "n": "Off",
      "d": 1295675,
      "h": 8591230267,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591230267),
//--TRIMMABLE-BOUNDARY-START(12886197563),
    {
      "t": 1295675,
      "n": "On",
      "d": 1295675,
      "h": 12886197563,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886197563)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296262971),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1295675,
      "h": 4296262971,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296262971)
  ],
  "h": 1295675
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkBroadcastActionType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkBroadcastActionType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1295675)
        
        

        //--TRIMMABLE-BOUNDARY-START(1426747)
        $asm.$str(`$pgHg.LCIDSM.SmartParkControlType`, ($self) => class SmartParkControlType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static GetStatus = 1;
            static SetBrightness = 2;
            static SetOnOff = 3;
            static CountDown = 4;
            static GetSchedules = 5;
            static AddSchedule = 6;
            static RemoveSchedule = 7;
            static ResetMeter = 8;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1426747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "GetStatus": 1n,
                    "SetBrightness": 2n,
                    "SetOnOff": 3n,
                    "CountDown": 4n,
                    "GetSchedules": 5n,
                    "AddSchedule": 6n,
                    "RemoveSchedule": 7n,
                    "ResetMeter": 8n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296394043)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296394043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296394043)
            
            //--TRIMMABLE-BOUNDARY-START(4296394043)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296394043)
            
            static $h = 1426747;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25771230523),
    {
      "t": 1426747,
      "n": "None",
      "d": 1426747,
      "h": 25771230523,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771230523),
//--TRIMMABLE-BOUNDARY-START(21476263227),
    {
      "t": 1426747,
      "n": "GetStatus",
      "d": 1426747,
      "h": 21476263227,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476263227),
//--TRIMMABLE-BOUNDARY-START(38656132411),
    {
      "t": 1426747,
      "n": "SetBrightness",
      "d": 1426747,
      "h": 38656132411,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656132411),
//--TRIMMABLE-BOUNDARY-START(42951099707),
    {
      "t": 1426747,
      "n": "SetOnOff",
      "d": 1426747,
      "h": 42951099707,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951099707),
//--TRIMMABLE-BOUNDARY-START(12886328635),
    {
      "t": 1426747,
      "n": "CountDown",
      "d": 1426747,
      "h": 12886328635,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886328635),
//--TRIMMABLE-BOUNDARY-START(17181295931),
    {
      "t": 1426747,
      "n": "GetSchedules",
      "d": 1426747,
      "h": 17181295931,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181295931),
//--TRIMMABLE-BOUNDARY-START(8591361339),
    {
      "t": 1426747,
      "n": "AddSchedule",
      "d": 1426747,
      "h": 8591361339,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591361339),
//--TRIMMABLE-BOUNDARY-START(30066197819),
    {
      "t": 1426747,
      "n": "RemoveSchedule",
      "d": 1426747,
      "h": 30066197819,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066197819),
//--TRIMMABLE-BOUNDARY-START(34361165115),
    {
      "t": 1426747,
      "n": "ResetMeter",
      "d": 1426747,
      "h": 34361165115,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361165115)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296394043),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1426747,
      "h": 4296394043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296394043)
  ],
  "h": 1426747
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkControlType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkControlType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1426747)
        
        

        //--TRIMMABLE-BOUNDARY-START(2868539)
        $asm.$str(`$pgHg.LCIDSM.SmartParkLogType`, ($self) => class SmartParkLogType extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static None = 0;
            static ChangedState = 1;
            static SetCountdown = 2;
            static CountdownTimeout = 3;
            static Power = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2868539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "ChangedState": 1n,
                    "SetCountdown": 2n,
                    "CountdownTimeout": 3n,
                    "Power": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297835835)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297835835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297835835)
            
            //--TRIMMABLE-BOUNDARY-START(4297835835)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297835835)
            
            static $h = 2868539;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182737723),
    {
      "t": 2868539,
      "n": "None",
      "d": 2868539,
      "h": 17182737723,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182737723),
//--TRIMMABLE-BOUNDARY-START(8592803131),
    {
      "t": 2868539,
      "n": "ChangedState",
      "d": 2868539,
      "h": 8592803131,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592803131),
//--TRIMMABLE-BOUNDARY-START(25772672315),
    {
      "t": 2868539,
      "n": "SetCountdown",
      "d": 2868539,
      "h": 25772672315,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772672315),
//--TRIMMABLE-BOUNDARY-START(12887770427),
    {
      "t": 2868539,
      "n": "CountdownTimeout",
      "d": 2868539,
      "h": 12887770427,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887770427),
//--TRIMMABLE-BOUNDARY-START(21477705019),
    {
      "t": 2868539,
      "n": "Power",
      "d": 2868539,
      "h": 21477705019,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477705019)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297835835),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2868539,
      "h": 4297835835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297835835)
  ],
  "h": 2868539
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkLogType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkLogType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2868539)
        
        

        //--TRIMMABLE-BOUNDARY-START(116027)
        $asm.$cls(`$pgHg.LCIDS._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590050619)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590050619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590050619)
            
            //--TRIMMABLE-BOUNDARY-START(4295083323)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295083323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295083323)
            
            //--TRIMMABLE-BOUNDARY-START(4295083323)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295083323)
            
            static $h = 116027;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590050619),
    {
      "r": 65537,
      "n": "Execute",
      "d": 116027,
      "h": 8590050619,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590050619)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295083323),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 116027,
      "h": 4295083323,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295083323)
  ],
  "h": 116027
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(116027)
        
        

        //--TRIMMABLE-BOUNDARY-START(2737467)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkLogModelTypeDescriptor`, ($self) => class SmartParkLogModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSM.SmartParkLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297704763)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297704763);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$pgHg.LCIDSM.SmartParkLogModelTypeDescriptor.GenerateProperties($.$pgHg.LCIDSM.SmartParkLogModel, this, factory);
                    }, $wbBulg ??= {"r":65537,"n":"","d":2737467,"h":0,"f":17825794}), 0, "SmartParkLogModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SmartPark\\Models_SmartParkLogModel_LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkLogModelTypeDescriptorBuilder.g.cs", "SmartParkLogModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297704763)
            
            //--TRIMMABLE-BOUNDARY-START(12887639355)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887639355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$pgHg.LCIDSM.SmartParkLogModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$pgHg.LCIDSM.SmartParkLogType, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkLogModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSM.SmartParkLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$pgHg.LCIDSM.SmartParkLogType, ($.$cast(target, $.$pgHg.LCIDSM.SmartParkLogModel)).Type);
                        }, $HhtcIg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2737467,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSM.SmartParkLogModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Type = value.AsEnumValue($.$pgHg.LCIDSM.SmartParkLogType);
                        }, $krTWRd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2737467,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Time"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$pgHg.LCIDSM.SmartParkLogModel.$type, $.$discardRef(), "Time", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Time")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Time";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkLogModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSM.SmartParkLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$pgHg.LCIDSM.SmartParkLogModel)).Time);
                        }, $iPqQTk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2737467,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSM.SmartParkLogModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Time = value.AsDateTime();
                        }, $xGxxMb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2737467,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Value"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$pgHg.LCIDSM.SmartParkLogModel.$type, $.$discardRef(), "Value", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Value")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Value";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkLogModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSM.SmartParkLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$pgHg.LCIDSM.SmartParkLogModel)).Value);
                        }, $qTFkob ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2737467,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSM.SmartParkLogModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.Value = value.AsInt();
                        }, $apUyjg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2737467,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Title"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$pgHg.LCIDSM.SmartParkLogModel.$type, $.$discardRef(), "Title", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Title")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Title";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkLogModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSM.SmartParkLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$pgHg.LCIDSM.SmartParkLogModel)).Title);
                        }, $RuJoeb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2737467,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$pgHg.LCIDSM.SmartParkLogModel.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Description";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkLogModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSM.SmartParkLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$pgHg.LCIDSM.SmartParkLogModel)).Description);
                        }, $pgargg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2737467,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Icon"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$pgHg.LCIDSM.SmartParkLogModel.$type, $.$discardRef(), "Icon", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Icon")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Icon";
                        $i11.DelaredOn = "LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkLogModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSM.SmartParkLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$pgHg.LCIDSM.SmartParkLogModel)).Icon);
                        }, $gVpfik ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2737467,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887639355)
            
            //--TRIMMABLE-BOUNDARY-START(17182606651)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkLogModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182606651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$pgHg.LCIDSM.SmartParkLogType));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$pgHg.LCIDSM.SmartParkLogType, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                        _target.Type = _Type;
                    }
                }
                {
                    /*var*/ let _Time = _target.Time;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Time"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _Time, ($v) => _Time = $v, null, true)))
                    {
                        _target.Time = _Time;
                    }
                }
                {
                    /*var*/ let _Value = _target.Value;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Value"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Value, ($v) => _Value = $v, $.$$.S.Int32)))
                    {
                        _target.Value = _Value;
                    }
                }
                {
                    /*var*/ let _Title = _target.Title;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Title"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Title, ($v) => _Title = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Icon = _target.Icon;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Icon"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Icon, ($v) => _Icon = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182606651)
            
            //--TRIMMABLE-BOUNDARY-START(8592672059)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkLogModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592672059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$pgHg.LCIDSM.SmartParkLogModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$pgHg.LCIDSM.SmartParkLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkLogModel)))
                {
                    /*var*/ let result = $.$pgHg.LCIDSM.SmartParkLogModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkLogModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$pgHg.LCIDSM.SmartParkLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkLogModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592672059)
            
            static $h = 2737467;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSM.SmartParkLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887639355),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2737467,
      "h": 12887639355,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887639355),
//--TRIMMABLE-BOUNDARY-START(17182606651),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2606395,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2737467,
      "h": 17182606651,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182606651),
//--TRIMMABLE-BOUNDARY-START(8592672059),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2606395,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2737467,
      "h": 8592672059,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592672059)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297704763),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2737467,
      "h": 4297704763,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297704763)
  ],
  "h": 2737467
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$pgHg.LCIDSM.SmartParkLogModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkLogModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkLogModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2737467)
        
        

        //--TRIMMABLE-BOUNDARY-START(1164603)
        $asm.$cls(`$pgHg.LCIDSMC.SmartParkTopupModelTypeDescriptor`, ($self) => class SmartParkTopupModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSMC.SmartParkTopupModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296131899)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296131899);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$pgHg.LCIDSMC.SmartParkTopupModelTypeDescriptor.GenerateProperties($.$pgHg.LCIDSMC.SmartParkTopupModel, this, factory);
                    }, $JMtpMj ??= {"r":65537,"n":"","d":1164603,"h":0,"f":17825794}), 0, "SmartParkTopupModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SmartPark\\Models_Controls_SmartParkTopupModel_LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkTopupModelTypeDescriptorBuilder.g.cs", "SmartParkTopupModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296131899)
            
            //--TRIMMABLE-BOUNDARY-START(12886066491)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886066491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Card"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$pgHg.LCIDSMC.SmartParkTopupModel.$type, $.$discardRef(), "Card", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Card")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Card";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkTopupModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSMC.SmartParkTopupModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$pgHg.LCIDSMC.SmartParkTopupModel)).Card);
                        }, $TONSwk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1164603,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSMC.SmartParkTopupModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Card = value.AsInt();
                        }, $RJDXla ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1164603,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Amount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$pgHg.LCIDSMC.SmartParkTopupModel.$type, $.$discardRef(), "Amount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Amount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Amount";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkTopupModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSMC.SmartParkTopupModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$pgHg.LCIDSMC.SmartParkTopupModel)).Amount);
                        }, $yfMMdc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1164603,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSMC.SmartParkTopupModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Amount = value.AsInt();
                        }, $DsvWfl ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1164603,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$pgHg.LCIDSMC.SmartParkTopupModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Command";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkTopupModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSMC.SmartParkTopupModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$pgHg.LCIDSMC.SmartParkTopupModel)).Command);
                        }, $KXZpda ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1164603,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886066491)
            
            //--TRIMMABLE-BOUNDARY-START(17181033787)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkTopupModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181033787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Card = _target.Card;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Card"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Card, ($v) => _Card = $v, $.$$.S.Int32)))
                    {
                        _target.Card = _Card;
                    }
                }
                {
                    /*var*/ let _Amount = _target.Amount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Amount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Amount, ($v) => _Amount = $v, $.$$.S.Int32)))
                    {
                        _target.Amount = _Amount;
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181033787)
            
            //--TRIMMABLE-BOUNDARY-START(8591099195)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkTopupModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591099195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$pgHg.LCIDSMC.SmartParkTopupModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$pgHg.LCIDSMC.SmartParkTopupModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSMC.SmartParkTopupModel)))
                {
                    /*var*/ let result = $.$pgHg.LCIDSMC.SmartParkTopupModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSMC.SmartParkTopupModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$pgHg.LCIDSMC.SmartParkTopupModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSMC.SmartParkTopupModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591099195)
            
            static $h = 1164603;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSMC.SmartParkTopupModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886066491),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1164603,
      "h": 12886066491,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886066491),
//--TRIMMABLE-BOUNDARY-START(17181033787),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1033531,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1164603,
      "h": 17181033787,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181033787),
//--TRIMMABLE-BOUNDARY-START(8591099195),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1033531,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1164603,
      "h": 8591099195,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591099195)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296131899),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1164603,
      "h": 4296131899,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296131899)
  ],
  "h": 1164603
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$pgHg.LCIDSMC.SmartParkTopupModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkTopupModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Controls${separator}SmartParkTopupModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1164603)
        
        

        //--TRIMMABLE-BOUNDARY-START(3392827)
        $asm.$cls(`$pgHg.LCIDSMS.SmartParkPowerStatusModelTypeDescriptor`, ($self) => class SmartParkPowerStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSMS.SmartParkPowerStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298360123)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298360123);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$pgHg.LCIDSMS.SmartParkPowerStatusModelTypeDescriptor.GenerateProperties($.$pgHg.LCIDSMS.SmartParkPowerStatusModel, this, factory);
                    }, $dkJOui ??= {"r":65537,"n":"","d":3392827,"h":0,"f":17825794}), 0, "SmartParkPowerStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SmartPark\\Models_Statuses_SmartParkStatusModel_LivingThing.Core.IOT.Devices.SmartPark.Models.Statuses.SmartParkPowerStatusModelTypeDescriptorBuilder.g.cs", "SmartParkPowerStatusModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298360123)
            
            //--TRIMMABLE-BOUNDARY-START(12888294715)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888294715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Status"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$pgHg.LCIDSMS.SmartParkPowerStatusModel.$type, $.$discardRef(), "Status", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Status")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Status";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.SmartPark.Models.Statuses.SmartParkPowerStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSMS.SmartParkPowerStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$pgHg.LCIDSMS.SmartParkPowerStatusModel)).Status);
                        }, $qzSyGa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3392827,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSMS.SmartParkPowerStatusModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Status = value.AsInt();
                        }, $KgVbgh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3392827,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Balance"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$pgHg.LCIDSMS.SmartParkPowerStatusModel.$type, $.$discardRef(), "Balance", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Balance")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.Int32), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Balance";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.SmartPark.Models.Statuses.SmartParkPowerStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSMS.SmartParkPowerStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.Int32), ($.$cast(target, $.$pgHg.LCIDSMS.SmartParkPowerStatusModel)).Balance);
                        }, $TVUjGe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3392827,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSMS.SmartParkPowerStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.Balance = value.AsReference($.$typeArray($.$$.S.Int32));
                        }, $tiKzwd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3392827,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Ids"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$pgHg.LCIDSMS.SmartParkPowerStatusModel.$type, $.$discardRef(), "Ids", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Ids")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Ids";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.SmartPark.Models.Statuses.SmartParkPowerStatusModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSMS.SmartParkPowerStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.String), ($.$cast(target, $.$pgHg.LCIDSMS.SmartParkPowerStatusModel)).Ids);
                        }, $cFbMgb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3392827,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSMS.SmartParkPowerStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Ids = value.AsReference($.$typeArray($.$$.S.String));
                        }, $iKjQkd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3392827,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888294715)
            
            //--TRIMMABLE-BOUNDARY-START(17183262011)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.Statuses.SmartParkPowerStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183262011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _Status = _target.Status;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Status"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Status, ($v) => _Status = $v, $.$$.S.Int32)))
                    {
                        _target.Status = _Status;
                    }
                }
                {
                    /*var*/ let _Balance = _target.Balance;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Balance"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.Int32)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.Int32), $.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.Int32), $.$$.S.Int32, property, $.$ref(() => _Balance, ($v) => _Balance = $v, $.$typeArray($.$$.S.Int32))))
                    {
                        _target.Balance = _Balance;
                        if (_Balance !== null)
                        {
                            let $i11 = 0;
                            let $arr11 = _Balance;
                            while ($i11 < $arr11.length)
                            {
                                let item = $arr11[$i11++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.Int32)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.Int32), $.$$.S.Int32, property, $.$ref(() => _Balance, ($v) => _Balance = $v, $.$typeArray($.$$.S.Int32)));
                    }
                }
                {
                    /*var*/ let _Ids = _target.Ids;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Ids"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Ids, ($v) => _Ids = $v, $.$typeArray($.$$.S.String))))
                    {
                        _target.Ids = _Ids;
                        if (_Ids !== null)
                        {
                            let $i16 = 0;
                            let $arr16 = _Ids;
                            while ($i16 < $arr16.length)
                            {
                                let item = $arr16[$i16++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Ids, ($v) => _Ids = $v, $.$typeArray($.$$.S.String)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183262011)
            
            //--TRIMMABLE-BOUNDARY-START(8593327419)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.Statuses.SmartParkPowerStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593327419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$pgHg.LCIDSMS.SmartParkPowerStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$pgHg.LCIDSMS.SmartParkPowerStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSMS.SmartParkPowerStatusModel)))
                {
                    /*var*/ let result = $.$pgHg.LCIDSMS.SmartParkPowerStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSMS.SmartParkPowerStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$pgHg.LCIDSMS.SmartParkPowerStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSMS.SmartParkPowerStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593327419)
            
            static $h = 3392827;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSMS.SmartParkPowerStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888294715),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3392827,
      "h": 12888294715,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888294715),
//--TRIMMABLE-BOUNDARY-START(17183262011),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3261755,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3392827,
      "h": 17183262011,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183262011),
//--TRIMMABLE-BOUNDARY-START(8593327419),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3261755,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3392827,
      "h": 8593327419,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593327419)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298360123),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3392827,
      "h": 4298360123,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298360123)
  ],
  "h": 3392827
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$pgHg.LCIDSMS.SmartParkPowerStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Statuses.SmartParkPowerStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Statuses${separator}SmartParkPowerStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3392827)
        
        

        //--TRIMMABLE-BOUNDARY-START(574779)
        $asm.$cls(`$pgHg.LCIDSMC.SmartParkCheckInRequestModelTypeDescriptor`, ($self) => class SmartParkCheckInRequestModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSMC.SmartParkCheckInRequestModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295542075)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295542075);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$pgHg.LCIDSMC.SmartParkCheckInRequestModelTypeDescriptor.GenerateProperties($.$pgHg.LCIDSMC.SmartParkCheckInRequestModel, this, factory);
                    }, $cmuIjg ??= {"r":65537,"n":"","d":574779,"h":0,"f":17825794}), 0, "SmartParkCheckInRequestModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SmartPark\\Models_Controls_SmartParkCheckInRequestModel_LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInRequestModelTypeDescriptorBuilder.g.cs", "SmartParkCheckInRequestModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295542075)
            
            //--TRIMMABLE-BOUNDARY-START(12885476667)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885476667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Card"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$pgHg.LCIDSMC.SmartParkCheckInRequestModel.$type, $.$discardRef(), "Card", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Card")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Card";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInRequestModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSMC.SmartParkCheckInRequestModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$pgHg.LCIDSMC.SmartParkCheckInRequestModel)).Card);
                        }, $NlxKna ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":574779,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSMC.SmartParkCheckInRequestModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Card = value.AsInt();
                        }, $SxdGEh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":574779,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$pgHg.LCIDSMC.SmartParkCheckInRequestModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Command";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInRequestModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSMC.SmartParkCheckInRequestModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$pgHg.LCIDSMC.SmartParkCheckInRequestModel)).Command);
                        }, $VITKRi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":574779,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885476667)
            
            //--TRIMMABLE-BOUNDARY-START(17180443963)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInRequestModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180443963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Card = _target.Card;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Card"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Card, ($v) => _Card = $v, $.$$.S.Int32)))
                    {
                        _target.Card = _Card;
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180443963)
            
            //--TRIMMABLE-BOUNDARY-START(8590509371)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInRequestModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590509371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$pgHg.LCIDSMC.SmartParkCheckInRequestModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$pgHg.LCIDSMC.SmartParkCheckInRequestModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSMC.SmartParkCheckInRequestModel)))
                {
                    /*var*/ let result = $.$pgHg.LCIDSMC.SmartParkCheckInRequestModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSMC.SmartParkCheckInRequestModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$pgHg.LCIDSMC.SmartParkCheckInRequestModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSMC.SmartParkCheckInRequestModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590509371)
            
            static $h = 574779;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSMC.SmartParkCheckInRequestModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885476667),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 574779,
      "h": 12885476667,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885476667),
//--TRIMMABLE-BOUNDARY-START(17180443963),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 443707,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 574779,
      "h": 17180443963,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180443963),
//--TRIMMABLE-BOUNDARY-START(8590509371),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 443707,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 574779,
      "h": 8590509371,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590509371)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295542075),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 574779,
      "h": 4295542075,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295542075)
  ],
  "h": 574779
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$pgHg.LCIDSMC.SmartParkCheckInRequestModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInRequestModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Controls${separator}SmartParkCheckInRequestModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(574779)
        
        

        //--TRIMMABLE-BOUNDARY-START(3589435)
        $asm.$cls(`$pgHg.LCIDSPC.SmartParkDeviceCommands<>`, (TDevice) => $asm.$gt(`$pgHg.LCIDSPC.SmartParkDeviceCommands<>`, [TDevice], ($self) => class SmartParkDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12888491323)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12888491323)
            
            //--TRIMMABLE-BOUNDARY-START(17183458619)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel?*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183458619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$pgHg.LCIDSPC.SmartParkDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17183458619)
            
            //--TRIMMABLE-BOUNDARY-START(8593524027)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593524027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593524027)
            
            //--TRIMMABLE-BOUNDARY-START(8593524027)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8593524027)
            
            //--TRIMMABLE-BOUNDARY-START(4298556731)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298556731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12888491323)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [new $.$pgHg.LCIDSPCV.SmartParkTopupCommand().$ctor$6()], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12888491323)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298556731)
            
            static $H = 3589435;
            static $h = 3589435;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183458619),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17183458619,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17183458619)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12888491323),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12888491323,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12888491323)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593524027),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8593524027,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593524027)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 3589435,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Protocol.Commands.SmartParkDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Protocol${separator}Commands${separator}SmartParkDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3589435)
        
        

        //--TRIMMABLE-BOUNDARY-START(3720507)
        $asm.$cls(`$pgHg.LCIDSPCV.SmartParkTopupCommand`, ($self) => class SmartParkTopupCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$pgHg.LCIDSMC.SmartParkTopupModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298687803)
            $ctor$6()
            {
                super.$ctor$5("Top-up", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298687803);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298687803)
            
            //--TRIMMABLE-BOUNDARY-START(17183589691)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-timer-sand"/*MaterialDesignIconNames.TimerSand*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17183589691)
            
            //--TRIMMABLE-BOUNDARY-START(4298687803)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4298687803)
            
            static $h = 3720507;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$pgHg.LCIDSMC.SmartParkTopupModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183589691),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888622395,
        "f": 50364417
      },
      "n": "Icon",
      "d": 3720507,
      "h": 17183589691,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17183589691)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298687803),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 3720507,
      "h": 4298687803,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298687803)
  ],
  "h": 3720507
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Protocol.Commands.Variants.SmartParkTopupCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Protocol${separator}Commands${separator}Variants${separator}SmartParkTopupCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3720507)
        
        

        //--TRIMMABLE-BOUNDARY-START(3654971)
        $asm.$cls(`$pgHg.LCIDSPCV.SmartParkCheckInCommand`, ($self) => class SmartParkCheckInCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$pgHg.LCIDSMC.SmartParkCheckInRequestModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298622267)
            $ctor$6()
            {
                super.$ctor$5("CheckIn", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298622267);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298622267)
            
            //--TRIMMABLE-BOUNDARY-START(17183524155)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-timer-sand"/*MaterialDesignIconNames.TimerSand*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17183524155)
            
            //--TRIMMABLE-BOUNDARY-START(4298622267)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4298622267)
            
            static $h = 3654971;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$pgHg.LCIDSMC.SmartParkCheckInRequestModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183524155),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888556859,
        "f": 50364417
      },
      "n": "Icon",
      "d": 3654971,
      "h": 17183524155,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17183524155)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298622267),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 3654971,
      "h": 4298622267,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298622267)
  ],
  "h": 3654971
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Protocol.Commands.Variants.SmartParkCheckInCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Protocol${separator}Commands${separator}Variants${separator}SmartParkCheckInCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3654971)
        
        

        //--TRIMMABLE-BOUNDARY-START(771387)
        $asm.$cls(`$pgHg.LCIDSMC.SmartParkCheckInResponseModel`, ($self) => class SmartParkCheckInResponseModel extends $.$XBGm.LCICDi.iSmartDeviceCommandResponseModel$$($.$pgHg.LCIDSMC.SmartParkCheckInResponseData)
        {
            //--TRIMMABLE-BOUNDARY-START(4295738683)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295738683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295738683)
            
            //--TRIMMABLE-BOUNDARY-START(4295738683)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295738683)
            
            static $h = 771387;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandResponseModel$$($.$pgHg.LCIDSMC.SmartParkCheckInResponseData); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295738683),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 771387,
      "h": 4295738683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295738683)
  ],
  "h": 771387
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInResponseModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Controls${separator}SmartParkCheckInResponseModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(771387)
        
        

        //--TRIMMABLE-BOUNDARY-START(2344251)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkDeviceSendDataModel`, ($self) => class SmartParkDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceCommandsModel
        {
            //--TRIMMABLE-BOUNDARY-START(8592278843)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592278843);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592278843)
            
            //--TRIMMABLE-BOUNDARY-START(12887246139)
            $ctor$5(/*SmartParkTopupModel*/ onOff)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887246139);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.OnOff = onOff;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887246139)
            
            //--TRIMMABLE-BOUNDARY-START(25772148027)
            /*SmartParkTopupModel?*/ OnOff = null;
            //--TRIMMABLE-BOUNDARY-END(25772148027)
            
            //--TRIMMABLE-BOUNDARY-START(8592278843)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8592278843)
            
            static $h = 2344251;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandsModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772148027),
    {
      "p": 1033531,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477180731,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34362082619,
        "f": 83886081
      },
      "n": "OnOff",
      "d": 2344251,
      "h": 25772148027,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 13432,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25772148027)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592278843),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2344251,
      "h": 8592278843,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592278843),
//--TRIMMABLE-BOUNDARY-START(12887246139),
    {
      "p": [
        {
          "n": "onOff",
          "p": 1033531
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2344251,
      "h": 12887246139,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887246139)
  ],
  "h": 2344251
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2344251)
        
        

        //--TRIMMABLE-BOUNDARY-START(902459)
        $asm.$cls(`$pgHg.LCIDSMC.SmartParkCheckInResponseModelTypeDescriptor`, ($self) => class SmartParkCheckInResponseModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSMC.SmartParkCheckInResponseModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295869755)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295869755);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$pgHg.LCIDSMC.SmartParkCheckInResponseModelTypeDescriptor.GenerateProperties($.$pgHg.LCIDSMC.SmartParkCheckInResponseModel, this, factory);
                    }, $HThDIj ??= {"r":65537,"n":"","d":902459,"h":0,"f":17825794}), 0, "SmartParkCheckInResponseModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SmartPark\\Models_Controls_SmartParkCheckInRequestModel_LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInResponseModelTypeDescriptorBuilder.g.cs", "SmartParkCheckInResponseModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295869755)
            
            //--TRIMMABLE-BOUNDARY-START(12885804347)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885804347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceCommandResponseModelTypeDescriptor$$($.$pgHg.LCIDSMC.SmartParkCheckInResponseData).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885804347)
            
            //--TRIMMABLE-BOUNDARY-START(17180771643)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInResponseModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180771643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandResponseModel<LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInResponseData>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandResponseModelTypeDescriptor$$($.$pgHg.LCIDSMC.SmartParkCheckInResponseData).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandResponseModel$$($.$pgHg.LCIDSMC.SmartParkCheckInResponseData)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180771643)
            
            //--TRIMMABLE-BOUNDARY-START(8590837051)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInResponseModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590837051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$pgHg.LCIDSMC.SmartParkCheckInResponseModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$pgHg.LCIDSMC.SmartParkCheckInResponseModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSMC.SmartParkCheckInResponseModel)))
                {
                    /*var*/ let result = $.$pgHg.LCIDSMC.SmartParkCheckInResponseModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSMC.SmartParkCheckInResponseModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$pgHg.LCIDSMC.SmartParkCheckInResponseModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSMC.SmartParkCheckInResponseModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590837051)
            
            static $h = 902459;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSMC.SmartParkCheckInResponseModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885804347),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 902459,
      "h": 12885804347,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885804347),
//--TRIMMABLE-BOUNDARY-START(17180771643),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 771387,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 902459,
      "h": 17180771643,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180771643),
//--TRIMMABLE-BOUNDARY-START(8590837051),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 771387,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 902459,
      "h": 8590837051,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590837051)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295869755),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 902459,
      "h": 4295869755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295869755)
  ],
  "h": 902459
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$pgHg.LCIDSMC.SmartParkCheckInResponseModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.Controls.SmartParkCheckInResponseModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}Controls${separator}SmartParkCheckInResponseModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(902459)
        
        

        //--TRIMMABLE-BOUNDARY-START(1819963)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel`, ($self) => class SmartParkDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$pgHg.LCIDSMS.SmartParkPowerStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296787259)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296787259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296787259)
            
            //--TRIMMABLE-BOUNDARY-START(4296787259)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296787259)
            
            static $h = 1819963;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$pgHg.LCIDSMS.SmartParkPowerStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296787259),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1819963,
      "h": 4296787259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296787259)
  ],
  "h": 1819963
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1819963)
        
        

        //--TRIMMABLE-BOUNDARY-START(2475323)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkDeviceSendDataModelTypeDescriptor`, ($self) => class SmartParkDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSM.SmartParkDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297442619)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297442619);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$pgHg.LCIDSM.SmartParkDeviceSendDataModelTypeDescriptor.GenerateProperties($.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, this, factory);
                    }, $qKnRgf ??= {"r":65537,"n":"","d":2475323,"h":0,"f":17825794}), 0, "SmartParkDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SmartPark\\Models_SmartParkDeviceSendDataModel_LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceSendDataModelTypeDescriptorBuilder.g.cs", "SmartParkDeviceSendDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297442619)
            
            //--TRIMMABLE-BOUNDARY-START(12887377211)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887377211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("OnOff"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel.$type, $.$discardRef(), "OnOff", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("OnOff")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$pgHg.LCIDSMC.SmartParkTopupModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "OnOff";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceSendDataModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSM.SmartParkDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$pgHg.LCIDSMC.SmartParkTopupModel, ($.$cast(target, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel)).OnOff);
                        }, $phuemg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2475323,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSM.SmartParkDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.OnOff = value.AsReference($.$pgHg.LCIDSMC.SmartParkTopupModel);
                        }, $fRxdle ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2475323,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887377211)
            
            //--TRIMMABLE-BOUNDARY-START(17182344507)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182344507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandsModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandsModel));
                {
                    /*var*/ let _OnOff = _target.OnOff;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("OnOff"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$pgHg.LCIDSMC.SmartParkTopupModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _OnOff, ($v) => _OnOff = $v, $.$pgHg.LCIDSMC.SmartParkTopupModel)))
                    {
                        _target.OnOff = _OnOff;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182344507)
            
            //--TRIMMABLE-BOUNDARY-START(8592409915)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592409915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$pgHg.LCIDSM.SmartParkDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592409915)
            
            static $h = 2475323;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSM.SmartParkDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887377211),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2475323,
      "h": 12887377211,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887377211),
//--TRIMMABLE-BOUNDARY-START(17182344507),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2344251,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2475323,
      "h": 17182344507,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182344507),
//--TRIMMABLE-BOUNDARY-START(8592409915),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2344251,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2475323,
      "h": 8592409915,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592409915)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297442619),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2475323,
      "h": 4297442619,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297442619)
  ],
  "h": 2475323
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$pgHg.LCIDSM.SmartParkDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2475323)
        
        

        //--TRIMMABLE-BOUNDARY-START(1951035)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkDeviceReceivedDataModelTypeDescriptor`, ($self) => class SmartParkDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296918331)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296918331);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, this, factory);
                    }, $xtHudf ??= {"r":65537,"n":"","d":1951035,"h":0,"f":17825794}), 0, "SmartParkDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SmartPark\\Models_SmartParkDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "SmartParkDeviceReceivedDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296918331)
            
            //--TRIMMABLE-BOUNDARY-START(12886852923)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886852923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$pgHg.LCIDSMS.SmartParkPowerStatusModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886852923)
            
            //--TRIMMABLE-BOUNDARY-START(17181820219)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181820219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.SmartPark.Models.Statuses.SmartParkPowerStatusModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$pgHg.LCIDSMS.SmartParkPowerStatusModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$pgHg.LCIDSMS.SmartParkPowerStatusModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181820219)
            
            //--TRIMMABLE-BOUNDARY-START(8591885627)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591885627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591885627)
            
            static $h = 1951035;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886852923),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1951035,
      "h": 12886852923,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886852923),
//--TRIMMABLE-BOUNDARY-START(17181820219),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1819963,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1951035,
      "h": 17181820219,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181820219),
//--TRIMMABLE-BOUNDARY-START(8591885627),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1819963,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1951035,
      "h": 8591885627,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591885627)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296918331),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1951035,
      "h": 4296918331,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296918331)
  ],
  "h": 1951035
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1951035)
        
        

        //--TRIMMABLE-BOUNDARY-START(4572475)
        $asm.$cls(`$pgHg.LCIDS.SmartParkDataConverter`, ($self) => class SmartParkDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299539771)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299539771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299539771)
            
            //--TRIMMABLE-BOUNDARY-START(4299539771)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299539771)
            
            static $h = 4572475;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299539771),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4572475,
      "h": 4299539771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299539771)
  ],
  "h": 4572475
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.SmartParkDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}SmartParkDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4572475)
        
        

        //--TRIMMABLE-BOUNDARY-START(3982651)
        $asm.$cls(`$pgHg.LCIDSS.ISmartParkRemoteService`, ($self) => class ISmartParkRemoteService
        {
            static $h = 3982651;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3982651
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$pgHg.LCIDSM.SmartParkServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$pgHg.LCIDSM.SmartParkServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$pgHg.LCIDSM.SmartParkServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$pgHg.LCIDSM.SmartParkServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$pgHg.LCIDSM.SmartParkServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$pgHg.LCIDSM.SmartParkServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$pgHg.LCIDSM.SmartParkServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$pgHg.LCIDSM.SmartParkServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Services${separator}ISmartParkRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3982651)
        
        

        //--TRIMMABLE-BOUNDARY-START(3917115)
        $asm.$cls(`$pgHg.LCIDSS.ISmartParkDeviceStatusHandler`, ($self) => class ISmartParkDeviceStatusHandler
        {
            static $h = 3917115;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3917115
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Services${separator}ISmartParkDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3917115)
        
        

        $asm.$typeProxy("$pgHg.LCIDSM.SmartParkServiceModel", "$pgHg.LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkServiceModel");
        $asm.$typeProxy("$pgHg.LCIDSM.SmartParkDeviceScopeModel", "$pgHg.LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceScopeModel");
        $asm.$typeProxy("$pgHg.LCIDSS$1.SmartParkDeviceSettings", "$pgHg.LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceSettings");
        $asm.$typeProxy("$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings", "$pgHg.LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceHardwareSettings");
        $asm.$typeProxy("$pgHg.LCIDSS.ISmartParkDeviceHubClient", "$pgHg.LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkDeviceHubClient");
        //--TRIMMABLE-BOUNDARY-START(1557819)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkDeviceModel`, ($self) => class SmartParkDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296525115)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296525115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296525115)
            
            //--TRIMMABLE-BOUNDARY-START(4296525115)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296525115)
            
            static $h = 1557819;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296525115),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1557819,
      "h": 4296525115,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296525115)
  ],
  "h": 1557819
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1557819)
        
        

        //--TRIMMABLE-BOUNDARY-START(2082107)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkDeviceScopeModel`, ($self) => class SmartParkDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297049403)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297049403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297049403)
            
            //--TRIMMABLE-BOUNDARY-START(4297049403)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4297049403)
            
            static $h = 2082107;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297049403),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 2082107,
      "h": 4297049403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297049403)
  ],
  "h": 2082107
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2082107)
        
        

        //--TRIMMABLE-BOUNDARY-START(2999611)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkServiceModel`, ($self) => class SmartParkServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297966907)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297966907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297966907)
            
            //--TRIMMABLE-BOUNDARY-START(4297966907)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4297966907)
            
            static $h = 2999611;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297966907),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 2999611,
      "h": 4297966907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297966907)
  ],
  "h": 2999611
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2999611)
        
        

        //--TRIMMABLE-BOUNDARY-START(4048187)
        $asm.$cls(`$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings`, ($self) => class SmartParkDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4299015483)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299015483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299015483)
            
            //--TRIMMABLE-BOUNDARY-START(4299015483)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299015483)
            
            static $h = 4048187;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299015483),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4048187,
      "h": 4299015483,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299015483)
  ],
  "h": 4048187
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Settings${separator}SmartParkDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4048187)
        
        

        //--TRIMMABLE-BOUNDARY-START(3851579)
        $asm.$cls(`$pgHg.LCIDSS.ISmartParkDeviceHubClient`, ($self) => class ISmartParkDeviceHubClient
        {
            static $h = 3851579;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3851579
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Services${separator}ISmartParkDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3851579)
        
        

        //--TRIMMABLE-BOUNDARY-START(4310331)
        $asm.$cls(`$pgHg.LCIDSS$1.SmartParkDeviceSettings`, ($self) => class SmartParkDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $self, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(21479146811)
            /*bool*/ HasMetering = false;
            //--TRIMMABLE-BOUNDARY-END(21479146811)
            
            //--TRIMMABLE-BOUNDARY-START(8594244923)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594244923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594244923)
            
            //--TRIMMABLE-BOUNDARY-START(8594244923)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8594244923)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21479146811)
                this.HasMetering = true;
                //--TRIMMABLE-BOUNDARY-END(21479146811)
                
            }
            static $h = 4310331;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21479146811),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17184179515,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30069081403,
        "f": 83886081
      },
      "n": "HasMetering",
      "d": 4310331,
      "h": 21479146811,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21479146811)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594244923),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4310331,
      "h": 8594244923,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594244923)
  ],
  "h": 4310331
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Settings${separator}SmartParkDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4310331)
        
        

        //--TRIMMABLE-BOUNDARY-START(4834619)
        $asm.$cls(`$pgHg.LCIDS.SmartParkDeviceModelDefinition`, ($self) => class SmartParkDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4299801915)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299801915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299801915)
            
            //--TRIMMABLE-BOUNDARY-START(4299801915)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299801915)
            
            static $h = 4834619;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299801915),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4834619,
      "h": 4299801915,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299801915)
  ],
  "h": 4834619
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.SmartParkDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}SmartParkDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4834619)
        
        

        //--TRIMMABLE-BOUNDARY-START(2213179)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkDeviceScopeModelTypeDescriptor`, ($self) => class SmartParkDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSM.SmartParkDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297180475)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297180475);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$pgHg.LCIDSM.SmartParkDeviceScopeModelTypeDescriptor.GenerateProperties($.$pgHg.LCIDSM.SmartParkDeviceScopeModel, this, factory);
                    }, $ZCjxBf ??= {"r":65537,"n":"","d":2213179,"h":0,"f":17825794}), 0, "SmartParkDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SmartPark\\Models_SmartParkDeviceScopeModel_LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceScopeModelTypeDescriptorBuilder.g.cs", "SmartParkDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297180475)
            
            //--TRIMMABLE-BOUNDARY-START(12887115067)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887115067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887115067)
            
            //--TRIMMABLE-BOUNDARY-START(17182082363)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182082363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceModel, LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceSettings, LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceSendDataModel, LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkDeviceStatusHandler, LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkDeviceHubClient, LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182082363)
            
            //--TRIMMABLE-BOUNDARY-START(8592147771)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592147771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$pgHg.LCIDSM.SmartParkDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel)))
                {
                    /*var*/ let result = $.$pgHg.LCIDSM.SmartParkDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592147771)
            
            static $h = 2213179;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSM.SmartParkDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887115067),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2213179,
      "h": 12887115067,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887115067),
//--TRIMMABLE-BOUNDARY-START(17182082363),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2082107,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2213179,
      "h": 17182082363,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182082363),
//--TRIMMABLE-BOUNDARY-START(8592147771),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2082107,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2213179,
      "h": 8592147771,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592147771)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297180475),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2213179,
      "h": 4297180475,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297180475)
  ],
  "h": 2213179
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$pgHg.LCIDSM.SmartParkDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2213179)
        
        

        //--TRIMMABLE-BOUNDARY-START(3130683)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkServiceModelTypeDescriptor`, ($self) => class SmartParkServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSM.SmartParkServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298097979)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298097979);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$pgHg.LCIDSM.SmartParkServiceModelTypeDescriptor.GenerateProperties($.$pgHg.LCIDSM.SmartParkServiceModel, this, factory);
                    }, $jnXWsf ??= {"r":65537,"n":"","d":3130683,"h":0,"f":17825794}), 0, "SmartParkServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SmartPark\\Models_SmartParkServiceModel_LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkServiceModelTypeDescriptorBuilder.g.cs", "SmartParkServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298097979)
            
            //--TRIMMABLE-BOUNDARY-START(12888032571)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888032571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888032571)
            
            //--TRIMMABLE-BOUNDARY-START(17182999867)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182999867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceModel, LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceSettings, LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceSendDataModel, LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkDeviceStatusHandler, LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkDeviceHubClient, LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182999867)
            
            //--TRIMMABLE-BOUNDARY-START(8593065275)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593065275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$pgHg.LCIDSM.SmartParkServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$pgHg.LCIDSM.SmartParkServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkServiceModel)))
                {
                    /*var*/ let result = $.$pgHg.LCIDSM.SmartParkServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$pgHg.LCIDSM.SmartParkServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593065275)
            
            static $h = 3130683;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSM.SmartParkServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888032571),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3130683,
      "h": 12888032571,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888032571),
//--TRIMMABLE-BOUNDARY-START(17182999867),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2999611,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3130683,
      "h": 17182999867,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182999867),
//--TRIMMABLE-BOUNDARY-START(8593065275),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2999611,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3130683,
      "h": 8593065275,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593065275)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298097979),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3130683,
      "h": 4298097979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298097979)
  ],
  "h": 3130683
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$pgHg.LCIDSM.SmartParkServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3130683)
        
        

        //--TRIMMABLE-BOUNDARY-START(4441403)
        $asm.$cls(`$pgHg.LCIDSS$1.SmartParkDeviceSettingsTypeDescriptor`, ($self) => class SmartParkDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSS$1.SmartParkDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299408699)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299408699);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$pgHg.LCIDSS$1.SmartParkDeviceSettingsTypeDescriptor.GenerateProperties($.$pgHg.LCIDSS$1.SmartParkDeviceSettings, this, factory);
                    }, $ohpuhj ??= {"r":65537,"n":"","d":4441403,"h":0,"f":17825794}), 0, "SmartParkDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SmartPark\\Settings_SmartParkDeviceSettings_LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceSettingsTypeDescriptorBuilder.g.cs", "SmartParkDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299408699)
            
            //--TRIMMABLE-BOUNDARY-START(12889343291)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889343291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("HasMetering"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings.$type, $.$discardRef(), "HasMetering", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("HasMetering")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "HasMetering";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSS$1.SmartParkDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings)).HasMetering);
                        }, $SMWqAd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4441403,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$pgHg.LCIDSS$1.SmartParkDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.HasMetering = value.AsBool();
                        }, $bHtRgj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4441403,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889343291)
            
            //--TRIMMABLE-BOUNDARY-START(17184310587)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184310587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceModel, LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceSettings, LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceSendDataModel, LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkDeviceStatusHandler, LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkDeviceHubClient, LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).iSmartDeviceSettings));
                {
                    /*var*/ let _HasMetering = _target.HasMetering;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("HasMetering"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _HasMetering, ($v) => _HasMetering = $v, null, true)))
                    {
                        _target.HasMetering = _HasMetering;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184310587)
            
            //--TRIMMABLE-BOUNDARY-START(8594375995)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594375995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$pgHg.LCIDSS$1.SmartParkDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings)))
                {
                    /*var*/ let result = $.$pgHg.LCIDSS$1.SmartParkDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594375995)
            
            static $h = 4441403;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSS$1.SmartParkDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889343291),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4441403,
      "h": 12889343291,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889343291),
//--TRIMMABLE-BOUNDARY-START(17184310587),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4310331,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4441403,
      "h": 17184310587,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184310587),
//--TRIMMABLE-BOUNDARY-START(8594375995),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4310331,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4441403,
      "h": 8594375995,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594375995)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299408699),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4441403,
      "h": 4299408699,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299408699)
  ],
  "h": 4441403
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$pgHg.LCIDSS$1.SmartParkDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Settings${separator}SmartParkDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4441403)
        
        

        //--TRIMMABLE-BOUNDARY-START(4179259)
        $asm.$cls(`$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettingsTypeDescriptor`, ($self) => class SmartParkDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299146555)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299146555);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, this, factory);
                    }, $dDEZHj ??= {"r":65537,"n":"","d":4179259,"h":0,"f":17825794}), 0, "SmartParkDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SmartPark\\Settings_SmartParkDeviceHardwareSettings_LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "SmartParkDeviceHardwareSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299146555)
            
            //--TRIMMABLE-BOUNDARY-START(12889081147)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889081147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889081147)
            
            //--TRIMMABLE-BOUNDARY-START(17184048443)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184048443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceModel, LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceSettings, LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceSendDataModel, LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkDeviceStatusHandler, LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkDeviceHubClient, LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).iSmartDeviceHardwareSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184048443)
            
            //--TRIMMABLE-BOUNDARY-START(8594113851)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594113851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594113851)
            
            static $h = 4179259;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889081147),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4179259,
      "h": 12889081147,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889081147),
//--TRIMMABLE-BOUNDARY-START(17184048443),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4048187,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4179259,
      "h": 17184048443,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184048443),
//--TRIMMABLE-BOUNDARY-START(8594113851),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4048187,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4179259,
      "h": 8594113851,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594113851)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299146555),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4179259,
      "h": 4299146555,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299146555)
  ],
  "h": 4179259
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Settings${separator}SmartParkDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4179259)
        
        

        //--TRIMMABLE-BOUNDARY-START(1688891)
        $asm.$cls(`$pgHg.LCIDSM.SmartParkDeviceModelTypeDescriptor`, ($self) => class SmartParkDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSM.SmartParkDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296656187)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296656187);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$pgHg.LCIDSM.SmartParkDeviceModelTypeDescriptor.GenerateProperties($.$pgHg.LCIDSM.SmartParkDeviceModel, this, factory);
                    }, $uFxppi ??= {"r":65537,"n":"","d":1688891,"h":0,"f":17825794}), 0, "SmartParkDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.SmartPark\\Models_SmartParkDeviceModel_LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceModelTypeDescriptorBuilder.g.cs", "SmartParkDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296656187)
            
            //--TRIMMABLE-BOUNDARY-START(12886590779)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886590779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886590779)
            
            //--TRIMMABLE-BOUNDARY-START(17181558075)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181558075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceModel, LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceSettings, LivingThing.Core.IOT.Devices.SmartPark.Settings.SmartParkDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceSendDataModel, LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkDeviceStatusHandler, LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkDeviceHubClient, LivingThing.Core.IOT.Devices.SmartPark.Services.ISmartParkRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181558075)
            
            //--TRIMMABLE-BOUNDARY-START(8591623483)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591623483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$pgHg.LCIDSM.SmartParkDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$pgHg.LCIDSM.SmartParkDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkDeviceModel)))
                {
                    /*var*/ let result = $.$pgHg.LCIDSM.SmartParkDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$pgHg.LCIDSM.SmartParkDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$pgHg.LCIDSM.SmartParkDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591623483)
            
            static $h = 1688891;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$pgHg.LCIDSM.SmartParkDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886590779),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1688891,
      "h": 12886590779,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886590779),
//--TRIMMABLE-BOUNDARY-START(17181558075),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1557819,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1688891,
      "h": 17181558075,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181558075),
//--TRIMMABLE-BOUNDARY-START(8591623483),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1557819,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1688891,
      "h": 8591623483,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591623483)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296656187),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1688891,
      "h": 4296656187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296656187)
  ],
  "h": 1688891
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$pgHg.LCIDSM.SmartParkDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Models.SmartParkDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Models${separator}SmartParkDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1688891)
        
        

        //--TRIMMABLE-BOUNDARY-START(4638011)
        $asm.$cls(`$pgHg.LCIDS.SmartParkDevice`, ($self) => class SmartParkDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$pgHg.LCIDSMS.SmartParkPowerStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4299605307)
            $ctor$2(/*IIOTDeviceFamily<SmartParkDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*SmartParkDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299605307);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299605307)
            
            //--TRIMMABLE-BOUNDARY-START(38659343675)
            /*IconDescriptor */ get Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25774441787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let icon = super.Icon;
                return (() =>
                {
                    //new $.$fPer.LCFC.IconDescriptor()
                    const $t1 = $.$fPer.LCFC.IconDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Icon = $.$XBGm.LCIC.UtilityExtension.MaterialIcon(this.Model$1.DeviceType, this.Full);
                    $i1.Theme = $.$with(icon.Theme, ($clone) =>
                    {
                        $clone.ForegroundColor = this.Full ? "FFFF00" : icon.Theme.ForegroundColor;
                    });
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(38659343675)
            
            //--TRIMMABLE-BOUNDARY-START(8594572603)
            /*bool */ get Full()
            {
                return ((this.Received?.Status?.Status ?? null)) === 15;
            }
            //--TRIMMABLE-BOUNDARY-END(8594572603)
            
            //--TRIMMABLE-BOUNDARY-START(42954310971)
            /*string */ get StatusText()
            {
                return this.Full ? "Full" : "OFF";
            }
            //--TRIMMABLE-BOUNDARY-END(42954310971)
            
            static $h = 4638011;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDS.SmartParkDevice, $.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$pgHg.LCIDSMS.SmartParkPowerStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38659343675),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25774441787,
        "f": 50364417
      },
      "n": "Icon",
      "d": 4638011,
      "h": 38659343675,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38659343675),
//--TRIMMABLE-BOUNDARY-START(8594572603),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17184507195,
        "f": 50331649
      },
      "n": "Full",
      "d": 4638011,
      "h": 8594572603,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8594572603),
//--TRIMMABLE-BOUNDARY-START(42954310971),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34364376379,
        "f": 50364417
      },
      "n": "StatusText",
      "d": 4638011,
      "h": 42954310971,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42954310971)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299605307),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$pgHg.LCIDS.SmartParkDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 1557819
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4638011,
      "h": 4299605307,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299605307)
  ],
  "h": 4638011
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.SmartParkDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}SmartParkDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4638011)
        
        

        //--TRIMMABLE-BOUNDARY-START(4703547)
        $asm.$cls(`$pgHg.LCIDS.SmartParkDeviceDefinition`, ($self) => class SmartParkDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDS.SmartParkDevice, $.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$pgHg.LCIDSMS.SmartParkPowerStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299670843)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299670843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299670843)
            
            //--TRIMMABLE-BOUNDARY-START(4299670843)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299670843)
            
            static $h = 4703547;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDS.SmartParkDevice, $.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$pgHg.LCIDSMS.SmartParkPowerStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299670843),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4703547,
      "h": 4299670843,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299670843)
  ],
  "h": 4703547
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.SmartParkDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}SmartParkDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4703547)
        
        

        //--TRIMMABLE-BOUNDARY-START(4769083)
        $asm.$cls(`$pgHg.LCIDS.SmartParkDeviceFamily`, ($self) => class SmartParkDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDS.SmartParkDevice, $.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4299736379)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<SmartParkDeviceReceivedDataModel, SmartParkDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<SmartParkDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299736379);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299736379)
            
            static $h = 4769083;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$pgHg.LCIDS.SmartParkDevice, $.$pgHg.LCIDSM.SmartParkServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$pgHg.LCIDSM.SmartParkDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$pgHg.LCIDSM.SmartParkDeviceModel, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel, $.$pgHg.LCIDSS.ISmartParkDeviceStatusHandler, $.$pgHg.LCIDSS.ISmartParkDeviceHubClient, $.$pgHg.LCIDSS.ISmartParkRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299736379),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4769083,
      "h": 4299736379,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299736379)
  ],
  "h": 4769083
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$pgHg.LCIDS.SmartParkDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$pgHg.LCIDS.SmartParkDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.SmartParkDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}SmartParkDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4769083)
        
        

        //--TRIMMABLE-BOUNDARY-START(5096763)
        $asm.$cls(`$pgHg.LCIDSV.SmartParkViewRenderer`, ($self) => class SmartParkViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$pgHg.LCIDS.SmartParkDevice, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4300064059)
            $ctor$3(/*IOTRootViewModel*/ root)
            {
                super.$ctor$2(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300064059);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300064059)
            
            //--TRIMMABLE-BOUNDARY-START(8595031355)
            /*RenderFragment */ GetView(/*IClientUnitOfWork*/ ui, /*SmartParkDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>*/ clicked, /*Func<Task>*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595031355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === 3/*DeviceViewType.Details*/)
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$pgHg.LCIDSV.SmartParkDeviceDetails, $.$pgHg.LCIDSV.SmartParkDetailsViewModel, new $.$pgHg.LCIDSV.SmartParkDetailsViewModel().$ctor$9(this.Root, device.OwnerScope, device), true, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(8595031355)
            
            static $h = 5096763;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$pgHg.LCIDS.SmartParkDevice, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595031355),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 4638011
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 5096763,
      "h": 8595031355,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8595031355)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300064059),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5096763,
      "h": 4300064059,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300064059)
  ],
  "h": 5096763
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$pgHg.LCIDS.SmartParkDevice), $.$ntej.LCICD$1.IDeviceViewRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Views.SmartParkViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Views${separator}SmartParkViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5096763)
        
        

        //--TRIMMABLE-BOUNDARY-START(4965691)
        $asm.$cls(`$pgHg.LCIDSV.SmartParkDetailsViewModel`, ($self) => class SmartParkDetailsViewModel extends $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$pgHg.LCIDS.SmartParkDevice, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299932987)
            $ctor$9(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*SmartParkDevice*/ device)
            {
                super.$ctor$8(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299932987);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299932987)
            
            //--TRIMMABLE-BOUNDARY-START(8594900283)
            /*void */ OnPropertyChanged$1(/*object*/ sender, /*PropertyChangedEventArgs*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594900283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (sender === this.Device$1 && (args.PropertyName === "Status" || args.PropertyName === "ReceivedStatus"))
                {
                }
                super.OnPropertyChanged$1(sender, args);
            }
            //--TRIMMABLE-BOUNDARY-END(8594900283)
            
            static $h = 4965691;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$pgHg.LCIDS.SmartParkDevice, $.$pgHg.LCIDSS$1.SmartParkDeviceSettings, $.$pgHg.LCIDSS$1.SmartParkDeviceHardwareSettings, $.$pgHg.LCIDSM.SmartParkDeviceReceivedDataModel, $.$pgHg.LCIDSM.SmartParkDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594900283),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "args",
          "p": 1310738
        }
      ],
      "n": "OnPropertyChanged",
      "o": "@$1",
      "d": 4965691,
      "h": 8594900283,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8594900283)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299932987),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 4638011
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 4965691,
      "h": 4299932987,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299932987)
  ],
  "h": 4965691
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICDV.IDeviceDetailsViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Views.SmartParkDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Views${separator}SmartParkDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4965691)
        
        

        //--TRIMMABLE-BOUNDARY-START(5031227)
        $asm.$cls(`$pgHg.LCIDSV.SmartParkDeviceDetails`, ($self) => class SmartParkDeviceDetails extends $.$hDPm.LCFCC$1.BaseComponent$$($.$pgHg.LCIDSV.SmartParkDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(60134573371)
            /*string */ get OptimizedComponentName()
            {
                return "smartparkdevicedetails";
            }
            //--TRIMMABLE-BOUNDARY-END(60134573371)
            
            //--TRIMMABLE-BOUNDARY-START(85904377147)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85904377147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$pgHg.LCIDSV.SmartParkDetailsViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(85904377147)
            
            //--TRIMMABLE-BOUNDARY-START(55839606075)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55839606075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.UI = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IUIClientService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(55839606075)
            
            //--TRIMMABLE-BOUNDARY-START(94494311739)
            /*SmartParkDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(94494311739)
            
            //--TRIMMABLE-BOUNDARY-START(21479867707)
            /*string[]*/ Cards = null;
            //--TRIMMABLE-BOUNDARY-END(21479867707)
            
            //--TRIMMABLE-BOUNDARY-START(90199344443)
            /*IUIClientService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(90199344443)
            
            //--TRIMMABLE-BOUNDARY-START(81609409851)
            /*ValueTask *//*async*/  Topup()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81609409851);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let cardId = ($t2 = this.UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Prompt($.$$.S.String, "Card Id", `Please enter your car id`, "OK", "Cancel", null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    /*var*/ let n = $.$$.S.Array.IndexOf$5($.$$.S.String, this.Cards, $.$$.S.String.Trim.call($.$$.S.String.ToUpper.call(cardId)));
                    if (n < 0)
                    {
                        let $t3, $r3;
                        ($t3 = $.$hDPm.LCFCI.ViewPresenterExtensions.MessageBox($.$hDPm.LCFCI.ViewConfiguration, this.UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Error`, false), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Unknown Card`, false), null, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                    /*var*/ let amount = ($t4 = this.UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Prompt($.$$.S.Int32, "Unit", `Please enter unit to top up (1 - 100)`, "OK", "Cancel", null, 0), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    amount %= 100;
                    try
                    {
                        let $t5, $r5;
                        ($t5 = $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$pgHg.LCIDSPCV.SmartParkTopupCommand, $.$pgHg.LCIDSMC.SmartParkTopupModel, this.ViewModel.Device$1, new $.$pgHg.LCIDSPCV.SmartParkTopupCommand().$ctor$6(), (() =>
                        {
                            //new $.$pgHg.LCIDSMC.SmartParkTopupModel()
                            const $t6 = $.$pgHg.LCIDSMC.SmartParkTopupModel;
                            const $i6 = new $t6();
                            $i6.$ctor$2();
                            $i6.Card = ((n + 1) | 0);
                            $i6.Amount = amount;
                            return $i6;
                        })()), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    }
                    catch($e)
                    {
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(81609409851)
            
            //--TRIMMABLE-BOUNDARY-START(25774835003)
            /*ValueTask *//*async*/  CheckIn(/*int*/ n)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25774835003);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t7, $r7;
                        /*var*/ let r = ($t7 = $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.SendCommand$2($.$pgHg.LCIDSPCV.SmartParkCheckInCommand, $.$pgHg.LCIDSMC.SmartParkCheckInRequestModel, $.$pgHg.LCIDSMC.SmartParkCheckInResponseModel, this.ViewModel.Device$1, new $.$pgHg.LCIDSPCV.SmartParkCheckInCommand().$ctor$6(), (() =>
                        {
                            //new $.$pgHg.LCIDSMC.SmartParkCheckInRequestModel()
                            const $t8 = $.$pgHg.LCIDSMC.SmartParkCheckInRequestModel;
                            const $i8 = new $t8();
                            $i8.$ctor$2();
                            $i8.Card = ((n + 1) | 0);
                            return $i8;
                        })(), null), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                        if (r.Data.Code === 0)
                        {
                            let $t9, $r9;
                            ($t9 = $.$hDPm.LCFCI.ViewPresenterExtensions.MessageBox($.$hDPm.LCFCI.ViewConfiguration, this.UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Success`, false), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `You are Checked In`, false), null, null), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                        }
                        else if (r.Data.Code === 1)
                        {
                            let $t10, $r10;
                            ($t10 = $.$hDPm.LCFCI.ViewPresenterExtensions.MessageBox($.$hDPm.LCFCI.ViewConfiguration, this.UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Error`, false), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Unknown Card`, false), null, null), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                        }
                        else if (r.Data.Code === 2)
                        {
                            let $t11, $r11;
                            ($t11 = $.$hDPm.LCFCI.ViewPresenterExtensions.MessageBox($.$hDPm.LCFCI.ViewConfiguration, this.UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Error`, false), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Insufficient Balance. Please Topup`, false), null, null), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                        }
                    }
                    catch($e)
                    {
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25774835003)
            
            //--TRIMMABLE-BOUNDARY-START(17184900411)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184900411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$pgHg.LCIDS.SmartParkDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$pgHg.LCIDS.SmartParkDevice), this.ViewModel));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(3, "div");
                    __builder2.AddAttribute$5(4, "class", "grid gap-1 colm-15 pd");
                    for(/*int*/ let i = 0; i < 4; i++)
                    {
                        /*var*/ let empty = (((this.ViewModel.Device$1.Received?.Status?.Status ?? null) ?? 0) & (1 << i)) === 0;
                        __builder2.OpenElement(5, "div");
                        __builder2.AddAttribute$5(6, "class", `pos-rel pd bg-${$.$strNN((i === 0 ? "primary" : i === 1 ? "secondary" : i === 2 ? "warning" : "fatal"))}-${$.$strNN((!empty ? "03" : "09"))} flex mihx-2`);
                        __builder2.OpenElement(7, "h1");
                        __builder2.AddAttribute$5(8, "class", "mg-a");
                        __builder2.AddContent$4(9, "Slot ");
                        __builder2.AddContent$3(10, $.$box(((i + 1) | 0), $.$$.S.Int32));
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(11, "\r\n                ");
                        __builder2.OpenElement(12, "div");
                        __builder2.AddAttribute$5(13, "class", "pos-abs b-0 r-0 pd");
                        __builder2.AddContent$4(14, !empty ? "Taken" : "Empty");
                        if (empty)
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$$.S.Int32), 15);
                            __builder2.AddComponentParameter(16, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 128/*ButtonFeatures.XSmall*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                            __builder2.AddComponentParameter(17, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.Int32), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$$.S.Int32, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.ValueTask))().$ctor(this, this.CheckIn))));
                            __builder2.AddComponentParameter(18, "CommandParameter", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, i), $.$$.S.Int32));
                            __builder2.AddComponentParameter(19, "Class", "mg");
                            __builder2.AddComponentParameter(20, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                            __builder2.AddAttribute$3(21, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                            {
                                __builder3.AddContent$4(22, "Book");
                            }), $Cwudii ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":5031227,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(23, "\r\n    ");
                    __builder2.OpenElement(24, "div");
                    __builder2.AddAttribute$5(25, "class", "mg");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 26);
                    __builder2.AddComponentParameter(27, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Topup))));
                    __builder2.AddComponentParameter(28, "Class", "wf");
                    __builder2.AddComponentParameter(29, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder2.AddAttribute$3(30, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddContent$4(31, "Topup");
                    }), $xjFZwc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":5031227,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                }), $haRqNf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":5031227,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17184900411)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12889933115)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889933115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12889933115)
            
            //--TRIMMABLE-BOUNDARY-START(12889933115)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12889933115)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21479867707)
                this.Cards = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["308C584E", "92F65D47", "D28BD321", "C2BFCC21"], [-1], null);
                //--TRIMMABLE-BOUNDARY-END(21479867707)
                
                //--TRIMMABLE-BOUNDARY-START(90199344443)
                this.UI = null;
                //--TRIMMABLE-BOUNDARY-END(90199344443)
                
            }
            static $h = 5031227;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$pgHg.LCIDSV.SmartParkDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60134573371),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34364769595,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 5031227,
      "h": 60134573371,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60134573371),
//--TRIMMABLE-BOUNDARY-START(94494311739),
    {
      "p": 4965691,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51544638779,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77314442555,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 5031227,
      "h": 94494311739,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94494311739),
//--TRIMMABLE-BOUNDARY-START(90199344443),
    {
      "p": 65492650,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42954704187,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68724507963,
        "f": 83886081
      },
      "n": "UI",
      "d": 5031227,
      "h": 90199344443,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90199344443)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85904377147),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 5031227,
      "h": 85904377147,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85904377147),
//--TRIMMABLE-BOUNDARY-START(55839606075),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 5031227,
      "h": 55839606075,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55839606075),
//--TRIMMABLE-BOUNDARY-START(81609409851),
    {
      "r": 181338113,
      "n": "Topup",
      "d": 5031227,
      "h": 81609409851,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(81609409851),
//--TRIMMABLE-BOUNDARY-START(25774835003),
    {
      "r": 181338113,
      "p": [
        {
          "n": "n",
          "p": 655361
        }
      ],
      "n": "CheckIn",
      "d": 5031227,
      "h": 25774835003,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(25774835003),
//--TRIMMABLE-BOUNDARY-START(17184900411),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 5031227,
      "h": 17184900411,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17184900411)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21479867707),
    {
      "t": $.$typeArray($.$$.S.String).$h,
      "n": "Cards",
      "d": 5031227,
      "h": 21479867707,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21479867707)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12889933115),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 5031227,
      "h": 12889933115,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889933115)
  ],
  "h": 5031227
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartPark.Views.SmartParkDeviceDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartPark${separator}Views${separator}SmartParkDeviceDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5031227)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(50491)
