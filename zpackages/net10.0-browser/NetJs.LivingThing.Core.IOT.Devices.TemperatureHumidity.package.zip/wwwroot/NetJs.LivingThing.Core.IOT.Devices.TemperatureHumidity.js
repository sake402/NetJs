
//--TRIMMABLE-BOUNDARY-START(8573)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $gGpILb;
    let $OVrhmc;
    let $OmxQxd;
    let $vGZoTb;
    let $WLnMga;
    let $gmjDUd;
    let $wKNJwd;
    let $SqnWbh;
    let $DPpOng;
    let $VoPXnk;
    let $GZCiQk;
    let $eqHPeg;
    let $FkQzRc;
    let $YCmXla;
    let $UxKpmj;
    let $orbnNb;
    let $qjLLWi;
    let $njfaqf;
    let $meqYud;
    let $CCjaUj;
    let $udoHFc;
    let $gFCSka;
    let $YUVUoc;
    let $jOBbtf;
    let $xdfUrf;
    let $EsdQcd;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.TemperatureHumidity", 
    {
  "h": 8573,
  "f": "LivingThing.Core.IOT.Devices.TemperatureHumidity",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.TemperatureHumidity",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.TemperatureHumidity",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5UZW1wZXJhdHVyZUh1bWlkaXR5LlRlbXBlcmF0dXJlSHVtaWRpdHlEZXZpY2UiOiB7DQogICAgICAiQ2F0ZWdvcmllcyI6IFsgIlNtYXJ0IEhvbWUiIF0sDQogICAgICAiTmFtZSI6ICJUZW1wZXJhdHVyZUh1bWlkaXR5IiwNCiAgICAgICJEZXNjcmlwdGlvbiI6ICIiLA0KICAgICAgIkJhbm5lckltYWdlIjogIn4vVGVtcGVyYXR1cmVIdW1pZGl0eS9pbWcvYmFubmVyLmpwZyIsDQogICAgICAiSWNvbiI6IHsgIk5hbWUiOiAibWRpIG1kaS1lbGVjdHJpYy1zd2l0Y2giIH0sDQogICAgICAiVGhlbWVDb2xvciI6ICIjZDc3YmJhIiwNCiAgICAgICJGbGFncyI6ICJGZWF0dXJlZCxQdWJsaXNoZWQiLA0KICAgICAgIlNlY3VyaXRpZXMiOiAiQ2hhbGxlbmdlSGFuZFNoYWtlQXV0aGVudGljYXRpb25Qcm90b2NvbCxBZHZhbmNlZEVuY3J5cHRpb25TdGFuZGFyZCxFbGxpcHRpY0N1cnZlRmlybXdhcmVVcGRhdGVTaWduaW5nIg0KICAgIH0NCiAgfQ0KfQ=="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(74109)
        $asm.$cls(`$hmEn.LCIDT._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295041405)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295041405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$hmEn.LCIDT.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295041405)
            
            static $h = 74109;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295041405),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 74109,
      "h": 4295041405,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295041405)
  ],
  "h": 74109
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(74109)
        
        

        //--TRIMMABLE-BOUNDARY-START(663933)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityDeviceModelCustomAttributesProvider`, ($self) => class TemperatureHumidityDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295631229)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295631229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295631229)
            
            static $h = 663933;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295631229),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 663933,
      "h": 4295631229,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295631229)
  ],
  "h": 663933
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(663933)
        
        

        //--TRIMMABLE-BOUNDARY-START(1188221)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModelCustomAttributesProvider`, ($self) => class TemperatureHumidityDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296155517)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296155517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296155517)
            
            static $h = 1188221;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296155517),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1188221,
      "h": 4296155517,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296155517)
  ],
  "h": 1188221
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1188221)
        
        

        //--TRIMMABLE-BOUNDARY-START(2302333)
        $asm.$cls(`$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class TemperatureHumidityDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297269629)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297269629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297269629)
            
            static $h = 2302333;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297269629),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2302333,
      "h": 4297269629,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297269629)
  ],
  "h": 2302333
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Settings${separator}TemperatureHumidityDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2302333)
        
        

        //--TRIMMABLE-BOUNDARY-START(1450365)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModelCustomAttributesProvider`, ($self) => class TemperatureHumidityDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296417661)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296417661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceCommandsModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296417661)
            
            static $h = 1450365;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296417661),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1450365,
      "h": 4296417661,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296417661)
  ],
  "h": 1450365
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1450365)
        
        

        //--TRIMMABLE-BOUNDARY-START(205181)
        $asm.$cls(`$hmEn.LCIDT.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295172477)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295172477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$hmEn.LCIDTMS.TemperatureHumidityStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$hmEn.LCIDTMS.TemperatureHumidityStatusModelCustomAttributesProvider, $.$hmEn.LCIDTMS.TemperatureHumidityStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$hmEn.LCIDTM.TemperatureHumidityDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$hmEn.LCIDTM.TemperatureHumidityDeviceModelCustomAttributesProvider, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModelCustomAttributesProvider, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModelCustomAttributesProvider, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModelCustomAttributesProvider, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$hmEn.LCIDTM.TemperatureHumidityServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$hmEn.LCIDTM.TemperatureHumidityServiceModelCustomAttributesProvider, $.$hmEn.LCIDTM.TemperatureHumidityServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettingsCustomAttributesProvider, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettingsCustomAttributesProvider, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295172477)
            
            static $h = 205181;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295172477),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 205181,
      "h": 4295172477,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295172477)
  ],
  "h": 205181
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(205181)
        
        

        //--TRIMMABLE-BOUNDARY-START(3088765)
        $asm.$cls(`$hmEn.LCIDT.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298056061)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298056061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hmEn.LCIDTMS.TemperatureHumidityStatusModelTypeDescriptorBuilder.Register();
                $.$hmEn.LCIDTM.TemperatureHumidityDeviceModelTypeDescriptorBuilder.Register();
                $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$hmEn.LCIDTM.TemperatureHumidityServiceModelTypeDescriptorBuilder.Register();
                $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298056061)
            
            static $h = 3088765;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298056061),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3088765,
      "h": 4298056061,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298056061)
  ],
  "h": 3088765
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3088765)
        
        

        //--TRIMMABLE-BOUNDARY-START(2564477)
        $asm.$cls(`$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettingsCustomAttributesProvider`, ($self) => class TemperatureHumidityDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297531773)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297531773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297531773)
            
            static $h = 2564477;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297531773),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2564477,
      "h": 4297531773,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297531773)
  ],
  "h": 2564477
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Settings${separator}TemperatureHumidityDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2564477)
        
        

        //--TRIMMABLE-BOUNDARY-START(1057149)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class TemperatureHumidityDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590991741)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590991741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $OVrhmc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1057149,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590991741)
            
            //--TRIMMABLE-BOUNDARY-START(4296024445)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296024445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296024445)
            
            //--TRIMMABLE-BOUNDARY-START(4296024445)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296024445)
            
            static $h = 1057149;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590991741),
    {
      "r": 65537,
      "n": "Register",
      "d": 1057149,
      "h": 8590991741,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590991741)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296024445),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1057149,
      "h": 4296024445,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296024445)
  ],
  "h": 1057149
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1057149)
        
        

        //--TRIMMABLE-BOUNDARY-START(2433405)
        $asm.$cls(`$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class TemperatureHumidityDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592367997)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592367997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $DPpOng ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2433405,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592367997)
            
            //--TRIMMABLE-BOUNDARY-START(4297400701)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297400701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297400701)
            
            //--TRIMMABLE-BOUNDARY-START(4297400701)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297400701)
            
            static $h = 2433405;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592367997),
    {
      "r": 65537,
      "n": "Register",
      "d": 2433405,
      "h": 8592367997,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592367997)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297400701),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2433405,
      "h": 4297400701,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297400701)
  ],
  "h": 2433405
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Settings${separator}TemperatureHumidityDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2433405)
        
        

        //--TRIMMABLE-BOUNDARY-START(1319293)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModelTypeDescriptorBuilder`, ($self) => class TemperatureHumidityDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591253885)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591253885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $wKNJwd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1319293,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591253885)
            
            //--TRIMMABLE-BOUNDARY-START(4296286589)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296286589);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296286589)
            
            //--TRIMMABLE-BOUNDARY-START(4296286589)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296286589)
            
            static $h = 1319293;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591253885),
    {
      "r": 65537,
      "n": "Register",
      "d": 1319293,
      "h": 8591253885,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591253885)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296286589),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1319293,
      "h": 4296286589,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296286589)
  ],
  "h": 1319293
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1319293)
        
        

        //--TRIMMABLE-BOUNDARY-START(1712509)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityServiceModelCustomAttributesProvider`, ($self) => class TemperatureHumidityServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296679805)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296679805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296679805)
            
            static $h = 1712509;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296679805),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1712509,
      "h": 4296679805,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296679805)
  ],
  "h": 1712509
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1712509)
        
        

        //--TRIMMABLE-BOUNDARY-START(926077)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class TemperatureHumidityDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295893373)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295893373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$hmEn.LCIDTMS.TemperatureHumidityStatusModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295893373)
            
            static $h = 926077;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295893373),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 926077,
      "h": 4295893373,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295893373)
  ],
  "h": 926077
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(926077)
        
        

        //--TRIMMABLE-BOUNDARY-START(795005)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityDeviceModelTypeDescriptorBuilder`, ($self) => class TemperatureHumidityDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590729597)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590729597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$hmEn.LCIDTM.TemperatureHumidityDeviceModelTypeDescriptor()
                        const $t1 = $.$hmEn.LCIDTM.TemperatureHumidityDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $GZCiQk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":795005,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$hmEn.LCIDTM.TemperatureHumidityDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590729597)
            
            //--TRIMMABLE-BOUNDARY-START(4295762301)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295762301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295762301)
            
            //--TRIMMABLE-BOUNDARY-START(4295762301)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295762301)
            
            static $h = 795005;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590729597),
    {
      "r": 65537,
      "n": "Register",
      "d": 795005,
      "h": 8590729597,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590729597)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295762301),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 795005,
      "h": 4295762301,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295762301)
  ],
  "h": 795005
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(795005)
        
        

        //--TRIMMABLE-BOUNDARY-START(532861)
        $asm.$cls(`$hmEn.LCIDTMS.TemperatureHumidityStatusModelTypeDescriptorBuilder`, ($self) => class TemperatureHumidityStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590467453)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590467453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$hmEn.LCIDTMS.TemperatureHumidityStatusModelTypeDescriptor()
                        const $t1 = $.$hmEn.LCIDTMS.TemperatureHumidityStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.Statuses.TemperatureHumidityStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $meqYud ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":532861,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$hmEn.LCIDTMS.TemperatureHumidityStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590467453)
            
            //--TRIMMABLE-BOUNDARY-START(4295500157)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295500157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295500157)
            
            //--TRIMMABLE-BOUNDARY-START(4295500157)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295500157)
            
            static $h = 532861;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590467453),
    {
      "r": 65537,
      "n": "Register",
      "d": 532861,
      "h": 8590467453,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590467453)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295500157),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 532861,
      "h": 4295500157,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295500157)
  ],
  "h": 532861
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.Statuses.TemperatureHumidityStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}Statuses${separator}TemperatureHumidityStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(532861)
        
        

        //--TRIMMABLE-BOUNDARY-START(1581437)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class TemperatureHumidityDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591516029)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591516029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $FkQzRc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1581437,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591516029)
            
            //--TRIMMABLE-BOUNDARY-START(4296548733)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296548733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296548733)
            
            //--TRIMMABLE-BOUNDARY-START(4296548733)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296548733)
            
            static $h = 1581437;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591516029),
    {
      "r": 65537,
      "n": "Register",
      "d": 1581437,
      "h": 8591516029,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591516029)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296548733),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1581437,
      "h": 4296548733,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296548733)
  ],
  "h": 1581437
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1581437)
        
        

        //--TRIMMABLE-BOUNDARY-START(401789)
        $asm.$cls(`$hmEn.LCIDTMS.TemperatureHumidityStatusModelCustomAttributesProvider`, ($self) => class TemperatureHumidityStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295369085)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295369085)
            
            //--TRIMMABLE-BOUNDARY-START(8590336381)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590336381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$hmEn.LCIDTMS.TemperatureHumidityStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Temperature", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.ConvertType = ($.$$.S.Single.$type);
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Class=1"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Humidity", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.ConvertType = ($.$$.S.Single.$type);
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Class=2"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$hmEn.LCIDTMS.TemperatureHumidityStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $UxKpmj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":401789,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $orbnNb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":401789,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590336381)
            
            static $h = 401789;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590336381),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 401789,
      "h": 8590336381,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590336381)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295369085),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 401789,
      "h": 4295369085,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295369085)
  ],
  "h": 401789
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.Statuses.TemperatureHumidityStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}Statuses${separator}TemperatureHumidityStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(401789)
        
        

        //--TRIMMABLE-BOUNDARY-START(1843581)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityServiceModelTypeDescriptorBuilder`, ($self) => class TemperatureHumidityServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591778173)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591778173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$hmEn.LCIDTM.TemperatureHumidityServiceModelTypeDescriptor()
                        const $t1 = $.$hmEn.LCIDTM.TemperatureHumidityServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $qjLLWi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1843581,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$hmEn.LCIDTM.TemperatureHumidityServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591778173)
            
            //--TRIMMABLE-BOUNDARY-START(4296810877)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296810877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296810877)
            
            //--TRIMMABLE-BOUNDARY-START(4296810877)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296810877)
            
            static $h = 1843581;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591778173),
    {
      "r": 65537,
      "n": "Register",
      "d": 1843581,
      "h": 8591778173,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591778173)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296810877),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1843581,
      "h": 4296810877,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296810877)
  ],
  "h": 1843581
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1843581)
        
        

        //--TRIMMABLE-BOUNDARY-START(2695549)
        $asm.$cls(`$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettingsTypeDescriptorBuilder`, ($self) => class TemperatureHumidityDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592630141)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592630141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettingsTypeDescriptor()
                        const $t1 = $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $xdfUrf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2695549,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592630141)
            
            //--TRIMMABLE-BOUNDARY-START(4297662845)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297662845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297662845)
            
            //--TRIMMABLE-BOUNDARY-START(4297662845)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297662845)
            
            static $h = 2695549;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592630141),
    {
      "r": 65537,
      "n": "Register",
      "d": 2695549,
      "h": 8592630141,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592630141)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297662845),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2695549,
      "h": 4297662845,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297662845)
  ],
  "h": 2695549
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Settings${separator}TemperatureHumidityDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2695549)
        
        

        //--TRIMMABLE-BOUNDARY-START(139645)
        $asm.$cls(`$hmEn.LCIDT.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180008829)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180008829)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295106941)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295106941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295106941)
            
            //--TRIMMABLE-BOUNDARY-START(4295106941)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295106941)
            
            static $h = 139645;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180008829),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885041533,
        "f": 50331649
      },
      "n": "Paths",
      "d": 139645,
      "h": 17180008829,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180008829)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295106941),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 139645,
      "h": 4295106941,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295106941)
  ],
  "h": 139645
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(139645)
        
        

        //--TRIMMABLE-BOUNDARY-START(1909117)
        $asm.$cls(`$hmEn.LCIDT.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181778301)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$hmEn.LCIDTV$1.TemperatureHumidityDeviceDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$hmEn.LCIDTV$1.TemperatureHumidityDeviceDetails().$ctor$4();
                    }, $gGpILb ??= {"r":2752627,"n":"","d":1909117,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17181778301)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4296876413)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296876413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296876413)
            
            //--TRIMMABLE-BOUNDARY-START(4296876413)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296876413)
            
            static $h = 1909117;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181778301),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886811005,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 1909117,
      "h": 17181778301,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181778301)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296876413),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1909117,
      "h": 4296876413,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296876413)
  ],
  "h": 1909117
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1909117)
        
        

        //--TRIMMABLE-BOUNDARY-START(1974653)
        $asm.$cls(`$hmEn.LCIDT.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591909245)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591909245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$hmEn.LCIDT.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$hmEn.LCIDT.TemperatureHumidityDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$hmEn.LCIDT.TemperatureHumidityDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$hmEn.LCIDT.TemperatureHumidityDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$hmEn.LCIDT.TemperatureHumidityDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$hmEn.LCIDT.TemperatureHumidityDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hmEn.LCIDT.TemperatureHumidityDeviceFamily, x);
                }, $vGZoTb ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":1974653,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hmEn.LCIDT.TemperatureHumidityDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$hmEn.LCIDT.TemperatureHumidityDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $WLnMga ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":1974653,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$hmEn.LCIDT.TemperatureHumidityDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hmEn.LCIDT.TemperatureHumidityDeviceFamily, x);
                }, $gmjDUd ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$hmEn.LCIDT.TemperatureHumidityDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":1974653,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$hmEn.LCIDT.TemperatureHumidityDevice), $.$hmEn.LCIDTMC.TemperatureHumidityDeviceCommands$$($.$hmEn.LCIDT.TemperatureHumidityDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$hmEn.LCIDT.TemperatureHumidityDevice), $.$hmEn.LCIDTV$1.TemperatureHumidityViewRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$hmEn.LCIDTV.TemperatureHumidityClientAppViewModel, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591909245)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hmEn.LCIDT.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296941949)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296941949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296941949)
            
            //--TRIMMABLE-BOUNDARY-START(4296941949)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296941949)
            
            static $h = 1974653;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591909245),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1974653,
      "h": 8591909245,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591909245)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296941949),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1974653,
      "h": 4296941949,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296941949)
  ],
  "h": 1974653
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1974653)
        
        

        //--TRIMMABLE-BOUNDARY-START(3678589)
        $asm.$cls(`$hmEn.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298645885)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298645885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298645885)
            
            //--TRIMMABLE-BOUNDARY-START(4298645885)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298645885)
            
            static $h = 3678589;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298645885),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3678589,
      "h": 4298645885,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298645885)
  ],
  "h": 3678589
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3678589)
        
        

        //--TRIMMABLE-BOUNDARY-START(3744125)
        $asm.$cls(`$hmEn.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298711421)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298711421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298711421)
            
            //--TRIMMABLE-BOUNDARY-START(4298711421)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298711421)
            
            static $h = 3744125;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298711421),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3744125,
      "h": 4298711421,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298711421)
  ],
  "h": 3744125,
  "a": [
    {
      "t": 3678589,
      "c": 4298645885
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3744125)
        
        

        //--TRIMMABLE-BOUNDARY-START(336253)
        $asm.$cls(`$hmEn.LCIDTMS.TemperatureHumidityStatusModel`, ($self) => class TemperatureHumidityStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(55834911101)
            /*double*/ Temperature = 0;
            //--TRIMMABLE-BOUNDARY-END(55834911101)
            
            //--TRIMMABLE-BOUNDARY-START(34360074621)
            /*double*/ Humidity = 0;
            //--TRIMMABLE-BOUNDARY-END(34360074621)
            
            //--TRIMMABLE-BOUNDARY-START(12885238141)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885238141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885238141)
            
            //--TRIMMABLE-BOUNDARY-START(12885238141)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885238141)
            
            static $h = 336253;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55834911101),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065107325,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51539943805,
        "f": 83886081
      },
      "n": "Temperature",
      "d": 336253,
      "h": 55834911101,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//Class=1"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834911101),
//--TRIMMABLE-BOUNDARY-START(34360074621),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475172733,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950009213,
        "f": 83886081
      },
      "n": "Humidity",
      "d": 336253,
      "h": 34360074621,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//Class=2"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360074621)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885238141),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 336253,
      "h": 12885238141,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885238141)
  ],
  "h": 336253
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.Statuses.TemperatureHumidityStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}Statuses${separator}TemperatureHumidityStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(336253)
        
        

        //--TRIMMABLE-BOUNDARY-START(467325)
        $asm.$cls(`$hmEn.LCIDTMS.TemperatureHumidityStatusModelTypeDescriptor`, ($self) => class TemperatureHumidityStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hmEn.LCIDTMS.TemperatureHumidityStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295434621)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295434621);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$hmEn.LCIDTMS.TemperatureHumidityStatusModelTypeDescriptor.GenerateProperties($.$hmEn.LCIDTMS.TemperatureHumidityStatusModel, this, factory);
                    }, $CCjaUj ??= {"r":65537,"n":"","d":467325,"h":0,"f":17825794}), 0, "TemperatureHumidityStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TemperatureHumidity\\Models_Statuses_TemperatureAndHumidityStatusModel_LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.Statuses.TemperatureHumidityStatusModelTypeDescriptorBuilder.g.cs", "TemperatureHumidityStatusModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295434621)
            
            //--TRIMMABLE-BOUNDARY-START(12885369213)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885369213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Temperature"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$hmEn.LCIDTMS.TemperatureHumidityStatusModel.$type, $.$discardRef(), "Temperature", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Temperature")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Temperature";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.Statuses.TemperatureHumidityStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$hmEn.LCIDTMS.TemperatureHumidityStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$hmEn.LCIDTMS.TemperatureHumidityStatusModel)).Temperature);
                        }, $udoHFc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":467325,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$hmEn.LCIDTMS.TemperatureHumidityStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Temperature = value.AsDouble();
                        }, $gFCSka ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":467325,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Humidity"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$hmEn.LCIDTMS.TemperatureHumidityStatusModel.$type, $.$discardRef(), "Humidity", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Humidity")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Humidity";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.Statuses.TemperatureHumidityStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$hmEn.LCIDTMS.TemperatureHumidityStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$hmEn.LCIDTMS.TemperatureHumidityStatusModel)).Humidity);
                        }, $YUVUoc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":467325,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$hmEn.LCIDTMS.TemperatureHumidityStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Humidity = value.AsDouble();
                        }, $jOBbtf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":467325,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885369213)
            
            //--TRIMMABLE-BOUNDARY-START(17180336509)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.Statuses.TemperatureHumidityStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180336509);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _Temperature = _target.Temperature;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Temperature"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Temperature, ($v) => _Temperature = $v, $.$$.S.Double)))
                    {
                        _target.Temperature = _Temperature;
                    }
                }
                {
                    /*var*/ let _Humidity = _target.Humidity;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Humidity"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Humidity, ($v) => _Humidity = $v, $.$$.S.Double)))
                    {
                        _target.Humidity = _Humidity;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180336509)
            
            //--TRIMMABLE-BOUNDARY-START(8590401917)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.Statuses.TemperatureHumidityStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590401917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$hmEn.LCIDTMS.TemperatureHumidityStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$hmEn.LCIDTMS.TemperatureHumidityStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTMS.TemperatureHumidityStatusModel)))
                {
                    /*var*/ let result = $.$hmEn.LCIDTMS.TemperatureHumidityStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTMS.TemperatureHumidityStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$hmEn.LCIDTMS.TemperatureHumidityStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTMS.TemperatureHumidityStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590401917)
            
            static $h = 467325;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hmEn.LCIDTMS.TemperatureHumidityStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885369213),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 467325,
      "h": 12885369213,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885369213),
//--TRIMMABLE-BOUNDARY-START(17180336509),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 336253,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 467325,
      "h": 17180336509,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180336509),
//--TRIMMABLE-BOUNDARY-START(8590401917),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 336253,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 467325,
      "h": 8590401917,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590401917)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295434621),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 467325,
      "h": 4295434621,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295434621)
  ],
  "h": 467325
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$hmEn.LCIDTMS.TemperatureHumidityStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.Statuses.TemperatureHumidityStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}Statuses${separator}TemperatureHumidityStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(467325)
        
        

        //--TRIMMABLE-BOUNDARY-START(270717)
        $asm.$cls(`$hmEn.LCIDTMC.TemperatureHumidityDeviceCommands<>`, (TDevice) => $asm.$gt(`$hmEn.LCIDTMC.TemperatureHumidityDeviceCommands<>`, [TDevice], ($self) => class TemperatureHumidityDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12885172605)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12885172605)
            
            //--TRIMMABLE-BOUNDARY-START(17180139901)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel?*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180139901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$hmEn.LCIDTMC.TemperatureHumidityDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17180139901)
            
            //--TRIMMABLE-BOUNDARY-START(8590205309)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590205309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590205309)
            
            //--TRIMMABLE-BOUNDARY-START(8590205309)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590205309)
            
            //--TRIMMABLE-BOUNDARY-START(4295238013)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295238013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885172605)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12885172605)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295238013)
            
            static $H = 270717;
            static $h = 270717;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180139901),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17180139901,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180139901)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885172605),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12885172605,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885172605)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590205309),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8590205309,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590205309)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 270717,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.Commands.TemperatureHumidityDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}Commands${separator}TemperatureHumidityDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(270717)
        
        

        //--TRIMMABLE-BOUNDARY-START(1384829)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel`, ($self) => class TemperatureHumidityDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceCommandsModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296352125)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296352125);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296352125)
            
            //--TRIMMABLE-BOUNDARY-START(4296352125)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296352125)
            
            static $h = 1384829;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandsModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296352125),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1384829,
      "h": 4296352125,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296352125)
  ],
  "h": 1384829
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1384829)
        
        

        //--TRIMMABLE-BOUNDARY-START(860541)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel`, ($self) => class TemperatureHumidityDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$hmEn.LCIDTMS.TemperatureHumidityStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8590795133)
            /*IEnumerable<IIOTDeviceDataPointModel>? */ GetDataPoints(/*SchemaType*/ schemaType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590795133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (schemaType === 32/*SchemaType.Database*/)
                {
                    return null;
                }
                return super.GetDataPoints(schemaType);
            }
            //--TRIMMABLE-BOUNDARY-END(8590795133)
            
            //--TRIMMABLE-BOUNDARY-START(4295827837)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295827837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295827837)
            
            //--TRIMMABLE-BOUNDARY-START(4295827837)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295827837)
            
            static $h = 860541;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$hmEn.LCIDTMS.TemperatureHumidityStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590795133),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceDataPointModel).$h,
      "p": [
        {
          "n": "schemaType",
          "p": 2722134
        }
      ],
      "n": "GetDataPoints",
      "d": 860541,
      "h": 8590795133,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590795133)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295827837),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 860541,
      "h": 4295827837,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295827837)
  ],
  "h": 860541
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(860541)
        
        

        //--TRIMMABLE-BOUNDARY-START(1515901)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModelTypeDescriptor`, ($self) => class TemperatureHumidityDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296483197)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296483197);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModelTypeDescriptor.GenerateProperties($.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, this, factory);
                    }, $YCmXla ??= {"r":65537,"n":"","d":1515901,"h":0,"f":17825794}), 0, "TemperatureHumidityDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TemperatureHumidity\\Models_TemperatureAndHumidityDeviceSendDataModel_LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceSendDataModelTypeDescriptorBuilder.g.cs", "TemperatureHumidityDeviceSendDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296483197)
            
            //--TRIMMABLE-BOUNDARY-START(12886417789)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886417789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886417789)
            
            //--TRIMMABLE-BOUNDARY-START(17181385085)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181385085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandsModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandsModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181385085)
            
            //--TRIMMABLE-BOUNDARY-START(8591450493)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591450493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591450493)
            
            static $h = 1515901;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886417789),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1515901,
      "h": 12886417789,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886417789),
//--TRIMMABLE-BOUNDARY-START(17181385085),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1384829,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1515901,
      "h": 17181385085,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181385085),
//--TRIMMABLE-BOUNDARY-START(8591450493),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1384829,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1515901,
      "h": 8591450493,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591450493)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296483197),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1515901,
      "h": 4296483197,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296483197)
  ],
  "h": 1515901
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1515901)
        
        

        //--TRIMMABLE-BOUNDARY-START(991613)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModelTypeDescriptor`, ($self) => class TemperatureHumidityDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295958909)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295958909);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, this, factory);
                    }, $OmxQxd ??= {"r":65537,"n":"","d":991613,"h":0,"f":17825794}), 0, "TemperatureHumidityDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TemperatureHumidity\\Models_TemperatureAndHumidityDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "TemperatureHumidityDeviceReceivedDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295958909)
            
            //--TRIMMABLE-BOUNDARY-START(12885893501)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885893501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$hmEn.LCIDTMS.TemperatureHumidityStatusModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885893501)
            
            //--TRIMMABLE-BOUNDARY-START(17180860797)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180860797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.Statuses.TemperatureHumidityStatusModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$hmEn.LCIDTMS.TemperatureHumidityStatusModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$hmEn.LCIDTMS.TemperatureHumidityStatusModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180860797)
            
            //--TRIMMABLE-BOUNDARY-START(8590926205)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590926205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590926205)
            
            static $h = 991613;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885893501),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 991613,
      "h": 12885893501,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885893501),
//--TRIMMABLE-BOUNDARY-START(17180860797),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 860541,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 991613,
      "h": 17180860797,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180860797),
//--TRIMMABLE-BOUNDARY-START(8590926205),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 860541,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 991613,
      "h": 8590926205,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590926205)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295958909),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 991613,
      "h": 4295958909,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295958909)
  ],
  "h": 991613
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(991613)
        
        

        //--TRIMMABLE-BOUNDARY-START(2761085)
        $asm.$cls(`$hmEn.LCIDT.TemperatureHumidityDataConverter`, ($self) => class TemperatureHumidityDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297728381)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297728381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297728381)
            
            //--TRIMMABLE-BOUNDARY-START(4297728381)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297728381)
            
            static $h = 2761085;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297728381),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2761085,
      "h": 4297728381,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297728381)
  ],
  "h": 2761085
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.TemperatureHumidityDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}TemperatureHumidityDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2761085)
        
        

        //--TRIMMABLE-BOUNDARY-START(2040189)
        $asm.$cls(`$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient`, ($self) => class ITemperatureHumidityDeviceHubClient
        {
            static $h = 2040189;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2040189
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Services${separator}ITemperatureHumidityDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2040189)
        
        

        $asm.$typeProxy("$hmEn.LCIDTM.TemperatureHumidityServiceModel", "$hmEn.LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityServiceModel");
        $asm.$typeProxy("$hmEn.LCIDTM.TemperatureHumidityDeviceModel", "$hmEn.LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceModel");
        $asm.$typeProxy("$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings", "$hmEn.LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceSettings");
        $asm.$typeProxy("$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings", "$hmEn.LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceHardwareSettings");
        $asm.$typeProxy("$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler", "$hmEn.LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityDeviceStatusHandler");
        $asm.$typeProxy("$hmEn.LCIDTS.ITemperatureHumidityRemoteService", "$hmEn.LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityRemoteService");
        //--TRIMMABLE-BOUNDARY-START(1122685)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel`, ($self) => class TemperatureHumidityDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296089981)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296089981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296089981)
            
            //--TRIMMABLE-BOUNDARY-START(4296089981)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296089981)
            
            static $h = 1122685;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296089981),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1122685,
      "h": 4296089981,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296089981)
  ],
  "h": 1122685
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1122685)
        
        

        //--TRIMMABLE-BOUNDARY-START(598397)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityDeviceModel`, ($self) => class TemperatureHumidityDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295565693)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295565693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295565693)
            
            //--TRIMMABLE-BOUNDARY-START(4295565693)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295565693)
            
            static $h = 598397;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295565693),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 598397,
      "h": 4295565693,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295565693)
  ],
  "h": 598397
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(598397)
        
        

        //--TRIMMABLE-BOUNDARY-START(2498941)
        $asm.$cls(`$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings`, ($self) => class TemperatureHumidityDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $self, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297466237)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297466237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297466237)
            
            //--TRIMMABLE-BOUNDARY-START(4297466237)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297466237)
            
            static $h = 2498941;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297466237),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2498941,
      "h": 4297466237,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297466237)
  ],
  "h": 2498941
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Settings${separator}TemperatureHumidityDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2498941)
        
        

        //--TRIMMABLE-BOUNDARY-START(2105725)
        $asm.$cls(`$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler`, ($self) => class ITemperatureHumidityDeviceStatusHandler
        {
            static $h = 2105725;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2105725
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Services${separator}ITemperatureHumidityDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2105725)
        
        

        //--TRIMMABLE-BOUNDARY-START(2171261)
        $asm.$cls(`$hmEn.LCIDTS.ITemperatureHumidityRemoteService`, ($self) => class ITemperatureHumidityRemoteService
        {
            static $h = 2171261;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2171261
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Services${separator}ITemperatureHumidityRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2171261)
        
        

        //--TRIMMABLE-BOUNDARY-START(1646973)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityServiceModel`, ($self) => class TemperatureHumidityServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296614269)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296614269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296614269)
            
            //--TRIMMABLE-BOUNDARY-START(4296614269)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4296614269)
            
            static $h = 1646973;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296614269),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 1646973,
      "h": 4296614269,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296614269)
  ],
  "h": 1646973
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1646973)
        
        

        //--TRIMMABLE-BOUNDARY-START(2236797)
        $asm.$cls(`$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings`, ($self) => class TemperatureHumidityDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297204093)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297204093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297204093)
            
            //--TRIMMABLE-BOUNDARY-START(4297204093)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297204093)
            
            static $h = 2236797;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297204093),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2236797,
      "h": 4297204093,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297204093)
  ],
  "h": 2236797
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Settings${separator}TemperatureHumidityDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2236797)
        
        

        //--TRIMMABLE-BOUNDARY-START(3023229)
        $asm.$cls(`$hmEn.LCIDT.TemperatureHumidityDeviceModelDefinition`, ($self) => class TemperatureHumidityDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4297990525)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297990525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297990525)
            
            //--TRIMMABLE-BOUNDARY-START(4297990525)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297990525)
            
            static $h = 3023229;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297990525),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3023229,
      "h": 4297990525,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297990525)
  ],
  "h": 3023229
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.TemperatureHumidityDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}TemperatureHumidityDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3023229)
        
        

        //--TRIMMABLE-BOUNDARY-START(2367869)
        $asm.$cls(`$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettingsTypeDescriptor`, ($self) => class TemperatureHumidityDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297335165)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297335165);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, this, factory);
                    }, $VoPXnk ??= {"r":65537,"n":"","d":2367869,"h":0,"f":17825794}), 0, "TemperatureHumidityDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TemperatureHumidity\\Settings_TemperatureAndHumidityDeviceHardwareSettings_LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "TemperatureHumidityDeviceHardwareSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297335165)
            
            //--TRIMMABLE-BOUNDARY-START(12887269757)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887269757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887269757)
            
            //--TRIMMABLE-BOUNDARY-START(17182237053)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182237053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceSettings, LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceSendDataModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityDeviceStatusHandler, LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityDeviceHubClient, LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).iSmartDeviceHardwareSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182237053)
            
            //--TRIMMABLE-BOUNDARY-START(8592302461)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592302461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592302461)
            
            static $h = 2367869;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887269757),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2367869,
      "h": 12887269757,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887269757),
//--TRIMMABLE-BOUNDARY-START(17182237053),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2236797,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2367869,
      "h": 17182237053,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182237053),
//--TRIMMABLE-BOUNDARY-START(8592302461),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2236797,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2367869,
      "h": 8592302461,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592302461)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297335165),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2367869,
      "h": 4297335165,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297335165)
  ],
  "h": 2367869
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Settings${separator}TemperatureHumidityDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2367869)
        
        

        //--TRIMMABLE-BOUNDARY-START(1253757)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModelTypeDescriptor`, ($self) => class TemperatureHumidityDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296221053)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296221053);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModelTypeDescriptor.GenerateProperties($.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, this, factory);
                    }, $SqnWbh ??= {"r":65537,"n":"","d":1253757,"h":0,"f":17825794}), 0, "TemperatureHumidityDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TemperatureHumidity\\Models_TemperatureAndHumidityDeviceScopeModel_LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceScopeModelTypeDescriptorBuilder.g.cs", "TemperatureHumidityDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296221053)
            
            //--TRIMMABLE-BOUNDARY-START(12886155645)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886155645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886155645)
            
            //--TRIMMABLE-BOUNDARY-START(17181122941)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181122941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceSettings, LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceSendDataModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityDeviceStatusHandler, LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityDeviceHubClient, LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181122941)
            
            //--TRIMMABLE-BOUNDARY-START(8591188349)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591188349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel)))
                {
                    /*var*/ let result = $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591188349)
            
            static $h = 1253757;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886155645),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1253757,
      "h": 12886155645,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886155645),
//--TRIMMABLE-BOUNDARY-START(17181122941),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1122685,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1253757,
      "h": 17181122941,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181122941),
//--TRIMMABLE-BOUNDARY-START(8591188349),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1122685,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1253757,
      "h": 8591188349,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591188349)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296221053),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1253757,
      "h": 4296221053,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296221053)
  ],
  "h": 1253757
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1253757)
        
        

        //--TRIMMABLE-BOUNDARY-START(729469)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityDeviceModelTypeDescriptor`, ($self) => class TemperatureHumidityDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295696765)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295696765);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$hmEn.LCIDTM.TemperatureHumidityDeviceModelTypeDescriptor.GenerateProperties($.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, this, factory);
                    }, $eqHPeg ??= {"r":65537,"n":"","d":729469,"h":0,"f":17825794}), 0, "TemperatureHumidityDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TemperatureHumidity\\Models_TemperatureAndHumidityDeviceModel_LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceModelTypeDescriptorBuilder.g.cs", "TemperatureHumidityDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295696765)
            
            //--TRIMMABLE-BOUNDARY-START(12885631357)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885631357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885631357)
            
            //--TRIMMABLE-BOUNDARY-START(17180598653)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180598653);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceSettings, LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceSendDataModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityDeviceStatusHandler, LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityDeviceHubClient, LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180598653)
            
            //--TRIMMABLE-BOUNDARY-START(8590664061)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590664061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel)))
                {
                    /*var*/ let result = $.$hmEn.LCIDTM.TemperatureHumidityDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590664061)
            
            static $h = 729469;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885631357),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 729469,
      "h": 12885631357,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885631357),
//--TRIMMABLE-BOUNDARY-START(17180598653),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 598397,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 729469,
      "h": 17180598653,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180598653),
//--TRIMMABLE-BOUNDARY-START(8590664061),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 598397,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 729469,
      "h": 8590664061,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590664061)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295696765),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 729469,
      "h": 4295696765,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295696765)
  ],
  "h": 729469
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(729469)
        
        

        //--TRIMMABLE-BOUNDARY-START(1778045)
        $asm.$cls(`$hmEn.LCIDTM.TemperatureHumidityServiceModelTypeDescriptor`, ($self) => class TemperatureHumidityServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296745341)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296745341);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$hmEn.LCIDTM.TemperatureHumidityServiceModelTypeDescriptor.GenerateProperties($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, this, factory);
                    }, $njfaqf ??= {"r":65537,"n":"","d":1778045,"h":0,"f":17825794}), 0, "TemperatureHumidityServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TemperatureHumidity\\Models_TemperatureAndHumidityServiceModel_LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityServiceModelTypeDescriptorBuilder.g.cs", "TemperatureHumidityServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296745341)
            
            //--TRIMMABLE-BOUNDARY-START(12886679933)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886679933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886679933)
            
            //--TRIMMABLE-BOUNDARY-START(17181647229)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181647229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceSettings, LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceSendDataModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityDeviceStatusHandler, LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityDeviceHubClient, LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181647229)
            
            //--TRIMMABLE-BOUNDARY-START(8591712637)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591712637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$hmEn.LCIDTM.TemperatureHumidityServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel)))
                {
                    /*var*/ let result = $.$hmEn.LCIDTM.TemperatureHumidityServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591712637)
            
            static $h = 1778045;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886679933),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1778045,
      "h": 12886679933,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886679933),
//--TRIMMABLE-BOUNDARY-START(17181647229),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1646973,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1778045,
      "h": 17181647229,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181647229),
//--TRIMMABLE-BOUNDARY-START(8591712637),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1646973,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1778045,
      "h": 8591712637,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591712637)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296745341),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1778045,
      "h": 4296745341,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296745341)
  ],
  "h": 1778045
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Models${separator}TemperatureHumidityServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1778045)
        
        

        //--TRIMMABLE-BOUNDARY-START(2630013)
        $asm.$cls(`$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettingsTypeDescriptor`, ($self) => class TemperatureHumidityDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297597309)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297597309);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettingsTypeDescriptor.GenerateProperties($.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, this, factory);
                    }, $EsdQcd ??= {"r":65537,"n":"","d":2630013,"h":0,"f":17825794}), 0, "TemperatureHumidityDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TemperatureHumidity\\Settings_TemperatureAndHumidityDeviceSettings_LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceSettingsTypeDescriptorBuilder.g.cs", "TemperatureHumidityDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297597309)
            
            //--TRIMMABLE-BOUNDARY-START(12887531901)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887531901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887531901)
            
            //--TRIMMABLE-BOUNDARY-START(17182499197)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182499197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceSettings, LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Models.TemperatureHumidityDeviceSendDataModel, LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityDeviceStatusHandler, LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityDeviceHubClient, LivingThing.Core.IOT.Devices.TemperatureHumidity.Services.ITemperatureHumidityRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService).iSmartDeviceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182499197)
            
            //--TRIMMABLE-BOUNDARY-START(8592564605)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592564605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings)))
                {
                    /*var*/ let result = $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592564605)
            
            static $h = 2630013;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887531901),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2630013,
      "h": 12887531901,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887531901),
//--TRIMMABLE-BOUNDARY-START(17182499197),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2498941,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2630013,
      "h": 17182499197,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182499197),
//--TRIMMABLE-BOUNDARY-START(8592564605),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2498941,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2630013,
      "h": 8592564605,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592564605)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297597309),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2630013,
      "h": 4297597309,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297597309)
  ],
  "h": 2630013
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Settings.TemperatureHumidityDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Settings${separator}TemperatureHumidityDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2630013)
        
        

        //--TRIMMABLE-BOUNDARY-START(2826621)
        $asm.$cls(`$hmEn.LCIDT.TemperatureHumidityDevice`, ($self) => class TemperatureHumidityDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$hmEn.LCIDTMS.TemperatureHumidityStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4297793917)
            $ctor$2(/*IIOTDeviceFamily<TemperatureHumidityDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*TemperatureHumidityDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297793917);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297793917)
            
            static $h = 2826621;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$hmEn.LCIDTMS.TemperatureHumidityStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297793917),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$hmEn.LCIDT.TemperatureHumidityDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 598397
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2826621,
      "h": 4297793917,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297793917)
  ],
  "h": 2826621
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.TemperatureHumidityDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}TemperatureHumidityDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2826621)
        
        

        //--TRIMMABLE-BOUNDARY-START(2892157)
        $asm.$cls(`$hmEn.LCIDT.TemperatureHumidityDeviceDefinition`, ($self) => class TemperatureHumidityDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$hmEn.LCIDTMS.TemperatureHumidityStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297859453)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297859453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297859453)
            
            //--TRIMMABLE-BOUNDARY-START(4297859453)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297859453)
            
            static $h = 2892157;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$hmEn.LCIDTMS.TemperatureHumidityStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297859453),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2892157,
      "h": 4297859453,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297859453)
  ],
  "h": 2892157
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.TemperatureHumidityDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}TemperatureHumidityDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2892157)
        
        

        //--TRIMMABLE-BOUNDARY-START(2957693)
        $asm.$cls(`$hmEn.LCIDT.TemperatureHumidityDeviceFamily`, ($self) => class TemperatureHumidityDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4297924989)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<TemperatureHumidityDeviceReceivedDataModel, TemperatureHumidityDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<TemperatureHumidityDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297924989);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297924989)
            
            static $h = 2957693;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297924989),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2957693,
      "h": 4297924989,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297924989)
  ],
  "h": 2957693
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$hmEn.LCIDT.TemperatureHumidityDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$hmEn.LCIDT.TemperatureHumidityDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.TemperatureHumidityDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}TemperatureHumidityDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2957693)
        
        

        //--TRIMMABLE-BOUNDARY-START(3613053)
        $asm.$cls(`$hmEn.LCIDTV$1.TemperatureHumidityViewRenderer`, ($self) => class TemperatureHumidityViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$$$$$$($.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel))
        {
            //--TRIMMABLE-BOUNDARY-START(4298580349)
            $ctor$2(/*IOTRootViewModel*/ root)
            {
                super.$ctor$1(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298580349);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298580349)
            
            //--TRIMMABLE-BOUNDARY-START(8593547645)
            /*RenderFragment? */ GetView(/*IClientUnitOfWork*/ ui, /*TemperatureHumidityDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>?*/ clicked, /*Func<Task>?*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593547645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === 3/*DeviceViewType.Details*/)
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$hmEn.LCIDTV$1.TemperatureHumidityDeviceDetails, $.$hmEn.LCIDTV$1.TemperatureHumidityDetailsViewModel, new $.$hmEn.LCIDTV$1.TemperatureHumidityDetailsViewModel().$ctor$8(this.Root, device.OwnerScope, device), true, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(8593547645)
            
            static $h = 3613053;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$$$$$$($.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593547645),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 2826621
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 3613053,
      "h": 8593547645,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8593547645)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298580349),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3613053,
      "h": 4298580349,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298580349)
  ],
  "h": 3613053
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$hmEn.LCIDT.TemperatureHumidityDevice), $.$ntej.LCICD$1.IDeviceViewRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Views.TemperatureHumidityViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Views${separator}TemperatureHumidityViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3613053)
        
        

        //--TRIMMABLE-BOUNDARY-START(3481981)
        $asm.$cls(`$hmEn.LCIDTV$1.TemperatureHumidityDetailsViewModel`, ($self) => class TemperatureHumidityDetailsViewModel extends $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$$$$$$($.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel))
        {
            //--TRIMMABLE-BOUNDARY-START(4298449277)
            $ctor$8(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*TemperatureHumidityDevice*/ device)
            {
                super.$ctor$7(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298449277);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298449277)
            
            static $h = 3481981;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$$$$$$($.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298449277),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 2826621
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 3481981,
      "h": 4298449277,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298449277)
  ],
  "h": 3481981
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICDV.IDeviceDetailsViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Views.TemperatureHumidityDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Views${separator}TemperatureHumidityDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3481981)
        
        

        //--TRIMMABLE-BOUNDARY-START(3547517)
        $asm.$cls(`$hmEn.LCIDTV$1.TemperatureHumidityDeviceDetails`, ($self) => class TemperatureHumidityDeviceDetails extends $.$hDPm.LCFCC$1.BaseComponent$$($.$hmEn.LCIDTV$1.TemperatureHumidityDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(51543155069)
            /*TemperatureHumidityDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(51543155069)
            
            //--TRIMMABLE-BOUNDARY-START(34363285885)
            /*string */ get OptimizedComponentName()
            {
                return "temperaturehumiditydevicedetails";
            }
            //--TRIMMABLE-BOUNDARY-END(34363285885)
            
            //--TRIMMABLE-BOUNDARY-START(47248187773)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47248187773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$hmEn.LCIDTV$1.TemperatureHumidityDetailsViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(47248187773)
            
            //--TRIMMABLE-BOUNDARY-START(12888449405)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888449405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$hmEn.LCIDT.TemperatureHumidityDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$hmEn.LCIDT.TemperatureHumidityDevice), this.ViewModel));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICD$1.DeviceDetailsFeatures, 479/*DeviceDetailsFeatures.Default*/ & ~256/*DeviceDetailsFeatures.IO*/), $.$ntej.LCICD$1.DeviceDetailsFeatures));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12888449405)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8593482109)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593482109);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593482109)
            
            //--TRIMMABLE-BOUNDARY-START(8593482109)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8593482109)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51543155069)
                this.ViewModel = null;
                //--TRIMMABLE-BOUNDARY-END(51543155069)
                
            }
            static $h = 3547517;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$hmEn.LCIDTV$1.TemperatureHumidityDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51543155069),
    {
      "p": 3481981,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068318589,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42953220477,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 3547517,
      "h": 51543155069,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51543155069),
//--TRIMMABLE-BOUNDARY-START(34363285885),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478383997,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 3547517,
      "h": 34363285885,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34363285885)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47248187773),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 3547517,
      "h": 47248187773,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47248187773),
//--TRIMMABLE-BOUNDARY-START(12888449405),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 3547517,
      "h": 12888449405,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12888449405)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593482109),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3547517,
      "h": 8593482109,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593482109)
  ],
  "h": 3547517
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.Views.TemperatureHumidityDeviceDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}Views${separator}TemperatureHumidityDeviceDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3547517)
        
        

        $asm.$typeProxy("$hmEn.LCIDTV.TemperatureHumidityClientAppViewModel", "$hmEn.LivingThing.Core.IOT.Devices.TemperatureHumidity.ViewModels.TemperatureHumidityClientAppViewModel");
        $asm.$typeProxy("$hmEn.LCIDTV.TemperatureHumidityClientAppServiceViewModel", "$hmEn.LivingThing.Core.IOT.Devices.TemperatureHumidity.ViewModels.TemperatureHumidityClientAppServiceViewModel");
        $asm.$typeProxy("$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceViewModel", "$hmEn.LivingThing.Core.IOT.Devices.TemperatureHumidity.ViewModels.TemperatureHumidityClientAppDeviceViewModel");
        //--TRIMMABLE-BOUNDARY-START(3219837)
        $asm.$cls(`$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceScopeViewModel`, ($self) => class TemperatureHumidityClientAppDeviceScopeViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTV.TemperatureHumidityClientAppViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppServiceViewModel, $self, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceViewModel, $.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298187133)
            $ctor$3(/*TemperatureHumidityClientAppServiceViewModel*/ service, /*TemperatureHumidityDeviceScopeModel*/ model, /*IEnumerable<TemperatureHumidityClientAppDeviceViewModel>*/ devices)
            {
                super.$ctor$3(service, model, devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298187133);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298187133)
            
            static $h = 3219837;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTV.TemperatureHumidityClientAppViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppServiceViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceScopeViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceViewModel, $.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298187133),
    {
      "p": [
        {
          "n": "service",
          "p": 3350909
        },
        {
          "n": "model",
          "p": 1122685
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3219837,
      "h": 4298187133,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298187133)
  ],
  "h": 3219837
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$vWqU.LCFCC.IViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTDeviceScopeViewModel$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceViewModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.ViewModels.TemperatureHumidityClientAppDeviceScopeViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}ViewModels${separator}TemperatureHumidityClientAppDeviceScopeViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3219837)
        
        

        //--TRIMMABLE-BOUNDARY-START(3285373)
        $asm.$cls(`$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceViewModel`, ($self) => class TemperatureHumidityClientAppDeviceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTV.TemperatureHumidityClientAppViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppServiceViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceScopeViewModel, $self, $.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298252669)
            $ctor$7(/*TemperatureHumidityClientAppServiceViewModel*/ service, /*TemperatureHumidityDeviceModel*/ model, /*IEnumerable<TemperatureHumidityClientAppDeviceScopeViewModel>*/ scopes)
            {
                super.$ctor$7(service, model, scopes);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298252669);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298252669)
            
            static $h = 3285373;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTV.TemperatureHumidityClientAppViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppServiceViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceScopeViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceViewModel, $.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298252669),
    {
      "p": [
        {
          "n": "service",
          "p": 3350909
        },
        {
          "n": "model",
          "p": 598397
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 3285373,
      "h": 4298252669,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298252669)
  ],
  "h": 3285373
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICV.IIOTDeviceViewModel$$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTDeviceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.ViewModels.TemperatureHumidityClientAppDeviceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}ViewModels${separator}TemperatureHumidityClientAppDeviceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3285373)
        
        

        //--TRIMMABLE-BOUNDARY-START(3416445)
        $asm.$cls(`$hmEn.LCIDTV.TemperatureHumidityClientAppViewModel`, ($self) => class TemperatureHumidityClientAppViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($self, $.$hmEn.LCIDTV.TemperatureHumidityClientAppServiceViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceScopeViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceViewModel, $.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298383741)
            $ctor$5(/*IOTRootViewModel*/ root, /*TemperatureHumidityDeviceFamily*/ family, /*IHubConnector<IIOTDeviceHubClientBase<TemperatureHumidityDeviceReceivedDataModel, IOTDeviceStatusModel>>*/ hubConnector)
            {
                super.$ctor$5(root, family, $.$$.N.InterfaceVarianceStubHandler.Create(hubConnector, $.$kVHt.LCFCH.IHubConnector$$($.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)), $.$kVHt.LCFCH.IHubConnector$$($.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient)));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298383741);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298383741)
            
            //--TRIMMABLE-BOUNDARY-START(8593351037)
            /*bool */ get Authorize()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593351037)
            
            //--TRIMMABLE-BOUNDARY-START(21478252925)
            /*TemperatureHumidityClientAppServiceViewModel */ GetServiceViewModel(/*TemperatureHumidityServiceModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478252925);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$hmEn.LCIDTV.TemperatureHumidityClientAppServiceViewModel().$ctor$3(this, model);
            }
            //--TRIMMABLE-BOUNDARY-END(21478252925)
            
            static $h = 3416445;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTV.TemperatureHumidityClientAppViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppServiceViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceScopeViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceViewModel, $.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8593351037),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183285629,
        "f": 50364417
      },
      "n": "Authorize",
      "d": 3416445,
      "h": 8593351037,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8593351037)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21478252925),
    {
      "r": 3350909,
      "p": [
        {
          "n": "model",
          "p": 1646973
        }
      ],
      "n": "GetServiceViewModel",
      "d": 3416445,
      "h": 21478252925,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21478252925)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298383741),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "family",
          "p": 2957693
        },
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$($.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3416445,
      "h": 4298383741,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298383741)
  ],
  "h": 3416445
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$ntej.LCICV.IIOTAppViewModel$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel), $.$ntej.LCICV.IIOTApplicationViewModel, $.$vWqU.LCFCC.IServiceViewModel$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel), $.$vWqU.LCFCC.IServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$yleQ.LCFCA.IApplicationService, $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$vWqU.LCFCC.IServiceSubscriptionViewModel$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel), $.$vWqU.LCFCC.IServiceSubscriptionViewModel, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IClientRootService$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel), $.$vWqU.LCFCC.IClientRootService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.ViewModels.TemperatureHumidityClientAppViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}ViewModels${separator}TemperatureHumidityClientAppViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3416445)
        
        

        //--TRIMMABLE-BOUNDARY-START(3350909)
        $asm.$cls(`$hmEn.LCIDTV.TemperatureHumidityClientAppServiceViewModel`, ($self) => class TemperatureHumidityClientAppServiceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTV.TemperatureHumidityClientAppViewModel, $self, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceScopeViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceViewModel, $.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298318205)
            $ctor$3(/*TemperatureHumidityClientAppViewModel*/ app, /*TemperatureHumidityServiceModel*/ model)
            {
                super.$ctor$3(app, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298318205);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298318205)
            
            //--TRIMMABLE-BOUNDARY-START(12888252797)
            /*TemperatureHumidityClientAppDeviceViewModel */ GetDeviceViewModel(/*TemperatureHumidityDeviceModel*/ model, /*IEnumerable<TemperatureHumidityClientAppDeviceScopeViewModel>*/ scopes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888252797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceViewModel().$ctor$7(this, model, scopes);
            }
            //--TRIMMABLE-BOUNDARY-END(12888252797)
            
            //--TRIMMABLE-BOUNDARY-START(8593285501)
            /*TemperatureHumidityClientAppDeviceScopeViewModel */ GetDeviceScopeViewModel(/*TemperatureHumidityDeviceScopeModel*/ model, /*IEnumerable<TemperatureHumidityClientAppDeviceViewModel>*/ devices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593285501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceScopeViewModel().$ctor$3(this, model, devices);
            }
            //--TRIMMABLE-BOUNDARY-END(8593285501)
            
            static $h = 3350909;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTV.TemperatureHumidityClientAppViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppServiceViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceScopeViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceViewModel, $.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888252797),
    {
      "r": 3285373,
      "p": [
        {
          "n": "model",
          "p": 598397
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": "GetDeviceViewModel",
      "d": 3350909,
      "h": 12888252797,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12888252797),
//--TRIMMABLE-BOUNDARY-START(8593285501),
    {
      "r": 3219837,
      "p": [
        {
          "n": "model",
          "p": 1122685
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceViewModel).$h
        }
      ],
      "n": "GetDeviceScopeViewModel",
      "d": 3350909,
      "h": 8593285501,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8593285501)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298318205),
    {
      "p": [
        {
          "n": "app",
          "p": 3416445
        },
        {
          "n": "model",
          "p": 1646973
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3350909,
      "h": 4298318205,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298318205)
  ],
  "h": 3350909
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTApplicationServiceViewModel$$$$$$$$($.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceScopeViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceViewModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTApplicationServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.ViewModels.TemperatureHumidityClientAppServiceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}ViewModels${separator}TemperatureHumidityClientAppServiceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3350909)
        
        

        //--TRIMMABLE-BOUNDARY-START(3154301)
        $asm.$cls(`$hmEn.LCIDTV.TemperatureHumidityClientAppDefinition`, ($self) => class TemperatureHumidityClientAppDefinition extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTV.TemperatureHumidityClientAppViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppServiceViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceScopeViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceViewModel, $.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298121597)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298121597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298121597)
            
            //--TRIMMABLE-BOUNDARY-START(4298121597)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298121597)
            
            static $h = 3154301;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$hmEn.LCIDTV.TemperatureHumidityClientAppViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppServiceViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceScopeViewModel, $.$hmEn.LCIDTV.TemperatureHumidityClientAppDeviceViewModel, $.$hmEn.LCIDT.TemperatureHumidityDevice, $.$hmEn.LCIDTM.TemperatureHumidityServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$hmEn.LCIDTM.TemperatureHumidityDeviceModel, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceSettings, $.$hmEn.LCIDTS$1.TemperatureHumidityDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceReceivedDataModel, $.$hmEn.LCIDTM.TemperatureHumidityDeviceSendDataModel, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceStatusHandler, $.$hmEn.LCIDTS.ITemperatureHumidityDeviceHubClient, $.$hmEn.LCIDTS.ITemperatureHumidityRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298121597),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3154301,
      "h": 4298121597,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298121597)
  ],
  "h": 3154301
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TemperatureHumidity.ViewModels.TemperatureHumidityClientAppDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TemperatureHumidity${separator}ViewModels${separator}TemperatureHumidityClientAppDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3154301)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(8573)
