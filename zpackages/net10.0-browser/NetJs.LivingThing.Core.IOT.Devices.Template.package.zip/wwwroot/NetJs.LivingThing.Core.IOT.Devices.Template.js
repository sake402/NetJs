
//--TRIMMABLE-BOUNDARY-START(49494)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $SeTFVb;
    let $NbiPHg;
    let $GbPEzc;
    let $BMdgkg;
    let $TGyxla;
    let $EarGQf;
    let $XpXSUa;
    let $mLnDld;
    let $VDibvj;
    let $Vbdllk;
    let $kucHRj;
    let $MSUaEf;
    let $VPGIll;
    let $cyhWzj;
    let $vQCRBd;
    let $aySsNb;
    let $GCWFxe;
    let $XYhSfb;
    let $KwzgNe;
    let $MJaeGg;
    let $YNszjj;
    let $QDGTFj;
    let $UKiBPd;
    let $AxZPDa;
    let $WhjEqk;
    let $vLtKRe;
    let $kkiPqe;
    let $RfGQUh;
    let $jkDxub;
    let $YJxYRd;
    let $lXLWYj;
    let $LjVSFj;
    let $qUQtPi;
    let $fMohJa;
    let $ahpmrf;
    let $sVtFyb;
    let $cCdQll;
    let $egAora;
    let $HGkVqf;
    let $fPsiuj;
    let $EsJWIh;
    let $GdbMca;
    let $KfZKoh;
    let $xFSIof;
    let $wUefzb;
    let $mUEDpb;
    let $iIKqyh;
    let $AovAza;
    let $Pjunri;
    let $KfLHMj;
    let $GBYmCe;
    let $QEGEOf;
    let $LgWpyk;
    let $GsqMec;
    let $qYwJld;
    let $MoaOGi;
    let $gnsXni;
    let $hxLQNa;
    let $RhieNi;
    let $GTownh;
    let $QvXZba;
    let $ITehNb;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.Template", 
    {
  "h": 49494,
  "f": "LivingThing.Core.IOT.Devices.Template",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.Template",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.Template",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5UZW1wbGF0ZS5UZW1wbGF0ZURldmljZSI6IHsNCiAgICAgICJDYXRlZ29yaWVzIjogWyAiU21hcnQgSG9tZSIgXSwNCiAgICAgICJOYW1lIjogIlRlbXBsYXRlIiwNCiAgICAgICJEZXNjcmlwdGlvbiI6ICIiLA0KICAgICAgIkJhbm5lckltYWdlIjogIn4vVGVtcGxhdGUvaW1nL2Jhbm5lci5qcGciLA0KICAgICAgIkljb24iOiB7ICJOYW1lIjogIm1kaSBtZGktZWxlY3RyaWMtc3dpdGNoIiB9LA0KICAgICAgIlRoZW1lQ29sb3IiOiAiI2Q3N2JiYSIsDQogICAgICAiRmxhZ3MiOiAiRmVhdHVyZWQsUHVibGlzaGVkIiwNCiAgICAgICJTZWN1cml0aWVzIjogIkNoYWxsZW5nZUhhbmRTaGFrZUF1dGhlbnRpY2F0aW9uUHJvdG9jb2wsQWR2YW5jZWRFbmNyeXB0aW9uU3RhbmRhcmQsRWxsaXB0aWNDdXJ2ZUZpcm13YXJlVXBkYXRlU2lnbmluZyINCiAgICB9DQogIH0NCn0="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(835926)
        $asm.$cls(`$ivxN.LCIDTMC.TemplateOneShotControlModelCustomAttributesProvider`, ($self) => class TemplateOneShotControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295803222)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295803222);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295803222)
            
            static $h = 835926;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295803222),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 835926,
      "h": 4295803222,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295803222)
  ],
  "h": 835926
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOneShotControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Commands${separator}TemplateOneShotControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(835926)
        
        

        //--TRIMMABLE-BOUNDARY-START(3916118)
        $asm.$cls(`$ivxN.LCIDTS$1.TemplateClickCommandCustomAttributesProvider`, ($self) => class TemplateClickCommandCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298883414)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298883414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298883414)
            
            static $h = 3916118;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298883414),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3916118,
      "h": 4298883414,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298883414)
  ],
  "h": 3916118
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Settings.TemplateClickCommandCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Settings${separator}TemplateClickCommandCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3916118)
        
        

        //--TRIMMABLE-BOUNDARY-START(2081110)
        $asm.$cls(`$ivxN.LCIDTM.TemplateDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class TemplateDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297048406)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297048406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$$($.$ivxN.LCIDTMS.TemplateStatusModel, $.$ivxN.LCIDTM.TemplateLogModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297048406)
            
            static $h = 2081110;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297048406),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2081110,
      "h": 4297048406,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297048406)
  ],
  "h": 2081110
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2081110)
        
        

        //--TRIMMABLE-BOUNDARY-START(3785046)
        $asm.$cls(`$ivxN.LCIDTS$1.TemplateBroadcastPeerMessagesCustomAttributesProvider`, ($self) => class TemplateBroadcastPeerMessagesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298752342)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298752342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298752342)
            
            static $h = 3785046;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298752342),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3785046,
      "h": 4298752342,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298752342)
  ],
  "h": 3785046
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Settings.TemplateBroadcastPeerMessagesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Settings${separator}TemplateBroadcastPeerMessagesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3785046)
        
        

        //--TRIMMABLE-BOUNDARY-START(2343254)
        $asm.$cls(`$ivxN.LCIDTM.TemplateDeviceScopeModelCustomAttributesProvider`, ($self) => class TemplateDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297310550)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297310550);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297310550)
            
            static $h = 2343254;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297310550),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2343254,
      "h": 4297310550,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297310550)
  ],
  "h": 2343254
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2343254)
        
        

        //--TRIMMABLE-BOUNDARY-START(2867542)
        $asm.$cls(`$ivxN.LCIDTM.TemplateLogModelCustomAttributesProvider`, ($self) => class TemplateLogModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297834838)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297834838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceLogModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297834838)
            
            static $h = 2867542;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297834838),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2867542,
      "h": 4297834838,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297834838)
  ],
  "h": 2867542
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateLogModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateLogModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2867542)
        
        

        //--TRIMMABLE-BOUNDARY-START(1425750)
        $asm.$cls(`$ivxN.LCIDTMS.TemplateStatusModelCustomAttributesProvider`, ($self) => class TemplateStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296393046)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296393046)
            
            //--TRIMMABLE-BOUNDARY-START(8591360342)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591360342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ivxN.LCIDTMS.TemplateStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Status", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Format=Bool(ON, OFF)"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CountDown", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.ConvertType = ($.$$.S.UInt16.$type);
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Format=TimeSpan>Remove(^0s$)", "Icon=Timer"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ivxN.LCIDTMS.TemplateStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $SeTFVb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1425750,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $NbiPHg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1425750,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591360342)
            
            static $h = 1425750;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591360342),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1425750,
      "h": 8591360342,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591360342)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296393046),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1425750,
      "h": 4296393046,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296393046)
  ],
  "h": 1425750
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Statuses.TemplateStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Statuses${separator}TemplateStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1425750)
        
        

        //--TRIMMABLE-BOUNDARY-START(4833622)
        $asm.$cls(`$ivxN.LCIDT.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4299800918)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299800918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ivxN.LCIDTMC.TemplateCountDownControlModelTypeDescriptorBuilder.Register();
                $.$ivxN.LCIDTMC.TemplateOneShotControlModelTypeDescriptorBuilder.Register();
                $.$ivxN.LCIDTMC.TemplateOnOffControlModelTypeDescriptorBuilder.Register();
                $.$ivxN.LCIDTMS.TemplateStatusModelTypeDescriptorBuilder.Register();
                $.$ivxN.LCIDTM.TemplateDeviceModelTypeDescriptorBuilder.Register();
                $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$ivxN.LCIDTM.TemplateDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$ivxN.LCIDTM.TemplateDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$ivxN.LCIDTM.TemplateLogModelTypeDescriptorBuilder.Register();
                $.$ivxN.LCIDTM.TemplateServiceModelTypeDescriptorBuilder.Register();
                $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$ivxN.LCIDTS$1.TemplateDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4299800918)
            
            static $h = 4833622;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299800918),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 4833622,
      "h": 4299800918,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4299800918)
  ],
  "h": 4833622
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4833622)
        
        

        //--TRIMMABLE-BOUNDARY-START(246102)
        $asm.$cls(`$ivxN.LCIDT.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295213398)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295213398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295213398)
            
            static $h = 246102;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295213398),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 246102,
      "h": 4295213398,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295213398)
  ],
  "h": 246102
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(246102)
        
        

        //--TRIMMABLE-BOUNDARY-START(1163606)
        $asm.$cls(`$ivxN.LCIDTMC.TemplateOnOffControlModelCustomAttributesProvider`, ($self) => class TemplateOnOffControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296130902)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296130902)
            
            //--TRIMMABLE-BOUNDARY-START(8591098198)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591098198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ivxN.LCIDTMC.TemplateOnOffControlModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("State", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("LogTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (4);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ivxN.LCIDTMC.TemplateOnOffControlModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $GbPEzc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1163606,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $BMdgkg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1163606,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591098198)
            
            static $h = 1163606;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591098198),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1163606,
      "h": 8591098198,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591098198)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296130902),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1163606,
      "h": 4296130902,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296130902)
  ],
  "h": 1163606
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOnOffControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Commands${separator}TemplateOnOffControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1163606)
        
        

        //--TRIMMABLE-BOUNDARY-START(3129686)
        $asm.$cls(`$ivxN.LCIDTM.TemplateServiceModelCustomAttributesProvider`, ($self) => class TemplateServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298096982)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298096982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298096982)
            
            static $h = 3129686;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298096982),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3129686,
      "h": 4298096982,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298096982)
  ],
  "h": 3129686
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3129686)
        
        

        //--TRIMMABLE-BOUNDARY-START(442710)
        $asm.$cls(`$ivxN.LCIDTMC.TemplateCountDownControlModelCustomAttributesProvider`, ($self) => class TemplateCountDownControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295410006)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295410006)
            
            //--TRIMMABLE-BOUNDARY-START(8590377302)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590377302);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ivxN.LCIDTMC.TemplateCountDownControlModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Count", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("LogTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (4);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ivxN.LCIDTMC.TemplateCountDownControlModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $TGyxla ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":442710,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $EarGQf ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":442710,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590377302)
            
            static $h = 442710;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590377302),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 442710,
      "h": 8590377302,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590377302)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295410006),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 442710,
      "h": 4295410006,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295410006)
  ],
  "h": 442710
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateCountDownControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Commands${separator}TemplateCountDownControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(442710)
        
        

        //--TRIMMABLE-BOUNDARY-START(1818966)
        $asm.$cls(`$ivxN.LCIDTM.TemplateDeviceModelCustomAttributesProvider`, ($self) => class TemplateDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296786262)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296786262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296786262)
            
            static $h = 1818966;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296786262),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1818966,
      "h": 4296786262,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296786262)
  ],
  "h": 1818966
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1818966)
        
        

        //--TRIMMABLE-BOUNDARY-START(2998614)
        $asm.$cls(`$ivxN.LCIDTM.TemplateLogModelTypeDescriptorBuilder`, ($self) => class TemplateLogModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592933206)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592933206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ivxN.LCIDTM.TemplateLogModelTypeDescriptor()
                        const $t1 = $.$ivxN.LCIDTM.TemplateLogModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Template.Models.TemplateLogModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $XpXSUa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2998614,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ivxN.LCIDTM.TemplateLogModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592933206)
            
            //--TRIMMABLE-BOUNDARY-START(4297965910)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297965910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297965910)
            
            //--TRIMMABLE-BOUNDARY-START(4297965910)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297965910)
            
            static $h = 2998614;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592933206),
    {
      "r": 65537,
      "n": "Register",
      "d": 2998614,
      "h": 8592933206,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592933206)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297965910),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2998614,
      "h": 4297965910,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297965910)
  ],
  "h": 2998614
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateLogModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateLogModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2998614)
        
        

        //--TRIMMABLE-BOUNDARY-START(4047190)
        $asm.$cls(`$ivxN.LCIDTS$1.TemplateDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class TemplateDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299014486)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299014486)
            
            //--TRIMMABLE-BOUNDARY-START(8593981782)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593981782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Sample", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Key = "rem";
                            $i3.Order = (20);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $kucHRj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4047190,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $MSUaEf ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4047190,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider$$($.$ivxN.LCIDTS$1.TemplateActions).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593981782)
            
            static $h = 4047190;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593981782),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4047190,
      "h": 8593981782,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593981782)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299014486),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4047190,
      "h": 4299014486,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299014486)
  ],
  "h": 4047190
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Settings${separator}TemplateDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4047190)
        
        

        //--TRIMMABLE-BOUNDARY-START(3653974)
        $asm.$cls(`$ivxN.LCIDTS$1.TemplateActionsCustomAttributesProvider`, ($self) => class TemplateActionsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298621270)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298621270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298621270)
            
            static $h = 3653974;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298621270),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3653974,
      "h": 4298621270,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298621270)
  ],
  "h": 3653974
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Settings.TemplateActionsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Settings${separator}TemplateActionsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3653974)
        
        

        //--TRIMMABLE-BOUNDARY-START(180566)
        $asm.$cls(`$ivxN.LCIDT.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295147862)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295147862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ivxN.LCIDTMC.TemplateCountDownControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ivxN.LCIDTMC.TemplateCountDownControlModelCustomAttributesProvider, $.$ivxN.LCIDTMC.TemplateCountDownControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ivxN.LCIDTMC.TemplateOneShotControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ivxN.LCIDTMC.TemplateOneShotControlModelCustomAttributesProvider, $.$ivxN.LCIDTMC.TemplateOneShotControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ivxN.LCIDTMC.TemplateOnOffControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ivxN.LCIDTMC.TemplateOnOffControlModelCustomAttributesProvider, $.$ivxN.LCIDTMC.TemplateOnOffControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ivxN.LCIDTMS.TemplateStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ivxN.LCIDTMS.TemplateStatusModelCustomAttributesProvider, $.$ivxN.LCIDTMS.TemplateStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ivxN.LCIDTM.TemplateBroadcastActionType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ivxN.LCIDTM.TemplateBroadcastActionTypeCustomAttributesProvider, $.$ivxN.LCIDTM.TemplateBroadcastActionTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ivxN.LCIDTM.TemplateDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ivxN.LCIDTM.TemplateDeviceModelCustomAttributesProvider, $.$ivxN.LCIDTM.TemplateDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModelCustomAttributesProvider, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ivxN.LCIDTM.TemplateDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ivxN.LCIDTM.TemplateDeviceScopeModelCustomAttributesProvider, $.$ivxN.LCIDTM.TemplateDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ivxN.LCIDTM.TemplateDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ivxN.LCIDTM.TemplateDeviceSendDataModelCustomAttributesProvider, $.$ivxN.LCIDTM.TemplateDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ivxN.LCIDTM.TemplateLogModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ivxN.LCIDTM.TemplateLogModelCustomAttributesProvider, $.$ivxN.LCIDTM.TemplateLogModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ivxN.LCIDTM.TemplateServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ivxN.LCIDTM.TemplateServiceModelCustomAttributesProvider, $.$ivxN.LCIDTM.TemplateServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ivxN.LCIDTS$1.TemplateBroadcastPeerMessages.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ivxN.LCIDTS$1.TemplateBroadcastPeerMessagesCustomAttributesProvider, $.$ivxN.LCIDTS$1.TemplateBroadcastPeerMessagesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ivxN.LCIDTS$1.TemplateActions.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ivxN.LCIDTS$1.TemplateActionsCustomAttributesProvider, $.$ivxN.LCIDTS$1.TemplateActionsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettingsCustomAttributesProvider, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ivxN.LCIDTS$1.TemplateClickCommand.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ivxN.LCIDTS$1.TemplateClickCommandCustomAttributesProvider, $.$ivxN.LCIDTS$1.TemplateClickCommandCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ivxN.LCIDTS$1.TemplateDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ivxN.LCIDTS$1.TemplateDeviceSettingsCustomAttributesProvider, $.$ivxN.LCIDTS$1.TemplateDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295147862)
            
            static $h = 180566;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295147862),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 180566,
      "h": 4295147862,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295147862)
  ],
  "h": 180566
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(180566)
        
        

        //--TRIMMABLE-BOUNDARY-START(1950038)
        $asm.$cls(`$ivxN.LCIDTM.TemplateDeviceModelTypeDescriptorBuilder`, ($self) => class TemplateDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591884630)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591884630);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ivxN.LCIDTM.TemplateDeviceModelTypeDescriptor()
                        const $t1 = $.$ivxN.LCIDTM.TemplateDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $vQCRBd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1950038,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ivxN.LCIDTM.TemplateDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591884630)
            
            //--TRIMMABLE-BOUNDARY-START(4296917334)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296917334);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296917334)
            
            //--TRIMMABLE-BOUNDARY-START(4296917334)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296917334)
            
            static $h = 1950038;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591884630),
    {
      "r": 65537,
      "n": "Register",
      "d": 1950038,
      "h": 8591884630,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591884630)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296917334),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1950038,
      "h": 4296917334,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296917334)
  ],
  "h": 1950038
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1950038)
        
        

        //--TRIMMABLE-BOUNDARY-START(966998)
        $asm.$cls(`$ivxN.LCIDTMC.TemplateOneShotControlModelTypeDescriptorBuilder`, ($self) => class TemplateOneShotControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590901590)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590901590);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ivxN.LCIDTMC.TemplateOneShotControlModelTypeDescriptor()
                        const $t1 = $.$ivxN.LCIDTMC.TemplateOneShotControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOneShotControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $KwzgNe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":966998,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ivxN.LCIDTMC.TemplateOneShotControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590901590)
            
            //--TRIMMABLE-BOUNDARY-START(4295934294)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295934294);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295934294)
            
            //--TRIMMABLE-BOUNDARY-START(4295934294)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295934294)
            
            static $h = 966998;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590901590),
    {
      "r": 65537,
      "n": "Register",
      "d": 966998,
      "h": 8590901590,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590901590)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295934294),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 966998,
      "h": 4295934294,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295934294)
  ],
  "h": 966998
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOneShotControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Commands${separator}TemplateOneShotControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(966998)
        
        

        //--TRIMMABLE-BOUNDARY-START(2212182)
        $asm.$cls(`$ivxN.LCIDTM.TemplateDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class TemplateDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592146774)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592146774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $VDibvj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2212182,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592146774)
            
            //--TRIMMABLE-BOUNDARY-START(4297179478)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297179478);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297179478)
            
            //--TRIMMABLE-BOUNDARY-START(4297179478)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297179478)
            
            static $h = 2212182;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592146774),
    {
      "r": 65537,
      "n": "Register",
      "d": 2212182,
      "h": 8592146774,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592146774)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297179478),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2212182,
      "h": 4297179478,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297179478)
  ],
  "h": 2212182
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2212182)
        
        

        //--TRIMMABLE-BOUNDARY-START(2474326)
        $asm.$cls(`$ivxN.LCIDTM.TemplateDeviceScopeModelTypeDescriptorBuilder`, ($self) => class TemplateDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592408918)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592408918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ivxN.LCIDTM.TemplateDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$ivxN.LCIDTM.TemplateDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $VPGIll ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2474326,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ivxN.LCIDTM.TemplateDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592408918)
            
            //--TRIMMABLE-BOUNDARY-START(4297441622)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297441622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297441622)
            
            //--TRIMMABLE-BOUNDARY-START(4297441622)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297441622)
            
            static $h = 2474326;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592408918),
    {
      "r": 65537,
      "n": "Register",
      "d": 2474326,
      "h": 8592408918,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592408918)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297441622),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2474326,
      "h": 4297441622,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297441622)
  ],
  "h": 2474326
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2474326)
        
        

        //--TRIMMABLE-BOUNDARY-START(2605398)
        $asm.$cls(`$ivxN.LCIDTM.TemplateDeviceSendDataModelCustomAttributesProvider`, ($self) => class TemplateDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297572694)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297572694)
            
            //--TRIMMABLE-BOUNDARY-START(8592539990)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592539990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ivxN.LCIDTM.TemplateDeviceSendDataModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("On", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (13432);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CountDown", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (13432);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ivxN.LCIDTM.TemplateDeviceSendDataModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $GCWFxe ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2605398,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $XYhSfb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2605398,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandsModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592539990)
            
            static $h = 2605398;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592539990),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2605398,
      "h": 8592539990,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592539990)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297572694),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2605398,
      "h": 4297572694,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297572694)
  ],
  "h": 2605398
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2605398)
        
        

        //--TRIMMABLE-BOUNDARY-START(4178262)
        $asm.$cls(`$ivxN.LCIDTS$1.TemplateDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class TemplateDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594112854)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594112854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $lXLWYj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4178262,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594112854)
            
            //--TRIMMABLE-BOUNDARY-START(4299145558)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299145558);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299145558)
            
            //--TRIMMABLE-BOUNDARY-START(4299145558)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299145558)
            
            static $h = 4178262;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594112854),
    {
      "r": 65537,
      "n": "Register",
      "d": 4178262,
      "h": 8594112854,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594112854)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299145558),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4178262,
      "h": 4299145558,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299145558)
  ],
  "h": 4178262
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Settings${separator}TemplateDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4178262)
        
        

        //--TRIMMABLE-BOUNDARY-START(4309334)
        $asm.$cls(`$ivxN.LCIDTS$1.TemplateDeviceSettingsCustomAttributesProvider`, ($self) => class TemplateDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299276630)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299276630)
            
            //--TRIMMABLE-BOUNDARY-START(8594243926)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594243926);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ivxN.LCIDTS$1.TemplateDeviceSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Invert", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (256);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("OnClick", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (257);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ivxN.LCIDTS$1.TemplateDeviceSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $QDGTFj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4309334,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $UKiBPd ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4309334,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594243926)
            
            static $h = 4309334;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594243926),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4309334,
      "h": 8594243926,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594243926)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299276630),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4309334,
      "h": 4299276630,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299276630)
  ],
  "h": 4309334
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Settings${separator}TemplateDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4309334)
        
        

        //--TRIMMABLE-BOUNDARY-START(1687894)
        $asm.$cls(`$ivxN.LCIDTM.TemplateBroadcastActionTypeCustomAttributesProvider`, ($self) => class TemplateBroadcastActionTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296655190)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296655190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296655190)
            
            static $h = 1687894;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296655190),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1687894,
      "h": 4296655190,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296655190)
  ],
  "h": 1687894
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateBroadcastActionTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateBroadcastActionTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1687894)
        
        

        //--TRIMMABLE-BOUNDARY-START(3260758)
        $asm.$cls(`$ivxN.LCIDTM.TemplateServiceModelTypeDescriptorBuilder`, ($self) => class TemplateServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593195350)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593195350);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ivxN.LCIDTM.TemplateServiceModelTypeDescriptor()
                        const $t1 = $.$ivxN.LCIDTM.TemplateServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Template.Models.TemplateServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $jkDxub ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3260758,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ivxN.LCIDTM.TemplateServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593195350)
            
            //--TRIMMABLE-BOUNDARY-START(4298228054)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298228054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298228054)
            
            //--TRIMMABLE-BOUNDARY-START(4298228054)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298228054)
            
            static $h = 3260758;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593195350),
    {
      "r": 65537,
      "n": "Register",
      "d": 3260758,
      "h": 8593195350,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593195350)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298228054),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3260758,
      "h": 4298228054,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298228054)
  ],
  "h": 3260758
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3260758)
        
        

        //--TRIMMABLE-BOUNDARY-START(1294678)
        $asm.$cls(`$ivxN.LCIDTMC.TemplateOnOffControlModelTypeDescriptorBuilder`, ($self) => class TemplateOnOffControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591229270)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591229270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ivxN.LCIDTMC.TemplateOnOffControlModelTypeDescriptor()
                        const $t1 = $.$ivxN.LCIDTMC.TemplateOnOffControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOnOffControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ahpmrf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1294678,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ivxN.LCIDTMC.TemplateOnOffControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591229270)
            
            //--TRIMMABLE-BOUNDARY-START(4296261974)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296261974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296261974)
            
            //--TRIMMABLE-BOUNDARY-START(4296261974)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296261974)
            
            static $h = 1294678;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591229270),
    {
      "r": 65537,
      "n": "Register",
      "d": 1294678,
      "h": 8591229270,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591229270)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296261974),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1294678,
      "h": 4296261974,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296261974)
  ],
  "h": 1294678
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOnOffControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Commands${separator}TemplateOnOffControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1294678)
        
        

        //--TRIMMABLE-BOUNDARY-START(4440406)
        $asm.$cls(`$ivxN.LCIDTS$1.TemplateDeviceSettingsTypeDescriptorBuilder`, ($self) => class TemplateDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594374998)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594374998);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ivxN.LCIDTS$1.TemplateDeviceSettingsTypeDescriptor()
                        const $t1 = $.$ivxN.LCIDTS$1.TemplateDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $fPsiuj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4440406,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ivxN.LCIDTS$1.TemplateDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594374998)
            
            //--TRIMMABLE-BOUNDARY-START(4299407702)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299407702);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299407702)
            
            //--TRIMMABLE-BOUNDARY-START(4299407702)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299407702)
            
            static $h = 4440406;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594374998),
    {
      "r": 65537,
      "n": "Register",
      "d": 4440406,
      "h": 8594374998,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594374998)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299407702),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4440406,
      "h": 4299407702,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299407702)
  ],
  "h": 4440406
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Settings${separator}TemplateDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4440406)
        
        

        //--TRIMMABLE-BOUNDARY-START(1556822)
        $asm.$cls(`$ivxN.LCIDTMS.TemplateStatusModelTypeDescriptorBuilder`, ($self) => class TemplateStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591491414)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591491414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ivxN.LCIDTMS.TemplateStatusModelTypeDescriptor()
                        const $t1 = $.$ivxN.LCIDTMS.TemplateStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Template.Models.Statuses.TemplateStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $mUEDpb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1556822,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ivxN.LCIDTMS.TemplateStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591491414)
            
            //--TRIMMABLE-BOUNDARY-START(4296524118)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296524118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296524118)
            
            //--TRIMMABLE-BOUNDARY-START(4296524118)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296524118)
            
            static $h = 1556822;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591491414),
    {
      "r": 65537,
      "n": "Register",
      "d": 1556822,
      "h": 8591491414,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591491414)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296524118),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1556822,
      "h": 4296524118,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296524118)
  ],
  "h": 1556822
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Statuses.TemplateStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Statuses${separator}TemplateStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1556822)
        
        

        //--TRIMMABLE-BOUNDARY-START(573782)
        $asm.$cls(`$ivxN.LCIDTMC.TemplateCountDownControlModelTypeDescriptorBuilder`, ($self) => class TemplateCountDownControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590508374)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590508374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ivxN.LCIDTMC.TemplateCountDownControlModelTypeDescriptor()
                        const $t1 = $.$ivxN.LCIDTMC.TemplateCountDownControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateCountDownControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $QEGEOf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":573782,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ivxN.LCIDTMC.TemplateCountDownControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590508374)
            
            //--TRIMMABLE-BOUNDARY-START(4295541078)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295541078);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295541078)
            
            //--TRIMMABLE-BOUNDARY-START(4295541078)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295541078)
            
            static $h = 573782;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590508374),
    {
      "r": 65537,
      "n": "Register",
      "d": 573782,
      "h": 8590508374,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590508374)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295541078),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 573782,
      "h": 4295541078,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295541078)
  ],
  "h": 573782
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateCountDownControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Commands${separator}TemplateCountDownControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(573782)
        
        

        //--TRIMMABLE-BOUNDARY-START(2736470)
        $asm.$cls(`$ivxN.LCIDTM.TemplateDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class TemplateDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592671062)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592671062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ivxN.LCIDTM.TemplateDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$ivxN.LCIDTM.TemplateDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $gnsXni ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2736470,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ivxN.LCIDTM.TemplateDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592671062)
            
            //--TRIMMABLE-BOUNDARY-START(4297703766)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297703766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297703766)
            
            //--TRIMMABLE-BOUNDARY-START(4297703766)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297703766)
            
            static $h = 2736470;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592671062),
    {
      "r": 65537,
      "n": "Register",
      "d": 2736470,
      "h": 8592671062,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592671062)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297703766),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2736470,
      "h": 4297703766,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297703766)
  ],
  "h": 2736470
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2736470)
        
        

        //--TRIMMABLE-BOUNDARY-START(115030)
        $asm.$cls(`$ivxN.LCIDT.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17179984214)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17179984214)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295082326)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295082326);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295082326)
            
            //--TRIMMABLE-BOUNDARY-START(4295082326)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295082326)
            
            static $h = 115030;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17179984214),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885016918,
        "f": 50331649
      },
      "n": "Paths",
      "d": 115030,
      "h": 17179984214,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17179984214)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295082326),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 115030,
      "h": 4295082326,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295082326)
  ],
  "h": 115030
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(115030)
        
        

        //--TRIMMABLE-BOUNDARY-START(3326294)
        $asm.$cls(`$ivxN.LCIDT.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593260886)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593260886);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$ivxN.LCIDT.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ivxN.LCIDT.TemplateDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$ivxN.LCIDT.TemplateDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$ivxN.LCIDT.TemplateDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$ivxN.LCIDT.TemplateDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$ivxN.LCIDT.TemplateDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ivxN.LCIDT.TemplateDeviceFamily, x);
                }, $AxZPDa ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":3326294,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ivxN.LCIDT.TemplateDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$ivxN.LCIDT.TemplateDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $WhjEqk ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":3326294,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$ivxN.LCIDT.TemplateDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ivxN.LCIDT.TemplateDeviceFamily, x);
                }, $vLtKRe ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$ivxN.LCIDT.TemplateDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":3326294,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$ivxN.LCIDT.TemplateDevice), $.$ivxN.LCIDTMC.TemplateDeviceCommands$$($.$ivxN.LCIDT.TemplateDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$ivxN.LCIDTV.TemplateClientAppViewModel, services);
                $.$fPer.LCFCD.DataConverter.Register($.$ivxN.LCIDTM.TemplateBroadcastActionType, $.$typeArray($.$$.S.Byte), new ($.$$.S.Func$$$($.$ivxN.LCIDTM.TemplateBroadcastActionType, $.$typeArray($.$$.S.Byte)))().$ctor(this,  (/*a*/ a) =>
                {
                    return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [a], [-1], null);
                }, $kkiPqe ??= {"r":$.$typeArray($.$$.S.Byte).$h,"p":[{"n":"a","p":1622358}],"n":"","d":3326294,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$typeArray($.$$.S.Byte), $.$ivxN.LCIDTM.TemplateBroadcastActionType))().$ctor(this,  (/*b*/ b) =>
                {
                    return $.$cast($.$$.System.Array.$ReadT1.call(b, 0), $.$ivxN.LCIDTM.TemplateBroadcastActionType);
                }, $RfGQUh ??= {"r":1622358,"p":[{"n":"b","p":$.$typeArray($.$$.S.Byte).$h}],"n":"","d":3326294,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8593260886)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ivxN.LCIDT.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298293590)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298293590);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298293590)
            
            //--TRIMMABLE-BOUNDARY-START(4298293590)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298293590)
            
            static $h = 3326294;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593260886),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3326294,
      "h": 8593260886,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593260886)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298293590),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3326294,
      "h": 4298293590,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298293590)
  ],
  "h": 3326294
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3326294)
        
        

        //--TRIMMABLE-BOUNDARY-START(770390)
        $asm.$cls(`$ivxN.LCIDTMC.TemplateOneShotControlModel`, ($self) => class TemplateOneShotControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(8590704982)
            /*int */ get Command()
            {
                return ((128 + 6) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(8590704982)
            
            //--TRIMMABLE-BOUNDARY-START(4295737686)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295737686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295737686)
            
            //--TRIMMABLE-BOUNDARY-START(4295737686)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295737686)
            
            static $h = 770390;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590704982),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180639574,
        "f": 50364417
      },
      "n": "Command",
      "d": 770390,
      "h": 8590704982,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8590704982)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295737686),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 770390,
      "h": 4295737686,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295737686)
  ],
  "h": 770390
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOneShotControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Commands${separator}TemplateOneShotControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(770390)
        
        

        //--TRIMMABLE-BOUNDARY-START(1098070)
        $asm.$cls(`$ivxN.LCIDTMC.TemplateOnOffControlModel`, ($self) => class TemplateOnOffControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(12885999958)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885999958);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885999958)
            
            //--TRIMMABLE-BOUNDARY-START(17180967254)
            $ctor$3(/*bool*/ state)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180967254);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.State = state;
                    this.LogTime = $.$fPer.LCFCDC.PackedDateTime.Pack($.$$.S.DateTime.UtcNow, 2020);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180967254)
            
            //--TRIMMABLE-BOUNDARY-START(21475934550)
            /*int */ get Command()
            {
                return ((128 + 3) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(21475934550)
            
            //--TRIMMABLE-BOUNDARY-START(73015542102)
            /*bool*/ State = false;
            //--TRIMMABLE-BOUNDARY-END(73015542102)
            
            //--TRIMMABLE-BOUNDARY-START(51540705622)
            /*uint*/ LogTime = 0;
            //--TRIMMABLE-BOUNDARY-END(51540705622)
            
            //--TRIMMABLE-BOUNDARY-START(12885999958)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885999958)
            
            static $h = 1098070;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475934550),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065869142,
        "f": 50364417
      },
      "n": "Command",
      "d": 1098070,
      "h": 21475934550,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475934550),
//--TRIMMABLE-BOUNDARY-START(73015542102),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245738326,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720574806,
        "f": 83886082
      },
      "n": "State",
      "d": 1098070,
      "h": 73015542102,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015542102),
//--TRIMMABLE-BOUNDARY-START(51540705622),
    {
      "p": 720897,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655803734,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130640214,
        "f": 83886082
      },
      "n": "LogTime",
      "d": 1098070,
      "h": 51540705622,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540705622)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885999958),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1098070,
      "h": 12885999958,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885999958),
//--TRIMMABLE-BOUNDARY-START(17180967254),
    {
      "p": [
        {
          "n": "state",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1098070,
      "h": 17180967254,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180967254)
  ],
  "h": 1098070
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOnOffControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Commands${separator}TemplateOnOffControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1098070)
        
        

        //--TRIMMABLE-BOUNDARY-START(377174)
        $asm.$cls(`$ivxN.LCIDTMC.TemplateCountDownControlModel`, ($self) => class TemplateCountDownControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(12885279062)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885279062);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885279062)
            
            //--TRIMMABLE-BOUNDARY-START(17180246358)
            $ctor$3(/*int*/ count)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180246358);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Count = count;
                    this.LogTime = $.$fPer.LCFCDC.PackedDateTime.Pack($.$$.S.DateTime.UtcNow, 2020);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180246358)
            
            //--TRIMMABLE-BOUNDARY-START(21475213654)
            /*int */ get Command()
            {
                return ((128 + 4) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(21475213654)
            
            //--TRIMMABLE-BOUNDARY-START(25770180950)
            /*int*/ Count = 0;
            //--TRIMMABLE-BOUNDARY-END(25770180950)
            
            //--TRIMMABLE-BOUNDARY-START(55834952022)
            /*uint*/ LogTime = 0;
            //--TRIMMABLE-BOUNDARY-END(55834952022)
            
            //--TRIMMABLE-BOUNDARY-START(12885279062)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885279062)
            
            static $h = 377174;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475213654),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360115542,
        "f": 50364417
      },
      "n": "Command",
      "d": 377174,
      "h": 21475213654,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475213654),
//--TRIMMABLE-BOUNDARY-START(25770180950),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950050134,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424886614,
        "f": 83886082
      },
      "n": "Count",
      "d": 377174,
      "h": 25770180950,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770180950),
//--TRIMMABLE-BOUNDARY-START(55834952022),
    {
      "p": 720897,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539984726,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014821206,
        "f": 83886082
      },
      "n": "LogTime",
      "d": 377174,
      "h": 55834952022,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834952022)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885279062),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 377174,
      "h": 12885279062,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885279062),
//--TRIMMABLE-BOUNDARY-START(17180246358),
    {
      "p": [
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 377174,
      "h": 17180246358,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180246358)
  ],
  "h": 377174
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateCountDownControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Commands${separator}TemplateCountDownControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(377174)
        
        

        //--TRIMMABLE-BOUNDARY-START(1360214)
        $asm.$cls(`$ivxN.LCIDTMS.TemplateStatusModel`, ($self) => class TemplateStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(55835935062)
            /*bool*/ Status = false;
            //--TRIMMABLE-BOUNDARY-END(55835935062)
            
            //--TRIMMABLE-BOUNDARY-START(17181229398)
            /*int*/ CountDown = 0;
            //--TRIMMABLE-BOUNDARY-END(17181229398)
            
            //--TRIMMABLE-BOUNDARY-START(12886262102)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886262102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886262102)
            
            //--TRIMMABLE-BOUNDARY-START(12886262102)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886262102)
            
            static $h = 1360214;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835935062),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361098582,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540967766,
        "f": 83886081
      },
      "n": "Status",
      "d": 1360214,
      "h": 55835935062,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "Options",
              "v": [
                "Format=Bool(ON, OFF)"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835935062),
//--TRIMMABLE-BOUNDARY-START(17181229398),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771163990,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42951033174,
        "f": 83886081
      },
      "n": "CountDown",
      "d": 1360214,
      "h": 17181229398,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "Format=TimeSpan\u003ERemove(^0s$)",
                "Icon=Timer"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181229398)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886262102),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1360214,
      "h": 12886262102,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886262102)
  ],
  "h": 1360214
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Statuses.TemplateStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Statuses${separator}TemplateStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1360214)
        
        

        //--TRIMMABLE-BOUNDARY-START(2802006)
        $asm.$cls(`$ivxN.LCIDTM.TemplateLogModel`, ($self) => class TemplateLogModel extends $.$XBGm.LCICDi.iSmartDeviceLogModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297769302)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297769302);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297769302)
            
            //--TRIMMABLE-BOUNDARY-START(4297769302)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297769302)
            
            static $h = 2802006;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceLogModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297769302),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2802006,
      "h": 4297769302,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297769302)
  ],
  "h": 2802006
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceLog, $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateLogModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateLogModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2802006)
        
        

        //--TRIMMABLE-BOUNDARY-START(1622358)
        $asm.$str(`$ivxN.LCIDTM.TemplateBroadcastActionType`, ($self) => class TemplateBroadcastActionType extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static Off = 0;
            static On = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1622358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Off": 0n,
                    "On": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296589654)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296589654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296589654)
            
            //--TRIMMABLE-BOUNDARY-START(4296589654)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296589654)
            
            static $h = 1622358;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591556950),
    {
      "t": 1622358,
      "n": "Off",
      "d": 1622358,
      "h": 8591556950,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591556950),
//--TRIMMABLE-BOUNDARY-START(12886524246),
    {
      "t": 1622358,
      "n": "On",
      "d": 1622358,
      "h": 12886524246,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886524246)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296589654),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1622358,
      "h": 4296589654,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296589654)
  ],
  "h": 1622358
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateBroadcastActionType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateBroadcastActionType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1622358)
        
        

        //--TRIMMABLE-BOUNDARY-START(3719510)
        $asm.$str(`$ivxN.LCIDTS$1.TemplateBroadcastPeerMessages`, ($self) => class TemplateBroadcastPeerMessages extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static State = 1;
            static ToggleCountDown = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3719510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "State": 1n,
                    "ToggleCountDown": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298686806)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298686806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298686806)
            
            //--TRIMMABLE-BOUNDARY-START(4298686806)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298686806)
            
            static $h = 3719510;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8593654102),
    {
      "t": 3719510,
      "n": "None",
      "d": 3719510,
      "h": 8593654102,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593654102),
//--TRIMMABLE-BOUNDARY-START(12888621398),
    {
      "t": 3719510,
      "n": "State",
      "d": 3719510,
      "h": 12888621398,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888621398),
//--TRIMMABLE-BOUNDARY-START(17183588694),
    {
      "t": 3719510,
      "n": "ToggleCountDown",
      "d": 3719510,
      "h": 17183588694,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183588694)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298686806),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3719510,
      "h": 4298686806,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298686806)
  ],
  "h": 3719510
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Settings.TemplateBroadcastPeerMessages`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Settings${separator}TemplateBroadcastPeerMessages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3719510)
        
        

        //--TRIMMABLE-BOUNDARY-START(3588438)
        $asm.$str(`$ivxN.LCIDTS$1.TemplateActions`, ($self) => class TemplateActions extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static Off = 0;
            static On = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3588438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Off": 0n,
                    "On": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298555734)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298555734);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298555734)
            
            //--TRIMMABLE-BOUNDARY-START(4298555734)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298555734)
            
            static $h = 3588438;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8593523030),
    {
      "t": 3588438,
      "n": "Off",
      "d": 3588438,
      "h": 8593523030,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593523030),
//--TRIMMABLE-BOUNDARY-START(12888490326),
    {
      "t": 3588438,
      "n": "On",
      "d": 3588438,
      "h": 12888490326,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888490326)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298555734),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3588438,
      "h": 4298555734,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298555734)
  ],
  "h": 3588438
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Settings.TemplateActions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Settings${separator}TemplateActions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3588438)
        
        

        //--TRIMMABLE-BOUNDARY-START(3850582)
        $asm.$str(`$ivxN.LCIDTS$1.TemplateClickCommand`, ($self) => class TemplateClickCommand extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Toggle = 0;
            static CountDown = 1;
            static OnShot = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3850582);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Toggle": 0n,
                    "CountDown": 1n,
                    "OnShot": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298817878)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298817878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298817878)
            
            //--TRIMMABLE-BOUNDARY-START(4298817878)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298817878)
            
            static $h = 3850582;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17183719766),
    {
      "t": 3850582,
      "n": "Toggle",
      "d": 3850582,
      "h": 17183719766,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183719766),
//--TRIMMABLE-BOUNDARY-START(8593785174),
    {
      "t": 3850582,
      "n": "CountDown",
      "d": 3850582,
      "h": 8593785174,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593785174),
//--TRIMMABLE-BOUNDARY-START(12888752470),
    {
      "t": 3850582,
      "n": "OnShot",
      "d": 3850582,
      "h": 12888752470,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888752470)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298817878),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3850582,
      "h": 4298817878,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298817878)
  ],
  "h": 3850582
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Settings.TemplateClickCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Settings${separator}TemplateClickCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3850582)
        
        

        //--TRIMMABLE-BOUNDARY-START(901462)
        $asm.$cls(`$ivxN.LCIDTMC.TemplateOneShotControlModelTypeDescriptor`, ($self) => class TemplateOneShotControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTMC.TemplateOneShotControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295868758)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295868758);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ivxN.LCIDTMC.TemplateOneShotControlModelTypeDescriptor.GenerateProperties($.$ivxN.LCIDTMC.TemplateOneShotControlModel, this, factory);
                    }, $MJaeGg ??= {"r":65537,"n":"","d":901462,"h":0,"f":17825794}), 0, "TemplateOneShotControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Template\\Models_Commands_TemplateOneShotControlModel_LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOneShotControlModelTypeDescriptorBuilder.g.cs", "TemplateOneShotControlModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295868758)
            
            //--TRIMMABLE-BOUNDARY-START(12885803350)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885803350);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ivxN.LCIDTMC.TemplateOneShotControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Command";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOneShotControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTMC.TemplateOneShotControlModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ivxN.LCIDTMC.TemplateOneShotControlModel)).Command);
                        }, $YNszjj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":901462,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885803350)
            
            //--TRIMMABLE-BOUNDARY-START(17180770646)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOneShotControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180770646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180770646)
            
            //--TRIMMABLE-BOUNDARY-START(8590836054)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOneShotControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590836054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ivxN.LCIDTMC.TemplateOneShotControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ivxN.LCIDTMC.TemplateOneShotControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTMC.TemplateOneShotControlModel)))
                {
                    /*var*/ let result = $.$ivxN.LCIDTMC.TemplateOneShotControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTMC.TemplateOneShotControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ivxN.LCIDTMC.TemplateOneShotControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTMC.TemplateOneShotControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590836054)
            
            static $h = 901462;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTMC.TemplateOneShotControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885803350),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 901462,
      "h": 12885803350,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885803350),
//--TRIMMABLE-BOUNDARY-START(17180770646),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 770390,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 901462,
      "h": 17180770646,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180770646),
//--TRIMMABLE-BOUNDARY-START(8590836054),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 770390,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 901462,
      "h": 8590836054,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590836054)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295868758),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 901462,
      "h": 4295868758,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295868758)
  ],
  "h": 901462
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ivxN.LCIDTMC.TemplateOneShotControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOneShotControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Commands${separator}TemplateOneShotControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(901462)
        
        

        //--TRIMMABLE-BOUNDARY-START(1229142)
        $asm.$cls(`$ivxN.LCIDTMC.TemplateOnOffControlModelTypeDescriptor`, ($self) => class TemplateOnOffControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTMC.TemplateOnOffControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296196438)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296196438);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ivxN.LCIDTMC.TemplateOnOffControlModelTypeDescriptor.GenerateProperties($.$ivxN.LCIDTMC.TemplateOnOffControlModel, this, factory);
                    }, $sVtFyb ??= {"r":65537,"n":"","d":1229142,"h":0,"f":17825794}), 0, "TemplateOnOffControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Template\\Models_Commands_TemplateOnOffControlModel_LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOnOffControlModelTypeDescriptorBuilder.g.cs", "TemplateOnOffControlModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296196438)
            
            //--TRIMMABLE-BOUNDARY-START(12886131030)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886131030);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("State"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ivxN.LCIDTMC.TemplateOnOffControlModel.$type, $.$discardRef(), "State", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("State")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "State";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOnOffControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTMC.TemplateOnOffControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$ivxN.LCIDTMC.TemplateOnOffControlModel)).State);
                        }, $cCdQll ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1229142,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LogTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ivxN.LCIDTMC.TemplateOnOffControlModel.$type, $.$discardRef(), "LogTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LogTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.UInt32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "LogTime";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOnOffControlModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTMC.TemplateOnOffControlModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$13(($.$cast(target, $.$ivxN.LCIDTMC.TemplateOnOffControlModel)).LogTime);
                        }, $egAora ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1229142,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ivxN.LCIDTMC.TemplateOnOffControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Command";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOnOffControlModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTMC.TemplateOnOffControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ivxN.LCIDTMC.TemplateOnOffControlModel)).Command);
                        }, $HGkVqf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1229142,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886131030)
            
            //--TRIMMABLE-BOUNDARY-START(17181098326)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOnOffControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181098326);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _State = _target.State;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("State"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _State, ($v) => _State = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _LogTime = _target.LogTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LogTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.UInt32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.UInt32, property, $.$ref(() => _LogTime, ($v) => _LogTime = $v, $.$$.S.UInt32)))
                    {
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181098326)
            
            //--TRIMMABLE-BOUNDARY-START(8591163734)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOnOffControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591163734);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ivxN.LCIDTMC.TemplateOnOffControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ivxN.LCIDTMC.TemplateOnOffControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTMC.TemplateOnOffControlModel)))
                {
                    /*var*/ let result = $.$ivxN.LCIDTMC.TemplateOnOffControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTMC.TemplateOnOffControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ivxN.LCIDTMC.TemplateOnOffControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTMC.TemplateOnOffControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591163734)
            
            static $h = 1229142;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTMC.TemplateOnOffControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886131030),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1229142,
      "h": 12886131030,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886131030),
//--TRIMMABLE-BOUNDARY-START(17181098326),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1098070,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1229142,
      "h": 17181098326,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181098326),
//--TRIMMABLE-BOUNDARY-START(8591163734),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1098070,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1229142,
      "h": 8591163734,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591163734)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296196438),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1229142,
      "h": 4296196438,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296196438)
  ],
  "h": 1229142
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ivxN.LCIDTMC.TemplateOnOffControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOnOffControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Commands${separator}TemplateOnOffControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1229142)
        
        

        //--TRIMMABLE-BOUNDARY-START(1491286)
        $asm.$cls(`$ivxN.LCIDTMS.TemplateStatusModelTypeDescriptor`, ($self) => class TemplateStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTMS.TemplateStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296458582)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296458582);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ivxN.LCIDTMS.TemplateStatusModelTypeDescriptor.GenerateProperties($.$ivxN.LCIDTMS.TemplateStatusModel, this, factory);
                    }, $iIKqyh ??= {"r":65537,"n":"","d":1491286,"h":0,"f":17825794}), 0, "TemplateStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Template\\Models_Statuses_TemplateStatusModel_LivingThing.Core.IOT.Devices.Template.Models.Statuses.TemplateStatusModelTypeDescriptorBuilder.g.cs", "TemplateStatusModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296458582)
            
            //--TRIMMABLE-BOUNDARY-START(12886393174)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886393174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Status"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ivxN.LCIDTMS.TemplateStatusModel.$type, $.$discardRef(), "Status", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Status")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Status";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Template.Models.Statuses.TemplateStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTMS.TemplateStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$ivxN.LCIDTMS.TemplateStatusModel)).Status);
                        }, $AovAza ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1491286,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTMS.TemplateStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Status = value.AsBool();
                        }, $Pjunri ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1491286,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CountDown"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ivxN.LCIDTMS.TemplateStatusModel.$type, $.$discardRef(), "CountDown", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CountDown")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "CountDown";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Template.Models.Statuses.TemplateStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTMS.TemplateStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ivxN.LCIDTMS.TemplateStatusModel)).CountDown);
                        }, $KfLHMj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1491286,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTMS.TemplateStatusModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.CountDown = value.AsInt();
                        }, $GBYmCe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1491286,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886393174)
            
            //--TRIMMABLE-BOUNDARY-START(17181360470)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.Statuses.TemplateStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181360470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _Status = _target.Status;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Status"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _Status, ($v) => _Status = $v, null, true)))
                    {
                        _target.Status = _Status;
                    }
                }
                {
                    /*var*/ let _CountDown = _target.CountDown;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CountDown"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _CountDown, ($v) => _CountDown = $v, $.$$.S.Int32)))
                    {
                        _target.CountDown = _CountDown;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181360470)
            
            //--TRIMMABLE-BOUNDARY-START(8591425878)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.Statuses.TemplateStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591425878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ivxN.LCIDTMS.TemplateStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ivxN.LCIDTMS.TemplateStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTMS.TemplateStatusModel)))
                {
                    /*var*/ let result = $.$ivxN.LCIDTMS.TemplateStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTMS.TemplateStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ivxN.LCIDTMS.TemplateStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTMS.TemplateStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591425878)
            
            static $h = 1491286;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTMS.TemplateStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886393174),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1491286,
      "h": 12886393174,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886393174),
//--TRIMMABLE-BOUNDARY-START(17181360470),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1360214,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1491286,
      "h": 17181360470,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181360470),
//--TRIMMABLE-BOUNDARY-START(8591425878),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1360214,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1491286,
      "h": 8591425878,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591425878)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296458582),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1491286,
      "h": 4296458582,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296458582)
  ],
  "h": 1491286
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ivxN.LCIDTMS.TemplateStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Statuses.TemplateStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Statuses${separator}TemplateStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1491286)
        
        

        //--TRIMMABLE-BOUNDARY-START(508246)
        $asm.$cls(`$ivxN.LCIDTMC.TemplateCountDownControlModelTypeDescriptor`, ($self) => class TemplateCountDownControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTMC.TemplateCountDownControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295475542)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295475542);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ivxN.LCIDTMC.TemplateCountDownControlModelTypeDescriptor.GenerateProperties($.$ivxN.LCIDTMC.TemplateCountDownControlModel, this, factory);
                    }, $LgWpyk ??= {"r":65537,"n":"","d":508246,"h":0,"f":17825794}), 0, "TemplateCountDownControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Template\\Models_Commands_TemplateCountDownControlModel_LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateCountDownControlModelTypeDescriptorBuilder.g.cs", "TemplateCountDownControlModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295475542)
            
            //--TRIMMABLE-BOUNDARY-START(12885410134)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885410134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Count"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ivxN.LCIDTMC.TemplateCountDownControlModel.$type, $.$discardRef(), "Count", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Count")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Count";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateCountDownControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTMC.TemplateCountDownControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ivxN.LCIDTMC.TemplateCountDownControlModel)).Count);
                        }, $GsqMec ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":508246,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LogTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ivxN.LCIDTMC.TemplateCountDownControlModel.$type, $.$discardRef(), "LogTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LogTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.UInt32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "LogTime";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateCountDownControlModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTMC.TemplateCountDownControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$13(($.$cast(target, $.$ivxN.LCIDTMC.TemplateCountDownControlModel)).LogTime);
                        }, $qYwJld ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":508246,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ivxN.LCIDTMC.TemplateCountDownControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Command";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateCountDownControlModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTMC.TemplateCountDownControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ivxN.LCIDTMC.TemplateCountDownControlModel)).Command);
                        }, $MoaOGi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":508246,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885410134)
            
            //--TRIMMABLE-BOUNDARY-START(17180377430)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateCountDownControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180377430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Count = _target.Count;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Count"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Count, ($v) => _Count = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _LogTime = _target.LogTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LogTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.UInt32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.UInt32, property, $.$ref(() => _LogTime, ($v) => _LogTime = $v, $.$$.S.UInt32)))
                    {
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180377430)
            
            //--TRIMMABLE-BOUNDARY-START(8590442838)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateCountDownControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590442838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ivxN.LCIDTMC.TemplateCountDownControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ivxN.LCIDTMC.TemplateCountDownControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTMC.TemplateCountDownControlModel)))
                {
                    /*var*/ let result = $.$ivxN.LCIDTMC.TemplateCountDownControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTMC.TemplateCountDownControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ivxN.LCIDTMC.TemplateCountDownControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTMC.TemplateCountDownControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590442838)
            
            static $h = 508246;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTMC.TemplateCountDownControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885410134),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 508246,
      "h": 12885410134,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885410134),
//--TRIMMABLE-BOUNDARY-START(17180377430),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 377174,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 508246,
      "h": 17180377430,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180377430),
//--TRIMMABLE-BOUNDARY-START(8590442838),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 377174,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 508246,
      "h": 8590442838,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590442838)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295475542),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 508246,
      "h": 4295475542,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295475542)
  ],
  "h": 508246
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ivxN.LCIDTMC.TemplateCountDownControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateCountDownControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Commands${separator}TemplateCountDownControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(508246)
        
        

        //--TRIMMABLE-BOUNDARY-START(2933078)
        $asm.$cls(`$ivxN.LCIDTM.TemplateLogModelTypeDescriptor`, ($self) => class TemplateLogModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTM.TemplateLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297900374)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297900374);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ivxN.LCIDTM.TemplateLogModelTypeDescriptor.GenerateProperties($.$ivxN.LCIDTM.TemplateLogModel, this, factory);
                    }, $mLnDld ??= {"r":65537,"n":"","d":2933078,"h":0,"f":17825794}), 0, "TemplateLogModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Template\\Models_TemplateLogModel_LivingThing.Core.IOT.Devices.Template.Models.TemplateLogModelTypeDescriptorBuilder.g.cs", "TemplateLogModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297900374)
            
            //--TRIMMABLE-BOUNDARY-START(12887834966)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887834966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceLogModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887834966)
            
            //--TRIMMABLE-BOUNDARY-START(17182802262)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.TemplateLogModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182802262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceLogModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceLogModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceLogModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182802262)
            
            //--TRIMMABLE-BOUNDARY-START(8592867670)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.TemplateLogModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592867670);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ivxN.LCIDTM.TemplateLogModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ivxN.LCIDTM.TemplateLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateLogModel)))
                {
                    /*var*/ let result = $.$ivxN.LCIDTM.TemplateLogModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateLogModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ivxN.LCIDTM.TemplateLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateLogModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592867670)
            
            static $h = 2933078;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTM.TemplateLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887834966),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2933078,
      "h": 12887834966,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887834966),
//--TRIMMABLE-BOUNDARY-START(17182802262),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2802006,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2933078,
      "h": 17182802262,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182802262),
//--TRIMMABLE-BOUNDARY-START(8592867670),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2802006,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2933078,
      "h": 8592867670,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592867670)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297900374),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2933078,
      "h": 4297900374,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297900374)
  ],
  "h": 2933078
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ivxN.LCIDTM.TemplateLogModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateLogModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateLogModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2933078)
        
        

        //--TRIMMABLE-BOUNDARY-START(639318)
        $asm.$cls(`$ivxN.LCIDTMC.TemplateDeviceCommands<>`, (TDevice) => $asm.$gt(`$ivxN.LCIDTMC.TemplateDeviceCommands<>`, [TDevice], ($self) => class TemplateDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12885541206)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12885541206)
            
            //--TRIMMABLE-BOUNDARY-START(17180508502)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel?*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180508502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$ivxN.LCIDTMC.TemplateDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17180508502)
            
            //--TRIMMABLE-BOUNDARY-START(8590573910)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590573910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590573910)
            
            //--TRIMMABLE-BOUNDARY-START(8590573910)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590573910)
            
            //--TRIMMABLE-BOUNDARY-START(4295606614)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295606614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885541206)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [new $.$ivxN.LCIDTMC.TemplateOnOffCommand().$ctor$6(), new $.$ivxN.LCIDTMC.TemplateCountDownCommand().$ctor$6(), new $.$ivxN.LCIDTMC.TemplateOneShotCommand().$ctor$6()], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12885541206)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295606614)
            
            static $H = 639318;
            static $h = 639318;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180508502),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17180508502,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180508502)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885541206),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12885541206,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885541206)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590573910),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8590573910,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590573910)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 639318,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Commands${separator}TemplateDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(639318)
        
        

        //--TRIMMABLE-BOUNDARY-START(311638)
        $asm.$cls(`$ivxN.LCIDTMC.TemplateCountDownCommand`, ($self) => class TemplateCountDownCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$ivxN.LCIDTMC.TemplateCountDownControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295278934)
            $ctor$6()
            {
                super.$ctor$5("CountDown", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295278934);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295278934)
            
            //--TRIMMABLE-BOUNDARY-START(17180180822)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-counter"/*MaterialDesignIconNames.Counter*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17180180822)
            
            //--TRIMMABLE-BOUNDARY-START(4295278934)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295278934)
            
            static $h = 311638;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$ivxN.LCIDTMC.TemplateCountDownControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180180822),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885213526,
        "f": 50364417
      },
      "n": "Icon",
      "d": 311638,
      "h": 17180180822,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180180822)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295278934),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 311638,
      "h": 4295278934,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295278934)
  ],
  "h": 311638
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateCountDownCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Commands${separator}TemplateCountDownCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(311638)
        
        

        //--TRIMMABLE-BOUNDARY-START(1032534)
        $asm.$cls(`$ivxN.LCIDTMC.TemplateOnOffCommand`, ($self) => class TemplateOnOffCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$ivxN.LCIDTMC.TemplateOnOffControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295999830)
            $ctor$6()
            {
                super.$ctor$5("On/Off", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295999830);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295999830)
            
            //--TRIMMABLE-BOUNDARY-START(17180901718)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-electric-switch"/*MaterialDesignIconNames.ElectricSwitch*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17180901718)
            
            //--TRIMMABLE-BOUNDARY-START(4295999830)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295999830)
            
            static $h = 1032534;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$ivxN.LCIDTMC.TemplateOnOffControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180901718),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885934422,
        "f": 50364417
      },
      "n": "Icon",
      "d": 1032534,
      "h": 17180901718,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180901718)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295999830),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1032534,
      "h": 4295999830,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295999830)
  ],
  "h": 1032534
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOnOffCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Commands${separator}TemplateOnOffCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1032534)
        
        

        //--TRIMMABLE-BOUNDARY-START(704854)
        $asm.$cls(`$ivxN.LCIDTMC.TemplateOneShotCommand`, ($self) => class TemplateOneShotCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$ivxN.LCIDTMC.TemplateOneShotControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295672150)
            $ctor$6()
            {
                super.$ctor$5("OneShot", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295672150);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295672150)
            
            //--TRIMMABLE-BOUNDARY-START(17180574038)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-timer-sand"/*MaterialDesignIconNames.TimerSand*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17180574038)
            
            //--TRIMMABLE-BOUNDARY-START(4295672150)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295672150)
            
            static $h = 704854;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$ivxN.LCIDTMC.TemplateOneShotControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180574038),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885606742,
        "f": 50364417
      },
      "n": "Icon",
      "d": 704854,
      "h": 17180574038,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180574038)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295672150),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 704854,
      "h": 4295672150,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295672150)
  ],
  "h": 704854
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.Commands.TemplateOneShotCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}Commands${separator}TemplateOneShotCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(704854)
        
        

        //--TRIMMABLE-BOUNDARY-START(2539862)
        $asm.$cls(`$ivxN.LCIDTM.TemplateDeviceSendDataModel`, ($self) => class TemplateDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceCommandsModel
        {
            //--TRIMMABLE-BOUNDARY-START(12887441750)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887441750);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887441750)
            
            //--TRIMMABLE-BOUNDARY-START(21477376342)
            $ctor$6(/*TemplateOnOffControlModel*/ on)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477376342);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.On = on;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477376342)
            
            //--TRIMMABLE-BOUNDARY-START(17182409046)
            $ctor$5(/*TemplateCountDownControlModel*/ countDown)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182409046);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.CountDown = countDown;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182409046)
            
            //--TRIMMABLE-BOUNDARY-START(47247180118)
            /*TemplateOnOffControlModel?*/ On = null;
            //--TRIMMABLE-BOUNDARY-END(47247180118)
            
            //--TRIMMABLE-BOUNDARY-START(25772343638)
            /*TemplateCountDownControlModel?*/ CountDown = null;
            //--TRIMMABLE-BOUNDARY-END(25772343638)
            
            //--TRIMMABLE-BOUNDARY-START(12887441750)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12887441750)
            
            static $h = 2539862;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandsModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47247180118),
    {
      "p": 1098070,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952212822,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64427049302,
        "f": 83886081
      },
      "n": "On",
      "d": 2539862,
      "h": 47247180118,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 13432,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47247180118),
//--TRIMMABLE-BOUNDARY-START(25772343638),
    {
      "p": 377174,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362278230,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55837114710,
        "f": 83886081
      },
      "n": "CountDown",
      "d": 2539862,
      "h": 25772343638,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 13432,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25772343638)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887441750),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2539862,
      "h": 12887441750,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887441750),
//--TRIMMABLE-BOUNDARY-START(21477376342),
    {
      "p": [
        {
          "n": "on",
          "p": 1098070
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2539862,
      "h": 21477376342,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477376342),
//--TRIMMABLE-BOUNDARY-START(17182409046),
    {
      "p": [
        {
          "n": "countDown",
          "p": 377174
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2539862,
      "h": 17182409046,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182409046)
  ],
  "h": 2539862
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2539862)
        
        

        //--TRIMMABLE-BOUNDARY-START(2670934)
        $asm.$cls(`$ivxN.LCIDTM.TemplateDeviceSendDataModelTypeDescriptor`, ($self) => class TemplateDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTM.TemplateDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297638230)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297638230);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ivxN.LCIDTM.TemplateDeviceSendDataModelTypeDescriptor.GenerateProperties($.$ivxN.LCIDTM.TemplateDeviceSendDataModel, this, factory);
                    }, $hxLQNa ??= {"r":65537,"n":"","d":2670934,"h":0,"f":17825794}), 0, "TemplateDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Template\\Models_TemplateDeviceSendDataModel_LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceSendDataModelTypeDescriptorBuilder.g.cs", "TemplateDeviceSendDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297638230)
            
            //--TRIMMABLE-BOUNDARY-START(12887572822)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887572822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("On"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel.$type, $.$discardRef(), "On", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("On")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ivxN.LCIDTMC.TemplateOnOffControlModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "On";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceSendDataModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTM.TemplateDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$ivxN.LCIDTMC.TemplateOnOffControlModel, ($.$cast(target, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel)).On);
                        }, $RhieNi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2670934,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTM.TemplateDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.On = value.AsReference($.$ivxN.LCIDTMC.TemplateOnOffControlModel);
                        }, $GTownh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2670934,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CountDown"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel.$type, $.$discardRef(), "CountDown", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CountDown")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ivxN.LCIDTMC.TemplateCountDownControlModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "CountDown";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceSendDataModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTM.TemplateDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$ivxN.LCIDTMC.TemplateCountDownControlModel, ($.$cast(target, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel)).CountDown);
                        }, $QvXZba ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2670934,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTM.TemplateDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CountDown = value.AsReference($.$ivxN.LCIDTMC.TemplateCountDownControlModel);
                        }, $ITehNb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2670934,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887572822)
            
            //--TRIMMABLE-BOUNDARY-START(17182540118)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182540118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandsModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandsModel));
                {
                    /*var*/ let _On = _target.On;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("On"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ivxN.LCIDTMC.TemplateOnOffControlModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _On, ($v) => _On = $v, $.$ivxN.LCIDTMC.TemplateOnOffControlModel)))
                    {
                        _target.On = _On;
                    }
                }
                {
                    /*var*/ let _CountDown = _target.CountDown;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CountDown"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ivxN.LCIDTMC.TemplateCountDownControlModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _CountDown, ($v) => _CountDown = $v, $.$ivxN.LCIDTMC.TemplateCountDownControlModel)))
                    {
                        _target.CountDown = _CountDown;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182540118)
            
            //--TRIMMABLE-BOUNDARY-START(8592605526)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592605526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ivxN.LCIDTM.TemplateDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$ivxN.LCIDTM.TemplateDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592605526)
            
            static $h = 2670934;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTM.TemplateDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887572822),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2670934,
      "h": 12887572822,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887572822),
//--TRIMMABLE-BOUNDARY-START(17182540118),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2539862,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2670934,
      "h": 17182540118,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182540118),
//--TRIMMABLE-BOUNDARY-START(8592605526),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2539862,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2670934,
      "h": 8592605526,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592605526)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297638230),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2670934,
      "h": 4297638230,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297638230)
  ],
  "h": 2670934
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ivxN.LCIDTM.TemplateDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2670934)
        
        

        //--TRIMMABLE-BOUNDARY-START(2015574)
        $asm.$cls(`$ivxN.LCIDTM.TemplateDeviceReceivedDataModel`, ($self) => class TemplateDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$ivxN.LCIDTMS.TemplateStatusModel, $.$ivxN.LCIDTM.TemplateLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296982870)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296982870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296982870)
            
            //--TRIMMABLE-BOUNDARY-START(4296982870)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296982870)
            
            static $h = 2015574;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$ivxN.LCIDTMS.TemplateStatusModel, $.$ivxN.LCIDTM.TemplateLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296982870),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2015574,
      "h": 4296982870,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296982870)
  ],
  "h": 2015574
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2015574)
        
        

        //--TRIMMABLE-BOUNDARY-START(2146646)
        $asm.$cls(`$ivxN.LCIDTM.TemplateDeviceReceivedDataModelTypeDescriptor`, ($self) => class TemplateDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297113942)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297113942);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, this, factory);
                    }, $Vbdllk ??= {"r":65537,"n":"","d":2146646,"h":0,"f":17825794}), 0, "TemplateDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Template\\Models_TemplateDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "TemplateDeviceReceivedDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297113942)
            
            //--TRIMMABLE-BOUNDARY-START(12887048534)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887048534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$ivxN.LCIDTMS.TemplateStatusModel, $.$ivxN.LCIDTM.TemplateLogModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887048534)
            
            //--TRIMMABLE-BOUNDARY-START(17182015830)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182015830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.Template.Models.Statuses.TemplateStatusModel, LivingThing.Core.IOT.Devices.Template.Models.TemplateLogModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$ivxN.LCIDTMS.TemplateStatusModel, $.$ivxN.LCIDTM.TemplateLogModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$ivxN.LCIDTMS.TemplateStatusModel, $.$ivxN.LCIDTM.TemplateLogModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182015830)
            
            //--TRIMMABLE-BOUNDARY-START(8592081238)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592081238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592081238)
            
            static $h = 2146646;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887048534),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2146646,
      "h": 12887048534,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887048534),
//--TRIMMABLE-BOUNDARY-START(17182015830),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2015574,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2146646,
      "h": 17182015830,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182015830),
//--TRIMMABLE-BOUNDARY-START(8592081238),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2015574,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2146646,
      "h": 8592081238,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592081238)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297113942),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2146646,
      "h": 4297113942,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297113942)
  ],
  "h": 2146646
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2146646)
        
        

        //--TRIMMABLE-BOUNDARY-START(4505942)
        $asm.$cls(`$ivxN.LCIDT.TemplateDataConverter`, ($self) => class TemplateDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299473238)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299473238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299473238)
            
            //--TRIMMABLE-BOUNDARY-START(4299473238)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299473238)
            
            static $h = 4505942;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299473238),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4505942,
      "h": 4299473238,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299473238)
  ],
  "h": 4505942
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.TemplateDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}TemplateDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4505942)
        
        

        $asm.$typeProxy("$ivxN.LCIDTM.TemplateServiceModel", "$ivxN.LivingThing.Core.IOT.Devices.Template.Models.TemplateServiceModel");
        $asm.$typeProxy("$ivxN.LCIDTM.TemplateDeviceModel", "$ivxN.LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceModel");
        $asm.$typeProxy("$ivxN.LCIDTS$1.TemplateDeviceSettings", "$ivxN.LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceSettings");
        $asm.$typeProxy("$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings", "$ivxN.LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceHardwareSettings");
        $asm.$typeProxy("$ivxN.LCIDTS.ITemplateDeviceStatusHandler", "$ivxN.LivingThing.Core.IOT.Devices.Template.Services.ITemplateDeviceStatusHandler");
        $asm.$typeProxy("$ivxN.LCIDTS.ITemplateDeviceHubClient", "$ivxN.LivingThing.Core.IOT.Devices.Template.Services.ITemplateDeviceHubClient");
        $asm.$typeProxy("$ivxN.LCIDTS.ITemplateRemoteService", "$ivxN.LivingThing.Core.IOT.Devices.Template.Services.ITemplateRemoteService");
        //--TRIMMABLE-BOUNDARY-START(2277718)
        $asm.$cls(`$ivxN.LCIDTM.TemplateDeviceScopeModel`, ($self) => class TemplateDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297245014)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297245014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297245014)
            
            //--TRIMMABLE-BOUNDARY-START(4297245014)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4297245014)
            
            static $h = 2277718;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297245014),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 2277718,
      "h": 4297245014,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297245014)
  ],
  "h": 2277718
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2277718)
        
        

        //--TRIMMABLE-BOUNDARY-START(3064150)
        $asm.$cls(`$ivxN.LCIDTM.TemplateServiceModel`, ($self) => class TemplateServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298031446)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298031446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298031446)
            
            //--TRIMMABLE-BOUNDARY-START(4298031446)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4298031446)
            
            static $h = 3064150;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298031446),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 3064150,
      "h": 4298031446,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298031446)
  ],
  "h": 3064150
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3064150)
        
        

        //--TRIMMABLE-BOUNDARY-START(3522902)
        $asm.$cls(`$ivxN.LCIDTS.ITemplateRemoteService`, ($self) => class ITemplateRemoteService
        {
            static $h = 3522902;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3522902
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$ivxN.LCIDTM.TemplateServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$ivxN.LCIDTM.TemplateServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$ivxN.LCIDTM.TemplateServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$ivxN.LCIDTM.TemplateServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$ivxN.LCIDTM.TemplateServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$ivxN.LCIDTM.TemplateServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$ivxN.LCIDTM.TemplateServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$ivxN.LCIDTM.TemplateServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Services.ITemplateRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Services${separator}ITemplateRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3522902)
        
        

        //--TRIMMABLE-BOUNDARY-START(1753430)
        $asm.$cls(`$ivxN.LCIDTM.TemplateDeviceModel`, ($self) => class TemplateDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296720726)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296720726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296720726)
            
            //--TRIMMABLE-BOUNDARY-START(4296720726)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296720726)
            
            static $h = 1753430;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296720726),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1753430,
      "h": 4296720726,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296720726)
  ],
  "h": 1753430
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1753430)
        
        

        //--TRIMMABLE-BOUNDARY-START(3391830)
        $asm.$cls(`$ivxN.LCIDTS.ITemplateDeviceHubClient`, ($self) => class ITemplateDeviceHubClient
        {
            static $h = 3391830;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3391830
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Services.ITemplateDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Services${separator}ITemplateDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3391830)
        
        

        //--TRIMMABLE-BOUNDARY-START(3457366)
        $asm.$cls(`$ivxN.LCIDTS.ITemplateDeviceStatusHandler`, ($self) => class ITemplateDeviceStatusHandler
        {
            static $h = 3457366;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3457366
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Services.ITemplateDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Services${separator}ITemplateDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3457366)
        
        

        //--TRIMMABLE-BOUNDARY-START(3981654)
        $asm.$cls(`$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings`, ($self) => class TemplateDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).iSmartDeviceHardwareSettings$$($.$ivxN.LCIDTS$1.TemplateActions)
        {
            //--TRIMMABLE-BOUNDARY-START(21478818134)
            /*IOTDeviceInternalConfiguration<bool>*/ Sample = null;
            //--TRIMMABLE-BOUNDARY-END(21478818134)
            
            //--TRIMMABLE-BOUNDARY-START(8593916246)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593916246);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593916246)
            
            //--TRIMMABLE-BOUNDARY-START(8593916246)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8593916246)
            
            static $h = 3981654;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).iSmartDeviceHardwareSettings$$($.$ivxN.LCIDTS$1.TemplateActions); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21478818134),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183850838,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30068752726,
        "f": 83886081
      },
      "n": "Sample",
      "d": 3981654,
      "h": 21478818134,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "rem",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 20,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21478818134)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593916246),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3981654,
      "h": 8593916246,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593916246)
  ],
  "h": 3981654
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Settings${separator}TemplateDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3981654)
        
        

        //--TRIMMABLE-BOUNDARY-START(4243798)
        $asm.$cls(`$ivxN.LCIDTS$1.TemplateDeviceSettings`, ($self) => class TemplateDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $self, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(34363982166)
            /*bool*/ Invert = false;
            //--TRIMMABLE-BOUNDARY-END(34363982166)
            
            //--TRIMMABLE-BOUNDARY-START(38658949462)
            /*TemplateClickCommand*/ OnClick = 0;
            //--TRIMMABLE-BOUNDARY-END(38658949462)
            
            //--TRIMMABLE-BOUNDARY-START(12889145686)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889145686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12889145686)
            
            //--TRIMMABLE-BOUNDARY-START(12889145686)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12889145686)
            
            static $h = 4243798;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34363982166),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479080278,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47248884054,
        "f": 83886081
      },
      "n": "Invert",
      "d": 4243798,
      "h": 34363982166,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 256,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34363982166),
//--TRIMMABLE-BOUNDARY-START(38658949462),
    {
      "p": 3850582,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069014870,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55838818646,
        "f": 83886081
      },
      "n": "OnClick",
      "d": 4243798,
      "h": 38658949462,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 257,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38658949462)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12889145686),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4243798,
      "h": 12889145686,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889145686)
  ],
  "h": 4243798
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Settings${separator}TemplateDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4243798)
        
        

        //--TRIMMABLE-BOUNDARY-START(4768086)
        $asm.$cls(`$ivxN.LCIDT.TemplateDeviceModelDefinition`, ($self) => class TemplateDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4299735382)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299735382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299735382)
            
            //--TRIMMABLE-BOUNDARY-START(4299735382)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299735382)
            
            static $h = 4768086;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299735382),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4768086,
      "h": 4299735382,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299735382)
  ],
  "h": 4768086
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.TemplateDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}TemplateDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4768086)
        
        

        //--TRIMMABLE-BOUNDARY-START(2408790)
        $asm.$cls(`$ivxN.LCIDTM.TemplateDeviceScopeModelTypeDescriptor`, ($self) => class TemplateDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTM.TemplateDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297376086)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297376086);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ivxN.LCIDTM.TemplateDeviceScopeModelTypeDescriptor.GenerateProperties($.$ivxN.LCIDTM.TemplateDeviceScopeModel, this, factory);
                    }, $cyhWzj ??= {"r":65537,"n":"","d":2408790,"h":0,"f":17825794}), 0, "TemplateDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Template\\Models_TemplateDeviceScopeModel_LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceScopeModelTypeDescriptorBuilder.g.cs", "TemplateDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297376086)
            
            //--TRIMMABLE-BOUNDARY-START(12887310678)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887310678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887310678)
            
            //--TRIMMABLE-BOUNDARY-START(17182277974)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182277974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Template.Models.TemplateServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceModel, LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceSettings, LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceSendDataModel, LivingThing.Core.IOT.Devices.Template.Services.ITemplateDeviceStatusHandler, LivingThing.Core.IOT.Devices.Template.Services.ITemplateDeviceHubClient, LivingThing.Core.IOT.Devices.Template.Services.ITemplateRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182277974)
            
            //--TRIMMABLE-BOUNDARY-START(8592343382)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592343382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ivxN.LCIDTM.TemplateDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateDeviceScopeModel)))
                {
                    /*var*/ let result = $.$ivxN.LCIDTM.TemplateDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592343382)
            
            static $h = 2408790;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTM.TemplateDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887310678),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2408790,
      "h": 12887310678,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887310678),
//--TRIMMABLE-BOUNDARY-START(17182277974),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2277718,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2408790,
      "h": 17182277974,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182277974),
//--TRIMMABLE-BOUNDARY-START(8592343382),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2277718,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2408790,
      "h": 8592343382,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592343382)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297376086),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2408790,
      "h": 4297376086,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297376086)
  ],
  "h": 2408790
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ivxN.LCIDTM.TemplateDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2408790)
        
        

        //--TRIMMABLE-BOUNDARY-START(1884502)
        $asm.$cls(`$ivxN.LCIDTM.TemplateDeviceModelTypeDescriptor`, ($self) => class TemplateDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTM.TemplateDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296851798)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296851798);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ivxN.LCIDTM.TemplateDeviceModelTypeDescriptor.GenerateProperties($.$ivxN.LCIDTM.TemplateDeviceModel, this, factory);
                    }, $aySsNb ??= {"r":65537,"n":"","d":1884502,"h":0,"f":17825794}), 0, "TemplateDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Template\\Models_TemplateDeviceModel_LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceModelTypeDescriptorBuilder.g.cs", "TemplateDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296851798)
            
            //--TRIMMABLE-BOUNDARY-START(12886786390)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886786390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886786390)
            
            //--TRIMMABLE-BOUNDARY-START(17181753686)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181753686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Template.Models.TemplateServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceModel, LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceSettings, LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceSendDataModel, LivingThing.Core.IOT.Devices.Template.Services.ITemplateDeviceStatusHandler, LivingThing.Core.IOT.Devices.Template.Services.ITemplateDeviceHubClient, LivingThing.Core.IOT.Devices.Template.Services.ITemplateRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181753686)
            
            //--TRIMMABLE-BOUNDARY-START(8591819094)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591819094);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ivxN.LCIDTM.TemplateDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ivxN.LCIDTM.TemplateDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateDeviceModel)))
                {
                    /*var*/ let result = $.$ivxN.LCIDTM.TemplateDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ivxN.LCIDTM.TemplateDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591819094)
            
            static $h = 1884502;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTM.TemplateDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886786390),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1884502,
      "h": 12886786390,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886786390),
//--TRIMMABLE-BOUNDARY-START(17181753686),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1753430,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1884502,
      "h": 17181753686,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181753686),
//--TRIMMABLE-BOUNDARY-START(8591819094),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1753430,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1884502,
      "h": 8591819094,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591819094)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296851798),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1884502,
      "h": 4296851798,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296851798)
  ],
  "h": 1884502
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ivxN.LCIDTM.TemplateDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1884502)
        
        

        //--TRIMMABLE-BOUNDARY-START(4112726)
        $asm.$cls(`$ivxN.LCIDTS$1.TemplateDeviceHardwareSettingsTypeDescriptor`, ($self) => class TemplateDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299080022)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299080022);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, this, factory);
                    }, $LjVSFj ??= {"r":65537,"n":"","d":4112726,"h":0,"f":17825794}), 0, "TemplateDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Template\\Settings_TemplateDeviceHardwareSettings_LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "TemplateDeviceHardwareSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299080022)
            
            //--TRIMMABLE-BOUNDARY-START(12889014614)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889014614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Sample"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings.$type, $.$discardRef(), "Sample", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Sample")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Sample";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceHardwareSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean), ($.$cast(target, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings)).Sample);
                        }, $qUQtPi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4112726,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Sample = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean));
                        }, $fMohJa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4112726,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor$$($.$ivxN.LCIDTS$1.TemplateActions).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889014614)
            
            //--TRIMMABLE-BOUNDARY-START(17183981910)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183981910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.Template.Models.TemplateServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceModel, LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceSettings, LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceSendDataModel, LivingThing.Core.IOT.Devices.Template.Services.ITemplateDeviceStatusHandler, LivingThing.Core.IOT.Devices.Template.Services.ITemplateDeviceHubClient, LivingThing.Core.IOT.Devices.Template.Services.ITemplateRemoteService>.iSmartDeviceHardwareSettings<LivingThing.Core.IOT.Devices.Template.Settings.TemplateActions>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor$$($.$ivxN.LCIDTS$1.TemplateActions).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).iSmartDeviceHardwareSettings$$($.$ivxN.LCIDTS$1.TemplateActions)));
                {
                    /*var*/ let _Sample = _target.Sample;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Sample"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Sample, ($v) => _Sample = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean))))
                    {
                        _target.Sample = _Sample;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183981910)
            
            //--TRIMMABLE-BOUNDARY-START(8594047318)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594047318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594047318)
            
            static $h = 4112726;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889014614),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4112726,
      "h": 12889014614,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889014614),
//--TRIMMABLE-BOUNDARY-START(17183981910),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3981654,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4112726,
      "h": 17183981910,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183981910),
//--TRIMMABLE-BOUNDARY-START(8594047318),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3981654,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4112726,
      "h": 8594047318,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594047318)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299080022),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4112726,
      "h": 4299080022,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299080022)
  ],
  "h": 4112726
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Settings${separator}TemplateDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4112726)
        
        

        //--TRIMMABLE-BOUNDARY-START(3195222)
        $asm.$cls(`$ivxN.LCIDTM.TemplateServiceModelTypeDescriptor`, ($self) => class TemplateServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTM.TemplateServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298162518)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298162518);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ivxN.LCIDTM.TemplateServiceModelTypeDescriptor.GenerateProperties($.$ivxN.LCIDTM.TemplateServiceModel, this, factory);
                    }, $YJxYRd ??= {"r":65537,"n":"","d":3195222,"h":0,"f":17825794}), 0, "TemplateServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Template\\Models_TemplateServiceModel_LivingThing.Core.IOT.Devices.Template.Models.TemplateServiceModelTypeDescriptorBuilder.g.cs", "TemplateServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298162518)
            
            //--TRIMMABLE-BOUNDARY-START(12888097110)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888097110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888097110)
            
            //--TRIMMABLE-BOUNDARY-START(17183064406)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.TemplateServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183064406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Template.Models.TemplateServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceModel, LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceSettings, LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceSendDataModel, LivingThing.Core.IOT.Devices.Template.Services.ITemplateDeviceStatusHandler, LivingThing.Core.IOT.Devices.Template.Services.ITemplateDeviceHubClient, LivingThing.Core.IOT.Devices.Template.Services.ITemplateRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183064406)
            
            //--TRIMMABLE-BOUNDARY-START(8593129814)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Models.TemplateServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593129814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ivxN.LCIDTM.TemplateServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ivxN.LCIDTM.TemplateServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateServiceModel)))
                {
                    /*var*/ let result = $.$ivxN.LCIDTM.TemplateServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ivxN.LCIDTM.TemplateServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTM.TemplateServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593129814)
            
            static $h = 3195222;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTM.TemplateServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888097110),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3195222,
      "h": 12888097110,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888097110),
//--TRIMMABLE-BOUNDARY-START(17183064406),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3064150,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3195222,
      "h": 17183064406,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183064406),
//--TRIMMABLE-BOUNDARY-START(8593129814),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3064150,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3195222,
      "h": 8593129814,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593129814)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298162518),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3195222,
      "h": 4298162518,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298162518)
  ],
  "h": 3195222
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ivxN.LCIDTM.TemplateServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Models.TemplateServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Models${separator}TemplateServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3195222)
        
        

        //--TRIMMABLE-BOUNDARY-START(4374870)
        $asm.$cls(`$ivxN.LCIDTS$1.TemplateDeviceSettingsTypeDescriptor`, ($self) => class TemplateDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTS$1.TemplateDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299342166)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299342166);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ivxN.LCIDTS$1.TemplateDeviceSettingsTypeDescriptor.GenerateProperties($.$ivxN.LCIDTS$1.TemplateDeviceSettings, this, factory);
                    }, $EsJWIh ??= {"r":65537,"n":"","d":4374870,"h":0,"f":17825794}), 0, "TemplateDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Template\\Settings_TemplateDeviceSettings_LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceSettingsTypeDescriptorBuilder.g.cs", "TemplateDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299342166)
            
            //--TRIMMABLE-BOUNDARY-START(12889276758)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889276758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Invert"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ivxN.LCIDTS$1.TemplateDeviceSettings.$type, $.$discardRef(), "Invert", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Invert")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Invert";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTS$1.TemplateDeviceSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$ivxN.LCIDTS$1.TemplateDeviceSettings)).Invert);
                        }, $GdbMca ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4374870,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTS$1.TemplateDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Invert = value.AsBool();
                        }, $KfZKoh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4374870,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("OnClick"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ivxN.LCIDTS$1.TemplateDeviceSettings.$type, $.$discardRef(), "OnClick", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("OnClick")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ivxN.LCIDTS$1.TemplateClickCommand, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "OnClick";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTS$1.TemplateDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$ivxN.LCIDTS$1.TemplateClickCommand, ($.$cast(target, $.$ivxN.LCIDTS$1.TemplateDeviceSettings)).OnClick);
                        }, $xFSIof ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4374870,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ivxN.LCIDTS$1.TemplateDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.OnClick = value.AsEnumValue($.$ivxN.LCIDTS$1.TemplateClickCommand);
                        }, $wUefzb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4374870,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889276758)
            
            //--TRIMMABLE-BOUNDARY-START(17184244054)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184244054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.Template.Models.TemplateServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceModel, LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceSettings, LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Template.Models.TemplateDeviceSendDataModel, LivingThing.Core.IOT.Devices.Template.Services.ITemplateDeviceStatusHandler, LivingThing.Core.IOT.Devices.Template.Services.ITemplateDeviceHubClient, LivingThing.Core.IOT.Devices.Template.Services.ITemplateRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService).iSmartDeviceSettings));
                {
                    /*var*/ let _Invert = _target.Invert;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Invert"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _Invert, ($v) => _Invert = $v, null, true)))
                    {
                        _target.Invert = _Invert;
                    }
                }
                {
                    /*var*/ let _OnClick = _target.OnClick;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("OnClick"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ivxN.LCIDTS$1.TemplateClickCommand));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ivxN.LCIDTS$1.TemplateClickCommand, () => _OnClick, ($v) => _OnClick = $v, null, true)))
                    {
                        _target.OnClick = _OnClick;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184244054)
            
            //--TRIMMABLE-BOUNDARY-START(8594309462)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594309462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ivxN.LCIDTS$1.TemplateDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTS$1.TemplateDeviceSettings)))
                {
                    /*var*/ let result = $.$ivxN.LCIDTS$1.TemplateDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTS$1.TemplateDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ivxN.LCIDTS$1.TemplateDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594309462)
            
            static $h = 4374870;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ivxN.LCIDTS$1.TemplateDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889276758),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4374870,
      "h": 12889276758,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889276758),
//--TRIMMABLE-BOUNDARY-START(17184244054),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4243798,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4374870,
      "h": 17184244054,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184244054),
//--TRIMMABLE-BOUNDARY-START(8594309462),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4243798,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4374870,
      "h": 8594309462,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594309462)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299342166),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4374870,
      "h": 4299342166,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299342166)
  ],
  "h": 4374870
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ivxN.LCIDTS$1.TemplateDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.Settings.TemplateDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}Settings${separator}TemplateDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4374870)
        
        

        //--TRIMMABLE-BOUNDARY-START(4571478)
        $asm.$cls(`$ivxN.LCIDT.TemplateDevice`, ($self) => class TemplateDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$ivxN.LCIDTMS.TemplateStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4299538774)
            $ctor$2(/*IIOTDeviceFamily<TemplateDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*TemplateDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299538774);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299538774)
            
            //--TRIMMABLE-BOUNDARY-START(38659277142)
            /*IconDescriptor */ get Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184440662);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let icon = super.Icon;
                return (() =>
                {
                    //new $.$fPer.LCFC.IconDescriptor()
                    const $t1 = $.$fPer.LCFC.IconDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Icon = this.Model$1.DeviceType !== 0/*IOTDeviceType.Others*/ ? $.$XBGm.LCIC.UtilityExtension.MaterialIcon(this.Model$1.DeviceType, this.On) : icon.Icon;
                    $i1.Theme = $.$with(icon.Theme, ($clone) =>
                    {
                        $clone.ForegroundColor = this.On ? "FFFF00" : "FFFFFF";
                    });
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(38659277142)
            
            //--TRIMMABLE-BOUNDARY-START(42954244438)
            /*bool */ get On()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25774375254);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let b = (this.Received?.Status?.Status ?? null);
                if ($.$$.S.Boolean.op_BitwiseAnd$2(((this.Settings$1?.Invert ?? null) ?? false), b !== null))
                {
                    b = b === true ? false : true;
                }
                return b ?? false;
            }
            //--TRIMMABLE-BOUNDARY-END(42954244438)
            
            //--TRIMMABLE-BOUNDARY-START(64429080918)
            /*string */ get StatusText()
            {
                return this.On ? "ON" : "OFF";
            }
            //--TRIMMABLE-BOUNDARY-END(64429080918)
            
            //--TRIMMABLE-BOUNDARY-START(55839146326)
            /*Task */ SetOnOff(/*bool*/ on)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55839146326);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$ivxN.LCIDTMC.TemplateOnOffCommand, $.$ivxN.LCIDTMC.TemplateOnOffControlModel, this, new $.$ivxN.LCIDTMC.TemplateOnOffCommand().$ctor$6(), new $.$ivxN.LCIDTMC.TemplateOnOffControlModel().$ctor$3(on));
            }
            //--TRIMMABLE-BOUNDARY-END(55839146326)
            
            //--TRIMMABLE-BOUNDARY-START(47249211734)
            /*Task */ SetCountDown(/*TimeSpan*/ time)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47249211734);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$ivxN.LCIDTMC.TemplateCountDownCommand, $.$ivxN.LCIDTMC.TemplateCountDownControlModel, this, new $.$ivxN.LCIDTMC.TemplateCountDownCommand().$ctor$6(), new $.$ivxN.LCIDTMC.TemplateCountDownControlModel().$ctor$3($.$cast(time.TotalSeconds, $.$$.S.Int32)));
            }
            //--TRIMMABLE-BOUNDARY-END(47249211734)
            
            //--TRIMMABLE-BOUNDARY-START(51544179030)
            /*Task */ SetOneShot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51544179030);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$ivxN.LCIDTMC.TemplateOneShotCommand, $.$ivxN.LCIDTMC.TemplateOneShotControlModel, this, new $.$ivxN.LCIDTMC.TemplateOneShotCommand().$ctor$6(), new $.$ivxN.LCIDTMC.TemplateOneShotControlModel().$ctor$2());
            }
            //--TRIMMABLE-BOUNDARY-END(51544179030)
            
            //--TRIMMABLE-BOUNDARY-START(8594506070)
            /*Task */ Clicked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594506070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let on = (this.Received?.Status?.Status ?? null) ?? false;
                let $switch2 = this.Settings$1.OnClick;
                switch($switch2)
                {
                    case 0/*TemplateClickCommand.Toggle*/:
                    return this.SetOnOff(!on);
                    case 2/*TemplateClickCommand.OnShot*/:
                    return this.SetOneShot();
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(8594506070)
            
            //--TRIMMABLE-BOUNDARY-START(60134113622)
            /*void */ SetStatus(/*bool*/ enable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60134113622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetOnOff(enable);
            }
            //--TRIMMABLE-BOUNDARY-END(60134113622)
            
            static $h = 4571478;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$ivxN.LCIDTMS.TemplateStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38659277142),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17184440662,
        "f": 50364417
      },
      "n": "Icon",
      "d": 4571478,
      "h": 38659277142,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38659277142),
//--TRIMMABLE-BOUNDARY-START(42954244438),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25774375254,
        "f": 50331649
      },
      "n": "On",
      "d": 4571478,
      "h": 42954244438,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42954244438),
//--TRIMMABLE-BOUNDARY-START(64429080918),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34364309846,
        "f": 50364417
      },
      "n": "StatusText",
      "d": 4571478,
      "h": 64429080918,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64429080918)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55839146326),
    {
      "r": 178454529,
      "p": [
        {
          "n": "on",
          "p": 262145
        }
      ],
      "n": "SetOnOff",
      "d": 4571478,
      "h": 55839146326,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55839146326),
//--TRIMMABLE-BOUNDARY-START(47249211734),
    {
      "r": 178454529,
      "p": [
        {
          "n": "time",
          "p": 186646529
        }
      ],
      "n": "SetCountDown",
      "d": 4571478,
      "h": 47249211734,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47249211734),
//--TRIMMABLE-BOUNDARY-START(51544179030),
    {
      "r": 178454529,
      "n": "SetOneShot",
      "d": 4571478,
      "h": 51544179030,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51544179030),
//--TRIMMABLE-BOUNDARY-START(8594506070),
    {
      "r": 178454529,
      "n": "Clicked",
      "d": 4571478,
      "h": 8594506070,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8594506070),
//--TRIMMABLE-BOUNDARY-START(60134113622),
    {
      "r": 65537,
      "p": [
        {
          "n": "enable",
          "p": 262145
        }
      ],
      "n": "SetStatus",
      "d": 4571478,
      "h": 60134113622,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60134113622)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299538774),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$ivxN.LCIDT.TemplateDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 1753430
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4571478,
      "h": 4299538774,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299538774)
  ],
  "h": 4571478
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.TemplateDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}TemplateDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4571478)
        
        

        //--TRIMMABLE-BOUNDARY-START(4637014)
        $asm.$cls(`$ivxN.LCIDT.TemplateDeviceDefinition`, ($self) => class TemplateDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$ivxN.LCIDTMS.TemplateStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299604310)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299604310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299604310)
            
            //--TRIMMABLE-BOUNDARY-START(4299604310)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299604310)
            
            static $h = 4637014;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$ivxN.LCIDTMS.TemplateStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299604310),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4637014,
      "h": 4299604310,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299604310)
  ],
  "h": 4637014
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.TemplateDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}TemplateDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4637014)
        
        

        //--TRIMMABLE-BOUNDARY-START(4702550)
        $asm.$cls(`$ivxN.LCIDT.TemplateDeviceFamily`, ($self) => class TemplateDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4299669846)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<TemplateDeviceReceivedDataModel, TemplateDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<TemplateDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299669846);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299669846)
            
            //--TRIMMABLE-BOUNDARY-START(12889604438)
            /*Type */ get DeviceBroadcastSendMessageEnumType()
            {
                return $.$ivxN.LCIDTS$1.TemplateBroadcastPeerMessages.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(12889604438)
            
            //--TRIMMABLE-BOUNDARY-START(8594637142)
            /*Type */ get DeviceBroadcastReceiveActionType()
            {
                return $.$ivxN.LCIDTM.TemplateBroadcastActionType.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8594637142)
            
            //--TRIMMABLE-BOUNDARY-START(17184571734)
            /*Type */ get DeviceLogType()
            {
                return $.$ivxN.LCIDTM.TemplateLogModel.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17184571734)
            
            static $h = 4702550;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12889604438),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34364440918,
        "f": 50364417
      },
      "n": "DeviceBroadcastSendMessageEnumType",
      "d": 4702550,
      "h": 12889604438,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12889604438),
//--TRIMMABLE-BOUNDARY-START(8594637142),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25774506326,
        "f": 50364417
      },
      "n": "DeviceBroadcastReceiveActionType",
      "d": 4702550,
      "h": 8594637142,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8594637142),
//--TRIMMABLE-BOUNDARY-START(17184571734),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42954375510,
        "f": 50364417
      },
      "n": "DeviceLogType",
      "d": 4702550,
      "h": 17184571734,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17184571734)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299669846),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4702550,
      "h": 4299669846,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299669846)
  ],
  "h": 4702550
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$ivxN.LCIDT.TemplateDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$ivxN.LCIDT.TemplateDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.TemplateDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}TemplateDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4702550)
        
        

        $asm.$typeProxy("$ivxN.LCIDTV.TemplateClientAppViewModel", "$ivxN.LivingThing.Core.IOT.Devices.Template.ViewModels.TemplateClientAppViewModel");
        $asm.$typeProxy("$ivxN.LCIDTV.TemplateClientAppDeviceScopeViewModel", "$ivxN.LivingThing.Core.IOT.Devices.Template.ViewModels.TemplateClientAppDeviceScopeViewModel");
        $asm.$typeProxy("$ivxN.LCIDTV.TemplateClientAppDeviceViewModel", "$ivxN.LivingThing.Core.IOT.Devices.Template.ViewModels.TemplateClientAppDeviceViewModel");
        //--TRIMMABLE-BOUNDARY-START(5095766)
        $asm.$cls(`$ivxN.LCIDTV.TemplateClientAppServiceViewModel`, ($self) => class TemplateClientAppServiceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTV.TemplateClientAppViewModel, $self, $.$ivxN.LCIDTV.TemplateClientAppDeviceScopeViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceViewModel, $.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4300063062)
            $ctor$3(/*TemplateClientAppViewModel*/ app, /*TemplateServiceModel*/ model)
            {
                super.$ctor$3(app, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300063062);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300063062)
            
            //--TRIMMABLE-BOUNDARY-START(12889997654)
            /*TemplateClientAppDeviceViewModel */ GetDeviceViewModel(/*TemplateDeviceModel*/ model, /*IEnumerable<TemplateClientAppDeviceScopeViewModel>*/ scopes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889997654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$ivxN.LCIDTV.TemplateClientAppDeviceViewModel().$ctor$7(this, model, scopes);
            }
            //--TRIMMABLE-BOUNDARY-END(12889997654)
            
            //--TRIMMABLE-BOUNDARY-START(8595030358)
            /*TemplateClientAppDeviceScopeViewModel */ GetDeviceScopeViewModel(/*TemplateDeviceScopeModel*/ model, /*IEnumerable<TemplateClientAppDeviceViewModel>*/ devices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595030358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$ivxN.LCIDTV.TemplateClientAppDeviceScopeViewModel().$ctor$3(this, model, devices);
            }
            //--TRIMMABLE-BOUNDARY-END(8595030358)
            
            static $h = 5095766;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTV.TemplateClientAppViewModel, $.$ivxN.LCIDTV.TemplateClientAppServiceViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceScopeViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceViewModel, $.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889997654),
    {
      "r": 5030230,
      "p": [
        {
          "n": "model",
          "p": 1753430
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$ivxN.LCIDTV.TemplateClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": "GetDeviceViewModel",
      "d": 5095766,
      "h": 12889997654,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12889997654),
//--TRIMMABLE-BOUNDARY-START(8595030358),
    {
      "r": 4964694,
      "p": [
        {
          "n": "model",
          "p": 2277718
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$ivxN.LCIDTV.TemplateClientAppDeviceViewModel).$h
        }
      ],
      "n": "GetDeviceScopeViewModel",
      "d": 5095766,
      "h": 8595030358,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8595030358)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300063062),
    {
      "p": [
        {
          "n": "app",
          "p": 5161302
        },
        {
          "n": "model",
          "p": 3064150
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5095766,
      "h": 4300063062,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300063062)
  ],
  "h": 5095766
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTApplicationServiceViewModel$$$$$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceScopeViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceViewModel, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTApplicationServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.ViewModels.TemplateClientAppServiceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}ViewModels${separator}TemplateClientAppServiceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5095766)
        
        

        //--TRIMMABLE-BOUNDARY-START(4964694)
        $asm.$cls(`$ivxN.LCIDTV.TemplateClientAppDeviceScopeViewModel`, ($self) => class TemplateClientAppDeviceScopeViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTV.TemplateClientAppViewModel, $.$ivxN.LCIDTV.TemplateClientAppServiceViewModel, $self, $.$ivxN.LCIDTV.TemplateClientAppDeviceViewModel, $.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4299931990)
            $ctor$3(/*TemplateClientAppServiceViewModel*/ service, /*TemplateDeviceScopeModel*/ model, /*IEnumerable<TemplateClientAppDeviceViewModel>*/ devices)
            {
                super.$ctor$3(service, model, devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299931990);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299931990)
            
            static $h = 4964694;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTV.TemplateClientAppViewModel, $.$ivxN.LCIDTV.TemplateClientAppServiceViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceScopeViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceViewModel, $.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299931990),
    {
      "p": [
        {
          "n": "service",
          "p": 5095766
        },
        {
          "n": "model",
          "p": 2277718
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$ivxN.LCIDTV.TemplateClientAppDeviceViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4964694,
      "h": 4299931990,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299931990)
  ],
  "h": 4964694
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$vWqU.LCFCC.IViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTDeviceScopeViewModel$$$($.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceViewModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.ViewModels.TemplateClientAppDeviceScopeViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}ViewModels${separator}TemplateClientAppDeviceScopeViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4964694)
        
        

        //--TRIMMABLE-BOUNDARY-START(5030230)
        $asm.$cls(`$ivxN.LCIDTV.TemplateClientAppDeviceViewModel`, ($self) => class TemplateClientAppDeviceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTV.TemplateClientAppViewModel, $.$ivxN.LCIDTV.TemplateClientAppServiceViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceScopeViewModel, $self, $.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4299997526)
            $ctor$7(/*TemplateClientAppServiceViewModel*/ service, /*TemplateDeviceModel*/ model, /*IEnumerable<TemplateClientAppDeviceScopeViewModel>*/ scopes)
            {
                super.$ctor$7(service, model, scopes);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299997526);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299997526)
            
            static $h = 5030230;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTV.TemplateClientAppViewModel, $.$ivxN.LCIDTV.TemplateClientAppServiceViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceScopeViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceViewModel, $.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299997526),
    {
      "p": [
        {
          "n": "service",
          "p": 5095766
        },
        {
          "n": "model",
          "p": 1753430
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$ivxN.LCIDTV.TemplateClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 5030230,
      "h": 4299997526,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299997526)
  ],
  "h": 5030230
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICV.IIOTDeviceViewModel$$$$($.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTDeviceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.ViewModels.TemplateClientAppDeviceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}ViewModels${separator}TemplateClientAppDeviceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5030230)
        
        

        //--TRIMMABLE-BOUNDARY-START(5161302)
        $asm.$cls(`$ivxN.LCIDTV.TemplateClientAppViewModel`, ($self) => class TemplateClientAppViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($self, $.$ivxN.LCIDTV.TemplateClientAppServiceViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceScopeViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceViewModel, $.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4300128598)
            $ctor$5(/*IOTRootViewModel*/ root, /*TemplateDeviceFamily*/ family, /*IHubConnector<IIOTDeviceHubClientBase<TemplateDeviceReceivedDataModel, IOTDeviceStatusModel>>*/ hubConnector)
            {
                super.$ctor$5(root, family, $.$$.N.InterfaceVarianceStubHandler.Create(hubConnector, $.$kVHt.LCFCH.IHubConnector$$($.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)), $.$kVHt.LCFCH.IHubConnector$$($.$ivxN.LCIDTS.ITemplateDeviceHubClient)));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300128598);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300128598)
            
            //--TRIMMABLE-BOUNDARY-START(8595095894)
            /*bool */ get Authorize()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595095894)
            
            //--TRIMMABLE-BOUNDARY-START(21479997782)
            /*TemplateClientAppServiceViewModel */ GetServiceViewModel(/*TemplateServiceModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479997782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$ivxN.LCIDTV.TemplateClientAppServiceViewModel().$ctor$3(this, model);
            }
            //--TRIMMABLE-BOUNDARY-END(21479997782)
            
            static $h = 5161302;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTV.TemplateClientAppViewModel, $.$ivxN.LCIDTV.TemplateClientAppServiceViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceScopeViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceViewModel, $.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8595095894),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17185030486,
        "f": 50364417
      },
      "n": "Authorize",
      "d": 5161302,
      "h": 8595095894,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8595095894)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21479997782),
    {
      "r": 5095766,
      "p": [
        {
          "n": "model",
          "p": 3064150
        }
      ],
      "n": "GetServiceViewModel",
      "d": 5161302,
      "h": 21479997782,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21479997782)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300128598),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "family",
          "p": 4702550
        },
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$($.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5161302,
      "h": 4300128598,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300128598)
  ],
  "h": 5161302
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$ntej.LCICV.IIOTAppViewModel$$($.$ivxN.LCIDTM.TemplateServiceModel), $.$ntej.LCICV.IIOTApplicationViewModel, $.$vWqU.LCFCC.IServiceViewModel$$($.$ivxN.LCIDTM.TemplateServiceModel), $.$vWqU.LCFCC.IServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$yleQ.LCFCA.IApplicationService, $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$($.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$vWqU.LCFCC.IServiceSubscriptionViewModel$$($.$ivxN.LCIDTM.TemplateServiceModel), $.$vWqU.LCFCC.IServiceSubscriptionViewModel, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IClientRootService$$($.$ivxN.LCIDTM.TemplateServiceModel), $.$vWqU.LCFCC.IClientRootService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.ViewModels.TemplateClientAppViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}ViewModels${separator}TemplateClientAppViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5161302)
        
        

        //--TRIMMABLE-BOUNDARY-START(4899158)
        $asm.$cls(`$ivxN.LCIDTV.TemplateClientAppDefinition`, ($self) => class TemplateClientAppDefinition extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTV.TemplateClientAppViewModel, $.$ivxN.LCIDTV.TemplateClientAppServiceViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceScopeViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceViewModel, $.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299866454)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299866454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299866454)
            
            //--TRIMMABLE-BOUNDARY-START(4299866454)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299866454)
            
            static $h = 4899158;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ivxN.LCIDTV.TemplateClientAppViewModel, $.$ivxN.LCIDTV.TemplateClientAppServiceViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceScopeViewModel, $.$ivxN.LCIDTV.TemplateClientAppDeviceViewModel, $.$ivxN.LCIDT.TemplateDevice, $.$ivxN.LCIDTM.TemplateServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ivxN.LCIDTM.TemplateDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ivxN.LCIDTM.TemplateDeviceModel, $.$ivxN.LCIDTS$1.TemplateDeviceSettings, $.$ivxN.LCIDTS$1.TemplateDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ivxN.LCIDTM.TemplateDeviceReceivedDataModel, $.$ivxN.LCIDTM.TemplateDeviceSendDataModel, $.$ivxN.LCIDTS.ITemplateDeviceStatusHandler, $.$ivxN.LCIDTS.ITemplateDeviceHubClient, $.$ivxN.LCIDTS.ITemplateRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299866454),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4899158,
      "h": 4299866454,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299866454)
  ],
  "h": 4899158
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Template.ViewModels.TemplateClientAppDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Template${separator}ViewModels${separator}TemplateClientAppDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4899158)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(49494)
