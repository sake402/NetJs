
//--TRIMMABLE-BOUNDARY-START(51812)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $MQrkmi;
    let $Xaycqd;
    let $jMyGke;
    let $JPeVMj;
    let $ougZXb;
    let $urmbIf;
    let $RwQnYb;
    let $XHhdIk;
    let $yTbskb;
    let $fCerxc;
    let $VzjoJk;
    let $wSsdIf;
    let $icTPdh;
    let $SRmAGk;
    let $aCSawd;
    let $grPFYd;
    let $OxdYxg;
    let $ihHXth;
    let $avItwj;
    let $hSXPxi;
    let $aDCOAk;
    let $HxJsnb;
    let $vExkEk;
    let $xRDDLj;
    let $hVCxdg;
    let $gsbYRg;
    let $PAItge;
    let $uQVcRj;
    let $lGowMh;
    let $QqRLPd;
    let $bEJojl;
    let $wflKtf;
    let $FLlPai;
    let $imfxGd;
    let $RjrQrh;
    let $kBUBvj;
    let $YCYtYh;
    let $sZOFbd;
    let $SXIlNe;
    let $TPpXYb;
    let $nsyKPj;
    let $RLneDc;
    let $ReCCjj;
    let $biczqb;
    let $Diyilc;
    let $tpkGZb;
    let $ZnOCCi;
    let $xwPami;
    let $WTsvWg;
    let $JutIAb;
    let $iNaWcd;
    let $nVvdgk;
    let $SebnAk;
    let $fwLxxd;
    let $pGcVDe;
    let $hygVLg;
    let $vnYvCd;
    let $DlZxZh;
    let $wigNqg;
    let $PnxlJj;
    let $AreYyh;
    let $QCYgyg;
    let $ZEKSlh;
    let $JFwfDb;
    let $horKbc;
    let $PQsNEi;
    let $Uylscl;
    let $HPrJoh;
    let $ZHQRUa;
    let $SFNNGk;
    let $OLnQTc;
    let $VNkqUj;
    let $mcCGRg;
    let $bTDUsf;
    let $Dlurze;
    let $bndivd;
    let $IVIyOe;
    let $dgVBOf;
    let $koqxCc;
    let $QvpGQd;
    let $XiJZvf;
    let $MtBNZk;
    let $TlrsUj;
    let $Zolhra;
    let $GGuSKg;
    let $hitRgi;
    let $MZYKGe;
    let $gUpXJd;
    let $mfapri;
    let $gAEjfe;
    let $PqKsfb;
    let $coGAGg;
    let $Omvcse;
    let $glFkyc;
    let $UpNCGf;
    let $YuAsse;
    let $nilemi;
    let $biSvja;
    let $mkkjwk;
    let $OKccze;
    let $eeaREd;
    let $FTXqzf;
    let $dTotCg;
    let $dzSehj;
    let $ZwqwPd;
    let $lyvBii;
    let $yEiHbe;
    let $TpTcSh;
    let $YeBqSb;
    let $LuYfkd;
    let $vKZsed;
    let $IJIece;
    let $SnRDva;
    let $oUZMyh;
    let $XvLwle;
    let $faerHi;
    let $NikQIi;
    let $ADqgJi;
    let $RNJXmk;
    let $vscwNi;
    let $euRDZd;
    let $RvFWjf;
    let $RYWvsk;
    let $Epxhzb;
    let $HnYGBg;
    let $AGsjtk;
    let $qzOgEi;
    let $XTikqg;
    let $JJFxEj;
    let $YrTsQi;
    let $uAgRll;
    let $kgYbCa;
    let $uvIGEe;
    let $Igzxre;
    let $KZbPCd;
    let $DPVvMf;
    let $IJNFVi;
    let $bLJfZg;
    let $RlYogh;
    let $lbVGjf;
    let $LVCErk;
    let $IuFFwh;
    let $hpwkci;
    let $uOUskc;
    let $MjxEJb;
    let $zBuHGk;
    let $xOEWuc;
    let $GNImDi;
    let $hBDjlj;
    let $ocsOog;
    let $Wxcyag;
    let $mxjwzg;
    let $KduYdi;
    let $TxCsCe;
    let $SQeksh;
    let $AGCMma;
    let $cbQIfd;
    let $HzbwPg;
    let $ighxEc;
    let $UYvUwd;
    let $HWzFqa;
    let $CpKCwk;
    let $ifBuse;
    let $jstgTb;
    let $DHKVYf;
    let $ykZYmf;
    let $vtDEeg;
    let $axLPKa;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.Terrameter", 
    {
  "h": 51812,
  "f": "LivingThing.Core.IOT.Devices.Terrameter",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.Terrameter",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.Terrameter",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5UZXJyYW1ldGVyLlRlcnJhbWV0ZXJEZXZpY2UiOiB7DQogICAgICAiQ2F0ZWdvcmllcyI6IFsgIk1lYXN1cmVtZW50IiwgIkdlb3BoeXNpY3MiLCAiUmVzaXN0aXZpdHkgbWV0ZXIiIF0sDQogICAgICAiTmFtZSI6ICJUZXJyYW1ldGVyIiwNCiAgICAgICJDYXRhbG9ndWVOYW1lIjogIlRlcnJhbWV0ZXIsIFJlc2lzdGl2aXR5L1NQL0lQL0VSVCBtZXRlciIsDQogICAgICAiRGVzY3JpcHRpb24iOiAiQSB0ZXJyYW1ldGVyIG1ldGVyIGlzIGFuIGFkdmFuY2VkIGdlb3BoeXNpY2FsIGluc3RydW1lbnQgZGVzaWduZWQgdG8gbWVhc3VyZSB0aGUgZWxlY3RyaWNhbCByZXNpc3Rpdml0eSBvZiB2YXJpb3VzIG1hdGVyaWFscywgcHJpbWFyaWx5IHVzZWQgaW4gc3Vic3VyZmFjZSBpbnZlc3RpZ2F0aW9ucy5cclxuXHJcbkl0IHR5cGljYWxseSBjb25zaXN0cyBvZiBhIHBvcnRhYmxlIGNvbnRyb2wgdW5pdCwgZWxlY3Ryb2RlcywgYW5kIGNhYmxlcyB0byBpbmplY3QgZWxlY3RyaWNhbCBjdXJyZW50IGludG8gdGhlIGdyb3VuZCBhbmQgbWVhc3VyZSB0aGUgcmVzdWx0aW5nIHZvbHRhZ2UgZGlmZmVyZW5jZXMuIFRoaXMgZGF0YSBpcyB0aGVuIHVzZWQgdG8gY2FsY3VsYXRlIHRoZSByZXNpc3Rpdml0eSBvZiB0aGUgc3Vic3VyZmFjZSBtYXRlcmlhbHMuXHJcblxyXG4qKkN1cnJlbnQgSW5qZWN0aW9uKio6IFRoZSBtYWNoaW5lIHNlbmRzIGEgY29udHJvbGxlZCBlbGVjdHJpY2FsIGN1cnJlbnQgaW50byB0aGUgZ3JvdW5kIHRocm91Z2ggdGhlIGVsZWN0cm9kZXMuXHJcblxyXG4qKlZvbHRhZ2UgTWVhc3VyZW1lbnQqKjogSXQgbWVhc3VyZXMgdGhlIHZvbHRhZ2UgZGlmZmVyZW5jZSBiZXR3ZWVuIHNlbGVjdGVkIGVsZWN0cm9kZXMuXHJcblxyXG4qKlJlc2lzdGl2aXR5IENhbGN1bGF0aW9uKio6IFRoZSBtYWNoaW5lIGNhbGN1bGF0ZXMgdGhlIGFwcGFyZW50IHJlc2lzdGl2aXR5IG9mIHRoZSBncm91bmQgdXNpbmcgdGhlIG1lYXN1cmVkIHZvbHRhZ2UsIGluamVjdGVkIGN1cnJlbnQsIGFuZCBlbGVjdHJvZGUgc3BhY2luZy5cclxuXHJcblRoZSByZXNpc3Rpdml0eSBtZXRlcuKAmXMgcG9ydGFiaWxpdHkgYW5kIGFjY3VyYWN5IG1ha2UgaXQgaWRlYWwgZm9yIGZpZWxkIHN1cnZleXMsIG9mZmVyaW5nIGEgbm9uLWRlc3RydWN0aXZlIG1lYW5zIG9mIHByb2JpbmcgYmVsb3cgdGhlIEVhcnRo4oCZcyBzdXJmYWNlIHdpdGhvdXQgdGhlIG5lZWQgZm9yIGRyaWxsaW5nIG9yIGV4Y2F2YXRpb24uIiwNCiAgICAgICJJY29uIjogeyAiTmFtZSI6ICJtZGkgbWRpLWVsZWN0cmljLXN3aXRjaCIgfSwNCiAgICAgICJUaGVtZUNvbG9yIjogIiNkNzdiYmEiLA0KICAgICAgIkZsYWdzIjogIkZlYXR1cmVkLFB1Ymxpc2hlZCIsDQogICAgICAiU2VjdXJpdGllcyI6ICJDaGFsbGVuZ2VIYW5kU2hha2VBdXRoZW50aWNhdGlvblByb3RvY29sLEFkdmFuY2VkRW5jcnlwdGlvblN0YW5kYXJkLEVsbGlwdGljQ3VydmVGaXJtd2FyZVVwZGF0ZVNpZ25pbmciLA0KICAgICAgIkJhbm5lckltYWdlIjogIn4vaW1nL3NlcnZlci9tZXRlcl9pbl9pcDYwLmpwZyIsDQogICAgICAiVXJsU2x1ZyI6ICJUZXJyYW1ldGVyIiwNCiAgICAgICJJbWFnZXMiOiBbDQogICAgICAgICJ\u002BL2ltZy9zZXJ2ZXIvbWV0ZXJfaW5faXA2MC5qcGciLA0KICAgICAgICAifi9pbWcvc2VydmVyL3RlcnJfaXA2NV9zb2xhciAoMSkuanBnIiwNCiAgICAgICAgIn4vaW1nL3NlcnZlci90ZXJyX2lwNjVfc29sYXIgKDIpLmpwZyIsDQogICAgICAgICJ\u002BL2ltZy9zZXJ2ZXIvdGVycl9pcDY1X3NvbGFyICgzKS5qcGciLA0KICAgICAgICAifi9pbWcvc2VydmVyL3RlcnJfaXA2NV9zb2xhciAoNCkuanBnIiwNCiAgICAgICAgIn4vaW1nL3NlcnZlci90ZXJyX2lwNjVfc29sYXIgKDUpLmpwZyIsDQogICAgICAgICJ\u002BL2ltZy9zZXJ2ZXIvdGVycl9pcDY1X3NvbGFyICg2KS5qcGciLA0KICAgICAgICAifi9pbWcvc2VydmVyL3RlcnJfaXA2NV9zb2xhciAoNykuanBnIiwNCiAgICAgICAgIn4vaW1nL3NlcnZlci90ZXJyX2lwNjVfc29sYXIgKDgpLmpwZyIsDQogICAgICAgICJ\u002BL2ltZy9zZXJ2ZXIvdGVycl9pcDY1X3NvbGFyICg5KS5qcGciLA0KICAgICAgICAifi9pbWcvc2VydmVyL3RlcnJfaXA2NV9zb2xhciAoMTApLmpwZyIsDQogICAgICAgICJ\u002BL2ltZy9zZXJ2ZXIvdGVycl9pcDY1X3NvbGFyICgxMSkuanBnIiwNCiAgICAgICAgIn4vaW1nL3NlcnZlci90ZXJyX2lwNjVfc29sYXIgKDEyKS5qcGciLA0KICAgICAgICAifi9pbWcvc2VydmVyL3RlcnJfaXA2NV9zb2xhciAoMTMpLmpwZyIsDQogICAgICAgICJ\u002BL2ltZy9zZXJ2ZXIvdGVycl9pcDY1X3NvbGFyICgxNCkuanBnIiwNCiAgICAgICAgIn4vaW1nL3NlcnZlci90ZXJyX2lwNjVfc29sYXIgKDE1KS5qcGciLA0KICAgICAgICAifi9pbWcvc2VydmVyL3RlcnJfaXA2NV9zb2xhciAoMTYpLmpwZyIsDQogICAgICAgICJ\u002BL2ltZy9zZXJ2ZXIvdGVycl9pcDY1X3NvbGFyICgxNykuanBnIiwNCiAgICAgICAgIn4vaW1nL3NlcnZlci90ZXJyX2lwNjVfc29sYXIgKDE4KS5qcGciLA0KICAgICAgICAifi9pbWcvc2VydmVyL3RlcnJfaXA2NV9zb2xhciAoMTkpLmpwZyIsDQogICAgICAgICJ\u002BL2ltZy9zZXJ2ZXIvdGVycl9pcDY1X3NvbGFyICgyMCkuanBnIiwNCiAgICAgICAgIn4vaW1nL3NlcnZlci90ZXJyX2lwNjVfc29sYXIgKDIxKS5qcGciLA0KICAgICAgICAifi9pbWcvc2VydmVyL3RlcnJfaXA2NV9zb2xhciAoMjIpLmpwZyIsDQogICAgICAgICJ\u002BL2ltZy9zZXJ2ZXIvdGVycl9pcDY1X3NvbGFyICgyMykuanBnIiwNCiAgICAgICAgIn4vaW1nL3NlcnZlci90MS5qcGciLA0KICAgICAgICAifi9pbWcvc2VydmVyL3QyLmpwZyIsDQogICAgICAgICJ\u002BL2ltZy9zZXJ2ZXIvdDMuanBnIiwNCiAgICAgICAgIn4vaW1nL3NlcnZlci90NC5qcGciLA0KICAgICAgICAifi9pbWcvc2VydmVyL3Q1LmpwZyIsDQogICAgICAgICJ\u002BL2ltZy9zZXJ2ZXIvdDYuanBnIiwNCiAgICAgICAgIn4vaW1nL3NlcnZlci90Ny5qcGciLA0KICAgICAgICAifi9pbWcvc2VydmVyL3Q4LmpwZyIsDQogICAgICAgICJ\u002BL2ltZy9zZXJ2ZXIvdDkuanBnIiwNCiAgICAgICAgIn4vaW1nL3NlcnZlci90MTAuanBnIiwNCiAgICAgICAgIn4vaW1nL3NlcnZlci90MTEuanBnIiwNCiAgICAgICAgIn4vaW1nL3NlcnZlci90MTIuanBnIg0KICAgICAgXSwNCiAgICAgICJVbml0Q29zdCI6IHsNCiAgICAgICAgIlZhbHVlIjogODIwMDAwLA0KICAgICAgICAiVW5pdCI6ICJOYWlyYSINCiAgICAgIH0sDQogICAgICAiVGFncyI6IFsNCiAgICAgICAgew0KICAgICAgICAgICJOYW1lIjogIlRlcnJhbWV0ZXIiDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiTmFtZSI6ICJSZXNpc3Rpdml0eSBtZXRlciINCiAgICAgICAgfQ0KICAgICAgXSwNCiAgICAgICJGZWF0dXJlcyI6IFsNCiAgICAgICAgew0KICAgICAgICAgICJUaXRsZSI6ICJDb250cm9sIFVuaXQiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJUaGUgbWFpbiBib2R5IG9mIHRoZSByZXNpc3Rpdml0eSBtZXRlciwgdXN1YWxseSBlcXVpcHBlZCB3aXRoIGEgZGlnaXRhbCBpbnRlcmZhY2UgdG8gZGlzcGxheSBtZWFzdXJlbWVudHMsIGNvbnRyb2wgY3VycmVudCBpbmplY3Rpb24sIGFuZCBhZGp1c3Qgb3BlcmF0aW9uYWwgc2V0dGluZ3MiDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiQXV0b21hdGljIFNQIENhbmNlbGxhdGlvbiIsDQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogIlNlbGYgcG90ZW50aWFsIGJldHdlZW4gTU4gZWxlY3RvZGVzIGltcGVkZXMgdGhlIG1lYXN1cmVtZW50IG9mIHJlc2lzdGl2aXR5IGFuZCBJUCBpbiBnZW9waHlzaWNhbCBzdXJ2ZXkuIGlTbWFydCBUZXJyYW1ldGVyIGlzIGVxdWlwZWQgd2l0aCBhbiBhdXRvbWF0aWMgU1AgY2FuY2VsbGF0aW9uIHNjaGVtZSB0aGUgcmVtb3ZlcyB0aGUgU1Agdm9sdGFnZSBmcm9tIGludGVyZmVyaW5nIHdpdGggeW91ciBtZWFzdXJlbWVudHMuIg0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIkhpZ2ggR2FsdmFuaWMgSXNvbGF0aW9uIiwNCiAgICAgICAgICAiRGVzY3JpcHRpb24iOiAiTWVhc3VyaW5nIGFjY3VyYXRlIHJlc3VsdCBpbiBzb21lIGdlb3BoeXNpY2FsIG1ldGhvZHMgcmVxdWlyZXMgYSB2ZXJ5IGhpZ2ggaW1wZWRhbmNlIGJldHdlZW4gdGhlIHRyYW5zbWl0dGVyIGFuZCB0aGUgcmVjZWl2ZXIuIGlTbWFydCBUZXJyYW1ldGVyIGlzIGRlc2lnbmVkIHdpdGggYSBjb21wbGV0ZSBnYWx2YW5pYyBpc29hdGlvbiBiZXR3ZWVuIHRoZSB0cmFuc21pdHRlciBhbmQgcmVjZWl2ZXIuIg0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIkhpZ2ggTm9pc2UgcmVqZWN0aW9uIiwNCiAgICAgICAgICAiRGVzY3JpcHRpb24iOiAiV2hpbGUgbWVhc3VyaW5nIGVhcnRoJ3MgbmF0dXJhbCBwaGVub21lbm9uIGxpa2UgcmVzaXN0aXZpdHkgYW5kIElQLCBtb3N0IG1ldGVyIGFyZSBzdWNjZXB0aWJsZSB0byBlYXJ0aCdzIG93biBlbGVjdHJpYyBhbmQgbWFnbmV0aWMgZmllbGQgdGhlIGJlY29tZXMgcGFydCBvZiB0aGUgc2lnbmFsIG1lYXN1cmVkLiBpU21hcnQgVGVycmFtZXRlciBjYXJyaWVzIGFuIGluYnVpbHQgaGlnaCBvcmRlciBmaWx0ZXIgdGhlIHJlbW92ZXMgc3VjaCBpbnRlcmZlcmVuY2UgYmVmb3JlIHRha2luZyBtZWFzdWVtZW50cy4iDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiRWxlY3Ryb2RlcyIsDQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogIk1ldGFsIHJvZHMgaW5zZXJ0ZWQgaW50byB0aGUgZ3JvdW5kIHRvIGluamVjdCBlbGVjdHJpY2FsIGN1cnJlbnQgYW5kIG1lYXN1cmUgdm9sdGFnZS4gRGVwZW5kaW5nIG9uIHRoZSBzdXJ2ZXksIHR3byBvciBmb3VyIGVsZWN0cm9kZXMgbWF5IGJlIHVzZWQiDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiQ2FibGVzIiwNCiAgICAgICAgICAiRGVzY3JpcHRpb24iOiAiQ29ubmVjdCB0aGUgY29udHJvbCB1bml0IHRvIHRoZSBlbGVjdHJvZGVzLCB0cmFuc21pdHRpbmcgY3VycmVudCBhbmQgY29sbGVjdGluZyB2b2x0YWdlIHNpZ25hbHMiDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiRGF0YSBTdG9yYWdlIiwNCiAgICAgICAgICAiRGVzY3JpcHRpb24iOiAiTWFueSBtb2Rlcm4gcmVzaXN0aXZpdHkgbWV0ZXJzIGNvbWUgd2l0aCBidWlsdC1pbiBtZW1vcnkgb3IgaW50ZXJmYWNlcyB0byBjb25uZWN0IHRvIGV4dGVybmFsIGRldmljZXMgZm9yIGRhdGEgbG9nZ2luZyBhbmQgYW5hbHlzaXMiDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiRGF0YSBHUFMgU3RhbXAiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJNZWFzdXJlZCBkYXRhIGFyZSBzdGFtcGVkIHdpdGggR1BTIGNvb3JkaW5hdGUgb24gdGhlIG1vYmlsZSBhcHAsIHNvIHlvdSBuZXZlciBmb3JnZXQgd2hlcmUgeW91IGFjcXVpcmUgYSBkYXRhIg0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIkRhdGEgVGltZSBTdGFtcCIsDQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogIk1lYXN1cmVkIGRhdGEgYXJlIHN0YW1wZWQgd2l0aCBjdXJyZW50IHRpbWUgb24gdGhlIG1vYmlsZSBhcHAsIHNvIHlvdSBuZXZlciBmb3JnZXQgd2hlbiB5b3UgYWNxdWlyZSBhIGRhdGEiDQogICAgICAgIH0NCiAgICAgIF0sDQogICAgICAiU3BlY2lmaWNhdGlvbnMiOiBbDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiU3VwcGx5IFZvbHRhZ2UiLA0KICAgICAgICAgICJWYWx1ZSI6ICIxMlYgREMiDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiSW5idWlsdCBCYXR0ZXJ5IiwNCiAgICAgICAgICAiVmFsdWUiOiAiWWVzIg0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIkNoYXJnZXIiLA0KICAgICAgICAgICJWYWx1ZSI6ICJZZXMiDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiRXh0ZXJuYWwgQmF0dGVyeSBjb25uZWN0aW9uIiwNCiAgICAgICAgICAiVmFsdWUiOiAiWWVzIg0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIkRpc3BsYXkiLA0KICAgICAgICAgICJWYWx1ZSI6ICJMQ0QiDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiTWV0aG9kcyIsDQogICAgICAgICAgIlZhbHVlIjogIlNlbGYgUG90ZW50aWFsLCBSZXNpc3Rpdml0eSwgSW5kdWNlZCBQb2xhcml6YXRpb24gYW5kIEVsZWN0cmljYWwgUmVzaXN0aXZpdHkgVG9tb2dyYXBoeSINCiAgICAgICAgfSwNCiAgICAgICAgew0KICAgICAgICAgICJUaXRsZSI6ICJQcmVjaXNpb24iLA0KICAgICAgICAgICJWYWx1ZSI6ICJWZXJ5IGhpZ2gsIHVwIHRvIDAuMSUiDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiQWNjdXJhY3kiLA0KICAgICAgICAgICJWYWx1ZSI6ICJWZXJ5IGhpZ2gsIHVwIHRvIDElIg0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIkFCIHByb2JlIGRyaXZlIHZvbHRhZ2UiLA0KICAgICAgICAgICJWYWx1ZSI6ICJ1cCB0byA1MDBWIg0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIkFCIGRyaXZlIGN1cnJlbnQiLA0KICAgICAgICAgICJWYWx1ZSI6ICJVcCB0byA1MDBtQSINCiAgICAgICAgfSwNCiAgICAgICAgew0KICAgICAgICAgICJUaXRsZSI6ICJNTiBzZW5zaXRpdml0eSIsDQogICAgICAgICAgIlZhbHVlIjogIkJldHRlciB0aGFuIDEwdVYiDQogICAgICAgIH0NCiAgICAgIF0sDQogICAgICAiVXNlQ2FzZXMiOiBbDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiR2VvdGVjaG5pY2FsIEVuZ2luZWVyaW5nIiwNCiAgICAgICAgICAiRGVzY3JpcHRpb24iOiAiRXZhbHVhdGVzIHNvaWwgcHJvcGVydGllcyBmb3IgY29uc3RydWN0aW9uIHByb2plY3RzIg0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIkVudmlyb25tZW50YWwgU3R1ZGllcyIsDQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogIkRldGVjdHMgY29udGFtaW5hdGlvbiwgd2F0ZXIgdGFibGVzLCBvciBidXJpZWQgb2JqZWN0cyINCiAgICAgICAgfSwNCiAgICAgICAgew0KICAgICAgICAgICJUaXRsZSI6ICJNaW5pbmcgYW5kIE1pbmVyYWwgRXhwbG9yYXRpb24iLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJJZGVudGlmaWVzIG9yZSBib2RpZXMgYW5kIG90aGVyIG1pbmVyYWwtcmljaCB6b25lcyINCiAgICAgICAgfSwNCiAgICAgICAgew0KICAgICAgICAgICJUaXRsZSI6ICJBcmNoYWVvbG9neSIsDQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogIk5vbi1pbnZhc2l2ZSBpbnZlc3RpZ2F0aW9ucyBvZiBzdWJzdXJmYWNlIGhpc3RvcmljYWwgc3RydWN0dXJlcyINCiAgICAgICAgfQ0KICAgICAgXSwNCiAgICAgICJWaWRlb3MiOiBbDQogICAgICAgIHsNCiAgICAgICAgICAiTGluayI6ICJodHRwczovL3d3dy55b3V0dWJlLmNvbS9lbWJlZC9NNWRpTUpESVJacyINCiAgICAgICAgfSwNCiAgICAgICAgew0KICAgICAgICAgICJMaW5rIjogIn4vaW1nL3NlcnZlci90ZXN0MS5tcDQiDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiTGluayI6ICJ\u002BL2ltZy9zZXJ2ZXIvdGVzdDIubXA0Ig0KICAgICAgICB9DQogICAgICBdLA0KICAgICAgIlZhcmlhbnRzIjogWw0KICAgICAgICB7DQogICAgICAgICAgIk5hbWUiOiAiTm8gYWNjZXNzb3JpZXMiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJUZXJyYW1ldGVyIGFsb25lLCBzdXBwbGllZCB3aXRoIG5vIGZpZWxkIGFjY2Vzc29yaWVzIg0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIk5hbWUiOiAiV2l0aCBpbmJ1aWx0IGJvb3N0ZXIoNTIwViwgNTAwbUEpLCBObyBhY2Nlc3NvcmllcyIsDQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogIkFuIGluYnVpbHQgYm9vc3RlciBtYWtlcyBpdCBwb3NzaWJsZSB0byBwcm9iZSBkZWVwZXIgd2l0aCA1MjBWIERDIHZvbHRhZ2UgYW5kIHVwIHRvIDUwMG1BIGN1cnJlbnQuIiwNCiAgICAgICAgICAiQWNjZXNzb3JpZXNJZCI6IFsgImluYnVpbHQtYm9vc3RlciIgXQ0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIk5hbWUiOiAiV2l0aCBBY2Nlc3NvcmllcyIsDQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogIkFjY2Vzc29yaWVzIGFzIDIgSGFtbWVycywgOCBFbGVjdHJvZGVzLCA0IFJlZWxzIHdpdGggY2FibGVzLCAyIG1lYXN1cmluZyB0YXBlcyBhcmUgc3VwcGxpZWQgd2l0aCB0aGUgbWV0ZXIiLA0KICAgICAgICAgICJBY2Nlc3Nvcmllc0lkIjogWyAiMi1oYW1tZXJzIiwgIjgtZWxlY3Ryb2RlcyIsICI0LXJlZWxzLWFuZC1jYWJsZXMiLCAiMi1tZWFzdXJpbmctdGFwZXMiIF0NCiAgICAgICAgfSwNCiAgICAgICAgew0KICAgICAgICAgICJOYW1lIjogIldpdGggSW5idWlsdCBCb29zdGVyKDUyMFYsIDUwMG1BKSBhbmQgQWNjZXNzb3JpZXMiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJBbiBpbmJ1aWx0IGJvb3N0ZXIgbWFrZXMgaXQgcG9zc2libGUgdG8gcHJvYmUgZGVlcGVyIHdpdGggNTIwViBEQyB2b2x0YWdlIGFuZCB1cCB0byA1MDBtQSBjdXJyZW50LlxyXG5BY2Nlc3NvcmllcyBhcyAyIEhhbW1lcnMsIDggRWxlY3Ryb2RlcywgNCBSZWVscyB3aXRoIGNhYmxlcywgMiBtZWFzdXJpbmcgdGFwZXMgYXJlIHN1cHBsaWVkIHdpdGggdGhlIG1ldGVyIiwNCiAgICAgICAgICAiQWNjZXNzb3JpZXNJZCI6IFsgImluYnVpbHQtYm9vc3RlciIsICIyLWhhbW1lcnMiLCAiOC1lbGVjdHJvZGVzIiwgIjQtcmVlbHMtYW5kLWNhYmxlcyIsICIyLW1lYXN1cmluZy10YXBlcyIgXQ0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIk5hbWUiOiAiV2l0aCBJUDY1IGVuY2xvc3VyZSwgTm8gYWNjZXNzb3JpZXMiLA0KICAgICAgICAgICJCYW5uZXJJbWFnZSI6ICJ\u002BL2ltZy9zZXJ2ZXIvdDkuanBnIiwNCiAgICAgICAgICAiQWNjZXNzb3JpZXNJZCI6IFsgImlwNjUtZW5jbG9zdXJlIiBdDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiTmFtZSI6ICJXaXRoIElQNjUgZW5jbG9zdXJlICsgSW5idWlsdCBCb29zdGVyKDUyMFYsIDUwMG1BKSwgTm8gYWNjZXNzb3JpZXMiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJBbiBpbmJ1aWx0IGJvb3N0ZXIgbWFrZXMgaXQgcG9zc2libGUgdG8gcHJvYmUgZGVlcGVyIHdpdGggNTIwViBEQyB2b2x0YWdlIGFuZCB1cCB0byA1MDBtQSBjdXJyZW50LiIsDQogICAgICAgICAgIkJhbm5lckltYWdlIjogIn4vaW1nL3NlcnZlci90OS5qcGciLA0KICAgICAgICAgICJBY2Nlc3Nvcmllc0lkIjogWyAiaXA2NS1lbmNsb3N1cmUiLCAiaW5idWlsdC1ib29zdGVyIiBdDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiTmFtZSI6ICJXaXRoIElQNjUgZW5jbG9zdXJlIGFuZCBBY2Nlc3NvcmllcyIsDQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogIkFjY2Vzc29yaWVzIGFzIDIgSGFtbWVycywgOCBFbGVjdHJvZGVzLCA0IFJlZWxzIHdpdGggY2FibGVzLCAyIG1lYXN1cmluZyB0YXBlcyBhcmUgc3VwcGxpZWQgd2l0aCB0aGUgbWV0ZXIiLA0KICAgICAgICAgICJCYW5uZXJJbWFnZSI6ICJ\u002BL2ltZy9zZXJ2ZXIvdDEuanBnIiwNCiAgICAgICAgICAiQWNjZXNzb3JpZXNJZCI6IFsgImlwNjUtZW5jbG9zdXJlIiwgIjItaGFtbWVycyIsICI4LWVsZWN0cm9kZXMiLCAiNC1yZWVscy1hbmQtY2FibGVzIiwgIjItbWVhc3VyaW5nLXRhcGVzIiBdDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiTmFtZSI6ICJXaXRoIElQNjUgZW5jbG9zdXJlICsgSW5idWlsdCBCb29zdGVyKDUyMFYsIDUwMG1BKSBhbmQgQWNjZXNzb3JpZXMiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJBbiBpbmJ1aWx0IGJvb3N0ZXIgbWFrZXMgaXQgcG9zc2libGUgdG8gcHJvYmUgZGVlcGVyIHdpdGggNTIwViBEQyB2b2x0YWdlIGFuZCB1cCB0byA1MDBtQSBjdXJyZW50LlxyXG5BY2Nlc3NvcmllcyBhcyAyIEhhbW1lcnMsIDggRWxlY3Ryb2RlcywgNCBSZWVscyB3aXRoIGNhYmxlcywgMiBtZWFzdXJpbmcgdGFwZXMgYXJlIHN1cHBsaWVkIHdpdGggdGhlIG1ldGVyIiwNCiAgICAgICAgICAiQmFubmVySW1hZ2UiOiAifi9pbWcvc2VydmVyL3QyLmpwZyIsDQogICAgICAgICAgIkFjY2Vzc29yaWVzSWQiOiBbICJpcDY1LWVuY2xvc3VyZSIsICJpbmJ1aWx0LWJvb3N0ZXIiLCAiMi1oYW1tZXJzIiwgIjgtZWxlY3Ryb2RlcyIsICI0LXJlZWxzLWFuZC1jYWJsZXMiLCAiMi1tZWFzdXJpbmctdGFwZXMiIF0NCiAgICAgICAgfQ0KICAgICAgXSwNCiAgICAgICJBY2Nlc3NvcmllcyI6IFsNCiAgICAgICAgew0KICAgICAgICAgICJOYW1lIjogIjIgdGVzdCBraXQiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJTb21ldGltZXMsIHlvdSBhcmUgaW5kb29yIGFuZCB5b3UganVzdCB3YW50IHRvIHF1aWNrbHkgdGVzdCB5b3VyIHRlcnJhbWV0ZXIgYW5kIG1ha2Ugc3VyZSBhbGwgaXMgd2VsbCB3aXRoIGl0LiBXZSBwcm92aWRlIG91IHdpdGggdHdvIHByZS1jYWxpYnJhdGVkIHRlc3QgcmVzaXN0b3IgbmV0d29yayB0aGF0IGNvbm5lY3RzIHRvIHlvdXIgbWV0ZXIuIFRoZSBtZXRlciBydW5zIGEgIG1lYXN1cmVtZW50IHVzaW5nIHRoZXNlIGtpdHMgYW5kIGlmIHRoZSByZXN1bHQgaXMgY2xvc2UgdG8gdGhlIGNhbGlicmF0ZWQgdmFsdWVzLCB5b3UgYXJlIGFzc3VyZWQgeW91ciB0ZXJyYW1ldGVyIGlzIGluIGdvb2QgY29uZGl0aW9uLiIsDQogICAgICAgICAgIkltYWdlcyI6IFsgIn4vaW1nL3NlcnZlci90ZXN0a2l0MS5qcGciIF0NCiAgICAgICAgfSwNCiAgICAgICAgew0KICAgICAgICAgICJOYW1lIjogIlNvbGFyIHBhbmVsIiwNCiAgICAgICAgICAiRGVzY3JpcHRpb24iOiAiTmV2ZXIgcnVuIG91dCBvZiBiYXR0ZXJ5IHdoaWxlIGRvaW5nIGEgZmllbGQgd29yayBhZ2Fpbi4gQ29ubmVjdCB0aGUgc3VwcGxpZWQgc29sYXIgcGFuZSB0byB5b3VyIG1ldGVyIGluIHRoZSBmaWVsZCBhbmQgY29udGludWUgbWVhc3VyaW5nIHRocm91Z2hvdXQgdGhlIGRheS4iLA0KICAgICAgICAgICJJbWFnZXMiOiBbICJ\u002BL2ltZy9zZXJ2ZXIvc29sYXIuanBnIiBdDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiTmFtZSI6ICIxNVYgYWRhcHRlciIsDQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogIktlZXAgdGhlIGluYnVpbHQgYmF0dGVyeSB0b3BwZWQgdXAgdXNpbmcgdGhlIHByb3ZpZGVkIGNoYXJnZXIgYmVmb3JlIGhlYWRpbmcgb3V0IHRvIGZpZWxkLiIsDQogICAgICAgICAgIkltYWdlcyI6IFsgIn4vaW1nL3NlcnZlci9jaGFyZ2VyLmpwZyIgXQ0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIk5hbWUiOiAiSW5idWlsdCBCb29zdGVyIiwNCiAgICAgICAgICAiRGVzY3JpcHRpb24iOiAiQW4gaW5idWlsdCBib29zdGVyIG1ha2VzIGl0IHBvc3NpYmxlIHRvIHByb2JlIGRlZXBlciB3aXRoIDUyMFYgREMgdm9sdGFnZSBhbmQgdXAgdG8gNTAwbUEgY3VycmVudC4iLA0KICAgICAgICAgICJTS1UiOiAiaW5idWlsdC1ib29zdGVyIiwNCiAgICAgICAgICAiSW1hZ2VzIjogWyAifi9pbWcvc2VydmVyL2Jvb3N0ZXIuanBnIiBdLA0KICAgICAgICAgICJDb3N0Ijogew0KICAgICAgICAgICAgIlVuaXQiOiAiTmFpcmEiLA0KICAgICAgICAgICAgIlZhbHVlIjogMTQwMDAwDQogICAgICAgICAgfQ0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIk5hbWUiOiAiSVA2NSBFbmNsb3N1cmUiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJBbiBpbmJ1aWx0IGJvb3N0ZXIgbWFrZXMgaXQgcG9zc2libGUgdG8gcHJvYmUgZGVlcGVyIHdpdGggNTIwViBEQyB2b2x0YWdlIGFuZCB1cCB0byA1MDBtQSBjdXJyZW50LiIsDQogICAgICAgICAgIkltYWdlcyI6IFsgIn4vaW1nL3NlcnZlci9pcDY1LmpwZyIgXSwNCiAgICAgICAgICAiU0tVIjogImlwNjUtZW5jbG9zdXJlIiwNCiAgICAgICAgICAiQ29zdCI6IHsNCiAgICAgICAgICAgICJVbml0IjogIk5haXJhIiwNCiAgICAgICAgICAgICJWYWx1ZSI6IDQxMDAwMA0KICAgICAgICAgIH0NCiAgICAgICAgfSwNCiAgICAgICAgew0KICAgICAgICAgICJOYW1lIjogIjIgaGFtbWVycyIsDQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogIkZvciBidXJ5aW5nIGVsZWN0cm9kZXMgaW4gZmllbGQuIiwNCiAgICAgICAgICAiSW1hZ2VzIjogWyAifi9pbWcvc2VydmVyL2hhbW1lci5qcGciIF0sDQogICAgICAgICAgIlNLVSI6ICIyLWhhbW1lcnMiLA0KICAgICAgICAgICJDb3N0Ijogew0KICAgICAgICAgICAgIlVuaXQiOiAiTmFpcmEiLA0KICAgICAgICAgICAgIlZhbHVlIjogMzIwMDANCiAgICAgICAgICB9DQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiTmFtZSI6ICI4IGVsZWN0cm9kZXMiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJBQk1OIHRlcm1pbmFsIG1lYXN1cmVtZW50IGVsZWN0b2Rlcy4iLA0KICAgICAgICAgICJJbWFnZXMiOiBbICJ\u002BL2ltZy9zZXJ2ZXIvZWxlY3Ryb2RlLmpwZyIgXSwNCiAgICAgICAgICAiU0tVIjogIjgtZWxlY3Ryb2RlcyIsDQogICAgICAgICAgIkNvc3QiOiB7DQogICAgICAgICAgICAiVW5pdCI6ICJOYWlyYSIsDQogICAgICAgICAgICAiVmFsdWUiOiA2NDAwMA0KICAgICAgICAgIH0NCiAgICAgICAgfSwNCiAgICAgICAgew0KICAgICAgICAgICJOYW1lIjogIjQgcmVlbHMgYW5kIGNhYmxlcyIsDQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogIkFCTU4gY2FibGVzIGZyb20gbWV0ZXIgdG8gZWxlY3RvZGVzLiBBIGFuZCBCID0gMjAwbSBNIGFuZCBOID0gNTBtIiwNCiAgICAgICAgICAiSW1hZ2VzIjogWyAifi9pbWcvc2VydmVyL3JlZWwuanBnIiBdLA0KICAgICAgICAgICJTS1UiOiAiNC1yZWVscy1hbmQtY2FibGVzIiwNCiAgICAgICAgICAiQ29zdCI6IHsNCiAgICAgICAgICAgICJVbml0IjogIk5haXJhIiwNCiAgICAgICAgICAgICJWYWx1ZSI6IDYxMDAwMA0KICAgICAgICAgIH0NCiAgICAgICAgfSwNCiAgICAgICAgew0KICAgICAgICAgICJOYW1lIjogIjIgbWVhc3VyaW5nIHRhcGUiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJNZWFzdXJlIHByZWNpc2VseSBlbGVjdG9kZSBzcGFjaW5ncyBkdXJpbmcgbWVhc3VybWVudHMuIiwNCiAgICAgICAgICAiSW1hZ2VzIjogWyAifi9pbWcvc2VydmVyL3RhcGUuanBnIiBdLA0KICAgICAgICAgICJTS1UiOiAiMi1tZWFzdXJpbmctdGFwZXMiLA0KICAgICAgICAgICJDb3N0Ijogew0KICAgICAgICAgICAgIlVuaXQiOiAiTmFpcmEiLA0KICAgICAgICAgICAgIlZhbHVlIjogNjAwMDANCiAgICAgICAgICB9DQogICAgICAgIH0NCiAgICAgIF0NCiAgICB9DQogIH0NCn0="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1231460)
        $asm.$cls(`$fsgt.LCIDTMC.TerrameterMeasurementTimeCustomAttributesProvider`, ($self) => class TerrameterMeasurementTimeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296198756)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296198756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296198756)
            
            static $h = 1231460;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296198756),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1231460,
      "h": 4296198756,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296198756)
  ],
  "h": 1231460
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasurementTimeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterMeasurementTimeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1231460)
        
        

        //--TRIMMABLE-BOUNDARY-START(1362532)
        $asm.$cls(`$fsgt.LCIDTMC.TerrameterMeasureResultCustomAttributesProvider`, ($self) => class TerrameterMeasureResultCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296329828)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296329828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296329828)
            
            static $h = 1362532;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296329828),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1362532,
      "h": 4296329828,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296329828)
  ],
  "h": 1362532
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureResultCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterMeasureResultCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1362532)
        
        

        //--TRIMMABLE-BOUNDARY-START(2280036)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class TerrameterDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297247332)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297247332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$$($.$fsgt.LCIDTMS.TerrameterStatusModel, $.$fsgt.LCIDTM.TerrameterLogModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297247332)
            
            static $h = 2280036;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297247332),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2280036,
      "h": 4297247332,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297247332)
  ],
  "h": 2280036
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2280036)
        
        

        //--TRIMMABLE-BOUNDARY-START(3066468)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterLogModelCustomAttributesProvider`, ($self) => class TerrameterLogModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298033764)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298033764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceLogModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298033764)
            
            static $h = 3066468;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298033764),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3066468,
      "h": 4298033764,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298033764)
  ],
  "h": 3066468
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterLogModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterLogModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3066468)
        
        

        //--TRIMMABLE-BOUNDARY-START(445028)
        $asm.$cls(`$fsgt.LCIDT.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295412324)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295412324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295412324)
            
            static $h = 445028;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295412324),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 445028,
      "h": 4295412324,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295412324)
  ],
  "h": 445028
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(445028)
        
        

        //--TRIMMABLE-BOUNDARY-START(2542180)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterDeviceScopeModelCustomAttributesProvider`, ($self) => class TerrameterDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297509476)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297509476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297509476)
            
            static $h = 2542180;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297509476),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2542180,
      "h": 4297509476,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297509476)
  ],
  "h": 2542180
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2542180)
        
        

        //--TRIMMABLE-BOUNDARY-START(3328612)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterMeasureModeCustomAttributesProvider`, ($self) => class TerrameterMeasureModeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298295908)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298295908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298295908)
            
            static $h = 3328612;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298295908),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3328612,
      "h": 4298295908,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298295908)
  ],
  "h": 3328612
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterMeasureModeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterMeasureModeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3328612)
        
        

        //--TRIMMABLE-BOUNDARY-START(4967012)
        $asm.$cls(`$fsgt.LCIDT.TerrameterDeviceModelCustomAttributesProvider`, ($self) => class TerrameterDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299934308)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299934308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299934308)
            
            static $h = 4967012;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299934308),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4967012,
      "h": 4299934308,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299934308)
  ],
  "h": 4967012
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}TerrameterDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4967012)
        
        

        //--TRIMMABLE-BOUNDARY-START(248420)
        $asm.$cls(`$fsgt.LCIDT._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295215716)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295215716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$fsgt.LCIDT.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295215716)
            
            static $h = 248420;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295215716),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 248420,
      "h": 4295215716,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295215716)
  ],
  "h": 248420
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(248420)
        
        

        //--TRIMMABLE-BOUNDARY-START(379492)
        $asm.$cls(`$fsgt.LCIDT.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295346788)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295346788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fsgt.LCIDTMC.TerrameterErrorChecks.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fsgt.LCIDTMC.TerrameterErrorChecksCustomAttributesProvider, $.$fsgt.LCIDTMC.TerrameterErrorChecksCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fsgt.LCIDTMC.TerrameterMeasureCommandModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelCustomAttributesProvider, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fsgt.LCIDTMC.TerrameterMeasurementCurrent.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fsgt.LCIDTMC.TerrameterMeasurementCurrentCustomAttributesProvider, $.$fsgt.LCIDTMC.TerrameterMeasurementCurrentCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fsgt.LCIDTMC.TerrameterMeasurementTime.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fsgt.LCIDTMC.TerrameterMeasurementTimeCustomAttributesProvider, $.$fsgt.LCIDTMC.TerrameterMeasurementTimeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fsgt.LCIDTMC.TerrameterMeasureResult.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureResultCustomAttributesProvider, $.$fsgt.LCIDTMC.TerrameterMeasureResultCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fsgt.LCIDTMC.TerrameterUnlockCommandModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fsgt.LCIDTMC.TerrameterUnlockCommandModelCustomAttributesProvider, $.$fsgt.LCIDTMC.TerrameterUnlockCommandModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fsgt.LCIDTMS.TerrameterStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fsgt.LCIDTMS.TerrameterStatusModelCustomAttributesProvider, $.$fsgt.LCIDTMS.TerrameterStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModelCustomAttributesProvider, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fsgt.LCIDTM.TerrameterDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fsgt.LCIDTM.TerrameterDeviceScopeModelCustomAttributesProvider, $.$fsgt.LCIDTM.TerrameterDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fsgt.LCIDTM.TerrameterDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fsgt.LCIDTM.TerrameterDeviceSendDataModelCustomAttributesProvider, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fsgt.LCIDTM.TerrameterLogModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fsgt.LCIDTM.TerrameterLogModelCustomAttributesProvider, $.$fsgt.LCIDTM.TerrameterLogModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fsgt.LCIDTM.TerrameterMeasureMode.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fsgt.LCIDTM.TerrameterMeasureModeCustomAttributesProvider, $.$fsgt.LCIDTM.TerrameterMeasureModeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fsgt.LCIDTM.TerrameterServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fsgt.LCIDTM.TerrameterServiceModelCustomAttributesProvider, $.$fsgt.LCIDTM.TerrameterServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettingsCustomAttributesProvider, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fsgt.LCIDTS$1.TerrameterDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fsgt.LCIDTS$1.TerrameterDeviceSettingsCustomAttributesProvider, $.$fsgt.LCIDTS$1.TerrameterDeviceSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$fsgt.LCIDT.TerrameterDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$fsgt.LCIDT.TerrameterDeviceModelCustomAttributesProvider, $.$fsgt.LCIDT.TerrameterDeviceModelCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295346788)
            
            static $h = 379492;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295346788),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 379492,
      "h": 4295346788,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295346788)
  ],
  "h": 379492
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(379492)
        
        

        //--TRIMMABLE-BOUNDARY-START(2804324)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterDeviceSendDataModelCustomAttributesProvider`, ($self) => class TerrameterDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297771620)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297771620)
            
            //--TRIMMABLE-BOUNDARY-START(8592738916)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592738916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$fsgt.LCIDTM.TerrameterDeviceSendDataModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Measure", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (13432);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$fsgt.LCIDTM.TerrameterDeviceSendDataModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $urmbIf ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2804324,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $RwQnYb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2804324,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandsModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592738916)
            
            static $h = 2804324;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592738916),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2804324,
      "h": 8592738916,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592738916)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297771620),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2804324,
      "h": 4297771620,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297771620)
  ],
  "h": 2804324
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2804324)
        
        

        //--TRIMMABLE-BOUNDARY-START(1559140)
        $asm.$cls(`$fsgt.LCIDTMC.TerrameterUnlockCommandModelCustomAttributesProvider`, ($self) => class TerrameterUnlockCommandModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296526436)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296526436)
            
            //--TRIMMABLE-BOUNDARY-START(8591493732)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591493732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$fsgt.LCIDTMC.TerrameterUnlockCommandModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Times", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (256);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$fsgt.LCIDTMC.TerrameterUnlockCommandModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $XHhdIk ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1559140,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $yTbskb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1559140,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591493732)
            
            static $h = 1559140;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591493732),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1559140,
      "h": 8591493732,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591493732)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296526436),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1559140,
      "h": 4296526436,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296526436)
  ],
  "h": 1559140
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterUnlockCommandModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterUnlockCommandModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1559140)
        
        

        //--TRIMMABLE-BOUNDARY-START(1100388)
        $asm.$cls(`$fsgt.LCIDTMC.TerrameterMeasurementCurrentCustomAttributesProvider`, ($self) => class TerrameterMeasurementCurrentCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296067684)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296067684)
            
            //--TRIMMABLE-BOUNDARY-START(8591034980)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591034980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$fsgt.LCIDTMC.TerrameterMeasurementCurrentCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(10, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("_500uA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Title = "500uA";
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("_1mA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Title = "1mA";
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("_2mA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Title = "2mA";
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("_5mA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Title = "5mA";
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("_10mA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Title = "10mA";
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("_20mA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Title = "20mA";
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("_50mA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Title = "50mA";
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("_100mA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Title = "100mA";
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("_200mA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Title = "200mA";
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("_500mA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t12 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$4();
                            $i12.Title = "500mA";
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$fsgt.LCIDTMC.TerrameterMeasurementCurrentCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $SRmAGk ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1100388,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $aCSawd ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1100388,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591034980)
            
            static $h = 1100388;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591034980),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1100388,
      "h": 8591034980,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591034980)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296067684),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1100388,
      "h": 4296067684,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296067684)
  ],
  "h": 1100388
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasurementCurrentCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterMeasurementCurrentCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1100388)
        
        

        //--TRIMMABLE-BOUNDARY-START(838244)
        $asm.$cls(`$fsgt.LCIDTMC.TerrameterMeasureCommandModelCustomAttributesProvider`, ($self) => class TerrameterMeasureCommandModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295805540)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295805540)
            
            //--TRIMMABLE-BOUNDARY-START(8590772836)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590772836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$fsgt.LCIDTMC.TerrameterMeasureCommandModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(8, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Mode", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (256);
                            $i3.ConvertType = ($.$$.S.Byte.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("MeasurementTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (257);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Cycles", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (258);
                            $i5.ConvertType = ($.$$.S.Byte.$type);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Current", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (259);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("HighVoltage", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (260);
                            $i7.ConvertType = ($.$$.S.UInt16.$type);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CheckErrors", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Order = (261);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ErtSpacings1", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Order = (261);
                            $i9.ConvertType = ($.$$.S.Byte.$type);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ErtSpacings2", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Order = (262);
                            $i10.ConvertType = ($.$$.S.Byte.$type);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$fsgt.LCIDTMC.TerrameterMeasureCommandModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $hSXPxi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":838244,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $aDCOAk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":838244,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590772836)
            
            static $h = 838244;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590772836),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 838244,
      "h": 8590772836,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590772836)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295805540),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 838244,
      "h": 4295805540,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295805540)
  ],
  "h": 838244
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterMeasureCommandModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(838244)
        
        

        //--TRIMMABLE-BOUNDARY-START(5163620)
        $asm.$cls(`$fsgt.LCIDT.TerrameterDeviceModelTypeDescriptorBuilder`, ($self) => class TerrameterDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595098212)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595098212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$fsgt.LCIDT.TerrameterDeviceModelTypeDescriptor()
                        const $t1 = $.$fsgt.LCIDT.TerrameterDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ihHXth ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5163620,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$fsgt.LCIDT.TerrameterDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595098212)
            
            //--TRIMMABLE-BOUNDARY-START(4300130916)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300130916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300130916)
            
            //--TRIMMABLE-BOUNDARY-START(4300130916)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300130916)
            
            static $h = 5163620;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595098212),
    {
      "r": 65537,
      "n": "Register",
      "d": 5163620,
      "h": 8595098212,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595098212)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300130916),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5163620,
      "h": 4300130916,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300130916)
  ],
  "h": 5163620
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}TerrameterDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5163620)
        
        

        //--TRIMMABLE-BOUNDARY-START(2673252)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterDeviceScopeModelTypeDescriptorBuilder`, ($self) => class TerrameterDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592607844)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592607844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$fsgt.LCIDTM.TerrameterDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$fsgt.LCIDTM.TerrameterDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $wSsdIf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2673252,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$fsgt.LCIDTM.TerrameterDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592607844)
            
            //--TRIMMABLE-BOUNDARY-START(4297640548)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297640548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297640548)
            
            //--TRIMMABLE-BOUNDARY-START(4297640548)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297640548)
            
            static $h = 2673252;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592607844),
    {
      "r": 65537,
      "n": "Register",
      "d": 2673252,
      "h": 8592607844,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592607844)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297640548),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2673252,
      "h": 4297640548,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297640548)
  ],
  "h": 2673252
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2673252)
        
        

        //--TRIMMABLE-BOUNDARY-START(4180580)
        $asm.$cls(`$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class TerrameterDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299147876)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299147876)
            
            //--TRIMMABLE-BOUNDARY-START(8594115172)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594115172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Sample", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Key = "rem";
                            $i3.Order = (20);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $fCerxc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4180580,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $VzjoJk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4180580,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594115172)
            
            static $h = 4180580;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594115172),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4180580,
      "h": 8594115172,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594115172)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299147876),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4180580,
      "h": 4299147876,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299147876)
  ],
  "h": 4180580
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Settings${separator}TerrameterDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4180580)
        
        

        //--TRIMMABLE-BOUNDARY-START(2935396)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class TerrameterDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592869988)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592869988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$fsgt.LCIDTM.TerrameterDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$fsgt.LCIDTM.TerrameterDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $HxJsnb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2935396,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$fsgt.LCIDTM.TerrameterDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592869988)
            
            //--TRIMMABLE-BOUNDARY-START(4297902692)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297902692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297902692)
            
            //--TRIMMABLE-BOUNDARY-START(4297902692)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297902692)
            
            static $h = 2935396;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592869988),
    {
      "r": 65537,
      "n": "Register",
      "d": 2935396,
      "h": 8592869988,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592869988)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297902692),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2935396,
      "h": 4297902692,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297902692)
  ],
  "h": 2935396
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2935396)
        
        

        //--TRIMMABLE-BOUNDARY-START(641636)
        $asm.$cls(`$fsgt.LCIDTMC.TerrameterErrorChecksCustomAttributesProvider`, ($self) => class TerrameterErrorChecksCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295608932)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295608932)
            
            //--TRIMMABLE-BOUNDARY-START(8590576228)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590576228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$fsgt.LCIDTMC.TerrameterErrorChecksCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(2);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t4 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i4 = new $t4();
                        $i4.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i4.set_Item("All", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i4;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$fsgt.LCIDTMC.TerrameterErrorChecksCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $grPFYd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":641636,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $OxdYxg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":641636,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590576228)
            
            static $h = 641636;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590576228),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 641636,
      "h": 8590576228,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590576228)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295608932),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 641636,
      "h": 4295608932,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295608932)
  ],
  "h": 641636
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterErrorChecksCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterErrorChecksCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(641636)
        
        

        //--TRIMMABLE-BOUNDARY-START(3721828)
        $asm.$cls(`$fsgt.LCIDT.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593656420)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593656420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$fsgt.LCIDTV.TerrameterUnlock, "LivingThing.Core.IOT.Devices.Terrameter", "Views\\TerrameterUnlock", "Terrameter Unlock", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/TMv402Unlock" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8593656420)
            
            //--TRIMMABLE-BOUNDARY-START(4298689124)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298689124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298689124)
            
            //--TRIMMABLE-BOUNDARY-START(4298689124)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298689124)
            
            static $h = 3721828;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593656420),
    {
      "r": 65537,
      "n": "Build",
      "d": 3721828,
      "h": 8593656420,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8593656420)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298689124),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3721828,
      "h": 4298689124,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298689124)
  ],
  "h": 3721828
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3721828)
        
        

        //--TRIMMABLE-BOUNDARY-START(4311652)
        $asm.$cls(`$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class TerrameterDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594246244)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594246244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $SXIlNe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4311652,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594246244)
            
            //--TRIMMABLE-BOUNDARY-START(4299278948)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299278948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299278948)
            
            //--TRIMMABLE-BOUNDARY-START(4299278948)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299278948)
            
            static $h = 4311652;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594246244),
    {
      "r": 65537,
      "n": "Register",
      "d": 4311652,
      "h": 8594246244,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594246244)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299278948),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4311652,
      "h": 4299278948,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299278948)
  ],
  "h": 4311652
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Settings${separator}TerrameterDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4311652)
        
        

        //--TRIMMABLE-BOUNDARY-START(3590756)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterServiceModelTypeDescriptorBuilder`, ($self) => class TerrameterServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593525348)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593525348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$fsgt.LCIDTM.TerrameterServiceModelTypeDescriptor()
                        const $t1 = $.$fsgt.LCIDTM.TerrameterServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $gsbYRg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3590756,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$fsgt.LCIDTM.TerrameterServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593525348)
            
            //--TRIMMABLE-BOUNDARY-START(4298558052)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298558052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298558052)
            
            //--TRIMMABLE-BOUNDARY-START(4298558052)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298558052)
            
            static $h = 3590756;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593525348),
    {
      "r": 65537,
      "n": "Register",
      "d": 3590756,
      "h": 8593525348,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593525348)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298558052),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3590756,
      "h": 4298558052,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298558052)
  ],
  "h": 3590756
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3590756)
        
        

        //--TRIMMABLE-BOUNDARY-START(2017892)
        $asm.$cls(`$fsgt.LCIDTMS.TerrameterStatusModelCustomAttributesProvider`, ($self) => class TerrameterStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296985188)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296985188)
            
            //--TRIMMABLE-BOUNDARY-START(8591952484)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591952484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$fsgt.LCIDTMS.TerrameterStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(6, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Token", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("BatteryVoltage", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.ConvertType = ($.$$.S.Single.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ChargerVoltage", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3);
                            $i5.ConvertType = ($.$$.S.Single.$type);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("MNVoltage", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (4);
                            $i6.Exclude = $.$cast((16776831), $.$fPer.LCFCA$1.SchemaType);
                            $i6.ConvertType = ($.$$.S.Single.$type);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ABCurrent", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (5);
                            $i7.ConvertType = ($.$$.S.Single.$type);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("MeasurementData", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Order = (6);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$fsgt.LCIDTMS.TerrameterStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $QqRLPd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2017892,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $bEJojl ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2017892,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591952484)
            
            static $h = 2017892;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591952484),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2017892,
      "h": 8591952484,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591952484)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296985188),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2017892,
      "h": 4296985188,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296985188)
  ],
  "h": 2017892
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Statuses${separator}TerrameterStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2017892)
        
        

        //--TRIMMABLE-BOUNDARY-START(1690212)
        $asm.$cls(`$fsgt.LCIDTMC.TerrameterUnlockCommandModelTypeDescriptorBuilder`, ($self) => class TerrameterUnlockCommandModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591624804)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591624804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$fsgt.LCIDTMC.TerrameterUnlockCommandModelTypeDescriptor()
                        const $t1 = $.$fsgt.LCIDTMC.TerrameterUnlockCommandModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterUnlockCommandModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $imfxGd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1690212,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$fsgt.LCIDTMC.TerrameterUnlockCommandModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591624804)
            
            //--TRIMMABLE-BOUNDARY-START(4296657508)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296657508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296657508)
            
            //--TRIMMABLE-BOUNDARY-START(4296657508)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296657508)
            
            static $h = 1690212;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591624804),
    {
      "r": 65537,
      "n": "Register",
      "d": 1690212,
      "h": 8591624804,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591624804)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296657508),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1690212,
      "h": 4296657508,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296657508)
  ],
  "h": 1690212
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterUnlockCommandModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterUnlockCommandModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1690212)
        
        

        //--TRIMMABLE-BOUNDARY-START(2411108)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class TerrameterDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592345700)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592345700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $uQVcRj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2411108,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592345700)
            
            //--TRIMMABLE-BOUNDARY-START(4297378404)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297378404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297378404)
            
            //--TRIMMABLE-BOUNDARY-START(4297378404)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297378404)
            
            static $h = 2411108;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592345700),
    {
      "r": 65537,
      "n": "Register",
      "d": 2411108,
      "h": 8592345700,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592345700)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297378404),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2411108,
      "h": 4297378404,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297378404)
  ],
  "h": 2411108
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2411108)
        
        

        //--TRIMMABLE-BOUNDARY-START(969316)
        $asm.$cls(`$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptorBuilder`, ($self) => class TerrameterMeasureCommandModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590903908)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590903908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor()
                        const $t1 = $.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $iNaWcd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":969316,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$fsgt.LCIDTMC.TerrameterMeasureCommandModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590903908)
            
            //--TRIMMABLE-BOUNDARY-START(4295936612)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295936612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295936612)
            
            //--TRIMMABLE-BOUNDARY-START(4295936612)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295936612)
            
            static $h = 969316;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590903908),
    {
      "r": 65537,
      "n": "Register",
      "d": 969316,
      "h": 8590903908,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590903908)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295936612),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 969316,
      "h": 4295936612,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295936612)
  ],
  "h": 969316
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterMeasureCommandModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(969316)
        
        

        //--TRIMMABLE-BOUNDARY-START(5229156)
        $asm.$cls(`$fsgt.LCIDT.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4300196452)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300196452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptorBuilder.Register();
                $.$fsgt.LCIDTMC.TerrameterUnlockCommandModelTypeDescriptorBuilder.Register();
                $.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptorBuilder.Register();
                $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$fsgt.LCIDTM.TerrameterDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$fsgt.LCIDTM.TerrameterDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$fsgt.LCIDTM.TerrameterLogModelTypeDescriptorBuilder.Register();
                $.$fsgt.LCIDTM.TerrameterServiceModelTypeDescriptorBuilder.Register();
                $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$fsgt.LCIDTS$1.TerrameterDeviceSettingsTypeDescriptorBuilder.Register();
                $.$fsgt.LCIDT.TerrameterDeviceModelTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4300196452)
            
            static $h = 5229156;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300196452),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 5229156,
      "h": 4300196452,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4300196452)
  ],
  "h": 5229156
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5229156)
        
        

        //--TRIMMABLE-BOUNDARY-START(3787364)
        $asm.$cls(`$fsgt.LCIDT.SecureTokenManager`, ($self) => class SecureTokenManager
        {
            //--TRIMMABLE-BOUNDARY-START(8593721956)
            /*string*/ static Alphabet = null;
            //--TRIMMABLE-BOUNDARY-END(8593721956)
            
            //--TRIMMABLE-BOUNDARY-START(12888689252)
            /*int*/ static Base = 0;
            //--TRIMMABLE-BOUNDARY-END(12888689252)
            
            //--TRIMMABLE-BOUNDARY-START(38658493028)
            /*byte[]*/ static SecretKey = null;
            //--TRIMMABLE-BOUNDARY-END(38658493028)
            
            //--TRIMMABLE-BOUNDARY-START(42953460324)
            /*int*/ static SignatureLength = 4;
            //--TRIMMABLE-BOUNDARY-END(42953460324)
            
            //--TRIMMABLE-BOUNDARY-START(34363525732)
            /*char*/ static PayloadSeparator = /*-*/ 45;
            //--TRIMMABLE-BOUNDARY-END(34363525732)
            
            //--TRIMMABLE-BOUNDARY-START(30068558436)
            static /*string */ GenerateUnlockToken(/*long*/ usageCount, /*string*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068558436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(seed))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13("Seed cannot be null or empty.", "seed");
                }
                /*long*/ let currentUnixTime = $.$$.S.DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                /*string*/ let countStr = $.$fsgt.LCIDT.SecureTokenManager.Base62Encode(usageCount);
                /*string*/ let timeStr = $.$fsgt.LCIDT.SecureTokenManager.Base62Encode(currentUnixTime);
                /*string*/ let payloadStr = `${$.$strNN(countStr)}${$.$strNN($.$$.S.Char.ToString.call(/*-*/ 45))}${$.$strNN(timeStr)}`;
                /*string*/ let signature = $.$fsgt.LCIDT.SecureTokenManager.GenerateSignature(payloadStr, seed);
                return $.$strNN(payloadStr) + $.$strNN(signature);
            }
            //--TRIMMABLE-BOUNDARY-END(30068558436)
            
            //--TRIMMABLE-BOUNDARY-START(47248427620)
            static /*bool */ TryVerifyAndDecodeToken(/*string*/ token, /*string*/ seed, /*long*/ maxValiditySeconds, /*out long*/ usageCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47248427620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                usageCount.$v = 0n;
                if ($.$$.S.String.IsNullOrEmpty(token) || token.length <= 4/*SignatureLength*/ || $.$$.S.String.IsNullOrEmpty(seed) || maxValiditySeconds <= 0n)
                {
                    return false;
                }
                /*string*/ let payloadStr = $.$$.S.String.Substring.call(token, 0, ((token.length - 4/*SignatureLength*/) | 0));
                /*string*/ let providedSignature = $.$$.S.String.Substring$1.call(token, ((token.length - 4/*SignatureLength*/) | 0));
                /*string*/ let expectedSignature = $.$fsgt.LCIDT.SecureTokenManager.GenerateSignature(payloadStr, seed);
                if (!$.$sscr.SSC.CryptographicOperations.FixedTimeEquals($.$$.S.ReadOnlySpan$$($.$$.S.Byte).op_Implicit$1($.$$.ST.Encoding.UTF8.GetBytes$8(providedSignature)), $.$$.S.ReadOnlySpan$$($.$$.S.Byte).op_Implicit$1($.$$.ST.Encoding.UTF8.GetBytes$8(expectedSignature))))
                {
                    return false;
                }
                /*string[]*/ let parts = $.$$.S.String.Split$1.call(payloadStr, /*-*/ 45, 0);
                if (parts.length !== 2)
                {
                    return false;
                }
                try
                {
                    usageCount.$v = $.$fsgt.LCIDT.SecureTokenManager.Base62Decode($.$$.System.Array.$ReadT1.call(parts, 0));
                    /*long*/ let tokenUnixTime = $.$fsgt.LCIDT.SecureTokenManager.Base62Decode($.$$.System.Array.$ReadT1.call(parts, 1));
                    /*long*/ let currentUnixTime = $.$$.S.DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                    /*long*/ let tokenAgeSeconds = BigInt.asIntN(64, currentUnixTime - tokenUnixTime);
                    if (tokenAgeSeconds > maxValiditySeconds || tokenAgeSeconds < BigInt(-10))
                    {
                        return false;
                    }
                    return true;
                }
                catch($e)
                {
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47248427620)
            
            //--TRIMMABLE-BOUNDARY-START(25773591140)
            static /*string */ GenerateSignature(/*string*/ input, /*string*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773591140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let hmac = null;
                try
                {
                    hmac = new $.$sscr.SSC.HMACSHA256().$ctor$5($.$fsgt.LCIDT.SecureTokenManager.SecretKey);
                    /*string*/ let combinedInput = $.$strNN($.$strNN(input) + "|") + $.$strNN(seed);
                    /*byte[]*/ let hashBytes = hmac.ComputeHash$1($.$$.ST.Encoding.UTF8.GetBytes$8(combinedInput));
                    /*long*/ let numericHashPiece = $.$$.S.Math.Abs$4($.$$.S.BitConverter.ToInt64(hashBytes, 0));
                    /*string*/ let fullSig = $.$fsgt.LCIDT.SecureTokenManager.Base62Encode(numericHashPiece);
                    if (fullSig.length < 4/*SignatureLength*/)
                    {
                        fullSig = $.$$.S.String.PadLeft.call(fullSig, 4/*SignatureLength*/, /*0*/ 48);
                    }
                    return $.$$.S.String.Substring.call(fullSig, 0, 4/*SignatureLength*/);
                }
                finally
                {
                    hmac?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25773591140)
            
            //--TRIMMABLE-BOUNDARY-START(21478623844)
            static /*string */ Base62Encode(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478623844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === 0n)
                {
                    return $.$$.S.Char.ToString.call($.$$.S.String.get_Chars.call("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"/*Alphabet*/, 0));
                }
                /*var*/ let builder = new $.$$.ST.StringBuilder().$ctor$1();
                while(value > 0n)
                {
                    builder.Insert$3(0, $.$$.S.String.get_Chars.call("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"/*Alphabet*/, $.$cast((value % BigInt($.$fsgt.LCIDT.SecureTokenManager.Base)), $.$$.S.Int32)));
                    value /= BigInt($.$fsgt.LCIDT.SecureTokenManager.Base);
                }
                return builder.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(21478623844)
            
            //--TRIMMABLE-BOUNDARY-START(17183656548)
            static /*long */ Base62Decode(/*string*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183656548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let num = 0n;
                let $en1 = $.$$.S.String.GetEnumerator.call(token);
                while ($en1.MoveNext())
                {
                    let c = $en1.Current;
                    {
                        /*int*/ let index = $.$$.S.String.IndexOf$3.call("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"/*Alphabet*/, c);
                        if (index === -1)
                        {
                            throw new $.$$.S.ArgumentException().$ctor$9();
                        }
                        num = BigInt.asIntN(64, (BigInt.asIntN(64, num * BigInt($.$fsgt.LCIDT.SecureTokenManager.Base))) + BigInt(index));
                    }
                }
                return num;
            }
            //--TRIMMABLE-BOUNDARY-END(17183656548)
            
            //--TRIMMABLE-BOUNDARY-START(4298754660)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298754660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8593721956)
                    this.Alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
                    //--TRIMMABLE-BOUNDARY-END(8593721956)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12888689252)
                    this.Base = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"/*Alphabet*/.length;
                    //--TRIMMABLE-BOUNDARY-END(12888689252)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38658493028)
                    this.SecretKey = $.$$.ST.Encoding.UTF8.GetBytes$8("YourSuperSecretKeyForSigningTokens123!");
                    //--TRIMMABLE-BOUNDARY-END(38658493028)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298754660)
            
            static $h = 3787364;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(30068558436),
    {
      "r": 1310721,
      "p": [
        {
          "n": "usageCount",
          "p": 917505
        },
        {
          "n": "seed",
          "p": 1310721
        }
      ],
      "n": "GenerateUnlockToken",
      "d": 3787364,
      "h": 30068558436,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30068558436),
//--TRIMMABLE-BOUNDARY-START(47248427620),
    {
      "r": 262145,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "seed",
          "p": 1310721
        },
        {
          "n": "maxValiditySeconds",
          "p": 917505
        },
        {
          "n": "usageCount",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "TryVerifyAndDecodeToken",
      "d": 3787364,
      "h": 47248427620,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47248427620),
//--TRIMMABLE-BOUNDARY-START(25773591140),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": 1310721
        },
        {
          "n": "seed",
          "p": 1310721
        }
      ],
      "n": "GenerateSignature",
      "d": 3787364,
      "h": 25773591140,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25773591140),
//--TRIMMABLE-BOUNDARY-START(21478623844),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "Base62Encode",
      "d": 3787364,
      "h": 21478623844,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21478623844),
//--TRIMMABLE-BOUNDARY-START(17183656548),
    {
      "r": 917505,
      "p": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "n": "Base62Decode",
      "d": 3787364,
      "h": 17183656548,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17183656548)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8593721956),
    {
      "t": 1310721,
      "n": "Alphabet",
      "d": 3787364,
      "h": 8593721956,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8593721956),
//--TRIMMABLE-BOUNDARY-START(12888689252),
    {
      "t": 655361,
      "n": "Base",
      "d": 3787364,
      "h": 12888689252,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12888689252),
//--TRIMMABLE-BOUNDARY-START(38658493028),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "SecretKey",
      "d": 3787364,
      "h": 38658493028,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38658493028),
//--TRIMMABLE-BOUNDARY-START(42953460324),
    {
      "t": 655361,
      "n": "SignatureLength",
      "d": 3787364,
      "h": 42953460324,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42953460324),
//--TRIMMABLE-BOUNDARY-START(34363525732),
    {
      "t": 458753,
      "n": "PayloadSeparator",
      "d": 3787364,
      "h": 34363525732,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34363525732)
  ],
  "h": 3787364
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.SecureTokenManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}SecureTokenManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3787364)
        
        

        //--TRIMMABLE-BOUNDARY-START(4442724)
        $asm.$cls(`$fsgt.LCIDTS$1.TerrameterDeviceSettingsCustomAttributesProvider`, ($self) => class TerrameterDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299410020)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299410020)
            
            //--TRIMMABLE-BOUNDARY-START(8594377316)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594377316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$fsgt.LCIDTS$1.TerrameterDeviceSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Invert", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (256);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("OnClick", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (257);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$fsgt.LCIDTS$1.TerrameterDeviceSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $wflKtf ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4442724,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $FLlPai ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4442724,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594377316)
            
            static $h = 4442724;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594377316),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4442724,
      "h": 8594377316,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594377316)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299410020),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4442724,
      "h": 4299410020,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299410020)
  ],
  "h": 4442724
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Settings${separator}TerrameterDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4442724)
        
        

        //--TRIMMABLE-BOUNDARY-START(117348)
        $asm.$cls(`$fsgt._LCIDTVT.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(25769921124)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Client.Components.Input.InputEditorFeatures*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg1, /*int*/ __seq2, /*global::System.String*/ __arg2, /*int*/ __seq3, /*TValue*/ __arg3, /*int*/ __seq4, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg4, /*int*/ __seq5, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769921124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Features", $.$box(__arg0, $.$hDPm.LCFCCI$1.InputEditorFeatures));
                __builder.AddComponentParameter(__seq1, "Type", $.$box(__arg1, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq2, "PlaceHolder", __arg2);
                __builder.AddComponentParameter(__seq3, "Value", $.$box(__arg3, TValue));
                __builder.AddComponentParameter(__seq4, "ValueChanged", __arg4);
                __builder.AddComponentParameter(__seq5, "ValueExpression", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(25769921124)
            
            //--TRIMMABLE-BOUNDARY-START(30064888420)
            static /*void */ CreateInputEditor_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Client.Components.Input.InputEditorFeatures*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg1, /*int*/ __seq2, /*global::System.String*/ __arg2, /*int*/ __seq3, /*TValue*/ __arg3, /*int*/ __seq4, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg4, /*int*/ __seq5, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064888420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Features", $.$box(__arg0, $.$hDPm.LCFCCI$1.InputEditorFeatures));
                __builder.AddComponentParameter(__seq1, "Type", $.$box(__arg1, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq2, "PlaceHolder", __arg2);
                __builder.AddComponentParameter(__seq3, "Value", $.$box(__arg3, TValue));
                __builder.AddComponentParameter(__seq4, "ValueChanged", __arg4);
                __builder.AddComponentParameter(__seq5, "ValueExpression", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(30064888420)
            
            //--TRIMMABLE-BOUNDARY-START(34359855716)
            static /*void */ CreateInputEditor_2(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Client.Components.Input.InputEditorFeatures*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg1, /*int*/ __seq2, /*global::System.String*/ __arg2, /*int*/ __seq3, /*TValue*/ __arg3, /*int*/ __seq4, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg4, /*int*/ __seq5, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359855716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Features", $.$box(__arg0, $.$hDPm.LCFCCI$1.InputEditorFeatures));
                __builder.AddComponentParameter(__seq1, "Type", $.$box(__arg1, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq2, "PlaceHolder", __arg2);
                __builder.AddComponentParameter(__seq3, "Value", $.$box(__arg3, TValue));
                __builder.AddComponentParameter(__seq4, "ValueChanged", __arg4);
                __builder.AddComponentParameter(__seq5, "ValueExpression", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(34359855716)
            
            //--TRIMMABLE-BOUNDARY-START(4295084644)
            static /*void */ CreateEditable_3(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Boolean?*/ __arg0, /*int*/ __seq1, /*TValue*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg2, /*int*/ __seq3, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295084644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCE.Editable$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Enable", $.$box(__arg0, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq1, "Value", $.$box(__arg1, TValue));
                __builder.AddComponentParameter(__seq2, "ValueChanged", __arg2);
                __builder.AddComponentParameter(__seq3, "ValueExpression", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295084644)
            
            //--TRIMMABLE-BOUNDARY-START(8590051940)
            static /*void */ CreateEditable_4(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Boolean?*/ __arg0, /*int*/ __seq1, /*TValue*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg2, /*int*/ __seq3, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590051940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCE.Editable$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Enable", $.$box(__arg0, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq1, "Value", $.$box(__arg1, TValue));
                __builder.AddComponentParameter(__seq2, "ValueChanged", __arg2);
                __builder.AddComponentParameter(__seq3, "ValueExpression", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590051940)
            
            //--TRIMMABLE-BOUNDARY-START(12885019236)
            static /*void */ CreateEditable_5(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Boolean?*/ __arg0, /*int*/ __seq1, /*TValue*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg2, /*int*/ __seq3, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885019236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCE.Editable$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Enable", $.$box(__arg0, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq1, "Value", $.$box(__arg1, TValue));
                __builder.AddComponentParameter(__seq2, "ValueChanged", __arg2);
                __builder.AddComponentParameter(__seq3, "ValueExpression", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12885019236)
            
            //--TRIMMABLE-BOUNDARY-START(17179986532)
            static /*void */ CreateEditable_6(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Boolean?*/ __arg0, /*int*/ __seq1, /*TValue*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg2, /*int*/ __seq3, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179986532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCE.Editable$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Enable", $.$box(__arg0, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq1, "Value", $.$box(__arg1, TValue));
                __builder.AddComponentParameter(__seq2, "ValueChanged", __arg2);
                __builder.AddComponentParameter(__seq3, "ValueExpression", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17179986532)
            
            //--TRIMMABLE-BOUNDARY-START(21474953828)
            static /*void */ CreateEditable_7(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Boolean?*/ __arg0, /*int*/ __seq1, /*TValue*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg2, /*int*/ __seq3, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474953828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCE.Editable$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Enable", $.$box(__arg0, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq1, "Value", $.$box(__arg1, TValue));
                __builder.AddComponentParameter(__seq2, "ValueChanged", __arg2);
                __builder.AddComponentParameter(__seq3, "ValueExpression", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21474953828)
            
            static $h = 117348;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25769921124),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 27612842
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 47614294
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 1310721
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 117348,
      "h": 25769921124,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25769921124),
//--TRIMMABLE-BOUNDARY-START(30064888420),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 27612842
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 47614294
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 1310721
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_1",
      "d": 117348,
      "h": 30064888420,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(30064888420),
//--TRIMMABLE-BOUNDARY-START(34359855716),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 27612842
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 47614294
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 1310721
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_2",
      "d": 117348,
      "h": 34359855716,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(34359855716),
//--TRIMMABLE-BOUNDARY-START(4295084644),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": $.$typeNullable($.$$.S.Boolean).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateEditable_3",
      "d": 117348,
      "h": 4295084644,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295084644),
//--TRIMMABLE-BOUNDARY-START(8590051940),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": $.$typeNullable($.$$.S.Boolean).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateEditable_4",
      "d": 117348,
      "h": 8590051940,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590051940),
//--TRIMMABLE-BOUNDARY-START(12885019236),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": $.$typeNullable($.$$.S.Boolean).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateEditable_5",
      "d": 117348,
      "h": 12885019236,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885019236),
//--TRIMMABLE-BOUNDARY-START(17179986532),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": $.$typeNullable($.$$.S.Boolean).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateEditable_6",
      "d": 117348,
      "h": 17179986532,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17179986532),
//--TRIMMABLE-BOUNDARY-START(21474953828),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": $.$typeNullable($.$$.S.Boolean).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateEditable_7",
      "d": 117348,
      "h": 21474953828,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21474953828)
  ],
  "h": 117348
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.IOT.Devices.Terrameter.Views.TerrameterDeviceDetails.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Views${separator}TerrameterDeviceDetails${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(117348)
        
        

        //--TRIMMABLE-BOUNDARY-START(3197540)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterLogModelTypeDescriptorBuilder`, ($self) => class TerrameterLogModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593132132)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593132132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$fsgt.LCIDTM.TerrameterLogModelTypeDescriptor()
                        const $t1 = $.$fsgt.LCIDTM.TerrameterLogModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterLogModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ReCCjj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3197540,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$fsgt.LCIDTM.TerrameterLogModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593132132)
            
            //--TRIMMABLE-BOUNDARY-START(4298164836)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298164836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298164836)
            
            //--TRIMMABLE-BOUNDARY-START(4298164836)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298164836)
            
            static $h = 3197540;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593132132),
    {
      "r": 65537,
      "n": "Register",
      "d": 3197540,
      "h": 8593132132,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593132132)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298164836),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3197540,
      "h": 4298164836,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298164836)
  ],
  "h": 3197540
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterLogModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterLogModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3197540)
        
        

        //--TRIMMABLE-BOUNDARY-START(4573796)
        $asm.$cls(`$fsgt.LCIDTS$1.TerrameterDeviceSettingsTypeDescriptorBuilder`, ($self) => class TerrameterDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594508388)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594508388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$fsgt.LCIDTS$1.TerrameterDeviceSettingsTypeDescriptor()
                        const $t1 = $.$fsgt.LCIDTS$1.TerrameterDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Diyilc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4573796,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$fsgt.LCIDTS$1.TerrameterDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594508388)
            
            //--TRIMMABLE-BOUNDARY-START(4299541092)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299541092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299541092)
            
            //--TRIMMABLE-BOUNDARY-START(4299541092)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299541092)
            
            static $h = 4573796;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594508388),
    {
      "r": 65537,
      "n": "Register",
      "d": 4573796,
      "h": 8594508388,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594508388)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299541092),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4573796,
      "h": 4299541092,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299541092)
  ],
  "h": 4573796
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Settings${separator}TerrameterDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4573796)
        
        

        //--TRIMMABLE-BOUNDARY-START(2148964)
        $asm.$cls(`$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptorBuilder`, ($self) => class TerrameterStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592083556)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592083556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor()
                        const $t1 = $.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $SFNNGk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2148964,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$fsgt.LCIDTMS.TerrameterStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592083556)
            
            //--TRIMMABLE-BOUNDARY-START(4297116260)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297116260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297116260)
            
            //--TRIMMABLE-BOUNDARY-START(4297116260)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297116260)
            
            static $h = 2148964;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592083556),
    {
      "r": 65537,
      "n": "Register",
      "d": 2148964,
      "h": 8592083556,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592083556)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297116260),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2148964,
      "h": 4297116260,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297116260)
  ],
  "h": 2148964
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Statuses${separator}TerrameterStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2148964)
        
        

        //--TRIMMABLE-BOUNDARY-START(3459684)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterServiceModelCustomAttributesProvider`, ($self) => class TerrameterServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298426980)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298426980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298426980)
            
            static $h = 3459684;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298426980),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3459684,
      "h": 4298426980,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298426980)
  ],
  "h": 3459684
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3459684)
        
        

        //--TRIMMABLE-BOUNDARY-START(313956)
        $asm.$cls(`$fsgt.LCIDT.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180183140)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180183140)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295281252)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295281252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295281252)
            
            //--TRIMMABLE-BOUNDARY-START(4295281252)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295281252)
            
            static $h = 313956;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180183140),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885215844,
        "f": 50331649
      },
      "n": "Paths",
      "d": 313956,
      "h": 17180183140,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180183140)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295281252),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 313956,
      "h": 4295281252,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295281252)
  ],
  "h": 313956
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(313956)
        
        

        //--TRIMMABLE-BOUNDARY-START(3656292)
        $asm.$cls(`$fsgt.LCIDT.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17183525476)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$fsgt.LCIDTV.TerrameterDeviceDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$fsgt.LCIDTV.TerrameterDeviceDetails().$ctor$4();
                    }, $MQrkmi ??= {"r":2752627,"n":"","d":3656292,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$fsgt.LCIDTV.TerrameterUnlock.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$fsgt.LCIDTV.TerrameterUnlock().$ctor$3();
                    }, $Xaycqd ??= {"r":2752627,"n":"","d":3656292,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17183525476)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4298623588)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298623588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298623588)
            
            //--TRIMMABLE-BOUNDARY-START(4298623588)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298623588)
            
            static $h = 3656292;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183525476),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888558180,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 3656292,
      "h": 17183525476,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17183525476)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298623588),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3656292,
      "h": 4298623588,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298623588)
  ],
  "h": 3656292
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3656292)
        
        

        //--TRIMMABLE-BOUNDARY-START(3852900)
        $asm.$cls(`$fsgt.LCIDT.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593787492)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593787492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$fsgt.LCIDT.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$fsgt.LCIDT.TerrameterDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$fsgt.LCIDT.TerrameterDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$fsgt.LCIDT.TerrameterDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$fsgt.LCIDT.TerrameterDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$fsgt.LCIDT.TerrameterDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fsgt.LCIDT.TerrameterDeviceFamily, x);
                }, $jMyGke ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":3852900,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fsgt.LCIDT.TerrameterDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$fsgt.LCIDT.TerrameterDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $JPeVMj ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":3852900,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$fsgt.LCIDT.TerrameterDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fsgt.LCIDT.TerrameterDeviceFamily, x);
                }, $ougZXb ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$fsgt.LCIDT.TerrameterDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":3852900,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$fsgt.LCIDT.TerrameterDevice, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$fsgt.LCIDT.TerrameterDevice, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$fsgt.LCIDT.TerrameterDevice, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$fsgt.LCIDT.TerrameterDevice), $.$fsgt.LCIDTMC.TerrameterDeviceCommands$$($.$fsgt.LCIDT.TerrameterDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$fsgt.LCIDT.TerrameterDevice), $.$fsgt.LCIDTV.TerrameterViewRenderer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8593787492)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fsgt.LCIDT.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298820196)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298820196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298820196)
            
            //--TRIMMABLE-BOUNDARY-START(4298820196)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298820196)
            
            static $h = 3852900;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593787492),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3852900,
      "h": 8593787492,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593787492)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298820196),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3852900,
      "h": 4298820196,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298820196)
  ],
  "h": 3852900
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3852900)
        
        

        //--TRIMMABLE-BOUNDARY-START(1886820)
        $asm.$cls(`$fsgt.LCIDTMS.TerrameterSelfPotentialData`, ($self) => class TerrameterSelfPotentialData extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81606265444)
            /*double*/ Voltage = 0;
            //--TRIMMABLE-BOUNDARY-END(81606265444)
            
            //--TRIMMABLE-BOUNDARY-START(51541494372)
            /*int*/ Samples = 0;
            //--TRIMMABLE-BOUNDARY-END(51541494372)
            
            //--TRIMMABLE-BOUNDARY-START(47246527076)
            /*double*/ MNDistance = 0;
            //--TRIMMABLE-BOUNDARY-END(47246527076)
            
            //--TRIMMABLE-BOUNDARY-START(17181756004)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181756004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181756004)
            
            //--TRIMMABLE-BOUNDARY-START(17181756004)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17181756004)
            
            static $h = 1886820;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81606265444),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951559780,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77311298148,
        "f": 83886081
      },
      "n": "Voltage",
      "d": 1886820,
      "h": 81606265444,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81606265444),
//--TRIMMABLE-BOUNDARY-START(51541494372),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361625188,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68721363556,
        "f": 83886081
      },
      "n": "Samples",
      "d": 1886820,
      "h": 51541494372,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541494372),
//--TRIMMABLE-BOUNDARY-START(47246527076),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771690596,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60131428964,
        "f": 83886081
      },
      "n": "MNDistance",
      "d": 1886820,
      "h": 47246527076,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47246527076)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181756004),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1886820,
      "h": 17181756004,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181756004)
  ],
  "h": 1886820
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterSelfPotentialData`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Statuses${separator}TerrameterSelfPotentialData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1886820)
        
        

        //--TRIMMABLE-BOUNDARY-START(1821284)
        $asm.$cls(`$fsgt.LCIDTMS.TerrameterResistivityData`, ($self) => class TerrameterResistivityData extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(193275349604)
            /*double*/ PositiveMNVoltage1 = 0;
            //--TRIMMABLE-BOUNDARY-END(193275349604)
            
            //--TRIMMABLE-BOUNDARY-START(184685415012)
            /*double*/ PositiveABCurrent1 = 0;
            //--TRIMMABLE-BOUNDARY-END(184685415012)
            
            //--TRIMMABLE-BOUNDARY-START(201865284196)
            /*int*/ PositiveSamples1 = 0;
            //--TRIMMABLE-BOUNDARY-END(201865284196)
            
            //--TRIMMABLE-BOUNDARY-START(176095480420)
            /*double*/ NegativeMNVoltage = 0;
            //--TRIMMABLE-BOUNDARY-END(176095480420)
            
            //--TRIMMABLE-BOUNDARY-START(171800513124)
            /*double*/ NegativeABCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(171800513124)
            
            //--TRIMMABLE-BOUNDARY-START(180390447716)
            /*int*/ NegativeSamples = 0;
            //--TRIMMABLE-BOUNDARY-END(180390447716)
            
            //--TRIMMABLE-BOUNDARY-START(197570316900)
            /*double*/ PositiveMNVoltage2 = 0;
            //--TRIMMABLE-BOUNDARY-END(197570316900)
            
            //--TRIMMABLE-BOUNDARY-START(188980382308)
            /*double*/ PositiveABCurrent2 = 0;
            //--TRIMMABLE-BOUNDARY-END(188980382308)
            
            //--TRIMMABLE-BOUNDARY-START(206160251492)
            /*int*/ PositiveSamples2 = 0;
            //--TRIMMABLE-BOUNDARY-END(206160251492)
            
            //--TRIMMABLE-BOUNDARY-START(167505545828)
            /*double*/ MNDistance = 0;
            //--TRIMMABLE-BOUNDARY-END(167505545828)
            
            //--TRIMMABLE-BOUNDARY-START(55836396132)
            /*double*/ ABDistance = 0;
            //--TRIMMABLE-BOUNDARY-END(55836396132)
            
            //--TRIMMABLE-BOUNDARY-START(158915611236)
            /*double */ GetdV()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915611236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.Math.Abs$1((this.PositiveMNVoltage1 - 2 * this.NegativeMNVoltage + this.PositiveMNVoltage2) / 4);
            }
            //--TRIMMABLE-BOUNDARY-END(158915611236)
            
            //--TRIMMABLE-BOUNDARY-START(154620643940)
            /*double */ GetCurrent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620643940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this.PositiveABCurrent1 + 2 * this.NegativeABCurrent + this.PositiveABCurrent2) / 4;
            }
            //--TRIMMABLE-BOUNDARY-END(154620643940)
            
            //--TRIMMABLE-BOUNDARY-START(163210578532)
            /*double */ GetResult()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210578532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetdV() / this.GetCurrent();
            }
            //--TRIMMABLE-BOUNDARY-END(163210578532)
            
            //--TRIMMABLE-BOUNDARY-START(51541428836)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541428836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51541428836)
            
            //--TRIMMABLE-BOUNDARY-START(51541428836)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(51541428836)
            
            static $h = 1821284;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(193275349604),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555872868,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274879728228,
        "f": 83886081
      },
      "n": "PositiveMNVoltage1",
      "d": 1821284,
      "h": 193275349604,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193275349604),
//--TRIMMABLE-BOUNDARY-START(184685415012),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376003684,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257699859044,
        "f": 83886081
      },
      "n": "PositiveABCurrent1",
      "d": 1821284,
      "h": 184685415012,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184685415012),
//--TRIMMABLE-BOUNDARY-START(201865284196),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735742052,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292059597412,
        "f": 83886081
      },
      "n": "PositiveSamples1",
      "d": 1821284,
      "h": 201865284196,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201865284196),
//--TRIMMABLE-BOUNDARY-START(176095480420),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196134500,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240519989860,
        "f": 83886081
      },
      "n": "NegativeMNVoltage",
      "d": 1821284,
      "h": 176095480420,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176095480420),
//--TRIMMABLE-BOUNDARY-START(171800513124),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606199908,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231930055268,
        "f": 83886081
      },
      "n": "NegativeABCurrent",
      "d": 1821284,
      "h": 171800513124,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171800513124),
//--TRIMMABLE-BOUNDARY-START(180390447716),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786069092,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249109924452,
        "f": 83886081
      },
      "n": "NegativeSamples",
      "d": 1821284,
      "h": 180390447716,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 6,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180390447716),
//--TRIMMABLE-BOUNDARY-START(197570316900),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145807460,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283469662820,
        "f": 83886081
      },
      "n": "PositiveMNVoltage2",
      "d": 1821284,
      "h": 197570316900,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 7,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197570316900),
//--TRIMMABLE-BOUNDARY-START(188980382308),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965938276,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266289793636,
        "f": 83886081
      },
      "n": "PositiveABCurrent2",
      "d": 1821284,
      "h": 188980382308,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 8,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188980382308),
//--TRIMMABLE-BOUNDARY-START(206160251492),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325676644,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300649532004,
        "f": 83886081
      },
      "n": "PositiveSamples2",
      "d": 1821284,
      "h": 206160251492,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 9,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206160251492),
//--TRIMMABLE-BOUNDARY-START(167505545828),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016265316,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223340120676,
        "f": 83886081
      },
      "n": "MNDistance",
      "d": 1821284,
      "h": 167505545828,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167505545828),
//--TRIMMABLE-BOUNDARY-START(55836396132),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426330724,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214750186084,
        "f": 83886081
      },
      "n": "ABDistance",
      "d": 1821284,
      "h": 55836396132,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836396132)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(158915611236),
    {
      "r": 1179649,
      "n": "GetdV",
      "d": 1821284,
      "h": 158915611236,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158915611236),
//--TRIMMABLE-BOUNDARY-START(154620643940),
    {
      "r": 1179649,
      "n": "GetCurrent",
      "d": 1821284,
      "h": 154620643940,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154620643940),
//--TRIMMABLE-BOUNDARY-START(163210578532),
    {
      "r": 1179649,
      "n": "GetResult",
      "d": 1821284,
      "h": 163210578532,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163210578532)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51541428836),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1821284,
      "h": 51541428836,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541428836)
  ],
  "h": 1821284
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterResistivityData`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Statuses${separator}TerrameterResistivityData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1821284)
        
        

        //--TRIMMABLE-BOUNDARY-START(1755748)
        $asm.$cls(`$fsgt.LCIDTMS.TerrameterInducedPolarizationData`, ($self) => class TerrameterInducedPolarizationData extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(167505480292)
            /*int*/ sampleRateMs = 0;
            //--TRIMMABLE-BOUNDARY-END(167505480292)
            
            //--TRIMMABLE-BOUNDARY-START(158915545700)
            /*double*/ positiveABCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(158915545700)
            
            //--TRIMMABLE-BOUNDARY-START(150325611108)
            /*double*/ negativeABCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(150325611108)
            
            //--TRIMMABLE-BOUNDARY-START(163210512996)
            /*double*/ positiveMNVoltage = 0;
            //--TRIMMABLE-BOUNDARY-END(163210512996)
            
            //--TRIMMABLE-BOUNDARY-START(154620578404)
            /*double*/ negativeMNVoltage = 0;
            //--TRIMMABLE-BOUNDARY-END(154620578404)
            
            //--TRIMMABLE-BOUNDARY-START(253404826212)
            /*float[]*/ vpz = null;
            //--TRIMMABLE-BOUNDARY-END(253404826212)
            
            //--TRIMMABLE-BOUNDARY-START(249109858916)
            /*float[]*/ vnz = null;
            //--TRIMMABLE-BOUNDARY-END(249109858916)
            
            //--TRIMMABLE-BOUNDARY-START(146030643812)
            /*double*/ MNDistance = 0;
            //--TRIMMABLE-BOUNDARY-END(146030643812)
            
            //--TRIMMABLE-BOUNDARY-START(47246396004)
            /*double*/ ABDistance = 0;
            //--TRIMMABLE-BOUNDARY-END(47246396004)
            
            //--TRIMMABLE-BOUNDARY-START(137440709220)
            /*double */ GetVI()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440709220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*double[]*/ let vs = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Double), null, [this.vpz.length], null);
                for(/*int*/ let i = 0; i < this.vpz.length; i++)
                {
                    $.$$.System.Array.$WriteT1.call(vs, ($.$$.System.Array.$ReadT1.call(this.vpz, i) - $.$$.System.Array.$ReadT1.call(this.vnz, i)) / 4, i);
                }
                /*double*/ let vi = 0;
                for(/*int*/ let i = 0; i < this.vpz.length; i++)
                {
                    vi += ($.$$.System.Array.$ReadT1.call(vs, i) * this.sampleRateMs) / 1000;
                }
                return $.$$.S.Math.Abs$1(vi);
            }
            //--TRIMMABLE-BOUNDARY-END(137440709220)
            
            //--TRIMMABLE-BOUNDARY-START(141735676516)
            /*double */ GetVm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735676516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*double*/ let vm = $.$$.S.Math.Abs$1((this.positiveMNVoltage - this.negativeMNVoltage) / 2);
                return vm;
            }
            //--TRIMMABLE-BOUNDARY-END(141735676516)
            
            //--TRIMMABLE-BOUNDARY-START(128850774628)
            /*double */ GetCurrent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850774628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this.positiveABCurrent + this.negativeABCurrent) / 2;
            }
            //--TRIMMABLE-BOUNDARY-END(128850774628)
            
            //--TRIMMABLE-BOUNDARY-START(133145741924)
            /*double */ GetResult()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145741924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetVI() / this.GetVm();
            }
            //--TRIMMABLE-BOUNDARY-END(133145741924)
            
            //--TRIMMABLE-BOUNDARY-START(42951428708)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951428708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951428708)
            
            //--TRIMMABLE-BOUNDARY-START(42951428708)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(42951428708)
            
            static $h = 1755748;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(167505480292),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375938148,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227635022436,
        "f": 83886081
      },
      "n": "sampleRateMs",
      "d": 1755748,
      "h": 167505480292,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167505480292),
//--TRIMMABLE-BOUNDARY-START(158915545700),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196068964,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210455153252,
        "f": 83886081
      },
      "n": "positiveABCurrent",
      "d": 1755748,
      "h": 158915545700,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158915545700),
//--TRIMMABLE-BOUNDARY-START(150325611108),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016199780,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193275284068,
        "f": 83886081
      },
      "n": "negativeABCurrent",
      "d": 1755748,
      "h": 150325611108,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150325611108),
//--TRIMMABLE-BOUNDARY-START(163210512996),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786003556,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219045087844,
        "f": 83886081
      },
      "n": "positiveMNVoltage",
      "d": 1755748,
      "h": 163210512996,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163210512996),
//--TRIMMABLE-BOUNDARY-START(154620578404),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606134372,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201865218660,
        "f": 83886081
      },
      "n": "negativeMNVoltage",
      "d": 1755748,
      "h": 154620578404,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154620578404),
//--TRIMMABLE-BOUNDARY-START(253404826212),
    {
      "p": $.$typeArray($.$$.S.Single).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555807332,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244814891620,
        "f": 83886081
      },
      "n": "vpz",
      "d": 1755748,
      "h": 253404826212,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 6,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253404826212),
//--TRIMMABLE-BOUNDARY-START(249109858916),
    {
      "p": $.$typeArray($.$$.S.Single).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965872740,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236224957028,
        "f": 83886081
      },
      "n": "vnz",
      "d": 1755748,
      "h": 249109858916,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 7,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(249109858916),
//--TRIMMABLE-BOUNDARY-START(146030643812),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426265188,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184685349476,
        "f": 83886081
      },
      "n": "MNDistance",
      "d": 1755748,
      "h": 146030643812,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146030643812),
//--TRIMMABLE-BOUNDARY-START(47246396004),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836330596,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176095414884,
        "f": 83886081
      },
      "n": "ABDistance",
      "d": 1755748,
      "h": 47246396004,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47246396004)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(137440709220),
    {
      "r": 1179649,
      "n": "GetVI",
      "d": 1755748,
      "h": 137440709220,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137440709220),
//--TRIMMABLE-BOUNDARY-START(141735676516),
    {
      "r": 1179649,
      "n": "GetVm",
      "d": 1755748,
      "h": 141735676516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141735676516),
//--TRIMMABLE-BOUNDARY-START(128850774628),
    {
      "r": 1179649,
      "n": "GetCurrent",
      "d": 1755748,
      "h": 128850774628,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128850774628),
//--TRIMMABLE-BOUNDARY-START(133145741924),
    {
      "r": 1179649,
      "n": "GetResult",
      "d": 1755748,
      "h": 133145741924,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133145741924)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42951428708),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1755748,
      "h": 42951428708,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951428708)
  ],
  "h": 1755748
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterInducedPolarizationData`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Statuses${separator}TerrameterInducedPolarizationData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1755748)
        
        

        //--TRIMMABLE-BOUNDARY-START(5622372)
        $asm.$cls(`$fsgt.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4300589668)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300589668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300589668)
            
            //--TRIMMABLE-BOUNDARY-START(4300589668)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4300589668)
            
            static $h = 5622372;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300589668),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5622372,
      "h": 4300589668,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300589668)
  ],
  "h": 5622372,
  "a": [
    {
      "t": 5556836,
      "c": 4300524132
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5622372)
        
        

        //--TRIMMABLE-BOUNDARY-START(5556836)
        $asm.$cls(`$fsgt.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4300524132)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300524132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300524132)
            
            //--TRIMMABLE-BOUNDARY-START(4300524132)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4300524132)
            
            static $h = 5556836;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300524132),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5556836,
      "h": 4300524132,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300524132)
  ],
  "h": 5556836
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5556836)
        
        

        //--TRIMMABLE-BOUNDARY-START(1493604)
        $asm.$cls(`$fsgt.LCIDTMC.TerrameterUnlockCommandModel`, ($self) => class TerrameterUnlockCommandModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(8591428196)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591428196);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591428196)
            
            //--TRIMMABLE-BOUNDARY-START(12886395492)
            /*int */ get Command()
            {
                return ((128 + 2) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(12886395492)
            
            //--TRIMMABLE-BOUNDARY-START(42951166564)
            /*int*/ Times = 0;
            //--TRIMMABLE-BOUNDARY-END(42951166564)
            
            //--TRIMMABLE-BOUNDARY-START(8591428196)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8591428196)
            
            static $h = 1493604;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886395492),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476330084,
        "f": 50364417
      },
      "n": "Command",
      "d": 1493604,
      "h": 12886395492,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12886395492),
//--TRIMMABLE-BOUNDARY-START(42951166564),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066264676,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38656199268,
        "f": 83886081
      },
      "n": "Times",
      "d": 1493604,
      "h": 42951166564,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 256,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42951166564)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591428196),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1493604,
      "h": 8591428196,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591428196)
  ],
  "h": 1493604
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterUnlockCommandModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterUnlockCommandModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1493604)
        
        

        //--TRIMMABLE-BOUNDARY-START(772708)
        $asm.$cls(`$fsgt.LCIDTMC.TerrameterMeasureCommandModel`, ($self) => class TerrameterMeasureCommandModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(38655478372)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655478372);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655478372)
            
            //--TRIMMABLE-BOUNDARY-START(47245412964)
            /*int */ get Command()
            {
                return ((128 + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(47245412964)
            
            //--TRIMMABLE-BOUNDARY-START(154619595364)
            /*TerrameterMeasureMode*/ Mode = 0;
            //--TRIMMABLE-BOUNDARY-END(154619595364)
            
            //--TRIMMABLE-BOUNDARY-START(150324628068)
            /*TerrameterMeasurementTime*/ MeasurementTime = 0;
            //--TRIMMABLE-BOUNDARY-END(150324628068)
            
            //--TRIMMABLE-BOUNDARY-START(55835347556)
            /*int*/ Cycles = 0;
            //--TRIMMABLE-BOUNDARY-END(55835347556)
            
            //--TRIMMABLE-BOUNDARY-START(51540380260)
            /*TerrameterMeasurementCurrent*/ Current = 0;
            //--TRIMMABLE-BOUNDARY-END(51540380260)
            
            //--TRIMMABLE-BOUNDARY-START(146029660772)
            /*int*/ HighVoltage = 0;
            //--TRIMMABLE-BOUNDARY-END(146029660772)
            
            //--TRIMMABLE-BOUNDARY-START(42950445668)
            /*TerrameterErrorChecks*/ CheckErrors = 0;
            //--TRIMMABLE-BOUNDARY-END(42950445668)
            
            //--TRIMMABLE-BOUNDARY-START(60130314852)
            /*int*/ ErtSpacings1 = 0;
            //--TRIMMABLE-BOUNDARY-END(60130314852)
            
            //--TRIMMABLE-BOUNDARY-START(64425282148)
            /*int*/ ErtSpacings2 = 0;
            //--TRIMMABLE-BOUNDARY-END(64425282148)
            
            //--TRIMMABLE-BOUNDARY-START(38655478372)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(38655478372)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(154619595364)
                this.Mode = 1;
                //--TRIMMABLE-BOUNDARY-END(154619595364)
                
                //--TRIMMABLE-BOUNDARY-START(55835347556)
                this.Cycles = -1;
                //--TRIMMABLE-BOUNDARY-END(55835347556)
                
                //--TRIMMABLE-BOUNDARY-START(146029660772)
                this.HighVoltage = 250;
                //--TRIMMABLE-BOUNDARY-END(146029660772)
                
                //--TRIMMABLE-BOUNDARY-START(42950445668)
                this.CheckErrors = 4294967295;
                //--TRIMMABLE-BOUNDARY-END(42950445668)
                
            }
            static $h = 772708;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245412964),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605151332,
        "f": 50364417
      },
      "n": "Command",
      "d": 772708,
      "h": 47245412964,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47245412964),
//--TRIMMABLE-BOUNDARY-START(154619595364),
    {
      "p": 3263076,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734693476,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223339072100,
        "f": 83886081
      },
      "n": "Mode",
      "d": 772708,
      "h": 154619595364,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 256,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154619595364),
//--TRIMMABLE-BOUNDARY-START(150324628068),
    {
      "p": 1165924,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144758884,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214749137508,
        "f": 83886081
      },
      "n": "MeasurementTime",
      "d": 772708,
      "h": 150324628068,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 257,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150324628068),
//--TRIMMABLE-BOUNDARY-START(55835347556),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785020516,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180389399140,
        "f": 83886081
      },
      "n": "Cycles",
      "d": 772708,
      "h": 55835347556,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 258,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835347556),
//--TRIMMABLE-BOUNDARY-START(51540380260),
    {
      "p": 1034852,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195085924,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799464548,
        "f": 83886081
      },
      "n": "Current",
      "d": 772708,
      "h": 51540380260,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 259,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540380260),
//--TRIMMABLE-BOUNDARY-START(146029660772),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554824292,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206159202916,
        "f": 83886081
      },
      "n": "HighVoltage",
      "d": 772708,
      "h": 146029660772,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 260,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146029660772),
//--TRIMMABLE-BOUNDARY-START(42950445668),
    {
      "p": 576100,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015216740,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209529956,
        "f": 83886081
      },
      "n": "CheckErrors",
      "d": 772708,
      "h": 42950445668,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 261,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950445668),
//--TRIMMABLE-BOUNDARY-START(60130314852),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374955108,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188979333732,
        "f": 83886081
      },
      "n": "ErtSpacings1",
      "d": 772708,
      "h": 60130314852,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 261,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130314852),
//--TRIMMABLE-BOUNDARY-START(64425282148),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964889700,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197569268324,
        "f": 83886081
      },
      "n": "ErtSpacings2",
      "d": 772708,
      "h": 64425282148,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 262,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425282148)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655478372),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 772708,
      "h": 38655478372,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655478372)
  ],
  "h": 772708
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterMeasureCommandModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(772708)
        
        

        //--TRIMMABLE-BOUNDARY-START(1952356)
        $asm.$cls(`$fsgt.LCIDTMS.TerrameterStatusModel`, ($self) => class TerrameterStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(184685546084)
            /*int*/ Token = 0;
            //--TRIMMABLE-BOUNDARY-END(184685546084)
            
            //--TRIMMABLE-BOUNDARY-START(51541559908)
            /*double*/ BatteryVoltage = 0;
            //--TRIMMABLE-BOUNDARY-END(51541559908)
            
            //--TRIMMABLE-BOUNDARY-START(55836527204)
            /*double*/ ChargerVoltage = 0;
            //--TRIMMABLE-BOUNDARY-END(55836527204)
            
            //--TRIMMABLE-BOUNDARY-START(128850971236)
            /*double*/ MNVoltage = 0;
            //--TRIMMABLE-BOUNDARY-END(128850971236)
            
            //--TRIMMABLE-BOUNDARY-START(47246592612)
            /*double*/ ABCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(47246592612)
            
            //--TRIMMABLE-BOUNDARY-START(124556003940)
            /*byte[]?*/ MeasurementData = null;
            //--TRIMMABLE-BOUNDARY-END(124556003940)
            
            //--TRIMMABLE-BOUNDARY-START(115966069348)
            /*bool */ IsLockedOut()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966069348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Token < 0)
                {
                    return false;
                }
                if (this.Token === 0)
                {
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(115966069348)
            
            //--TRIMMABLE-BOUNDARY-START(12886854244)
            /*int*/ _sequenceNumber = 0;
            //--TRIMMABLE-BOUNDARY-END(12886854244)
            
            //--TRIMMABLE-BOUNDARY-START(8591886948)
            /*TerrameterMeasureResult*/ _measureResult = 0;
            //--TRIMMABLE-BOUNDARY-END(8591886948)
            
            //--TRIMMABLE-BOUNDARY-START(4296919652)
            /*float*/ _errorValue = 0;
            //--TRIMMABLE-BOUNDARY-END(4296919652)
            
            //--TRIMMABLE-BOUNDARY-START(120261036644)
            /*OneOf<TerrameterSelfPotentialData?, TerrameterResistivityData?, TerrameterInducedPolarizationData?>*/ lastMeasurement;
            //--TRIMMABLE-BOUNDARY-END(120261036644)
            
            //--TRIMMABLE-BOUNDARY-START(111671102052)
            /*OneOf<TerrameterSelfPotentialData?, TerrameterResistivityData?, TerrameterInducedPolarizationData?> */ GetMeasurement(/*out int*/ sequenceNumber, /*out TerrameterMeasureResult?*/ measureResult, /*out double*/ errorValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671102052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((this.lastMeasurement.IsT0 && this.lastMeasurement.AsT0 !== null) || (this.lastMeasurement.IsT1 && this.lastMeasurement.AsT1 !== null))
                {
                    sequenceNumber.$v = this._sequenceNumber;
                    measureResult.$v = this._measureResult;
                    errorValue.$v = this._errorValue;
                    return this.lastMeasurement;
                }
                if (this.MeasurementData !== null && this.MeasurementData.length > 0)
                {
                    /*PacketBuilder*/ let builder = new $.$fPer.LCFCD.PacketBuilder().$ctor$1(this.MeasurementData);
                    this._sequenceNumber = builder.GetWord(-1, 0);
                    /*TerrameterMeasureMode*/ let mode = $.$cast(builder.GetByte(-1), $.$fsgt.LCIDTM.TerrameterMeasureMode);
                    this._measureResult = $.$cast(builder.GetByte(-1), $.$fsgt.LCIDTMC.TerrameterMeasureResult);
                    this._errorValue = builder.GetFloat();
                    try
                    {
                        if (mode === 1/*TerrameterMeasureMode.SelfPotential*/)
                        {
                            this.lastMeasurement = $.$fPer.LCFCO.OneOf$$$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData, $.$fsgt.LCIDTMS.TerrameterResistivityData, $.$fsgt.LCIDTMS.TerrameterInducedPolarizationData).op_Implicit(builder.Get($.$fsgt.LCIDTMS.TerrameterSelfPotentialData, null, null));
                        }
                        else if (mode === 2/*TerrameterMeasureMode.Resistivity*/)
                        {
                            this.lastMeasurement = $.$fPer.LCFCO.OneOf$$$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData, $.$fsgt.LCIDTMS.TerrameterResistivityData, $.$fsgt.LCIDTMS.TerrameterInducedPolarizationData).op_Implicit$1(builder.Get($.$fsgt.LCIDTMS.TerrameterResistivityData, null, null));
                        }
                        else if (mode === 3/*TerrameterMeasureMode.InducedPolarization*/)
                        {
                            this.lastMeasurement = $.$fPer.LCFCO.OneOf$$$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData, $.$fsgt.LCIDTMS.TerrameterResistivityData, $.$fsgt.LCIDTMS.TerrameterInducedPolarizationData).op_Implicit$2(builder.Get($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData, null, null));
                        }
                    }
                    catch($e)
                    {
                    }
                    sequenceNumber.$v = this._sequenceNumber;
                    measureResult.$v = this._measureResult;
                    errorValue.$v = this._errorValue;
                    return this.lastMeasurement;
                }
                sequenceNumber.$v = 0;
                measureResult.$v = null;
                errorValue.$v = 0;
                return this.lastMeasurement;
            }
            //--TRIMMABLE-BOUNDARY-END(111671102052)
            
            //--TRIMMABLE-BOUNDARY-START(42951625316)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951625316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951625316)
            
            //--TRIMMABLE-BOUNDARY-START(42951625316)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(42951625316)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(120261036644)
                this.lastMeasurement = $.$default($.$fPer.LCFCO.OneOf$$$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData, $.$fsgt.LCIDTMS.TerrameterResistivityData, $.$fsgt.LCIDTMS.TerrameterInducedPolarizationData));
                //--TRIMMABLE-BOUNDARY-END(120261036644)
                
            }
            static $h = 1952356;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(184685546084),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376134756,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180390578788,
        "f": 83886081
      },
      "n": "Token",
      "d": 1952356,
      "h": 184685546084,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184685546084),
//--TRIMMABLE-BOUNDARY-START(51541559908),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016396388,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146030840420,
        "f": 83886081
      },
      "n": "BatteryVoltage",
      "d": 1952356,
      "h": 51541559908,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541559908),
//--TRIMMABLE-BOUNDARY-START(55836527204),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606330980,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620775012,
        "f": 83886081
      },
      "n": "ChargerVoltage",
      "d": 1952356,
      "h": 55836527204,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836527204),
//--TRIMMABLE-BOUNDARY-START(128850971236),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786200164,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171800644196,
        "f": 83886081
      },
      "n": "MNVoltage",
      "d": 1952356,
      "h": 128850971236,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16776831,
              "t": 2722134
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128850971236),
//--TRIMMABLE-BOUNDARY-START(47246592612),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426461796,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137440905828,
        "f": 83886081
      },
      "n": "ABCurrent",
      "d": 1952356,
      "h": 47246592612,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47246592612),
//--TRIMMABLE-BOUNDARY-START(124556003940),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196265572,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163210709604,
        "f": 83886081
      },
      "n": "MeasurementData",
      "d": 1952356,
      "h": 124556003940,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 6,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124556003940)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(115966069348),
    {
      "r": 262145,
      "n": "IsLockedOut",
      "d": 1952356,
      "h": 115966069348,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115966069348),
//--TRIMMABLE-BOUNDARY-START(111671102052),
    {
      "r": $.$fPer.LCFCO.OneOf$$$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData, $.$fsgt.LCIDTMS.TerrameterResistivityData, $.$fsgt.LCIDTMS.TerrameterInducedPolarizationData).$h,
      "p": [
        {
          "n": "sequenceNumber",
          "p": 655361,
          "f": 2
        },
        {
          "n": "measureResult",
          "p": $.$typeNullable($.$fsgt.LCIDTMC.TerrameterMeasureResult).$h,
          "f": 2
        },
        {
          "n": "errorValue",
          "p": 1179649,
          "f": 2
        }
      ],
      "n": "GetMeasurement",
      "d": 1952356,
      "h": 111671102052,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111671102052)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886854244),
    {
      "t": 655361,
      "n": "_sequenceNumber",
      "d": 1952356,
      "h": 12886854244,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886854244),
//--TRIMMABLE-BOUNDARY-START(8591886948),
    {
      "t": 1296996,
      "n": "_measureResult",
      "d": 1952356,
      "h": 8591886948,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591886948),
//--TRIMMABLE-BOUNDARY-START(4296919652),
    {
      "t": 1114113,
      "n": "_errorValue",
      "d": 1952356,
      "h": 4296919652,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296919652),
//--TRIMMABLE-BOUNDARY-START(120261036644),
    {
      "t": $.$fPer.LCFCO.OneOf$$$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData, $.$fsgt.LCIDTMS.TerrameterResistivityData, $.$fsgt.LCIDTMS.TerrameterInducedPolarizationData).$h,
      "n": "lastMeasurement",
      "d": 1952356,
      "h": 120261036644,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(120261036644)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42951625316),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1952356,
      "h": 42951625316,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951625316)
  ],
  "h": 1952356
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Statuses${separator}TerrameterStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1952356)
        
        

        //--TRIMMABLE-BOUNDARY-START(3000932)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterLogModel`, ($self) => class TerrameterLogModel extends $.$XBGm.LCICDi.iSmartDeviceLogModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297968228)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297968228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297968228)
            
            //--TRIMMABLE-BOUNDARY-START(4297968228)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297968228)
            
            static $h = 3000932;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceLogModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297968228),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3000932,
      "h": 4297968228,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297968228)
  ],
  "h": 3000932
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceLog, $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterLogModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterLogModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3000932)
        
        

        //--TRIMMABLE-BOUNDARY-START(1165924)
        $asm.$str(`$fsgt.LCIDTMC.TerrameterMeasurementTime`, ($self) => class TerrameterMeasurementTime extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static Auto = 0;
            static _1s = 1;
            static _2s = 2;
            static _5s = 3;
            static _10s = 4;
            static _20s = 5;
            static _30s = 6;
            static _60s = 7;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1165924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Auto": 0n,
                    "_1s": 1n,
                    "_2s": 2n,
                    "_5s": 3n,
                    "_10s": 4n,
                    "_20s": 5n,
                    "_30s": 6n,
                    "_60s": 7n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(34360904292)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360904292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360904292)
            
            //--TRIMMABLE-BOUNDARY-START(34360904292)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(34360904292)
            
            static $h = 1165924;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655871588),
    {
      "t": 1165924,
      "n": "Auto",
      "d": 1165924,
      "h": 38655871588,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655871588),
//--TRIMMABLE-BOUNDARY-START(8591100516),
    {
      "t": 1165924,
      "n": "_1s",
      "d": 1165924,
      "h": 8591100516,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591100516),
//--TRIMMABLE-BOUNDARY-START(17181035108),
    {
      "t": 1165924,
      "n": "_2s",
      "d": 1165924,
      "h": 17181035108,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181035108),
//--TRIMMABLE-BOUNDARY-START(25770969700),
    {
      "t": 1165924,
      "n": "_5s",
      "d": 1165924,
      "h": 25770969700,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770969700),
//--TRIMMABLE-BOUNDARY-START(4296133220),
    {
      "t": 1165924,
      "n": "_10s",
      "d": 1165924,
      "h": 4296133220,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4296133220),
//--TRIMMABLE-BOUNDARY-START(12886067812),
    {
      "t": 1165924,
      "n": "_20s",
      "d": 1165924,
      "h": 12886067812,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886067812),
//--TRIMMABLE-BOUNDARY-START(21476002404),
    {
      "t": 1165924,
      "n": "_30s",
      "d": 1165924,
      "h": 21476002404,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476002404),
//--TRIMMABLE-BOUNDARY-START(30065936996),
    {
      "t": 1165924,
      "n": "_60s",
      "d": 1165924,
      "h": 30065936996,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065936996)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360904292),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1165924,
      "h": 34360904292,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360904292)
  ],
  "h": 1165924
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasurementTime`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterMeasurementTime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1165924)
        
        

        //--TRIMMABLE-BOUNDARY-START(1034852)
        $asm.$str(`$fsgt.LCIDTMC.TerrameterMeasurementCurrent`, ($self) => class TerrameterMeasurementCurrent extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static _500uA = 0;
            static _1mA = 1;
            static _2mA = 2;
            static _5mA = 3;
            static _10mA = 4;
            static _20mA = 5;
            static _50mA = 6;
            static _100mA = 7;
            static _200mA = 8;
            static _500mA = 9;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1034852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "_500uA": 0n,
                    "_1mA": 1n,
                    "_2mA": 2n,
                    "_5mA": 3n,
                    "_10mA": 4n,
                    "_20mA": 5n,
                    "_50mA": 6n,
                    "_100mA": 7n,
                    "_200mA": 8n,
                    "_500mA": 9n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(47245675108)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245675108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245675108)
            
            //--TRIMMABLE-BOUNDARY-START(47245675108)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(47245675108)
            
            static $h = 1034852;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360773220),
    {
      "t": 1034852,
      "n": "_500uA",
      "d": 1034852,
      "h": 34360773220,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "500uA",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360773220),
//--TRIMMABLE-BOUNDARY-START(12885936740),
    {
      "t": 1034852,
      "n": "_1mA",
      "d": 1034852,
      "h": 12885936740,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "1mA",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885936740),
//--TRIMMABLE-BOUNDARY-START(25770838628),
    {
      "t": 1034852,
      "n": "_2mA",
      "d": 1034852,
      "h": 25770838628,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "2mA",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770838628),
//--TRIMMABLE-BOUNDARY-START(42950707812),
    {
      "t": 1034852,
      "n": "_5mA",
      "d": 1034852,
      "h": 42950707812,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "5mA",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950707812),
//--TRIMMABLE-BOUNDARY-START(8590969444),
    {
      "t": 1034852,
      "n": "_10mA",
      "d": 1034852,
      "h": 8590969444,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "10mA",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590969444),
//--TRIMMABLE-BOUNDARY-START(21475871332),
    {
      "t": 1034852,
      "n": "_20mA",
      "d": 1034852,
      "h": 21475871332,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "20mA",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475871332),
//--TRIMMABLE-BOUNDARY-START(38655740516),
    {
      "t": 1034852,
      "n": "_50mA",
      "d": 1034852,
      "h": 38655740516,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "50mA",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655740516),
//--TRIMMABLE-BOUNDARY-START(4296002148),
    {
      "t": 1034852,
      "n": "_100mA",
      "d": 1034852,
      "h": 4296002148,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "100mA",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4296002148),
//--TRIMMABLE-BOUNDARY-START(17180904036),
    {
      "t": 1034852,
      "n": "_200mA",
      "d": 1034852,
      "h": 17180904036,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "200mA",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180904036),
//--TRIMMABLE-BOUNDARY-START(30065805924),
    {
      "t": 1034852,
      "n": "_500mA",
      "d": 1034852,
      "h": 30065805924,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "500mA",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065805924)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47245675108),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1034852,
      "h": 47245675108,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245675108)
  ],
  "h": 1034852
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasurementCurrent`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterMeasurementCurrent`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1034852)
        
        

        //--TRIMMABLE-BOUNDARY-START(1296996)
        $asm.$str(`$fsgt.LCIDTMC.TerrameterMeasureResult`, ($self) => class TerrameterMeasureResult extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Success = 0;
            static LowBatteryError = 1;
            static LowCurrentError = 2;
            static HighCurrentError = 3;
            static MNProbeError = 4;
            static ABProbeError = 5;
            static HVGenError = 6;
            static FaultError = 7;
            static NotLicensedError = 8;
            static UnknownError = 31;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1296996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Success": 0n,
                    "LowBatteryError": 1n,
                    "LowCurrentError": 2n,
                    "HighCurrentError": 3n,
                    "MNProbeError": 4n,
                    "ABProbeError": 5n,
                    "HVGenError": 6n,
                    "FaultError": 7n,
                    "NotLicensedError": 8n,
                    "UnknownError": 31n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296264292)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296264292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296264292)
            
            //--TRIMMABLE-BOUNDARY-START(4296264292)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296264292)
            
            static $h = 1296996;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(42950969956),
    {
      "t": 1296996,
      "n": "Success",
      "d": 1296996,
      "h": 42950969956,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950969956),
//--TRIMMABLE-BOUNDARY-START(25771100772),
    {
      "t": 1296996,
      "n": "LowBatteryError",
      "d": 1296996,
      "h": 25771100772,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771100772),
//--TRIMMABLE-BOUNDARY-START(30066068068),
    {
      "t": 1296996,
      "n": "LowCurrentError",
      "d": 1296996,
      "h": 30066068068,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066068068),
//--TRIMMABLE-BOUNDARY-START(17181166180),
    {
      "t": 1296996,
      "n": "HighCurrentError",
      "d": 1296996,
      "h": 17181166180,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181166180),
//--TRIMMABLE-BOUNDARY-START(34361035364),
    {
      "t": 1296996,
      "n": "MNProbeError",
      "d": 1296996,
      "h": 34361035364,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361035364),
//--TRIMMABLE-BOUNDARY-START(8591231588),
    {
      "t": 1296996,
      "n": "ABProbeError",
      "d": 1296996,
      "h": 8591231588,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591231588),
//--TRIMMABLE-BOUNDARY-START(21476133476),
    {
      "t": 1296996,
      "n": "HVGenError",
      "d": 1296996,
      "h": 21476133476,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476133476),
//--TRIMMABLE-BOUNDARY-START(12886198884),
    {
      "t": 1296996,
      "n": "FaultError",
      "d": 1296996,
      "h": 12886198884,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886198884),
//--TRIMMABLE-BOUNDARY-START(38656002660),
    {
      "t": 1296996,
      "n": "NotLicensedError",
      "d": 1296996,
      "h": 38656002660,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656002660),
//--TRIMMABLE-BOUNDARY-START(47245937252),
    {
      "t": 1296996,
      "n": "UnknownError",
      "d": 1296996,
      "h": 47245937252,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245937252)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296264292),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1296996,
      "h": 4296264292,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296264292)
  ],
  "h": 1296996
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureResult`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterMeasureResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1296996)
        
        

        //--TRIMMABLE-BOUNDARY-START(3263076)
        $asm.$str(`$fsgt.LCIDTM.TerrameterMeasureMode`, ($self) => class TerrameterMeasureMode extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static None = 0;
            static SelfPotential = 1;
            static Resistivity = 2;
            static InducedPolarization = 3;
            static ElectricalResistivityTomography = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3263076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "SelfPotential": 1n,
                    "Resistivity": 2n,
                    "InducedPolarization": 3n,
                    "ElectricalResistivityTomography": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298230372)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298230372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298230372)
            
            //--TRIMMABLE-BOUNDARY-START(4298230372)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298230372)
            
            static $h = 3263076;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17183132260),
    {
      "t": 3263076,
      "n": "None",
      "d": 3263076,
      "h": 17183132260,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183132260),
//--TRIMMABLE-BOUNDARY-START(25773066852),
    {
      "t": 3263076,
      "n": "SelfPotential",
      "d": 3263076,
      "h": 25773066852,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25773066852),
//--TRIMMABLE-BOUNDARY-START(21478099556),
    {
      "t": 3263076,
      "n": "Resistivity",
      "d": 3263076,
      "h": 21478099556,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21478099556),
//--TRIMMABLE-BOUNDARY-START(12888164964),
    {
      "t": 3263076,
      "n": "InducedPolarization",
      "d": 3263076,
      "h": 12888164964,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888164964),
//--TRIMMABLE-BOUNDARY-START(8593197668),
    {
      "t": 3263076,
      "n": "ElectricalResistivityTomography",
      "d": 3263076,
      "h": 8593197668,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593197668)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298230372),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3263076,
      "h": 4298230372,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298230372)
  ],
  "h": 3263076
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterMeasureMode`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterMeasureMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3263076)
        
        

        //--TRIMMABLE-BOUNDARY-START(576100)
        $asm.$str(`$fsgt.LCIDTMC.TerrameterErrorChecks`, ($self) => class TerrameterErrorChecks extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static LowBatteryError = 2;
            static LowCurrentError = 4;
            static HighCurrentError = 8;
            static MNProbeError = 16;
            static ABProbeError = 32;
            static HVGenError = 64;
            static FaultError = 128;
            static NotLicensedError = 256;
            static UnknownError = 2147483648;
            static All = 4294967295;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(576100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "LowBatteryError": 2n,
                    "LowCurrentError": 4n,
                    "HighCurrentError": 8n,
                    "MNProbeError": 16n,
                    "ABProbeError": 32n,
                    "HVGenError": 64n,
                    "FaultError": 128n,
                    "NotLicensedError": 256n,
                    "UnknownError": 2147483648n,
                    "All": 4294967295n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295543396)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295543396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295543396)
            
            //--TRIMMABLE-BOUNDARY-START(4295543396)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295543396)
            
            static $h = 576100;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.UInt32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 720897,
  "l": [
//--TRIMMABLE-BOUNDARY-START(42950249060),
    {
      "t": 576100,
      "n": "None",
      "d": 576100,
      "h": 42950249060,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950249060),
//--TRIMMABLE-BOUNDARY-START(30065347172),
    {
      "t": 576100,
      "n": "LowBatteryError",
      "d": 576100,
      "h": 30065347172,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065347172),
//--TRIMMABLE-BOUNDARY-START(34360314468),
    {
      "t": 576100,
      "n": "LowCurrentError",
      "d": 576100,
      "h": 34360314468,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360314468),
//--TRIMMABLE-BOUNDARY-START(21475412580),
    {
      "t": 576100,
      "n": "HighCurrentError",
      "d": 576100,
      "h": 21475412580,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475412580),
//--TRIMMABLE-BOUNDARY-START(38655281764),
    {
      "t": 576100,
      "n": "MNProbeError",
      "d": 576100,
      "h": 38655281764,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655281764),
//--TRIMMABLE-BOUNDARY-START(8590510692),
    {
      "t": 576100,
      "n": "ABProbeError",
      "d": 576100,
      "h": 8590510692,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590510692),
//--TRIMMABLE-BOUNDARY-START(25770379876),
    {
      "t": 576100,
      "n": "HVGenError",
      "d": 576100,
      "h": 25770379876,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770379876),
//--TRIMMABLE-BOUNDARY-START(17180445284),
    {
      "t": 576100,
      "n": "FaultError",
      "d": 576100,
      "h": 17180445284,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180445284),
//--TRIMMABLE-BOUNDARY-START(47245216356),
    {
      "t": 576100,
      "n": "NotLicensedError",
      "d": 576100,
      "h": 47245216356,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245216356),
//--TRIMMABLE-BOUNDARY-START(51540183652),
    {
      "t": 576100,
      "n": "UnknownError",
      "d": 576100,
      "h": 51540183652,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540183652),
//--TRIMMABLE-BOUNDARY-START(12885477988),
    {
      "t": 576100,
      "n": "All",
      "d": 576100,
      "h": 12885477988,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885477988)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295543396),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 576100,
      "h": 4295543396,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295543396)
  ],
  "h": 576100,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterErrorChecks`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterErrorChecks`; }
        });
        //--TRIMMABLE-BOUNDARY-END(576100)
        
        

        //--TRIMMABLE-BOUNDARY-START(5425764)
        $asm.$cls(`$fsgt.LCIDTV.TerrameterUnlock`, ($self) => class TerrameterUnlock extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(60134967908)
            /*int*/ Times = 0;
            //--TRIMMABLE-BOUNDARY-END(60134967908)
            
            //--TRIMMABLE-BOUNDARY-START(64429935204)
            /*string*/ Token = null;
            //--TRIMMABLE-BOUNDARY-END(64429935204)
            
            //--TRIMMABLE-BOUNDARY-START(68724902500)
            /*string?*/ unlockCode = null;
            //--TRIMMABLE-BOUNDARY-END(68724902500)
            
            //--TRIMMABLE-BOUNDARY-START(38660131428)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38660131428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.unlockCode = $.$fsgt.LCIDT.SecureTokenManager.GenerateUnlockToken(BigInt(this.Times), this.Token);
            }
            //--TRIMMABLE-BOUNDARY-END(38660131428)
            
            //--TRIMMABLE-BOUNDARY-START(17185294948)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185294948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$4(0, this.unlockCode);
            }
            //--TRIMMABLE-BOUNDARY-END(17185294948)
            
            //--TRIMMABLE-BOUNDARY-START(12890327652)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890327652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12890327652)
            
            //--TRIMMABLE-BOUNDARY-START(12890327652)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12890327652)
            
            static $h = 5425764;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60134967908),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25775229540,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47250066020,
        "f": 83886081
      },
      "n": "Times",
      "d": 5425764,
      "h": 60134967908,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 12386419,
          "c": 8602321011,
          "n": [
            {
              "n": "Name",
              "v": "times",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60134967908),
//--TRIMMABLE-BOUNDARY-START(64429935204),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34365164132,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55840000612,
        "f": 83886081
      },
      "n": "Token",
      "d": 5425764,
      "h": 64429935204,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 12386419,
          "c": 8602321011,
          "n": [
            {
              "n": "Name",
              "v": "token",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64429935204)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38660131428),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 5425764,
      "h": 38660131428,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38660131428),
//--TRIMMABLE-BOUNDARY-START(17185294948),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 5425764,
      "h": 17185294948,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17185294948)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(68724902500),
    {
      "t": 1310721,
      "n": "unlockCode",
      "d": 5425764,
      "h": 68724902500,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68724902500)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12890327652),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5425764,
      "h": 12890327652,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12890327652)
  ],
  "h": 5425764,
  "a": [
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/TMv402Unlock",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Views.TerrameterUnlock`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Views${separator}TerrameterUnlock`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5425764)
        
        

        //--TRIMMABLE-BOUNDARY-START(182884)
        $asm.$cls(`$fsgt.LCIDT._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590117476)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590117476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590117476)
            
            //--TRIMMABLE-BOUNDARY-START(4295150180)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295150180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295150180)
            
            //--TRIMMABLE-BOUNDARY-START(4295150180)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295150180)
            
            static $h = 182884;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590117476),
    {
      "r": 65537,
      "n": "Execute",
      "d": 182884,
      "h": 8590117476,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590117476)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295150180),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 182884,
      "h": 4295150180,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295150180)
  ],
  "h": 182884
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(182884)
        
        

        //--TRIMMABLE-BOUNDARY-START(903780)
        $asm.$cls(`$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor`, ($self) => class TerrameterMeasureCommandModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTMC.TerrameterMeasureCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295871076)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295871076);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor.GenerateProperties($.$fsgt.LCIDTMC.TerrameterMeasureCommandModel, this, factory);
                    }, $nVvdgk ??= {"r":65537,"n":"","d":903780,"h":0,"f":17825794}), 0, "TerrameterMeasureCommandModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Terrameter\\Models_Commands_TerrameterMeasureCommandModel_LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModelTypeDescriptorBuilder.g.cs", "TerrameterMeasureCommandModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295871076)
            
            //--TRIMMABLE-BOUNDARY-START(12885805668)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885805668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Mode"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel.$type, $.$discardRef(), "Mode", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Mode")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fsgt.LCIDTM.TerrameterMeasureMode, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Mode";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$fsgt.LCIDTM.TerrameterMeasureMode, ($.$cast(target, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel)).Mode);
                        }, $SebnAk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":903780,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Mode = value.AsEnumValue($.$fsgt.LCIDTM.TerrameterMeasureMode);
                        }, $fwLxxd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":903780,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MeasurementTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel.$type, $.$discardRef(), "MeasurementTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MeasurementTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fsgt.LCIDTMC.TerrameterMeasurementTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "MeasurementTime";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$fsgt.LCIDTMC.TerrameterMeasurementTime, ($.$cast(target, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel)).MeasurementTime);
                        }, $pGcVDe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":903780,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.MeasurementTime = value.AsEnumValue($.$fsgt.LCIDTMC.TerrameterMeasurementTime);
                        }, $hygVLg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":903780,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Cycles"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel.$type, $.$discardRef(), "Cycles", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Cycles")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Cycles";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel)).Cycles);
                        }, $vnYvCd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":903780,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Cycles = value.AsInt();
                        }, $DlZxZh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":903780,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Current"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel.$type, $.$discardRef(), "Current", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Current")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fsgt.LCIDTMC.TerrameterMeasurementCurrent, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Current";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$fsgt.LCIDTMC.TerrameterMeasurementCurrent, ($.$cast(target, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel)).Current);
                        }, $wigNqg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":903780,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Current = value.AsEnumValue($.$fsgt.LCIDTMC.TerrameterMeasurementCurrent);
                        }, $PnxlJj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":903780,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("HighVoltage"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel.$type, $.$discardRef(), "HighVoltage", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("HighVoltage")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "HighVoltage";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel)).HighVoltage);
                        }, $AreYyh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":903780,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.HighVoltage = value.AsInt();
                        }, $QCYgyg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":903780,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CheckErrors"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel.$type, $.$discardRef(), "CheckErrors", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CheckErrors")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fsgt.LCIDTMC.TerrameterErrorChecks, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "CheckErrors";
                        $i11.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$fsgt.LCIDTMC.TerrameterErrorChecks, ($.$cast(target, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel)).CheckErrors);
                        }, $ZEKSlh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":903780,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CheckErrors = value.AsEnumValue($.$fsgt.LCIDTMC.TerrameterErrorChecks);
                        }, $JFwfDb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":903780,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ErtSpacings1"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel.$type, $.$discardRef(), "ErtSpacings1", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ErtSpacings1")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "ErtSpacings1";
                        $i13.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel)).ErtSpacings1);
                        }, $horKbc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":903780,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ErtSpacings1 = value.AsInt();
                        }, $PQsNEi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":903780,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ErtSpacings2"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel.$type, $.$discardRef(), "ErtSpacings2", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ErtSpacings2")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "ErtSpacings2";
                        $i15.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel)).ErtSpacings2);
                        }, $Uylscl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":903780,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ErtSpacings2 = value.AsInt();
                        }, $HPrJoh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":903780,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Command";
                        $i17.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel)).Command);
                        }, $ZHQRUa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":903780,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885805668)
            
            //--TRIMMABLE-BOUNDARY-START(17180772964)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180772964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Mode = _target.Mode;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Mode"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fsgt.LCIDTM.TerrameterMeasureMode));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fsgt.LCIDTM.TerrameterMeasureMode, () => _Mode, ($v) => _Mode = $v, null, true)))
                    {
                        _target.Mode = _Mode;
                    }
                }
                {
                    /*var*/ let _MeasurementTime = _target.MeasurementTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MeasurementTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fsgt.LCIDTMC.TerrameterMeasurementTime));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fsgt.LCIDTMC.TerrameterMeasurementTime, () => _MeasurementTime, ($v) => _MeasurementTime = $v, null, true)))
                    {
                        _target.MeasurementTime = _MeasurementTime;
                    }
                }
                {
                    /*var*/ let _Cycles = _target.Cycles;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Cycles"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Cycles, ($v) => _Cycles = $v, $.$$.S.Int32)))
                    {
                        _target.Cycles = _Cycles;
                    }
                }
                {
                    /*var*/ let _Current = _target.Current;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Current"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fsgt.LCIDTMC.TerrameterMeasurementCurrent));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fsgt.LCIDTMC.TerrameterMeasurementCurrent, () => _Current, ($v) => _Current = $v, null, true)))
                    {
                        _target.Current = _Current;
                    }
                }
                {
                    /*var*/ let _HighVoltage = _target.HighVoltage;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("HighVoltage"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _HighVoltage, ($v) => _HighVoltage = $v, $.$$.S.Int32)))
                    {
                        _target.HighVoltage = _HighVoltage;
                    }
                }
                {
                    /*var*/ let _CheckErrors = _target.CheckErrors;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CheckErrors"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fsgt.LCIDTMC.TerrameterErrorChecks));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fsgt.LCIDTMC.TerrameterErrorChecks, () => _CheckErrors, ($v) => _CheckErrors = $v, null, true)))
                    {
                        _target.CheckErrors = _CheckErrors;
                    }
                }
                {
                    /*var*/ let _ErtSpacings1 = _target.ErtSpacings1;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ErtSpacings1"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _ErtSpacings1, ($v) => _ErtSpacings1 = $v, $.$$.S.Int32)))
                    {
                        _target.ErtSpacings1 = _ErtSpacings1;
                    }
                }
                {
                    /*var*/ let _ErtSpacings2 = _target.ErtSpacings2;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ErtSpacings2"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _ErtSpacings2, ($v) => _ErtSpacings2 = $v, $.$$.S.Int32)))
                    {
                        _target.ErtSpacings2 = _ErtSpacings2;
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180772964)
            
            //--TRIMMABLE-BOUNDARY-START(8590838372)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590838372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel)))
                {
                    /*var*/ let result = $.$fsgt.LCIDTMC.TerrameterMeasureCommandModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590838372)
            
            static $h = 903780;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTMC.TerrameterMeasureCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885805668),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 903780,
      "h": 12885805668,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885805668),
//--TRIMMABLE-BOUNDARY-START(17180772964),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 772708,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 903780,
      "h": 17180772964,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180772964),
//--TRIMMABLE-BOUNDARY-START(8590838372),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 772708,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 903780,
      "h": 8590838372,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590838372)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295871076),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 903780,
      "h": 4295871076,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295871076)
  ],
  "h": 903780
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$fsgt.LCIDTMC.TerrameterMeasureCommandModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommandModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterMeasureCommandModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(903780)
        
        

        //--TRIMMABLE-BOUNDARY-START(1624676)
        $asm.$cls(`$fsgt.LCIDTMC.TerrameterUnlockCommandModelTypeDescriptor`, ($self) => class TerrameterUnlockCommandModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTMC.TerrameterUnlockCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296591972)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296591972);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$fsgt.LCIDTMC.TerrameterUnlockCommandModelTypeDescriptor.GenerateProperties($.$fsgt.LCIDTMC.TerrameterUnlockCommandModel, this, factory);
                    }, $RjrQrh ??= {"r":65537,"n":"","d":1624676,"h":0,"f":17825794}), 0, "TerrameterUnlockCommandModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Terrameter\\Models_Commands_TerrameterUnlockCommandModel_LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterUnlockCommandModelTypeDescriptorBuilder.g.cs", "TerrameterUnlockCommandModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296591972)
            
            //--TRIMMABLE-BOUNDARY-START(12886526564)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886526564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Times"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMC.TerrameterUnlockCommandModel.$type, $.$discardRef(), "Times", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Times")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Times";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterUnlockCommandModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterUnlockCommandModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$fsgt.LCIDTMC.TerrameterUnlockCommandModel)).Times);
                        }, $kBUBvj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1624676,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterUnlockCommandModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Times = value.AsInt();
                        }, $YCYtYh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1624676,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMC.TerrameterUnlockCommandModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Command";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterUnlockCommandModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMC.TerrameterUnlockCommandModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$fsgt.LCIDTMC.TerrameterUnlockCommandModel)).Command);
                        }, $sZOFbd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1624676,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886526564)
            
            //--TRIMMABLE-BOUNDARY-START(17181493860)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterUnlockCommandModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181493860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Times = _target.Times;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Times"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Times, ($v) => _Times = $v, $.$$.S.Int32)))
                    {
                        _target.Times = _Times;
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181493860)
            
            //--TRIMMABLE-BOUNDARY-START(8591559268)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterUnlockCommandModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591559268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$fsgt.LCIDTMC.TerrameterUnlockCommandModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$fsgt.LCIDTMC.TerrameterUnlockCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTMC.TerrameterUnlockCommandModel)))
                {
                    /*var*/ let result = $.$fsgt.LCIDTMC.TerrameterUnlockCommandModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTMC.TerrameterUnlockCommandModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$fsgt.LCIDTMC.TerrameterUnlockCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTMC.TerrameterUnlockCommandModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591559268)
            
            static $h = 1624676;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTMC.TerrameterUnlockCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886526564),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1624676,
      "h": 12886526564,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886526564),
//--TRIMMABLE-BOUNDARY-START(17181493860),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1493604,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1624676,
      "h": 17181493860,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181493860),
//--TRIMMABLE-BOUNDARY-START(8591559268),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1493604,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1624676,
      "h": 8591559268,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591559268)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296591972),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1624676,
      "h": 4296591972,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296591972)
  ],
  "h": 1624676
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$fsgt.LCIDTMC.TerrameterUnlockCommandModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterUnlockCommandModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterUnlockCommandModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1624676)
        
        

        //--TRIMMABLE-BOUNDARY-START(2083428)
        $asm.$cls(`$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor`, ($self) => class TerrameterStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTMS.TerrameterStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297050724)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297050724);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor.GenerateProperties($.$fsgt.LCIDTMS.TerrameterStatusModel, this, factory);
                    }, $OLnQTc ??= {"r":65537,"n":"","d":2083428,"h":0,"f":17825794}), 0, "TerrameterStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Terrameter\\Models_Statuses_TerrameterStatusModel_LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterStatusModelTypeDescriptorBuilder.g.cs", "TerrameterStatusModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297050724)
            
            //--TRIMMABLE-BOUNDARY-START(12886985316)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886985316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Token"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMS.TerrameterStatusModel.$type, $.$discardRef(), "Token", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Token")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Token";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$fsgt.LCIDTMS.TerrameterStatusModel)).Token);
                        }, $VNkqUj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2083428,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Token = value.AsInt();
                        }, $mcCGRg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2083428,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BatteryVoltage"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMS.TerrameterStatusModel.$type, $.$discardRef(), "BatteryVoltage", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BatteryVoltage")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "BatteryVoltage";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$fsgt.LCIDTMS.TerrameterStatusModel)).BatteryVoltage);
                        }, $bTDUsf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2083428,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.BatteryVoltage = value.AsDouble();
                        }, $Dlurze ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2083428,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ChargerVoltage"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMS.TerrameterStatusModel.$type, $.$discardRef(), "ChargerVoltage", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ChargerVoltage")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "ChargerVoltage";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterStatusModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$fsgt.LCIDTMS.TerrameterStatusModel)).ChargerVoltage);
                        }, $bndivd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2083428,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ChargerVoltage = value.AsDouble();
                        }, $IVIyOe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2083428,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MNVoltage"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMS.TerrameterStatusModel.$type, $.$discardRef(), "MNVoltage", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MNVoltage")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "MNVoltage";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterStatusModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$fsgt.LCIDTMS.TerrameterStatusModel)).MNVoltage);
                        }, $dgVBOf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2083428,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.MNVoltage = value.AsDouble();
                        }, $koqxCc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2083428,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ABCurrent"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMS.TerrameterStatusModel.$type, $.$discardRef(), "ABCurrent", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ABCurrent")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "ABCurrent";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterStatusModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$fsgt.LCIDTMS.TerrameterStatusModel)).ABCurrent);
                        }, $QvpGQd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2083428,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ABCurrent = value.AsDouble();
                        }, $XiJZvf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2083428,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MeasurementData"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTMS.TerrameterStatusModel.$type, $.$discardRef(), "MeasurementData", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MeasurementData")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.Byte), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "MeasurementData";
                        $i11.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterStatusModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.Byte), ($.$cast(target, $.$fsgt.LCIDTMS.TerrameterStatusModel)).MeasurementData);
                        }, $MtBNZk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2083428,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.MeasurementData = value.AsReference($.$typeArray($.$$.S.Byte));
                        }, $TlrsUj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2083428,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886985316)
            
            //--TRIMMABLE-BOUNDARY-START(17181952612)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181952612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _Token = _target.Token;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Token"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Token, ($v) => _Token = $v, $.$$.S.Int32)))
                    {
                        _target.Token = _Token;
                    }
                }
                {
                    /*var*/ let _BatteryVoltage = _target.BatteryVoltage;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BatteryVoltage"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _BatteryVoltage, ($v) => _BatteryVoltage = $v, $.$$.S.Double)))
                    {
                        _target.BatteryVoltage = _BatteryVoltage;
                    }
                }
                {
                    /*var*/ let _ChargerVoltage = _target.ChargerVoltage;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ChargerVoltage"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _ChargerVoltage, ($v) => _ChargerVoltage = $v, $.$$.S.Double)))
                    {
                        _target.ChargerVoltage = _ChargerVoltage;
                    }
                }
                {
                    /*var*/ let _MNVoltage = _target.MNVoltage;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MNVoltage"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _MNVoltage, ($v) => _MNVoltage = $v, $.$$.S.Double)))
                    {
                        _target.MNVoltage = _MNVoltage;
                    }
                }
                {
                    /*var*/ let _ABCurrent = _target.ABCurrent;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ABCurrent"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _ABCurrent, ($v) => _ABCurrent = $v, $.$$.S.Double)))
                    {
                        _target.ABCurrent = _ABCurrent;
                    }
                }
                {
                    /*var*/ let _MeasurementData = _target.MeasurementData;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MeasurementData"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.Byte)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.Byte), $.$$.S.Byte));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.Byte), $.$$.S.Byte, property, $.$ref(() => _MeasurementData, ($v) => _MeasurementData = $v, $.$typeArray($.$$.S.Byte))))
                    {
                        _target.MeasurementData = _MeasurementData;
                        if (_MeasurementData !== null)
                        {
                            let $i21 = 0;
                            let $arr21 = _MeasurementData;
                            while ($i21 < $arr21.length)
                            {
                                let item = $arr21[$i21++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.Byte)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.Byte), $.$$.S.Byte, property, $.$ref(() => _MeasurementData, ($v) => _MeasurementData = $v, $.$typeArray($.$$.S.Byte)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181952612)
            
            //--TRIMMABLE-BOUNDARY-START(8592018020)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592018020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$fsgt.LCIDTMS.TerrameterStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$fsgt.LCIDTMS.TerrameterStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTMS.TerrameterStatusModel)))
                {
                    /*var*/ let result = $.$fsgt.LCIDTMS.TerrameterStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTMS.TerrameterStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$fsgt.LCIDTMS.TerrameterStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTMS.TerrameterStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592018020)
            
            static $h = 2083428;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTMS.TerrameterStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886985316),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2083428,
      "h": 12886985316,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886985316),
//--TRIMMABLE-BOUNDARY-START(17181952612),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1952356,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2083428,
      "h": 17181952612,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181952612),
//--TRIMMABLE-BOUNDARY-START(8592018020),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1952356,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2083428,
      "h": 8592018020,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592018020)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297050724),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2083428,
      "h": 4297050724,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297050724)
  ],
  "h": 2083428
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$fsgt.LCIDTMS.TerrameterStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Statuses${separator}TerrameterStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2083428)
        
        

        //--TRIMMABLE-BOUNDARY-START(3132004)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterLogModelTypeDescriptor`, ($self) => class TerrameterLogModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTM.TerrameterLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298099300)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298099300);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$fsgt.LCIDTM.TerrameterLogModelTypeDescriptor.GenerateProperties($.$fsgt.LCIDTM.TerrameterLogModel, this, factory);
                    }, $biczqb ??= {"r":65537,"n":"","d":3132004,"h":0,"f":17825794}), 0, "TerrameterLogModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Terrameter\\Models_TerrameterLogModel_LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterLogModelTypeDescriptorBuilder.g.cs", "TerrameterLogModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298099300)
            
            //--TRIMMABLE-BOUNDARY-START(12888033892)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888033892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceLogModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888033892)
            
            //--TRIMMABLE-BOUNDARY-START(17183001188)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterLogModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183001188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceLogModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceLogModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceLogModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183001188)
            
            //--TRIMMABLE-BOUNDARY-START(8593066596)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterLogModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593066596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$fsgt.LCIDTM.TerrameterLogModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$fsgt.LCIDTM.TerrameterLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTM.TerrameterLogModel)))
                {
                    /*var*/ let result = $.$fsgt.LCIDTM.TerrameterLogModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTM.TerrameterLogModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$fsgt.LCIDTM.TerrameterLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTM.TerrameterLogModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593066596)
            
            static $h = 3132004;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTM.TerrameterLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888033892),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3132004,
      "h": 12888033892,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888033892),
//--TRIMMABLE-BOUNDARY-START(17183001188),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3000932,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3132004,
      "h": 17183001188,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183001188),
//--TRIMMABLE-BOUNDARY-START(8593066596),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3000932,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3132004,
      "h": 8593066596,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593066596)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298099300),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3132004,
      "h": 4298099300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298099300)
  ],
  "h": 3132004
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$fsgt.LCIDTM.TerrameterLogModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterLogModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterLogModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3132004)
        
        

        //--TRIMMABLE-BOUNDARY-START(1428068)
        $asm.$cls(`$fsgt.LCIDTMC.TerrameterUnlockCommand`, ($self) => class TerrameterUnlockCommand extends $.$XBGm.LCICDiC.iSmartDeviceCommand$$($.$fsgt.LCIDTMC.TerrameterUnlockCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296395364)
            $ctor$5()
            {
                super.$ctor$4("Unlock", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296395364);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296395364)
            
            //--TRIMMABLE-BOUNDARY-START(17181297252)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-lock"/*MaterialDesignIconNames.Lock*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17181297252)
            
            //--TRIMMABLE-BOUNDARY-START(4296395364)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296395364)
            
            static $h = 1428068;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceCommand$$($.$fsgt.LCIDTMC.TerrameterUnlockCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181297252),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886329956,
        "f": 50364417
      },
      "n": "Icon",
      "d": 1428068,
      "h": 17181297252,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17181297252)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296395364),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1428068,
      "h": 4296395364,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296395364)
  ],
  "h": 1428068
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterUnlockCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterUnlockCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1428068)
        
        

        //--TRIMMABLE-BOUNDARY-START(510564)
        $asm.$cls(`$fsgt.LCIDTMC.TerrameterDeviceCommands<>`, (TDevice) => $asm.$gt(`$fsgt.LCIDTMC.TerrameterDeviceCommands<>`, [TDevice], ($self) => class TerrameterDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12885412452)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12885412452)
            
            //--TRIMMABLE-BOUNDARY-START(17180379748)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel?*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180379748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$fsgt.LCIDTMC.TerrameterDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17180379748)
            
            //--TRIMMABLE-BOUNDARY-START(8590445156)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590445156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590445156)
            
            //--TRIMMABLE-BOUNDARY-START(8590445156)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590445156)
            
            //--TRIMMABLE-BOUNDARY-START(4295477860)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295477860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885412452)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [new $.$fsgt.LCIDTMC.TerrameterMeasureCommand().$ctor$6()], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12885412452)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295477860)
            
            static $H = 510564;
            static $h = 510564;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180379748),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17180379748,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180379748)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885412452),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12885412452,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885412452)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590445156),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8590445156,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590445156)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 510564,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(510564)
        
        

        //--TRIMMABLE-BOUNDARY-START(707172)
        $asm.$cls(`$fsgt.LCIDTMC.TerrameterMeasureCommand`, ($self) => class TerrameterMeasureCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$fsgt.LCIDTMC.TerrameterMeasureCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295674468)
            $ctor$6()
            {
                super.$ctor$5("Measure", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295674468);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295674468)
            
            //--TRIMMABLE-BOUNDARY-START(17180576356)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-counter"/*MaterialDesignIconNames.Counter*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17180576356)
            
            //--TRIMMABLE-BOUNDARY-START(4295674468)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295674468)
            
            static $h = 707172;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$fsgt.LCIDTMC.TerrameterMeasureCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180576356),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885609060,
        "f": 50364417
      },
      "n": "Icon",
      "d": 707172,
      "h": 17180576356,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180576356)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295674468),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 707172,
      "h": 4295674468,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295674468)
  ],
  "h": 707172
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.Commands.TerrameterMeasureCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}Commands${separator}TerrameterMeasureCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(707172)
        
        

        //--TRIMMABLE-BOUNDARY-START(2738788)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterDeviceSendDataModel`, ($self) => class TerrameterDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceCommandsModel
        {
            //--TRIMMABLE-BOUNDARY-START(8592673380)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592673380);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592673380)
            
            //--TRIMMABLE-BOUNDARY-START(12887640676)
            $ctor$5(/*TerrameterMeasureCommandModel*/ measure)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887640676);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Measure = measure;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887640676)
            
            //--TRIMMABLE-BOUNDARY-START(25772542564)
            /*TerrameterMeasureCommandModel?*/ Measure = null;
            //--TRIMMABLE-BOUNDARY-END(25772542564)
            
            //--TRIMMABLE-BOUNDARY-START(8592673380)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8592673380)
            
            static $h = 2738788;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandsModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772542564),
    {
      "p": 772708,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477575268,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34362477156,
        "f": 83886081
      },
      "n": "Measure",
      "d": 2738788,
      "h": 25772542564,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 13432,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25772542564)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592673380),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2738788,
      "h": 8592673380,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592673380),
//--TRIMMABLE-BOUNDARY-START(12887640676),
    {
      "p": [
        {
          "n": "measure",
          "p": 772708
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2738788,
      "h": 12887640676,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887640676)
  ],
  "h": 2738788
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2738788)
        
        

        //--TRIMMABLE-BOUNDARY-START(2869860)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterDeviceSendDataModelTypeDescriptor`, ($self) => class TerrameterDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTM.TerrameterDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297837156)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297837156);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$fsgt.LCIDTM.TerrameterDeviceSendDataModelTypeDescriptor.GenerateProperties($.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, this, factory);
                    }, $vExkEk ??= {"r":65537,"n":"","d":2869860,"h":0,"f":17825794}), 0, "TerrameterDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Terrameter\\Models_TerrameterDeviceSendDataModel_LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceSendDataModelTypeDescriptorBuilder.g.cs", "TerrameterDeviceSendDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297837156)
            
            //--TRIMMABLE-BOUNDARY-START(12887771748)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887771748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Measure"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel.$type, $.$discardRef(), "Measure", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Measure")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fsgt.LCIDTMC.TerrameterMeasureCommandModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Measure";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceSendDataModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTM.TerrameterDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$fsgt.LCIDTMC.TerrameterMeasureCommandModel, ($.$cast(target, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel)).Measure);
                        }, $xRDDLj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2869860,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTM.TerrameterDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Measure = value.AsReference($.$fsgt.LCIDTMC.TerrameterMeasureCommandModel);
                        }, $hVCxdg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2869860,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887771748)
            
            //--TRIMMABLE-BOUNDARY-START(17182739044)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182739044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandsModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandsModel));
                {
                    /*var*/ let _Measure = _target.Measure;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Measure"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fsgt.LCIDTMC.TerrameterMeasureCommandModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Measure, ($v) => _Measure = $v, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel)))
                    {
                        _target.Measure = _Measure;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182739044)
            
            //--TRIMMABLE-BOUNDARY-START(8592804452)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592804452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$fsgt.LCIDTM.TerrameterDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592804452)
            
            static $h = 2869860;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTM.TerrameterDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887771748),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2869860,
      "h": 12887771748,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887771748),
//--TRIMMABLE-BOUNDARY-START(17182739044),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2738788,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2869860,
      "h": 17182739044,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182739044),
//--TRIMMABLE-BOUNDARY-START(8592804452),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2738788,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2869860,
      "h": 8592804452,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592804452)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297837156),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2869860,
      "h": 4297837156,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297837156)
  ],
  "h": 2869860
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$fsgt.LCIDTM.TerrameterDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2869860)
        
        

        //--TRIMMABLE-BOUNDARY-START(2214500)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel`, ($self) => class TerrameterDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$fsgt.LCIDTMS.TerrameterStatusModel, $.$fsgt.LCIDTM.TerrameterLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297181796)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297181796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297181796)
            
            //--TRIMMABLE-BOUNDARY-START(4297181796)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4297181796)
            
            static $h = 2214500;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$fsgt.LCIDTMS.TerrameterStatusModel, $.$fsgt.LCIDTM.TerrameterLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297181796),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2214500,
      "h": 4297181796,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297181796)
  ],
  "h": 2214500
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder, $.$fPer.LCFCD.IChartableData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2214500)
        
        

        //--TRIMMABLE-BOUNDARY-START(2345572)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterDeviceReceivedDataModelTypeDescriptor`, ($self) => class TerrameterDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297312868)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297312868);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, this, factory);
                    }, $lGowMh ??= {"r":65537,"n":"","d":2345572,"h":0,"f":17825794}), 0, "TerrameterDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Terrameter\\Models_TerrameterDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "TerrameterDeviceReceivedDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297312868)
            
            //--TRIMMABLE-BOUNDARY-START(12887247460)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887247460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$fsgt.LCIDTMS.TerrameterStatusModel, $.$fsgt.LCIDTM.TerrameterLogModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887247460)
            
            //--TRIMMABLE-BOUNDARY-START(17182214756)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182214756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.Terrameter.Models.Statuses.TerrameterStatusModel, LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterLogModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$fsgt.LCIDTMS.TerrameterStatusModel, $.$fsgt.LCIDTM.TerrameterLogModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$fsgt.LCIDTMS.TerrameterStatusModel, $.$fsgt.LCIDTM.TerrameterLogModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182214756)
            
            //--TRIMMABLE-BOUNDARY-START(8592280164)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592280164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592280164)
            
            static $h = 2345572;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887247460),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2345572,
      "h": 12887247460,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887247460),
//--TRIMMABLE-BOUNDARY-START(17182214756),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2214500,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2345572,
      "h": 17182214756,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182214756),
//--TRIMMABLE-BOUNDARY-START(8592280164),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2214500,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2345572,
      "h": 8592280164,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592280164)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297312868),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2345572,
      "h": 4297312868,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297312868)
  ],
  "h": 2345572
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2345572)
        
        

        //--TRIMMABLE-BOUNDARY-START(4639332)
        $asm.$cls(`$fsgt.LCIDT.TerrameterDataConverter`, ($self) => class TerrameterDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299606628)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299606628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299606628)
            
            //--TRIMMABLE-BOUNDARY-START(4299606628)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299606628)
            
            static $h = 4639332;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299606628),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4639332,
      "h": 4299606628,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299606628)
  ],
  "h": 4639332
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.TerrameterDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}TerrameterDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4639332)
        
        

        $asm.$typeProxy("$fsgt.LCIDTM.TerrameterDeviceScopeModel", "$fsgt.LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceScopeModel");
        $asm.$typeProxy("$fsgt.LCIDT.TerrameterDeviceModel", "$fsgt.LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceModel");
        $asm.$typeProxy("$fsgt.LCIDTS$1.TerrameterDeviceSettings", "$fsgt.LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceSettings");
        $asm.$typeProxy("$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings", "$fsgt.LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceHardwareSettings");
        $asm.$typeProxy("$fsgt.LCIDTS.ITerrameterDeviceStatusHandler", "$fsgt.LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterDeviceStatusHandler");
        $asm.$typeProxy("$fsgt.LCIDTS.ITerrameterDeviceHubClient", "$fsgt.LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterDeviceHubClient");
        $asm.$typeProxy("$fsgt.LCIDTS.ITerrameterRemoteService", "$fsgt.LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterRemoteService");
        //--TRIMMABLE-BOUNDARY-START(3394148)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterServiceModel`, ($self) => class TerrameterServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298361444)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298361444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298361444)
            
            //--TRIMMABLE-BOUNDARY-START(4298361444)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4298361444)
            
            static $h = 3394148;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298361444),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 3394148,
      "h": 4298361444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298361444)
  ],
  "h": 3394148
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3394148)
        
        

        //--TRIMMABLE-BOUNDARY-START(4049508)
        $asm.$cls(`$fsgt.LCIDTS.ITerrameterRemoteService`, ($self) => class ITerrameterRemoteService
        {
            static $h = 4049508;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 4049508
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$fsgt.LCIDTM.TerrameterServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$fsgt.LCIDTM.TerrameterServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$fsgt.LCIDTM.TerrameterServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$fsgt.LCIDTM.TerrameterServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$fsgt.LCIDTM.TerrameterServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$fsgt.LCIDTM.TerrameterServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$fsgt.LCIDTM.TerrameterServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$fsgt.LCIDTM.TerrameterServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Services${separator}ITerrameterRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4049508)
        
        

        //--TRIMMABLE-BOUNDARY-START(4901476)
        $asm.$cls(`$fsgt.LCIDT.TerrameterDeviceModel`, ($self) => class TerrameterDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4299868772)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299868772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299868772)
            
            //--TRIMMABLE-BOUNDARY-START(4299868772)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4299868772)
            
            static $h = 4901476;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299868772),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 4901476,
      "h": 4299868772,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299868772)
  ],
  "h": 4901476
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}TerrameterDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4901476)
        
        

        //--TRIMMABLE-BOUNDARY-START(2476644)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterDeviceScopeModel`, ($self) => class TerrameterDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297443940)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297443940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297443940)
            
            //--TRIMMABLE-BOUNDARY-START(4297443940)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4297443940)
            
            static $h = 2476644;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297443940),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 2476644,
      "h": 4297443940,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297443940)
  ],
  "h": 2476644
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2476644)
        
        

        //--TRIMMABLE-BOUNDARY-START(3983972)
        $asm.$cls(`$fsgt.LCIDTS.ITerrameterDeviceStatusHandler`, ($self) => class ITerrameterDeviceStatusHandler
        {
            static $h = 3983972;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3983972
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Services${separator}ITerrameterDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3983972)
        
        

        //--TRIMMABLE-BOUNDARY-START(3918436)
        $asm.$cls(`$fsgt.LCIDTS.ITerrameterDeviceHubClient`, ($self) => class ITerrameterDeviceHubClient
        {
            static $h = 3918436;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3918436
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Services${separator}ITerrameterDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3918436)
        
        

        //--TRIMMABLE-BOUNDARY-START(4115044)
        $asm.$cls(`$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings`, ($self) => class TerrameterDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(21478951524)
            /*IOTDeviceInternalConfiguration<bool>*/ Sample = null;
            //--TRIMMABLE-BOUNDARY-END(21478951524)
            
            //--TRIMMABLE-BOUNDARY-START(8594049636)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594049636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594049636)
            
            //--TRIMMABLE-BOUNDARY-START(8594049636)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8594049636)
            
            static $h = 4115044;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21478951524),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183984228,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30068886116,
        "f": 83886081
      },
      "n": "Sample",
      "d": 4115044,
      "h": 21478951524,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "rem",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 20,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21478951524)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594049636),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4115044,
      "h": 8594049636,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594049636)
  ],
  "h": 4115044
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Settings${separator}TerrameterDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4115044)
        
        

        //--TRIMMABLE-BOUNDARY-START(4377188)
        $asm.$cls(`$fsgt.LCIDTS$1.TerrameterDeviceSettings`, ($self) => class TerrameterDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $self, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(34364115556)
            /*bool*/ Invert = false;
            //--TRIMMABLE-BOUNDARY-END(34364115556)
            
            //--TRIMMABLE-BOUNDARY-START(38659082852)
            /*TerrameterMeasureMode*/ OnClick = 0;
            //--TRIMMABLE-BOUNDARY-END(38659082852)
            
            //--TRIMMABLE-BOUNDARY-START(12889279076)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889279076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12889279076)
            
            //--TRIMMABLE-BOUNDARY-START(12889279076)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12889279076)
            
            static $h = 4377188;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34364115556),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479213668,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47249017444,
        "f": 83886081
      },
      "n": "Invert",
      "d": 4377188,
      "h": 34364115556,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 256,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34364115556),
//--TRIMMABLE-BOUNDARY-START(38659082852),
    {
      "p": 3263076,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069148260,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55838952036,
        "f": 83886081
      },
      "n": "OnClick",
      "d": 4377188,
      "h": 38659082852,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 257,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38659082852)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12889279076),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4377188,
      "h": 12889279076,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889279076)
  ],
  "h": 4377188
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Settings${separator}TerrameterDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4377188)
        
        

        //--TRIMMABLE-BOUNDARY-START(5032548)
        $asm.$cls(`$fsgt.LCIDT.TerrameterDeviceModelDefinition`, ($self) => class TerrameterDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4299999844)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299999844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299999844)
            
            //--TRIMMABLE-BOUNDARY-START(4299999844)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299999844)
            
            static $h = 5032548;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299999844),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5032548,
      "h": 4299999844,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299999844)
  ],
  "h": 5032548
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}TerrameterDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5032548)
        
        

        //--TRIMMABLE-BOUNDARY-START(2607716)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterDeviceScopeModelTypeDescriptor`, ($self) => class TerrameterDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTM.TerrameterDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297575012)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297575012);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$fsgt.LCIDTM.TerrameterDeviceScopeModelTypeDescriptor.GenerateProperties($.$fsgt.LCIDTM.TerrameterDeviceScopeModel, this, factory);
                    }, $icTPdh ??= {"r":65537,"n":"","d":2607716,"h":0,"f":17825794}), 0, "TerrameterDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Terrameter\\Models_TerrameterDeviceScopeModel_LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceScopeModelTypeDescriptorBuilder.g.cs", "TerrameterDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297575012)
            
            //--TRIMMABLE-BOUNDARY-START(12887509604)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887509604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887509604)
            
            //--TRIMMABLE-BOUNDARY-START(17182476900)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182476900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceModel, LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceSettings, LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceSendDataModel, LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterDeviceStatusHandler, LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterDeviceHubClient, LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182476900)
            
            //--TRIMMABLE-BOUNDARY-START(8592542308)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592542308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$fsgt.LCIDTM.TerrameterDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel)))
                {
                    /*var*/ let result = $.$fsgt.LCIDTM.TerrameterDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592542308)
            
            static $h = 2607716;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTM.TerrameterDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887509604),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2607716,
      "h": 12887509604,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887509604),
//--TRIMMABLE-BOUNDARY-START(17182476900),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2476644,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2607716,
      "h": 17182476900,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182476900),
//--TRIMMABLE-BOUNDARY-START(8592542308),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2476644,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2607716,
      "h": 8592542308,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592542308)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297575012),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2607716,
      "h": 4297575012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297575012)
  ],
  "h": 2607716
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$fsgt.LCIDTM.TerrameterDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2607716)
        
        

        //--TRIMMABLE-BOUNDARY-START(5098084)
        $asm.$cls(`$fsgt.LCIDT.TerrameterDeviceModelTypeDescriptor`, ($self) => class TerrameterDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDT.TerrameterDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4300065380)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300065380);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$fsgt.LCIDT.TerrameterDeviceModelTypeDescriptor.GenerateProperties($.$fsgt.LCIDT.TerrameterDeviceModel, this, factory);
                    }, $avItwj ??= {"r":65537,"n":"","d":5098084,"h":0,"f":17825794}), 0, "TerrameterDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Terrameter\\TerrameterDeviceModel_LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceModelTypeDescriptorBuilder.g.cs", "TerrameterDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300065380)
            
            //--TRIMMABLE-BOUNDARY-START(12889999972)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889999972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889999972)
            
            //--TRIMMABLE-BOUNDARY-START(17184967268)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184967268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceModel, LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceSettings, LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceSendDataModel, LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterDeviceStatusHandler, LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterDeviceHubClient, LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184967268)
            
            //--TRIMMABLE-BOUNDARY-START(8595032676)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595032676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$fsgt.LCIDT.TerrameterDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$fsgt.LCIDT.TerrameterDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDT.TerrameterDeviceModel)))
                {
                    /*var*/ let result = $.$fsgt.LCIDT.TerrameterDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDT.TerrameterDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$fsgt.LCIDT.TerrameterDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDT.TerrameterDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595032676)
            
            static $h = 5098084;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDT.TerrameterDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889999972),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5098084,
      "h": 12889999972,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889999972),
//--TRIMMABLE-BOUNDARY-START(17184967268),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4901476,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5098084,
      "h": 17184967268,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184967268),
//--TRIMMABLE-BOUNDARY-START(8595032676),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4901476,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5098084,
      "h": 8595032676,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595032676)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300065380),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5098084,
      "h": 4300065380,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300065380)
  ],
  "h": 5098084
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$fsgt.LCIDT.TerrameterDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}TerrameterDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5098084)
        
        

        //--TRIMMABLE-BOUNDARY-START(3525220)
        $asm.$cls(`$fsgt.LCIDTM.TerrameterServiceModelTypeDescriptor`, ($self) => class TerrameterServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTM.TerrameterServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298492516)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298492516);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$fsgt.LCIDTM.TerrameterServiceModelTypeDescriptor.GenerateProperties($.$fsgt.LCIDTM.TerrameterServiceModel, this, factory);
                    }, $PAItge ??= {"r":65537,"n":"","d":3525220,"h":0,"f":17825794}), 0, "TerrameterServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Terrameter\\Models_TerrameterServiceModel_LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterServiceModelTypeDescriptorBuilder.g.cs", "TerrameterServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298492516)
            
            //--TRIMMABLE-BOUNDARY-START(12888427108)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888427108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888427108)
            
            //--TRIMMABLE-BOUNDARY-START(17183394404)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183394404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceModel, LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceSettings, LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceSendDataModel, LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterDeviceStatusHandler, LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterDeviceHubClient, LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183394404)
            
            //--TRIMMABLE-BOUNDARY-START(8593459812)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593459812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$fsgt.LCIDTM.TerrameterServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$fsgt.LCIDTM.TerrameterServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTM.TerrameterServiceModel)))
                {
                    /*var*/ let result = $.$fsgt.LCIDTM.TerrameterServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTM.TerrameterServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$fsgt.LCIDTM.TerrameterServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTM.TerrameterServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593459812)
            
            static $h = 3525220;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTM.TerrameterServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888427108),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3525220,
      "h": 12888427108,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888427108),
//--TRIMMABLE-BOUNDARY-START(17183394404),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3394148,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3525220,
      "h": 17183394404,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183394404),
//--TRIMMABLE-BOUNDARY-START(8593459812),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3394148,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3525220,
      "h": 8593459812,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593459812)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298492516),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3525220,
      "h": 4298492516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298492516)
  ],
  "h": 3525220
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$fsgt.LCIDTM.TerrameterServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Models${separator}TerrameterServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3525220)
        
        

        //--TRIMMABLE-BOUNDARY-START(4246116)
        $asm.$cls(`$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettingsTypeDescriptor`, ($self) => class TerrameterDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299213412)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299213412);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, this, factory);
                    }, $TPpXYb ??= {"r":65537,"n":"","d":4246116,"h":0,"f":17825794}), 0, "TerrameterDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Terrameter\\Settings_TerrameterDeviceHardwareSettings_LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "TerrameterDeviceHardwareSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299213412)
            
            //--TRIMMABLE-BOUNDARY-START(12889148004)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889148004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Sample"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings.$type, $.$discardRef(), "Sample", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Sample")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Sample";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceHardwareSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean), ($.$cast(target, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings)).Sample);
                        }, $nsyKPj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4246116,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettingsTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.Sample = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean));
                        }, $RLneDc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4246116,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889148004)
            
            //--TRIMMABLE-BOUNDARY-START(17184115300)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184115300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceModel, LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceSettings, LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceSendDataModel, LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterDeviceStatusHandler, LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterDeviceHubClient, LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).iSmartDeviceHardwareSettings));
                {
                    /*var*/ let _Sample = _target.Sample;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Sample"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Sample, ($v) => _Sample = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Boolean))))
                    {
                        _target.Sample = _Sample;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184115300)
            
            //--TRIMMABLE-BOUNDARY-START(8594180708)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594180708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594180708)
            
            static $h = 4246116;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889148004),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4246116,
      "h": 12889148004,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889148004),
//--TRIMMABLE-BOUNDARY-START(17184115300),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4115044,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4246116,
      "h": 17184115300,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184115300),
//--TRIMMABLE-BOUNDARY-START(8594180708),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4115044,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4246116,
      "h": 8594180708,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594180708)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299213412),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4246116,
      "h": 4299213412,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299213412)
  ],
  "h": 4246116
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Settings${separator}TerrameterDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4246116)
        
        

        //--TRIMMABLE-BOUNDARY-START(4508260)
        $asm.$cls(`$fsgt.LCIDTS$1.TerrameterDeviceSettingsTypeDescriptor`, ($self) => class TerrameterDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTS$1.TerrameterDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299475556)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299475556);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$fsgt.LCIDTS$1.TerrameterDeviceSettingsTypeDescriptor.GenerateProperties($.$fsgt.LCIDTS$1.TerrameterDeviceSettings, this, factory);
                    }, $tpkGZb ??= {"r":65537,"n":"","d":4508260,"h":0,"f":17825794}), 0, "TerrameterDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Terrameter\\Settings_TerrameterDeviceSettings_LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceSettingsTypeDescriptorBuilder.g.cs", "TerrameterDeviceSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299475556)
            
            //--TRIMMABLE-BOUNDARY-START(12889410148)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889410148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Invert"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings.$type, $.$discardRef(), "Invert", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Invert")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Invert";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTS$1.TerrameterDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings)).Invert);
                        }, $ZnOCCi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4508260,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTS$1.TerrameterDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Invert = value.AsBool();
                        }, $xwPami ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4508260,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("OnClick"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings.$type, $.$discardRef(), "OnClick", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("OnClick")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fsgt.LCIDTM.TerrameterMeasureMode, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "OnClick";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTS$1.TerrameterDeviceSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$fsgt.LCIDTM.TerrameterMeasureMode, ($.$cast(target, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings)).OnClick);
                        }, $WTsvWg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4508260,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$fsgt.LCIDTS$1.TerrameterDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.OnClick = value.AsEnumValue($.$fsgt.LCIDTM.TerrameterMeasureMode);
                        }, $JutIAb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4508260,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889410148)
            
            //--TRIMMABLE-BOUNDARY-START(17184377444)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184377444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceModel, LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceSettings, LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Terrameter.Models.TerrameterDeviceSendDataModel, LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterDeviceStatusHandler, LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterDeviceHubClient, LivingThing.Core.IOT.Devices.Terrameter.Services.ITerrameterRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService).iSmartDeviceSettings));
                {
                    /*var*/ let _Invert = _target.Invert;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Invert"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _Invert, ($v) => _Invert = $v, null, true)))
                    {
                        _target.Invert = _Invert;
                    }
                }
                {
                    /*var*/ let _OnClick = _target.OnClick;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("OnClick"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fsgt.LCIDTM.TerrameterMeasureMode));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fsgt.LCIDTM.TerrameterMeasureMode, () => _OnClick, ($v) => _OnClick = $v, null, true)))
                    {
                        _target.OnClick = _OnClick;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184377444)
            
            //--TRIMMABLE-BOUNDARY-START(8594442852)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594442852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$fsgt.LCIDTS$1.TerrameterDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings)))
                {
                    /*var*/ let result = $.$fsgt.LCIDTS$1.TerrameterDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594442852)
            
            static $h = 4508260;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$fsgt.LCIDTS$1.TerrameterDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889410148),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4508260,
      "h": 12889410148,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889410148),
//--TRIMMABLE-BOUNDARY-START(17184377444),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4377188,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4508260,
      "h": 17184377444,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184377444),
//--TRIMMABLE-BOUNDARY-START(8594442852),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4377188,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4508260,
      "h": 8594442852,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594442852)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299475556),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4508260,
      "h": 4299475556,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299475556)
  ],
  "h": 4508260
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$fsgt.LCIDTS$1.TerrameterDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Settings.TerrameterDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Settings${separator}TerrameterDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4508260)
        
        

        //--TRIMMABLE-BOUNDARY-START(4704868)
        $asm.$cls(`$fsgt.LCIDT.TerrameterDevice`, ($self) => class TerrameterDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$fsgt.LCIDTMS.TerrameterStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(17184574052)
            $ctor$2(/*IIOTDeviceFamily<TerrameterDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*TerrameterDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17184574052);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17184574052)
            
            //--TRIMMABLE-BOUNDARY-START(64429214308)
            /*Dictionary<int, TerrameterSelfPotentialData>*/ SelfPotential = null;
            //--TRIMMABLE-BOUNDARY-END(64429214308)
            
            //--TRIMMABLE-BOUNDARY-START(60134247012)
            /*Dictionary<int, TerrameterResistivityData>*/ Resistivities = null;
            //--TRIMMABLE-BOUNDARY-END(60134247012)
            
            //--TRIMMABLE-BOUNDARY-START(47249345124)
            /*Dictionary<int, TerrameterInducedPolarizationData>*/ InducedPolarizations = null;
            //--TRIMMABLE-BOUNDARY-END(47249345124)
            
            //--TRIMMABLE-BOUNDARY-START(55839279716)
            /*ValueTask */ RaisePropertyChanged(/*object?*/ sender, /*params string[]*/ names)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55839279716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.MemoryExtensions.Contains$2($.$$.S.String, $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1(names), "ReceivedStatus"))
                {
                    if ((this.Received?.Status?.MeasurementData ?? null) !== null)
                    {
                        /*var*/ let sequenceNumber;
                        /*var*/ let measureResult;
                        /*var*/ let errorValue;
                        /*var*/ let data = this.Received.Status.GetMeasurement($.$ref(() => sequenceNumber, ($v) => sequenceNumber = $v, $.$$.S.Int32), $.$ref(() => measureResult, ($v) => measureResult = $v, $.$typeNullable($.$fsgt.LCIDTMC.TerrameterMeasureResult)), $.$ref(() => errorValue, ($v) => errorValue = $v, $.$$.S.Double));
                        if (data.IsT0 && data.AsT0 !== null)
                        {
                            this.SelfPotential.set_Item(sequenceNumber, data.AsT0);
                        }
                        else if (data.IsT1 && data.AsT1 !== null)
                        {
                            this.Resistivities.set_Item(sequenceNumber, data.AsT1);
                        }
                        else if (data.IsT2 && data.AsT2 !== null)
                        {
                            this.InducedPolarizations.set_Item(sequenceNumber, data.AsT2);
                        }
                    }
                }
                return super.RaisePropertyChanged(sender, names);
            }
            //--TRIMMABLE-BOUNDARY-END(55839279716)
            
            //--TRIMMABLE-BOUNDARY-START(51544312420)
            /*Task */ Measure(/*TerrameterMeasureCommandModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51544312420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$fsgt.LCIDTMC.TerrameterMeasureCommand, $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel, this, new $.$fsgt.LCIDTMC.TerrameterMeasureCommand().$ctor$6(), model);
            }
            //--TRIMMABLE-BOUNDARY-END(51544312420)
            
            //--TRIMMABLE-BOUNDARY-START(68724181604)
            /*Task */ Unlock(/*TerrameterUnlockCommandModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68724181604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$fsgt.LCIDTMC.TerrameterUnlockCommand, $.$fsgt.LCIDTMC.TerrameterUnlockCommandModel, this, new $.$fsgt.LCIDTMC.TerrameterUnlockCommand().$ctor$5(), model);
            }
            //--TRIMMABLE-BOUNDARY-END(68724181604)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64429214308)
                this.SelfPotential = new ($.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$fsgt.LCIDTMS.TerrameterSelfPotentialData))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(64429214308)
                
                //--TRIMMABLE-BOUNDARY-START(60134247012)
                this.Resistivities = new ($.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$fsgt.LCIDTMS.TerrameterResistivityData))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(60134247012)
                
                //--TRIMMABLE-BOUNDARY-START(47249345124)
                this.InducedPolarizations = new ($.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$fsgt.LCIDTMS.TerrameterInducedPolarizationData))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(47249345124)
                
            }
            static $h = 4704868;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDT.TerrameterDevice, $.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$fsgt.LCIDTMS.TerrameterStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64429214308),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$fsgt.LCIDTMS.TerrameterSelfPotentialData).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42954377828,
        "f": 50331649
      },
      "n": "SelfPotential",
      "d": 4704868,
      "h": 64429214308,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64429214308),
//--TRIMMABLE-BOUNDARY-START(60134247012),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$fsgt.LCIDTMS.TerrameterResistivityData).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34364443236,
        "f": 50331649
      },
      "n": "Resistivities",
      "d": 4704868,
      "h": 60134247012,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60134247012),
//--TRIMMABLE-BOUNDARY-START(47249345124),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$fsgt.LCIDTMS.TerrameterInducedPolarizationData).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25774508644,
        "f": 50331649
      },
      "n": "InducedPolarizations",
      "d": 4704868,
      "h": 47249345124,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47249345124)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55839279716),
    {
      "r": 181338113,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "names",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "RaisePropertyChanged",
      "d": 4704868,
      "h": 55839279716,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55839279716),
//--TRIMMABLE-BOUNDARY-START(51544312420),
    {
      "r": 178454529,
      "p": [
        {
          "n": "model",
          "p": 772708
        }
      ],
      "n": "Measure",
      "d": 4704868,
      "h": 51544312420,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51544312420),
//--TRIMMABLE-BOUNDARY-START(68724181604),
    {
      "r": 178454529,
      "p": [
        {
          "n": "model",
          "p": 1493604
        }
      ],
      "n": "Unlock",
      "d": 4704868,
      "h": 68724181604,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68724181604)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17184574052),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$fsgt.LCIDT.TerrameterDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 4901476
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4704868,
      "h": 17184574052,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17184574052)
  ],
  "h": 4704868
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.TerrameterDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}TerrameterDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4704868)
        
        

        //--TRIMMABLE-BOUNDARY-START(4770404)
        $asm.$cls(`$fsgt.LCIDT.TerrameterDeviceDefinition`, ($self) => class TerrameterDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDT.TerrameterDevice, $.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$fsgt.LCIDTMS.TerrameterStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299737700)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299737700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299737700)
            
            //--TRIMMABLE-BOUNDARY-START(4299737700)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299737700)
            
            static $h = 4770404;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDT.TerrameterDevice, $.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$fsgt.LCIDTMS.TerrameterStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299737700),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4770404,
      "h": 4299737700,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299737700)
  ],
  "h": 4770404
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}TerrameterDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4770404)
        
        

        //--TRIMMABLE-BOUNDARY-START(4835940)
        $asm.$cls(`$fsgt.LCIDT.TerrameterDeviceFamily`, ($self) => class TerrameterDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDT.TerrameterDevice, $.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4299803236)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<TerrameterDeviceReceivedDataModel, TerrameterDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<TerrameterDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299803236);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299803236)
            
            //--TRIMMABLE-BOUNDARY-START(8594770532)
            /*Type */ get DeviceLogType()
            {
                return $.$fsgt.LCIDTM.TerrameterLogModel.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8594770532)
            
            static $h = 4835940;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$fsgt.LCIDT.TerrameterDevice, $.$fsgt.LCIDTM.TerrameterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$fsgt.LCIDTM.TerrameterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$fsgt.LCIDT.TerrameterDeviceModel, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel, $.$fsgt.LCIDTS.ITerrameterDeviceStatusHandler, $.$fsgt.LCIDTS.ITerrameterDeviceHubClient, $.$fsgt.LCIDTS.ITerrameterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8594770532),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17184705124,
        "f": 50364417
      },
      "n": "DeviceLogType",
      "d": 4835940,
      "h": 8594770532,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8594770532)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299803236),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4835940,
      "h": 4299803236,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299803236)
  ],
  "h": 4835940
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$fsgt.LCIDT.TerrameterDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$fsgt.LCIDT.TerrameterDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.TerrameterDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}TerrameterDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4835940)
        
        

        //--TRIMMABLE-BOUNDARY-START(5491300)
        $asm.$cls(`$fsgt.LCIDTV.TerrameterViewRenderer`, ($self) => class TerrameterViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$fsgt.LCIDT.TerrameterDevice, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4300458596)
            $ctor$3(/*IOTRootViewModel*/ root)
            {
                super.$ctor$2(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300458596);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300458596)
            
            //--TRIMMABLE-BOUNDARY-START(8595425892)
            /*RenderFragment? */ GetView(/*IClientUnitOfWork*/ ui, /*TerrameterDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>?*/ clicked, /*Func<Task>?*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595425892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === 3/*DeviceViewType.Details*/)
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$fsgt.LCIDTV.TerrameterDeviceDetails, $.$fsgt.LCIDTV.TerrameterDetailsViewModel, new $.$fsgt.LCIDTV.TerrameterDetailsViewModel().$ctor$9(this.Root, device.OwnerScope, device), true, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(8595425892)
            
            static $h = 5491300;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$fsgt.LCIDT.TerrameterDevice, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595425892),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 4704868
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 5491300,
      "h": 8595425892,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8595425892)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300458596),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5491300,
      "h": 4300458596,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300458596)
  ],
  "h": 5491300
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$fsgt.LCIDT.TerrameterDevice), $.$ntej.LCICD$1.IDeviceViewRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Views.TerrameterViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Views${separator}TerrameterViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5491300)
        
        

        //--TRIMMABLE-BOUNDARY-START(5294692)
        $asm.$cls(`$fsgt.LCIDTV.TerrameterDetailsViewModel`, ($self) => class TerrameterDetailsViewModel extends $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$fsgt.LCIDT.TerrameterDevice, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4300261988)
            $ctor$9(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*TerrameterDevice*/ device)
            {
                super.$ctor$8(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300261988);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300261988)
            
            //--TRIMMABLE-BOUNDARY-START(21480131172)
            /*string */ get Title()
            {
                return `${$.$strNN(this.Device$1.Model$1.Name)} (Terrameter)`;
            }
            //--TRIMMABLE-BOUNDARY-END(21480131172)
            
            //--TRIMMABLE-BOUNDARY-START(17185163876)
            /*Task */ Restart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185163876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    $.$XBGm.LCICDi.iSmartDeviceCommandExtension.Reset$2(this.Device$1);
                }
                catch($e)
                {
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(17185163876)
            
            static $h = 5294692;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$fsgt.LCIDT.TerrameterDevice, $.$fsgt.LCIDTS$1.TerrameterDeviceSettings, $.$fsgt.LCIDTS$1.TerrameterDeviceHardwareSettings, $.$fsgt.LCIDTM.TerrameterDeviceReceivedDataModel, $.$fsgt.LCIDTM.TerrameterDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21480131172),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12890196580,
        "f": 50331649
      },
      "n": "Title",
      "d": 5294692,
      "h": 21480131172,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21480131172)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17185163876),
    {
      "r": 178454529,
      "n": "Restart",
      "d": 5294692,
      "h": 17185163876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17185163876)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300261988),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 4704868
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 5294692,
      "h": 4300261988,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300261988)
  ],
  "h": 5294692
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICDV.IDeviceDetailsViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Views.TerrameterDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Views${separator}TerrameterDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5294692)
        
        

        //--TRIMMABLE-BOUNDARY-START(5360228)
        $asm.$cls(`$fsgt.LCIDTV.TerrameterDeviceDetails`, ($self) => class TerrameterDeviceDetails extends $.$hDPm.LCFCC$1.BaseComponent$$($.$fsgt.LCIDTV.TerrameterDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(98789608036)
            /*string */ get OptimizedComponentName()
            {
                return "terrameterdevicedetails";
            }
            //--TRIMMABLE-BOUNDARY-END(98789608036)
            
            //--TRIMMABLE-BOUNDARY-START(150329215588)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150329215588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$fsgt.LCIDTV.TerrameterDetailsViewModel);
                    return true;
                    case "Page":
                    this.Page = $.$cast(parameter.Value, $.$lJUR.LCFCS.IApplicationPageContext);
                    return true;
                    case "Layout":
                    this.Layout = $.$cast(parameter.Value, $.$lJUR.LCFCS.ApplicationLayout);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(150329215588)
            
            //--TRIMMABLE-BOUNDARY-START(167509084772)
            /*TerrameterDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(167509084772)
            
            //--TRIMMABLE-BOUNDARY-START(103084575332)
            /*IApplicationPageContext?*/ Page = null;
            //--TRIMMABLE-BOUNDARY-END(103084575332)
            
            //--TRIMMABLE-BOUNDARY-START(81609738852)
            /*ApplicationLayout?*/ Layout = null;
            //--TRIMMABLE-BOUNDARY-END(81609738852)
            
            //--TRIMMABLE-BOUNDARY-START(90199673444)
            /*TerrameterMeasureCommandModel*/ measureConfig = null;
            //--TRIMMABLE-BOUNDARY-END(90199673444)
            
            //--TRIMMABLE-BOUNDARY-START(137444313700)
            /*void */ SP()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137444313700);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.measureConfig.Mode = 1/*TerrameterMeasureMode.SelfPotential*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137444313700)
            
            //--TRIMMABLE-BOUNDARY-START(107379542628)
            /*void */ RES()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107379542628);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.measureConfig.Mode = 2/*TerrameterMeasureMode.Resistivity*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107379542628)
            
            //--TRIMMABLE-BOUNDARY-START(77314771556)
            /*void */ IP()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77314771556);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.measureConfig.Mode = 3/*TerrameterMeasureMode.InducedPolarization*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77314771556)
            
            //--TRIMMABLE-BOUNDARY-START(30070131300)
            /*void */ ERT()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30070131300);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.measureConfig.Mode = 4/*TerrameterMeasureMode.ElectricalResistivityTomography*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30070131300)
            
            //--TRIMMABLE-BOUNDARY-START(146034248292)
            /*string*/ tokenSeed = null;
            //--TRIMMABLE-BOUNDARY-END(146034248292)
            
            //--TRIMMABLE-BOUNDARY-START(141739280996)
            /*string*/ testToken = null;
            //--TRIMMABLE-BOUNDARY-END(141739280996)
            
            //--TRIMMABLE-BOUNDARY-START(163214117476)
            /*bool*/ unlockCodeSent = false;
            //--TRIMMABLE-BOUNDARY-END(163214117476)
            
            //--TRIMMABLE-BOUNDARY-START(158919150180)
            /*string?*/ unlockCode = null;
            //--TRIMMABLE-BOUNDARY-END(158919150180)
            
            //--TRIMMABLE-BOUNDARY-START(85904706148)
            /*Task *//*async*/  Lock()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85904706148);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = this.ViewModel.Device$1.Unlock((() =>
                    {
                        //new $.$fsgt.LCIDTMC.TerrameterUnlockCommandModel()
                        const $t3 = $.$fsgt.LCIDTMC.TerrameterUnlockCommandModel;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Times = 1;
                        return $i3;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85904706148)
            
            //--TRIMMABLE-BOUNDARY-START(154624182884)
            /*Task *//*async*/  Unlock()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154624182884);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.unlockCodeSent = false;
                    if (!$.$$.S.String.IsNullOrEmpty(this.unlockCode))
                    {
                        /*long*/ let usageCount;
                        if ($.$fsgt.LCIDT.SecureTokenManager.TryVerifyAndDecodeToken(this.unlockCode, this.tokenSeed, BigInt(60 * 60), $.$ref(() => usageCount, ($v) => usageCount = $v, $.$$.S.Int64)))
                        {
                            let $t5, $r5;
                            ($t5 = this.ViewModel.Device$1.Unlock((() =>
                            {
                                //new $.$fsgt.LCIDTMC.TerrameterUnlockCommandModel()
                                const $t6 = $.$fsgt.LCIDTMC.TerrameterUnlockCommandModel;
                                const $i6 = new $t6();
                                $i6.$ctor$2();
                                $i6.Times = $.$cast(usageCount, $.$$.S.Int32);
                                return $i6;
                            })()), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                            this.unlockCodeSent = true;
                        }
                        else 
                        {
                            this.NotifyError("Invalid code", null);
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(154624182884)
            
            //--TRIMMABLE-BOUNDARY-START(25775164004)
            /*Pager<ISelectOption<int>>*/ cycles = null;
            //--TRIMMABLE-BOUNDARY-END(25775164004)
            
            //--TRIMMABLE-BOUNDARY-START(73019804260)
            /*Task */ GO()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73019804260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ViewModel.Device$1.Measure(this.measureConfig);
            }
            //--TRIMMABLE-BOUNDARY-END(73019804260)
            
            //--TRIMMABLE-BOUNDARY-START(94494640740)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94494640740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.tokenSeed = $.$strNN($.$strNN(this.ViewModel.Device$1.UniqueId) + "/") + $.$strNN($.$fPer.LCFCS$6.StringExtension.GetRandomString(8, true, true, false));
                this.cycles = $.$fPer.LCFCD.Paging.GetPager($.$fPer.LCFC.ISelectOption$$($.$$.S.Int32), $.$sl.SL.Enumerable.ToList($.$fPer.LCFC.ISelectOption$$($.$$.S.Int32), $.$sl.SL.Enumerable.Select$1($.$$.S.Int32, $.$fPer.LCFC.ISelectOption$$($.$$.S.Int32), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [-1, 1, 2, 3, 4, 5, 6, 7], [-1], null), new ($.$$.S.Func$$$($.$$.S.Int32, $.$fPer.LCFC.ISelectOption$$($.$$.S.Int32)))().$ctor(this,  (/**/ v) =>
                {
                    return (() =>
                    {
                        //new $.$fPer.LCFC.SelectOption$$($.$$.S.Int32)()
                        const $t7 = $.$fPer.LCFC.SelectOption$$($.$$.S.Int32);
                        const $i7 = new $t7();
                        $i7.$ctor$3(v);
                        $i7.Title = v === -1 ? "LOOP" : $.$$.S.Int32.ToString.call(v);
                        $i7.Default = v === -1;
                        return $i7;
                    })();
                }, $Zolhra ??= {"r":$.$fPer.LCFC.ISelectOption$$($.$$.S.Int32).$h,"p":[{"n":"v","p":655361}],"n":"","d":5360228,"h":0,"f":17825794}))), null);
                let pg;
                if ($.$is(this.Page, $.$lJUR.LCFCS.ApplicationPageFactoryContext$$($.$NXre.LCID.SmartDeviceBase), { set $v($v){ pg = $v; } }))
                {
                    pg.FloatingButtons = new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext)))().$ctor(this,  (/**/ c) =>
                    {
                        return this.FloatingButton();
                    }, $GGuSKg ??= {"r":6881395,"p":[{"n":"c","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext).$h}],"n":"","d":5360228,"h":0,"f":17825794});
                }
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(94494640740)
            
            //--TRIMMABLE-BOUNDARY-START(21480196708)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21480196708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$fsgt.LCIDT.TerrameterDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$fsgt.LCIDT.TerrameterDevice), this.ViewModel));
                __builder.AddComponentParameter(2, "home-class", "bg-card scroll");
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    if ((this.ViewModel.Device$1.Received?.Status?.IsLockedOut() ?? null) === true)
                    {
                        __builder2.OpenElement(4, "div");
                        __builder2.AddAttribute$5(5, "class", "hf flex bg-card");
                        __builder2.OpenElement(6, "div");
                        __builder2.AddAttribute$5(7, "class", "mg-a pd-10");
                        if (!this.unlockCodeSent)
                        {
                            __builder2.OpenElement(8, "h3");
                            __builder2.AddContent$4(9, "Meter is locked! ");
                            __builder2.AddContent$4(10, this.testToken);
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(11, "\r\n                    ");
                            __builder2.OpenElement(12, "p");
                            __builder2.AddContent$4(13, "Contact SIT support with this code ");
                            __builder2.OpenElement(14, "b");
                            __builder2.AddContent$4(15, this.tokenSeed);
                            __builder2.CloseElement();
                            __builder2.AddContent$4(16, " to request for an unlock code.");
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(17, "\r\n                    ");
                            __builder2.OpenElement(18, "input");
                            __builder2.AddAttribute$5(19, "type", "text");
                            __builder2.AddAttribute$5(20, "class", "pd");
                            __builder2.AddAttribute$5(21, "placeholder", "Unlock Code here");
                            __builder2.AddAttribute$5(22, "value", $.$mac.MAC.BindConverter.FormatValue$28(this.unlockCode, null));
                            __builder2.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 23, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$28($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                return this.unlockCode = __value;
                            }, $hitRgi ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":5360228,"h":0,"f":17825794}), this.unlockCode, null));
                            __builder2.SetUpdatesAttributeName("value");
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(24, "\r\n                    ");
                            __builder2.OpenElement(25, "button");
                            __builder2.AddAttribute$5(26, "class", "bg-primary corner-5 fw-bold pd miwx-1 sd mgt");
                            __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 27, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Unlock)));
                            __builder2.AddMarkupContent(28, "<i class=\"mgr-2 mdi mdi-lock-open\"></i>\r\n                        ");
                            __builder2.AddMarkupContent(29, "<span class=\"nowrap\">Unlock</span>");
                            __builder2.CloseElement();
                        }
                        else 
                        {
                            __builder2.AddMarkupContent(30, "<h3>Unlock code sent!</h3>\r\n                    ");
                            __builder2.AddMarkupContent(31, "<p>Error code will clear in a moment</p>");
                        }
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }
                    else 
                    {
                        /*var*/ let sequenceNumber;
                        /*var*/ let measureResult;
                        /*var*/ let errorValue;
                        __builder2.OpenElement(32, "div");
                        __builder2.AddAttribute$5(33, "class", "bdb scroll");
                        __builder2.OpenElement(34, "div");
                        __builder2.AddAttribute$5(35, "class", "flex pd");
                        __builder2.OpenElement(36, "div");
                        __builder2.AddAttribute$5(37, "class", "fill mgx");
                        __builder2.OpenElement(38, "button");
                        __builder2.AddAttribute$5(39, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("bg-success" + $.$strNN((this.measureConfig.Mode !== 1/*TerrameterMeasureMode.SelfPotential*/ ? "-02" : ""))) + " corner-5") + " fw-bold") + " pdx") + " pdy-1") + " miwx-1") + " sd") + " nowrap");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 40, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.SP)));
                        __builder2.AddMarkupContent(41, "<i class=\"mgr-2 mdi mdi-chart-line\"></i>\r\n                        ");
                        __builder2.AddMarkupContent(42, "<span class=\"nowrap\">Self Potential</span>");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(43, "\r\n                ");
                        __builder2.OpenElement(44, "div");
                        __builder2.AddAttribute$5(45, "class", "fill mgx");
                        __builder2.OpenElement(46, "button");
                        __builder2.AddAttribute$5(47, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("bg-success" + $.$strNN((this.measureConfig.Mode !== 2/*TerrameterMeasureMode.Resistivity*/ ? "-02" : ""))) + " corner-5") + " fw-bold") + " pdx") + " pdy-1") + " miwx-1") + " sd") + " nowrap");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 48, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.RES)));
                        __builder2.AddMarkupContent(49, "<i class=\"mgr-2 mdi mdi-chart-areaspline\"></i>\r\n                        ");
                        __builder2.AddMarkupContent(50, "<span class=\"nowrap\">Resistivity</span>");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(51, "\r\n                ");
                        __builder2.OpenElement(52, "div");
                        __builder2.AddAttribute$5(53, "class", "fill mgx");
                        __builder2.OpenElement(54, "button");
                        __builder2.AddAttribute$5(55, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("bg-success" + $.$strNN((this.measureConfig.Mode !== 3/*TerrameterMeasureMode.InducedPolarization*/ ? "-02" : ""))) + " corner-5") + " fw-bold") + " pdx") + " pdy-1") + " miwx-1") + " sd") + " nowrap");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 56, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.IP)));
                        __builder2.AddMarkupContent(57, "<i class=\"mgr-2 mdi mdi-chart-bell-curve\"></i>\r\n                        ");
                        __builder2.AddMarkupContent(58, "<span class=\"nowrap\">Induced Polarization</span>");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(59, "\r\n                ");
                        __builder2.OpenElement(60, "div");
                        __builder2.AddAttribute$5(61, "class", "fill mgx");
                        __builder2.OpenElement(62, "button");
                        __builder2.AddAttribute$5(63, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("bg-success" + $.$strNN((this.measureConfig.Mode !== 4/*TerrameterMeasureMode.ElectricalResistivityTomography*/ ? "-02" : ""))) + " corner-5") + " fw-bold") + " pdx") + " pdy-1") + " miwx-1") + " sd") + " nowrap");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 64, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ERT)));
                        __builder2.AddMarkupContent(65, "<i class=\"mgr-2 mdi mdi-chart-bell-curve-cumulative\"></i>\r\n                        ");
                        __builder2.AddMarkupContent(66, "<span class=\"nowrap\">ERT</span>");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        /*var*/ let ab = this.measureConfig.Mode === 2/*TerrameterMeasureMode.Resistivity*/ || this.measureConfig.Mode === 3/*TerrameterMeasureMode.InducedPolarization*/ || this.measureConfig.Mode === 4/*TerrameterMeasureMode.ElectricalResistivityTomography*/;
                        /*var*/ let mn = true;
                        /*var*/ let measurement = this.ViewModel.Device$1.Received.Status.GetMeasurement($.$ref(() => sequenceNumber, ($v) => sequenceNumber = $v, $.$$.S.Int32), $.$ref(() => measureResult, ($v) => measureResult = $v, $.$typeNullable($.$fsgt.LCIDTMC.TerrameterMeasureResult)), $.$ref(() => errorValue, ($v) => errorValue = $v, $.$$.S.Double));
                        /*bool*/ let isMobile = (this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false;
                        __builder2.OpenElement(67, "div");
                        __builder2.AddAttribute$5(68, "class", "stack mgt");
                        __builder2.OpenElement(69, "div");
                        __builder2.AddAttribute$5(70, "class", "row");
                        if (!isMobile)
                        {
                            __builder2.OpenElement(71, "div");
                            __builder2.AddAttribute$5(72, "class", "col-1 flex");
                            if (ab)
                            {
                                __builder2.AddMarkupContent(73, "<div class=\"fill\"></div>\r\n                            <div style=\"width: 17px;\"></div>\r\n                            ");
                                __builder2.AddMarkupContent(74, "<div class=\"fill stack\"><div class=\"bdb bdw-2 mgt-a bd-error\"></div></div>");
                            }
                            __builder2.CloseElement();
                        }
                        __builder2.OpenElement(75, "div");
                        __builder2.AddAttribute$5(76, "class", $.$strNN("col-" + $.$strNN((isMobile ? "10 mgx-2" : "8"))) + " flex");
                        __builder2.OpenElement(77, "div");
                        __builder2.AddAttribute$5(78, "class", "fill bd bdw-2 bd-success bg-success-01 mgx-a corner-t stack");
                        __builder2.OpenComponent$1($.$macw.MACF.EditForm, 79);
                        __builder2.AddComponentParameter(80, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.measureConfig));
                        __builder2.AddComponentParameter(81, "class", "row col-3 pd");
                        __builder2.AddAttribute$3(82, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenElement(83, "div");
                                __builder3.AddAttribute$5(84, "class", "mgy-a stack");
                                __builder3.AddMarkupContent(85, "<small>Cycles</small>\r\n                                ");
                                __builder3.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$($.$$.S.Int32), 86);
                                __builder3.AddComponentParameter(87, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCI$1.InputEditorFeatures, 4131/*InputEditorFeatures.Default*/ & ~32/*InputEditorFeatures.Pad*/), $.$hDPm.LCFCCI$1.InputEditorFeatures));
                                __builder3.AddComponentParameter(88, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.InputType, 21n), $.$fPer.LCFC.InputType));
                                __builder3.AddComponentParameter(89, "PlaceHolder", "Cycles");
                                __builder3.AddComponentParameter(90, "Options", (this.cycles));
                                __builder3.AddComponentParameter(91, "Value", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, this.measureConfig.Cycles), $.$$.S.Int32));
                                __builder3.AddComponentParameter(92, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.Int32), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Int32, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Int32, this, new ($.$$.S.Action$$($.$$.S.Int32))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return this.measureConfig.Cycles = __value;
                                }, $MZYKGe ??= {"r":65537,"p":[{"n":"__value","p":655361}],"n":"","d":5360228,"h":0,"f":17825794}), this.measureConfig.Cycles))));
                                __builder3.AddComponentParameter(93, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.Int32)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                {
                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "measureConfig"), "Cycles"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                }, $gUpXJd ??= {"r":38797349,"n":"","d":5360228,"h":0,"f":17825794})).Invoke())));
                                __builder3.CloseComponent();
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(94, "\r\n                            ");
                                __builder3.OpenElement(95, "div");
                                __builder3.AddAttribute$5(96, "class", "mgl mgy-a stack");
                                __builder3.AddMarkupContent(97, "<small>Time</small>\r\n                                ");
                                $.$fsgt._LCIDTVT.TypeInference.CreateInputEditor_0($.$fsgt.LCIDTMC.TerrameterMeasurementTime, __builder3, 98, 99, 4131/*InputEditorFeatures.Default*/ & ~32/*InputEditorFeatures.Pad*/, 100, 21n, 101, "Measurement Time", 102, this.measureConfig.MeasurementTime, 103, $.$mac.MAC.EventCallback.Factory.Create$6($.$fsgt.LCIDTMC.TerrameterMeasurementTime, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$fsgt.LCIDTMC.TerrameterMeasurementTime, this, new ($.$$.S.Action$$($.$fsgt.LCIDTMC.TerrameterMeasurementTime))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return this.measureConfig.MeasurementTime = __value;
                                }, $mfapri ??= {"r":65537,"p":[{"n":"__value","p":1165924}],"n":"","d":5360228,"h":0,"f":17825794}), this.measureConfig.MeasurementTime)), 104, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                {
                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "measureConfig"), "MeasurementTime"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                }, $gAEjfe ??= {"r":38797349,"n":"","d":5360228,"h":0,"f":17825794})).Invoke()));
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(105, "\r\n                            ");
                                __builder3.OpenElement(106, "div");
                                __builder3.AddAttribute$5(107, "class", "mgl mgy-a stack");
                                __builder3.AddMarkupContent(108, "<small>Current</small>\r\n                                ");
                                $.$fsgt._LCIDTVT.TypeInference.CreateInputEditor_1($.$fsgt.LCIDTMC.TerrameterMeasurementCurrent, __builder3, 109, 110, 4131/*InputEditorFeatures.Default*/ & ~32/*InputEditorFeatures.Pad*/, 111, 21n, 112, "Measurement Current", 113, this.measureConfig.Current, 114, $.$mac.MAC.EventCallback.Factory.Create$6($.$fsgt.LCIDTMC.TerrameterMeasurementCurrent, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$fsgt.LCIDTMC.TerrameterMeasurementCurrent, this, new ($.$$.S.Action$$($.$fsgt.LCIDTMC.TerrameterMeasurementCurrent))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return this.measureConfig.Current = __value;
                                }, $PqKsfb ??= {"r":65537,"p":[{"n":"__value","p":1034852}],"n":"","d":5360228,"h":0,"f":17825794}), this.measureConfig.Current)), 115, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                {
                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "measureConfig"), "Current"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                }, $coGAGg ??= {"r":38797349,"n":"","d":5360228,"h":0,"f":17825794})).Invoke()));
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(116, "\r\n                            ");
                                __builder3.OpenElement(117, "div");
                                __builder3.AddAttribute$5(118, "class", "mgl mgy-a stack");
                                __builder3.AddMarkupContent(119, "<small>Error checks</small>\r\n                                ");
                                $.$fsgt._LCIDTVT.TypeInference.CreateInputEditor_2($.$fsgt.LCIDTMC.TerrameterErrorChecks, __builder3, 120, 121, 4131/*InputEditorFeatures.Default*/ & ~32/*InputEditorFeatures.Pad*/, 122, 24n, 123, "Check Errors", 124, this.measureConfig.CheckErrors, 125, $.$mac.MAC.EventCallback.Factory.Create$6($.$fsgt.LCIDTMC.TerrameterErrorChecks, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$fsgt.LCIDTMC.TerrameterErrorChecks, this, new ($.$$.S.Action$$($.$fsgt.LCIDTMC.TerrameterErrorChecks))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return this.measureConfig.CheckErrors = __value;
                                }, $Omvcse ??= {"r":65537,"p":[{"n":"__value","p":576100}],"n":"","d":5360228,"h":0,"f":17825794}), this.measureConfig.CheckErrors)), 126, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                {
                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "measureConfig"), "CheckErrors"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                }, $glFkyc ??= {"r":38797349,"n":"","d":5360228,"h":0,"f":17825794})).Invoke()));
                                __builder3.CloseElement();
                            }, $UpNCGf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                        }), $YuAsse ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":5360228,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(127, "\r\n                        ");
                        __builder2.OpenElement(128, "div");
                        __builder2.AddAttribute$5(129, "class", "flex pd");
                        /*var*/ let isError = measureResult !== null && measureResult !== 0/*TerrameterMeasureResult.Success*/;
                        __builder2.OpenElement(130, "div");
                        __builder2.AddAttribute$5(131, "class", "mg-a stack");
                        __builder2.OpenElement(132, "span");
                        __builder2.AddAttribute$5(133, "class", $.$strNN($.$strNN($.$strNN("mgx-a" + " fw-bold") + " fsz-25") + " ") + $.$strNN((isError ? "cl-error" : "cl-success")));
                        if (isError)
                        {
                            __builder2.AddContent$4(134, $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Nullable$$($.$fsgt.LCIDTMC.TerrameterMeasureResult).ToString.call(measureResult)));
                            if (measureResult === 1/*TerrameterMeasureResult.LowBatteryError*/)
                            {
                                __builder2.AddContent$4(135, "(");
                                __builder2.AddContent$4(136, $.$fPer.LCFCS$6.NumberExtension.FormatScientific(errorValue, "0.0", false));
                                __builder2.AddContent$4(137, "V)");
                            }
                            else if (measureResult === 5/*TerrameterMeasureResult.ABProbeError*/)
                            {
                                __builder2.AddContent$4(138, "(");
                                __builder2.AddContent$4(139, $.$fPer.LCFCS$6.NumberExtension.FormatScientific(errorValue, "0.0", false));
                                __builder2.AddContent$4(140, "A)");
                            }
                        }
                        else if (measurement.IsT0 && measurement.AsT0 !== null)
                        {
                            __builder2.AddContent$4(141, "SP = ");
                            __builder2.AddContent$4(142, $.$strNN($.$fPer.LCFCS$6.NumberExtension.FormatScientific(measurement.AsT0.Voltage, "0.0", false)) + "V");
                        }
                        else if (measurement.IsT1 && measurement.AsT1 !== null)
                        {
                            __builder2.AddContent$4(143, "RS = ");
                            __builder2.AddContent$4(144, $.$strNN($.$fPer.LCFCS$6.NumberExtension.FormatScientific(measurement.AsT1.GetResult(), "0.0", false)) + "\u03A9");
                        }
                        else if (measurement.IsT2 && measurement.AsT2 !== null)
                        {
                            __builder2.AddContent$4(145, "IP = ");
                            __builder2.AddContent$4(146, $.$strNN($.$fPer.LCFCS$6.NumberExtension.FormatScientific(measurement.AsT2.GetResult(), "0.0", false)) + "s");
                        }
                        else 
                        {
                            __builder2.AddContent$4(147, "SP = ");
                            __builder2.AddContent$4(148, $.$strNN($.$fPer.LCFCS$6.NumberExtension.FormatScientific(this.ViewModel.Device$1.Received.Status.MNVoltage, "0.0", false)) + "V");
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(149, "\r\n                                ");
                        __builder2.OpenElement(150, "small");
                        __builder2.AddAttribute$5(151, "class", "mgx-a op-8");
                        if (isError)
                        {
                        }
                        else if (measurement.IsT0 && measurement.AsT0 !== null)
                        {
                            __builder2.AddContent$4(152, "from ");
                            __builder2.AddContent$3(153, $.$box(measurement.AsT0.Samples, $.$$.S.Int32));
                            __builder2.AddContent$4(154, " samples");
                        }
                        else if (measurement.IsT1 && measurement.AsT1 !== null)
                        {
                            __builder2.AddContent$4(155, "from ");
                            __builder2.AddContent$3(156, $.$box(measurement.AsT1.PositiveSamples1, $.$$.S.Int32));
                            __builder2.AddContent$4(157, ", ");
                            __builder2.AddContent$3(158, $.$box(measurement.AsT1.NegativeSamples, $.$$.S.Int32));
                            __builder2.AddContent$4(159, ", ");
                            __builder2.AddContent$3(160, $.$box(measurement.AsT1.PositiveSamples2, $.$$.S.Int32));
                            __builder2.AddContent$4(161, " samples");
                        }
                        else if (measurement.IsT2 && measurement.AsT2 !== null)
                        {
                        }
                        else 
                        {
                        }
                        __builder2.CloseElement();
                        if ($.$$.S.Int32.op_GreaterThanOrEqual((this.ViewModel.Device$1.Received?.Status?.Token ?? null), 0))
                        {
                            __builder2.OpenElement(162, "small");
                            __builder2.AddAttribute$5(163, "class", "mgx-a");
                            __builder2.AddContent$3(164, $.$box((this.ViewModel.Device$1.Received?.Status?.Token ?? null), $.$$.S.Int32));
                            __builder2.AddContent$4(165, " tokens");
                            __builder2.CloseElement();
                        }
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(166, "\r\n                        ");
                        __builder2.OpenElement(167, "div");
                        __builder2.AddAttribute$5(168, "class", "row mgt-a");
                        __builder2.AddMarkupContent(169, "<div class=\"col-3 cl-primary fw-bold pdl\"><small>iSmart\u2122</small>\r\n                                <small>TMv402</small></div>");
                        if (mn)
                        {
                            __builder2.OpenElement(170, "div");
                            __builder2.AddAttribute$5(171, "class", "col-5 text-center");
                            __builder2.AddMarkupContent(172, "\r\n                                    MN = ");
                            __builder2.AddContent$4(173, $.$fPer.LCFCS$6.NumberExtension.FormatScientific(this.ViewModel.Device$1.Received.Status.MNVoltage, "0.0", false));
                            __builder2.AddMarkupContent(174, "V\r\n                                ");
                            __builder2.CloseElement();
                        }
                        __builder2.OpenElement(175, "div");
                        __builder2.AddAttribute$5(176, "class", "col-3 text-right pdr fw-bold");
                        __builder2.AddMarkupContent(177, "\r\n                                B = ");
                        __builder2.AddContent$4(178, $.$fPer.LCFCS$6.NumberExtension.FormatScientific(this.ViewModel.Device$1.Received.Status.BatteryVoltage, "0.0", false));
                        __builder2.AddMarkupContent(179, "V\r\n                            ");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        if (!isMobile)
                        {
                            __builder2.OpenElement(180, "div");
                            __builder2.AddAttribute$5(181, "class", "col-1 flex");
                            if (ab)
                            {
                                __builder2.AddMarkupContent(182, "<div class=\"fill stack\"><div class=\"bdb bdw-2 mgt-a bd-error\"></div></div>\r\n                            <div style=\"width: 17px;\"></div>\r\n                            <div class=\"fill\"></div>");
                            }
                            __builder2.CloseElement();
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(183, "\r\n            ");
                        __builder2.OpenElement(184, "div");
                        __builder2.AddAttribute$5(185, "class", "row");
                        __builder2.OpenElement(186, "div");
                        __builder2.AddAttribute$5(187, "class", "col-3 flex");
                        if (ab)
                        {
                            __builder2.OpenElement(188, "div");
                            __builder2.AddAttribute$5(189, "class", "mgx-a flex hx-1 pos-rel");
                            __builder2.AddAttribute$5(190, "style", "width: 17px;");
                            __builder2.OpenElement(191, "span");
                            __builder2.AddAttribute$5(192, "class", "pos-abs wx-1");
                            __builder2.AddAttribute$5(193, "style", "right:-230%;top:35%;transform:rotate(270deg)");
                            __builder2.OpenElement(194, "small");
                            __builder2.AddAttribute$5(195, "class", "nowrap wx-15");
                            __builder2.AddMarkupContent(196, "\r\n                                    250V @\r\n");
                            if (measurement.IsT1 && measurement.AsT1 !== null)
                            {
                                __builder2.AddContent$4(197, $.$strNN($.$fPer.LCFCS$6.NumberExtension.FormatScientific(measurement.AsT1.GetCurrent(), "0.0", false)) + "A");
                            }
                            else if (measurement.IsT2 && measurement.AsT2 !== null)
                            {
                                __builder2.AddContent$4(198, $.$strNN($.$fPer.LCFCS$6.NumberExtension.FormatScientific(measurement.AsT2.GetCurrent(), "0.0", false)) + "A");
                            }
                            else 
                            {
                                __builder2.AddContent$4(199, $.$strNN($.$fPer.LCFCS$6.NumberExtension.FormatScientific(this.ViewModel.Device$1.Received.Status.ABCurrent, "0.0", false)) + "A");
                            }
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(200, "\r\n                            <div class=\"mgl-a hx-1 bd bd-error bdl hf pos-rel\"></div>");
                            __builder2.CloseElement();
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(201, "\r\n                ");
                        __builder2.OpenElement(202, "div");
                        __builder2.AddAttribute$5(203, "class", "col-3 flex");
                        if (mn)
                        {
                            __builder2.AddMarkupContent(204, "<div class=\"mgx-a stack hx-1\" style=\"width: 17px;\"><div class=\"mgl-a hx-1 bd bd-primary bdl hf pos-rel\"></div></div>");
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(205, "\r\n                ");
                        __builder2.OpenElement(206, "div");
                        __builder2.AddAttribute$5(207, "class", "col-3 flex");
                        if (mn)
                        {
                            __builder2.AddMarkupContent(208, "<div class=\"mgx-a stack hx-1\" style=\"width: 17px;\"><div class=\"mgr-a hx-1 bd bd-primary bdr hf pos-rel\"></div></div>");
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(209, "\r\n                ");
                        __builder2.OpenElement(210, "div");
                        __builder2.AddAttribute$5(211, "class", "col-3 flex");
                        if (ab)
                        {
                            __builder2.OpenElement(212, "div");
                            __builder2.AddAttribute$5(213, "class", "mgx-a flex hx-1 pos-rel");
                            __builder2.AddAttribute$5(214, "style", "width: 17px;");
                            __builder2.OpenElement(215, "span");
                            __builder2.AddAttribute$5(216, "class", "pos-abs wx-1");
                            __builder2.AddAttribute$5(217, "style", "right:-245%;top:35%;transform:rotate(270deg)");
                            __builder2.OpenElement(218, "small");
                            __builder2.AddAttribute$5(219, "class", "nowrap");
                            __builder2.AddMarkupContent(220, "\r\n                                    0V @\r\n");
                            if (measurement.IsT1 && measurement.AsT1 !== null)
                            {
                                __builder2.AddContent$4(221, $.$strNN($.$fPer.LCFCS$6.NumberExtension.FormatScientific(measurement.AsT1.GetCurrent(), "0.0", false)) + "A");
                            }
                            else if (measurement.IsT2 && measurement.AsT2 !== null)
                            {
                                __builder2.AddContent$4(222, $.$strNN($.$fPer.LCFCS$6.NumberExtension.FormatScientific(measurement.AsT2.GetCurrent(), "0.0", false)) + "A");
                            }
                            else 
                            {
                                __builder2.AddContent$4(223, $.$strNN($.$fPer.LCFCS$6.NumberExtension.FormatScientific(this.ViewModel.Device$1.Received.Status.ABCurrent, "0.0", false)) + "A");
                            }
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(224, "\r\n                            <div class=\"mgr-a hx-1 bd bd-error bdl hf pos-rel\"></div>");
                            __builder2.CloseElement();
                        }
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(225, "\r\n            ");
                        __builder2.OpenElement(226, "div");
                        __builder2.AddAttribute$5(227, "class", "row");
                        __builder2.OpenElement(228, "div");
                        __builder2.AddAttribute$5(229, "class", "col-3 flex");
                        if (ab)
                        {
                            __builder2.AddMarkupContent(230, "<div class=\"mgx-a stack\"><div class=\"pos-rel bdr bdw-2 bd-error\"><b>A</b></div>\r\n                            <div class=\"stack hx-1\"><div style=\"width: 17px;\" class=\"hx-1 bg-error sd\"></div></div></div>");
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(231, "\r\n                ");
                        __builder2.OpenElement(232, "div");
                        __builder2.AddAttribute$5(233, "class", "col-3 flex");
                        if (mn)
                        {
                            __builder2.AddMarkupContent(234, "<div class=\"mgx-a stack\"><div class=\"pos-rel bdr bdw-2 bd-primary\"><b>M</b></div>\r\n                            <div class=\"stack hx-1\"><div style=\"width: 17px;\" class=\"hx-1 bg-primary sd\"></div></div></div>");
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(235, "\r\n                ");
                        __builder2.OpenElement(236, "div");
                        __builder2.AddAttribute$5(237, "class", "col-3 flex");
                        if (mn)
                        {
                            __builder2.AddMarkupContent(238, "<div class=\"mgx-a stack\"><div class=\"pos-rel bdl bdw-2 bd-primary\"><b>N</b></div>\r\n                            <div class=\"stack hx-1\"><div style=\"width: 17px;\" class=\"hx-1 bg-primary sd\"></div></div></div>");
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(239, "\r\n                ");
                        __builder2.OpenElement(240, "div");
                        __builder2.AddAttribute$5(241, "class", "col-3 flex");
                        if (ab)
                        {
                            __builder2.AddMarkupContent(242, "<div class=\"mgx-a stack\"><div class=\"pos-rel bdl bdw-2 bd-error\"><b>B</b></div>\r\n                            <div class=\"stack hx-1\"><div style=\"width: 17px;\" class=\"hx-1 bg-error sd\"></div></div></div>");
                        }
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(243, "\r\n            ");
                        __builder2.OpenElement(244, "div");
                        __builder2.AddAttribute$5(245, "class", "row bg-gray hx-2");
                        __builder2.OpenElement(246, "div");
                        __builder2.AddAttribute$5(247, "class", "col-3 flex");
                        if (ab)
                        {
                            __builder2.AddMarkupContent(248, "<div class=\"stack hx-1 mgx-a\"><div style=\"width: 17px;\" class=\"hx-1 bg-error sd\"></div>\r\n                            <div style=\"width: 17px;margin-top:0px;position: relative;left:1.5px\" class=\"tipdown tipdown-error bg-black\"></div></div>");
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(249, "\r\n                ");
                        __builder2.OpenElement(250, "div");
                        __builder2.AddAttribute$5(251, "class", "col-3 flex");
                        if (mn)
                        {
                            __builder2.AddMarkupContent(252, "<div class=\"stack hx-1 mgx-a\"><div style=\"width: 17px;\" class=\"hx-1 bg-primary sd\"></div>\r\n                            <div style=\"width: 17px;margin-top:0px;position: relative;left:1.5px\" class=\"tipdown tipdown-primary bg-black\"></div></div>");
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(253, "\r\n                ");
                        __builder2.OpenElement(254, "div");
                        __builder2.AddAttribute$5(255, "class", "col-3 flex");
                        if (mn)
                        {
                            __builder2.AddMarkupContent(256, "<div class=\"stack hx-1 mgx-a\"><div style=\"width: 17px;\" class=\"hx-1 bg-primary sd\"></div>\r\n                            <div style=\"width: 17px;margin-top:0px;position: relative;left:1.5px\" class=\"tipdown tipdown-primary bg-black\"></div></div>");
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(257, "\r\n                ");
                        __builder2.OpenElement(258, "div");
                        __builder2.AddAttribute$5(259, "class", "col-3 flex");
                        if (ab)
                        {
                            __builder2.AddMarkupContent(260, "<div class=\"stack hx-1 mgx-a\"><div style=\"width: 17px;\" class=\"hx-1 bg-error sd\"></div>\r\n                            <div style=\"width: 17px;margin-top:0px;position: relative;left:1.5px\" class=\"tipdown tipdown-error bg-black\"></div></div>");
                        }
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(261, "\r\n        ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCT$4.Themable, 262);
                        __builder2.AddAttribute$3(263, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors)))().$ctor(this, ( (/*theme*/ theme) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                if (this.measureConfig.Mode === 1/*TerrameterMeasureMode.SelfPotential*/)
                                {
                                    __builder3.OpenElement(264, "div");
                                    __builder3.AddAttribute$5(265, "class", "scroll-x");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCT.TableChart$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData), 266);
                                    __builder3.AddComponentParameter(267, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData), this.ViewModel.Device$1.SelfPotential.Values));
                                    __builder3.AddComponentParameter(268, "XLabel", "MN distance(m)");
                                    __builder3.AddComponentParameter(269, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$fsgt.LCIDTMS.TerrameterSelfPotentialData, $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*e*/ e) =>
                                    {
                                        return $.$$.S.Double.ToString.call(e.MNDistance);
                                    }), $nilemi ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"e","p":1886820}],"n":"","d":5360228,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(270, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData)))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCT.TableChartYAxis$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData), 271);
                                            __builder4.AddComponentParameter(272, "Label", "MN distance(m)");
                                            __builder4.AddComponentParameter(273, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT.TableChartFeatures, 1/*TableChartFeatures.Table*/), $.$hDPm.LCFCCT.TableChartFeatures));
                                            __builder4.AddAttribute$3(274, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData)))().$ctor(this, ( (/*item*/ item) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    $.$fsgt._LCIDTVT.TypeInference.CreateEditable_3($.$$.S.Double, __builder5, 275, 276, true, 277, item.Data.MNDistance, 278, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Double, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Double, this, new ($.$$.S.Action$$($.$$.S.Double))().$ctor(this,  (/*__value*/ __value) =>
                                                    {
                                                        return item.Data.MNDistance = __value;
                                                    }, $biSvja ??= {"r":65537,"p":[{"n":"__value","p":1179649}],"n":"","d":5360228,"h":0,"f":17825794}), item.Data.MNDistance)), 279, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                    {
                                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1($.$clone(item)), "Data"), "MNDistance"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                    }, $mkkjwk ??= {"r":38797349,"n":"","d":5360228,"h":0,"f":17825794})).Invoke()));
                                                }, $OKccze ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $eeaREd ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCI.ContainerContext$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                            __builder4.AddMarkupContent(280, "\r\n                        ");
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCT.TableChartYAxis$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData), 281);
                                            __builder4.AddComponentParameter(282, "Label", "SP");
                                            __builder4.AddComponentParameter(283, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData))().$ctor(this, ( (/*e*/ e) =>
                                            {
                                                return $.$box(e.LCFCCD$1$IDataListItemContext$$$Data.Voltage, $.$$.S.Double);
                                            }), $FTXqzf ??= {"r":131073,"p":[{"n":"e","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            const $t11 = () => theme.Data.ChartColors;
                                            __builder4.AddComponentParameter(284, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$ifnn($t11, ($t) => $.$$.System.Array.$ReadT1.call($t, 0))));
                                            const $t12 = () => theme.Data.ChartColors;
                                            __builder4.AddComponentParameter(285, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$ifnn($t12, ($t) => $.$$.System.Array.$ReadT1.call($t, 0))) + "80"));
                                            __builder4.AddAttribute$3(286, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData)))().$ctor(this, ( (/*item*/ item) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(287, $.$fPer.LCFCS$6.NumberExtension.FormatScientific(item.Data.Voltage, "0.0", false));
                                                    __builder5.AddMarkupContent(288, "V\r\n                            ");
                                                }, $dTotCg ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $dzSehj ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCI.ContainerContext$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                        }, $ZwqwPd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                    }), $lyvBii ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$fsgt.LCIDTMS.TerrameterSelfPotentialData).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.CloseElement();
                                }
                                else if (this.measureConfig.Mode === 2/*TerrameterMeasureMode.Resistivity*/)
                                {
                                    __builder3.OpenElement(289, "div");
                                    __builder3.AddAttribute$5(290, "class", "scroll-x");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTable$$($.$fsgt.LCIDTMS.TerrameterResistivityData), 291);
                                    __builder3.AddComponentParameter(292, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterResistivityData), this.ViewModel.Device$1.Resistivities.Values));
                                    __builder3.AddAttribute$3(293, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterResistivityData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData), 294);
                                            __builder4.AddAttribute$3(295, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterResistivityData)))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(296, "MN distance(m)");
                                                }, $yEiHbe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $TpTcSh ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterResistivityData).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.AddAttribute$3(297, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterResistivityData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData))))().$ctor(this, ( (/*item*/ item) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    $.$fsgt._LCIDTVT.TypeInference.CreateEditable_4($.$$.S.Double, __builder5, 298, 299, true, 300, item.Data.MNDistance, 301, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Double, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Double, this, new ($.$$.S.Action$$($.$$.S.Double))().$ctor(this,  (/*__value*/ __value) =>
                                                    {
                                                        return item.Data.MNDistance = __value;
                                                    }, $YeBqSb ??= {"r":65537,"p":[{"n":"__value","p":1179649}],"n":"","d":5360228,"h":0,"f":17825794}), item.Data.MNDistance)), 302, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                    {
                                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(item), "Data"), "MNDistance"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                    }, $LuYfkd ??= {"r":38797349,"n":"","d":5360228,"h":0,"f":17825794})).Invoke()));
                                                }, $vKZsed ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $IJIece ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterResistivityData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData)).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                            __builder4.AddMarkupContent(303, "\r\n                        ");
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData), 304);
                                            __builder4.AddAttribute$3(305, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterResistivityData)))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(306, "AB distance(m)");
                                                }, $SnRDva ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $oUZMyh ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterResistivityData).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.AddAttribute$3(307, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterResistivityData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData))))().$ctor(this, ( (/*item*/ item) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    $.$fsgt._LCIDTVT.TypeInference.CreateEditable_5($.$$.S.Double, __builder5, 308, 309, true, 310, item.Data.ABDistance, 311, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Double, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Double, this, new ($.$$.S.Action$$($.$$.S.Double))().$ctor(this,  (/*__value*/ __value) =>
                                                    {
                                                        return item.Data.ABDistance = __value;
                                                    }, $XvLwle ??= {"r":65537,"p":[{"n":"__value","p":1179649}],"n":"","d":5360228,"h":0,"f":17825794}), item.Data.ABDistance)), 312, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                    {
                                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(item), "Data"), "ABDistance"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                    }, $faerHi ??= {"r":38797349,"n":"","d":5360228,"h":0,"f":17825794})).Invoke()));
                                                }, $NikQIi ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $ADqgJi ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterResistivityData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData)).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                            __builder4.AddMarkupContent(313, "\r\n                        ");
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData), 314);
                                            __builder4.AddAttribute$3(315, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterResistivityData)))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(316, "Current");
                                                }, $RNJXmk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $vscwNi ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterResistivityData).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.AddAttribute$3(317, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterResistivityData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData))))().$ctor(this, ( (/*item*/ item) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(318, $.$fPer.LCFCS$6.NumberExtension.FormatScientific(item.Data.GetCurrent(), "0.0", false));
                                                    __builder5.AddMarkupContent(319, "A\r\n                            ");
                                                }, $euRDZd ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $RvFWjf ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterResistivityData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData)).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                            __builder4.AddMarkupContent(320, "\r\n                        ");
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData), 321);
                                            __builder4.AddAttribute$3(322, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterResistivityData)))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(323, "Voltage");
                                                }, $RYWvsk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $Epxhzb ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterResistivityData).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.AddAttribute$3(324, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterResistivityData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData))))().$ctor(this, ( (/*item*/ item) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(325, $.$fPer.LCFCS$6.NumberExtension.FormatScientific(item.Data.GetdV(), "0.0", false));
                                                    __builder5.AddMarkupContent(326, "V\r\n                            ");
                                                }, $HnYGBg ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $AGsjtk ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterResistivityData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData)).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                            __builder4.AddMarkupContent(327, "\r\n                        ");
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData), 328);
                                            __builder4.AddAttribute$3(329, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterResistivityData)))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(330, "Resitivity");
                                                }, $qzOgEi ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $XTikqg ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterResistivityData).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.AddAttribute$3(331, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterResistivityData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData))))().$ctor(this, ( (/*item*/ item) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(332, $.$fPer.LCFCS$6.NumberExtension.FormatScientific(item.Data.GetResult(), "0.0", false));
                                                    __builder5.AddMarkupContent(333, "\u03A9\r\n                            ");
                                                }, $JJFxEj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $YrTsQi ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterResistivityData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData)).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                        }, $uAgRll ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                    }), $kgYbCa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterResistivityData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterResistivityData)).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.CloseElement();
                                }
                                else if (this.measureConfig.Mode === 3/*TerrameterMeasureMode.InducedPolarization*/)
                                {
                                    __builder3.OpenElement(334, "div");
                                    __builder3.AddAttribute$5(335, "class", "scroll-x");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTable$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData), 336);
                                    __builder3.AddComponentParameter(337, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData), this.ViewModel.Device$1.InducedPolarizations.Values));
                                    __builder3.AddAttribute$3(338, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData), 339);
                                            __builder4.AddAttribute$3(340, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData)))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(341, "MN distance(m)");
                                                }, $uvIGEe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $Igzxre ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.AddAttribute$3(342, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData))))().$ctor(this, ( (/*item*/ item) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    $.$fsgt._LCIDTVT.TypeInference.CreateEditable_6($.$$.S.Double, __builder5, 343, 344, true, 345, item.Data.MNDistance, 346, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Double, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Double, this, new ($.$$.S.Action$$($.$$.S.Double))().$ctor(this,  (/*__value*/ __value) =>
                                                    {
                                                        return item.Data.MNDistance = __value;
                                                    }, $KZbPCd ??= {"r":65537,"p":[{"n":"__value","p":1179649}],"n":"","d":5360228,"h":0,"f":17825794}), item.Data.MNDistance)), 347, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                    {
                                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(item), "Data"), "MNDistance"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                    }, $DPVvMf ??= {"r":38797349,"n":"","d":5360228,"h":0,"f":17825794})).Invoke()));
                                                }, $IJNFVi ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $bLJfZg ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData)).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                            __builder4.AddMarkupContent(348, "\r\n                        ");
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData), 349);
                                            __builder4.AddAttribute$3(350, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData)))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(351, "AB distance(m)");
                                                }, $RlYogh ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $lbVGjf ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.AddAttribute$3(352, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData))))().$ctor(this, ( (/*item*/ item) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    $.$fsgt._LCIDTVT.TypeInference.CreateEditable_7($.$$.S.Double, __builder5, 353, 354, true, 355, item.Data.ABDistance, 356, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Double, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Double, this, new ($.$$.S.Action$$($.$$.S.Double))().$ctor(this,  (/*__value*/ __value) =>
                                                    {
                                                        return item.Data.ABDistance = __value;
                                                    }, $LVCErk ??= {"r":65537,"p":[{"n":"__value","p":1179649}],"n":"","d":5360228,"h":0,"f":17825794}), item.Data.ABDistance)), 357, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                    {
                                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(item), "Data"), "ABDistance"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                    }, $IuFFwh ??= {"r":38797349,"n":"","d":5360228,"h":0,"f":17825794})).Invoke()));
                                                }, $hpwkci ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $uOUskc ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData)).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                            __builder4.AddMarkupContent(358, "\r\n                        ");
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData), 359);
                                            __builder4.AddAttribute$3(360, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData)))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(361, "Current");
                                                }, $MjxEJb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $zBuHGk ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.AddAttribute$3(362, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData))))().$ctor(this, ( (/*item*/ item) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(363, $.$fPer.LCFCS$6.NumberExtension.FormatScientific(item.Data.GetCurrent(), "0.0", false));
                                                    __builder5.AddMarkupContent(364, "A\r\n                            ");
                                                }, $xOEWuc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $GNImDi ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData)).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                            __builder4.AddMarkupContent(365, "\r\n                        ");
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData), 366);
                                            __builder4.AddAttribute$3(367, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData)))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(368, "Voltage(Vm)");
                                                }, $hBDjlj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $ocsOog ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.AddAttribute$3(369, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData))))().$ctor(this, ( (/*item*/ item) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(370, $.$fPer.LCFCS$6.NumberExtension.FormatScientific(item.Data.GetVm(), "0.0", false));
                                                    __builder5.AddMarkupContent(371, "V\r\n                            ");
                                                }, $Wxcyag ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $mxjwzg ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData)).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                            __builder4.AddMarkupContent(372, "\r\n                        ");
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData), 373);
                                            __builder4.AddAttribute$3(374, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData)))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(375, "Voltage Integral(Vi)");
                                                }, $KduYdi ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $TxCsCe ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.AddAttribute$3(376, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData))))().$ctor(this, ( (/*item*/ item) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(377, $.$fPer.LCFCS$6.NumberExtension.FormatScientific(item.Data.GetVI(), "0.0", false));
                                                    __builder5.AddMarkupContent(378, "F\r\n                            ");
                                                }, $SQeksh ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $AGCMma ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData)).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                            __builder4.AddMarkupContent(379, "\r\n                        ");
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData), 380);
                                            __builder4.AddAttribute$3(381, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData)))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(382, "Resitivity");
                                                }, $cbQIfd ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $HzbwPg ??= {"r":6881395,"p":[{"n":"_","p":$.$$.SCG.IEnumerable$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.AddAttribute$3(383, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData))))().$ctor(this, ( (/*item*/ item) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddContent$4(384, $.$fPer.LCFCS$6.NumberExtension.FormatScientific(item.Data.GetResult(), "0.0", false));
                                                    __builder5.AddMarkupContent(385, "s\r\n                            ");
                                                }, $ighxEc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                            }), $UYvUwd ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData)).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                        }, $HWzFqa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                                    }), $CpKCwk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$fsgt.LCIDTMS.TerrameterInducedPolarizationData)).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.CloseElement();
                                }
                            }, $ifBuse ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
                        }), $jstgTb ??= {"r":6881395,"p":[{"n":"theme","p":$.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors).$h}],"n":"","d":5360228,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(386, "\r\n        <div class=\"mgb-20\"></div>");
                    }
                }), $DHKVYf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794}));
                __builder.CloseComponent();
                if ((this.ViewModel.Device$1.Received?.Status?.IsLockedOut() ?? null) === false)
                {
                    if (this.Layout !== null)
                    {
                        __builder.OpenComponent$1($.$mac.MACS.SectionContent, 387);
                        __builder.AddComponentParameter(388, "SectionName", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Layout.FloatingButtonSectionId));
                        __builder.AddAttribute$3(389, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                        {
                            __builder2.AddContent$1(390, this.FloatingButton());
                        }), $ykZYmf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794}));
                        __builder.CloseComponent();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21480196708)
            
            //--TRIMMABLE-BOUNDARY-START(34365098596)
            /*RenderFragment */ FloatingButton()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34365098596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(391, "div");
                    __builder2.AddAttribute$5(392, "class", "stack");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 393);
                    __builder2.AddComponentParameter(394, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder2.AddComponentParameter(395, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 132178/*ButtonFeatures.FloatingButton*/ | 8192/*ButtonFeatures.LoadingOnClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.AddComponentParameter(396, "Class", "mgb-20");
                    __builder2.AddComponentParameter(397, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.GO))));
                    __builder2.AddAttribute$3(398, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(399, "<i class=\"mg-a mdi mdi-run\"></i>");
                    }), $vtDEeg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                }, $axLPKa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":5360228,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(34365098596)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17185229412)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185229412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17185229412)
            
            //--TRIMMABLE-BOUNDARY-START(17185229412)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(17185229412)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(167509084772)
                this.ViewModel = null;
                //--TRIMMABLE-BOUNDARY-END(167509084772)
                
                //--TRIMMABLE-BOUNDARY-START(90199673444)
                this.measureConfig = new $.$fsgt.LCIDTMC.TerrameterMeasureCommandModel().$ctor$2();
                //--TRIMMABLE-BOUNDARY-END(90199673444)
                
                //--TRIMMABLE-BOUNDARY-START(146034248292)
                this.tokenSeed = null;
                //--TRIMMABLE-BOUNDARY-END(146034248292)
                
                //--TRIMMABLE-BOUNDARY-START(141739280996)
                this.testToken = null;
                //--TRIMMABLE-BOUNDARY-END(141739280996)
                
                //--TRIMMABLE-BOUNDARY-START(25775164004)
                this.cycles = null;
                //--TRIMMABLE-BOUNDARY-END(25775164004)
                
            }
            static $h = 5360228;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$fsgt.LCIDTV.TerrameterDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98789608036),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51544967780,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 5360228,
      "h": 98789608036,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(98789608036),
//--TRIMMABLE-BOUNDARY-START(167509084772),
    {
      "p": 5294692,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68724836964,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133149346404,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 5360228,
      "h": 167509084772,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167509084772),
//--TRIMMABLE-BOUNDARY-START(103084575332),
    {
      "p": 4730953,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60134902372,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124559411812,
        "f": 83886081
      },
      "n": "Page",
      "d": 5360228,
      "h": 103084575332,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103084575332),
//--TRIMMABLE-BOUNDARY-START(81609738852),
    {
      "p": 1257545,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42955033188,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115969477220,
        "f": 83886081
      },
      "n": "Layout",
      "d": 5360228,
      "h": 81609738852,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81609738852)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(150329215588),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 5360228,
      "h": 150329215588,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150329215588),
//--TRIMMABLE-BOUNDARY-START(137444313700),
    {
      "r": 65537,
      "n": "SP",
      "d": 5360228,
      "h": 137444313700,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137444313700),
//--TRIMMABLE-BOUNDARY-START(107379542628),
    {
      "r": 65537,
      "n": "RES",
      "d": 5360228,
      "h": 107379542628,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(107379542628),
//--TRIMMABLE-BOUNDARY-START(77314771556),
    {
      "r": 65537,
      "n": "IP",
      "d": 5360228,
      "h": 77314771556,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77314771556),
//--TRIMMABLE-BOUNDARY-START(30070131300),
    {
      "r": 65537,
      "n": "ERT",
      "d": 5360228,
      "h": 30070131300,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30070131300),
//--TRIMMABLE-BOUNDARY-START(85904706148),
    {
      "r": 178454529,
      "n": "Lock",
      "d": 5360228,
      "h": 85904706148,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(85904706148),
//--TRIMMABLE-BOUNDARY-START(154624182884),
    {
      "r": 178454529,
      "n": "Unlock",
      "d": 5360228,
      "h": 154624182884,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(154624182884),
//--TRIMMABLE-BOUNDARY-START(73019804260),
    {
      "r": 178454529,
      "n": "GO",
      "d": 5360228,
      "h": 73019804260,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73019804260),
//--TRIMMABLE-BOUNDARY-START(94494640740),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 5360228,
      "h": 94494640740,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(94494640740),
//--TRIMMABLE-BOUNDARY-START(21480196708),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 5360228,
      "h": 21480196708,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21480196708),
//--TRIMMABLE-BOUNDARY-START(34365098596),
    {
      "r": 6881395,
      "n": "FloatingButton",
      "d": 5360228,
      "h": 34365098596,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34365098596)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(90199673444),
    {
      "t": 772708,
      "n": "measureConfig",
      "d": 5360228,
      "h": 90199673444,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(90199673444),
//--TRIMMABLE-BOUNDARY-START(146034248292),
    {
      "t": 1310721,
      "n": "tokenSeed",
      "d": 5360228,
      "h": 146034248292,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(146034248292),
//--TRIMMABLE-BOUNDARY-START(141739280996),
    {
      "t": 1310721,
      "n": "testToken",
      "d": 5360228,
      "h": 141739280996,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(141739280996),
//--TRIMMABLE-BOUNDARY-START(163214117476),
    {
      "t": 262145,
      "n": "unlockCodeSent",
      "d": 5360228,
      "h": 163214117476,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(163214117476),
//--TRIMMABLE-BOUNDARY-START(158919150180),
    {
      "t": 1310721,
      "n": "unlockCode",
      "d": 5360228,
      "h": 158919150180,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(158919150180),
//--TRIMMABLE-BOUNDARY-START(25775164004),
    {
      "t": $.$fPer.LCFCD.Pager$$($.$fPer.LCFC.ISelectOption$$($.$$.S.Int32)).$h,
      "n": "cycles",
      "d": 5360228,
      "h": 25775164004,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25775164004)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17185229412),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 5360228,
      "h": 17185229412,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17185229412)
  ],
  "h": 5360228
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCC$1.IManagedBaseComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Terrameter.Views.TerrameterDeviceDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Terrameter${separator}Views${separator}TerrameterDeviceDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5360228)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(51812)
