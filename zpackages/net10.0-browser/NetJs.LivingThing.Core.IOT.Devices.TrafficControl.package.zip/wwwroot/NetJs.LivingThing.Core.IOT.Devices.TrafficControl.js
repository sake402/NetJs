
//--TRIMMABLE-BOUNDARY-START(62803)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $vDnyvd;
    let $JguSVa;
    let $UCtfRd;
    let $SAfHxj;
    let $TsCuEa;
    let $DkaSLj;
    let $ScpCwd;
    let $ihMaNc;
    let $LLgeia;
    let $vvGQMe;
    let $rrScHk;
    let $vushak;
    let $GnSIrf;
    let $LIjPpc;
    let $kWGrTh;
    let $kQpUZj;
    let $Noqbof;
    let $CHnoki;
    let $tlrUpd;
    let $NZNeJj;
    let $IuWXmh;
    let $RJKsca;
    let $KgyVnj;
    let $GKZkei;
    let $tDjpFc;
    let $uGvMzf;
    let $JbswSd;
    let $brzVsb;
    let $SgVJUc;
    let $ZREMFa;
    let $kWzhnb;
    let $dlCYAi;
    let $PXSkmb;
    let $DkMBvf;
    let $bkqQqd;
    let $pMBBJf;
    let $qhqUKf;
    let $WYExWj;
    let $LJHdEc;
    let $MMCOMc;
    let $THKYhg;
    let $UGgHhc;
    let $kIVoza;
    let $GtJyaj;
    let $bBRqce;
    let $BEebri;
    let $GBfVcb;
    let $JrzeAj;
    let $ONxpXi;
    let $WcMYWb;
    let $MGooee;
    let $ltdywb;
    let $swEnWf;
    let $wjceHi;
    let $byBdQd;
    let $tAwuCi;
    let $tVUPFg;
    let $mfzomd;
    let $eBoTKi;
    let $erOcib;
    let $nMPYZe;
    let $rBAbOb;
    let $fFsNCk;
    let $NOTifi;
    let $wHLVtf;
    let $WMdpif;
    let $qjVsXe;
    let $LAEFhe;
    let $AYgGkg;
    let $BLXeEa;
    let $bLPLwf;
    let $bwXwjf;
    let $JTmyYj;
    let $MLHsVd;
    let $zKqfAf;
    let $gJMqbf;
    let $ngvJRk;
    let $pKDxvd;
    let $anDylc;
    let $qnUlge;
    let $Xlkini;
    let $WBtBdl;
    let $xeuDUd;
    let $ZhgIfj;
    let $pZyOyk;
    let $Adydmf;
    let $NPDQok;
    let $QIawkg;
    let $dMycee;
    let $YPdOZj;
    let $kWyfBi;
    let $PDeJkd;
    let $HQNEse;
    let $ZJErMe;
    let $Pfedwh;
    let $CzaCAc;
    let $owZsaf;
    let $mmJCfg;
    let $jhLyBg;
    let $SGsjnj;
    let $MwILgk;
    let $ThPyld;
    let $ukVbSk;
    let $xThvyf;
    let $uKNVyj;
    let $HoOjVk;
    let $OBSYad;
    let $uBbOTk;
    let $JXomdi;
    let $CRFFXg;
    let $xgpKsj;
    let $yPGPMa;
    let $dSQIle;
    let $NQAyHg;
    let $kjVIJe;
    let $FeXyRi;
    let $qOpRSe;
    let $lgluBk;
    let $Dwsdmc;
    let $QOWZvd;
    let $hjpjDh;
    let $TfCAQa;
    let $TaWJge;
    let $ScLtKh;
    let $yvDAKj;
    let $XfyDJa;
    let $EDJdKc;
    let $wWssVd;
    let $ehpyub;
    let $ntnqFj;
    let $OSJwmg;
    let $PKSZTf;
    let $sAkOUd;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.TrafficControl", 
    {
  "h": 62803,
  "f": "LivingThing.Core.IOT.Devices.TrafficControl",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.TrafficControl",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.TrafficControl",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5UcmFmZmljQ29udHJvbC5UcmFmZmljQ29udHJvbERldmljZSI6IHsNCiAgICAgICJDYXRlZ29yaWVzIjogWyAiU21hcnQgSG9tZSIgXSwNCiAgICAgICJOYW1lIjogIlRyYWZmaWNDb250cm9sIiwNCiAgICAgICJEZXNjcmlwdGlvbiI6ICIiLA0KICAgICAgIkJhbm5lckltYWdlIjogIn4vVHJhZmZpY0NvbnRyb2wvaW1nL2Jhbm5lci5qcGciLA0KICAgICAgIkljb24iOiB7ICJOYW1lIjogIm1kaSBtZGktZWxlY3RyaWMtc3dpdGNoIiB9LA0KICAgICAgIlRoZW1lQ29sb3IiOiAiI2Q3N2JiYSIsDQogICAgICAiRmxhZ3MiOiAiRmVhdHVyZWQsUHVibGlzaGVkIiwNCiAgICAgICJTZWN1cml0aWVzIjogIkNoYWxsZW5nZUhhbmRTaGFrZUF1dGhlbnRpY2F0aW9uUHJvdG9jb2wsQWR2YW5jZWRFbmNyeXB0aW9uU3RhbmRhcmQsRWxsaXB0aWNDdXJ2ZUZpcm13YXJlVXBkYXRlU2lnbmluZyINCiAgICB9DQogIH0NCn0="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1373523)
        $asm.$cls(`$CFEL.LCIDTMC.TrafficStateCustomAttributesProvider`, ($self) => class TrafficStateCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296340819)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296340819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296340819)
            
            static $h = 1373523;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296340819),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1373523,
      "h": 4296340819,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296340819)
  ],
  "h": 1373523
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficStateCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Commands${separator}TrafficStateCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1373523)
        
        

        //--TRIMMABLE-BOUNDARY-START(2028883)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class TrafficControlDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296996179)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296996179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$$($.$CFEL.LCIDTMS.TrafficControlStatusModel, $.$CFEL.LCIDTM.TrafficControlLogModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296996179)
            
            static $h = 2028883;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296996179),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2028883,
      "h": 4296996179,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296996179)
  ],
  "h": 2028883
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2028883)
        
        

        //--TRIMMABLE-BOUNDARY-START(3732819)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficControlClickCommandCustomAttributesProvider`, ($self) => class TrafficControlClickCommandCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298700115)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298700115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298700115)
            
            static $h = 3732819;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298700115),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3732819,
      "h": 4298700115,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298700115)
  ],
  "h": 3732819
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlClickCommandCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlClickCommandCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3732819)
        
        

        //--TRIMMABLE-BOUNDARY-START(1766739)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlDeviceModelCustomAttributesProvider`, ($self) => class TrafficControlDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296734035)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296734035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296734035)
            
            static $h = 1766739;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296734035),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1766739,
      "h": 4296734035,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296734035)
  ],
  "h": 1766739
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1766739)
        
        

        //--TRIMMABLE-BOUNDARY-START(521555)
        $asm.$cls(`$CFEL.LCIDT.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295488851)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295488851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295488851)
            
            static $h = 521555;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295488851),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 521555,
      "h": 4295488851,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295488851)
  ],
  "h": 521555
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(521555)
        
        

        //--TRIMMABLE-BOUNDARY-START(2815315)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlLogModelCustomAttributesProvider`, ($self) => class TrafficControlLogModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297782611)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297782611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceLogModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297782611)
            
            static $h = 2815315;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297782611),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2815315,
      "h": 4297782611,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297782611)
  ],
  "h": 2815315
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlLogModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlLogModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2815315)
        
        

        //--TRIMMABLE-BOUNDARY-START(3077459)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlServiceModelCustomAttributesProvider`, ($self) => class TrafficControlServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298044755)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298044755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298044755)
            
            static $h = 3077459;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298044755),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3077459,
      "h": 4298044755,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298044755)
  ],
  "h": 3077459
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3077459)
        
        

        //--TRIMMABLE-BOUNDARY-START(456019)
        $asm.$cls(`$CFEL.LCIDT.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295423315)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295423315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CFEL.LCIDTMC.TrafficState.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CFEL.LCIDTMC.TrafficStateCustomAttributesProvider, $.$CFEL.LCIDTMC.TrafficStateCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CFEL.LCIDTMC.TrafficControlOverrideControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CFEL.LCIDTMC.TrafficControlOverrideControlModelCustomAttributesProvider, $.$CFEL.LCIDTMC.TrafficControlOverrideControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CFEL.LCIDTMC.TrafficControlOverrideModeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CFEL.LCIDTMC.TrafficControlOverrideModeModelCustomAttributesProvider, $.$CFEL.LCIDTMC.TrafficControlOverrideModeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CFEL.LCIDTMS.TrafficControlStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CFEL.LCIDTMS.TrafficControlStatusModelCustomAttributesProvider, $.$CFEL.LCIDTMS.TrafficControlStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CFEL.LCIDTM.TrafficControlDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CFEL.LCIDTM.TrafficControlDeviceModelCustomAttributesProvider, $.$CFEL.LCIDTM.TrafficControlDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModelCustomAttributesProvider, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CFEL.LCIDTM.TrafficControlDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CFEL.LCIDTM.TrafficControlDeviceScopeModelCustomAttributesProvider, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CFEL.LCIDTM.TrafficControlDeviceSendDataModelCustomAttributesProvider, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CFEL.LCIDTM.TrafficControlLogModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CFEL.LCIDTM.TrafficControlLogModelCustomAttributesProvider, $.$CFEL.LCIDTM.TrafficControlLogModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CFEL.LCIDTM.TrafficControlServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CFEL.LCIDTM.TrafficControlServiceModelCustomAttributesProvider, $.$CFEL.LCIDTM.TrafficControlServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CFEL.LCIDTS$1.TrafficControlEnabledLane.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CFEL.LCIDTS$1.TrafficControlEnabledLaneCustomAttributesProvider, $.$CFEL.LCIDTS$1.TrafficControlEnabledLaneCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CFEL.LCIDTS$1.TrafficControlMode.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CFEL.LCIDTS$1.TrafficControlModeCustomAttributesProvider, $.$CFEL.LCIDTS$1.TrafficControlModeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CFEL.LCIDTS$1.TrafficControlSlotSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsCustomAttributesProvider, $.$CFEL.LCIDTS$1.TrafficControlSlotSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettingsCustomAttributesProvider, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CFEL.LCIDTS$1.TrafficControlClickCommand.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CFEL.LCIDTS$1.TrafficControlClickCommandCustomAttributesProvider, $.$CFEL.LCIDTS$1.TrafficControlClickCommandCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$CFEL.LCIDTS$1.TrafficControlDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$CFEL.LCIDTS$1.TrafficControlDeviceSettingsCustomAttributesProvider, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295423315)
            
            static $h = 456019;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295423315),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 456019,
      "h": 4295423315,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295423315)
  ],
  "h": 456019
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(456019)
        
        

        //--TRIMMABLE-BOUNDARY-START(2291027)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlDeviceScopeModelCustomAttributesProvider`, ($self) => class TrafficControlDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297258323)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297258323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297258323)
            
            static $h = 2291027;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297258323),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2291027,
      "h": 4297258323,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297258323)
  ],
  "h": 2291027
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2291027)
        
        

        //--TRIMMABLE-BOUNDARY-START(1111379)
        $asm.$cls(`$CFEL.LCIDTMC.TrafficControlOverrideModeModelCustomAttributesProvider`, ($self) => class TrafficControlOverrideModeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296078675)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296078675)
            
            //--TRIMMABLE-BOUNDARY-START(8591045971)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591045971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$CFEL.LCIDTMC.TrafficControlOverrideModeModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Mode", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            $i3.ConvertType = ($.$$.S.Byte.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$CFEL.LCIDTMC.TrafficControlOverrideModeModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $UCtfRd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1111379,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $SAfHxj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1111379,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591045971)
            
            static $h = 1111379;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591045971),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1111379,
      "h": 8591045971,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591045971)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296078675),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1111379,
      "h": 4296078675,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296078675)
  ],
  "h": 1111379
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideModeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Commands${separator}TrafficControlOverrideModeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1111379)
        
        

        //--TRIMMABLE-BOUNDARY-START(2553171)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlDeviceSendDataModelCustomAttributesProvider`, ($self) => class TrafficControlDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297520467)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297520467)
            
            //--TRIMMABLE-BOUNDARY-START(8592487763)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592487763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Override", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (13432);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $vDnyvd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2553171,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $JguSVa ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2553171,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandsModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592487763)
            
            static $h = 2553171;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592487763),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2553171,
      "h": 8592487763,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592487763)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297520467),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2553171,
      "h": 4297520467,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297520467)
  ],
  "h": 2553171
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2553171)
        
        

        //--TRIMMABLE-BOUNDARY-START(3339603)
        $asm.$cls(`$CFEL.LCIDT.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593274195)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593274195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$CFEL.LCIDTV$1.TrafficControl, "LivingThing.Core.IOT.Devices.TrafficControl", "Views\\TrafficControl", "Traffic Control", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/TrafficControl" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8593274195)
            
            //--TRIMMABLE-BOUNDARY-START(4298306899)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298306899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298306899)
            
            //--TRIMMABLE-BOUNDARY-START(4298306899)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298306899)
            
            static $h = 3339603;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593274195),
    {
      "r": 65537,
      "n": "Build",
      "d": 3339603,
      "h": 8593274195,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8593274195)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298306899),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3339603,
      "h": 4298306899,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298306899)
  ],
  "h": 3339603
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3339603)
        
        

        //--TRIMMABLE-BOUNDARY-START(4519251)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficControlModeCustomAttributesProvider`, ($self) => class TrafficControlModeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299486547)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299486547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4299486547)
            
            static $h = 4519251;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299486547),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4519251,
      "h": 4299486547,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299486547)
  ],
  "h": 4519251
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlModeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlModeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4519251)
        
        

        //--TRIMMABLE-BOUNDARY-START(3863891)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class TrafficControlDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298831187)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298831187)
            
            //--TRIMMABLE-BOUNDARY-START(8593798483)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593798483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Slots", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Key = "tfs";
                            $i3.Order = (20);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $TsCuEa ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3863891,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $DkaSLj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3863891,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593798483)
            
            static $h = 3863891;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593798483),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3863891,
      "h": 8593798483,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593798483)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298831187),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3863891,
      "h": 4298831187,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298831187)
  ],
  "h": 3863891
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3863891)
        
        

        //--TRIMMABLE-BOUNDARY-START(4388179)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficControlEnabledLaneCustomAttributesProvider`, ($self) => class TrafficControlEnabledLaneCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299355475)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299355475)
            
            //--TRIMMABLE-BOUNDARY-START(8594322771)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594322771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$CFEL.LCIDTS$1.TrafficControlEnabledLaneCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(2);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t4 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i4 = new $t4();
                        $i4.$ctor$7(8, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i4.set_Item("Lane1", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Title = "Lane 1";
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i4.set_Item("Lane2", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Title = "Lane 2";
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i4.set_Item("Lane3", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Title = "Lane 3";
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i4.set_Item("Lane4", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Title = "Lane 4";
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i4.set_Item("Lane5", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Title = "Lane 5";
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i4.set_Item("Lane6", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Title = "Lane 6";
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i4.set_Item("Lane7", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Title = "Lane 7";
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i4.set_Item("Lane8", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t12 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$4();
                            $i12.Title = "Lane 8";
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i4;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$CFEL.LCIDTS$1.TrafficControlEnabledLaneCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $vvGQMe ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4388179,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $rrScHk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4388179,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594322771)
            
            static $h = 4388179;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594322771),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4388179,
      "h": 8594322771,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594322771)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299355475),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4388179,
      "h": 4299355475,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299355475)
  ],
  "h": 4388179
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlEnabledLaneCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlEnabledLaneCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4388179)
        
        

        //--TRIMMABLE-BOUNDARY-START(324947)
        $asm.$cls(`$CFEL.LCIDT._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295292243)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295292243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$CFEL.LCIDT.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295292243)
            
            static $h = 324947;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295292243),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 324947,
      "h": 4295292243,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295292243)
  ],
  "h": 324947
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(324947)
        
        

        //--TRIMMABLE-BOUNDARY-START(5305683)
        $asm.$cls(`$CFEL.LCIDT.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4300272979)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300272979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$CFEL.LCIDTMC.TrafficControlOverrideControlModelTypeDescriptorBuilder.Register();
                $.$CFEL.LCIDTMC.TrafficControlOverrideModeModelTypeDescriptorBuilder.Register();
                $.$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptorBuilder.Register();
                $.$CFEL.LCIDTM.TrafficControlDeviceModelTypeDescriptorBuilder.Register();
                $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$CFEL.LCIDTM.TrafficControlDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$CFEL.LCIDTM.TrafficControlLogModelTypeDescriptorBuilder.Register();
                $.$CFEL.LCIDTM.TrafficControlServiceModelTypeDescriptorBuilder.Register();
                $.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptorBuilder.Register();
                $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$CFEL.LCIDTS$1.TrafficControlDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4300272979)
            
            static $h = 5305683;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300272979),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 5305683,
      "h": 4300272979,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4300272979)
  ],
  "h": 5305683
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5305683)
        
        

        //--TRIMMABLE-BOUNDARY-START(783699)
        $asm.$cls(`$CFEL.LCIDTMC.TrafficControlOverrideControlModelCustomAttributesProvider`, ($self) => class TrafficControlOverrideControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295750995)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295750995)
            
            //--TRIMMABLE-BOUNDARY-START(8590718291)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590718291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$CFEL.LCIDTMC.TrafficControlOverrideControlModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Lane", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            $i3.ConvertType = ($.$$.S.Byte.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("State", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (4);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Time", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (5);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$CFEL.LCIDTMC.TrafficControlOverrideControlModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $kWGrTh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":783699,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $kQpUZj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":783699,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590718291)
            
            static $h = 783699;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590718291),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 783699,
      "h": 8590718291,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590718291)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295750995),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 783699,
      "h": 4295750995,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295750995)
  ],
  "h": 783699
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Commands${separator}TrafficControlOverrideControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(783699)
        
        

        //--TRIMMABLE-BOUNDARY-START(4650323)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficControlSlotSettingsCustomAttributesProvider`, ($self) => class TrafficControlSlotSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299617619)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299617619)
            
            //--TRIMMABLE-BOUNDARY-START(8594584915)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594584915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$CFEL.LCIDTS$1.TrafficControlSlotSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(9, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Flags = (65536);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Magic", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (1);
                            $i4.ConvertType = ($.$$.S.Byte.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Start", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (2);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("End", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (3);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("StandbyTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (6);
                            $i7.ConvertType = ($.$$.S.Byte.$type);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Mode", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Order = (7);
                            $i8.ConvertType = ($.$$.S.Byte.$type);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("EnableLaneFlags", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Order = (8);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Slices", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Order = (9);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Relationships", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Order = (10);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$CFEL.LCIDTS$1.TrafficControlSlotSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $tlrUpd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4650323,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $NZNeJj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4650323,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594584915)
            
            static $h = 4650323;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594584915),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4650323,
      "h": 8594584915,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594584915)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299617619),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4650323,
      "h": 4299617619,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299617619)
  ],
  "h": 4650323
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlSlotSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4650323)
        
        

        //--TRIMMABLE-BOUNDARY-START(4126035)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficControlDeviceSettingsCustomAttributesProvider`, ($self) => class TrafficControlDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299093331)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299093331)
            
            //--TRIMMABLE-BOUNDARY-START(8594060627)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594060627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$CFEL.LCIDTS$1.TrafficControlDeviceSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Invert", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (256);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("OnClick", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (257);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$CFEL.LCIDTS$1.TrafficControlDeviceSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $Noqbof ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4126035,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $CHnoki ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4126035,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594060627)
            
            static $h = 4126035;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594060627),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4126035,
      "h": 8594060627,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594060627)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299093331),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4126035,
      "h": 4299093331,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299093331)
  ],
  "h": 4126035
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4126035)
        
        

        //--TRIMMABLE-BOUNDARY-START(4257107)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficControlDeviceSettingsTypeDescriptorBuilder`, ($self) => class TrafficControlDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594191699)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594191699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CFEL.LCIDTS$1.TrafficControlDeviceSettingsTypeDescriptor()
                        const $t1 = $.$CFEL.LCIDTS$1.TrafficControlDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $tDjpFc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4257107,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CFEL.LCIDTS$1.TrafficControlDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594191699)
            
            //--TRIMMABLE-BOUNDARY-START(4299224403)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299224403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299224403)
            
            //--TRIMMABLE-BOUNDARY-START(4299224403)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299224403)
            
            static $h = 4257107;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594191699),
    {
      "r": 65537,
      "n": "Register",
      "d": 4257107,
      "h": 8594191699,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594191699)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299224403),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4257107,
      "h": 4299224403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299224403)
  ],
  "h": 4257107
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4257107)
        
        

        //--TRIMMABLE-BOUNDARY-START(1504595)
        $asm.$cls(`$CFEL.LCIDTMS.TrafficControlStatusModelCustomAttributesProvider`, ($self) => class TrafficControlStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296471891)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296471891)
            
            //--TRIMMABLE-BOUNDARY-START(8591439187)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591439187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$CFEL.LCIDTMS.TrafficControlStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(5, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("EnableLaneFlags", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("RunningSlot", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.ConvertType = ($.$$.S.Byte.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CurrentSlice", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3);
                            $i5.ConvertType = ($.$$.S.Byte.$type);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CurrentSliceElapsed", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (4);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Statuses", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (5);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$CFEL.LCIDTMS.TrafficControlStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $IuWXmh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1504595,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $RJKsca ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1504595,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591439187)
            
            static $h = 1504595;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591439187),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1504595,
      "h": 8591439187,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591439187)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296471891),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1504595,
      "h": 4296471891,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296471891)
  ],
  "h": 1504595
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Statuses.TrafficControlStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Statuses${separator}TrafficControlStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1504595)
        
        

        //--TRIMMABLE-BOUNDARY-START(2946387)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlLogModelTypeDescriptorBuilder`, ($self) => class TrafficControlLogModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592880979)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592880979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CFEL.LCIDTM.TrafficControlLogModelTypeDescriptor()
                        const $t1 = $.$CFEL.LCIDTM.TrafficControlLogModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlLogModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $KgyVnj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2946387,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CFEL.LCIDTM.TrafficControlLogModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592880979)
            
            //--TRIMMABLE-BOUNDARY-START(4297913683)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297913683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297913683)
            
            //--TRIMMABLE-BOUNDARY-START(4297913683)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297913683)
            
            static $h = 2946387;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592880979),
    {
      "r": 65537,
      "n": "Register",
      "d": 2946387,
      "h": 8592880979,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592880979)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297913683),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2946387,
      "h": 4297913683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297913683)
  ],
  "h": 2946387
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlLogModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlLogModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2946387)
        
        

        //--TRIMMABLE-BOUNDARY-START(3994963)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class TrafficControlDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593929555)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593929555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $PXSkmb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3994963,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593929555)
            
            //--TRIMMABLE-BOUNDARY-START(4298962259)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298962259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298962259)
            
            //--TRIMMABLE-BOUNDARY-START(4298962259)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298962259)
            
            static $h = 3994963;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593929555),
    {
      "r": 65537,
      "n": "Register",
      "d": 3994963,
      "h": 8593929555,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593929555)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298962259),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3994963,
      "h": 4298962259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298962259)
  ],
  "h": 3994963
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3994963)
        
        

        //--TRIMMABLE-BOUNDARY-START(2684243)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class TrafficControlDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592618835)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592618835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $qhqUKf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2684243,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592618835)
            
            //--TRIMMABLE-BOUNDARY-START(4297651539)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297651539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297651539)
            
            //--TRIMMABLE-BOUNDARY-START(4297651539)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297651539)
            
            static $h = 2684243;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592618835),
    {
      "r": 65537,
      "n": "Register",
      "d": 2684243,
      "h": 8592618835,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592618835)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297651539),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2684243,
      "h": 4297651539,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297651539)
  ],
  "h": 2684243
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2684243)
        
        

        //--TRIMMABLE-BOUNDARY-START(2159955)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class TrafficControlDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592094547)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592094547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $kWzhnb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2159955,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592094547)
            
            //--TRIMMABLE-BOUNDARY-START(4297127251)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297127251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297127251)
            
            //--TRIMMABLE-BOUNDARY-START(4297127251)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297127251)
            
            static $h = 2159955;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592094547),
    {
      "r": 65537,
      "n": "Register",
      "d": 2159955,
      "h": 8592094547,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592094547)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297127251),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2159955,
      "h": 4297127251,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297127251)
  ],
  "h": 2159955
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2159955)
        
        

        //--TRIMMABLE-BOUNDARY-START(1897811)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlDeviceModelTypeDescriptorBuilder`, ($self) => class TrafficControlDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591832403)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591832403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CFEL.LCIDTM.TrafficControlDeviceModelTypeDescriptor()
                        const $t1 = $.$CFEL.LCIDTM.TrafficControlDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ONxpXi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1897811,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CFEL.LCIDTM.TrafficControlDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591832403)
            
            //--TRIMMABLE-BOUNDARY-START(4296865107)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296865107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296865107)
            
            //--TRIMMABLE-BOUNDARY-START(4296865107)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296865107)
            
            static $h = 1897811;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591832403),
    {
      "r": 65537,
      "n": "Register",
      "d": 1897811,
      "h": 8591832403,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591832403)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296865107),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1897811,
      "h": 4296865107,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296865107)
  ],
  "h": 1897811
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1897811)
        
        

        //--TRIMMABLE-BOUNDARY-START(1635667)
        $asm.$cls(`$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptorBuilder`, ($self) => class TrafficControlStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591570259)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591570259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptor()
                        const $t1 = $.$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TrafficControl.Models.Statuses.TrafficControlStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $erOcib ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1635667,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CFEL.LCIDTMS.TrafficControlStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591570259)
            
            //--TRIMMABLE-BOUNDARY-START(4296602963)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296602963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296602963)
            
            //--TRIMMABLE-BOUNDARY-START(4296602963)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296602963)
            
            static $h = 1635667;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591570259),
    {
      "r": 65537,
      "n": "Register",
      "d": 1635667,
      "h": 8591570259,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591570259)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296602963),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1635667,
      "h": 4296602963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296602963)
  ],
  "h": 1635667
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Statuses.TrafficControlStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Statuses${separator}TrafficControlStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1635667)
        
        

        //--TRIMMABLE-BOUNDARY-START(914771)
        $asm.$cls(`$CFEL.LCIDTMC.TrafficControlOverrideControlModelTypeDescriptorBuilder`, ($self) => class TrafficControlOverrideControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590849363)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590849363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CFEL.LCIDTMC.TrafficControlOverrideControlModelTypeDescriptor()
                        const $t1 = $.$CFEL.LCIDTMC.TrafficControlOverrideControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $MGooee ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":914771,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CFEL.LCIDTMC.TrafficControlOverrideControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590849363)
            
            //--TRIMMABLE-BOUNDARY-START(4295882067)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295882067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295882067)
            
            //--TRIMMABLE-BOUNDARY-START(4295882067)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295882067)
            
            static $h = 914771;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590849363),
    {
      "r": 65537,
      "n": "Register",
      "d": 914771,
      "h": 8590849363,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590849363)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295882067),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 914771,
      "h": 4295882067,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295882067)
  ],
  "h": 914771
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Commands${separator}TrafficControlOverrideControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(914771)
        
        

        //--TRIMMABLE-BOUNDARY-START(4781395)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptorBuilder`, ($self) => class TrafficControlSlotSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594715987)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594715987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor()
                        const $t1 = $.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $HQNEse ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4781395,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CFEL.LCIDTS$1.TrafficControlSlotSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594715987)
            
            //--TRIMMABLE-BOUNDARY-START(4299748691)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299748691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299748691)
            
            //--TRIMMABLE-BOUNDARY-START(4299748691)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299748691)
            
            static $h = 4781395;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594715987),
    {
      "r": 65537,
      "n": "Register",
      "d": 4781395,
      "h": 8594715987,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594715987)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299748691),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4781395,
      "h": 4299748691,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299748691)
  ],
  "h": 4781395
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlSlotSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4781395)
        
        

        //--TRIMMABLE-BOUNDARY-START(193875)
        $asm.$cls(`$CFEL._LCIDTVT.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295161171)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg1, /*int*/ __seq2, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295161171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "ValueChanged", __arg1);
                __builder.AddComponentParameter(__seq2, "ValueExpression", __arg2);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295161171)
            
            static $h = 193875;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295161171),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 193875,
      "h": 4295161171,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295161171)
  ],
  "h": 193875
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.IOT.Devices.TrafficControl.Views.TrafficControl.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Views${separator}TrafficControl${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(193875)
        
        

        //--TRIMMABLE-BOUNDARY-START(128339)
        $asm.$cls(`$CFEL._LCIDTVS.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295095635)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295095635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Theme", $.$clone(__arg0));
                __builder.AddComponentParameter(__seq1, "PlaceHolder", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295095635)
            
            //--TRIMMABLE-BOUNDARY-START(8590062931)
            static /*void */ CreateInputEditor_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590062931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Theme", $.$clone(__arg0));
                __builder.AddComponentParameter(__seq1, "PlaceHolder", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590062931)
            
            static $h = 128339;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295095635),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 65309014
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 128339,
      "h": 4295095635,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295095635),
//--TRIMMABLE-BOUNDARY-START(8590062931),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 65309014
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_1",
      "d": 128339,
      "h": 8590062931,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590062931)
  ],
  "h": 128339
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.IOT.Devices.TrafficControl.Views.SlotEditor.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Views${separator}SlotEditor${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(128339)
        
        

        //--TRIMMABLE-BOUNDARY-START(1242451)
        $asm.$cls(`$CFEL.LCIDTMC.TrafficControlOverrideModeModelTypeDescriptorBuilder`, ($self) => class TrafficControlOverrideModeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591177043)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591177043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CFEL.LCIDTMC.TrafficControlOverrideModeModelTypeDescriptor()
                        const $t1 = $.$CFEL.LCIDTMC.TrafficControlOverrideModeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideModeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $bwXwjf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1242451,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CFEL.LCIDTMC.TrafficControlOverrideModeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591177043)
            
            //--TRIMMABLE-BOUNDARY-START(4296209747)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296209747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296209747)
            
            //--TRIMMABLE-BOUNDARY-START(4296209747)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296209747)
            
            static $h = 1242451;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591177043),
    {
      "r": 65537,
      "n": "Register",
      "d": 1242451,
      "h": 8591177043,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591177043)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296209747),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1242451,
      "h": 4296209747,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296209747)
  ],
  "h": 1242451
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideModeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Commands${separator}TrafficControlOverrideModeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1242451)
        
        

        //--TRIMMABLE-BOUNDARY-START(2422099)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlDeviceScopeModelTypeDescriptorBuilder`, ($self) => class TrafficControlDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592356691)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592356691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CFEL.LCIDTM.TrafficControlDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$CFEL.LCIDTM.TrafficControlDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ngvJRk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2422099,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CFEL.LCIDTM.TrafficControlDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592356691)
            
            //--TRIMMABLE-BOUNDARY-START(4297389395)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297389395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297389395)
            
            //--TRIMMABLE-BOUNDARY-START(4297389395)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297389395)
            
            static $h = 2422099;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592356691),
    {
      "r": 65537,
      "n": "Register",
      "d": 2422099,
      "h": 8592356691,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592356691)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297389395),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2422099,
      "h": 4297389395,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297389395)
  ],
  "h": 2422099
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2422099)
        
        

        //--TRIMMABLE-BOUNDARY-START(3208531)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlServiceModelTypeDescriptorBuilder`, ($self) => class TrafficControlServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593143123)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593143123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$CFEL.LCIDTM.TrafficControlServiceModelTypeDescriptor()
                        const $t1 = $.$CFEL.LCIDTM.TrafficControlServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $anDylc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3208531,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$CFEL.LCIDTM.TrafficControlServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593143123)
            
            //--TRIMMABLE-BOUNDARY-START(4298175827)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298175827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298175827)
            
            //--TRIMMABLE-BOUNDARY-START(4298175827)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298175827)
            
            static $h = 3208531;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593143123),
    {
      "r": 65537,
      "n": "Register",
      "d": 3208531,
      "h": 8593143123,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593143123)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298175827),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3208531,
      "h": 4298175827,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298175827)
  ],
  "h": 3208531
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3208531)
        
        

        //--TRIMMABLE-BOUNDARY-START(390483)
        $asm.$cls(`$CFEL.LCIDT.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180259667)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180259667)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295357779)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295357779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295357779)
            
            //--TRIMMABLE-BOUNDARY-START(4295357779)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295357779)
            
            static $h = 390483;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180259667),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885292371,
        "f": 50331649
      },
      "n": "Paths",
      "d": 390483,
      "h": 17180259667,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180259667)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295357779),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 390483,
      "h": 4295357779,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295357779)
  ],
  "h": 390483
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(390483)
        
        

        //--TRIMMABLE-BOUNDARY-START(4912467)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficSlice`, ($self) => class TrafficSlice extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34364650835)
            /*int*/ Id = 0;
            //--TRIMMABLE-BOUNDARY-END(34364650835)
            
            //--TRIMMABLE-BOUNDARY-START(38659618131)
            /*int*/ Period = 0;
            //--TRIMMABLE-BOUNDARY-END(38659618131)
            
            //--TRIMMABLE-BOUNDARY-START(12889814355)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889814355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12889814355)
            
            //--TRIMMABLE-BOUNDARY-START(12889814355)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12889814355)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38659618131)
                this.Period = 40;
                //--TRIMMABLE-BOUNDARY-END(38659618131)
                
            }
            static $h = 4912467;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34364650835),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479748947,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47249552723,
        "f": 83886081
      },
      "n": "Id",
      "d": 4912467,
      "h": 34364650835,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34364650835),
//--TRIMMABLE-BOUNDARY-START(38659618131),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069683539,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55839487315,
        "f": 83886081
      },
      "n": "Period",
      "d": 4912467,
      "h": 38659618131,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38659618131)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12889814355),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4912467,
      "h": 12889814355,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889814355)
  ],
  "h": 4912467
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficSlice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficSlice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4912467)
        
        

        //--TRIMMABLE-BOUNDARY-START(4846931)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficLaneSliceRelationship`, ($self) => class TrafficLaneSliceRelationship extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34364585299)
            /*int*/ LaneId = 0;
            //--TRIMMABLE-BOUNDARY-END(34364585299)
            
            //--TRIMMABLE-BOUNDARY-START(55839421779)
            /*int*/ SliceId = 0;
            //--TRIMMABLE-BOUNDARY-END(55839421779)
            
            //--TRIMMABLE-BOUNDARY-START(12889748819)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889748819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12889748819)
            
            //--TRIMMABLE-BOUNDARY-START(12889748819)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12889748819)
            
            static $h = 4846931;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34364585299),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479683411,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42954519891,
        "f": 83886081
      },
      "n": "LaneId",
      "d": 4846931,
      "h": 34364585299,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34364585299),
//--TRIMMABLE-BOUNDARY-START(55839421779),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069618003,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51544454483,
        "f": 83886081
      },
      "n": "SliceId",
      "d": 4846931,
      "h": 55839421779,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55839421779)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12889748819),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4846931,
      "h": 12889748819,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889748819)
  ],
  "h": 4846931
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficLaneSliceRelationship`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficLaneSliceRelationship`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4846931)
        
        

        //--TRIMMABLE-BOUNDARY-START(3405139)
        $asm.$cls(`$CFEL.LCIDT.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593339731)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593339731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$CFEL.LCIDT.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$CFEL.LCIDT.TrafficControlDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$CFEL.LCIDT.TrafficControlDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$CFEL.LCIDT.TrafficControlDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$CFEL.LCIDT.TrafficControlDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$CFEL.LCIDT.TrafficControlDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$CFEL.LCIDT.TrafficControlDeviceFamily, x);
                }, $ScpCwd ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":3405139,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$CFEL.LCIDT.TrafficControlDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$CFEL.LCIDT.TrafficControlDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $ihMaNc ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":3405139,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$CFEL.LCIDT.TrafficControlDevice)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$CFEL.LCIDT.TrafficControlDeviceFamily, x);
                }, $LLgeia ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$CFEL.LCIDT.TrafficControlDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":3405139,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$CFEL.LCIDT.TrafficControlDevice), $.$CFEL.LCIDTMC.TrafficControlDeviceCommands, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$CFEL.LCIDTV.TrafficControlClientAppViewModel, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8593339731)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$CFEL.LCIDT.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298372435)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298372435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298372435)
            
            //--TRIMMABLE-BOUNDARY-START(4298372435)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298372435)
            
            static $h = 3405139;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593339731),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3405139,
      "h": 8593339731,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593339731)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298372435),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3405139,
      "h": 4298372435,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298372435)
  ],
  "h": 3405139
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3405139)
        
        

        //--TRIMMABLE-BOUNDARY-START(3274067)
        $asm.$cls(`$CFEL.LCIDT.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17183143251)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$CFEL.LCIDTV$1.RoadAnimation.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$CFEL.LCIDTV$1.RoadAnimation().$ctor$3();
                    }, $vushak ??= {"r":2752627,"n":"","d":3274067,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$CFEL.LCIDTV$1.SlotEditor.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$CFEL.LCIDTV$1.SlotEditor().$ctor$5();
                    }, $GnSIrf ??= {"r":2752627,"n":"","d":3274067,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$CFEL.LCIDTV$1.TrafficControl.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$CFEL.LCIDTV$1.TrafficControl().$ctor$6();
                    }, $LIjPpc ??= {"r":2752627,"n":"","d":3274067,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17183143251)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4298241363)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298241363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298241363)
            
            //--TRIMMABLE-BOUNDARY-START(4298241363)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298241363)
            
            static $h = 3274067;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183143251),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888175955,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 3274067,
      "h": 17183143251,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17183143251)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298241363),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3274067,
      "h": 4298241363,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298241363)
  ],
  "h": 3274067
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3274067)
        
        

        //--TRIMMABLE-BOUNDARY-START(4584787)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficControlSlotSettings`, ($self) => class TrafficControlSlotSettings extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(163213342035)
            /*int*/ Magic = 0;
            //--TRIMMABLE-BOUNDARY-END(163213342035)
            
            //--TRIMMABLE-BOUNDARY-START(274882491731)
            /*MaskableDateTime*/ Start = null;
            //--TRIMMABLE-BOUNDARY-END(274882491731)
            
            //--TRIMMABLE-BOUNDARY-START(279177459027)
            /*bool*/ StartEnabled = false;
            //--TRIMMABLE-BOUNDARY-END(279177459027)
            
            //--TRIMMABLE-BOUNDARY-START(55839159635)
            /*MaskableDateTime*/ End = null;
            //--TRIMMABLE-BOUNDARY-END(55839159635)
            
            //--TRIMMABLE-BOUNDARY-START(60134126931)
            /*bool*/ EndEnabled = false;
            //--TRIMMABLE-BOUNDARY-END(60134126931)
            
            //--TRIMMABLE-BOUNDARY-START(270587524435)
            /*int*/ StandbyTime = 0;
            //--TRIMMABLE-BOUNDARY-END(270587524435)
            
            //--TRIMMABLE-BOUNDARY-START(167508309331)
            /*TrafficControlMode*/ Mode = 0;
            //--TRIMMABLE-BOUNDARY-END(167508309331)
            
            //--TRIMMABLE-BOUNDARY-START(51544192339)
            /*TrafficControlEnabledLane*/ EnableLaneFlags = 0;
            //--TRIMMABLE-BOUNDARY-END(51544192339)
            
            //--TRIMMABLE-BOUNDARY-START(266292557139)
            /*TrafficSlice[]?*/ Slices = null;
            //--TRIMMABLE-BOUNDARY-END(266292557139)
            
            //--TRIMMABLE-BOUNDARY-START(176098243923)
            /*TrafficLaneSliceRelationship[]?*/ Relationships = null;
            //--TRIMMABLE-BOUNDARY-END(176098243923)
            
            //--TRIMMABLE-BOUNDARY-START(158918374739)
            /*bool */ get IsEnabled()
            {
                return this.Magic === 85;
            }
            //--TRIMMABLE-BOUNDARY-END(158918374739)
            
            //--TRIMMABLE-BOUNDARY-START(283472426323)
            /*void */ ToggleEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283472426323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Magic === 85)
                {
                    this.Magic = 0;
                }
                else 
                {
                    this.Magic = 85;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(283472426323)
            
            //--TRIMMABLE-BOUNDARY-START(171803276627)
            /*void */ PackTo(/*PacketBuilder*/ packet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171803276627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                packet.Push$1($.$cast(this.Magic, $.$$.S.Byte));
                packet.Push$13($.$fPer.LCFCDC.PackedDateTime.From(this.Start, 2020), 0);
                packet.Push$1($.$cast(($.$cast(this.Start.Weekday, $.$$.S.Byte) | (this.StartEnabled ? 128 : 0)), $.$$.S.Byte));
                packet.Push$13($.$fPer.LCFCDC.PackedDateTime.From(this.End, 2020), 0);
                packet.Push$1($.$cast(($.$cast(this.End.Weekday, $.$$.S.Byte) | (this.EndEnabled ? 128 : 0)), $.$$.S.Byte));
                packet.Push$1($.$cast(this.StandbyTime, $.$$.S.Byte));
                packet.Push$1($.$cast(this.Mode, $.$$.S.Byte));
                packet.PushT($.$CFEL.LCIDTS$1.TrafficControlEnabledLane, this.EnableLaneFlags, null);
                packet.Pushs($.$CFEL.LCIDTS$1.TrafficSlice, this.Slices, true, null);
                packet.Pushs($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship, this.Relationships, true, null);
            }
            //--TRIMMABLE-BOUNDARY-END(171803276627)
            
            //--TRIMMABLE-BOUNDARY-START(287767393619)
            /*void */ UnPackFrom(/*PacketBuilder*/ packet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287767393619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Magic = packet.GetByte(-1);
                if (this.Magic === 85)
                {
                    /*uint*/ let tm = packet.GetDWord(-1, 0);
                    $.$fPer.LCFCDC.PackedDateTime.Populate(this.Start, tm, 2020);
                    /*byte*/ let wk = packet.GetByte(-1);
                    this.Start.Weekday = $.$cast((wk & 127), $.$fPer.LCFCDC.WeekDays);
                    this.StartEnabled = (wk & 128) !== 0;
                    tm = packet.GetDWord(-1, 0);
                    $.$fPer.LCFCDC.PackedDateTime.Populate(this.End, tm, 2020);
                    wk = packet.GetByte(-1);
                    this.End.Weekday = $.$cast((wk & 127), $.$fPer.LCFCDC.WeekDays);
                    this.EndEnabled = (wk & 128) !== 0;
                    this.StandbyTime = packet.GetByte(-1);
                    this.Mode = $.$cast(packet.GetByte(-1), $.$CFEL.LCIDTS$1.TrafficControlMode);
                    this.EnableLaneFlags = $.$cast(packet.GetDWord(-1, 0), $.$CFEL.LCIDTS$1.TrafficControlEnabledLane);
                    this.Slices = packet.Gets($.$CFEL.LCIDTS$1.TrafficSlice, -1, null);
                    this.Relationships = packet.Gets($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship, -1, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(287767393619)
            
            //--TRIMMABLE-BOUNDARY-START(4315515222)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IPacketBuilder.PackTo(LivingThing.Core.Frameworks.Common.Data.PacketBuilder)
            LCFCD$IPacketBuilder$PackTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4315515222);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PackTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4315515222)
            
            //--TRIMMABLE-BOUNDARY-START(8610482518)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IPacketBuilder.UnPackFrom(LivingThing.Core.Frameworks.Common.Data.PacketBuilder)
            LCFCD$IPacketBuilder$UnPackFrom()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8610482518);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UnPackFrom(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8610482518)
            
            //--TRIMMABLE-BOUNDARY-START(47249225043)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47249225043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47249225043)
            
            //--TRIMMABLE-BOUNDARY-START(47249225043)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(47249225043)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(274882491731)
                this.Start = new $.$fPer.LCFCDC.MaskableDateTime().$ctor$3();
                //--TRIMMABLE-BOUNDARY-END(274882491731)
                
                //--TRIMMABLE-BOUNDARY-START(55839159635)
                this.End = new $.$fPer.LCFCDC.MaskableDateTime().$ctor$3();
                //--TRIMMABLE-BOUNDARY-END(55839159635)
                
                //--TRIMMABLE-BOUNDARY-START(270587524435)
                this.StandbyTime = 5;
                //--TRIMMABLE-BOUNDARY-END(270587524435)
                
                //--TRIMMABLE-BOUNDARY-START(51544192339)
                this.EnableLaneFlags = 15;
                //--TRIMMABLE-BOUNDARY-END(51544192339)
                
            }
            static $h = 4584787;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(163213342035),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103083799891,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210457982291,
        "f": 83886081
      },
      "n": "Magic",
      "d": 4584787,
      "h": 163213342035,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163213342035),
//--TRIMMABLE-BOUNDARY-START(274882491731),
    {
      "p": 6719830,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146033472851,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253407655251,
        "f": 83886081
      },
      "n": "Start",
      "d": 4584787,
      "h": 274882491731,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(274882491731),
//--TRIMMABLE-BOUNDARY-START(279177459027),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154623407443,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261997589843,
        "f": 83886081
      },
      "n": "StartEnabled",
      "d": 4584787,
      "h": 279177459027,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279177459027),
//--TRIMMABLE-BOUNDARY-START(55839159635),
    {
      "p": 6719830,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77313996115,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193278113107,
        "f": 83886081
      },
      "n": "End",
      "d": 4584787,
      "h": 55839159635,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55839159635),
//--TRIMMABLE-BOUNDARY-START(60134126931),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85903930707,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201868047699,
        "f": 83886081
      },
      "n": "EndEnabled",
      "d": 4584787,
      "h": 60134126931,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60134126931),
//--TRIMMABLE-BOUNDARY-START(270587524435),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137443538259,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244817720659,
        "f": 83886081
      },
      "n": "StandbyTime",
      "d": 4584787,
      "h": 270587524435,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 6,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(270587524435),
//--TRIMMABLE-BOUNDARY-START(167508309331),
    {
      "p": 4453715,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111673734483,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219047916883,
        "f": 83886081
      },
      "n": "Mode",
      "d": 4584787,
      "h": 167508309331,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 7,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167508309331),
//--TRIMMABLE-BOUNDARY-START(51544192339),
    {
      "p": 4322643,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68724061523,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184688178515,
        "f": 83886081
      },
      "n": "EnableLaneFlags",
      "d": 4584787,
      "h": 51544192339,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 8,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51544192339),
//--TRIMMABLE-BOUNDARY-START(266292557139),
    {
      "p": $.$typeArray($.$CFEL.LCIDTS$1.TrafficSlice).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128853603667,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236227786067,
        "f": 83886081
      },
      "n": "Slices",
      "d": 4584787,
      "h": 266292557139,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 9,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(266292557139),
//--TRIMMABLE-BOUNDARY-START(176098243923),
    {
      "p": $.$typeArray($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120263669075,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227637851475,
        "f": 83886081
      },
      "n": "Relationships",
      "d": 4584787,
      "h": 176098243923,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 10,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176098243923),
//--TRIMMABLE-BOUNDARY-START(158918374739),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94493865299,
        "f": 50331649
      },
      "n": "IsEnabled",
      "d": 4584787,
      "h": 158918374739,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158918374739)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(283472426323),
    {
      "r": 65537,
      "n": "ToggleEnabled",
      "d": 4584787,
      "h": 283472426323,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(283472426323),
//--TRIMMABLE-BOUNDARY-START(171803276627),
    {
      "r": 65537,
      "p": [
        {
          "n": "packet",
          "p": 31164758
        }
      ],
      "n": "PackTo",
      "d": 4584787,
      "h": 171803276627,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(171803276627),
//--TRIMMABLE-BOUNDARY-START(287767393619),
    {
      "r": 65537,
      "p": [
        {
          "n": "packet",
          "p": 31164758
        }
      ],
      "n": "UnPackFrom",
      "d": 4584787,
      "h": 287767393619,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(287767393619)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47249225043),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4584787,
      "h": 47249225043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47249225043)
  ],
  "h": 4584787,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Flags",
          "v": 65536,
          "t": 655361
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlSlotSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4584787)
        
        

        //--TRIMMABLE-BOUNDARY-START(5961043)
        $asm.$cls(`$CFEL.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4300928339)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300928339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300928339)
            
            //--TRIMMABLE-BOUNDARY-START(4300928339)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4300928339)
            
            static $h = 5961043;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300928339),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5961043,
      "h": 4300928339,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300928339)
  ],
  "h": 5961043,
  "a": [
    {
      "t": 5895507,
      "c": 4300862803
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5961043)
        
        

        //--TRIMMABLE-BOUNDARY-START(5895507)
        $asm.$cls(`$CFEL.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4300862803)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300862803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300862803)
            
            //--TRIMMABLE-BOUNDARY-START(4300862803)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4300862803)
            
            static $h = 5895507;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300862803),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5895507,
      "h": 4300862803,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300862803)
  ],
  "h": 5895507
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5895507)
        
        

        //--TRIMMABLE-BOUNDARY-START(1045843)
        $asm.$cls(`$CFEL.LCIDTMC.TrafficControlOverrideModeModel`, ($self) => class TrafficControlOverrideModeModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(8590980435)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590980435);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590980435)
            
            //--TRIMMABLE-BOUNDARY-START(12885947731)
            /*int */ get Command()
            {
                return 129;
            }
            //--TRIMMABLE-BOUNDARY-END(12885947731)
            
            //--TRIMMABLE-BOUNDARY-START(34360784211)
            /*TrafficControlMode*/ Mode = 0;
            //--TRIMMABLE-BOUNDARY-END(34360784211)
            
            //--TRIMMABLE-BOUNDARY-START(8590980435)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590980435)
            
            static $h = 1045843;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885947731),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475882323,
        "f": 50364417
      },
      "n": "Command",
      "d": 1045843,
      "h": 12885947731,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12885947731),
//--TRIMMABLE-BOUNDARY-START(34360784211),
    {
      "p": 4453715,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065816915,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950718803,
        "f": 83886081
      },
      "n": "Mode",
      "d": 1045843,
      "h": 34360784211,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360784211)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590980435),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1045843,
      "h": 8590980435,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590980435)
  ],
  "h": 1045843
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideModeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Commands${separator}TrafficControlOverrideModeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1045843)
        
        

        //--TRIMMABLE-BOUNDARY-START(1439059)
        $asm.$cls(`$CFEL.LCIDTMS.TrafficControlStatusModel`, ($self) => class TrafficControlStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(38656144723)
            /*int*/ EnableLaneFlags = 0;
            //--TRIMMABLE-BOUNDARY-END(38656144723)
            
            //--TRIMMABLE-BOUNDARY-START(85900784979)
            /*int*/ RunningSlot = 0;
            //--TRIMMABLE-BOUNDARY-END(85900784979)
            
            //--TRIMMABLE-BOUNDARY-START(30066210131)
            /*int*/ CurrentSlice = 0;
            //--TRIMMABLE-BOUNDARY-END(30066210131)
            
            //--TRIMMABLE-BOUNDARY-START(34361177427)
            /*int*/ CurrentSliceElapsed = 0;
            //--TRIMMABLE-BOUNDARY-END(34361177427)
            
            //--TRIMMABLE-BOUNDARY-START(133145425235)
            /*byte[]?*/ Statuses = null;
            //--TRIMMABLE-BOUNDARY-END(133145425235)
            
            //--TRIMMABLE-BOUNDARY-START(25771242835)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771242835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771242835)
            
            //--TRIMMABLE-BOUNDARY-START(25771242835)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(25771242835)
            
            static $h = 1439059;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656144723),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425948499,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670588755,
        "f": 83886081
      },
      "n": "EnableLaneFlags",
      "d": 1439059,
      "h": 38656144723,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656144723),
//--TRIMMABLE-BOUNDARY-START(85900784979),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015883091,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260523347,
        "f": 83886081
      },
      "n": "RunningSlot",
      "d": 1439059,
      "h": 85900784979,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900784979),
//--TRIMMABLE-BOUNDARY-START(30066210131),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246079315,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490719571,
        "f": 83886081
      },
      "n": "CurrentSlice",
      "d": 1439059,
      "h": 30066210131,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066210131),
//--TRIMMABLE-BOUNDARY-START(34361177427),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836013907,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080654163,
        "f": 83886081
      },
      "n": "CurrentSliceElapsed",
      "d": 1439059,
      "h": 34361177427,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361177427),
//--TRIMMABLE-BOUNDARY-START(133145425235),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605817683,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128850457939,
        "f": 83886081
      },
      "n": "Statuses",
      "d": 1439059,
      "h": 133145425235,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133145425235)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771242835),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1439059,
      "h": 25771242835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771242835)
  ],
  "h": 1439059
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Statuses.TrafficControlStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Statuses${separator}TrafficControlStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1439059)
        
        

        //--TRIMMABLE-BOUNDARY-START(718163)
        $asm.$cls(`$CFEL.LCIDTMC.TrafficControlOverrideControlModel`, ($self) => class TrafficControlOverrideControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(17180587347)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180587347);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180587347)
            
            //--TRIMMABLE-BOUNDARY-START(21475554643)
            /*int */ get Command()
            {
                return 128;
            }
            //--TRIMMABLE-BOUNDARY-END(21475554643)
            
            //--TRIMMABLE-BOUNDARY-START(60130260307)
            /*int*/ Lane = 0;
            //--TRIMMABLE-BOUNDARY-END(60130260307)
            
            //--TRIMMABLE-BOUNDARY-START(90195031379)
            /*TrafficState*/ State = 0;
            //--TRIMMABLE-BOUNDARY-END(90195031379)
            
            //--TRIMMABLE-BOUNDARY-START(94489998675)
            /*int*/ Time = 0;
            //--TRIMMABLE-BOUNDARY-END(94489998675)
            
            //--TRIMMABLE-BOUNDARY-START(17180587347)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17180587347)
            
            static $h = 718163;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475554643),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065489235,
        "f": 50364417
      },
      "n": "Command",
      "d": 718163,
      "h": 21475554643,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475554643),
//--TRIMMABLE-BOUNDARY-START(60130260307),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655423827,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720194899,
        "f": 83886081
      },
      "n": "Lane",
      "d": 718163,
      "h": 60130260307,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130260307),
//--TRIMMABLE-BOUNDARY-START(90195031379),
    {
      "p": 1307987,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245358419,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310129491,
        "f": 83886081
      },
      "n": "State",
      "d": 718163,
      "h": 90195031379,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90195031379),
//--TRIMMABLE-BOUNDARY-START(94489998675),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835293011,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900064083,
        "f": 83886081
      },
      "n": "Time",
      "d": 718163,
      "h": 94489998675,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94489998675)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180587347),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 718163,
      "h": 17180587347,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180587347)
  ],
  "h": 718163
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Commands${separator}TrafficControlOverrideControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(718163)
        
        

        //--TRIMMABLE-BOUNDARY-START(2749779)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlLogModel`, ($self) => class TrafficControlLogModel extends $.$XBGm.LCICDi.iSmartDeviceLogModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297717075)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297717075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297717075)
            
            //--TRIMMABLE-BOUNDARY-START(4297717075)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297717075)
            
            static $h = 2749779;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceLogModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297717075),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2749779,
      "h": 4297717075,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297717075)
  ],
  "h": 2749779
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceLog, $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlLogModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlLogModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2749779)
        
        

        //--TRIMMABLE-BOUNDARY-START(3667283)
        $asm.$str(`$CFEL.LCIDTS$1.TrafficControlClickCommand`, ($self) => class TrafficControlClickCommand extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Toggle = 0;
            static CountDown = 1;
            static OnShot = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3667283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Toggle": 0n,
                    "CountDown": 1n,
                    "OnShot": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298634579)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298634579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298634579)
            
            //--TRIMMABLE-BOUNDARY-START(4298634579)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298634579)
            
            static $h = 3667283;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17183536467),
    {
      "t": 3667283,
      "n": "Toggle",
      "d": 3667283,
      "h": 17183536467,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183536467),
//--TRIMMABLE-BOUNDARY-START(8593601875),
    {
      "t": 3667283,
      "n": "CountDown",
      "d": 3667283,
      "h": 8593601875,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593601875),
//--TRIMMABLE-BOUNDARY-START(12888569171),
    {
      "t": 3667283,
      "n": "OnShot",
      "d": 3667283,
      "h": 12888569171,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888569171)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298634579),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3667283,
      "h": 4298634579,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298634579)
  ],
  "h": 3667283
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlClickCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlClickCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3667283)
        
        

        //--TRIMMABLE-BOUNDARY-START(1307987)
        $asm.$str(`$CFEL.LCIDTMC.TrafficState`, ($self) => class TrafficState extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static Standby = 0;
            static Go = 1;
            static Stop = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1307987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Standby": 0n,
                    "Go": 1n,
                    "Stop": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296275283)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296275283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296275283)
            
            //--TRIMMABLE-BOUNDARY-START(4296275283)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296275283)
            
            static $h = 1307987;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886209875),
    {
      "t": 1307987,
      "n": "Standby",
      "d": 1307987,
      "h": 12886209875,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886209875),
//--TRIMMABLE-BOUNDARY-START(8591242579),
    {
      "t": 1307987,
      "n": "Go",
      "d": 1307987,
      "h": 8591242579,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591242579),
//--TRIMMABLE-BOUNDARY-START(17181177171),
    {
      "t": 1307987,
      "n": "Stop",
      "d": 1307987,
      "h": 17181177171,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181177171)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296275283),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1307987,
      "h": 4296275283,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296275283)
  ],
  "h": 1307987
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Commands${separator}TrafficState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1307987)
        
        

        //--TRIMMABLE-BOUNDARY-START(4322643)
        $asm.$str(`$CFEL.LCIDTS$1.TrafficControlEnabledLane`, ($self) => class TrafficControlEnabledLane extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Lane1 = 1;
            static Lane2 = 2;
            static Lane3 = 4;
            static Lane4 = 8;
            static Lane5 = 16;
            static Lane6 = 32;
            static Lane7 = 64;
            static Lane8 = 128;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4322643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Lane1": 1n,
                    "Lane2": 2n,
                    "Lane3": 4n,
                    "Lane4": 8n,
                    "Lane5": 16n,
                    "Lane6": 32n,
                    "Lane7": 64n,
                    "Lane8": 128n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4299289939)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299289939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299289939)
            
            //--TRIMMABLE-BOUNDARY-START(4299289939)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299289939)
            
            static $h = 4322643;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(42953995603),
    {
      "t": 4322643,
      "n": "None",
      "d": 4322643,
      "h": 42953995603,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42953995603),
//--TRIMMABLE-BOUNDARY-START(8594257235),
    {
      "t": 4322643,
      "n": "Lane1",
      "d": 4322643,
      "h": 8594257235,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "Lane 1",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8594257235),
//--TRIMMABLE-BOUNDARY-START(12889224531),
    {
      "t": 4322643,
      "n": "Lane2",
      "d": 4322643,
      "h": 12889224531,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "Lane 2",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12889224531),
//--TRIMMABLE-BOUNDARY-START(17184191827),
    {
      "t": 4322643,
      "n": "Lane3",
      "d": 4322643,
      "h": 17184191827,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "Lane 3",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17184191827),
//--TRIMMABLE-BOUNDARY-START(21479159123),
    {
      "t": 4322643,
      "n": "Lane4",
      "d": 4322643,
      "h": 21479159123,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "Lane 4",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21479159123),
//--TRIMMABLE-BOUNDARY-START(25774126419),
    {
      "t": 4322643,
      "n": "Lane5",
      "d": 4322643,
      "h": 25774126419,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "Lane 5",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25774126419),
//--TRIMMABLE-BOUNDARY-START(30069093715),
    {
      "t": 4322643,
      "n": "Lane6",
      "d": 4322643,
      "h": 30069093715,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "Lane 6",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30069093715),
//--TRIMMABLE-BOUNDARY-START(34364061011),
    {
      "t": 4322643,
      "n": "Lane7",
      "d": 4322643,
      "h": 34364061011,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "Lane 7",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34364061011),
//--TRIMMABLE-BOUNDARY-START(38659028307),
    {
      "t": 4322643,
      "n": "Lane8",
      "d": 4322643,
      "h": 38659028307,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "Lane 8",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38659028307)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299289939),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4322643,
      "h": 4299289939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299289939)
  ],
  "h": 4322643,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlEnabledLane`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlEnabledLane`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4322643)
        
        

        //--TRIMMABLE-BOUNDARY-START(4453715)
        $asm.$str(`$CFEL.LCIDTS$1.TrafficControlMode`, ($self) => class TrafficControlMode extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Normal = 0;
            static Flash = 1;
            static Off = 2;
            static Disable = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4453715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Normal": 0n,
                    "Flash": 1n,
                    "Off": 2n,
                    "Disable": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4299421011)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299421011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299421011)
            
            //--TRIMMABLE-BOUNDARY-START(4299421011)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299421011)
            
            static $h = 4453715;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17184322899),
    {
      "t": 4453715,
      "n": "Normal",
      "d": 4453715,
      "h": 17184322899,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17184322899),
//--TRIMMABLE-BOUNDARY-START(12889355603),
    {
      "t": 4453715,
      "n": "Flash",
      "d": 4453715,
      "h": 12889355603,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889355603),
//--TRIMMABLE-BOUNDARY-START(21479290195),
    {
      "t": 4453715,
      "n": "Off",
      "d": 4453715,
      "h": 21479290195,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21479290195),
//--TRIMMABLE-BOUNDARY-START(8594388307),
    {
      "t": 4453715,
      "n": "Disable",
      "d": 4453715,
      "h": 8594388307,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8594388307)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299421011),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4453715,
      "h": 4299421011,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299421011)
  ],
  "h": 4453715
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlMode`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4453715)
        
        

        //--TRIMMABLE-BOUNDARY-START(259411)
        $asm.$cls(`$CFEL.LCIDT._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590194003)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590194003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590194003)
            
            //--TRIMMABLE-BOUNDARY-START(4295226707)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295226707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295226707)
            
            //--TRIMMABLE-BOUNDARY-START(4295226707)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295226707)
            
            static $h = 259411;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590194003),
    {
      "r": 65537,
      "n": "Execute",
      "d": 259411,
      "h": 8590194003,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590194003)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295226707),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 259411,
      "h": 4295226707,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295226707)
  ],
  "h": 259411
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(259411)
        
        

        //--TRIMMABLE-BOUNDARY-START(5698899)
        $asm.$cls(`$CFEL.LCIDTV$1.RoadAnimation`, ($self) => class RoadAnimation extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(107379881299)
            /*string */ get OptimizedComponentName()
            {
                return "roadanimation";
            }
            //--TRIMMABLE-BOUNDARY-END(107379881299)
            
            //--TRIMMABLE-BOUNDARY-START(133149685075)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133149685075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Device":
                    this.Device = $.$cast(parameter.Value, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(133149685075)
            
            //--TRIMMABLE-BOUNDARY-START(103084914003)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103084914003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Connection = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$KuVO.LCFCC.RemoteClientConnectionProxy, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(103084914003)
            
            //--TRIMMABLE-BOUNDARY-START(38660404563)
            /*RemoteClientConnectionProxy*/ Connection = null;
            //--TRIMMABLE-BOUNDARY-END(38660404563)
            
            //--TRIMMABLE-BOUNDARY-START(42955371859)
            /*TrafficControlClientAppDeviceViewModel?*/ Device = null;
            //--TRIMMABLE-BOUNDARY-END(42955371859)
            
            //--TRIMMABLE-BOUNDARY-START(17185568083)
            static /*string */ get BackgroundColor()
            {
                return "#00800070";
            }
            //--TRIMMABLE-BOUNDARY-END(17185568083)
            
            //--TRIMMABLE-BOUNDARY-START(111674848595)
            static /*string */ get RoadColor()
            {
                return "#635c2d";
            }
            //--TRIMMABLE-BOUNDARY-END(111674848595)
            
            //--TRIMMABLE-BOUNDARY-START(25775502675)
            /*void */ BuildLED(/*ISVGBuilder*/ svg, /*int*/ lane, /*int*/ led)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25775502675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string[]*/ let colors = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["#FF0000", "#FFFF00", "#00FF00"], [-1], null);
                const $t2 = this.Device;
                const $t3 = ($t) => $t.Received$1;
                const $t4 = ($t) => $t.Status;
                const $t5 = ($t) => $t.Statuses;
                /*var*/ let bits = $.$ifnn($t2, ($t) => $.$ifnn($t3($t), ($t) => $.$ifnn($t4($t), ($t) => $.$ifnn($t5($t), ($t) => $.$$.System.Array.$ReadT1.call($t, $.trunc(lane / 2)))))) >> ((4 * (lane % 2)) | 0);
                /*bool*/ let isOnline = bits !== null;
                /*bool*/ let isOn = ($.$$.S.Int32.op_BitwiseAnd$1((bits >> led), 1)) === 0;
                /*var*/ let color = $.$$.System.Array.$ReadT1.call(colors, led);
                if (!isOnline)
                {
                    color = "#80808020";
                }
                else 
                {
                    if (!isOn)
                    {
                        color += "30";
                    }
                }
                $.$hDPm.LCFCCSF.SVGBuilderExtension.OnClick$1(svg.LCFCCSF$ISVGBuilder$MoveTo(0.5, 0.5).LCFCCSF$ISVGCircleBuilder$Circle($.$hDPm.LCFCC$1.Dimension.op_Implicit(0.75)).LCFCCSF$ISVGBuilder$FillColor(color).LCFCCSF$ISVGBuilder$Attribute("class", "clickable"), new ($.$$.S.Func$$$($.$macw.MACW.MouseEventArgs, $.$$.STT.Task))().$ctor(this, /*async*/  (/**/ e) =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                    {
                        if (this.Device !== null)
                        {
                            let $t6, $r6;
                            /*var*/ let client = this.Connection.get_Item$3(`TrafficControl/${$.$strNN(this.Device.Model$1.UniqueId)}`);
                            ($t6 = $.$CFEL.LCIDTMC.TrafficControlDeviceCommands.OverrideControl(client, lane, led === 0 ? 2/*TrafficState.Stop*/ : led === 1 ? 0/*TrafficState.Standby*/ : 1/*TrafficState.Go*/, 40), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        }
                    });
                }, $THKYhg ??= {"r":178454529,"p":[{"n":"e","p":6750325}],"n":"","d":5698899,"h":0,"f":17829890}), this);
            }
            //--TRIMMABLE-BOUNDARY-END(25775502675)
            
            //--TRIMMABLE-BOUNDARY-START(34365437267)
            /*void */ BuildRYG(/*ISVGBuilder*/ svg, /*int*/ lane)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34365437267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                svg.LCFCCSF$ISVGGroupBuilder$Group(new ($.$$.S.Action$$($.$hDPm.LCFCCSF.ISVGBuilder))().$ctor(this,  (/*svg*/ svg) =>
                {
                    /*double*/ let arc = 0.1;
                    svg.LCFCCSF$ISVGPathBuilder$PathMoveTo(0, arc, false).LCFCCSF$ISVGPathBuilder$PathArcTo(arc, 0, 0.01, 0.01, false, false).LCFCCSF$ISVGPathBuilder$PathLineTo(1 - arc, 0, false).LCFCCSF$ISVGPathBuilder$PathArcTo(1, arc, 0.01, 0.01, false, false).LCFCCSF$ISVGPathBuilder$PathLineTo(1, 1 - arc, false).LCFCCSF$ISVGPathBuilder$PathArcTo(1 - arc, 1, 0.01, 0.01, false, false).LCFCCSF$ISVGPathBuilder$PathLineTo(arc, 1, false).LCFCCSF$ISVGPathBuilder$PathArcTo(0, 1 - arc, 0.01, 0.01, false, false).LCFCCSF$ISVGPathBuilder$PathLineTo(0, arc, false).LCFCCSF$ISVGPathBuilder$PathClose().LCFCCSF$ISVGPathBuilder$PathEnd().LCFCCSF$ISVGBuilder$FillColor("black");
                    $.$hDPm.LCFCCSF.SVGBuilderExtension.BoxStepX(svg, 0, 1, 3, new ($.$$.S.Action$$$($.$hDPm.LCFCCSF.ISVGBuilder, $.$$.S.Int32))().$ctor(this,  (/**/ svg, /*i*/ i) =>
                    {
                        this.BuildLED(svg, lane, i);
                    }, $UGgHhc ??= {"r":65537,"p":[{"n":"svg","p":46945962},{"n":"i","p":655361}],"n":"","d":5698899,"h":0,"f":17825794}));
                }, $kIVoza ??= {"r":65537,"p":[{"n":"svg","p":46945962}],"n":"","d":5698899,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(34365437267)
            
            //--TRIMMABLE-BOUNDARY-START(55840273747)
            /*void */ DrawRoundAbout(/*ISVGBuilder*/ svg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55840273747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                svg.LCFCCSF$ISVGGroupBuilder$Group(new ($.$$.S.Action$$($.$hDPm.LCFCCSF.ISVGBuilder))().$ctor(this,  (/*svg*/ svg) =>
                {
                    svg.LCFCCSF$ISVGBuilder$MoveTo(0.5, 0.5).LCFCCSF$ISVGCircleBuilder$Circle($.$hDPm.LCFCC$1.Dimension.op_Implicit(0.2)).LCFCCSF$ISVGBuilder$FillColor($.$CFEL.LCIDTV$1.RoadAnimation.RoadColor).LCFCCSF$ISVGBuilder$StrokeColor("#534c1d").LCFCCSF$ISVGBuilder$StrokeWidth(0.5);
                    svg.LCFCCSF$ISVGBuilder$MoveTo(0.5, 0.5).LCFCCSF$ISVGCircleBuilder$Circle($.$hDPm.LCFCC$1.Dimension.op_Implicit(0.1)).LCFCCSF$ISVGBuilder$FillColor("#00AEFF").LCFCCSF$ISVGBuilder$StrokeColor("white").LCFCCSF$ISVGBuilder$StrokeWidth(0.5);
                }, $GtJyaj ??= {"r":65537,"p":[{"n":"svg","p":46945962}],"n":"","d":5698899,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(55840273747)
            
            //--TRIMMABLE-BOUNDARY-START(47250339155)
            /*void */ DrawFloor(/*ISVGBuilder*/ svg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47250339155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                svg.LCFCCSF$ISVGBuilder$MoveTo(0, 0).LCFCCSF$ISVGRectangleBuilder$Rectangle(1, 1).LCFCCSF$ISVGBuilder$FillColor("transparent");
            }
            //--TRIMMABLE-BOUNDARY-END(47250339155)
            
            //--TRIMMABLE-BOUNDARY-START(51545306451)
            /*void */ DrawLane(/*ISVGBuilder*/ svg, /*int*/ lane)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51545306451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*double*/ let roadWidth = 0.2;
                svg.LCFCCSF$ISVGBuilder$MoveTo(0, 0.5 - roadWidth / 2).LCFCCSF$ISVGRectangleBuilder$Rectangle(1.5, roadWidth).LCFCCSF$ISVGBuilder$FillColor($.$CFEL.LCIDTV$1.RoadAnimation.RoadColor);
                svg.LCFCCSF$ISVGBuilder$MoveTo(0, 0.5 - roadWidth / 2).LCFCCSF$ISVGLineBuilder$LineTo(1.5, 0.5 - roadWidth / 2, false).LCFCCSF$ISVGBuilder$StrokeColor("white").LCFCCSF$ISVGBuilder$StrokeWidth(0.5);
                svg.LCFCCSF$ISVGBuilder$MoveTo(0, 0.5).LCFCCSF$ISVGLineBuilder$LineTo(1.5, 0.5, false).LCFCCSF$ISVGBuilder$StrokeColor("white").LCFCCSF$ISVGBuilder$Attribute("stroke-dasharray", "4 4").LCFCCSF$ISVGBuilder$StrokeWidth(0.5);
                svg.LCFCCSF$ISVGBuilder$MoveTo(0, 0.5 + roadWidth / 2).LCFCCSF$ISVGLineBuilder$LineTo(1.5, 0.5 + roadWidth / 2, false).LCFCCSF$ISVGBuilder$StrokeColor("white").LCFCCSF$ISVGBuilder$StrokeWidth(0.5);
                svg.LCFCCSF$ISVGBuilder$Box(0.4, 0.275, 0.3, 0.1, new ($.$$.S.Action$$($.$hDPm.LCFCCSF.ISVGBuilder))().$ctor(this,  (/*svg*/ svg) =>
                {
                    this.BuildRYG(svg, lane);
                }, $bBRqce ??= {"r":65537,"p":[{"n":"svg","p":46945962}],"n":"","d":5698899,"h":0,"f":17825794}));
                svg.LCFCCSF$ISVGBuilder$MoveTo(0.4, 0.5 - roadWidth / 2).LCFCCSF$ISVGTextBuilder$Text(`${$.$strNN(((lane + 1) | 0))}`).LCFCCSF$ISVGBuilder$BaseLine(7/*BaseLine.Hanging*/).LCFCCSF$ISVGBuilder$FillColor("white").LCFCCSF$ISVGBuilder$Attribute("font-size", "4");
            }
            //--TRIMMABLE-BOUNDARY-END(51545306451)
            
            //--TRIMMABLE-BOUNDARY-START(21480535379)
            /*RenderFragment */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21480535379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let svg = $.$hDPm.LCFCCSF.SVGBuilder.Create(100, 100, 3/*DimensionUnit.Proportional*/, true, 0, 0).LCFCCSF$ISVGBuilder$Attribute("class", "wf hf");
                this.DrawFloor(svg);
                /*int*/ let lanes = 4;
                /*var*/ let lf = (this.Device?.Received$1?.Status?.EnableLaneFlags ?? null);
                if (lf !== null)
                {
                    lanes = 0;
                    for(/*int*/ let i = 0; i < 32; i++)
                    {
                        if (($.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(lf) & 1 << i) !== 0)
                        {
                            lanes++;
                        }
                    }
                    if (lanes === 0)
                    {
                        lanes = 4;
                    }
                }
                $.$hDPm.LCFCCSF.SVGBuilderExtension.RadiusStep(svg, 0.5, lanes, new ($.$$.S.Action$$$$$$($.$hDPm.LCFCCSF.ISVGBuilder, $.$$.S.Int32, $.$$.S.Double, $.$$.S.Double, $.$$.S.Double))().$ctor(this,  (/*svg*/ svg, /*lane*/ lane, /*angle*/ angle, /*x*/ x, /*y*/ y) =>
                {
                    /*double*/ let roadWidth = 0.05;
                    /*var*/ let roadWidthdy = Math.cos(angle) * roadWidth;
                    /*var*/ let roadWidthdx = Math.sin(angle) * roadWidth;
                    svg.LCFCCSF$ISVGGroupBuilder$Group(new ($.$$.S.Action$$($.$hDPm.LCFCCSF.ISVGBuilder))().$ctor(this,  (/**/ svg) =>
                    {
                        svg.LCFCCSF$ISVGBuilder$Box(0.5, 0.25, 0.5, 0.5, new ($.$$.S.Action$$($.$hDPm.LCFCCSF.ISVGBuilder))().$ctor(this,  (/*svg*/ svg) =>
                        {
                            this.DrawLane(svg, lane);
                        }, $BEebri ??= {"r":65537,"p":[{"n":"svg","p":46945962}],"n":"","d":5698899,"h":0,"f":17825794}));
                    }, $GBfVcb ??= {"r":65537,"p":[{"n":"svg","p":46945962}],"n":"","d":5698899,"h":0,"f":17825794})).LCFCCSF$ISVGBuilder$Rotate$1(angle * 180 / 3.141592653589793/*Math.PI*/, 0.5, 0.5);
                }, $JrzeAj ??= {"r":65537,"p":[{"n":"svg","p":46945962},{"n":"lane","p":655361},{"n":"angle","p":1179649},{"n":"x","p":1179649},{"n":"y","p":1179649}],"n":"","d":5698899,"h":0,"f":17825794}), 0);
                this.DrawRoundAbout(svg);
                return svg.LCFCCSF$ISVGBuilder$Build();
            }
            //--TRIMMABLE-BOUNDARY-END(21480535379)
            
            //--TRIMMABLE-BOUNDARY-START(30070469971)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30070469971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.Build());
            }
            //--TRIMMABLE-BOUNDARY-END(30070469971)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12890600787)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890600787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12890600787)
            
            //--TRIMMABLE-BOUNDARY-START(12890600787)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12890600787)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38660404563)
                this.Connection = null;
                //--TRIMMABLE-BOUNDARY-END(38660404563)
                
            }
            static $h = 5698899;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107379881299),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90200012115,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 5698899,
      "h": 107379881299,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(107379881299),
//--TRIMMABLE-BOUNDARY-START(38660404563),
    {
      "p": 2485934,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73020142931,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120264783187,
        "f": 83886081
      },
      "n": "Connection",
      "d": 5698899,
      "h": 38660404563,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38660404563),
//--TRIMMABLE-BOUNDARY-START(42955371859),
    {
      "p": 5502291,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81610077523,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128854717779,
        "f": 83886081
      },
      "n": "Device",
      "d": 5698899,
      "h": 42955371859,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42955371859),
//--TRIMMABLE-BOUNDARY-START(17185568083),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64430208339,
        "f": 50331681
      },
      "n": "BackgroundColor",
      "d": 5698899,
      "h": 17185568083,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17185568083),
//--TRIMMABLE-BOUNDARY-START(111674848595),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98789946707,
        "f": 50331681
      },
      "n": "RoadColor",
      "d": 5698899,
      "h": 111674848595,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(111674848595)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(133149685075),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 5698899,
      "h": 133149685075,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(133149685075),
//--TRIMMABLE-BOUNDARY-START(103084914003),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 5698899,
      "h": 103084914003,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103084914003),
//--TRIMMABLE-BOUNDARY-START(25775502675),
    {
      "r": 65537,
      "p": [
        {
          "n": "svg",
          "p": 46945962
        },
        {
          "n": "lane",
          "p": 655361
        },
        {
          "n": "led",
          "p": 655361
        }
      ],
      "n": "BuildLED",
      "d": 5698899,
      "h": 25775502675,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25775502675),
//--TRIMMABLE-BOUNDARY-START(34365437267),
    {
      "r": 65537,
      "p": [
        {
          "n": "svg",
          "p": 46945962
        },
        {
          "n": "lane",
          "p": 655361
        }
      ],
      "n": "BuildRYG",
      "d": 5698899,
      "h": 34365437267,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34365437267),
//--TRIMMABLE-BOUNDARY-START(55840273747),
    {
      "r": 65537,
      "p": [
        {
          "n": "svg",
          "p": 46945962
        }
      ],
      "n": "DrawRoundAbout",
      "d": 5698899,
      "h": 55840273747,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55840273747),
//--TRIMMABLE-BOUNDARY-START(47250339155),
    {
      "r": 65537,
      "p": [
        {
          "n": "svg",
          "p": 46945962
        }
      ],
      "n": "DrawFloor",
      "d": 5698899,
      "h": 47250339155,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47250339155),
//--TRIMMABLE-BOUNDARY-START(51545306451),
    {
      "r": 65537,
      "p": [
        {
          "n": "svg",
          "p": 46945962
        },
        {
          "n": "lane",
          "p": 655361
        }
      ],
      "n": "DrawLane",
      "d": 5698899,
      "h": 51545306451,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51545306451),
//--TRIMMABLE-BOUNDARY-START(21480535379),
    {
      "r": 6881395,
      "n": "Build",
      "d": 5698899,
      "h": 21480535379,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21480535379),
//--TRIMMABLE-BOUNDARY-START(30070469971),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 5698899,
      "h": 30070469971,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30070469971)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12890600787),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5698899,
      "h": 12890600787,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12890600787)
  ],
  "h": 5698899
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCC$1.IManagedBaseComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Views.RoadAnimation`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Views${separator}RoadAnimation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5698899)
        
        

        //--TRIMMABLE-BOUNDARY-START(5764435)
        $asm.$cls(`$CFEL.LCIDTV$1.SlotEditor`, ($self) => class SlotEditor extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(98790012243)
            /*string */ get OptimizedComponentName()
            {
                return "sloteditor";
            }
            //--TRIMMABLE-BOUNDARY-END(98790012243)
            
            //--TRIMMABLE-BOUNDARY-START(163214521683)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163214521683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Index":
                    this.Index = $.$cast(parameter.Value, $.$$.S.Int32);
                    return true;
                    case "Device":
                    this.Device = $.$cast(parameter.Value, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel);
                    return true;
                    case "Update":
                    this.Update = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(163214521683)
            
            //--TRIMMABLE-BOUNDARY-START(94495044947)
            /*bool*/ open = false;
            //--TRIMMABLE-BOUNDARY-END(94495044947)
            
            //--TRIMMABLE-BOUNDARY-START(154624587091)
            /*void */ ToggleEditor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154624587091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.open = !this.open;
            }
            //--TRIMMABLE-BOUNDARY-END(154624587091)
            
            //--TRIMMABLE-BOUNDARY-START(90200077651)
            /*int*/ Index = 0;
            //--TRIMMABLE-BOUNDARY-END(90200077651)
            
            //--TRIMMABLE-BOUNDARY-START(30070535507)
            /*TrafficControlClientAppDeviceViewModel?*/ Device = null;
            //--TRIMMABLE-BOUNDARY-END(30070535507)
            
            //--TRIMMABLE-BOUNDARY-START(167509488979)
            /*EventCallback<TrafficControlSlotSettings>*/ Update;
            //--TRIMMABLE-BOUNDARY-END(167509488979)
            
            //--TRIMMABLE-BOUNDARY-START(150329619795)
            /*DateTime */ get StartTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77315175763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.S.DateTime().$ctor$16($.$$.S.DateTime.Now.Year, $.$$.S.DateTime.Now.Month, $.$$.S.DateTime.Now.Day, $.$$.S.Math.Max$4(0, $.$$.S.Math.Min$4(23, this.ViewModel.Start.Hour)), $.$$.S.Math.Max$4(0, $.$$.S.Math.Min$4(59, this.ViewModel.Start.Minute)), 0);
            }
            /*DateTime */ set StartTime(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137444717907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.DateTime.op_Equality(value, $.$$.S.DateTime.MinValue))
                {
                    this.ViewModel.Start.Hour = -1;
                    this.ViewModel.Start.Minute = -1;
                    this.ViewModel.StartEnabled = false;
                }
                else 
                {
                    this.ViewModel.Start.Hour = value.Hour;
                    this.ViewModel.Start.Minute = value.Minute;
                    this.ViewModel.StartEnabled = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150329619795)
            
            //--TRIMMABLE-BOUNDARY-START(34365502803)
            /*DateTime */ get EndTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51545371987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.S.DateTime().$ctor$16($.$$.S.DateTime.Now.Year, $.$$.S.DateTime.Now.Month, $.$$.S.DateTime.Now.Day, $.$$.S.Math.Max$4(0, $.$$.S.Math.Min$4(23, this.ViewModel.End.Hour)), $.$$.S.Math.Max$4(0, $.$$.S.Math.Min$4(59, this.ViewModel.End.Minute)), 0);
            }
            /*DateTime */ set EndTime(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120264848723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.DateTime.op_Equality(value, $.$$.S.DateTime.MinValue))
                {
                    this.ViewModel.End.Hour = -1;
                    this.ViewModel.End.Minute = -1;
                    this.ViewModel.EndEnabled = false;
                }
                else 
                {
                    this.ViewModel.End.Hour = value.Hour;
                    this.ViewModel.End.Minute = value.Minute;
                    this.ViewModel.EndEnabled = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34365502803)
            
            //--TRIMMABLE-BOUNDARY-START(21480600915)
            /*void */ AddSlice()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21480600915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ViewModel.Slices = $.$sl.SL.Enumerable.ToArray($.$CFEL.LCIDTS$1.TrafficSlice, $.$sl.SL.Enumerable.Concat($.$CFEL.LCIDTS$1.TrafficSlice, (this.ViewModel.Slices ?? $.$sl.SL.Enumerable.Empty($.$CFEL.LCIDTS$1.TrafficSlice)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$CFEL.LCIDTS$1.TrafficSlice), [(() =>
                {
                    //new $.$CFEL.LCIDTS$1.TrafficSlice()
                    const $t2 = $.$CFEL.LCIDTS$1.TrafficSlice;
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    return $i2;
                })()], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(21480600915)
            
            //--TRIMMABLE-BOUNDARY-START(103084979539)
            /*void */ RemoveSlice(/*TrafficSlice*/ slice)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103084979539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficSlice[]?*/ let __ca1__;
                this.ViewModel.Slices = ((__ca1__ = this.ViewModel.Slices) !== null ? $.$sl.SL.Enumerable.ToArray($.$CFEL.LCIDTS$1.TrafficSlice, $.$sl.SL.Enumerable.Except$1($.$CFEL.LCIDTS$1.TrafficSlice, __ca1__, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$CFEL.LCIDTS$1.TrafficSlice), [slice], null, null))) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(103084979539)
            
            //--TRIMMABLE-BOUNDARY-START(158919554387)
            /*void */ ToggleGo(/*int*/ lane_i, /*int*/ slice_i)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158919554387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficLaneSliceRelationship[]?*/ let __ca2__;
                /*var*/ let existing = ((__ca2__ = this.ViewModel.Relationships) !== null ? $.$sl.SL.Enumerable.Where($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship, __ca2__, new ($.$$.S.Func$$$($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship, $.$$.S.Boolean))().$ctor(this,  (/*r*/ r) =>
                {
                    return r.SliceId === slice_i && r.LaneId === lane_i;
                }, $FeXyRi ??= {"r":262145,"p":[{"n":"r","p":4846931}],"n":"","d":5764435,"h":0,"f":17825794})) : null);
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficLaneSliceRelationship>?*/ let __ca3__;
                if ((__ca3__ = existing) !== null ? $.$sl.SL.Enumerable.Any$1($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship, __ca3__) : false)
                {
                    /*LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficLaneSliceRelationship[]?*/ let __ca4__;
                    this.ViewModel.Relationships = ((__ca4__ = this.ViewModel.Relationships) !== null ? $.$sl.SL.Enumerable.ToArray($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship, $.$sl.SL.Enumerable.Except$1($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship, __ca4__, existing)) : null);
                }
                else 
                {
                    this.ViewModel.Relationships = $.$sl.SL.Enumerable.ToArray($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship, $.$sl.SL.Enumerable.Concat($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship, (this.ViewModel.Relationships ?? $.$sl.SL.Enumerable.Empty($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship), [(() =>
                    {
                        //new $.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship()
                        const $t3 = $.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship;
                        const $i3 = new $t3();
                        $i3.$ctor$1();
                        $i3.SliceId = slice_i;
                        $i3.LaneId = lane_i;
                        return $i3;
                    })()], null, null)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158919554387)
            
            //--TRIMMABLE-BOUNDARY-START(25775568211)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25775568211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pd bg-chart1-01 corner stack mgt");
                __builder.AddMarkupContent(2, "<small>Schedule</small>\r\n    ");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "row");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 5, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToggleEditor)));
                __builder.OpenElement(6, "div");
                __builder.AddAttribute$5(7, "class", "col-a fsz-30 font-cursive pos-rel");
                $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder, 8, "onclick", true);
                __builder.OpenElement(9, "span");
                __builder.AddAttribute$5(10, "class", "nowrap");
                __builder.AddContent$4(11, `${$.$strNN((this.ViewModel.StartEnabled && this.ViewModel.Start.Hour >= 0 ? (() =>
                {
                    var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(0, 1);
                    $handler.AppendFormatted($.$box(this.ViewModel.Start.Hour, $.$$.S.Int32), null, "D2");
                    return $handler.ToStringAndClear            ();
                })() : "XX"))}:${$.$strNN((this.ViewModel.StartEnabled && this.ViewModel.Start.Minute >= 0 ? (() =>
                {
                    var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(0, 1);
                    $handler.AppendFormatted($.$box(this.ViewModel.Start.Minute, $.$$.S.Int32), null, "D2");
                    return $handler.ToStringAndClear            ();
                })() : "XX"))}`);
                __builder.CloseElement();
                __builder.AddMarkupContent(12, "\r\n            ");
                __builder.OpenElement(13, "input");
                __builder.AddAttribute$5(14, "class", "pos-abs t-0 b-0 r-0 l-0 mawp-10");
                __builder.AddAttribute$5(15, "type", "time");
                __builder.AddAttribute$5(16, "style", "opacity:0");
                __builder.AddAttribute$5(17, "value", $.$mac.MAC.BindConverter.FormatValue$4(this.StartTime, "HH:mm:ss", $.$$.SG.CultureInfo.InvariantCulture));
                __builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 18, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$4($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.DateTime))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.StartTime = __value;
                }, $qOpRSe ??= {"r":65537,"p":[{"n":"__value","p":65994753}],"n":"","d":5764435,"h":0,"f":17825794}), this.StartTime, "HH:mm:ss", $.$$.SG.CultureInfo.InvariantCulture));
                __builder.SetUpdatesAttributeName("value");
                __builder.CloseElement();
                __builder.AddMarkupContent(19, "\r\n            ");
                __builder.OpenElement(20, "button");
                __builder.AddAttribute$5(21, "class", "mdi mdi-close cl-error pos-abs b-0 l-0 pd-0 bg-transparent");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 22, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                {
                    return this.StartTime = new $.$$.S.DateTime();
                }, $lgluBk ??= {"r":65537,"n":"","d":5764435,"h":0,"f":17825794})));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(23, "\r\n        ");
                __builder.AddMarkupContent(24, "<div class=\"stack mgx col-a\"><span class=\"mgy-a\">-</span></div>\r\n        ");
                __builder.OpenElement(25, "div");
                __builder.AddAttribute$5(26, "class", "col-a fsz-30 font-cursive pos-rel");
                $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder, 27, "onclick", true);
                __builder.OpenElement(28, "span");
                __builder.AddAttribute$5(29, "class", "nowrap");
                __builder.AddContent$4(30, `${$.$strNN((this.ViewModel.EndEnabled && this.ViewModel.End.Hour >= 0 ? (() =>
                {
                    var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(0, 1);
                    $handler.AppendFormatted($.$box(this.ViewModel.End.Hour, $.$$.S.Int32), null, "D2");
                    return $handler.ToStringAndClear            ();
                })() : "XX"))}:${$.$strNN((this.ViewModel.EndEnabled && this.ViewModel.End.Minute >= 0 ? (() =>
                {
                    var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(0, 1);
                    $handler.AppendFormatted($.$box(this.ViewModel.End.Minute, $.$$.S.Int32), null, "D2");
                    return $handler.ToStringAndClear            ();
                })() : "XX"))}`);
                __builder.CloseElement();
                __builder.AddMarkupContent(31, "\r\n            ");
                __builder.OpenElement(32, "input");
                __builder.AddAttribute$5(33, "class", "pos-abs t-0 b-0 r-0 l-0 mawp-10");
                __builder.AddAttribute$5(34, "type", "time");
                __builder.AddAttribute$5(35, "style", "opacity:0");
                __builder.AddAttribute$5(36, "value", $.$mac.MAC.BindConverter.FormatValue$4(this.EndTime, "HH:mm:ss", $.$$.SG.CultureInfo.InvariantCulture));
                __builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 37, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$4($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.DateTime))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.EndTime = __value;
                }, $Dwsdmc ??= {"r":65537,"p":[{"n":"__value","p":65994753}],"n":"","d":5764435,"h":0,"f":17825794}), this.EndTime, "HH:mm:ss", $.$$.SG.CultureInfo.InvariantCulture));
                __builder.SetUpdatesAttributeName("value");
                __builder.CloseElement();
                __builder.AddMarkupContent(38, "\r\n            ");
                __builder.OpenElement(39, "button");
                __builder.AddAttribute$5(40, "class", "mdi mdi-close cl-error pos-abs b-0 l-0 pd-0 bg-transparent");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 41, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                {
                    return this.EndTime = new $.$$.S.DateTime();
                }, $QOWZvd ??= {"r":65537,"n":"","d":5764435,"h":0,"f":17825794})));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(42, "\r\n        <div class=\"fill stack mgl\"></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(43, "\r\n    ");
                __builder.OpenElement(44, "div");
                __builder.AddAttribute$5(45, "class", "flex mgt mgl-a");
                $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder, 46, "onclick", true);
                let $en4 = $.$$.S.Array.GetEnumerator.call($.$$.S.Enum.GetValues($.$fPer.LCFCDC.WeekDays.$type));
                while ($en4.SC$1$IEnumerator$MoveNext())
                {
                    let day = $en4.SC$1$IEnumerator$Current;
                    {
                        /*var*/ let _day = $.$cast(day, $.$fPer.LCFCDC.WeekDays);
                        if (_day !== 0/*WeekDays.None*/)
                        {
                            __builder.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$fPer.LCFCDC.WeekDays), 47);
                            __builder.AddComponentParameter(48, "CommandParameter", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCDC.WeekDays, _day), $.$fPer.LCFCDC.WeekDays));
                            __builder.AddComponentParameter(49, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$fPer.LCFCDC.WeekDays), $.$mac.MAC.EventCallback.Factory.Create$8($.$fPer.LCFCDC.WeekDays, this, new ($.$$.S.Action$$($.$fPer.LCFCDC.WeekDays))().$ctor(this,  (/*c*/ c) =>
                            {
                                return this.ViewModel.Start.Weekday ^= c;
                            }, $hjpjDh ??= {"r":65537,"p":[{"n":"c","p":7440726}],"n":"","d":5764435,"h":0,"f":17825794}))));
                            __builder.AddComponentParameter(50, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, ((this.ViewModel.Start.Weekday & (_day)) == (_day)) ? $.$fPer.LCFC.Theme.Primary : $.$fPer.LCFC.Theme.Card));
                            __builder.AddComponentParameter(51, "Class", "mgl-3 hx-03 wx-03 round flex !pd");
                            __builder.AddComponentParameter(52, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ & ~131072/*ButtonFeatures.Pad*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                            __builder.AddAttribute$3(53, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                            {
                                __builder2.OpenElement(54, "span");
                                __builder2.AddAttribute$5(55, "class", "mg-a");
                                __builder2.AddContent$3(56, $.$box($.$$.S.String.get_Chars.call($.$$.S.Enum.ToStringT($.$fPer.LCFCDC.WeekDays, $.$$.S.UInt32, _day), 0), $.$$.S.Char));
                                __builder2.CloseElement();
                            }), $TfCAQa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":5764435,"h":0,"f":17825794}));
                            __builder.CloseComponent();
                        }
                    }
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(57, "\r\n\r\n");
                __builder.OpenElement(58, "div");
                __builder.AddAttribute$5(59, "class", "pd bg-chart1-01 corner stack mgt");
                __builder.AddMarkupContent(60, "<small>Enable Lane</small>\r\n    ");
                __builder.OpenElement(61, "div");
                __builder.AddAttribute$5(62, "class", "flex mgt");
                let $i5 = 0;
                let $arr5 = $.$$.S.Enum.GetValues$1($.$CFEL.LCIDTS$1.TrafficControlEnabledLane);
                while ($i5 < $arr5.length)
                {
                    let mlane = $arr5[$i5++];
                    /*var*/ let _lane = mlane;
                    if (_lane !== 0/*TrafficControlEnabledLane.None*/)
                    {
                        __builder.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$CFEL.LCIDTS$1.TrafficControlEnabledLane), 63);
                        __builder.AddComponentParameter(64, "CommandParameter", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$CFEL.LCIDTS$1.TrafficControlEnabledLane, _lane), $.$CFEL.LCIDTS$1.TrafficControlEnabledLane));
                        __builder.AddComponentParameter(65, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$CFEL.LCIDTS$1.TrafficControlEnabledLane), $.$mac.MAC.EventCallback.Factory.Create$8($.$CFEL.LCIDTS$1.TrafficControlEnabledLane, this, new ($.$$.S.Action$$($.$CFEL.LCIDTS$1.TrafficControlEnabledLane))().$ctor(this,  (/**/ c) =>
                        {
                            return this.ViewModel.EnableLaneFlags ^= c;
                        }, $TaWJge ??= {"r":65537,"p":[{"n":"c","p":4322643}],"n":"","d":5764435,"h":0,"f":17825794}))));
                        __builder.AddComponentParameter(66, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, ((this.ViewModel.EnableLaneFlags & (mlane)) == (mlane)) ? $.$fPer.LCFC.Theme.Primary : $.$fPer.LCFC.Theme.Card));
                        __builder.AddComponentParameter(67, "Class", "mgr-3 hx-03 wx-03 round flex !pd");
                        __builder.AddComponentParameter(68, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ & ~131072/*ButtonFeatures.Pad*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder.AddAttribute$3(69, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenElement(70, "span");
                            __builder2.AddAttribute$5(71, "class", "mg-a");
                            __builder2.AddContent$4(72, $.$$.S.String.Replace$3.call($.$$.S.Enum.ToStringT($.$CFEL.LCIDTS$1.TrafficControlEnabledLane, $.$$.S.UInt32, _lane), "Lane", ""));
                            __builder2.CloseElement();
                        }), $ScLtKh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":5764435,"h":0,"f":17825794}));
                        __builder.CloseComponent();
                    }
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(73, "\r\n\r\n");
                __builder.OpenElement(74, "div");
                __builder.AddAttribute$5(75, "class", "pd bg-chart1-01 corner stack mgt");
                __builder.AddMarkupContent(76, "<small>Mode</small>\r\n    ");
                $.$CFEL._LCIDTVS.TypeInference.CreateInputEditor_0($.$CFEL.LCIDTS$1.TrafficControlMode, __builder, 77, 78, $.$fPer.LCFC.Theme.Primary, 79, "Mode", 80, this.ViewModel.Mode, 81, $.$mac.MAC.EventCallback.Factory.Create$6($.$CFEL.LCIDTS$1.TrafficControlMode, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$CFEL.LCIDTS$1.TrafficControlMode, this, new ($.$$.S.Action$$($.$CFEL.LCIDTS$1.TrafficControlMode))().$ctor(this,  (/**/ __value) =>
                {
                    return this.ViewModel.Mode = __value;
                }, $yvDAKj ??= {"r":65537,"p":[{"n":"__value","p":4453715}],"n":"","d":5764435,"h":0,"f":17825794}), this.ViewModel.Mode)), 82, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                {
                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "ViewModel"), "Mode"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                }, $XfyDJa ??= {"r":38797349,"n":"","d":5764435,"h":0,"f":17825794})).Invoke()));
                __builder.CloseElement();
                __builder.AddMarkupContent(83, "\r\n\r\n");
                __builder.OpenElement(84, "div");
                __builder.AddAttribute$5(85, "class", "pd bg-chart1-01 corner stack mgt");
                __builder.AddMarkupContent(86, "<small>Standby Time(s)</small>\r\n    ");
                $.$CFEL._LCIDTVS.TypeInference.CreateInputEditor_1($.$$.S.Int32, __builder, 87, 88, $.$fPer.LCFC.Theme.Primary, 89, "Standby Time", 90, this.ViewModel.StandbyTime, 91, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Int32, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Int32, this, new ($.$$.S.Action$$($.$$.S.Int32))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.ViewModel.StandbyTime = __value;
                }, $EDJdKc ??= {"r":65537,"p":[{"n":"__value","p":655361}],"n":"","d":5764435,"h":0,"f":17825794}), this.ViewModel.StandbyTime)), 92, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                {
                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "ViewModel"), "StandbyTime"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                }, $wWssVd ??= {"r":38797349,"n":"","d":5764435,"h":0,"f":17825794})).Invoke()));
                __builder.CloseElement();
                /*bool*/ let showStandbyTime = true;
                __builder.OpenElement(93, "div");
                __builder.AddAttribute$5(94, "class", "pd bg-chart1-01 corner stack mgt");
                __builder.AddMarkupContent(95, "<small>Time slices</small>");
                /*LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficSlice[]?*/ let __ca1__;
                if ((__ca1__ = this.ViewModel.Slices) !== null ? $.$sl.SL.Enumerable.Any$1($.$CFEL.LCIDTS$1.TrafficSlice, __ca1__) : false)
                {
                    __builder.OpenElement(96, "div");
                    __builder.AddAttribute$5(97, "class", "mgt wf scroll mawx-4");
                    __builder.OpenElement(98, "table");
                    __builder.AddAttribute$5(99, "class", "wf");
                    __builder.AddAttribute$5(100, "style", "border-collapse:collapse");
                    __builder.OpenElement(101, "thead");
                    __builder.OpenElement(102, "tr");
                    __builder.AddMarkupContent(103, "<td class=\"bdb bg-card fsz-11\">Time(s)</td>");
                    /*int*/ let ih = 1;
                    let $i6 = 0;
                    let $arr6 = this.ViewModel.Slices;
                    while ($i6 < $arr6.length)
                    {
                        let _slice = $arr6[$i6++];
                        /*var*/ let slice = _slice;
                        __builder.OpenElement(104, "td");
                        __builder.AddAttribute$5(105, "class", "nobreak bdb bdr bg-card");
                        __builder.AddAttribute$5(106, "colspan", /*showStandbyTime ?*/ "2"/* : "1"*/);
                        __builder.OpenElement(107, "div");
                        __builder.AddAttribute$5(108, "class", "flex");
                        __builder.OpenElement(109, "input");
                        __builder.AddAttribute$5(110, "type", "number");
                        __builder.AddAttribute$5(111, "class", "bg-transparent fw-bold wx-04 bd");
                        __builder.AddAttribute$5(112, "value", $.$mac.MAC.BindConverter.FormatValue$10(slice.Period, $.$$.SG.CultureInfo.InvariantCulture));
                        __builder.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 113, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$10($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.Int32))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            return slice.Period = __value;
                        }, $ehpyub ??= {"r":65537,"p":[{"n":"__value","p":655361}],"n":"","d":5764435,"h":0,"f":17825794}), slice.Period, $.$$.SG.CultureInfo.InvariantCulture));
                        __builder.SetUpdatesAttributeName("value");
                        __builder.CloseElement();
                        __builder.AddMarkupContent(114, "\r\n                                    ");
                        __builder.OpenElement(115, "button");
                        __builder.AddAttribute$5(116, "class", "mdi mdi-delete fsz-small cl-error bg-transparent pd-0");
                        __builder.AddAttribute$5(117, "title", "Remove Slice");
                        __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 118, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                        {
                            return this.RemoveSlice(slice);
                        }, $ntnqFj ??= {"r":65537,"n":"","d":5764435,"h":0,"f":17825794})));
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.CloseElement();
                        ih++;
                    }
                    __builder.OpenElement(119, "td");
                    __builder.OpenElement(120, "button");
                    __builder.AddAttribute$5(121, "class", "mdi mdi-plus cl-primary");
                    __builder.AddAttribute$5(122, "title", "Add Slice");
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 123, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.AddSlice)));
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(124, "\r\n                ");
                    __builder.OpenElement(125, "tbody");
                    /*int*/ let il = 1;
                    let $i7 = 0;
                    let $arr7 = $.$$.S.Enum.GetValues$1($.$CFEL.LCIDTS$1.TrafficControlEnabledLane);
                    while ($i7 < $arr7.length)
                    {
                        let lane = $arr7[$i7++];
                        if (lane === 0/*TrafficControlEnabledLane.None*/)
                        {
                            continue;
                        }
                        if (((this.ViewModel.EnableLaneFlags & (lane)) == (lane)))
                        {
                            __builder.OpenElement(126, "tr");
                            __builder.OpenElement(127, "td");
                            __builder.OpenElement(128, "b");
                            __builder.AddAttribute$5(129, "class", "nobreak");
                            __builder.AddContent$4(130, $.$fPer.LCFCT.EnumExtensions.GetTitle($.$box(lane, $.$CFEL.LCIDTS$1.TrafficControlEnabledLane)));
                            __builder.CloseElement();
                            __builder.CloseElement();
                            /*int*/ let i_s = 1;
                            let $i8 = 0;
                            let $arr8 = this.ViewModel.Slices;
                            while ($i8 < $arr8.length)
                            {
                                let slice = $arr8[$i8++];
                                /*var*/ let totalSliceTime = ((((this.ViewModel.StandbyTime * 1000) | 0) + ((slice.Period * 1000) | 0)) | 0);
                                /*var*/ let l_i = il;
                                /*var*/ let s_i = i_s;
                                /*LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficLaneSliceRelationship[]?*/ let __ca2__;
                                /*var*/ let go = ((__ca2__ = this.ViewModel.Relationships) !== null ? $.$sl.SL.Enumerable.Any($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship, __ca2__, new ($.$$.S.Func$$$($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship, $.$$.S.Boolean))().$ctor(this,  (/*r*/ r) =>
                                {
                                    return r.SliceId === i_s && r.LaneId === il;
                                }, $OSJwmg ??= {"r":262145,"p":[{"n":"r","p":4846931}],"n":"","d":5764435,"h":0,"f":17825794})) : false);
                                /*int*/ let previous_slice_i = ((i_s - 1) | 0);
                                if (previous_slice_i < 0)
                                {
                                    previous_slice_i = (($.$sl.SL.Enumerable.Count$1($.$CFEL.LCIDTS$1.TrafficSlice, this.ViewModel.Slices) - 1) | 0);
                                }
                                /*LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficLaneSliceRelationship[]?*/ let __ca3__;
                                /*var*/ let previousGo = ((__ca3__ = this.ViewModel.Relationships) !== null ? $.$sl.SL.Enumerable.Any($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship, __ca3__, new ($.$$.S.Func$$$($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship, $.$$.S.Boolean))().$ctor(this,  (/*r*/ r) =>
                                {
                                    return r.SliceId === previous_slice_i && r.LaneId === il;
                                }, $PKSZTf ??= {"r":262145,"p":[{"n":"r","p":4846931}],"n":"","d":5764435,"h":0,"f":17825794})) : false);
                                if (showStandbyTime && go !== previousGo)
                                {
                                    __builder.OpenElement(131, "td");
                                    __builder.AddAttribute$5(132, "class", "bdb clickable bg-warning");
                                    __builder.AddAttribute$5(133, "style", "padding:1px");
                                    __builder.AddAttribute$5(134, "title", `Standby: ${$.$strNN(this.ViewModel.StandbyTime)}s`);
                                    __builder.CloseElement();
                                }
                                __builder.OpenElement(135, "td");
                                __builder.AddAttribute$5(136, "class", $.$strNN($.$strNN($.$strNN($.$strNN("bdb" + " bdr") + " pd") + " clickable") + " ") + $.$strNN((go ? "bg-success" : "bg-error")));
                                __builder.AddAttribute$5(137, "colspan", showStandbyTime && go === previousGo ? "2" : "1");
                                __builder.AddAttribute$5(138, "title", `${$.$strNN((go ? "Go" : "Stop"))}: ${$.$strNN(slice.Period)}s`);
                                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 139, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                {
                                    return this.ToggleGo(l_i, s_i);
                                }, $sAkOUd ??= {"r":65537,"n":"","d":5764435,"h":0,"f":17825794})));
                                __builder.CloseElement();
                                i_s++;
                            }
                            __builder.AddMarkupContent(140, "<td></td>");
                            __builder.CloseElement();
                            il++;
                        }
                    }
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 141);
                    __builder.AddComponentParameter(142, "Message", "Traffic control requires time slices during which lanes are passed");
                    __builder.AddComponentParameter(143, "ButtonText", "Add a Slice");
                    __builder.AddComponentParameter(144, "Class", "mgt");
                    __builder.AddComponentParameter(145, "ButtonClick", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback, $.$mac.MAC.EventCallback.Factory.Create$1(this, new $.$$.S.Action().$ctor(this, this.AddSlice))));
                    __builder.CloseComponent();
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(25775568211)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17185633619)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185633619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17185633619)
            
            //--TRIMMABLE-BOUNDARY-START(17185633619)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(17185633619)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(167509488979)
                this.Update = $.$default($.$mac.MAC.EventCallback$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings));
                //--TRIMMABLE-BOUNDARY-END(167509488979)
                
            }
            static $h = 5764435;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98790012243),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68725241171,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 5764435,
      "h": 98790012243,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(98790012243),
//--TRIMMABLE-BOUNDARY-START(90200077651),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60135306579,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128854783315,
        "f": 83886081
      },
      "n": "Index",
      "d": 5764435,
      "h": 90200077651,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90200077651),
//--TRIMMABLE-BOUNDARY-START(30070535507),
    {
      "p": 5502291,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42955437395,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111674914131,
        "f": 83886081
      },
      "n": "Device",
      "d": 5764435,
      "h": 30070535507,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30070535507),
//--TRIMMABLE-BOUNDARY-START(167509488979),
    {
      "p": $.$mac.MAC.EventCallback$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85905110355,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146034652499,
        "f": 83886081
      },
      "n": "Update",
      "d": 5764435,
      "h": 167509488979,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167509488979),
//--TRIMMABLE-BOUNDARY-START(150329619795),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77315175763,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137444717907,
        "f": 83886082
      },
      "n": "StartTime",
      "d": 5764435,
      "h": 150329619795,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(150329619795),
//--TRIMMABLE-BOUNDARY-START(34365502803),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51545371987,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120264848723,
        "f": 83886082
      },
      "n": "EndTime",
      "d": 5764435,
      "h": 34365502803,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(34365502803)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(163214521683),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 5764435,
      "h": 163214521683,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(163214521683),
//--TRIMMABLE-BOUNDARY-START(154624587091),
    {
      "r": 65537,
      "n": "ToggleEditor",
      "d": 5764435,
      "h": 154624587091,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(154624587091),
//--TRIMMABLE-BOUNDARY-START(21480600915),
    {
      "r": 65537,
      "n": "AddSlice",
      "d": 5764435,
      "h": 21480600915,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21480600915),
//--TRIMMABLE-BOUNDARY-START(103084979539),
    {
      "r": 65537,
      "p": [
        {
          "n": "slice",
          "p": 4912467
        }
      ],
      "n": "RemoveSlice",
      "d": 5764435,
      "h": 103084979539,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103084979539),
//--TRIMMABLE-BOUNDARY-START(158919554387),
    {
      "r": 65537,
      "p": [
        {
          "n": "lane_i",
          "p": 655361
        },
        {
          "n": "slice_i",
          "p": 655361
        }
      ],
      "n": "ToggleGo",
      "d": 5764435,
      "h": 158919554387,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(158919554387),
//--TRIMMABLE-BOUNDARY-START(25775568211),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 5764435,
      "h": 25775568211,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25775568211)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(94495044947),
    {
      "t": 262145,
      "n": "open",
      "d": 5764435,
      "h": 94495044947,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(94495044947)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17185633619),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5764435,
      "h": 17185633619,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17185633619)
  ],
  "h": 5764435
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Views.SlotEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Views${separator}SlotEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5764435)
        
        

        //--TRIMMABLE-BOUNDARY-START(4715859)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor`, ($self) => class TrafficControlSlotSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299683155)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299683155);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor.GenerateProperties($.$CFEL.LCIDTS$1.TrafficControlSlotSettings, this, factory);
                    }, $ZJErMe ??= {"r":65537,"n":"","d":4715859,"h":0,"f":17825794}), 0, "TrafficControlSlotSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TrafficControl\\Settings_TrafficControlDeviceHardwareSettings_LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettingsTypeDescriptorBuilder.g.cs", "TrafficControlSlotSettingsTypeDescriptor", 41);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299683155)
            
            //--TRIMMABLE-BOUNDARY-START(12889617747)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889617747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Magic"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings.$type, $.$discardRef(), "Magic", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Magic")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Magic";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings)).Magic);
                        }, $Pfedwh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4715859,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Magic = value.AsInt();
                        }, $CzaCAc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4715859,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Start"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings.$type, $.$discardRef(), "Start", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Start")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDC.MaskableDateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Start";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$fPer.LCFCDC.MaskableDateTime, ($.$cast(target, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings)).Start);
                        }, $owZsaf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4715859,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Start = value.AsReference($.$fPer.LCFCDC.MaskableDateTime);
                        }, $mmJCfg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4715859,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("End"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings.$type, $.$discardRef(), "End", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("End")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDC.MaskableDateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "End";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettings";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$fPer.LCFCDC.MaskableDateTime, ($.$cast(target, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings)).End);
                        }, $jhLyBg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4715859,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.End = value.AsReference($.$fPer.LCFCDC.MaskableDateTime);
                        }, $SGsjnj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4715859,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("StandbyTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings.$type, $.$discardRef(), "StandbyTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("StandbyTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "StandbyTime";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettings";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings)).StandbyTime);
                        }, $MwILgk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4715859,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.StandbyTime = value.AsInt();
                        }, $ThPyld ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4715859,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Mode"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings.$type, $.$discardRef(), "Mode", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Mode")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$CFEL.LCIDTS$1.TrafficControlMode, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Mode";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettings";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$CFEL.LCIDTS$1.TrafficControlMode, ($.$cast(target, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings)).Mode);
                        }, $ukVbSk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4715859,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Mode = value.AsEnumValue($.$CFEL.LCIDTS$1.TrafficControlMode);
                        }, $xThvyf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4715859,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("EnableLaneFlags"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings.$type, $.$discardRef(), "EnableLaneFlags", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("EnableLaneFlags")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$CFEL.LCIDTS$1.TrafficControlEnabledLane, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "EnableLaneFlags";
                        $i11.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettings";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$CFEL.LCIDTS$1.TrafficControlEnabledLane, ($.$cast(target, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings)).EnableLaneFlags);
                        }, $uKNVyj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4715859,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.EnableLaneFlags = value.AsEnumValue($.$CFEL.LCIDTS$1.TrafficControlEnabledLane);
                        }, $HoOjVk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4715859,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Slices"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings.$type, $.$discardRef(), "Slices", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Slices")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$CFEL.LCIDTS$1.TrafficSlice), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Slices";
                        $i13.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettings";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$CFEL.LCIDTS$1.TrafficSlice), ($.$cast(target, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings)).Slices);
                        }, $OBSYad ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4715859,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Slices = value.AsReference($.$typeArray($.$CFEL.LCIDTS$1.TrafficSlice));
                        }, $uBbOTk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4715859,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Relationships"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings.$type, $.$discardRef(), "Relationships", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Relationships")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Relationships";
                        $i15.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettings";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship), ($.$cast(target, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings)).Relationships);
                        }, $JXomdi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4715859,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Relationships = value.AsReference($.$typeArray($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship));
                        }, $CRFFXg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4715859,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("StartEnabled"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings.$type, $.$discardRef(), "StartEnabled", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("StartEnabled")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "StartEnabled";
                        $i17.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettings";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings)).StartEnabled);
                        }, $xgpKsj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4715859,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.StartEnabled = value.AsBool();
                        }, $yPGPMa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4715859,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("EndEnabled"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings.$type, $.$discardRef(), "EndEnabled", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("EndEnabled")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "EndEnabled";
                        $i19.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettings";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings)).EndEnabled);
                        }, $dSQIle ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4715859,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.EndEnabled = value.AsBool();
                        }, $NQAyHg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4715859,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsEnabled"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings.$type, $.$discardRef(), "IsEnabled", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsEnabled")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "IsEnabled";
                        $i21.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettings";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings)).IsEnabled);
                        }, $kjVIJe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4715859,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12889617747)
            
            //--TRIMMABLE-BOUNDARY-START(17184585043)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184585043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Magic = _target.Magic;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Magic"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Magic, ($v) => _Magic = $v, $.$$.S.Int32)))
                    {
                        _target.Magic = _Magic;
                    }
                }
                {
                    /*var*/ let _Start = _target.Start;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Start"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDC.MaskableDateTime));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Start, ($v) => _Start = $v, $.$fPer.LCFCDC.MaskableDateTime)))
                    {
                        _target.Start = _Start;
                    }
                }
                {
                    /*var*/ let _End = _target.End;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("End"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDC.MaskableDateTime));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _End, ($v) => _End = $v, $.$fPer.LCFCDC.MaskableDateTime)))
                    {
                        _target.End = _End;
                    }
                }
                {
                    /*var*/ let _StandbyTime = _target.StandbyTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("StandbyTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _StandbyTime, ($v) => _StandbyTime = $v, $.$$.S.Int32)))
                    {
                        _target.StandbyTime = _StandbyTime;
                    }
                }
                {
                    /*var*/ let _Mode = _target.Mode;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Mode"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$CFEL.LCIDTS$1.TrafficControlMode));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$CFEL.LCIDTS$1.TrafficControlMode, () => _Mode, ($v) => _Mode = $v, null, true)))
                    {
                        _target.Mode = _Mode;
                    }
                }
                {
                    /*var*/ let _EnableLaneFlags = _target.EnableLaneFlags;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("EnableLaneFlags"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$CFEL.LCIDTS$1.TrafficControlEnabledLane));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$CFEL.LCIDTS$1.TrafficControlEnabledLane, () => _EnableLaneFlags, ($v) => _EnableLaneFlags = $v, null, true)))
                    {
                        _target.EnableLaneFlags = _EnableLaneFlags;
                    }
                }
                {
                    /*var*/ let _Slices = _target.Slices;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Slices"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$CFEL.LCIDTS$1.TrafficSlice)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$CFEL.LCIDTS$1.TrafficSlice), $.$CFEL.LCIDTS$1.TrafficSlice));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$CFEL.LCIDTS$1.TrafficSlice), $.$CFEL.LCIDTS$1.TrafficSlice, property, $.$ref(() => _Slices, ($v) => _Slices = $v, $.$typeArray($.$CFEL.LCIDTS$1.TrafficSlice))))
                    {
                        _target.Slices = _Slices;
                        if (_Slices !== null)
                        {
                            let $i34 = 0;
                            let $arr34 = _Slices;
                            while ($i34 < $arr34.length)
                            {
                                let item = $arr34[$i34++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$CFEL.LCIDTS$1.TrafficSlice)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$CFEL.LCIDTS$1.TrafficSlice), $.$CFEL.LCIDTS$1.TrafficSlice, property, $.$ref(() => _Slices, ($v) => _Slices = $v, $.$typeArray($.$CFEL.LCIDTS$1.TrafficSlice)));
                    }
                }
                {
                    /*var*/ let _Relationships = _target.Relationships;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Relationships"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship), $.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship), $.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship, property, $.$ref(() => _Relationships, ($v) => _Relationships = $v, $.$typeArray($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship))))
                    {
                        _target.Relationships = _Relationships;
                        if (_Relationships !== null)
                        {
                            let $i39 = 0;
                            let $arr39 = _Relationships;
                            while ($i39 < $arr39.length)
                            {
                                let item = $arr39[$i39++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship), $.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship, property, $.$ref(() => _Relationships, ($v) => _Relationships = $v, $.$typeArray($.$CFEL.LCIDTS$1.TrafficLaneSliceRelationship)));
                    }
                }
                {
                    /*var*/ let _StartEnabled = _target.StartEnabled;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("StartEnabled"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _StartEnabled, ($v) => _StartEnabled = $v, null, true)))
                    {
                        _target.StartEnabled = _StartEnabled;
                    }
                }
                {
                    /*var*/ let _EndEnabled = _target.EndEnabled;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("EndEnabled"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _EndEnabled, ($v) => _EndEnabled = $v, null, true)))
                    {
                        _target.EndEnabled = _EndEnabled;
                    }
                }
                {
                    /*var*/ let _IsEnabled = _target.IsEnabled;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsEnabled"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsEnabled, ($v) => _IsEnabled = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184585043)
            
            //--TRIMMABLE-BOUNDARY-START(8594650451)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594650451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CFEL.LCIDTS$1.TrafficControlSlotSettings().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings)))
                {
                    /*var*/ let result = $.$CFEL.LCIDTS$1.TrafficControlSlotSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTS$1.TrafficControlSlotSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594650451)
            
            static $h = 4715859;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889617747),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4715859,
      "h": 12889617747,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889617747),
//--TRIMMABLE-BOUNDARY-START(17184585043),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4584787,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4715859,
      "h": 17184585043,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184585043),
//--TRIMMABLE-BOUNDARY-START(8594650451),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4584787,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4715859,
      "h": 8594650451,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594650451)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299683155),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4715859,
      "h": 4299683155,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299683155)
  ],
  "h": 4715859
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlSlotSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlSlotSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4715859)
        
        

        //--TRIMMABLE-BOUNDARY-START(849235)
        $asm.$cls(`$CFEL.LCIDTMC.TrafficControlOverrideControlModelTypeDescriptor`, ($self) => class TrafficControlOverrideControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTMC.TrafficControlOverrideControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295816531)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295816531);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CFEL.LCIDTMC.TrafficControlOverrideControlModelTypeDescriptor.GenerateProperties($.$CFEL.LCIDTMC.TrafficControlOverrideControlModel, this, factory);
                    }, $ltdywb ??= {"r":65537,"n":"","d":849235,"h":0,"f":17825794}), 0, "TrafficControlOverrideControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TrafficControl\\Models_Commands_TrafficControlOverrideControlCommand_LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideControlModelTypeDescriptorBuilder.g.cs", "TrafficControlOverrideControlModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295816531)
            
            //--TRIMMABLE-BOUNDARY-START(12885751123)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885751123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Lane"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel.$type, $.$discardRef(), "Lane", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Lane")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Lane";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMC.TrafficControlOverrideControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel)).Lane);
                        }, $swEnWf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":849235,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMC.TrafficControlOverrideControlModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Lane = value.AsInt();
                        }, $wjceHi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":849235,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("State"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel.$type, $.$discardRef(), "State", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("State")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$CFEL.LCIDTMC.TrafficState, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "State";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideControlModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMC.TrafficControlOverrideControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$CFEL.LCIDTMC.TrafficState, ($.$cast(target, $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel)).State);
                        }, $byBdQd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":849235,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMC.TrafficControlOverrideControlModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.State = value.AsEnumValue($.$CFEL.LCIDTMC.TrafficState);
                        }, $tAwuCi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":849235,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Time"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel.$type, $.$discardRef(), "Time", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Time")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Time";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideControlModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMC.TrafficControlOverrideControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel)).Time);
                        }, $tVUPFg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":849235,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMC.TrafficControlOverrideControlModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Time = value.AsInt();
                        }, $mfzomd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":849235,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Command";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideControlModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMC.TrafficControlOverrideControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel)).Command);
                        }, $eBoTKi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":849235,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885751123)
            
            //--TRIMMABLE-BOUNDARY-START(17180718419)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180718419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Lane = _target.Lane;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Lane"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Lane, ($v) => _Lane = $v, $.$$.S.Int32)))
                    {
                        _target.Lane = _Lane;
                    }
                }
                {
                    /*var*/ let _State = _target.State;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("State"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$CFEL.LCIDTMC.TrafficState));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$CFEL.LCIDTMC.TrafficState, () => _State, ($v) => _State = $v, null, true)))
                    {
                        _target.State = _State;
                    }
                }
                {
                    /*var*/ let _Time = _target.Time;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Time"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Time, ($v) => _Time = $v, $.$$.S.Int32)))
                    {
                        _target.Time = _Time;
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180718419)
            
            //--TRIMMABLE-BOUNDARY-START(8590783827)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590783827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel)))
                {
                    /*var*/ let result = $.$CFEL.LCIDTMC.TrafficControlOverrideControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590783827)
            
            static $h = 849235;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTMC.TrafficControlOverrideControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885751123),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 849235,
      "h": 12885751123,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885751123),
//--TRIMMABLE-BOUNDARY-START(17180718419),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 718163,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 849235,
      "h": 17180718419,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180718419),
//--TRIMMABLE-BOUNDARY-START(8590783827),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 718163,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 849235,
      "h": 8590783827,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590783827)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295816531),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 849235,
      "h": 4295816531,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295816531)
  ],
  "h": 849235
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CFEL.LCIDTMC.TrafficControlOverrideControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Commands${separator}TrafficControlOverrideControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(849235)
        
        

        //--TRIMMABLE-BOUNDARY-START(1570131)
        $asm.$cls(`$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptor`, ($self) => class TrafficControlStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTMS.TrafficControlStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296537427)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296537427);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptor.GenerateProperties($.$CFEL.LCIDTMS.TrafficControlStatusModel, this, factory);
                    }, $nMPYZe ??= {"r":65537,"n":"","d":1570131,"h":0,"f":17825794}), 0, "TrafficControlStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TrafficControl\\Models_Statuses_TrafficControlStatusModel_LivingThing.Core.IOT.Devices.TrafficControl.Models.Statuses.TrafficControlStatusModelTypeDescriptorBuilder.g.cs", "TrafficControlStatusModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296537427)
            
            //--TRIMMABLE-BOUNDARY-START(12886472019)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886472019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("EnableLaneFlags"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTMS.TrafficControlStatusModel.$type, $.$discardRef(), "EnableLaneFlags", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("EnableLaneFlags")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "EnableLaneFlags";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Models.Statuses.TrafficControlStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$CFEL.LCIDTMS.TrafficControlStatusModel)).EnableLaneFlags);
                        }, $rBAbOb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1570131,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.EnableLaneFlags = value.AsInt();
                        }, $fFsNCk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1570131,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("RunningSlot"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTMS.TrafficControlStatusModel.$type, $.$discardRef(), "RunningSlot", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("RunningSlot")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "RunningSlot";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Models.Statuses.TrafficControlStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$CFEL.LCIDTMS.TrafficControlStatusModel)).RunningSlot);
                        }, $NOTifi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1570131,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.RunningSlot = value.AsInt();
                        }, $wHLVtf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1570131,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CurrentSlice"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTMS.TrafficControlStatusModel.$type, $.$discardRef(), "CurrentSlice", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CurrentSlice")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "CurrentSlice";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Models.Statuses.TrafficControlStatusModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$CFEL.LCIDTMS.TrafficControlStatusModel)).CurrentSlice);
                        }, $WMdpif ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1570131,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CurrentSlice = value.AsInt();
                        }, $qjVsXe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1570131,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CurrentSliceElapsed"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTMS.TrafficControlStatusModel.$type, $.$discardRef(), "CurrentSliceElapsed", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CurrentSliceElapsed")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "CurrentSliceElapsed";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Models.Statuses.TrafficControlStatusModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$CFEL.LCIDTMS.TrafficControlStatusModel)).CurrentSliceElapsed);
                        }, $LAEFhe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1570131,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.CurrentSliceElapsed = value.AsInt();
                        }, $AYgGkg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1570131,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Statuses"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTMS.TrafficControlStatusModel.$type, $.$discardRef(), "Statuses", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Statuses")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.Byte), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Statuses";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Models.Statuses.TrafficControlStatusModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.Byte), ($.$cast(target, $.$CFEL.LCIDTMS.TrafficControlStatusModel)).Statuses);
                        }, $BLXeEa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1570131,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Statuses = value.AsReference($.$typeArray($.$$.S.Byte));
                        }, $bLPLwf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1570131,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886472019)
            
            //--TRIMMABLE-BOUNDARY-START(17181439315)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.Statuses.TrafficControlStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181439315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _EnableLaneFlags = _target.EnableLaneFlags;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("EnableLaneFlags"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _EnableLaneFlags, ($v) => _EnableLaneFlags = $v, $.$$.S.Int32)))
                    {
                        _target.EnableLaneFlags = _EnableLaneFlags;
                    }
                }
                {
                    /*var*/ let _RunningSlot = _target.RunningSlot;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("RunningSlot"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _RunningSlot, ($v) => _RunningSlot = $v, $.$$.S.Int32)))
                    {
                        _target.RunningSlot = _RunningSlot;
                    }
                }
                {
                    /*var*/ let _CurrentSlice = _target.CurrentSlice;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CurrentSlice"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _CurrentSlice, ($v) => _CurrentSlice = $v, $.$$.S.Int32)))
                    {
                        _target.CurrentSlice = _CurrentSlice;
                    }
                }
                {
                    /*var*/ let _CurrentSliceElapsed = _target.CurrentSliceElapsed;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CurrentSliceElapsed"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _CurrentSliceElapsed, ($v) => _CurrentSliceElapsed = $v, $.$$.S.Int32)))
                    {
                        _target.CurrentSliceElapsed = _CurrentSliceElapsed;
                    }
                }
                {
                    /*var*/ let _Statuses = _target.Statuses;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Statuses"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.Byte)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.Byte), $.$$.S.Byte));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.Byte), $.$$.S.Byte, property, $.$ref(() => _Statuses, ($v) => _Statuses = $v, $.$typeArray($.$$.S.Byte))))
                    {
                        _target.Statuses = _Statuses;
                        if (_Statuses !== null)
                        {
                            let $i18 = 0;
                            let $arr18 = _Statuses;
                            while ($i18 < $arr18.length)
                            {
                                let item = $arr18[$i18++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.Byte)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.Byte), $.$$.S.Byte, property, $.$ref(() => _Statuses, ($v) => _Statuses = $v, $.$typeArray($.$$.S.Byte)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181439315)
            
            //--TRIMMABLE-BOUNDARY-START(8591504723)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.Statuses.TrafficControlStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591504723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CFEL.LCIDTMS.TrafficControlStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CFEL.LCIDTMS.TrafficControlStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTMS.TrafficControlStatusModel)))
                {
                    /*var*/ let result = $.$CFEL.LCIDTMS.TrafficControlStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTMS.TrafficControlStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CFEL.LCIDTMS.TrafficControlStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTMS.TrafficControlStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591504723)
            
            static $h = 1570131;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTMS.TrafficControlStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886472019),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1570131,
      "h": 12886472019,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886472019),
//--TRIMMABLE-BOUNDARY-START(17181439315),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1439059,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1570131,
      "h": 17181439315,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181439315),
//--TRIMMABLE-BOUNDARY-START(8591504723),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1439059,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1570131,
      "h": 8591504723,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591504723)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296537427),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1570131,
      "h": 4296537427,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296537427)
  ],
  "h": 1570131
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CFEL.LCIDTMS.TrafficControlStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Statuses.TrafficControlStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Statuses${separator}TrafficControlStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1570131)
        
        

        //--TRIMMABLE-BOUNDARY-START(1176915)
        $asm.$cls(`$CFEL.LCIDTMC.TrafficControlOverrideModeModelTypeDescriptor`, ($self) => class TrafficControlOverrideModeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTMC.TrafficControlOverrideModeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296144211)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296144211);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CFEL.LCIDTMC.TrafficControlOverrideModeModelTypeDescriptor.GenerateProperties($.$CFEL.LCIDTMC.TrafficControlOverrideModeModel, this, factory);
                    }, $JTmyYj ??= {"r":65537,"n":"","d":1176915,"h":0,"f":17825794}), 0, "TrafficControlOverrideModeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TrafficControl\\Models_Commands_TrafficControlOverrideModeCommand_LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideModeModelTypeDescriptorBuilder.g.cs", "TrafficControlOverrideModeModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296144211)
            
            //--TRIMMABLE-BOUNDARY-START(12886078803)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886078803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Mode"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTMC.TrafficControlOverrideModeModel.$type, $.$discardRef(), "Mode", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Mode")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$CFEL.LCIDTS$1.TrafficControlMode, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Mode";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideModeModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMC.TrafficControlOverrideModeModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$CFEL.LCIDTS$1.TrafficControlMode, ($.$cast(target, $.$CFEL.LCIDTMC.TrafficControlOverrideModeModel)).Mode);
                        }, $MLHsVd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1176915,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMC.TrafficControlOverrideModeModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Mode = value.AsEnumValue($.$CFEL.LCIDTS$1.TrafficControlMode);
                        }, $zKqfAf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1176915,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTMC.TrafficControlOverrideModeModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Command";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideModeModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTMC.TrafficControlOverrideModeModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$CFEL.LCIDTMC.TrafficControlOverrideModeModel)).Command);
                        }, $gJMqbf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1176915,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886078803)
            
            //--TRIMMABLE-BOUNDARY-START(17181046099)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideModeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181046099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Mode = _target.Mode;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Mode"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$CFEL.LCIDTS$1.TrafficControlMode));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$CFEL.LCIDTS$1.TrafficControlMode, () => _Mode, ($v) => _Mode = $v, null, true)))
                    {
                        _target.Mode = _Mode;
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181046099)
            
            //--TRIMMABLE-BOUNDARY-START(8591111507)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideModeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591111507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CFEL.LCIDTMC.TrafficControlOverrideModeModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CFEL.LCIDTMC.TrafficControlOverrideModeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTMC.TrafficControlOverrideModeModel)))
                {
                    /*var*/ let result = $.$CFEL.LCIDTMC.TrafficControlOverrideModeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTMC.TrafficControlOverrideModeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CFEL.LCIDTMC.TrafficControlOverrideModeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTMC.TrafficControlOverrideModeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591111507)
            
            static $h = 1176915;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTMC.TrafficControlOverrideModeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886078803),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1176915,
      "h": 12886078803,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886078803),
//--TRIMMABLE-BOUNDARY-START(17181046099),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1045843,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1176915,
      "h": 17181046099,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181046099),
//--TRIMMABLE-BOUNDARY-START(8591111507),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1045843,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1176915,
      "h": 8591111507,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591111507)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296144211),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1176915,
      "h": 4296144211,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296144211)
  ],
  "h": 1176915
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CFEL.LCIDTMC.TrafficControlOverrideModeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideModeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Commands${separator}TrafficControlOverrideModeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1176915)
        
        

        //--TRIMMABLE-BOUNDARY-START(2880851)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlLogModelTypeDescriptor`, ($self) => class TrafficControlLogModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297848147)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297848147);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CFEL.LCIDTM.TrafficControlLogModelTypeDescriptor.GenerateProperties($.$CFEL.LCIDTM.TrafficControlLogModel, this, factory);
                    }, $GKZkei ??= {"r":65537,"n":"","d":2880851,"h":0,"f":17825794}), 0, "TrafficControlLogModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TrafficControl\\Models_TrafficControlLogModel_LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlLogModelTypeDescriptorBuilder.g.cs", "TrafficControlLogModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297848147)
            
            //--TRIMMABLE-BOUNDARY-START(12887782739)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887782739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceLogModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887782739)
            
            //--TRIMMABLE-BOUNDARY-START(17182750035)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlLogModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182750035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceLogModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceLogModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceLogModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182750035)
            
            //--TRIMMABLE-BOUNDARY-START(8592815443)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlLogModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592815443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CFEL.LCIDTM.TrafficControlLogModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CFEL.LCIDTM.TrafficControlLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlLogModel)))
                {
                    /*var*/ let result = $.$CFEL.LCIDTM.TrafficControlLogModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlLogModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CFEL.LCIDTM.TrafficControlLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlLogModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592815443)
            
            static $h = 2880851;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887782739),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2880851,
      "h": 12887782739,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887782739),
//--TRIMMABLE-BOUNDARY-START(17182750035),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2749779,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2880851,
      "h": 17182750035,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182750035),
//--TRIMMABLE-BOUNDARY-START(8592815443),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2749779,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2880851,
      "h": 8592815443,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592815443)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297848147),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2880851,
      "h": 4297848147,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297848147)
  ],
  "h": 2880851
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlLogModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlLogModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlLogModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2880851)
        
        

        //--TRIMMABLE-BOUNDARY-START(980307)
        $asm.$cls(`$CFEL.LCIDTMC.TrafficControlOverrideModeCommand`, ($self) => class TrafficControlOverrideModeCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$CFEL.LCIDTMC.TrafficControlOverrideModeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295947603)
            $ctor$6()
            {
                super.$ctor$5("Override Mode", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295947603);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295947603)
            
            //--TRIMMABLE-BOUNDARY-START(17180849491)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-electric-switch"/*MaterialDesignIconNames.ElectricSwitch*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17180849491)
            
            //--TRIMMABLE-BOUNDARY-START(4295947603)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295947603)
            
            static $h = 980307;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$CFEL.LCIDTMC.TrafficControlOverrideModeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180849491),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885882195,
        "f": 50364417
      },
      "n": "Icon",
      "d": 980307,
      "h": 17180849491,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180849491)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295947603),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 980307,
      "h": 4295947603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295947603)
  ],
  "h": 980307
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideModeCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Commands${separator}TrafficControlOverrideModeCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(980307)
        
        

        //--TRIMMABLE-BOUNDARY-START(652627)
        $asm.$cls(`$CFEL.LCIDTMC.TrafficControlOverrideControlCommand`, ($self) => class TrafficControlOverrideControlCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$CFEL.LCIDTMC.TrafficControlOverrideControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295619923)
            $ctor$6()
            {
                super.$ctor$5("Override", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295619923);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295619923)
            
            //--TRIMMABLE-BOUNDARY-START(17180521811)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-electric-switch"/*MaterialDesignIconNames.ElectricSwitch*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17180521811)
            
            //--TRIMMABLE-BOUNDARY-START(4295619923)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295619923)
            
            static $h = 652627;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$CFEL.LCIDTMC.TrafficControlOverrideControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180521811),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885554515,
        "f": 50364417
      },
      "n": "Icon",
      "d": 652627,
      "h": 17180521811,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180521811)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295619923),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 652627,
      "h": 4295619923,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295619923)
  ],
  "h": 652627
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlOverrideControlCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Commands${separator}TrafficControlOverrideControlCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(652627)
        
        

        //--TRIMMABLE-BOUNDARY-START(2487635)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlDeviceSendDataModel`, ($self) => class TrafficControlDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceCommandsModel
        {
            //--TRIMMABLE-BOUNDARY-START(8592422227)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592422227);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592422227)
            
            //--TRIMMABLE-BOUNDARY-START(12887389523)
            $ctor$5(/*TrafficControlOverrideControlModel*/ _override)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887389523);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Override = _override;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887389523)
            
            //--TRIMMABLE-BOUNDARY-START(25772291411)
            /*TrafficControlOverrideControlModel?*/ Override = null;
            //--TRIMMABLE-BOUNDARY-END(25772291411)
            
            //--TRIMMABLE-BOUNDARY-START(8592422227)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8592422227)
            
            static $h = 2487635;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandsModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772291411),
    {
      "p": 718163,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477324115,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34362226003,
        "f": 83886081
      },
      "n": "Override",
      "d": 2487635,
      "h": 25772291411,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 13432,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25772291411)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592422227),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2487635,
      "h": 8592422227,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592422227),
//--TRIMMABLE-BOUNDARY-START(12887389523),
    {
      "p": [
        {
          "n": "_override",
          "p": 718163
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2487635,
      "h": 12887389523,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887389523)
  ],
  "h": 2487635
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2487635)
        
        

        //--TRIMMABLE-BOUNDARY-START(2618707)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlDeviceSendDataModelTypeDescriptor`, ($self) => class TrafficControlDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297586003)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297586003);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModelTypeDescriptor.GenerateProperties($.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, this, factory);
                    }, $WYExWj ??= {"r":65537,"n":"","d":2618707,"h":0,"f":17825794}), 0, "TrafficControlDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TrafficControl\\Models_TrafficControlDeviceSendDataModel_LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceSendDataModelTypeDescriptorBuilder.g.cs", "TrafficControlDeviceSendDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297586003)
            
            //--TRIMMABLE-BOUNDARY-START(12887520595)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887520595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Override"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel.$type, $.$discardRef(), "Override", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Override")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$CFEL.LCIDTMC.TrafficControlOverrideControlModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Override";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceSendDataModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTM.TrafficControlDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$CFEL.LCIDTMC.TrafficControlOverrideControlModel, ($.$cast(target, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel)).Override);
                        }, $LJHdEc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2618707,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTM.TrafficControlDeviceSendDataModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Override = value.AsReference($.$CFEL.LCIDTMC.TrafficControlOverrideControlModel);
                        }, $MMCOMc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2618707,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887520595)
            
            //--TRIMMABLE-BOUNDARY-START(17182487891)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182487891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandsModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandsModel));
                {
                    /*var*/ let _Override = _target.Override;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Override"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$CFEL.LCIDTMC.TrafficControlOverrideControlModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Override, ($v) => _Override = $v, $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel)))
                    {
                        _target.Override = _Override;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182487891)
            
            //--TRIMMABLE-BOUNDARY-START(8592553299)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592553299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592553299)
            
            static $h = 2618707;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887520595),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2618707,
      "h": 12887520595,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887520595),
//--TRIMMABLE-BOUNDARY-START(17182487891),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2487635,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2618707,
      "h": 17182487891,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182487891),
//--TRIMMABLE-BOUNDARY-START(8592553299),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2487635,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2618707,
      "h": 8592553299,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592553299)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297586003),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2618707,
      "h": 4297586003,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297586003)
  ],
  "h": 2618707
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2618707)
        
        

        //--TRIMMABLE-BOUNDARY-START(1963347)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel`, ($self) => class TrafficControlDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$CFEL.LCIDTMS.TrafficControlStatusModel, $.$CFEL.LCIDTM.TrafficControlLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296930643)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296930643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296930643)
            
            //--TRIMMABLE-BOUNDARY-START(4296930643)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296930643)
            
            static $h = 1963347;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$CFEL.LCIDTMS.TrafficControlStatusModel, $.$CFEL.LCIDTM.TrafficControlLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296930643),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1963347,
      "h": 4296930643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296930643)
  ],
  "h": 1963347
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1963347)
        
        

        //--TRIMMABLE-BOUNDARY-START(2094419)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModelTypeDescriptor`, ($self) => class TrafficControlDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297061715)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297061715);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, this, factory);
                    }, $dlCYAi ??= {"r":65537,"n":"","d":2094419,"h":0,"f":17825794}), 0, "TrafficControlDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TrafficControl\\Models_TrafficControlDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "TrafficControlDeviceReceivedDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297061715)
            
            //--TRIMMABLE-BOUNDARY-START(12886996307)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886996307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$CFEL.LCIDTMS.TrafficControlStatusModel, $.$CFEL.LCIDTM.TrafficControlLogModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886996307)
            
            //--TRIMMABLE-BOUNDARY-START(17181963603)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181963603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.TrafficControl.Models.Statuses.TrafficControlStatusModel, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlLogModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$CFEL.LCIDTMS.TrafficControlStatusModel, $.$CFEL.LCIDTM.TrafficControlLogModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$CFEL.LCIDTMS.TrafficControlStatusModel, $.$CFEL.LCIDTM.TrafficControlLogModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181963603)
            
            //--TRIMMABLE-BOUNDARY-START(8592029011)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592029011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592029011)
            
            static $h = 2094419;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886996307),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2094419,
      "h": 12886996307,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886996307),
//--TRIMMABLE-BOUNDARY-START(17181963603),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1963347,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2094419,
      "h": 17181963603,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181963603),
//--TRIMMABLE-BOUNDARY-START(8592029011),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1963347,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2094419,
      "h": 8592029011,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592029011)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297061715),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2094419,
      "h": 4297061715,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297061715)
  ],
  "h": 2094419
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2094419)
        
        

        //--TRIMMABLE-BOUNDARY-START(4978003)
        $asm.$cls(`$CFEL.LCIDT.TrafficControlDataConverter`, ($self) => class TrafficControlDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299945299)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299945299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299945299)
            
            //--TRIMMABLE-BOUNDARY-START(4299945299)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299945299)
            
            static $h = 4978003;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299945299),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4978003,
      "h": 4299945299,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299945299)
  ],
  "h": 4978003
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.TrafficControlDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}TrafficControlDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4978003)
        
        

        $asm.$typeProxy("$CFEL.LCIDTM.TrafficControlServiceModel", "$CFEL.LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlServiceModel");
        $asm.$typeProxy("$CFEL.LCIDTM.TrafficControlDeviceScopeModel", "$CFEL.LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceScopeModel");
        $asm.$typeProxy("$CFEL.LCIDTS$1.TrafficControlDeviceSettings", "$CFEL.LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceSettings");
        $asm.$typeProxy("$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings", "$CFEL.LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceHardwareSettings");
        $asm.$typeProxy("$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler", "$CFEL.LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlDeviceStatusHandler");
        $asm.$typeProxy("$CFEL.LCIDTS.ITrafficControlDeviceHubClient", "$CFEL.LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlDeviceHubClient");
        $asm.$typeProxy("$CFEL.LCIDTS.ITrafficControlRemoteService", "$CFEL.LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlRemoteService");
        //--TRIMMABLE-BOUNDARY-START(1701203)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlDeviceModel`, ($self) => class TrafficControlDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296668499)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296668499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296668499)
            
            //--TRIMMABLE-BOUNDARY-START(4296668499)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296668499)
            
            static $h = 1701203;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296668499),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1701203,
      "h": 4296668499,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296668499)
  ],
  "h": 1701203
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1701203)
        
        

        //--TRIMMABLE-BOUNDARY-START(2225491)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlDeviceScopeModel`, ($self) => class TrafficControlDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297192787)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297192787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297192787)
            
            //--TRIMMABLE-BOUNDARY-START(4297192787)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4297192787)
            
            static $h = 2225491;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297192787),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 2225491,
      "h": 4297192787,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297192787)
  ],
  "h": 2225491
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2225491)
        
        

        //--TRIMMABLE-BOUNDARY-START(3601747)
        $asm.$cls(`$CFEL.LCIDTS.ITrafficControlRemoteService`, ($self) => class ITrafficControlRemoteService
        {
            static $h = 3601747;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3601747
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$CFEL.LCIDTM.TrafficControlServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$CFEL.LCIDTM.TrafficControlServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$CFEL.LCIDTM.TrafficControlServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$CFEL.LCIDTM.TrafficControlServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$CFEL.LCIDTM.TrafficControlServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$CFEL.LCIDTM.TrafficControlServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$CFEL.LCIDTM.TrafficControlServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$CFEL.LCIDTM.TrafficControlServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Services${separator}ITrafficControlRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3601747)
        
        

        //--TRIMMABLE-BOUNDARY-START(3470675)
        $asm.$cls(`$CFEL.LCIDTS.ITrafficControlDeviceHubClient`, ($self) => class ITrafficControlDeviceHubClient
        {
            static $h = 3470675;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3470675
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Services${separator}ITrafficControlDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3470675)
        
        

        //--TRIMMABLE-BOUNDARY-START(3536211)
        $asm.$cls(`$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler`, ($self) => class ITrafficControlDeviceStatusHandler
        {
            static $h = 3536211;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3536211
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Services${separator}ITrafficControlDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3536211)
        
        

        //--TRIMMABLE-BOUNDARY-START(4060499)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficControlDeviceSettings`, ($self) => class TrafficControlDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $self, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(34363798867)
            /*bool*/ Invert = false;
            //--TRIMMABLE-BOUNDARY-END(34363798867)
            
            //--TRIMMABLE-BOUNDARY-START(38658766163)
            /*TrafficControlClickCommand*/ OnClick = 0;
            //--TRIMMABLE-BOUNDARY-END(38658766163)
            
            //--TRIMMABLE-BOUNDARY-START(12888962387)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888962387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888962387)
            
            //--TRIMMABLE-BOUNDARY-START(12888962387)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12888962387)
            
            static $h = 4060499;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34363798867),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478896979,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47248700755,
        "f": 83886081
      },
      "n": "Invert",
      "d": 4060499,
      "h": 34363798867,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 256,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34363798867),
//--TRIMMABLE-BOUNDARY-START(38658766163),
    {
      "p": 3667283,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068831571,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55838635347,
        "f": 83886081
      },
      "n": "OnClick",
      "d": 4060499,
      "h": 38658766163,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 257,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38658766163)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888962387),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4060499,
      "h": 12888962387,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888962387)
  ],
  "h": 4060499
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4060499)
        
        

        //--TRIMMABLE-BOUNDARY-START(3011923)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlServiceModel`, ($self) => class TrafficControlServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297979219)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297979219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297979219)
            
            //--TRIMMABLE-BOUNDARY-START(4297979219)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4297979219)
            
            static $h = 3011923;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297979219),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 3011923,
      "h": 4297979219,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297979219)
  ],
  "h": 3011923
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3011923)
        
        

        //--TRIMMABLE-BOUNDARY-START(3798355)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings`, ($self) => class TrafficControlDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(30068569427)
            /*IOTDeviceInternalConfigurations<TrafficControlSlotSettings>*/ Slots = null;
            //--TRIMMABLE-BOUNDARY-END(30068569427)
            
            //--TRIMMABLE-BOUNDARY-START(8593732947)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593732947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593732947)
            
            //--TRIMMABLE-BOUNDARY-START(8593732947)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8593732947)
            
            static $h = 3798355;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30068569427),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183667539,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25773602131,
        "f": 83886081
      },
      "n": "Slots",
      "d": 3798355,
      "h": 30068569427,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "tfs",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 20,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30068569427)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593732947),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3798355,
      "h": 8593732947,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593732947)
  ],
  "h": 3798355
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3798355)
        
        

        //--TRIMMABLE-BOUNDARY-START(5240147)
        $asm.$cls(`$CFEL.LCIDT.TrafficControlDeviceModelDefinition`, ($self) => class TrafficControlDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4300207443)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300207443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300207443)
            
            //--TRIMMABLE-BOUNDARY-START(4300207443)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4300207443)
            
            static $h = 5240147;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300207443),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5240147,
      "h": 4300207443,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300207443)
  ],
  "h": 5240147
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.TrafficControlDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}TrafficControlDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5240147)
        
        

        //--TRIMMABLE-BOUNDARY-START(4191571)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficControlDeviceSettingsTypeDescriptor`, ($self) => class TrafficControlDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTS$1.TrafficControlDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299158867)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299158867);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CFEL.LCIDTS$1.TrafficControlDeviceSettingsTypeDescriptor.GenerateProperties($.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, this, factory);
                    }, $uGvMzf ??= {"r":65537,"n":"","d":4191571,"h":0,"f":17825794}), 0, "TrafficControlDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TrafficControl\\Settings_TrafficControlDeviceSettings_LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceSettingsTypeDescriptorBuilder.g.cs", "TrafficControlDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299158867)
            
            //--TRIMMABLE-BOUNDARY-START(12889093459)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889093459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Invert"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings.$type, $.$discardRef(), "Invert", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Invert")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Invert";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings)).Invert);
                        }, $JbswSd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4191571,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Invert = value.AsBool();
                        }, $brzVsb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4191571,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("OnClick"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings.$type, $.$discardRef(), "OnClick", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("OnClick")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$CFEL.LCIDTS$1.TrafficControlClickCommand, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "OnClick";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$CFEL.LCIDTS$1.TrafficControlClickCommand, ($.$cast(target, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings)).OnClick);
                        }, $SgVJUc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4191571,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlDeviceSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.OnClick = value.AsEnumValue($.$CFEL.LCIDTS$1.TrafficControlClickCommand);
                        }, $ZREMFa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4191571,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889093459)
            
            //--TRIMMABLE-BOUNDARY-START(17184060755)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184060755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceModel, LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceSettings, LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceSendDataModel, LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlDeviceStatusHandler, LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlDeviceHubClient, LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).iSmartDeviceSettings));
                {
                    /*var*/ let _Invert = _target.Invert;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Invert"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _Invert, ($v) => _Invert = $v, null, true)))
                    {
                        _target.Invert = _Invert;
                    }
                }
                {
                    /*var*/ let _OnClick = _target.OnClick;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("OnClick"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$CFEL.LCIDTS$1.TrafficControlClickCommand));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$CFEL.LCIDTS$1.TrafficControlClickCommand, () => _OnClick, ($v) => _OnClick = $v, null, true)))
                    {
                        _target.OnClick = _OnClick;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184060755)
            
            //--TRIMMABLE-BOUNDARY-START(8594126163)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594126163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings)))
                {
                    /*var*/ let result = $.$CFEL.LCIDTS$1.TrafficControlDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594126163)
            
            static $h = 4191571;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTS$1.TrafficControlDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889093459),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4191571,
      "h": 12889093459,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889093459),
//--TRIMMABLE-BOUNDARY-START(17184060755),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4060499,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4191571,
      "h": 17184060755,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184060755),
//--TRIMMABLE-BOUNDARY-START(8594126163),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4060499,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4191571,
      "h": 8594126163,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594126163)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299158867),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4191571,
      "h": 4299158867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299158867)
  ],
  "h": 4191571
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CFEL.LCIDTS$1.TrafficControlDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4191571)
        
        

        //--TRIMMABLE-BOUNDARY-START(3929427)
        $asm.$cls(`$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettingsTypeDescriptor`, ($self) => class TrafficControlDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298896723)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298896723);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, this, factory);
                    }, $DkMBvf ??= {"r":65537,"n":"","d":3929427,"h":0,"f":17825794}), 0, "TrafficControlDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TrafficControl\\Settings_TrafficControlDeviceHardwareSettings_LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "TrafficControlDeviceHardwareSettingsTypeDescriptor", 41);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298896723)
            
            //--TRIMMABLE-BOUNDARY-START(12888831315)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888831315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Slots"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings.$type, $.$discardRef(), "Slots", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Slots")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Slots";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceHardwareSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings), ($.$cast(target, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings)).Slots);
                        }, $bkqQqd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3929427,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Slots = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings));
                        }, $pMBBJf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3929427,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888831315)
            
            //--TRIMMABLE-BOUNDARY-START(17183798611)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183798611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceModel, LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceSettings, LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceSendDataModel, LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlDeviceStatusHandler, LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlDeviceHubClient, LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).iSmartDeviceHardwareSettings));
                {
                    /*var*/ let _Slots = _target.Slots;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Slots"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Slots, ($v) => _Slots = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfigurations$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings))))
                    {
                        _target.Slots = _Slots;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183798611)
            
            //--TRIMMABLE-BOUNDARY-START(8593864019)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593864019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593864019)
            
            static $h = 3929427;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888831315),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3929427,
      "h": 12888831315,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888831315),
//--TRIMMABLE-BOUNDARY-START(17183798611),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3798355,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3929427,
      "h": 17183798611,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183798611),
//--TRIMMABLE-BOUNDARY-START(8593864019),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3798355,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3929427,
      "h": 8593864019,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593864019)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298896723),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3929427,
      "h": 4298896723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298896723)
  ],
  "h": 3929427
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Settings${separator}TrafficControlDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3929427)
        
        

        //--TRIMMABLE-BOUNDARY-START(1832275)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlDeviceModelTypeDescriptor`, ($self) => class TrafficControlDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296799571)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296799571);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CFEL.LCIDTM.TrafficControlDeviceModelTypeDescriptor.GenerateProperties($.$CFEL.LCIDTM.TrafficControlDeviceModel, this, factory);
                    }, $WcMYWb ??= {"r":65537,"n":"","d":1832275,"h":0,"f":17825794}), 0, "TrafficControlDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TrafficControl\\Models_TrafficControlDeviceModel_LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceModelTypeDescriptorBuilder.g.cs", "TrafficControlDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296799571)
            
            //--TRIMMABLE-BOUNDARY-START(12886734163)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886734163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886734163)
            
            //--TRIMMABLE-BOUNDARY-START(17181701459)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181701459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceModel, LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceSettings, LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceSendDataModel, LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlDeviceStatusHandler, LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlDeviceHubClient, LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181701459)
            
            //--TRIMMABLE-BOUNDARY-START(8591766867)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591766867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CFEL.LCIDTM.TrafficControlDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CFEL.LCIDTM.TrafficControlDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlDeviceModel)))
                {
                    /*var*/ let result = $.$CFEL.LCIDTM.TrafficControlDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CFEL.LCIDTM.TrafficControlDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591766867)
            
            static $h = 1832275;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886734163),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1832275,
      "h": 12886734163,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886734163),
//--TRIMMABLE-BOUNDARY-START(17181701459),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1701203,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1832275,
      "h": 17181701459,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181701459),
//--TRIMMABLE-BOUNDARY-START(8591766867),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1701203,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1832275,
      "h": 8591766867,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591766867)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296799571),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1832275,
      "h": 4296799571,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296799571)
  ],
  "h": 1832275
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1832275)
        
        

        //--TRIMMABLE-BOUNDARY-START(2356563)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlDeviceScopeModelTypeDescriptor`, ($self) => class TrafficControlDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297323859)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297323859);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CFEL.LCIDTM.TrafficControlDeviceScopeModelTypeDescriptor.GenerateProperties($.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, this, factory);
                    }, $pKDxvd ??= {"r":65537,"n":"","d":2356563,"h":0,"f":17825794}), 0, "TrafficControlDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TrafficControl\\Models_TrafficControlDeviceScopeModel_LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceScopeModelTypeDescriptorBuilder.g.cs", "TrafficControlDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297323859)
            
            //--TRIMMABLE-BOUNDARY-START(12887258451)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887258451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887258451)
            
            //--TRIMMABLE-BOUNDARY-START(17182225747)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182225747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceModel, LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceSettings, LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceSendDataModel, LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlDeviceStatusHandler, LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlDeviceHubClient, LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182225747)
            
            //--TRIMMABLE-BOUNDARY-START(8592291155)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592291155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel)))
                {
                    /*var*/ let result = $.$CFEL.LCIDTM.TrafficControlDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592291155)
            
            static $h = 2356563;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887258451),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2356563,
      "h": 12887258451,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887258451),
//--TRIMMABLE-BOUNDARY-START(17182225747),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2225491,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2356563,
      "h": 17182225747,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182225747),
//--TRIMMABLE-BOUNDARY-START(8592291155),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2225491,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2356563,
      "h": 8592291155,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592291155)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297323859),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2356563,
      "h": 4297323859,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297323859)
  ],
  "h": 2356563
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2356563)
        
        

        //--TRIMMABLE-BOUNDARY-START(3142995)
        $asm.$cls(`$CFEL.LCIDTM.TrafficControlServiceModelTypeDescriptor`, ($self) => class TrafficControlServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298110291)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298110291);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$CFEL.LCIDTM.TrafficControlServiceModelTypeDescriptor.GenerateProperties($.$CFEL.LCIDTM.TrafficControlServiceModel, this, factory);
                    }, $qnUlge ??= {"r":65537,"n":"","d":3142995,"h":0,"f":17825794}), 0, "TrafficControlServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TrafficControl\\Models_TrafficControlServiceModel_LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlServiceModelTypeDescriptorBuilder.g.cs", "TrafficControlServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298110291)
            
            //--TRIMMABLE-BOUNDARY-START(12888044883)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888044883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888044883)
            
            //--TRIMMABLE-BOUNDARY-START(17183012179)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183012179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceModel, LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceSettings, LivingThing.Core.IOT.Devices.TrafficControl.Settings.TrafficControlDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceSendDataModel, LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlDeviceStatusHandler, LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlDeviceHubClient, LivingThing.Core.IOT.Devices.TrafficControl.Services.ITrafficControlRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183012179)
            
            //--TRIMMABLE-BOUNDARY-START(8593077587)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593077587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$CFEL.LCIDTM.TrafficControlServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$CFEL.LCIDTM.TrafficControlServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlServiceModel)))
                {
                    /*var*/ let result = $.$CFEL.LCIDTM.TrafficControlServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$CFEL.LCIDTM.TrafficControlServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$CFEL.LCIDTM.TrafficControlServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593077587)
            
            static $h = 3142995;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888044883),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3142995,
      "h": 12888044883,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888044883),
//--TRIMMABLE-BOUNDARY-START(17183012179),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3011923,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3142995,
      "h": 17183012179,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183012179),
//--TRIMMABLE-BOUNDARY-START(8593077587),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3011923,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3142995,
      "h": 8593077587,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593077587)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298110291),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3142995,
      "h": 4298110291,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298110291)
  ],
  "h": 3142995
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$CFEL.LCIDTM.TrafficControlServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}TrafficControlServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3142995)
        
        

        //--TRIMMABLE-BOUNDARY-START(5043539)
        $asm.$cls(`$CFEL.LCIDT.TrafficControlDevice`, ($self) => class TrafficControlDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$CFEL.LCIDTMS.TrafficControlStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4300010835)
            $ctor$2(/*IIOTDeviceFamily<TrafficControlDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*TrafficControlDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300010835);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300010835)
            
            static $h = 5043539;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$CFEL.LCIDTMS.TrafficControlStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300010835),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$CFEL.LCIDT.TrafficControlDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 1701203
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5043539,
      "h": 4300010835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300010835)
  ],
  "h": 5043539
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.TrafficControlDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}TrafficControlDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5043539)
        
        

        //--TRIMMABLE-BOUNDARY-START(5109075)
        $asm.$cls(`$CFEL.LCIDT.TrafficControlDeviceDefinition`, ($self) => class TrafficControlDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$CFEL.LCIDTMS.TrafficControlStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4300076371)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300076371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300076371)
            
            //--TRIMMABLE-BOUNDARY-START(4300076371)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4300076371)
            
            static $h = 5109075;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$CFEL.LCIDTMS.TrafficControlStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300076371),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5109075,
      "h": 4300076371,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300076371)
  ],
  "h": 5109075
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.TrafficControlDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}TrafficControlDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5109075)
        
        

        //--TRIMMABLE-BOUNDARY-START(5174611)
        $asm.$cls(`$CFEL.LCIDT.TrafficControlDeviceFamily`, ($self) => class TrafficControlDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4300141907)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<TrafficControlDeviceReceivedDataModel, TrafficControlDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<TrafficControlDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300141907);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300141907)
            
            //--TRIMMABLE-BOUNDARY-START(8595109203)
            /*Type */ get DeviceLogType()
            {
                return $.$CFEL.LCIDTM.TrafficControlLogModel.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8595109203)
            
            static $h = 5174611;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8595109203),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17185043795,
        "f": 50364417
      },
      "n": "DeviceLogType",
      "d": 5174611,
      "h": 8595109203,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8595109203)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300141907),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5174611,
      "h": 4300141907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300141907)
  ],
  "h": 5174611
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$CFEL.LCIDT.TrafficControlDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$CFEL.LCIDT.TrafficControlDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.TrafficControlDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}TrafficControlDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5174611)
        
        

        //--TRIMMABLE-BOUNDARY-START(587091)
        $asm.$cls(`$CFEL.LCIDTMC.TrafficControlDeviceCommands`, ($self) => class TrafficControlDeviceCommands extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$CFEL.LCIDT.TrafficControlDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12885488979)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12885488979)
            
            //--TRIMMABLE-BOUNDARY-START(17180456275)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel?*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180456275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$CFEL.LCIDTMC.TrafficControlDeviceCommands.commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17180456275)
            
            //--TRIMMABLE-BOUNDARY-START(21475423571)
            static /*Task */ OverrideControl(/*IConnectionClient*/ client, /*int*/ lane, /*TrafficState*/ state, /*int*/ time)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475423571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand($.$CFEL.LCIDTMC.TrafficControlOverrideControlCommand, $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel, client, new $.$CFEL.LCIDTMC.TrafficControlOverrideControlCommand().$ctor$6(), (() =>
                {
                    //new $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel()
                    const $t1 = $.$CFEL.LCIDTMC.TrafficControlOverrideControlModel;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Lane = lane;
                    $i1.State = state;
                    $i1.Time = time;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(21475423571)
            
            //--TRIMMABLE-BOUNDARY-START(25770390867)
            static /*Task */ OverrideMode(/*IConnectionClient*/ client, /*TrafficControlMode*/ mode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770390867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.SendCommand($.$CFEL.LCIDTMC.TrafficControlOverrideModeCommand, $.$CFEL.LCIDTMC.TrafficControlOverrideModeModel, $.$XBGm.LCICDi.iSmartDeviceAckResponseModel, client, new $.$CFEL.LCIDTMC.TrafficControlOverrideModeCommand().$ctor$6(), (() =>
                {
                    //new $.$CFEL.LCIDTMC.TrafficControlOverrideModeModel()
                    const $t2 = $.$CFEL.LCIDTMC.TrafficControlOverrideModeModel;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mode = mode;
                    return $i2;
                })(), null);
            }
            //--TRIMMABLE-BOUNDARY-END(25770390867)
            
            //--TRIMMABLE-BOUNDARY-START(8590521683)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590521683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590521683)
            
            //--TRIMMABLE-BOUNDARY-START(8590521683)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590521683)
            
            //--TRIMMABLE-BOUNDARY-START(4295554387)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295554387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885488979)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [new $.$CFEL.LCIDTMC.TrafficControlOverrideControlCommand().$ctor$6()], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12885488979)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295554387)
            
            static $h = 587091;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$CFEL.LCIDT.TrafficControlDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180456275),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": 587091,
      "h": 17180456275,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180456275),
//--TRIMMABLE-BOUNDARY-START(21475423571),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "lane",
          "p": 655361
        },
        {
          "n": "state",
          "p": 1307987
        },
        {
          "n": "time",
          "p": 655361
        }
      ],
      "n": "OverrideControl",
      "d": 587091,
      "h": 21475423571,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475423571),
//--TRIMMABLE-BOUNDARY-START(25770390867),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "mode",
          "p": 4453715
        }
      ],
      "n": "OverrideMode",
      "d": 587091,
      "h": 25770390867,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770390867)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885488979),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": 587091,
      "h": 12885488979,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885488979)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590521683),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 587091,
      "h": 8590521683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590521683)
  ],
  "h": 587091
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Models.Commands.TrafficControlDeviceCommands`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Models${separator}Commands${separator}TrafficControlDeviceCommands`; }
        });
        //--TRIMMABLE-BOUNDARY-END(587091)
        
        

        $asm.$typeProxy("$CFEL.LCIDTV.TrafficControlClientAppViewModel", "$CFEL.LivingThing.Core.IOT.Devices.TrafficControl.ViewModels.TrafficControlClientAppViewModel");
        $asm.$typeProxy("$CFEL.LCIDTV.TrafficControlClientAppServiceViewModel", "$CFEL.LivingThing.Core.IOT.Devices.TrafficControl.ViewModels.TrafficControlClientAppServiceViewModel");
        $asm.$typeProxy("$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel", "$CFEL.LivingThing.Core.IOT.Devices.TrafficControl.ViewModels.TrafficControlClientAppDeviceViewModel");
        //--TRIMMABLE-BOUNDARY-START(5436755)
        $asm.$cls(`$CFEL.LCIDTV.TrafficControlClientAppDeviceScopeViewModel`, ($self) => class TrafficControlClientAppDeviceScopeViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTV.TrafficControlClientAppViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppServiceViewModel, $self, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, $.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4300404051)
            $ctor$3(/*TrafficControlClientAppServiceViewModel*/ service, /*TrafficControlDeviceScopeModel*/ model, /*IEnumerable<TrafficControlClientAppDeviceViewModel>*/ devices)
            {
                super.$ctor$3(service, model, devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300404051);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300404051)
            
            static $h = 5436755;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTV.TrafficControlClientAppViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppServiceViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceScopeViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, $.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300404051),
    {
      "p": [
        {
          "n": "service",
          "p": 5567827
        },
        {
          "n": "model",
          "p": 2225491
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5436755,
      "h": 4300404051,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300404051)
  ],
  "h": 5436755
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$vWqU.LCFCC.IViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTDeviceScopeViewModel$$$($.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.ViewModels.TrafficControlClientAppDeviceScopeViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}ViewModels${separator}TrafficControlClientAppDeviceScopeViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5436755)
        
        

        //--TRIMMABLE-BOUNDARY-START(5633363)
        $asm.$cls(`$CFEL.LCIDTV.TrafficControlClientAppViewModel`, ($self) => class TrafficControlClientAppViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($self, $.$CFEL.LCIDTV.TrafficControlClientAppServiceViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceScopeViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, $.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4300600659)
            $ctor$5(/*IOTRootViewModel*/ root, /*TrafficControlDeviceFamily*/ family, /*IHubConnector<IIOTDeviceHubClientBase<TrafficControlDeviceReceivedDataModel, IOTDeviceStatusModel>>*/ hubConnector)
            {
                super.$ctor$5(root, family, $.$$.N.InterfaceVarianceStubHandler.Create(hubConnector, $.$kVHt.LCFCH.IHubConnector$$($.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)), $.$kVHt.LCFCH.IHubConnector$$($.$CFEL.LCIDTS.ITrafficControlDeviceHubClient)));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300600659);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300600659)
            
            //--TRIMMABLE-BOUNDARY-START(8595567955)
            /*bool */ get Authorize()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(8595567955)
            
            //--TRIMMABLE-BOUNDARY-START(21480469843)
            /*TrafficControlClientAppServiceViewModel */ GetServiceViewModel(/*TrafficControlServiceModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21480469843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$CFEL.LCIDTV.TrafficControlClientAppServiceViewModel().$ctor$3(this, model);
            }
            //--TRIMMABLE-BOUNDARY-END(21480469843)
            
            //--TRIMMABLE-BOUNDARY-START(25775437139)
            /*ValueTask<IEnumerable<UserServiceSubscriptionModel<TrafficControlServiceModel>>> *//*async*/  LoadServices()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$CFEL.LCIDTM.TrafficControlServiceModel))), $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$CFEL.LCIDTM.TrafficControlServiceModel)), async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25775437139);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let services = ($t1 = this.LoadServicesFromJWT(null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, services);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25775437139)
            
            static $h = 5633363;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTV.TrafficControlClientAppViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppServiceViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceScopeViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, $.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8595567955),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17185502547,
        "f": 50364417
      },
      "n": "Authorize",
      "d": 5633363,
      "h": 8595567955,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8595567955)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21480469843),
    {
      "r": 5567827,
      "p": [
        {
          "n": "model",
          "p": 3011923
        }
      ],
      "n": "GetServiceViewModel",
      "d": 5633363,
      "h": 21480469843,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21480469843),
//--TRIMMABLE-BOUNDARY-START(25775437139),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$CFEL.LCIDTM.TrafficControlServiceModel))).$h,
      "n": "LoadServices",
      "d": 5633363,
      "h": 25775437139,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(25775437139)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300600659),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "family",
          "p": 5174611
        },
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$($.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5633363,
      "h": 4300600659,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300600659)
  ],
  "h": 5633363
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$ntej.LCICV.IIOTAppViewModel$$($.$CFEL.LCIDTM.TrafficControlServiceModel), $.$ntej.LCICV.IIOTApplicationViewModel, $.$vWqU.LCFCC.IServiceViewModel$$($.$CFEL.LCIDTM.TrafficControlServiceModel), $.$vWqU.LCFCC.IServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$yleQ.LCFCA.IApplicationService, $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$vWqU.LCFCC.IServiceSubscriptionViewModel$$($.$CFEL.LCIDTM.TrafficControlServiceModel), $.$vWqU.LCFCC.IServiceSubscriptionViewModel, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IClientRootService$$($.$CFEL.LCIDTM.TrafficControlServiceModel), $.$vWqU.LCFCC.IClientRootService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.ViewModels.TrafficControlClientAppViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}ViewModels${separator}TrafficControlClientAppViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5633363)
        
        

        //--TRIMMABLE-BOUNDARY-START(5567827)
        $asm.$cls(`$CFEL.LCIDTV.TrafficControlClientAppServiceViewModel`, ($self) => class TrafficControlClientAppServiceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTV.TrafficControlClientAppViewModel, $self, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceScopeViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, $.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4300535123)
            $ctor$3(/*TrafficControlClientAppViewModel*/ app, /*TrafficControlServiceModel*/ model)
            {
                super.$ctor$3(app, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300535123);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300535123)
            
            //--TRIMMABLE-BOUNDARY-START(12890469715)
            /*TrafficControlClientAppDeviceViewModel */ GetDeviceViewModel(/*TrafficControlDeviceModel*/ model, /*IEnumerable<TrafficControlClientAppDeviceScopeViewModel>*/ scopes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890469715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel().$ctor$7(this, model, scopes);
            }
            //--TRIMMABLE-BOUNDARY-END(12890469715)
            
            //--TRIMMABLE-BOUNDARY-START(8595502419)
            /*TrafficControlClientAppDeviceScopeViewModel */ GetDeviceScopeViewModel(/*TrafficControlDeviceScopeModel*/ model, /*IEnumerable<TrafficControlClientAppDeviceViewModel>*/ devices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595502419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$CFEL.LCIDTV.TrafficControlClientAppDeviceScopeViewModel().$ctor$3(this, model, devices);
            }
            //--TRIMMABLE-BOUNDARY-END(8595502419)
            
            static $h = 5567827;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTV.TrafficControlClientAppViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppServiceViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceScopeViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, $.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890469715),
    {
      "r": 5502291,
      "p": [
        {
          "n": "model",
          "p": 1701203
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$CFEL.LCIDTV.TrafficControlClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": "GetDeviceViewModel",
      "d": 5567827,
      "h": 12890469715,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12890469715),
//--TRIMMABLE-BOUNDARY-START(8595502419),
    {
      "r": 5436755,
      "p": [
        {
          "n": "model",
          "p": 2225491
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel).$h
        }
      ],
      "n": "GetDeviceScopeViewModel",
      "d": 5567827,
      "h": 8595502419,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8595502419)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300535123),
    {
      "p": [
        {
          "n": "app",
          "p": 5633363
        },
        {
          "n": "model",
          "p": 3011923
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5567827,
      "h": 4300535123,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300535123)
  ],
  "h": 5567827
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTApplicationServiceViewModel$$$$$$$$($.$CFEL.LCIDTM.TrafficControlServiceModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceScopeViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTApplicationServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.ViewModels.TrafficControlClientAppServiceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}ViewModels${separator}TrafficControlClientAppServiceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5567827)
        
        

        //--TRIMMABLE-BOUNDARY-START(5502291)
        $asm.$cls(`$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel`, ($self) => class TrafficControlClientAppDeviceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTV.TrafficControlClientAppViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppServiceViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceScopeViewModel, $self, $.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4300469587)
            $ctor$7(/*TrafficControlClientAppServiceViewModel*/ service, /*TrafficControlDeviceModel*/ model, /*IEnumerable<TrafficControlClientAppDeviceScopeViewModel>*/ scopes)
            {
                super.$ctor$7(service, model, scopes);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300469587);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300469587)
            
            static $h = 5502291;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTV.TrafficControlClientAppViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppServiceViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceScopeViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, $.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300469587),
    {
      "p": [
        {
          "n": "service",
          "p": 5567827
        },
        {
          "n": "model",
          "p": 1701203
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$CFEL.LCIDTV.TrafficControlClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 5502291,
      "h": 4300469587,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300469587)
  ],
  "h": 5502291
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICV.IIOTDeviceViewModel$$$$($.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTDeviceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.ViewModels.TrafficControlClientAppDeviceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}ViewModels${separator}TrafficControlClientAppDeviceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5502291)
        
        

        //--TRIMMABLE-BOUNDARY-START(5371219)
        $asm.$cls(`$CFEL.LCIDTV.TrafficControlClientAppDefinition`, ($self) => class TrafficControlClientAppDefinition extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTV.TrafficControlClientAppViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppServiceViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceScopeViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, $.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4300338515)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300338515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300338515)
            
            //--TRIMMABLE-BOUNDARY-START(4300338515)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4300338515)
            
            static $h = 5371219;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$CFEL.LCIDTV.TrafficControlClientAppViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppServiceViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceScopeViewModel, $.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, $.$CFEL.LCIDT.TrafficControlDevice, $.$CFEL.LCIDTM.TrafficControlServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$CFEL.LCIDTM.TrafficControlDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$CFEL.LCIDTM.TrafficControlDeviceModel, $.$CFEL.LCIDTS$1.TrafficControlDeviceSettings, $.$CFEL.LCIDTS$1.TrafficControlDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$CFEL.LCIDTM.TrafficControlDeviceReceivedDataModel, $.$CFEL.LCIDTM.TrafficControlDeviceSendDataModel, $.$CFEL.LCIDTS.ITrafficControlDeviceStatusHandler, $.$CFEL.LCIDTS.ITrafficControlDeviceHubClient, $.$CFEL.LCIDTS.ITrafficControlRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300338515),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5371219,
      "h": 4300338515,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300338515)
  ],
  "h": 5371219
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.ViewModels.TrafficControlClientAppDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}ViewModels${separator}TrafficControlClientAppDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5371219)
        
        

        //--TRIMMABLE-BOUNDARY-START(5829971)
        $asm.$cls(`$CFEL.LCIDTV$1.TrafficControl`, ($self) => class TrafficControl extends $.$ntej.LCICS$2.JWTDashboard$$$($.$CFEL.LCIDTV.TrafficControlClientAppViewModel, $.$CFEL.LCIDTM.TrafficControlServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(81610208595)
            /*string */ get OptimizedComponentName()
            {
                return "trafficcontrol jwtdashboard";
            }
            //--TRIMMABLE-BOUNDARY-END(81610208595)
            
            //--TRIMMABLE-BOUNDARY-START(64430339411)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64430339411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Connection = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$KuVO.LCFCC.RemoteClientConnectionProxy, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(64430339411)
            
            //--TRIMMABLE-BOUNDARY-START(94495110483)
            /*string*/ static Route = null;
            //--TRIMMABLE-BOUNDARY-END(94495110483)
            
            //--TRIMMABLE-BOUNDARY-START(21480666451)
            /*string*/ static Description = null;
            //--TRIMMABLE-BOUNDARY-END(21480666451)
            
            //--TRIMMABLE-BOUNDARY-START(68725306707)
            /*string? */ get Name()
            {
                return "TrafficControl";
            }
            //--TRIMMABLE-BOUNDARY-END(68725306707)
            
            //--TRIMMABLE-BOUNDARY-START(17185699155)
            /*RemoteClientConnectionProxy*/ Connection = null;
            //--TRIMMABLE-BOUNDARY-END(17185699155)
            
            //--TRIMMABLE-BOUNDARY-START(103085045075)
            /*TrafficControlClientAppDeviceViewModel?*/ selectedDevice = null;
            //--TRIMMABLE-BOUNDARY-END(103085045075)
            
            //--TRIMMABLE-BOUNDARY-START(120264914259)
            /*IEnumerable<TrafficControlSlotSettings>?*/ slots = null;
            //--TRIMMABLE-BOUNDARY-END(120264914259)
            
            //--TRIMMABLE-BOUNDARY-START(90200143187)
            /*TrafficControlMode*/ overrideMode = 3;
            //--TRIMMABLE-BOUNDARY-END(90200143187)
            
            //--TRIMMABLE-BOUNDARY-START(85905175891)
            /*Task *//*async*/  OverideControlMode()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85905175891);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.selectedDevice !== null)
                    {
                        let $t1, $r1;
                        /*var*/ let client = this.Connection.get_Item$3(`TrafficControl/${$.$strNN(this.selectedDevice.Model$1.UniqueId)}`);
                        ($t1 = $.$CFEL.LCIDTMC.TrafficControlDeviceCommands.OverrideMode(client, this.overrideMode), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85905175891)
            
            //--TRIMMABLE-BOUNDARY-START(98790077779)
            /*Task *//*async*/  Save()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98790077779);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.slots !== null)
                    {
                        let $t4, $r4;
                        let $en2 = this.slots.SCG$IEnumerable$$$GetEnumerator();
                        while ($en2.SC$1$IEnumerator$MoveNext())
                        {
                            let slot = $en2.SCG$IEnumerator$$$Current;
                            {
                                if (slot.IsEnabled)
                                {
                                    if (slot.Slices !== null)
                                    {
                                        /*int*/ let i = 1;
                                        let $i3 = 0;
                                        let $arr3 = slot.Slices;
                                        while ($i3 < $arr3.length)
                                        {
                                            let sl = $arr3[$i3++];
                                            sl.Id = i;
                                            i++;
                                        }
                                    }
                                }
                            }
                        }
                        ($t4 = $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$CFEL.LCIDT.TrafficControlDevice).SetRemoteHardwareConfigurationT($.$$.SCG.IEnumerable$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings), $.$fPer.LCFCO.OneOf$$$($.$XBGm.LCICDi.IiSmartIOTDevice, $.$KuVO.LCFCC.IConnectionClient).FromT1(this.Connection.get_Item$3(`TrafficControl/${$.$strNN(this.selectedDevice.Model$1.UniqueId)}`)), this.slots, "tfs"), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        this.NotifySuccess("Settings Updated", null);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(98790077779)
            
            //--TRIMMABLE-BOUNDARY-START(124559881555)
            /*Dictionary<TrafficControlClientAppDeviceViewModel, IEnumerable<TrafficControlSlotSettings>>*/ slotsCache = null;
            //--TRIMMABLE-BOUNDARY-END(124559881555)
            
            //--TRIMMABLE-BOUNDARY-START(77315241299)
            /*ValueTask<bool> *//*async*/  OnSelected(/*DataListSelection<TrafficControlClientAppDeviceViewModel>*/ selection)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77315241299);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.selectedDevice = selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data;
                    this.slots = $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, $.$$.SCG.IEnumerable$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings), this.slotsCache, this.selectedDevice);
                    if (this.slots === null)
                    {
                        this.slots = null;
                        try
                        {
                            let $t5, $r5;
                            this.slots = ($t5 = $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$CFEL.LCIDT.TrafficControlDevice).GetRemoteHardwareConfigurationT($.$typeArray($.$CFEL.LCIDTS$1.TrafficControlSlotSettings), $.$fPer.LCFCO.OneOf$$$($.$XBGm.LCICDi.IiSmartIOTDevice, $.$KuVO.LCFCC.IConnectionClient).FromT1(this.Connection.get_Item$3(`TrafficControl/${$.$strNN(this.selectedDevice.Model$1.UniqueId)}`)), "tfs"), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                            if (this.slots !== null)
                            {
                                this.slotsCache.set_Item(this.selectedDevice, this.slots);
                            }
                        }
                        catch($e)
                        {
                        }
                    }
                    _ = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.TrafficControl\\TrafficControl.razor.cs", "OnSelected", 102);
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77315241299)
            
            //--TRIMMABLE-BOUNDARY-START(73020274003)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73020274003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(73020274003)
            
            //--TRIMMABLE-BOUNDARY-START(12890731859)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890731859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this, super.BuildRenderTree);
                __builder.AddContent$1(0, view);
            }
            //--TRIMMABLE-BOUNDARY-END(12890731859)
            
            //--TRIMMABLE-BOUNDARY-START(128854848851)
            /*RenderFragment */ get View()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                {
                    __builder2.OpenElement(1, "div");
                    __builder2.AddAttribute$5(2, "class", "hv-10 stack");
                    __builder2.OpenElement(3, "div");
                    __builder2.AddAttribute$5(4, "class", "pd bg-card flex bdb");
                    __builder2.OpenElement(5, "h2");
                    __builder2.AddAttribute$5(6, "class", "mgy-a fill");
                    __builder2.AddContent$4(7, this.ViewModel.SelectedServiceViewModel.Model.Title);
                    __builder2.CloseElement();
                    if (this.selectedDevice !== null && this.slots !== null)
                    {
                        __builder2.OpenElement(8, "button");
                        __builder2.AddAttribute$5(9, "class", "mgy-a bg-primary mgl pdy-2 pdx-4 corner");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 10, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Save)));
                        __builder2.AddContent$4(11, "Update");
                        __builder2.CloseElement();
                    }
                    __builder2.OpenElement(12, "button");
                    __builder2.AddAttribute$5(13, "class", "mgy-a bg-error mgl pdy-2 pdx-4 corner");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 14, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Reset)));
                    __builder2.AddContent$4(15, "Reset");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    if ((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false)
                    {
                        __builder2.OpenElement(16, "div");
                        __builder2.AddAttribute$5(17, "class", "fill clip");
                        __builder2.AddAttribute$5(18, "style", "background-color:" + $.$strNN(($.$CFEL.LCIDTV$1.RoadAnimation.BackgroundColor)));
                        __builder2.OpenComponent$1($.$CFEL.LCIDTV$1.RoadAnimation, 19);
                        __builder2.AddComponentParameter(20, "Device", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, this.selectedDevice));
                        __builder2.SetKey(this.selectedDevice);
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(21, "\r\n        ");
                        __builder2.OpenElement(22, "div");
                        __builder2.AddAttribute$5(23, "class", "hx-2 scroll bg-card");
                        __builder2.AddContent$1(24, this.Devices());
                        __builder2.CloseElement();
                    }
                    else 
                    {
                        __builder2.OpenElement(25, "div");
                        __builder2.AddAttribute$5(26, "class", "fill flex clip");
                        __builder2.OpenElement(27, "div");
                        __builder2.AddAttribute$5(28, "class", "miwx-25 mawx-25 scroll bg-card");
                        __builder2.AddContent$1(29, this.Devices());
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(30, "\r\n            ");
                        __builder2.OpenElement(31, "div");
                        __builder2.AddAttribute$5(32, "class", "fill clip");
                        __builder2.AddAttribute$5(33, "style", "background-color:" + $.$strNN(($.$CFEL.LCIDTV$1.RoadAnimation.BackgroundColor)));
                        __builder2.OpenComponent$1($.$CFEL.LCIDTV$1.RoadAnimation, 34);
                        __builder2.AddComponentParameter(35, "Device", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, this.selectedDevice));
                        __builder2.SetKey(this.selectedDevice);
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        if (this.slots !== null)
                        {
                            __builder2.OpenElement(36, "div");
                            __builder2.AddAttribute$5(37, "class", "miwx-3 scroll bg-card hf scroll");
                            __builder2.AddContent$1(38, this.Settings());
                            __builder2.CloseElement();
                        }
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(39, "\r\n");
                }, $Xlkini ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":5829971,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(128854848851)
            
            //--TRIMMABLE-BOUNDARY-START(115969946963)
            /*RenderFragment */ Settings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115969946963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(40, "\r\n        ");
                    __builder2.OpenElement(41, "div");
                    __builder2.AddAttribute$5(42, "class", "pd bg-chart1-01 corner stack mg");
                    __builder2.AddMarkupContent(43, "<small>Override Mode</small>\r\n            ");
                    $.$CFEL._LCIDTVT.TypeInference.CreateInputEditor_0($.$CFEL.LCIDTS$1.TrafficControlMode, __builder2, 44, 45, this.overrideMode, 46, $.$mac.MAC.EventCallback.Factory.Create$6($.$CFEL.LCIDTS$1.TrafficControlMode, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$2($.$CFEL.LCIDTS$1.TrafficControlMode, this, $.$mac.MACC.RuntimeHelpers.CreateInferredBindSetter$1($.$CFEL.LCIDTS$1.TrafficControlMode, new ($.$$.S.Func$$$($.$CFEL.LCIDTS$1.TrafficControlMode, $.$$.STT.Task))().$ctor(this,  (/**/ __value) =>
                    {
                        this.overrideMode = __value;
                        return $.$mac.MACC.RuntimeHelpers.InvokeAsynchronousDelegate$1(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.OverideControlMode));
                    }, $WBtBdl ??= {"r":178454529,"p":[{"n":"__value","p":4453715}],"n":"","d":5829971,"h":0,"f":17825794}), this.overrideMode), this.overrideMode)), 47, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                    {
                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "overrideMode"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                    }, $xeuDUd ??= {"r":38797349,"n":"","d":5829971,"h":0,"f":17825794})).Invoke()));
                    __builder2.CloseElement();
                    if (this.slots !== null)
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCA.Accordion, 48);
                        __builder2.AddComponentParameter(49, "Exclusive", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                        /*LivingThing.Core.IOT.Devices.TrafficControl.ViewModels.TrafficControlClientAppDeviceViewModel?*/ let __ca1__;
                        /*LivingThing.Core.IOT.Devices.TrafficControl.Models.TrafficControlDeviceReceivedDataModel?*/ let __ca2__;
                        /*LivingThing.Core.IOT.Devices.TrafficControl.Models.Statuses.TrafficControlStatusModel?*/ let __ca3__;
                        __builder2.AddComponentParameter(50, "InitialViewName", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, "Slot " + $.$strNN(((__ca1__ = this.selectedDevice) !== null ? ((__ca2__ = __ca1__.Received$1) !== null ? ((__ca3__ = __ca2__.Status) !== null ? $.$$.S.Int32.ToString.call(__ca3__.RunningSlot) : null) : null) : null))));
                        __builder2.AddAttribute$3(51, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                        {
                            /*int*/ let i = 0;
                            let $en6 = this.slots.SCG$IEnumerable$$$GetEnumerator();
                            while ($en6.SC$1$IEnumerator$MoveNext())
                            {
                                let _setting = $en6.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let setting = _setting;
                                    /*var*/ let ii = i;
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 52);
                                    __builder3.AddComponentParameter(53, "Class", "bg-card pd mgt");
                                    __builder3.AddComponentParameter(54, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, "Slot " + ii));
                                    __builder3.AddComponentParameter(55, "header-class", `${$.$strNN(((this.selectedDevice?.Received$1?.Status?.RunningSlot ?? null) === ii ? "bg-success-01" : "bg-primary-01"))} pd`);
                                    __builder3.AddAttribute$3(56, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenElement(57, "div");
                                            __builder4.AddAttribute$5(58, "class", $.$strNN("flex" + " ") + $.$strNN((setting.IsEnabled ? "" : "text-strike")));
                                            __builder4.OpenElement(59, "b");
                                            __builder4.AddContent$4(60, "Slot ");
                                            __builder4.AddContent$3(61, $.$box(((ii + 1) | 0), $.$$.S.Int32));
                                            __builder4.CloseElement();
                                            __builder4.AddMarkupContent(62, "\r\n                        ");
                                            __builder4.OpenElement(63, "span");
                                            __builder4.AddAttribute$5(64, "class", "mgl-a");
                                            __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 65, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(setting, setting.ToggleEnabled)));
                                            $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder4, 66, "onclick", true);
                                            __builder4.AddContent$4(67, setting.Start.ToString$1(true, true));
                                            __builder4.AddContent$4(68, " to ");
                                            __builder4.AddContent$4(69, setting.End.ToString$1(true, true));
                                            __builder4.CloseElement();
                                            __builder4.CloseElement();
                                        }, $ZhgIfj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":5829971,"h":0,"f":17825794});
                                    }), $pZyOyk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":5829971,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(70, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/**/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder4) =>
                                        {
                                            __builder4.OpenComponent$1($.$CFEL.LCIDTV$1.SlotEditor, 71);
                                            __builder4.AddComponentParameter(72, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$CFEL.LCIDTS$1.TrafficControlSlotSettings, setting));
                                            __builder4.AddComponentParameter(73, "Device", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, this.selectedDevice));
                                            __builder4.AddComponentParameter(74, "Index", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, ii), $.$$.S.Int32));
                                            __builder4.CloseComponent();
                                        }, $Adydmf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":5829971,"h":0,"f":17825794});
                                    }), $NPDQok ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":5829971,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    i++;
                                }
                            }
                        }), $QIawkg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":5829971,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }
                }, $dMycee ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":5829971,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(115969946963)
            
            //--TRIMMABLE-BOUNDARY-START(25775633747)
            /*RenderFragment */ Devices()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25775633747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(75, "\r\n        ");
                    __builder2.AddMarkupContent(76, "<div class=\"pd-1 bdb\"><h3 class=\"text-center mg-0\">Traffic Control Assets</h3></div>\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel), 77);
                    __builder2.AddComponentParameter(78, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel), this.ViewModel.SelectedServiceViewModel.Devices));
                    __builder2.AddComponentParameter(79, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 65536n | 524288n | 8388608n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder2.AddComponentParameter(80, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                    __builder2.AddAttribute$3(81, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel))))().$ctor(this, ( (/*device*/ device) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.OpenElement(82, "div");
                            __builder3.AddAttribute$5(83, "class", `row pd-1`);
                            __builder3.OpenElement(84, "div");
                            __builder3.AddAttribute$5(85, "class", "col-a mgx-2");
                            if (device.Data.Model$1.Icon !== null)
                            {
                                __builder3.OpenElement(86, "div");
                                __builder3.AddAttribute$5(87, "class", "round clip mg-a");
                                __builder3.AddAttribute$5(88, "style", "max-height:50px;max-width:50px");
                                __builder3.OpenElement(89, "img");
                                __builder3.AddAttribute$5(90, "class", "mawp-10 mahp-10");
                                __builder3.AddAttribute$4(91, "src", device.Data.Icon);
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                            }
                            else 
                            {
                                __builder3.OpenElement(92, "i");
                                __builder3.AddAttribute$5(93, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("fsz-25" + " hx-0") + " mdi") + " mdi-circle") + " cl-") + $.$strNN(((device.Data.Model$1.Online ?? false) ? "success" : "gray"))) + " mgy-a");
                                __builder3.CloseElement();
                            }
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(94, "\r\n                ");
                            __builder3.OpenElement(95, "div");
                            __builder3.AddAttribute$5(96, "class", "col-10 pdr-1 stack");
                            __builder3.OpenElement(97, "b");
                            __builder3.AddAttribute$5(98, "class", "d-block mgy-a fsz-small");
                            __builder3.AddContent$4(99, device.Data.Name);
                            __builder3.AddContent$4(100, " (");
                            __builder3.AddContent$4(101, device.Data.Model$1.UniqueId);
                            __builder3.AddMarkupContent(102, ")\r\n                    ");
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                        }, $YPdOZj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":5829971,"h":0,"f":17825794});
                    }), $kWyfBi ??= {"r":6881395,"p":[{"n":"device","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel)).$h}],"n":"","d":5829971,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(103, "\r\n    ");
                }, $PDeJkd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":5829971,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(25775633747)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.IOT.Devices.TrafficControl.ViewModels.TrafficControlClientAppDeviceViewModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.IOT.Devices.TrafficControl.ViewModels.TrafficControlClientAppDeviceViewModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$IOT$Devices$TrafficControl$ViewModels$TrafficControlClientAppDeviceViewModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(8595764563)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595764563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8595764563)
            
            //--TRIMMABLE-BOUNDARY-START(8595764563)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(8595764563)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17185699155)
                this.Connection = null;
                //--TRIMMABLE-BOUNDARY-END(17185699155)
                
                //--TRIMMABLE-BOUNDARY-START(124559881555)
                this.slotsCache = new ($.$$.SCG.Dictionary$$$($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, $.$$.SCG.IEnumerable$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(124559881555)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(94495110483)
                    this.Route = "/TrafficControl";
                    //--TRIMMABLE-BOUNDARY-END(94495110483)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21480666451)
                    this.Description = "Traffic light control system";
                    //--TRIMMABLE-BOUNDARY-END(21480666451)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 5829971;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICS$2.JWTDashboard$$$($.$CFEL.LCIDTV.TrafficControlClientAppViewModel, $.$CFEL.LCIDTM.TrafficControlServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81610208595),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51545437523,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 5829971,
      "h": 81610208595,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81610208595),
//--TRIMMABLE-BOUNDARY-START(68725306707),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42955502931,
        "f": 50364420
      },
      "n": "Name",
      "d": 5829971,
      "h": 68725306707,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(68725306707),
//--TRIMMABLE-BOUNDARY-START(17185699155),
    {
      "p": 2485934,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34365568339,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111674979667,
        "f": 83886081
      },
      "n": "Connection",
      "d": 5829971,
      "h": 17185699155,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17185699155),
//--TRIMMABLE-BOUNDARY-START(128854848851),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60135372115,
        "f": 50364420
      },
      "n": "View",
      "d": 5829971,
      "h": 128854848851,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(128854848851)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64430339411),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 5829971,
      "h": 64430339411,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64430339411),
//--TRIMMABLE-BOUNDARY-START(85905175891),
    {
      "r": 178454529,
      "n": "OverideControlMode",
      "d": 5829971,
      "h": 85905175891,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(85905175891),
//--TRIMMABLE-BOUNDARY-START(98790077779),
    {
      "r": 178454529,
      "n": "Save",
      "d": 5829971,
      "h": 98790077779,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(98790077779),
//--TRIMMABLE-BOUNDARY-START(77315241299),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel).$h
        }
      ],
      "n": "OnSelected",
      "d": 5829971,
      "h": 77315241299,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(77315241299),
//--TRIMMABLE-BOUNDARY-START(73020274003),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 5829971,
      "h": 73020274003,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(73020274003),
//--TRIMMABLE-BOUNDARY-START(12890731859),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 5829971,
      "h": 12890731859,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12890731859),
//--TRIMMABLE-BOUNDARY-START(115969946963),
    {
      "r": 6881395,
      "n": "Settings",
      "d": 5829971,
      "h": 115969946963,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115969946963),
//--TRIMMABLE-BOUNDARY-START(25775633747),
    {
      "r": 6881395,
      "n": "Devices",
      "d": 5829971,
      "h": 25775633747,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25775633747)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(94495110483),
    {
      "t": 1310721,
      "n": "Route",
      "d": 5829971,
      "h": 94495110483,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94495110483),
//--TRIMMABLE-BOUNDARY-START(21480666451),
    {
      "t": 1310721,
      "n": "Description",
      "d": 5829971,
      "h": 21480666451,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21480666451),
//--TRIMMABLE-BOUNDARY-START(103085045075),
    {
      "t": 5502291,
      "n": "selectedDevice",
      "d": 5829971,
      "h": 103085045075,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(103085045075),
//--TRIMMABLE-BOUNDARY-START(120264914259),
    {
      "t": $.$$.SCG.IEnumerable$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings).$h,
      "n": "slots",
      "d": 5829971,
      "h": 120264914259,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(120264914259),
//--TRIMMABLE-BOUNDARY-START(90200143187),
    {
      "t": 4453715,
      "n": "overrideMode",
      "d": 5829971,
      "h": 90200143187,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(90200143187),
//--TRIMMABLE-BOUNDARY-START(124559881555),
    {
      "t": $.$$.SCG.Dictionary$$$($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel, $.$$.SCG.IEnumerable$$($.$CFEL.LCIDTS$1.TrafficControlSlotSettings)).$h,
      "n": "slotsCache",
      "d": 5829971,
      "h": 124559881555,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(124559881555)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595764563),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 5829971,
      "h": 8595764563,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595764563)
  ],
  "h": 5829971,
  "a": [
    {
      "t": 30640470,
      "c": 25800444246,
      "n": [
        {
          "n": "OpenGraphTitle",
          "v": "Traffic light control system",
          "t": 1310721
        },
        {
          "n": "OpenGraphDescription",
          "v": "Traffic light control system",
          "t": 1310721
        },
        {
          "n": "OpenGraphPath",
          "v": "/TrafficControl",
          "t": 1310721
        },
        {
          "n": "OpenGraphImage",
          "v": "_content/LivingThing.Core.IOT.Devices.TrafficControl/img/trafficlight.jpg",
          "t": 1310721
        },
        {
          "n": "OpenGraphType",
          "v": 2,
          "t": 30902614
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/TrafficControl",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$CFEL.LCIDTV.TrafficControlClientAppDeviceViewModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCC$1.IManagedBaseComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.TrafficControl.Views.TrafficControl`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}TrafficControl${separator}Views${separator}TrafficControl`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5829971)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(62803)
