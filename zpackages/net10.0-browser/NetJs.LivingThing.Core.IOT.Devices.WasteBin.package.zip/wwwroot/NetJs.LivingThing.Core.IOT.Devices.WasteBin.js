
//--TRIMMABLE-BOUNDARY-START(29799)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $LsMzdi;
    let $mcCeqg;
    let $xxSIsd;
    let $KOhDpi;
    let $FIxdxc;
    let $CayJFc;
    let $TfFVUj;
    let $bMmnFa;
    let $hqnOIe;
    let $UHagsc;
    let $dLacWd;
    let $XunQlc;
    let $eAGuHj;
    let $KVOVOa;
    let $IbHLYg;
    let $pZBrwg;
    let $EwEQfd;
    let $EPxGqf;
    let $akjOTe;
    let $wFSzEh;
    let $LbVzyh;
    let $JkVmrg;
    let $CdYVVe;
    let $TALGaj;
    let $oCMsKj;
    let $gpOCtf;
    let $bGthMj;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.WasteBin", 
    {
  "h": 29799,
  "f": "LivingThing.Core.IOT.Devices.WasteBin",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.WasteBin",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.WasteBin",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5XYXN0ZUJpbi5TbWFydFdhc3RlQmluRGV2aWNlIjogew0KICAgICAgIkNhdGVnb3JpZXMiOiBbICJXYXN0ZUJpbiIgXSwNCiAgICAgICJOYW1lIjogIlNtYXJ0IFdhc3RlYmluIiwNCiAgICAgICJEZXNjcmlwdGlvbiI6ICJDbG91ZCBjb25uZWN0ZWQgd2FzdGUgYmluIiwNCiAgICAgICJCYW5uZXJJbWFnZSI6ICJ\u002BL3ByaWNlZGlzcGxheS5wbmciLA0KICAgICAgIkljb24iOiB7ICJOYW1lIjogIm1kaSBtZGktZWxlY3RyaWMtc3dpdGNoIiB9LA0KICAgICAgIlRoZW1lQ29sb3IiOiAiI2Q3N2JiYSIsDQogICAgICAiRmxhZ3MiOiAiRmVhdHVyZWQsUHVibGlzaGVkIiwNCiAgICAgICJTZWN1cml0aWVzIjogIkNoYWxsZW5nZUhhbmRTaGFrZUF1dGhlbnRpY2F0aW9uUHJvdG9jb2wsQWR2YW5jZWRFbmNyeXB0aW9uU3RhbmRhcmQsRWxsaXB0aWNDdXJ2ZUZpcm13YXJlVXBkYXRlU2lnbmluZyINCiAgICB9DQogIH0NCn0="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(160871)
        $asm.$cls(`$XBnD.LCIDW._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295128167)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295128167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$XBnD.LCIDW.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295128167)
            
            static $h = 160871;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295128167),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 160871,
      "h": 4295128167,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295128167)
  ],
  "h": 160871
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(160871)
        
        

        //--TRIMMABLE-BOUNDARY-START(2061415)
        $asm.$cls(`$XBnD.LCIDW.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591996007)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591996007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$XBnD.LCIDWV.WasteBin, "LivingThing.Core.IOT.Devices.WasteBin", "Views\\WasteBin", "Waste Bin", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/WasteBin" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8591996007)
            
            //--TRIMMABLE-BOUNDARY-START(4297028711)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297028711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297028711)
            
            //--TRIMMABLE-BOUNDARY-START(4297028711)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297028711)
            
            static $h = 2061415;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591996007),
    {
      "r": 65537,
      "n": "Build",
      "d": 2061415,
      "h": 8591996007,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591996007)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297028711),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2061415,
      "h": 4297028711,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297028711)
  ],
  "h": 2061415
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2061415)
        
        

        //--TRIMMABLE-BOUNDARY-START(2454631)
        $asm.$cls(`$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class SmartWasteBinDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297421927)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297421927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297421927)
            
            static $h = 2454631;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297421927),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2454631,
      "h": 4297421927,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297421927)
  ],
  "h": 2454631
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Settings${separator}SmartWasteBinDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2454631)
        
        

        //--TRIMMABLE-BOUNDARY-START(1537127)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinServiceModelCustomAttributesProvider`, ($self) => class SmartWasteBinServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296504423)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296504423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296504423)
            
            static $h = 1537127;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296504423),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1537127,
      "h": 4296504423,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296504423)
  ],
  "h": 1537127
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1537127)
        
        

        //--TRIMMABLE-BOUNDARY-START(2716775)
        $asm.$cls(`$XBnD.LCIDWS$1.SmartWasteBinDeviceSettingsCustomAttributesProvider`, ($self) => class SmartWasteBinDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297684071)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297684071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297684071)
            
            static $h = 2716775;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297684071),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2716775,
      "h": 4297684071,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297684071)
  ],
  "h": 2716775
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Settings${separator}SmartWasteBinDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2716775)
        
        

        //--TRIMMABLE-BOUNDARY-START(488551)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceModelCustomAttributesProvider`, ($self) => class SmartWasteBinDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295455847)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295455847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295455847)
            
            static $h = 488551;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295455847),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 488551,
      "h": 4295455847,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295455847)
  ],
  "h": 488551
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(488551)
        
        

        //--TRIMMABLE-BOUNDARY-START(291943)
        $asm.$cls(`$XBnD.LCIDW.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295259239)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295259239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$XBnD.LCIDWM.SmartWasteBinDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$XBnD.LCIDWM.SmartWasteBinDeviceModelCustomAttributesProvider, $.$XBnD.LCIDWM.SmartWasteBinDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModelCustomAttributesProvider, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModelCustomAttributesProvider, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModelCustomAttributesProvider, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$XBnD.LCIDWM.SmartWasteBinServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$XBnD.LCIDWM.SmartWasteBinServiceModelCustomAttributesProvider, $.$XBnD.LCIDWM.SmartWasteBinServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$XBnD.LCIDWM.SmartWasteBinStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$XBnD.LCIDWM.SmartWasteBinStatusModelCustomAttributesProvider, $.$XBnD.LCIDWM.SmartWasteBinStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettingsCustomAttributesProvider, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettingsCustomAttributesProvider, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295259239)
            
            static $h = 291943;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295259239),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 291943,
      "h": 4295259239,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295259239)
  ],
  "h": 291943
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(291943)
        
        

        //--TRIMMABLE-BOUNDARY-START(750695)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class SmartWasteBinDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295717991)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295717991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$XBnD.LCIDWM.SmartWasteBinStatusModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295717991)
            
            static $h = 750695;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295717991),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 750695,
      "h": 4295717991,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295717991)
  ],
  "h": 750695
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(750695)
        
        

        //--TRIMMABLE-BOUNDARY-START(881767)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class SmartWasteBinDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590816359)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590816359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $xxSIsd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":881767,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590816359)
            
            //--TRIMMABLE-BOUNDARY-START(4295849063)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295849063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295849063)
            
            //--TRIMMABLE-BOUNDARY-START(4295849063)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295849063)
            
            static $h = 881767;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590816359),
    {
      "r": 65537,
      "n": "Register",
      "d": 881767,
      "h": 8590816359,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590816359)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295849063),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 881767,
      "h": 4295849063,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295849063)
  ],
  "h": 881767
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(881767)
        
        

        //--TRIMMABLE-BOUNDARY-START(1012839)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceScopeModelCustomAttributesProvider`, ($self) => class SmartWasteBinDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295980135)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295980135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295980135)
            
            static $h = 1012839;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295980135),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1012839,
      "h": 4295980135,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295980135)
  ],
  "h": 1012839
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1012839)
        
        

        //--TRIMMABLE-BOUNDARY-START(1668199)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinServiceModelTypeDescriptorBuilder`, ($self) => class SmartWasteBinServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591602791)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591602791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$XBnD.LCIDWM.SmartWasteBinServiceModelTypeDescriptor()
                        const $t1 = $.$XBnD.LCIDWM.SmartWasteBinServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $bMmnFa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1668199,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$XBnD.LCIDWM.SmartWasteBinServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591602791)
            
            //--TRIMMABLE-BOUNDARY-START(4296635495)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296635495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296635495)
            
            //--TRIMMABLE-BOUNDARY-START(4296635495)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296635495)
            
            static $h = 1668199;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591602791),
    {
      "r": 65537,
      "n": "Register",
      "d": 1668199,
      "h": 8591602791,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591602791)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296635495),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1668199,
      "h": 4296635495,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296635495)
  ],
  "h": 1668199
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1668199)
        
        

        //--TRIMMABLE-BOUNDARY-START(619623)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceModelTypeDescriptorBuilder`, ($self) => class SmartWasteBinDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590554215)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590554215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$XBnD.LCIDWM.SmartWasteBinDeviceModelTypeDescriptor()
                        const $t1 = $.$XBnD.LCIDWM.SmartWasteBinDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $CayJFc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":619623,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$XBnD.LCIDWM.SmartWasteBinDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590554215)
            
            //--TRIMMABLE-BOUNDARY-START(4295586919)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295586919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295586919)
            
            //--TRIMMABLE-BOUNDARY-START(4295586919)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295586919)
            
            static $h = 619623;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590554215),
    {
      "r": 65537,
      "n": "Register",
      "d": 619623,
      "h": 8590554215,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590554215)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295586919),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 619623,
      "h": 4295586919,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295586919)
  ],
  "h": 619623
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(619623)
        
        

        //--TRIMMABLE-BOUNDARY-START(3241063)
        $asm.$cls(`$XBnD.LCIDW.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298208359)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298208359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBnD.LCIDWM.SmartWasteBinDeviceModelTypeDescriptorBuilder.Register();
                $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$XBnD.LCIDWM.SmartWasteBinServiceModelTypeDescriptorBuilder.Register();
                $.$XBnD.LCIDWM.SmartWasteBinStatusModelTypeDescriptorBuilder.Register();
                $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298208359)
            
            static $h = 3241063;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298208359),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3241063,
      "h": 4298208359,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298208359)
  ],
  "h": 3241063
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3241063)
        
        

        //--TRIMMABLE-BOUNDARY-START(1406055)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class SmartWasteBinDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591340647)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591340647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $LsMzdi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1406055,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591340647)
            
            //--TRIMMABLE-BOUNDARY-START(4296373351)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296373351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296373351)
            
            //--TRIMMABLE-BOUNDARY-START(4296373351)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296373351)
            
            static $h = 1406055;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591340647),
    {
      "r": 65537,
      "n": "Register",
      "d": 1406055,
      "h": 8591340647,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591340647)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296373351),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1406055,
      "h": 4296373351,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296373351)
  ],
  "h": 1406055
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1406055)
        
        

        //--TRIMMABLE-BOUNDARY-START(1274983)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModelCustomAttributesProvider`, ($self) => class SmartWasteBinDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296242279)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296242279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceSendDataModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296242279)
            
            static $h = 1274983;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296242279),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1274983,
      "h": 4296242279,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296242279)
  ],
  "h": 1274983
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1274983)
        
        

        //--TRIMMABLE-BOUNDARY-START(2585703)
        $asm.$cls(`$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class SmartWasteBinDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592520295)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592520295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $XunQlc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2585703,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592520295)
            
            //--TRIMMABLE-BOUNDARY-START(4297552999)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297552999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297552999)
            
            //--TRIMMABLE-BOUNDARY-START(4297552999)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297552999)
            
            static $h = 2585703;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592520295),
    {
      "r": 65537,
      "n": "Register",
      "d": 2585703,
      "h": 8592520295,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592520295)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297552999),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2585703,
      "h": 4297552999,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297552999)
  ],
  "h": 2585703
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Settings${separator}SmartWasteBinDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2585703)
        
        

        //--TRIMMABLE-BOUNDARY-START(1143911)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceScopeModelTypeDescriptorBuilder`, ($self) => class SmartWasteBinDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591078503)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591078503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $UHagsc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1143911,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591078503)
            
            //--TRIMMABLE-BOUNDARY-START(4296111207)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296111207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296111207)
            
            //--TRIMMABLE-BOUNDARY-START(4296111207)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296111207)
            
            static $h = 1143911;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591078503),
    {
      "r": 65537,
      "n": "Register",
      "d": 1143911,
      "h": 8591078503,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591078503)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296111207),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1143911,
      "h": 4296111207,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296111207)
  ],
  "h": 1143911
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1143911)
        
        

        //--TRIMMABLE-BOUNDARY-START(1930343)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinStatusModelTypeDescriptorBuilder`, ($self) => class SmartWasteBinStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591864935)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591864935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$XBnD.LCIDWM.SmartWasteBinStatusModelTypeDescriptor()
                        const $t1 = $.$XBnD.LCIDWM.SmartWasteBinStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $CdYVVe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1930343,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$XBnD.LCIDWM.SmartWasteBinStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591864935)
            
            //--TRIMMABLE-BOUNDARY-START(4296897639)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296897639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296897639)
            
            //--TRIMMABLE-BOUNDARY-START(4296897639)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296897639)
            
            static $h = 1930343;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591864935),
    {
      "r": 65537,
      "n": "Register",
      "d": 1930343,
      "h": 8591864935,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591864935)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296897639),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1930343,
      "h": 4296897639,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296897639)
  ],
  "h": 1930343
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1930343)
        
        

        //--TRIMMABLE-BOUNDARY-START(1799271)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinStatusModelCustomAttributesProvider`, ($self) => class SmartWasteBinStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296766567)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296766567)
            
            //--TRIMMABLE-BOUNDARY-START(8591733863)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591733863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$XBnD.LCIDWM.SmartWasteBinStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("WasteHeadRoom", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$XBnD.LCIDWM.SmartWasteBinStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $KVOVOa ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1799271,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $IbHLYg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1799271,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591733863)
            
            static $h = 1799271;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591733863),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1799271,
      "h": 8591733863,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591733863)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296766567),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1799271,
      "h": 4296766567,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296766567)
  ],
  "h": 1799271
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1799271)
        
        

        //--TRIMMABLE-BOUNDARY-START(2847847)
        $asm.$cls(`$XBnD.LCIDWS$1.SmartWasteBinDeviceSettingsTypeDescriptorBuilder`, ($self) => class SmartWasteBinDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592782439)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592782439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettingsTypeDescriptor()
                        const $t1 = $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $LbVzyh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2847847,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592782439)
            
            //--TRIMMABLE-BOUNDARY-START(4297815143)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297815143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297815143)
            
            //--TRIMMABLE-BOUNDARY-START(4297815143)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297815143)
            
            static $h = 2847847;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592782439),
    {
      "r": 65537,
      "n": "Register",
      "d": 2847847,
      "h": 8592782439,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592782439)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297815143),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2847847,
      "h": 4297815143,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297815143)
  ],
  "h": 2847847
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Settings${separator}SmartWasteBinDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2847847)
        
        

        //--TRIMMABLE-BOUNDARY-START(226407)
        $asm.$cls(`$XBnD.LCIDW.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180095591)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$sl.SL.Enumerable.Empty($.$$.S.String);
            }
            //--TRIMMABLE-BOUNDARY-END(17180095591)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295193703)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295193703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295193703)
            
            //--TRIMMABLE-BOUNDARY-START(4295193703)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295193703)
            
            static $h = 226407;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180095591),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885128295,
        "f": 50331649
      },
      "n": "Paths",
      "d": 226407,
      "h": 17180095591,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180095591)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295193703),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 226407,
      "h": 4295193703,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295193703)
  ],
  "h": 226407
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(226407)
        
        

        //--TRIMMABLE-BOUNDARY-START(1995879)
        $asm.$cls(`$XBnD.LCIDW.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181865063)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$XBnD.LCIDWV.WasteBin.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$XBnD.LCIDWV.WasteBin().$ctor$6();
                    }, $FIxdxc ??= {"r":2752627,"n":"","d":1995879,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17181865063)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4296963175)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296963175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296963175)
            
            //--TRIMMABLE-BOUNDARY-START(4296963175)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296963175)
            
            static $h = 1995879;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181865063),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886897767,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 1995879,
      "h": 17181865063,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181865063)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296963175),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1995879,
      "h": 4296963175,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296963175)
  ],
  "h": 1995879
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1995879)
        
        

        //--TRIMMABLE-BOUNDARY-START(2126951)
        $asm.$cls(`$XBnD.LCIDW.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592061543)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592061543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$XBnD.LCIDW.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBnD.LCIDW.SmartWasteBinDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$XBnD.LCIDW.SmartWasteBinDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$XBnD.LCIDW.SmartWasteBinDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$XBnD.LCIDW.SmartWasteBinDeviceFamily, x);
                }, $pZBrwg ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":2126951,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$XBnD.LCIDW.SmartWasteBinDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$XBnD.LCIDW.SmartWasteBinDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $EwEQfd ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":2126951,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$XBnD.LCIDW.SmartWasteBinDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$XBnD.LCIDW.SmartWasteBinDeviceFamily, x);
                }, $EPxGqf ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$XBnD.LCIDW.SmartWasteBinDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":2126951,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$XBnD.LCIDW.SmartWasteBinDeviceFamily, x);
                }, $akjOTe ??= {"r":$.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType).$h,"p":[{"n":"x","p":327718}],"n":"","d":2126951,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$XBnD.LCIDW.SmartWasteBinDeviceFamily, x);
                }, $wFSzEh ??= {"r":$.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType).$h,"p":[{"n":"x","p":327718}],"n":"","d":2126951,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$XBnD.LCIDW.SmartWasteBinDevice), $.$XBnD.LCIDWM.SmartWasteBinDeviceCommands$$($.$XBnD.LCIDW.SmartWasteBinDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$XBnD.LCIDWV.SmartWasteBinClientAppViewModel, services);
                $.$sZVd.LCFCA.ClientApplicationExtension.AddApplication($.$XBnD.LCIDWV.WasteBin, services, (() =>
                {
                    //new $.$sZVd.LCFCA.ClientApplicationModel$$($.$XBnD.LCIDWV.WasteBin)()
                    const $t1 = $.$sZVd.LCFCA.ClientApplicationModel$$($.$XBnD.LCIDWV.WasteBin);
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Categories = $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "IOT" ], null, null);
                    $i1.Name = "WasteBin";
                    $i1.Title = "Smart Wastebin";
                    $i1.Description = "Smart Wastebin with cloud connectivity";
                    $i1.Paths = $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "WasteBin" ], null, null);
                    $i1.Theme = $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t2 = $.$fPer.LCFC.Theme;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.BackgroundColor = "#00AEFF";
                        $i2.ForegroundColor = "#FFFFFF";
                        return $i2;
                    })());
                    $i1.Icon = $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-truck-cargo-container"/*MaterialDesignIconNames.TruckCargoContainer*/);
                    return $i1;
                })());
                $.$XBnD.LCIDW.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$XBnD.LCIDW.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592061543)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBnD.LCIDW.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297094247)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297094247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297094247)
            
            //--TRIMMABLE-BOUNDARY-START(4297094247)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297094247)
            
            static $h = 2126951;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592061543),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2126951,
      "h": 8592061543,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592061543)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297094247),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2126951,
      "h": 4297094247,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297094247)
  ],
  "h": 2126951
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2126951)
        
        

        //--TRIMMABLE-BOUNDARY-START(3699815)
        $asm.$cls(`$XBnD.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298667111)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298667111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298667111)
            
            //--TRIMMABLE-BOUNDARY-START(4298667111)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298667111)
            
            static $h = 3699815;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298667111),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3699815,
      "h": 4298667111,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298667111)
  ],
  "h": 3699815
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3699815)
        
        

        //--TRIMMABLE-BOUNDARY-START(3765351)
        $asm.$cls(`$XBnD.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298732647)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298732647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298732647)
            
            //--TRIMMABLE-BOUNDARY-START(4298732647)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298732647)
            
            static $h = 3765351;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298732647),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3765351,
      "h": 4298732647,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298732647)
  ],
  "h": 3765351,
  "a": [
    {
      "t": 3699815,
      "c": 4298667111
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3765351)
        
        

        //--TRIMMABLE-BOUNDARY-START(1733735)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinStatusModel`, ($self) => class SmartWasteBinStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(30066504807)
            /*float*/ WasteHeadRoom = 0;
            //--TRIMMABLE-BOUNDARY-END(30066504807)
            
            //--TRIMMABLE-BOUNDARY-START(8591668327)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591668327);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591668327)
            
            //--TRIMMABLE-BOUNDARY-START(8591668327)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8591668327)
            
            static $h = 1733735;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066504807),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181602919,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25771537511,
        "f": 83886081
      },
      "n": "WasteHeadRoom",
      "d": 1733735,
      "h": 30066504807,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066504807)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591668327),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1733735,
      "h": 8591668327,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591668327)
  ],
  "h": 1733735
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1733735)
        
        

        //--TRIMMABLE-BOUNDARY-START(95335)
        $asm.$cls(`$XBnD.LCIDW._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590029927)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590029927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590029927)
            
            //--TRIMMABLE-BOUNDARY-START(4295062631)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295062631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295062631)
            
            //--TRIMMABLE-BOUNDARY-START(4295062631)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295062631)
            
            static $h = 95335;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590029927),
    {
      "r": 65537,
      "n": "Execute",
      "d": 95335,
      "h": 8590029927,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590029927)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295062631),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 95335,
      "h": 4295062631,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295062631)
  ],
  "h": 95335
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(95335)
        
        

        //--TRIMMABLE-BOUNDARY-START(1209447)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel`, ($self) => class SmartWasteBinDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceSendDataModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296176743)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296176743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296176743)
            
            //--TRIMMABLE-BOUNDARY-START(4296176743)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296176743)
            
            static $h = 1209447;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceSendDataModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296176743),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1209447,
      "h": 4296176743,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296176743)
  ],
  "h": 1209447
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1209447)
        
        

        //--TRIMMABLE-BOUNDARY-START(1864807)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinStatusModelTypeDescriptor`, ($self) => class SmartWasteBinStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296832103)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296832103);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$XBnD.LCIDWM.SmartWasteBinStatusModelTypeDescriptor.GenerateProperties($.$XBnD.LCIDWM.SmartWasteBinStatusModel, this, factory);
                    }, $TALGaj ??= {"r":65537,"n":"","d":1864807,"h":0,"f":17825794}), 0, "SmartWasteBinStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.WasteBin\\Models_SmartWasteBinStatusModel_LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinStatusModelTypeDescriptorBuilder.g.cs", "SmartWasteBinStatusModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296832103)
            
            //--TRIMMABLE-BOUNDARY-START(12886766695)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886766695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("WasteHeadRoom"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$XBnD.LCIDWM.SmartWasteBinStatusModel.$type, $.$discardRef(), "WasteHeadRoom", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("WasteHeadRoom")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Single, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "WasteHeadRoom";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$XBnD.LCIDWM.SmartWasteBinStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$9(($.$cast(target, $.$XBnD.LCIDWM.SmartWasteBinStatusModel)).WasteHeadRoom);
                        }, $oCMsKj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1864807,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$XBnD.LCIDWM.SmartWasteBinStatusModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.WasteHeadRoom = value.AsFloat();
                        }, $gpOCtf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1864807,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886766695)
            
            //--TRIMMABLE-BOUNDARY-START(17181733991)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181733991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _WasteHeadRoom = _target.WasteHeadRoom;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("WasteHeadRoom"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Single));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Single, property, $.$ref(() => _WasteHeadRoom, ($v) => _WasteHeadRoom = $v, $.$$.S.Single)))
                    {
                        _target.WasteHeadRoom = _WasteHeadRoom;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181733991)
            
            //--TRIMMABLE-BOUNDARY-START(8591799399)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591799399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$XBnD.LCIDWM.SmartWasteBinStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$XBnD.LCIDWM.SmartWasteBinStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinStatusModel)))
                {
                    /*var*/ let result = $.$XBnD.LCIDWM.SmartWasteBinStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$XBnD.LCIDWM.SmartWasteBinStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591799399)
            
            static $h = 1864807;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886766695),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1864807,
      "h": 12886766695,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886766695),
//--TRIMMABLE-BOUNDARY-START(17181733991),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1733735,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1864807,
      "h": 17181733991,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181733991),
//--TRIMMABLE-BOUNDARY-START(8591799399),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1733735,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1864807,
      "h": 8591799399,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591799399)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296832103),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1864807,
      "h": 4296832103,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296832103)
  ],
  "h": 1864807
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1864807)
        
        

        //--TRIMMABLE-BOUNDARY-START(357479)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceCommands<>`, (TDevice) => $asm.$gt(`$XBnD.LCIDWM.SmartWasteBinDeviceCommands<>`, [TDevice], ($self) => class SmartWasteBinDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12885259367)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12885259367)
            
            //--TRIMMABLE-BOUNDARY-START(17180226663)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel?*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180226663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$XBnD.LCIDWM.SmartWasteBinDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17180226663)
            
            //--TRIMMABLE-BOUNDARY-START(8590292071)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590292071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590292071)
            
            //--TRIMMABLE-BOUNDARY-START(8590292071)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590292071)
            
            //--TRIMMABLE-BOUNDARY-START(4295324775)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295324775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885259367)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12885259367)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295324775)
            
            static $H = 357479;
            static $h = 357479;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180226663),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17180226663,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180226663)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885259367),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12885259367,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885259367)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590292071),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8590292071,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590292071)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 357479,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(357479)
        
        

        //--TRIMMABLE-BOUNDARY-START(1340519)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModelTypeDescriptor`, ($self) => class SmartWasteBinDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296307815)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296307815);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModelTypeDescriptor.GenerateProperties($.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, this, factory);
                    }, $mcCeqg ??= {"r":65537,"n":"","d":1340519,"h":0,"f":17825794}), 0, "SmartWasteBinDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.WasteBin\\Models_SmartWasteBinDeviceSendDataModel_LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceSendDataModelTypeDescriptorBuilder.g.cs", "SmartWasteBinDeviceSendDataModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296307815)
            
            //--TRIMMABLE-BOUNDARY-START(12886242407)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886242407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886242407)
            
            //--TRIMMABLE-BOUNDARY-START(17181209703)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181209703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceSendDataModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceSendDataModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181209703)
            
            //--TRIMMABLE-BOUNDARY-START(8591275111)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591275111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591275111)
            
            static $h = 1340519;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886242407),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1340519,
      "h": 12886242407,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886242407),
//--TRIMMABLE-BOUNDARY-START(17181209703),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1209447,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1340519,
      "h": 17181209703,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181209703),
//--TRIMMABLE-BOUNDARY-START(8591275111),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1209447,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1340519,
      "h": 8591275111,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591275111)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296307815),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1340519,
      "h": 4296307815,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296307815)
  ],
  "h": 1340519
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1340519)
        
        

        //--TRIMMABLE-BOUNDARY-START(685159)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel`, ($self) => class SmartWasteBinDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$XBnD.LCIDWM.SmartWasteBinStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295652455)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295652455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295652455)
            
            //--TRIMMABLE-BOUNDARY-START(4295652455)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295652455)
            
            static $h = 685159;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$XBnD.LCIDWM.SmartWasteBinStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295652455),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 685159,
      "h": 4295652455,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295652455)
  ],
  "h": 685159
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(685159)
        
        

        //--TRIMMABLE-BOUNDARY-START(816231)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModelTypeDescriptor`, ($self) => class SmartWasteBinDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295783527)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295783527);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, this, factory);
                    }, $KOhDpi ??= {"r":65537,"n":"","d":816231,"h":0,"f":17825794}), 0, "SmartWasteBinDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.WasteBin\\Models_SmartWasteBinDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "SmartWasteBinDeviceReceivedDataModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295783527)
            
            //--TRIMMABLE-BOUNDARY-START(12885718119)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885718119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinStatusModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885718119)
            
            //--TRIMMABLE-BOUNDARY-START(17180685415)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180685415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinStatusModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinStatusModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$XBnD.LCIDWM.SmartWasteBinStatusModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180685415)
            
            //--TRIMMABLE-BOUNDARY-START(8590750823)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590750823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590750823)
            
            static $h = 816231;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885718119),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 816231,
      "h": 12885718119,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885718119),
//--TRIMMABLE-BOUNDARY-START(17180685415),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 685159,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 816231,
      "h": 17180685415,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180685415),
//--TRIMMABLE-BOUNDARY-START(8590750823),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 685159,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 816231,
      "h": 8590750823,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590750823)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295783527),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 816231,
      "h": 4295783527,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295783527)
  ],
  "h": 816231
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(816231)
        
        

        //--TRIMMABLE-BOUNDARY-START(2913383)
        $asm.$cls(`$XBnD.LCIDW.SmartWasteBinDataConverter`, ($self) => class SmartWasteBinDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297880679)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297880679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297880679)
            
            //--TRIMMABLE-BOUNDARY-START(4297880679)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297880679)
            
            static $h = 2913383;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297880679),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2913383,
      "h": 4297880679,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297880679)
  ],
  "h": 2913383
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.SmartWasteBinDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}SmartWasteBinDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2913383)
        
        

        $asm.$typeProxy("$XBnD.LCIDWM.SmartWasteBinServiceModel", "$XBnD.LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinServiceModel");
        $asm.$typeProxy("$XBnD.LCIDWM.SmartWasteBinDeviceModel", "$XBnD.LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceModel");
        $asm.$typeProxy("$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings", "$XBnD.LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceSettings");
        $asm.$typeProxy("$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings", "$XBnD.LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceHardwareSettings");
        $asm.$typeProxy("$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler", "$XBnD.LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinDeviceStatusHandler");
        $asm.$typeProxy("$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient", "$XBnD.LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinDeviceHubClient");
        $asm.$typeProxy("$XBnD.LCIDWS.ISmartWasteBinRemoteService", "$XBnD.LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinRemoteService");
        //--TRIMMABLE-BOUNDARY-START(947303)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel`, ($self) => class SmartWasteBinDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295914599)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295914599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295914599)
            
            //--TRIMMABLE-BOUNDARY-START(4295914599)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295914599)
            
            static $h = 947303;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295914599),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 947303,
      "h": 4295914599,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295914599)
  ],
  "h": 947303
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(947303)
        
        

        //--TRIMMABLE-BOUNDARY-START(2192487)
        $asm.$cls(`$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient`, ($self) => class ISmartWasteBinDeviceHubClient
        {
            static $h = 2192487;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2192487
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Services${separator}ISmartWasteBinDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2192487)
        
        

        //--TRIMMABLE-BOUNDARY-START(2258023)
        $asm.$cls(`$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler`, ($self) => class ISmartWasteBinDeviceStatusHandler
        {
            static $h = 2258023;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2258023
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Services${separator}ISmartWasteBinDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2258023)
        
        

        //--TRIMMABLE-BOUNDARY-START(423015)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceModel`, ($self) => class SmartWasteBinDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295390311)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295390311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295390311)
            
            //--TRIMMABLE-BOUNDARY-START(4295390311)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295390311)
            
            static $h = 423015;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295390311),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 423015,
      "h": 4295390311,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295390311)
  ],
  "h": 423015
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(423015)
        
        

        //--TRIMMABLE-BOUNDARY-START(1471591)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinServiceModel`, ($self) => class SmartWasteBinServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296438887)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296438887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296438887)
            
            //--TRIMMABLE-BOUNDARY-START(4296438887)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4296438887)
            
            static $h = 1471591;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296438887),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 1471591,
      "h": 4296438887,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296438887)
  ],
  "h": 1471591
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1471591)
        
        

        //--TRIMMABLE-BOUNDARY-START(2323559)
        $asm.$cls(`$XBnD.LCIDWS.ISmartWasteBinRemoteService`, ($self) => class ISmartWasteBinRemoteService
        {
            static $h = 2323559;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2323559
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Services${separator}ISmartWasteBinRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2323559)
        
        

        //--TRIMMABLE-BOUNDARY-START(2389095)
        $asm.$cls(`$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings`, ($self) => class SmartWasteBinDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297356391)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297356391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297356391)
            
            //--TRIMMABLE-BOUNDARY-START(4297356391)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297356391)
            
            static $h = 2389095;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297356391),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2389095,
      "h": 4297356391,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297356391)
  ],
  "h": 2389095
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Settings${separator}SmartWasteBinDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2389095)
        
        

        //--TRIMMABLE-BOUNDARY-START(2651239)
        $asm.$cls(`$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings`, ($self) => class SmartWasteBinDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $self, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297618535)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297618535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297618535)
            
            //--TRIMMABLE-BOUNDARY-START(4297618535)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297618535)
            
            static $h = 2651239;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297618535),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2651239,
      "h": 4297618535,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297618535)
  ],
  "h": 2651239
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Settings${separator}SmartWasteBinDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2651239)
        
        

        //--TRIMMABLE-BOUNDARY-START(3175527)
        $asm.$cls(`$XBnD.LCIDW.SmartWasteBinDeviceModelDefinition`, ($self) => class SmartWasteBinDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4298142823)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298142823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298142823)
            
            //--TRIMMABLE-BOUNDARY-START(4298142823)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298142823)
            
            static $h = 3175527;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298142823),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3175527,
      "h": 4298142823,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298142823)
  ],
  "h": 3175527
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.SmartWasteBinDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}SmartWasteBinDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3175527)
        
        

        //--TRIMMABLE-BOUNDARY-START(1602663)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinServiceModelTypeDescriptor`, ($self) => class SmartWasteBinServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296569959)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296569959);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$XBnD.LCIDWM.SmartWasteBinServiceModelTypeDescriptor.GenerateProperties($.$XBnD.LCIDWM.SmartWasteBinServiceModel, this, factory);
                    }, $hqnOIe ??= {"r":65537,"n":"","d":1602663,"h":0,"f":17825794}), 0, "SmartWasteBinServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.WasteBin\\Models_SmartWasteBinServiceModel_LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinServiceModelTypeDescriptorBuilder.g.cs", "SmartWasteBinServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296569959)
            
            //--TRIMMABLE-BOUNDARY-START(12886504551)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886504551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886504551)
            
            //--TRIMMABLE-BOUNDARY-START(17181471847)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181471847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceModel, LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceSettings, LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceSendDataModel, LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinDeviceStatusHandler, LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinDeviceHubClient, LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181471847)
            
            //--TRIMMABLE-BOUNDARY-START(8591537255)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591537255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$XBnD.LCIDWM.SmartWasteBinServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinServiceModel)))
                {
                    /*var*/ let result = $.$XBnD.LCIDWM.SmartWasteBinServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591537255)
            
            static $h = 1602663;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886504551),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1602663,
      "h": 12886504551,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886504551),
//--TRIMMABLE-BOUNDARY-START(17181471847),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1471591,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1602663,
      "h": 17181471847,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181471847),
//--TRIMMABLE-BOUNDARY-START(8591537255),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1471591,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1602663,
      "h": 8591537255,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591537255)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296569959),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1602663,
      "h": 4296569959,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296569959)
  ],
  "h": 1602663
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1602663)
        
        

        //--TRIMMABLE-BOUNDARY-START(554087)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceModelTypeDescriptor`, ($self) => class SmartWasteBinDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295521383)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295521383);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$XBnD.LCIDWM.SmartWasteBinDeviceModelTypeDescriptor.GenerateProperties($.$XBnD.LCIDWM.SmartWasteBinDeviceModel, this, factory);
                    }, $TfFVUj ??= {"r":65537,"n":"","d":554087,"h":0,"f":17825794}), 0, "SmartWasteBinDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.WasteBin\\Models_SmartWasteBinDeviceModel_LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceModelTypeDescriptorBuilder.g.cs", "SmartWasteBinDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295521383)
            
            //--TRIMMABLE-BOUNDARY-START(12885455975)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885455975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885455975)
            
            //--TRIMMABLE-BOUNDARY-START(17180423271)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180423271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceModel, LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceSettings, LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceSendDataModel, LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinDeviceStatusHandler, LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinDeviceHubClient, LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180423271)
            
            //--TRIMMABLE-BOUNDARY-START(8590488679)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590488679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$XBnD.LCIDWM.SmartWasteBinDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel)))
                {
                    /*var*/ let result = $.$XBnD.LCIDWM.SmartWasteBinDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590488679)
            
            static $h = 554087;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885455975),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 554087,
      "h": 12885455975,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885455975),
//--TRIMMABLE-BOUNDARY-START(17180423271),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 423015,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 554087,
      "h": 17180423271,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180423271),
//--TRIMMABLE-BOUNDARY-START(8590488679),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 423015,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 554087,
      "h": 8590488679,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590488679)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295521383),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 554087,
      "h": 4295521383,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295521383)
  ],
  "h": 554087
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(554087)
        
        

        //--TRIMMABLE-BOUNDARY-START(1078375)
        $asm.$cls(`$XBnD.LCIDWM.SmartWasteBinDeviceScopeModelTypeDescriptor`, ($self) => class SmartWasteBinDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296045671)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296045671);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModelTypeDescriptor.GenerateProperties($.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, this, factory);
                    }, $dLacWd ??= {"r":65537,"n":"","d":1078375,"h":0,"f":17825794}), 0, "SmartWasteBinDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.WasteBin\\Models_SmartWasteBinDeviceScopeModel_LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceScopeModelTypeDescriptorBuilder.g.cs", "SmartWasteBinDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296045671)
            
            //--TRIMMABLE-BOUNDARY-START(12885980263)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885980263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885980263)
            
            //--TRIMMABLE-BOUNDARY-START(17180947559)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180947559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceModel, LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceSettings, LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceSendDataModel, LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinDeviceStatusHandler, LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinDeviceHubClient, LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180947559)
            
            //--TRIMMABLE-BOUNDARY-START(8591012967)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591012967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel)))
                {
                    /*var*/ let result = $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591012967)
            
            static $h = 1078375;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885980263),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1078375,
      "h": 12885980263,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885980263),
//--TRIMMABLE-BOUNDARY-START(17180947559),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 947303,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1078375,
      "h": 17180947559,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180947559),
//--TRIMMABLE-BOUNDARY-START(8591012967),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 947303,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1078375,
      "h": 8591012967,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591012967)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296045671),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1078375,
      "h": 4296045671,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296045671)
  ],
  "h": 1078375
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Models${separator}SmartWasteBinDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1078375)
        
        

        //--TRIMMABLE-BOUNDARY-START(2520167)
        $asm.$cls(`$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettingsTypeDescriptor`, ($self) => class SmartWasteBinDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297487463)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297487463);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, this, factory);
                    }, $eAGuHj ??= {"r":65537,"n":"","d":2520167,"h":0,"f":17825794}), 0, "SmartWasteBinDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.WasteBin\\Settings_SmartWasteBinDeviceHardwareSettings_LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "SmartWasteBinDeviceHardwareSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297487463)
            
            //--TRIMMABLE-BOUNDARY-START(12887422055)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887422055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887422055)
            
            //--TRIMMABLE-BOUNDARY-START(17182389351)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182389351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceModel, LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceSettings, LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceSendDataModel, LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinDeviceStatusHandler, LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinDeviceHubClient, LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).iSmartDeviceHardwareSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182389351)
            
            //--TRIMMABLE-BOUNDARY-START(8592454759)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592454759);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592454759)
            
            static $h = 2520167;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887422055),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2520167,
      "h": 12887422055,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887422055),
//--TRIMMABLE-BOUNDARY-START(17182389351),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2389095,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2520167,
      "h": 17182389351,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182389351),
//--TRIMMABLE-BOUNDARY-START(8592454759),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2389095,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2520167,
      "h": 8592454759,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592454759)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297487463),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2520167,
      "h": 4297487463,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297487463)
  ],
  "h": 2520167
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Settings${separator}SmartWasteBinDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2520167)
        
        

        //--TRIMMABLE-BOUNDARY-START(2782311)
        $asm.$cls(`$XBnD.LCIDWS$1.SmartWasteBinDeviceSettingsTypeDescriptor`, ($self) => class SmartWasteBinDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297749607)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297749607);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettingsTypeDescriptor.GenerateProperties($.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, this, factory);
                    }, $JkVmrg ??= {"r":65537,"n":"","d":2782311,"h":0,"f":17825794}), 0, "SmartWasteBinDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.WasteBin\\Settings_SmartWasteBinDeviceSettings_LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceSettingsTypeDescriptorBuilder.g.cs", "SmartWasteBinDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297749607)
            
            //--TRIMMABLE-BOUNDARY-START(12887684199)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887684199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887684199)
            
            //--TRIMMABLE-BOUNDARY-START(17182651495)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182651495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceModel, LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceSettings, LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.WasteBin.Models.SmartWasteBinDeviceSendDataModel, LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinDeviceStatusHandler, LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinDeviceHubClient, LivingThing.Core.IOT.Devices.WasteBin.Services.ISmartWasteBinRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService).iSmartDeviceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182651495)
            
            //--TRIMMABLE-BOUNDARY-START(8592716903)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592716903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings)))
                {
                    /*var*/ let result = $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592716903)
            
            static $h = 2782311;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887684199),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2782311,
      "h": 12887684199,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887684199),
//--TRIMMABLE-BOUNDARY-START(17182651495),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2651239,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2782311,
      "h": 17182651495,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182651495),
//--TRIMMABLE-BOUNDARY-START(8592716903),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2651239,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2782311,
      "h": 8592716903,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592716903)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297749607),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2782311,
      "h": 4297749607,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297749607)
  ],
  "h": 2782311
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Settings.SmartWasteBinDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Settings${separator}SmartWasteBinDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2782311)
        
        

        //--TRIMMABLE-BOUNDARY-START(2978919)
        $asm.$cls(`$XBnD.LCIDW.SmartWasteBinDevice`, ($self) => class SmartWasteBinDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$XBnD.LCIDWM.SmartWasteBinStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4297946215)
            $ctor$2(/*IIOTDeviceFamily<SmartWasteBinDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*SmartWasteBinDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297946215);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297946215)
            
            static $h = 2978919;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$XBnD.LCIDWM.SmartWasteBinStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297946215),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$XBnD.LCIDW.SmartWasteBinDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 423015
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2978919,
      "h": 4297946215,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297946215)
  ],
  "h": 2978919
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.SmartWasteBinDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}SmartWasteBinDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2978919)
        
        

        //--TRIMMABLE-BOUNDARY-START(3044455)
        $asm.$cls(`$XBnD.LCIDW.SmartWasteBinDeviceDefinition`, ($self) => class SmartWasteBinDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$XBnD.LCIDWM.SmartWasteBinStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298011751)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298011751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298011751)
            
            //--TRIMMABLE-BOUNDARY-START(4298011751)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298011751)
            
            static $h = 3044455;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$XBnD.LCIDWM.SmartWasteBinStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298011751),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3044455,
      "h": 4298011751,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298011751)
  ],
  "h": 3044455
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.SmartWasteBinDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}SmartWasteBinDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3044455)
        
        

        //--TRIMMABLE-BOUNDARY-START(3109991)
        $asm.$cls(`$XBnD.LCIDW.SmartWasteBinDeviceFamily`, ($self) => class SmartWasteBinDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4298077287)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<SmartWasteBinDeviceReceivedDataModel, SmartWasteBinDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<SmartWasteBinDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298077287);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298077287)
            
            //--TRIMMABLE-BOUNDARY-START(8593044583)
            /*IIOTDeviceFamilyFeatures */ get Features()
            {
                return super.Features | 1/*IIOTDeviceFamilyFeatures.NoDatabase*/;
            }
            //--TRIMMABLE-BOUNDARY-END(8593044583)
            
            static $h = 3109991;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8593044583),
    {
      "p": 26842513,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182979175,
        "f": 50364417
      },
      "n": "Features",
      "d": 3109991,
      "h": 8593044583,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8593044583)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298077287),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3109991,
      "h": 4298077287,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298077287)
  ],
  "h": 3109991
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$XBnD.LCIDW.SmartWasteBinDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.SmartWasteBinDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}SmartWasteBinDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3109991)
        
        

        $asm.$typeProxy("$XBnD.LCIDWV.SmartWasteBinClientAppViewModel", "$XBnD.LivingThing.Core.IOT.Devices.WasteBin.Views.SmartWasteBinClientAppViewModel");
        $asm.$typeProxy("$XBnD.LCIDWV.SmartWasteBinClientAppServiceViewModel", "$XBnD.LivingThing.Core.IOT.Devices.WasteBin.Views.SmartWasteBinClientAppServiceViewModel");
        $asm.$typeProxy("$XBnD.LCIDWV.SmartWasteBinClientAppDeviceViewModel", "$XBnD.LivingThing.Core.IOT.Devices.WasteBin.Views.SmartWasteBinClientAppDeviceViewModel");
        //--TRIMMABLE-BOUNDARY-START(3372135)
        $asm.$cls(`$XBnD.LCIDWV.SmartWasteBinClientAppDeviceScopeViewModel`, ($self) => class SmartWasteBinClientAppDeviceScopeViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWV.SmartWasteBinClientAppViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppServiceViewModel, $self, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceViewModel, $.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298339431)
            $ctor$3(/*SmartWasteBinClientAppServiceViewModel*/ service, /*SmartWasteBinDeviceScopeModel*/ model, /*IEnumerable<SmartWasteBinClientAppDeviceViewModel>*/ devices)
            {
                super.$ctor$3(service, model, devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298339431);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298339431)
            
            static $h = 3372135;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWV.SmartWasteBinClientAppViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppServiceViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceScopeViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceViewModel, $.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298339431),
    {
      "p": [
        {
          "n": "service",
          "p": 3503207
        },
        {
          "n": "model",
          "p": 947303
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3372135,
      "h": 4298339431,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298339431)
  ],
  "h": 3372135
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$vWqU.LCFCC.IViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTDeviceScopeViewModel$$$($.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceViewModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Views.SmartWasteBinClientAppDeviceScopeViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Views${separator}SmartWasteBinClientAppDeviceScopeViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3372135)
        
        

        //--TRIMMABLE-BOUNDARY-START(3437671)
        $asm.$cls(`$XBnD.LCIDWV.SmartWasteBinClientAppDeviceViewModel`, ($self) => class SmartWasteBinClientAppDeviceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWV.SmartWasteBinClientAppViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppServiceViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceScopeViewModel, $self, $.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298404967)
            $ctor$7(/*SmartWasteBinClientAppServiceViewModel*/ service, /*SmartWasteBinDeviceModel*/ model, /*IEnumerable<SmartWasteBinClientAppDeviceScopeViewModel>*/ scopes)
            {
                super.$ctor$7(service, model, scopes);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298404967);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298404967)
            
            static $h = 3437671;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWV.SmartWasteBinClientAppViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppServiceViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceScopeViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceViewModel, $.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298404967),
    {
      "p": [
        {
          "n": "service",
          "p": 3503207
        },
        {
          "n": "model",
          "p": 423015
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 3437671,
      "h": 4298404967,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298404967)
  ],
  "h": 3437671
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICV.IIOTDeviceViewModel$$$$($.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTDeviceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Views.SmartWasteBinClientAppDeviceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Views${separator}SmartWasteBinClientAppDeviceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3437671)
        
        

        //--TRIMMABLE-BOUNDARY-START(3503207)
        $asm.$cls(`$XBnD.LCIDWV.SmartWasteBinClientAppServiceViewModel`, ($self) => class SmartWasteBinClientAppServiceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWV.SmartWasteBinClientAppViewModel, $self, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceScopeViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceViewModel, $.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298470503)
            $ctor$3(/*SmartWasteBinClientAppViewModel*/ app, /*SmartWasteBinServiceModel*/ model)
            {
                super.$ctor$3(app, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298470503);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298470503)
            
            //--TRIMMABLE-BOUNDARY-START(12888405095)
            /*SmartWasteBinClientAppDeviceViewModel */ GetDeviceViewModel(/*SmartWasteBinDeviceModel*/ model, /*IEnumerable<SmartWasteBinClientAppDeviceScopeViewModel>*/ scopes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888405095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceViewModel().$ctor$7(this, model, scopes);
            }
            //--TRIMMABLE-BOUNDARY-END(12888405095)
            
            //--TRIMMABLE-BOUNDARY-START(8593437799)
            /*SmartWasteBinClientAppDeviceScopeViewModel */ GetDeviceScopeViewModel(/*SmartWasteBinDeviceScopeModel*/ model, /*IEnumerable<SmartWasteBinClientAppDeviceViewModel>*/ devices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593437799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceScopeViewModel().$ctor$3(this, model, devices);
            }
            //--TRIMMABLE-BOUNDARY-END(8593437799)
            
            static $h = 3503207;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWV.SmartWasteBinClientAppViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppServiceViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceScopeViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceViewModel, $.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888405095),
    {
      "r": 3437671,
      "p": [
        {
          "n": "model",
          "p": 423015
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": "GetDeviceViewModel",
      "d": 3503207,
      "h": 12888405095,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12888405095),
//--TRIMMABLE-BOUNDARY-START(8593437799),
    {
      "r": 3372135,
      "p": [
        {
          "n": "model",
          "p": 947303
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceViewModel).$h
        }
      ],
      "n": "GetDeviceScopeViewModel",
      "d": 3503207,
      "h": 8593437799,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8593437799)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298470503),
    {
      "p": [
        {
          "n": "app",
          "p": 3568743
        },
        {
          "n": "model",
          "p": 1471591
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3503207,
      "h": 4298470503,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298470503)
  ],
  "h": 3503207
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTApplicationServiceViewModel$$$$$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceScopeViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceViewModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTApplicationServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Views.SmartWasteBinClientAppServiceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Views${separator}SmartWasteBinClientAppServiceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3503207)
        
        

        //--TRIMMABLE-BOUNDARY-START(3568743)
        $asm.$cls(`$XBnD.LCIDWV.SmartWasteBinClientAppViewModel`, ($self) => class SmartWasteBinClientAppViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($self, $.$XBnD.LCIDWV.SmartWasteBinClientAppServiceViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceScopeViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceViewModel, $.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298536039)
            $ctor$5(/*IOTRootViewModel*/ root, /*SmartWasteBinDeviceFamily*/ family, /*IHubConnector<IIOTDeviceHubClientBase<SmartWasteBinDeviceReceivedDataModel, IOTDeviceStatusModel>>*/ hubConnector)
            {
                super.$ctor$5(root, family, $.$$.N.InterfaceVarianceStubHandler.Create(hubConnector, $.$kVHt.LCFCH.IHubConnector$$($.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)), $.$kVHt.LCFCH.IHubConnector$$($.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient)));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298536039);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298536039)
            
            //--TRIMMABLE-BOUNDARY-START(8593503335)
            /*bool */ get Authorize()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593503335)
            
            //--TRIMMABLE-BOUNDARY-START(21478405223)
            /*SmartWasteBinClientAppServiceViewModel */ GetServiceViewModel(/*SmartWasteBinServiceModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478405223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$XBnD.LCIDWV.SmartWasteBinClientAppServiceViewModel().$ctor$3(this, model);
            }
            //--TRIMMABLE-BOUNDARY-END(21478405223)
            
            static $h = 3568743;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWV.SmartWasteBinClientAppViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppServiceViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceScopeViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceViewModel, $.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8593503335),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183437927,
        "f": 50364417
      },
      "n": "Authorize",
      "d": 3568743,
      "h": 8593503335,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8593503335)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21478405223),
    {
      "r": 3503207,
      "p": [
        {
          "n": "model",
          "p": 1471591
        }
      ],
      "n": "GetServiceViewModel",
      "d": 3568743,
      "h": 21478405223,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21478405223)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298536039),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "family",
          "p": 3109991
        },
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$($.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3568743,
      "h": 4298536039,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298536039)
  ],
  "h": 3568743
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$ntej.LCICV.IIOTAppViewModel$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel), $.$ntej.LCICV.IIOTApplicationViewModel, $.$vWqU.LCFCC.IServiceViewModel$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel), $.$vWqU.LCFCC.IServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$yleQ.LCFCA.IApplicationService, $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$vWqU.LCFCC.IServiceSubscriptionViewModel$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel), $.$vWqU.LCFCC.IServiceSubscriptionViewModel, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IClientRootService$$($.$XBnD.LCIDWM.SmartWasteBinServiceModel), $.$vWqU.LCFCC.IClientRootService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Views.SmartWasteBinClientAppViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Views${separator}SmartWasteBinClientAppViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3568743)
        
        

        //--TRIMMABLE-BOUNDARY-START(3306599)
        $asm.$cls(`$XBnD.LCIDWV.SmartWasteBinClientAppDefinition`, ($self) => class SmartWasteBinClientAppDefinition extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWV.SmartWasteBinClientAppViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppServiceViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceScopeViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceViewModel, $.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298273895)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298273895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298273895)
            
            //--TRIMMABLE-BOUNDARY-START(4298273895)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298273895)
            
            static $h = 3306599;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$XBnD.LCIDWV.SmartWasteBinClientAppViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppServiceViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceScopeViewModel, $.$XBnD.LCIDWV.SmartWasteBinClientAppDeviceViewModel, $.$XBnD.LCIDW.SmartWasteBinDevice, $.$XBnD.LCIDWM.SmartWasteBinServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBnD.LCIDWM.SmartWasteBinDeviceModel, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceSettings, $.$XBnD.LCIDWS$1.SmartWasteBinDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceReceivedDataModel, $.$XBnD.LCIDWM.SmartWasteBinDeviceSendDataModel, $.$XBnD.LCIDWS.ISmartWasteBinDeviceStatusHandler, $.$XBnD.LCIDWS.ISmartWasteBinDeviceHubClient, $.$XBnD.LCIDWS.ISmartWasteBinRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298273895),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3306599,
      "h": 4298273895,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298273895)
  ],
  "h": 3306599
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Views.SmartWasteBinClientAppDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Views${separator}SmartWasteBinClientAppDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3306599)
        
        

        //--TRIMMABLE-BOUNDARY-START(3634279)
        $asm.$cls(`$XBnD.LCIDWV.WasteBin`, ($self) => class WasteBin extends $.$ntej.LCICS$2.JWTDashboard$$$($.$XBnD.LCIDWV.SmartWasteBinClientAppViewModel, $.$XBnD.LCIDWM.SmartWasteBinServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(38658339943)
            /*string*/ static Route = null;
            //--TRIMMABLE-BOUNDARY-END(38658339943)
            
            //--TRIMMABLE-BOUNDARY-START(12888536167)
            /*string*/ static Description = null;
            //--TRIMMABLE-BOUNDARY-END(12888536167)
            
            //--TRIMMABLE-BOUNDARY-START(34363372647)
            /*string */ get OptimizedComponentName()
            {
                return "wastebin jwtdashboard";
            }
            //--TRIMMABLE-BOUNDARY-END(34363372647)
            
            //--TRIMMABLE-BOUNDARY-START(8593568871)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593568871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this, super.BuildRenderTree);
                __builder.AddContent$1(0, view);
            }
            //--TRIMMABLE-BOUNDARY-END(8593568871)
            
            //--TRIMMABLE-BOUNDARY-START(42953307239)
            /*RenderFragment */ get View()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                {
                    __builder2.OpenElement(1, "div");
                    __builder2.AddAttribute$5(2, "class", "hv-10 stack");
                    __builder2.OpenElement(3, "div");
                    __builder2.AddAttribute$5(4, "class", "pd bg-card flex");
                    __builder2.OpenElement(5, "h2");
                    __builder2.AddAttribute$5(6, "class", "mgy-a fill");
                    __builder2.AddContent$4(7, this.ViewModel.SelectedServiceViewModel.Model.Title);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(8, "\r\n            ");
                    __builder2.OpenElement(9, "button");
                    __builder2.AddAttribute$5(10, "class", "mgy-a bg-error mgl pdy-2 pdx-4 corner");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 11, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Reset)));
                    __builder2.AddContent$4(12, "Reset");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(13, "\r\n        ");
                    __builder2.OpenElement(14, "div");
                    __builder2.AddAttribute$5(15, "class", "grid gap-2 colm-3 pd scroll-y");
                    let $en1 = this.ViewModel.SelectedServiceViewModel.Devices.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let device = $en1.SCG$IEnumerator$$$Current;
                        {
                            __builder2.OpenElement(16, "div");
                            __builder2.AddAttribute$5(17, "class", "bg-card bd");
                            __builder2.OpenElement(18, "div");
                            __builder2.AddAttribute$5(19, "class", "bdb pd flex");
                            __builder2.OpenElement(20, "div");
                            __builder2.AddAttribute$5(21, "class", "stack fill");
                            __builder2.OpenElement(22, "h3");
                            __builder2.AddAttribute$5(23, "class", "mg-0");
                            __builder2.AddContent$4(24, device.Model$1.Name);
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(25, "\r\n                        ");
                            __builder2.OpenElement(26, "small");
                            __builder2.AddAttribute$5(27, "class", "op-8");
                            __builder2.AddContent$4(28, device.Model$1.UniqueId);
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(29, "\r\n                    ");
                            __builder2.OpenElement(30, "i");
                            __builder2.AddAttribute$5(31, "class", $.$strNN($.$strNN($.$strNN($.$strNN("wx-01" + " hx-01") + " round") + " mgy-a") + " ") + $.$strNN(((device.Model$1.Online ?? false) ? "bg-success" : "bg-gray")));
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(32, "\r\n                ");
                            __builder2.OpenElement(33, "div");
                            __builder2.AddAttribute$5(34, "class", "pd stack");
                            /*double*/ let physicalHeight = 24;
                            __builder2.OpenComponent$1($.$hDPm.LCFCCG.TankContainer, 35);
                            __builder2.AddComponentParameter(36, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Double, 200), $.$$.S.Double));
                            __builder2.AddComponentParameter(37, "ContentsHeight", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.Double), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Double), [1 - (((device.Received$1?.Status?.WasteHeadRoom ?? null) ?? physicalHeight) / physicalHeight)], [-1], null)));
                            __builder2.AddComponentParameter(38, "UseCanvas", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }
                    }
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                }, $bGthMj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3634279,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(42953307239)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4298601575)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298601575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298601575)
            
            //--TRIMMABLE-BOUNDARY-START(4298601575)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4298601575)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(38658339943)
                    this.Route = "/WasteBin";
                    //--TRIMMABLE-BOUNDARY-END(38658339943)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12888536167)
                    this.Description = "Controls LED price display board remotely";
                    //--TRIMMABLE-BOUNDARY-END(12888536167)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 3634279;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICS$2.JWTDashboard$$$($.$XBnD.LCIDWV.SmartWasteBinClientAppViewModel, $.$XBnD.LCIDWM.SmartWasteBinServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34363372647),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478470759,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 3634279,
      "h": 34363372647,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34363372647),
//--TRIMMABLE-BOUNDARY-START(42953307239),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068405351,
        "f": 50364420
      },
      "n": "View",
      "d": 3634279,
      "h": 42953307239,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(42953307239)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593568871),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 3634279,
      "h": 8593568871,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8593568871)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38658339943),
    {
      "t": 1310721,
      "n": "Route",
      "d": 3634279,
      "h": 38658339943,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38658339943),
//--TRIMMABLE-BOUNDARY-START(12888536167),
    {
      "t": 1310721,
      "n": "Description",
      "d": 3634279,
      "h": 12888536167,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888536167)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298601575),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 3634279,
      "h": 4298601575,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298601575)
  ],
  "h": 3634279,
  "a": [
    {
      "t": 30640470,
      "c": 25800444246,
      "n": [
        {
          "n": "OpenGraphTitle",
          "v": "LED Price Display Control",
          "t": 1310721
        },
        {
          "n": "OpenGraphDescription",
          "v": "Controls LED price display board remotely",
          "t": 1310721
        },
        {
          "n": "OpenGraphPath",
          "v": "/WasteBin",
          "t": 1310721
        },
        {
          "n": "OpenGraphImage",
          "v": "_content/LivingThing.Core.IOT.Devices.WasteBin/img/pricedisplay.png",
          "t": 1310721
        },
        {
          "n": "OpenGraphType",
          "v": 2,
          "t": 30902614
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/WasteBin",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.WasteBin.Views.WasteBin`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}WasteBin${separator}Views${separator}WasteBin`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3634279)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(29799)
