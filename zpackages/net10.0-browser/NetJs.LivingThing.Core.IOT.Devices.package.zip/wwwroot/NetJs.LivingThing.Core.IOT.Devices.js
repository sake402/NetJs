
//--TRIMMABLE-BOUNDARY-START(59293)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $HnZw, $mep, $meca, $mxdi, $mexla, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $meo, $mecm, $mecga, $mec, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $fXpo, $zHIt, $uvJL, $KuVO, $lOHy, $kVHt, $UrvY, $vWqU, $JRhp, $DJRY, $tUcV, $nYKj, $AvdQ, $bMcF, $XBGm) {
    "use strict";
    let _;
    let $bhNQRi;
    let $jjtSra;
    let $KtWkni;
    let $SKmwUa;
    let $NkaNJe;
    let $rptkgc;
    let $nLtCQd;
    let $TraUDg;
    let $hCBuDh;
    let $WFMFbb;
    let $UHUdeg;
    let $rtechd;
    let $zWxPXa;
    let $tTegdk;
    let $uGTfAe;
    let $MJALqf;
    let $yTleRf;
    let $SionDi;
    let $NzXiGi;
    let $GYLSHi;
    let $nrntDd;
    let $arILWk;
    let $lSXhod;
    let $djUcrh;
    let $PLHjYk;
    let $YYMvli;
    let $IhOhYc;
    let $SDzaPe;
    let $MefNHj;
    let $Sgwnxg;
    let $wPvrgg;
    let $wGWGZd;
    let $zzmApg;
    let $dwPDRe;
    let $QPXIhi;
    let $aFVVoh;
    let $YvwjKf;
    let $vWFWUf;
    let $VqPvri;
    let $qJXmae;
    let $iQLhpc;
    let $pWqXgi;
    let $ESbOid;
    let $cRzJwe;
    let $gugNOg;
    let $hGxvva;
    let $WOHnjl;
    let $MEyeIa;
    let $jEaYXc;
    let $FlFCBi;
    let $JubgAk;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices", 
    {
  "h": 59293,
  "f": "LivingThing.Core.IOT.Devices",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5HZW5lcmljLlNtYXJ0R2VuZXJpY0RldmljZSI6IHsNCiAgICAgICJDYXRlZ29yaWVzIjogWyAiU21hcnQgSG9tZSIgXSwNCiAgICAgICJOYW1lIjogIkdlbmVyaWMgRGV2aWNlIiwNCiAgICAgICJEZXNjcmlwdGlvbiI6ICJDdXN0b20gZGV2aWNlLiIsDQogICAgICAiRmxhZ3MiOiAiUHVibGlzaGVkIiwNCiAgICAgICJJY29uIjogeyAiTmFtZSI6ICJtZGkgbWRpLWRldmljZXMiIH0sDQogICAgICAiVGhlbWVDb2xvciI6ICIjOGE2ZjMwIiwNCiAgICAgICJTZWN1cml0aWVzIjogIkNoYWxsZW5nZUhhbmRTaGFrZUF1dGhlbnRpY2F0aW9uUHJvdG9jb2wsQWR2YW5jZWRFbmNyeXB0aW9uU3RhbmRhcmQsRWxsaXB0aWNDdXJ2ZUZpcm13YXJlVXBkYXRlU2lnbmluZyIsDQogICAgICAiUHJvdG9jb2wiOiB7DQogICAgICAgICJTdGF0dXNlcyI6IFsNCiAgICAgICAgICB7DQogICAgICAgICAgICAiTmFtZSI6ICJTdGF0dXMiLA0KICAgICAgICAgICAgIlByZWZpeCI6IDIyMTMwLA0KICAgICAgICAgICAgIkRhdGFQb2ludHMiOiBbDQogICAgICAgICAgICAgIHsNCiAgICAgICAgICAgICAgICAiTmFtZSI6ICIjUHJlZml4IiwNCiAgICAgICAgICAgICAgICAiVHlwZSI6ICJ1aW50MTZfdCIsDQogICAgICAgICAgICAgICAgIlZhbHVlIjogMjIxMzANCiAgICAgICAgICAgICAgfQ0KICAgICAgICAgICAgXQ0KICAgICAgICAgIH0NCiAgICAgICAgXQ0KICAgICAgfQ0KICAgIH0NCiAgfQ0KfQ=="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1304477)
        $asm.$cls(`$NXre.LCIDSH.IHomeDeviceFinderImpl`, ($self) => class IHomeDeviceFinderImpl
        {
            static $h = 1304477;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296271773),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.DiscoveredIOTDevice)).$h,
      "n": "ScanAsync",
      "o": "LCIDSH$IHomeDeviceFinderImpl$ScanAsync",
      "d": 1304477,
      "h": 4296271773,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296271773)
  ],
  "h": 1304477
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Scopes.Home.IHomeDeviceFinderImpl`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Scopes${separator}Home${separator}IHomeDeviceFinderImpl`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1304477)
        
        

        //--TRIMMABLE-BOUNDARY-START(1501085)
        $asm.$cls(`$NXre.LCID.SmartDeviceBase`, ($self) => class SmartDeviceBase extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30066272157)
            $ctor$1(/*IIOTDeviceFamily*/ family, /*IIOTDeviceScope*/ ownerScope)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066272157);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Family = family;
                    this.OwnerScope = ownerScope;
                    this.Scopes.Add(this.OwnerScope);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066272157)
            
            //--TRIMMABLE-BOUNDARY-START(416613328797)
            /*List<IIOTDeviceScope>*/ Scopes = null;
            //--TRIMMABLE-BOUNDARY-END(416613328797)
            
            //--TRIMMABLE-BOUNDARY-START(369368688541)
            /*IIOTDeviceScope*/ OwnerScope = null;
            //--TRIMMABLE-BOUNDARY-END(369368688541)
            
            //--TRIMMABLE-BOUNDARY-START(77310912413)
            /*IIOTDeviceFamily*/ Family = null;
            //--TRIMMABLE-BOUNDARY-END(77310912413)
            
            //--TRIMMABLE-BOUNDARY-START(81605879709)
            /*IOTDeviceFeatures */ get Features()
            {
                return 1/*IOTDeviceFeatures.Default*/;
            }
            //--TRIMMABLE-BOUNDARY-END(81605879709)
            
            //--TRIMMABLE-BOUNDARY-START(352188819357)
            /*IIOTDeviceScope */ get LCICI$IIOTDevice$OwnerScope()
            {
                return this.OwnerScope;
            }
            //--TRIMMABLE-BOUNDARY-END(352188819357)
            
            //--TRIMMABLE-BOUNDARY-START(356483786653)
            /*IEnumerable<IIOTDeviceScope> */ get LCICI$IIOTDevice$Scopes()
            {
                return this.Scopes;
            }
            //--TRIMMABLE-BOUNDARY-END(356483786653)
            
            //--TRIMMABLE-BOUNDARY-START(309239146397)
            /*string */ get Id()
            {
                return (this.Model?.LCICI$IIOTDeviceModel$UniqueId ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(309239146397)
            
            //--TRIMMABLE-BOUNDARY-START(365073721245)
            /*string */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339800477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Model?.LCFC$INamed$Name ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(365073721245)
            
            //--TRIMMABLE-BOUNDARY-START(317829080989)
            /*Dictionary<IConnectionInterface, ClientConnectionIdentity>*/ Interfaces = null;
            //--TRIMMABLE-BOUNDARY-END(317829080989)
            
            //--TRIMMABLE-BOUNDARY-START(73015945117)
            /*string? */ get Description()
            {
                return (this.Family.LCICI$IIOTDeviceFamily$DeviceDescriptor?.Description$1 ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(73015945117)
            
            //--TRIMMABLE-BOUNDARY-START(304944179101)
            /*IconDescriptor */ get Icon()
            {
                return (() =>
                {
                    //new $.$fPer.LCFC.IconDescriptor()
                    const $t1 = $.$fPer.LCFC.IconDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Icon = this.Model.LCICI$IIOTDeviceModel$DeviceType !== 0/*IOTDeviceType.Others*/ ? $.$XBGm.LCIC.UtilityExtension.MaterialIcon(this.Model.LCICI$IIOTDeviceModel$DeviceType, this.IsAvailable) : (this.Family.LCICI$IIOTDeviceFamily$DeviceDescriptor?.Icon?.Name ?? null);
                    $i1.Theme = (() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t2 = $.$fPer.LCFC.Theme;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.BackgroundColor = (this.Family.LCICI$IIOTDeviceFamily$DeviceDescriptor?.ThemeColor ?? null) ?? "00AEFF";
                        $i2.ForegroundColor = "FFFFFF";
                        return $i2;
                    })();
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(304944179101)
            
            //--TRIMMABLE-BOUNDARY-START(313534113693)
            /*string */ get Image()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800192925);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Common.Models.IOTDeviceDescriptor?*/ let __ca1__;
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca2__;
                return (this.Family.LCICI$IIOTDeviceFamily$DeviceDescriptor?.BannerImage ?? null) ?? ((__ca1__ = this.Family.LCICI$IIOTDeviceFamily$DeviceDescriptor) !== null ? (((__ca2__ = __ca1__.Images) !== null ? ($.$sl.SL.Enumerable.FirstOrDefault$3($.$$.S.String, __ca2__) ?? this.OwnerScope.LCICI$IIOTDeviceScope$Factory.LCICI$IIOTDeviceScopeFactory$Icon) : this.OwnerScope.LCICI$IIOTDeviceScope$Factory.LCICI$IIOTDeviceScopeFactory$Icon) ?? this.OwnerScope.LCICI$IIOTDeviceScope$Factory.LCICI$IIOTDeviceScopeFactory$Icon) : this.OwnerScope.LCICI$IIOTDeviceScope$Factory.LCICI$IIOTDeviceScopeFactory$Icon);
            }
            //--TRIMMABLE-BOUNDARY-END(313534113693)
            
            //--TRIMMABLE-BOUNDARY-START(322124048285)
            /*bool */ get IsAvailable()
            {
                return $.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(this.LastSeenTime) && $.$$.S.DateTime.UtcNow.Subtract$1($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.LastSeenTime)).TotalSeconds < 120;
            }
            //--TRIMMABLE-BOUNDARY-END(322124048285)
            
            //--TRIMMABLE-BOUNDARY-START(463857969053)
            /*string? */ get StatusText()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469342621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Common.Models.IOTDeviceDescriptor?*/ let __ca3__;
                /*LivingThing.Core.IOT.Common.Interface.IIOTDeviceDataPointModel?*/ let __ca4__;
                return _ = ((__ca3__ = this.Family.LCICI$IIOTDeviceFamily$DeviceDescriptor) !== null ? ((__ca4__ = __ca3__.GetStatus(0, this)) !== null ? $.$dspc(__ca4__, $.$$.S.Object, ($t) => $t.ToString) : null) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(463857969053)
            
            //--TRIMMABLE-BOUNDARY-START(360778753949)
            /*IIOTDeviceModel */ get Model()
            {
                return this.GetModel();
            }
            //--TRIMMABLE-BOUNDARY-END(360778753949)
            
            //--TRIMMABLE-BOUNDARY-START(455268034461)
            /*IIOTDeviceSettings */ get Settings()
            {
                return this.GetSettings();
            }
            //--TRIMMABLE-BOUNDARY-END(455268034461)
            
            //--TRIMMABLE-BOUNDARY-START(326419015581)
            /*DateTime?*/ LastSeenTime = null;
            //--TRIMMABLE-BOUNDARY-END(326419015581)
            
            //--TRIMMABLE-BOUNDARY-START(330713982877)
            /*DateTime?*/ LastUpdateTime = null;
            //--TRIMMABLE-BOUNDARY-END(330713982877)
            
            //--TRIMMABLE-BOUNDARY-START(85900847005)
            /*string */ FormatDuration(/*int*/ seconds)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900847005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let h = $.trunc(seconds / 3600);
                /*int*/ let m = $.trunc(seconds / 60) % 60;
                /*int*/ let s = seconds % 60;
                if (h > 0)
                {
                    if (m > 0)
                    {
                        return `${$.$strNN(h)}h ${$.$strNN(m)}m`;
                    }
                    return `${$.$strNN(h)}h`;
                }
                else if (m > 0)
                {
                    if (s > 0)
                    {
                        return `${$.$strNN(m)}m ${$.$strNN(s)}s`;
                    }
                    return `${$.$strNN(m)}m`;
                }
                else 
                {
                    return `${$.$strNN(s)}s`;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900847005)
            
            //--TRIMMABLE-BOUNDARY-START(42951174045)
            /*string */ get Ago()
            {
                return $.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(this.LastUpdateTime) ? $.$fPer.LCFCDC.DateTimeExtension.Ago$3(this.LastUpdateTime, $.$$.S.DateTime.UtcNow, 2147483647) : "";
            }
            //--TRIMMABLE-BOUNDARY-END(42951174045)
            
            //--TRIMMABLE-BOUNDARY-START(459563001757)
            /*object? */ get StatusDescriptor()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(459563001757)
            
            //--TRIMMABLE-BOUNDARY-START(390843525021)
            /*IIOTDeviceReceivedDataModel?*/ receivedStatus = null;
            //--TRIMMABLE-BOUNDARY-END(390843525021)
            
            //--TRIMMABLE-BOUNDARY-START(395138492317)
            /*IIOTDeviceReceivedDataModel? */ get ReceivedStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519669661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.receivedStatus;
            }
            /*IIOTDeviceReceivedDataModel? */ set ReceivedStatus(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442383132573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.receivedStatus !== value)
                {
                    this.receivedStatus = value;
                    this.LastSeenTime = this.LastUpdateTime = $.$$.S.DateTime.UtcNow;
                    /*var*/ let pipelines = $.$fPer.LCFCS$3.ServiceFactoryExtensions.Get$1($.$fXpo.LCFCPC.IPipelineCollection$$($.$NXre.LCID.SmartDeviceBase), this.OwnerScope.LCICI$IIOTDeviceScope$Factory.LCICI$IIOTDeviceScopeFactory$Services);
                    _ = (pipelines?.LCFCPC$IPipelineCollection$LivingThing$Core$IOT$Devices$SmartDeviceBase$FeedAsync(this, null) ?? null);
                    this.RaisePropertyChanged$1("ReceivedStatus");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(395138492317)
            
            //--TRIMMABLE-BOUNDARY-START(55836075933)
            /*IEnumerable<IConnectionClient> */ get Clients()
            {
                return $.$sl.SL.Enumerable.ToArray($.$KuVO.LCFCC.IConnectionClient, $.$sl.SL.Enumerable.Where($.$KuVO.LCFCC.IConnectionClient, $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.ClientConnectionIdentity), $.$KuVO.LCFCC.IConnectionClient, this.Interfaces, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.ClientConnectionIdentity), $.$KuVO.LCFCC.IConnectionClient))().$ctor(this,  (/*kv*/ kv) =>
                {
                    return kv.Key.LCFCC$IConnectionInterface$get_Item(kv.Value);
                }, $tTegdk ??= {"r":1568430,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.ClientConnectionIdentity).$h}],"n":"","d":1501085,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$KuVO.LCFCC.IConnectionClient, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c !== null;
                }, $uGTfAe ??= {"r":262145,"p":[{"n":"c","p":1568430}],"n":"","d":1501085,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(55836075933)
            
            //--TRIMMABLE-BOUNDARY-START(60131043229)
            /*bool */ get ConnectedLocally()
            {
                return $.$sl.SL.Enumerable.Any($.$KuVO.LCFCC.IConnectionClient, this.Clients, new ($.$$.S.Func$$$($.$KuVO.LCFCC.IConnectionClient, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return $.$$.S.String.Contains$2.call(c.LCFCC$IConnectionClient$Interface.LCFCC$IConnectionInterface$Name, "Tcp", 3/*StringComparison.InvariantCultureIgnoreCase*/);
                }, $MJALqf ??= {"r":262145,"p":[{"n":"c","p":1568430}],"n":"","d":1501085,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(60131043229)
            
            //--TRIMMABLE-BOUNDARY-START(472447903645)
            /*string */ get UniqueId()
            {
                return this.Model.LCICI$IIOTDeviceModel$UniqueId;
            }
            //--TRIMMABLE-BOUNDARY-END(472447903645)
            
            //--TRIMMABLE-BOUNDARY-START(373663655837)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(373663655837)
            
            //--TRIMMABLE-BOUNDARY-START(373663655837)
            //--TRIMMABLE-BOUNDARY-START(38656206749)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656206749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(38656206749)
            
            //--TRIMMABLE-BOUNDARY-START(408023394205)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408023394205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(408023394205)
            
            //--TRIMMABLE-BOUNDARY-END(373663655837)
            
            //--TRIMMABLE-BOUNDARY-START(377958623133)
            /*ValueTask */ RaisePropertyChanged(/*object?*/ sender, /*params string[]*/ names)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377958623133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i3 = 0;
                let $arr3 = names;
                while ($i3 < $arr3.length)
                {
                    let name = $arr3[$i3++];
                    this.PropertyChanged?.Invoke(sender, new $.$so.SC$1.PropertyChangedEventArgs().$ctor$2(name));
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(377958623133)
            
            //--TRIMMABLE-BOUNDARY-START(386548557725)
            /*void */ RaisePropertyChanged$2(/*params string[]*/ names)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386548557725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.RaisePropertyChanged(this, names);
            }
            //--TRIMMABLE-BOUNDARY-END(386548557725)
            
            //--TRIMMABLE-BOUNDARY-START(382253590429)
            /*void */ RaisePropertyChanged$1(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382253590429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.RaisePropertyChanged(this, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ name ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(382253590429)
            
            //--TRIMMABLE-BOUNDARY-START(446678099869)
            /*Task */ SetRemoteHardwareConfig(/*IIOTDeviceInternalConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446678099869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(446678099869)
            
            //--TRIMMABLE-BOUNDARY-START(412318361501)
            /*Task */ ResetStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412318361501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ReceivedStatus = null;
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(412318361501)
            
            //--TRIMMABLE-BOUNDARY-START(481037838237)
            /*Task */ UpdateStatusFrom(/*IEnumerable<IObservableDataDescriptor>*/ actionData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481037838237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let command = $.$sl.SL.Enumerable.Single($.$fPer.LCFCD$1.IObservableDataDescriptor, actionData, new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IObservableDataDescriptor, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                {
                    return $.$$.S.String.Equals$2.call(a.LCFCD$1$IObservableDataDescriptor$Name, "commandname", 3/*StringComparison.InvariantCultureIgnoreCase*/);
                }, $yTleRf ??= {"r":262145,"p":[{"n":"a","p":40536406}],"n":"","d":1501085,"h":0,"f":17825794}));
                return $.$XBGm.LCIC.IOTDeviceExtension.SendCommand$4(this, $.$dspc(command.LCFCD$IValueProvider$Value, $.$$.S.Object, ($t) => $t.ToString), $.$sl.SL.Enumerable.ToArray($.$fPer.LCFCD$1.IObservableDataDescriptor, $.$sl.SL.Enumerable.Except$1($.$fPer.LCFCD$1.IObservableDataDescriptor, actionData, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD$1.IObservableDataDescriptor), [command], null, null))));
            }
            //--TRIMMABLE-BOUNDARY-END(481037838237)
            
            //--TRIMMABLE-BOUNDARY-START(51541108637)
            /*Task *//*async*/  Clicked()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541108637);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ((this.Family.LCICI$IIOTDeviceFamily$DeviceDescriptor?.ClickCommand ?? null) !== null)
                    {
                        let $t4, $r4;
                        /*var*/ let command = $.$sl.SL.Enumerable.Single($.$XBGm.LCICI.IIOTDeviceProtocolCommand, this.Family.LCICI$IIOTDeviceFamily$Protocol.LCICI$IIOTDeviceProtocol$GetCommands(this.Model), new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                        {
                            return c.LCICI$IIOTDeviceProtocolCommand$Name === this.Family.LCICI$IIOTDeviceFamily$DeviceDescriptor.ClickCommand.Name;
                        }, $SionDi ??= {"r":262145,"p":[{"n":"c","p":27694481}],"n":"","d":1501085,"h":0,"f":17825794}));
                        ($t4 = $.$XBGm.LCIC.IOTDeviceExtension.SendCommand$3(this, command, $.$sl.SL.Enumerable.Select$1($.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor, $.$fPer.LCFCD$1.IObservableDataDescriptor, this.Family.LCICI$IIOTDeviceFamily$DeviceDescriptor.ClickCommand.DataPoints, new ($.$$.S.Func$$$($.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor, $.$fPer.LCFCD$1.IObservableDataDescriptor))().$ctor(this,  (/**/ c) =>
                        {
                            return c.GetObservable($.$fPer.LCFCO.OneOf$$$$($.$$.S.Object, $.$$.S.Func$$($.$$.S.Object), $.$fPer.LCFCD.IValueProvider).op_Implicit($.$cast(command, $.$$.S.Object)), null);
                        }, $NzXiGi ??= {"r":40536406,"p":[{"n":"c","p":36541841}],"n":"","d":1501085,"h":0,"f":17825794}))), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51541108637)
            
            //--TRIMMABLE-BOUNDARY-START(468152936349)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468152936349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN(this.Name)}${$.$strNN((this.Id !== null ? `(${$.$strNN(this.Id)})` : null))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(468152936349)
            
            //--TRIMMABLE-BOUNDARY-START(476742870941)
            /*Task */ UpdateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476742870941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OwnerScope.LCICI$IIOTDeviceScope$UpdateDevice($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDevice), [ this ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(476742870941)
            
            //--TRIMMABLE-BOUNDARY-START(68720977821)
            /*Task */ DeleteAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720977821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OwnerScope.LCICI$IIOTDeviceScope$DeleteDevice($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDevice), [ this ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(68720977821)
            
            //--TRIMMABLE-BOUNDARY-START(47246141341)
            /*Task */ BindToScope(/*IIOTDeviceScope*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246141341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(47246141341)
            
            //--TRIMMABLE-BOUNDARY-START(399433459613)
            /*IIOTDeviceConfigurationProvider? */ get RemoteConfigurationProvider()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(399433459613)
            
            //--TRIMMABLE-BOUNDARY-START(64426010525)
            /*IPluginData */ get Data()
            {
                return this.Model;
            }
            //--TRIMMABLE-BOUNDARY-END(64426010525)
            
            //--TRIMMABLE-BOUNDARY-START(81630303633)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.Id.get
            get LCICI$IIOTDevice$Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184709518737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(81630303633)
            
            //--TRIMMABLE-BOUNDARY-START(176119584145)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.UniqueId.get
            get LCICI$IIOTDevice$UniqueId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240544093585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UniqueId;
            }
            //--TRIMMABLE-BOUNDARY-END(176119584145)
            
            //--TRIMMABLE-BOUNDARY-START(115990042001)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.Name.get
            get LCICI$IIOTDevice$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201889387921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(115990042001)
            
            //--TRIMMABLE-BOUNDARY-START(47270565265)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.Description.get
            get LCICI$IIOTDevice$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21500761489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(47270565265)
            
            //--TRIMMABLE-BOUNDARY-START(64450434449)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.Features.get
            get LCICI$IIOTDevice$Features()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30090696081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Features;
            }
            //--TRIMMABLE-BOUNDARY-END(64450434449)
            
            //--TRIMMABLE-BOUNDARY-START(55860499857)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.Family.get
            get LCICI$IIOTDevice$Family()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25795728785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Family;
            }
            //--TRIMMABLE-BOUNDARY-END(55860499857)
            
            //--TRIMMABLE-BOUNDARY-START(4320892305)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.BindToScope(LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope)
            LCICI$IIOTDevice$BindToScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4320892305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BindToScope(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4320892305)
            
            //--TRIMMABLE-BOUNDARY-START(98810172817)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.IsAvailable.get
            get LCICI$IIOTDevice$IsAvailable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193299453329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsAvailable;
            }
            //--TRIMMABLE-BOUNDARY-END(98810172817)
            
            //--TRIMMABLE-BOUNDARY-START(73040369041)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.Icon.get
            get LCICI$IIOTDevice$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180414551441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(73040369041)
            
            //--TRIMMABLE-BOUNDARY-START(90220238225)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.Image.get
            get LCICI$IIOTDevice$Image()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(189004486033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Image;
            }
            //--TRIMMABLE-BOUNDARY-END(90220238225)
            
            //--TRIMMABLE-BOUNDARY-START(219069257105)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.ResetStatus()
            LCICI$IIOTDevice$ResetStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219069257105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ResetStatus(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(219069257105)
            
            //--TRIMMABLE-BOUNDARY-START(8615859601)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.Clicked()
            LCICI$IIOTDevice$Clicked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8615859601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clicked(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8615859601)
            
            //--TRIMMABLE-BOUNDARY-START(227659191697)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.SetStatus(bool)
            LCICI$IIOTDevice$SetStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227659191697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetStatus(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(227659191697)
            
            //--TRIMMABLE-BOUNDARY-START(244839060881)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.UpdateAsync()
            LCICI$IIOTDevice$UpdateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244839060881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UpdateAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(244839060881)
            
            //--TRIMMABLE-BOUNDARY-START(17205794193)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.DeleteAsync()
            LCICI$IIOTDevice$DeleteAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17205794193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DeleteAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17205794193)
            
            //--TRIMMABLE-BOUNDARY-START(167529649553)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.StatusText.get
            get LCICI$IIOTDevice$StatusText()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236249126289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StatusText;
            }
            //--TRIMMABLE-BOUNDARY-END(167529649553)
            
            //--TRIMMABLE-BOUNDARY-START(107400107409)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.Model.get
            get LCICI$IIOTDevice$Model()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197594420625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Model;
            }
            //--TRIMMABLE-BOUNDARY-END(107400107409)
            
            //--TRIMMABLE-BOUNDARY-START(158939714961)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.Settings.get
            get LCICI$IIOTDevice$Settings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231954158993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Settings;
            }
            //--TRIMMABLE-BOUNDARY-END(158939714961)
            
            //--TRIMMABLE-BOUNDARY-START(38680630673)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.Clients.get
            get LCICI$IIOTDevice$Clients()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12910826897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clients;
            }
            //--TRIMMABLE-BOUNDARY-END(38680630673)
            
            //--TRIMMABLE-BOUNDARY-START(133169911185)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.ReceivedStatus.get
            get LCICI$IIOTDevice$ReceivedStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210479322513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReceivedStatus;
            }
            //--TRIMMABLE-BOUNDARY-END(133169911185)
            
            //--TRIMMABLE-BOUNDARY-START(141759845777)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDevice.RemoteConfigurationProvider.get
            get LCICI$IIOTDevice$RemoteConfigurationProvider()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214774289809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoteConfigurationProvider;
            }
            //--TRIMMABLE-BOUNDARY-END(141759845777)
            
            //--TRIMMABLE-BOUNDARY-START(12905974102)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IPlugin.Data.get
            get LCFCD$IPlugin$Data()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4316039510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Data;
            }
            //--TRIMMABLE-BOUNDARY-END(12905974102)
            
            //--TRIMMABLE-BOUNDARY-START(8615597457)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTAutomate.StatusDescriptor.get
            get LCICI$IIOTAutomate$StatusDescriptor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12910564753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StatusDescriptor;
            }
            //--TRIMMABLE-BOUNDARY-END(8615597457)
            
            //--TRIMMABLE-BOUNDARY-START(17205532049)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTAutomate.UpdateStatusFrom(System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor>)
            LCICI$IIOTAutomate$UpdateStatusFrom()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17205532049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UpdateStatusFrom(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17205532049)
            
            //--TRIMMABLE-BOUNDARY-START(4299524438)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.INotifyOnPropertyChanged.RaisePropertyChanged(object?, params string[])
            LCFCC$INotifyOnPropertyChanged$RaisePropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299524438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RaisePropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4299524438)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(416613328797)
                this.Scopes = new ($.$$.SCG.List$$($.$XBGm.LCICI.IIOTDeviceScope))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(416613328797)
                
                //--TRIMMABLE-BOUNDARY-START(317829080989)
                this.Interfaces = new ($.$$.SCG.Dictionary$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.ClientConnectionIdentity))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(317829080989)
                
                //--TRIMMABLE-BOUNDARY-START(326419015581)
                this.LastSeenTime = null;
                //--TRIMMABLE-BOUNDARY-END(326419015581)
                
                //--TRIMMABLE-BOUNDARY-START(330713982877)
                this.LastUpdateTime = null;
                //--TRIMMABLE-BOUNDARY-END(330713982877)
                
            }
            static $h = 1501085;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(416613328797),
    {
      "p": $.$$.SCG.List$$($.$XBGm.LCICI.IIOTDeviceScope).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257699538845,
        "f": 50331656
      },
      "n": "Scopes",
      "d": 1501085,
      "h": 416613328797,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(416613328797),
//--TRIMMABLE-BOUNDARY-START(369368688541),
    {
      "p": 28546449,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231929735069,
        "f": 50331649
      },
      "n": "OwnerScope",
      "d": 1501085,
      "h": 369368688541,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(369368688541),
//--TRIMMABLE-BOUNDARY-START(77310912413),
    {
      "p": 26711441,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440454557,
        "f": 50331649
      },
      "n": "Family",
      "d": 1501085,
      "h": 77310912413,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310912413),
//--TRIMMABLE-BOUNDARY-START(81605879709),
    {
      "p": 29922705,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030389149,
        "f": 50331777
      },
      "n": "Features",
      "d": 1501085,
      "h": 81605879709,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(81605879709),
//--TRIMMABLE-BOUNDARY-START(352188819357),
    {
      "p": 28546449,
      "g": {
        "r": 0,
        "d": 0,
        "h": 339303917469,
        "f": 50331650
      },
      "n": "{25925009}.OwnerScope",
      "o": "LCICI$IIOTDevice$OwnerScope",
      "d": 1501085,
      "h": 352188819357,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(352188819357),
//--TRIMMABLE-BOUNDARY-START(356483786653),
    {
      "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceScope).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 347893852061,
        "f": 50331650
      },
      "n": "{25925009}.Scopes",
      "o": "LCICI$IIOTDevice$Scopes",
      "d": 1501085,
      "h": 356483786653,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(356483786653),
//--TRIMMABLE-BOUNDARY-START(309239146397),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163210258333,
        "f": 50331649
      },
      "n": "Id",
      "d": 1501085,
      "h": 309239146397,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309239146397),
//--TRIMMABLE-BOUNDARY-START(365073721245),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223339800477,
        "f": 50331649
      },
      "n": "Name",
      "d": 1501085,
      "h": 365073721245,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(365073721245),
//--TRIMMABLE-BOUNDARY-START(317829080989),
    {
      "p": $.$$.SCG.Dictionary$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.ClientConnectionIdentity).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180390127517,
        "f": 50331649
      },
      "n": "Interfaces",
      "d": 1501085,
      "h": 317829080989,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(317829080989),
//--TRIMMABLE-BOUNDARY-START(73015945117),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850519965,
        "f": 50331777
      },
      "n": "Description",
      "d": 1501085,
      "h": 73015945117,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(73015945117),
//--TRIMMABLE-BOUNDARY-START(304944179101),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154620323741,
        "f": 50331777
      },
      "n": "Icon",
      "d": 1501085,
      "h": 304944179101,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(304944179101),
//--TRIMMABLE-BOUNDARY-START(313534113693),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171800192925,
        "f": 50331777
      },
      "n": "Image",
      "d": 1501085,
      "h": 313534113693,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(313534113693),
//--TRIMMABLE-BOUNDARY-START(322124048285),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188980062109,
        "f": 50331777
      },
      "n": "IsAvailable",
      "d": 1501085,
      "h": 322124048285,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(322124048285),
//--TRIMMABLE-BOUNDARY-START(463857969053),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283469342621,
        "f": 50331777
      },
      "n": "StatusText",
      "d": 1501085,
      "h": 463857969053,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(463857969053),
//--TRIMMABLE-BOUNDARY-START(360778753949),
    {
      "p": 27432337,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214749865885,
        "f": 50331649
      },
      "n": "Model",
      "d": 1501085,
      "h": 360778753949,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(360778753949),
//--TRIMMABLE-BOUNDARY-START(455268034461),
    {
      "p": 28808593,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266289473437,
        "f": 50331649
      },
      "n": "Settings",
      "d": 1501085,
      "h": 455268034461,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(455268034461),
//--TRIMMABLE-BOUNDARY-START(326419015581),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197569996701,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 425203263389,
        "f": 83886081
      },
      "n": "LastSeenTime",
      "d": 1501085,
      "h": 326419015581,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(326419015581),
//--TRIMMABLE-BOUNDARY-START(330713982877),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206159931293,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 433793197981,
        "f": 83886081
      },
      "n": "LastUpdateTime",
      "d": 1501085,
      "h": 330713982877,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(330713982877),
//--TRIMMABLE-BOUNDARY-START(42951174045),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490781597,
        "f": 50331649
      },
      "n": "Ago",
      "d": 1501085,
      "h": 42951174045,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951174045),
//--TRIMMABLE-BOUNDARY-START(459563001757),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274879408029,
        "f": 50331777
      },
      "n": "StatusDescriptor",
      "d": 1501085,
      "h": 459563001757,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(459563001757),
//--TRIMMABLE-BOUNDARY-START(395138492317),
    {
      "p": 28415377,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240519669661,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 442383132573,
        "f": 83886209
      },
      "n": "ReceivedStatus",
      "d": 1501085,
      "h": 395138492317,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(395138492317),
//--TRIMMABLE-BOUNDARY-START(55836075933),
    {
      "p": $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionClient).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080716189,
        "f": 50331649
      },
      "n": "Clients",
      "d": 1501085,
      "h": 55836075933,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836075933),
//--TRIMMABLE-BOUNDARY-START(60131043229),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670650781,
        "f": 50331649
      },
      "n": "ConnectedLocally",
      "d": 1501085,
      "h": 60131043229,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131043229),
//--TRIMMABLE-BOUNDARY-START(472447903645),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 292059277213,
        "f": 50331649
      },
      "n": "UniqueId",
      "d": 1501085,
      "h": 472447903645,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(472447903645),
//--TRIMMABLE-BOUNDARY-START(399433459613),
    {
      "p": 26056081,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249109604253,
        "f": 50331777
      },
      "n": "RemoteConfigurationProvider",
      "d": 1501085,
      "h": 399433459613,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(399433459613),
//--TRIMMABLE-BOUNDARY-START(64426010525),
    {
      "p": 21137750,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260585373,
        "f": 50331649
      },
      "n": "Data",
      "d": 1501085,
      "h": 64426010525,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426010525)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(296354244509),
    {
      "r": 27432337,
      "n": "GetModel",
      "d": 1501085,
      "h": 296354244509,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(296354244509),
//--TRIMMABLE-BOUNDARY-START(300649211805),
    {
      "r": 28808593,
      "n": "GetSettings",
      "d": 1501085,
      "h": 300649211805,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(300649211805),
//--TRIMMABLE-BOUNDARY-START(85900847005),
    {
      "r": 1310721,
      "p": [
        {
          "n": "seconds",
          "p": 655361
        }
      ],
      "n": "FormatDuration",
      "d": 1501085,
      "h": 85900847005,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85900847005),
//--TRIMMABLE-BOUNDARY-START(377958623133),
    {
      "r": 181338113,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "names",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "RaisePropertyChanged",
      "d": 1501085,
      "h": 377958623133,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(377958623133),
//--TRIMMABLE-BOUNDARY-START(386548557725),
    {
      "r": 65537,
      "p": [
        {
          "n": "names",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "RaisePropertyChanged",
      "o": "@$2",
      "d": 1501085,
      "h": 386548557725,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(386548557725),
//--TRIMMABLE-BOUNDARY-START(382253590429),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721,
          "f": 65,
          "v": "",
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "RaisePropertyChanged",
      "o": "@$1",
      "d": 1501085,
      "h": 382253590429,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(382253590429),
//--TRIMMABLE-BOUNDARY-START(450973067165),
    {
      "r": 65537,
      "p": [
        {
          "n": "enable",
          "p": 262145
        }
      ],
      "n": "SetStatus",
      "d": 1501085,
      "h": 450973067165,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(450973067165),
//--TRIMMABLE-BOUNDARY-START(446678099869),
    {
      "r": 178454529,
      "p": [
        {
          "n": "configuration",
          "p": 27170193
        }
      ],
      "n": "SetRemoteHardwareConfig",
      "d": 1501085,
      "h": 446678099869,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(446678099869),
//--TRIMMABLE-BOUNDARY-START(412318361501),
    {
      "r": 178454529,
      "n": "ResetStatus",
      "d": 1501085,
      "h": 412318361501,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(412318361501),
//--TRIMMABLE-BOUNDARY-START(481037838237),
    {
      "r": 178454529,
      "p": [
        {
          "n": "actionData",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor).$h
        }
      ],
      "n": "UpdateStatusFrom",
      "d": 1501085,
      "h": 481037838237,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(481037838237),
//--TRIMMABLE-BOUNDARY-START(51541108637),
    {
      "r": 178454529,
      "n": "Clicked",
      "d": 1501085,
      "h": 51541108637,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(51541108637),
//--TRIMMABLE-BOUNDARY-START(468152936349),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1501085,
      "h": 468152936349,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(468152936349),
//--TRIMMABLE-BOUNDARY-START(476742870941),
    {
      "r": 178454529,
      "n": "UpdateAsync",
      "d": 1501085,
      "h": 476742870941,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(476742870941),
//--TRIMMABLE-BOUNDARY-START(68720977821),
    {
      "r": 178454529,
      "n": "DeleteAsync",
      "d": 1501085,
      "h": 68720977821,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720977821),
//--TRIMMABLE-BOUNDARY-START(47246141341),
    {
      "r": 178454529,
      "p": [
        {
          "n": "scope",
          "p": 28546449
        }
      ],
      "n": "BindToScope",
      "d": 1501085,
      "h": 47246141341,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(47246141341)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(390843525021),
    {
      "t": 28415377,
      "n": "receivedStatus",
      "d": 1501085,
      "h": 390843525021,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(390843525021)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066272157),
    {
      "p": [
        {
          "n": "family",
          "p": 26711441
        },
        {
          "n": "ownerScope",
          "p": 28546449
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1501085,
      "h": 30066272157,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066272157)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(373663655837),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 1501085,
        "h": 38656206749,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 1501085,
        "h": 408023394205,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 1501085,
      "h": 373663655837,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(373663655837)
  ],
  "h": 1501085
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartDeviceBase`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartDeviceBase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1501085)
        
        

        //--TRIMMABLE-BOUNDARY-START(1697693)
        $asm.$cls(`$NXre.LCID.SmartGenericDeviceDefinition<,,,,,,,,,,,,,,,,,,,,>`, (TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings) => $asm.$gt(`$NXre.LCID.SmartGenericDeviceDefinition<,,,,,,,,,,,,,,,,,,,,>`, [TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings], ($self) => class SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(1828765)
            static $_ConfiguredServerDeviceFamily;
            static get ConfiguredServerDeviceFamily()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1828765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings);
                return $cls.$_ConfiguredServerDeviceFamily ??= $asm.$ncls(`$NXre.LCID.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>.ConfiguredServerDeviceFamily`, ($self) => class ConfiguredServerDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).ConfiguredDeviceFamily
                {
                    //--TRIMMABLE-BOUNDARY-START(4296796061)
                    $ctor$3(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<TDeviceReceivedDataModel, TDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<TDeviceReceivedDataModel, TDeviceStatusModel>*/ converter)
                    {
                        super.$ctor$1(config, protocol, converter);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296796061);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296796061)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591763357)
                    $ctor$4(/*IOTDeviceDescriptor<TServiceTierType, TServiceFeatureType>*/ descriptor, /*IOTDeviceProtocol<TDeviceReceivedDataModel, TDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<TDeviceReceivedDataModel, TDeviceStatusModel>*/ converter)
                    {
                        super.$ctor$2(descriptor, protocol, converter);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8591763357);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591763357)
                    
                    static $H = 1828765;
                    static $h = 1828765;
                    static $f = 0b10000000001110001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).ConfiguredDeviceFamily; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296796061),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$(TDeviceReceivedDataModel, TDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$(TDeviceReceivedDataModel, TDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1828765,
      "H": 4296796061,
      "h": Number(BigInt(1828765)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296796061),
//--TRIMMABLE-BOUNDARY-START(8591763357),
    {
      "p": [
        {
          "n": "descriptor",
          "p": $.$XBGm.LCICM.IOTDeviceDescriptor$$$(TServiceTierType, TServiceFeatureType).$h
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$(TDeviceReceivedDataModel, TDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$(TDeviceReceivedDataModel, TDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1828765,
      "H": 8591763357,
      "h": Number(BigInt(1828765)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8591763357)
  ],
  "d": 1697693,
  "H": 1828765,
  "h": 1828765
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$(TSmartDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$(TSmartDevice, TServiceTierType, TServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$(TServiceTierType, TServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$XBGm.LCICI.IIOTServerDeviceFamily ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>+ConfiguredServerDeviceFamily`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TDeviceScopeModel?.$getFullName(separator)}$${TDeviceScopeSettings?.$getFullName(separator)}$${TDeviceScopeStates?.$getFullName(separator)}$${TDeviceModel?.$getFullName(separator)}$${TDeviceSettings?.$getFullName(separator)}$${TDeviceHardwareSettings?.$getFullName(separator)}$${TDeviceStates?.$getFullName(separator)}$${TDeviceStatusModel?.$getFullName(separator)}$${TDeviceCommandModel?.$getFullName(separator)}$${TDeviceReceivedDataModel?.$getFullName(separator)}$${TDeviceSendDataModel?.$getFullName(separator)}$${TDeviceStatusHandler?.$getFullName(separator)}$${TServiceHubClient?.$getFullName(separator)}$${TServicesRemoteService?.$getFullName(separator)}$${TDeviceGlobalSettings?.$getFullName(separator)}$${separator}ConfiguredServerDeviceFamily`; }
                }, $cls, ($v) => $cls.$_ConfiguredServerDeviceFamily = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1828765)
            
            //--TRIMMABLE-BOUNDARY-START(1894301)
            static $_IOTDeviceModelDefinition;
            static get IOTDeviceModelDefinition()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1894301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings);
                return $cls.$_IOTDeviceModelDefinition ??= $asm.$ncls(`$NXre.LCID.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>.IOTDeviceModelDefinition`, ($self) => class IOTDeviceModelDefinition extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$(TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService)
                {
                    //--TRIMMABLE-BOUNDARY-START(4296861597)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296861597);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296861597)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296861597)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296861597)
                    
                    static $H = 1894301;
                    static $h = 1894301;
                    static $f = 0b10000000001010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$(TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService); }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296861597),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1894301,
      "H": 4296861597,
      "h": Number(BigInt(1894301)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296861597)
  ],
  "d": 1697693,
  "H": 1894301,
  "h": 1894301
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>+IOTDeviceModelDefinition`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TDeviceScopeModel?.$getFullName(separator)}$${TDeviceScopeSettings?.$getFullName(separator)}$${TDeviceScopeStates?.$getFullName(separator)}$${TDeviceModel?.$getFullName(separator)}$${TDeviceSettings?.$getFullName(separator)}$${TDeviceHardwareSettings?.$getFullName(separator)}$${TDeviceStates?.$getFullName(separator)}$${TDeviceStatusModel?.$getFullName(separator)}$${TDeviceCommandModel?.$getFullName(separator)}$${TDeviceReceivedDataModel?.$getFullName(separator)}$${TDeviceSendDataModel?.$getFullName(separator)}$${TDeviceStatusHandler?.$getFullName(separator)}$${TServiceHubClient?.$getFullName(separator)}$${TServicesRemoteService?.$getFullName(separator)}$${TDeviceGlobalSettings?.$getFullName(separator)}$${separator}IOTDeviceModelDefinition`; }
                }, $cls, ($v) => $cls.$_IOTDeviceModelDefinition = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1894301)
            
            //--TRIMMABLE-BOUNDARY-START(2025373)
            static $_SmartGenericDeviceFamily;
            static get SmartGenericDeviceFamily()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2025373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings);
                return $cls.$_SmartGenericDeviceFamily ??= $asm.$ncls(`$NXre.LCID.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>.SmartGenericDeviceFamily`, ($self) => class SmartGenericDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).ConfiguredDeviceFamily
                {
                    //--TRIMMABLE-BOUNDARY-START(4296992669)
                    $ctor$3(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<TDeviceReceivedDataModel, TDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<TDeviceReceivedDataModel, TDeviceStatusModel>*/ converter)
                    {
                        super.$ctor$1(config, protocol, converter);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296992669);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296992669)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476861853)
                    /*Type[] */ get PromotionTypes()
                    {
                        return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [], [-1], null);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476861853)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181894557)
                    /*Task */ Promote(/*IIOTDevice*/ device, /*Type*/ familyType)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181894557);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        ($.$cast(device.LCICI$IIOTDevice$Model, $.$XBGm.LCICM.IOTDeviceModel)).Family = $.$$.S.String.Replace$3.call(familyType.Name, "Family", "");
                        return device.LCICI$IIOTDevice$UpdateAsync();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181894557)
                    
                    //--TRIMMABLE-BOUNDARY-START(8620250513)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IPromotableDeviceFamily.PromotionTypes.get
                    get LCICI$IPromotableDeviceFamily$PromotionTypes()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17210185105);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.PromotionTypes;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8620250513)
                    
                    //--TRIMMABLE-BOUNDARY-START(12915217809)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IPromotableDeviceFamily.Promote(LivingThing.Core.IOT.Common.Interface.IIOTDevice, System.Type)
                    LCICI$IPromotableDeviceFamily$Promote()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12915217809);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Promote(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12915217809)
                    
                    static $H = 2025373;
                    static $h = 2025373;
                    static $f = 0b10000000001010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).ConfiguredDeviceFamily; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476861853),
    {
      "p": $.$typeArray($.$$.S.Type).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 12886927261,
        "h": Number(BigInt(2025373)|0x300000000n),
        "f": 50331649
      },
      "n": "PromotionTypes",
      "d": 2025373,
      "H": 21476861853,
      "h": Number(BigInt(2025373)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476861853)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181894557),
    {
      "r": 178454529,
      "p": [
        {
          "n": "device",
          "p": 25925009
        },
        {
          "n": "familyType",
          "p": 188547073
        }
      ],
      "n": "Promote",
      "d": 2025373,
      "H": 17181894557,
      "h": Number(BigInt(2025373)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181894557)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296992669),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$(TDeviceReceivedDataModel, TDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$(TDeviceReceivedDataModel, TDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2025373,
      "H": 4296992669,
      "h": Number(BigInt(2025373)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296992669)
  ],
  "d": 1697693,
  "H": 2025373,
  "h": 2025373
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$(TSmartDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$(TSmartDevice, TServiceTierType, TServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$(TServiceTierType, TServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$XBGm.LCICI.IPromotableDeviceFamily ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>+SmartGenericDeviceFamily`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TDeviceScopeModel?.$getFullName(separator)}$${TDeviceScopeSettings?.$getFullName(separator)}$${TDeviceScopeStates?.$getFullName(separator)}$${TDeviceModel?.$getFullName(separator)}$${TDeviceSettings?.$getFullName(separator)}$${TDeviceHardwareSettings?.$getFullName(separator)}$${TDeviceStates?.$getFullName(separator)}$${TDeviceStatusModel?.$getFullName(separator)}$${TDeviceCommandModel?.$getFullName(separator)}$${TDeviceReceivedDataModel?.$getFullName(separator)}$${TDeviceSendDataModel?.$getFullName(separator)}$${TDeviceStatusHandler?.$getFullName(separator)}$${TServiceHubClient?.$getFullName(separator)}$${TServicesRemoteService?.$getFullName(separator)}$${TDeviceGlobalSettings?.$getFullName(separator)}$${separator}SmartGenericDeviceFamily`; }
                }, $cls, ($v) => $cls.$_SmartGenericDeviceFamily = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2025373)
            
            //--TRIMMABLE-BOUNDARY-START(2287517)
            static $_SmartGenericServerDeviceScopeFactory;
            static get SmartGenericServerDeviceScopeFactory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2287517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings);
                return $cls.$_SmartGenericServerDeviceScopeFactory ??= $asm.$ncls(`$NXre.LCID.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>.SmartGenericServerDeviceScopeFactory`, ($self) => class SmartGenericServerDeviceScopeFactory extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDeviceScopeFactory
                {
                    //--TRIMMABLE-BOUNDARY-START(17182156701)
                    $ctor$2(/*ServiceFactory*/ services, /*IConfigurationParser*/ config, /*IScopeStore*/ scopeStore, /*IDeviceStore*/ deviceStore, /*IEnumerable<IIOTDeviceFamily<TSmartDevice>>*/ families, /*IServerRemoteService*/ serverRemoteService, /*IHubConnector<TServiceHubClient>?*/ hubConnector)
                    {
                        super.$ctor$1(services, config, scopeStore, deviceStore);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17182156701);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Families = families;
                            this.ServerRemoteService = serverRemoteService;
                            let client;
                            if (hubConnector !== null && $.$is(this, TServiceHubClient, { set $v($v){ client = $v; } }))
                            {
                                this.hub = hubConnector.LCFCH$IHubConnector$$$Subscribe(client);
                            }
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182156701)
                    
                    //--TRIMMABLE-BOUNDARY-START(120261371805)
                    /*IDisposable?*/ hub = null;
                    //--TRIMMABLE-BOUNDARY-END(120261371805)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951960477)
                    /*ScopeFactoryFeatures */ get Features()
                    {
                        return 4/*ScopeFactoryFeatures.CanScanScope*/;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42951960477)
                    
                    //--TRIMMABLE-BOUNDARY-START(146031175581)
                    /*IServerRemoteService*/ ServerRemoteService = null;
                    //--TRIMMABLE-BOUNDARY-END(146031175581)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656993181)
                    /*IEnumerable<IIOTDeviceFamily<TSmartDevice>>*/ Families = null;
                    //--TRIMMABLE-BOUNDARY-END(38656993181)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067058589)
                    /*IEnumerable<IIOTDeviceFamily> */ get DeviceFamilies()
                    {
                        return $.$$.N.InterfaceVarianceStubHandler.Create(this.Families, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily$$(TSmartDevice)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily));
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067058589)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477123997)
                    /*string? */ get DashboardLink()
                    {
                        return null;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477123997)
                    
                    //--TRIMMABLE-BOUNDARY-START(124556339101)
                    /*string */ get Icon()
                    {
                        return ($.$sl.SL.Enumerable.First$1($.$XBGm.LCICI.IIOTDeviceFamily$$(TSmartDevice), this.Families)?.LCFC$IDisplayable$Icon.Icon ?? null) ?? super.Icon;
                    }
                    //--TRIMMABLE-BOUNDARY-END(124556339101)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772091293)
                    /*string */ get Description()
                    {
                        return ($.$sl.SL.Enumerable.First$1($.$XBGm.LCICI.IIOTDeviceFamily$$(TSmartDevice), this.Families).LCICI$IIOTDeviceFamily$DeviceDescriptor?.Description$1 ?? null) ?? super.Description;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772091293)
                    
                    //--TRIMMABLE-BOUNDARY-START(133146273693)
                    /*Task */ Ping(/*object*/ id)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(133146273693);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let device = $.$as($.$sl.SL.Enumerable.SingleOrDefault$1($.$XBGm.LCICI.IIOTDevice, this.Devices, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDevice, $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                        {
                            return $.$$.S.String.Equals$5.call($.$dspc(d.LCICI$IIOTDevice$Model.LCFCD$IIded$Identifier.Id, $.$$.S.Object, ($t) => $t.ToString), $.$dsp(id, $.$$.S.Object, ($t) => $t.ToString)) || $.$$.S.String.Equals$5.call(d.LCICI$IIOTDevice$Model.LCICI$IIOTDeviceModel$UniqueId, $.$dsp(id, $.$$.S.Object, ($t) => $t.ToString));
                        }, $GYLSHi ??= {"r":262145,"p":[{"n":"d","p":25925009}],"n":"","d":2287517,"H":0,"h":0,"f":17825794})), $.$NXre.LCID.SmartDeviceBase);
                        if (device !== null)
                        {
                            device.LastSeenTime = $.$$.S.DateTime.UtcNow;
                        }
                        return $.$$.STT.Task.CompletedTask;
                    }
                    //--TRIMMABLE-BOUNDARY-END(133146273693)
                    
                    //--TRIMMABLE-BOUNDARY-START(137441240989)
                    /*Task */ Pong(/*object*/ id)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(137441240989);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let device = $.$as($.$sl.SL.Enumerable.SingleOrDefault$1($.$XBGm.LCICI.IIOTDevice, this.Devices, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDevice, $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                        {
                            return $.$$.S.String.Equals$5.call($.$dspc(d.LCICI$IIOTDevice$Model.LCFCD$IIded$Identifier.Id, $.$$.S.Object, ($t) => $t.ToString), $.$dsp(id, $.$$.S.Object, ($t) => $t.ToString));
                        }, $nrntDd ??= {"r":262145,"p":[{"n":"d","p":25925009}],"n":"","d":2287517,"H":0,"h":0,"f":17825794})), $.$NXre.LCID.SmartDeviceBase);
                        if (device !== null)
                        {
                        }
                        return $.$$.STT.Task.CompletedTask;
                    }
                    //--TRIMMABLE-BOUNDARY-END(137441240989)
                    
                    //--TRIMMABLE-BOUNDARY-START(141736208285)
                    /*Task *//*async*/  Scan(/*Action<IIOTDeviceScope>*/ found)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(141736208285);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let server = null;
                            try
                            {
                                let $t1, $r1;
                                server = this.ServerRemoteService.LCFCR$IServerRemoteService$GetRemoteService(TServicesRemoteService, null);
                                /*var*/ let services = ($t1 = $.$dsp(server.LCFCS$3$IServiceProxy$$$Service, TServicesRemoteService, ($t) => $t[`LCFCCR$ISubscriptionBasedRemoteService$${TServiceModel.$getFullName('$')}$LoadServices`], new $.$fPer.LCFCD.DataFilter().$ctor$22("iot", null, new $.$fPer.LCFCD.CompositeDataId(), null, null, null, null, null, new $.$fPer.LCFCD.Sorting(), null)).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                                if (services.Success)
                                {
                                    let $en2 = services.Data.SCG$IEnumerable$$$GetEnumerator();
                                    while ($en2.SC$1$IEnumerator$MoveNext())
                                    {
                                        let dash = $en2.SCG$IEnumerator$$$Current;
                                        {
                                            /*List<TDeviceModel>*/ let scopedDevices = new ($.$$.SCG.List$$(TDeviceModel))().$ctor$1();
                                            if (dash.Service.Scopes !== null)
                                            {
                                                let $en3 = dash.Service.Scopes.SCG$IEnumerable$$$GetEnumerator();
                                                while ($en3.SC$1$IEnumerator$MoveNext())
                                                {
                                                    let scp = $en3.SCG$IEnumerator$$$Current;
                                                    {
                                                        scp.RemoteId = scp.Identifier;
                                                        /*var*/ let devices = $.$sl.SL.Enumerable.Where(TDeviceModel, $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCD.DataId, TDeviceModel, scp.Devices, new ($.$$.S.Func$$$($.$fPer.LCFCD.DataId, TDeviceModel))().$ctor(this,  (/*id*/ id) =>
                                                        {
                                                            return $.$sl.SL.Enumerable.SingleOrDefault$1(TDeviceModel, dash.Service.Devices, new ($.$$.S.Func$$$(TDeviceModel, $.$$.S.Boolean))().$ctor(this,  (/*dev*/ dev) =>
                                                            {
                                                                return $.$dspc(dev.Identifier.Id, $.$$.S.Object, ($t) => $t.Equals$1, id.Id);
                                                            }, $arILWk ??= {"r":262145,"p":[{"n":"dev","p":TDeviceModel?.$h??2162688}],"n":"","d":2287517,"H":0,"h":0,"f":17825794}));
                                                        }, $lSXhod ??= {"r":TDeviceModel?.$h??2162688,"p":[{"n":"id","p":10455382}],"n":"","d":2287517,"H":0,"h":0,"f":17825794})), new ($.$$.S.Func$$$(TDeviceModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                                                        {
                                                            return t !== null;
                                                        }, $djUcrh ??= {"r":262145,"p":[{"n":"t","p":TDeviceModel?.$h??2162688}],"n":"","d":2287517,"H":0,"h":0,"f":17825794}));
                                                        let $en4 = devices.SCG$IEnumerable$$$GetEnumerator();
                                                        while ($en4.SC$1$IEnumerator$MoveNext())
                                                        {
                                                            let device = $en4.SCG$IEnumerator$$$Current;
                                                            {
                                                                device.Family ??= ($.$sl.SL.Enumerable.FirstOrDefault$3($.$XBGm.LCICI.IIOTDeviceFamily$$(TSmartDevice), this.Families)?.LCFC$INamed$Name ?? null);
                                                                device.RemoteId = device.Identifier;
                                                            }
                                                        }
                                                        /*var*/ let scope = this.GetScope(scp, devices);
                                                        found.Invoke(scope);
                                                        scopedDevices.AddRange(devices);
                                                    }
                                                }
                                            }
                                            /*var*/ let unScopedDevices = $.$sl.SL.Enumerable.Except$1(TDeviceModel, dash.Service.Devices, scopedDevices);
                                            if ($.$sl.SL.Enumerable.Any$1(TDeviceModel, unScopedDevices))
                                            {
                                                let $t6, $r6;
                                                /*var*/ let scope = this.GetScope((() =>
                                                {
                                                    //new TDeviceScopeModel()
                                                    const $t5 = TDeviceScopeModel.$isProxy === true ? TDeviceScopeModel.$prototype : TDeviceScopeModel;
                                                    const $i5 = new $t5();
                                                    $i5.$ctor$8();
                                                    $i5.Name = ($.$sl.SL.Enumerable.FirstOrDefault$3($.$XBGm.LCICI.IIOTDeviceFamily$$(TSmartDevice), this.Families)?.LCFC$INamed$Name ?? null) ?? "Uncategorized";
                                                    return $i5;
                                                })(), unScopedDevices);
                                                ($t6 = scope.EnsureLoaded(), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                                found.Invoke(scope);
                                            }
                                        }
                                    }
                                }
                                else 
                                {
                                    if (services.Message === "Not Authorized")
                                    {
                                        throw new $.$fPer.LCFCE.NoAuthenticationException().$ctor$8(services.Message);
                                    }
                                    throw new $.$$.S.Exception().$ctor$4(services.Message);
                                }
                            }
                            finally
                            {
                                server?.S$IDisposable$Dispose();
                            }
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(141736208285)
                    
                    //--TRIMMABLE-BOUNDARY-START(150326142877)
                    /*Task *//*async*/  UpdateDevice(/*IIOTDeviceScope*/ scope, /*params IIOTDevice[]*/ devices)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t7, $r7;
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(150326142877);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            ($t7 = super.UpdateDevice(scope, devices).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                            let $i8 = 0;
                            let $arr8 = devices;
                            while ($i8 < $arr8.length)
                            {
                                let device = $arr8[$i8++];
                                if (!device.LCICI$IIOTDevice$Model.LCICI$IIOTDeviceModel$RemoteId.Empty)
                                {
                                    let server = null;
                                    try
                                    {
                                        let $t9, $r9;
                                        server = this.ServerRemoteService.LCFCR$IServerRemoteService$GetRemoteService($.$vWqU.LCFCCR.ICoreRemoteService, null);
                                        /*var*/ let model = $.$cast(device.LCICI$IIOTDevice$Model, $.$Iaui.LCFCM.DataModel);
                                        ($t9 = server.LCFCS$3$IServiceProxy$$$Service.LCFCCR$ICoreRemoteService$UpdateData((() =>
                                        {
                                            //new $.$Iaui.LCFCM.UpdateRequestModel()
                                            const $t10 = $.$Iaui.LCFCM.UpdateRequestModel;
                                            const $i10 = new $t10();
                                            $i10.$ctor$2();
                                            $i10.Target = device.LCICI$IIOTDevice$Model.LCICI$IIOTDeviceModel$RemoteId;
                                            $i10.Properties = $.$fPer.LCFCS$1.Serialized.op_Implicit$1($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$Iaui.LCFCM.DataModel, model, true, false, true, false, false, false, false, "UpdateDevice", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices\\SmartGenericServerDeviceScopeFactory.cs", "UpdateDevice", 175));
                                            return $i10;
                                        })()), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                                    }
                                    finally
                                    {
                                        server?.S$IDisposable$Dispose();
                                    }
                                }
                            }
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(150326142877)
                    
                    //--TRIMMABLE-BOUNDARY-START(154621110173)
                    /*Task *//*async*/  UpdateScope(/*params IIOTDeviceScope[]*/ scopes)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t11, $r11;
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(154621110173);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            ($t11 = super.UpdateScope(scopes).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                            let $i12 = 0;
                            let $arr12 = scopes;
                            while ($i12 < $arr12.length)
                            {
                                let scope = $arr12[$i12++];
                                let server = null;
                                try
                                {
                                    let $t13, $r13;
                                    server = this.ServerRemoteService.LCFCR$IServerRemoteService$GetRemoteService($.$vWqU.LCFCCR.ICoreRemoteService, null);
                                    /*var*/ let model = $.$cast(scope.LCICI$IIOTDeviceScope$Model, TDeviceScopeModel);
                                    ($t13 = server.LCFCS$3$IServiceProxy$$$Service.LCFCCR$ICoreRemoteService$UpdateData((() =>
                                    {
                                        //new $.$Iaui.LCFCM.UpdateRequestModel()
                                        const $t14 = $.$Iaui.LCFCM.UpdateRequestModel;
                                        const $i14 = new $t14();
                                        $i14.$ctor$2();
                                        $i14.Target = model.Identifier;
                                        $i14.Properties = $.$fPer.LCFCS$1.Serialized.op_Implicit$1($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize(TDeviceScopeModel, model, true, false, true, false, false, false, false, "UpdateScope", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices\\SmartGenericServerDeviceScopeFactory.cs", "UpdateScope", 193));
                                        return $i14;
                                    })()), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                                }
                                finally
                                {
                                    server?.S$IDisposable$Dispose();
                                }
                            }
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(154621110173)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297254813)
                    /*IEnumerable<TServiceModel>?*/ _services = null;
                    //--TRIMMABLE-BOUNDARY-END(4297254813)
                    
                    //--TRIMMABLE-BOUNDARY-START(115966404509)
                    /*Task<IEnumerable<TServiceModel>> *//*async*/  GetServices()
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$(TServiceModel)), $.$$.SCG.IEnumerable$$(TServiceModel), async ($asnycContext) => 
                        {
                            let $t15, $r15;
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(115966404509);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            /*var*/ let loggedIn = ($t15 = $.$fPer.LCFCS$3.ServiceFactoryExtensions.GetRequired$1($.$GfYa.LCFCA.IAuthenticationService, this.Services).LCFCA$IReadOnlyAuthenticationService$GetIsLoggedIn(), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                            if (!loggedIn)
                            {
                                return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Empty(TServiceModel));
                            }
                            if (this._services !== null)
                            {
                                return $.$$.N.AsyncResolver.Result($asnycContext, this._services);
                            }
                            let server = null;
                            try
                            {
                                let $t16, $r16;
                                server = this.ServerRemoteService.LCFCR$IServerRemoteService$GetRemoteService(TServicesRemoteService, null);
                                /*var*/ let services = ($t16 = $.$dsp(server.LCFCS$3$IServiceProxy$$$Service, TServicesRemoteService, ($t) => $t[`LCFCCR$ISubscriptionBasedRemoteService$${TServiceModel.$getFullName('$')}$LoadServices`], new $.$fPer.LCFCD.DataFilter().$ctor$1()).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)));
                                if (services.Success)
                                {
                                    return $.$$.N.AsyncResolver.Result($asnycContext, this._services = $.$sl.SL.Enumerable.Select$1($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TServiceModel), TServiceModel, services.Data, new ($.$$.S.Func$$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TServiceModel), TServiceModel))().$ctor(this,  (/*s*/ s) =>
                                    {
                                        return s.Service;
                                    }, $PLHjYk ??= {"r":TServiceModel?.$h??1638400,"p":[{"n":"s","p":$.$Iaui.LCFCM.UserServiceSubscriptionModel$$(TServiceModel).$h}],"n":"","d":2287517,"H":0,"h":0,"f":17825794})));
                                }
                                return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Empty(TServiceModel));
                            }
                            finally
                            {
                                server?.S$IDisposable$Dispose();
                            }
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(115966404509)
                    
                    //--TRIMMABLE-BOUNDARY-START(111671437213)
                    /*ValueTask<IEnumerable<TDeviceScopeModel>> *//*async*/  GetScopes()
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TDeviceScopeModel)), $.$$.SCG.IEnumerable$$(TDeviceScopeModel), async ($asnycContext) => 
                        {
                            let $t17, $r17;
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(111671437213);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            /*var*/ let services = ($t17 = this.GetServices(), ($.$$.N.AsyncResolver.IsCompleted($t17, { set $v($v) { $r17 = $v; } }) ? $r17 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t17)));
                            return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.SelectMany$2(TServiceModel, TDeviceScopeModel, services, new ($.$$.S.Func$$$(TServiceModel, $.$$.SCG.IEnumerable$$(TDeviceScopeModel)))().$ctor(this,  (/*service*/ service) =>
                            {
                                return service.Scopes ?? $.$sl.SL.Enumerable.Empty(TDeviceScopeModel);
                            }, $YYMvli ??= {"r":$.$$.SCG.IEnumerable$$(TDeviceScopeModel).$h,"p":[{"n":"service","p":TServiceModel?.$h??1638400}],"n":"","d":2287517,"H":0,"h":0,"f":17825794})));
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(111671437213)
                    
                    //--TRIMMABLE-BOUNDARY-START(107376469917)
                    /*ValueTask<IEnumerable<TDeviceModel>> *//*async*/  GetDevices(/*TDeviceScopeModel*/ scope)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TDeviceModel)), $.$$.SCG.IEnumerable$$(TDeviceModel), async ($asnycContext) => 
                        {
                            let $t18, $r18;
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(107376469917);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            /*var*/ let services = ($t18 = this.GetServices(), ($.$$.N.AsyncResolver.IsCompleted($t18, { set $v($v) { $r18 = $v; } }) ? $r18 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t18)));
                            /*var*/ let service = $.$sl.SL.Enumerable.Single(TServiceModel, services, new ($.$$.S.Func$$$(TServiceModel, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                            {
                                /*System.Collections.Generic.IEnumerable<TDeviceScopeModel>?*/ let __ca1__;
                                return ((__ca1__ = s.Scopes) !== null ? $.$sl.SL.Enumerable.Contains$1(TDeviceScopeModel, __ca1__, scope) : false);
                            }, $IhOhYc ??= {"r":262145,"p":[{"n":"s","p":TServiceModel?.$h??1638400}],"n":"","d":2287517,"H":0,"h":0,"f":17825794}));
                            return $.$$.N.AsyncResolver.Result($asnycContext, $.$dsp(service, TServiceModel, ($t) => $t.GetDevices, scope.Devices ?? $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD.DataId)) ?? $.$sl.SL.Enumerable.Empty(TDeviceModel));
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(107376469917)
                    
                    //--TRIMMABLE-BOUNDARY-START(128851306397)
                    /*Task<IEnumerable<IIOTDeviceScope>> *//*async*/  LoadScopesAsync()
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceScope)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceScope), async ($asnycContext) => 
                        {
                            let $t19, $r19;
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(128851306397);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            /*var*/ let services = ($t19 = this.GetServices(), ($.$$.N.AsyncResolver.IsCompleted($t19, { set $v($v) { $r19 = $v; } }) ? $r19 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t19)));
                            /*List<IIOTDeviceScope>*/ let scopes = new ($.$$.SCG.List$$($.$XBGm.LCICI.IIOTDeviceScope))().$ctor$1();
                            let $en20 = services.SCG$IEnumerable$$$GetEnumerator();
                            while ($en20.SC$1$IEnumerator$MoveNext())
                            {
                                let service = $en20.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let singletonScope = this.GetScope$1(service);
                                    if (singletonScope === null)
                                    {
                                        let $t21, $r21;
                                        return $.$$.N.AsyncResolver.Result($asnycContext, ($t21 = super.LoadScopesAsync(), ($.$$.N.AsyncResolver.IsCompleted($t21, { set $v($v) { $r21 = $v; } }) ? $r21 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t21))));
                                    }
                                    scopes.Add(singletonScope);
                                }
                            }
                            return $.$$.N.AsyncResolver.Result($asnycContext, scopes);
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(128851306397)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362025885)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34362025885);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.hub?.S$IDisposable$Dispose();
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362025885)
                    
                    //--TRIMMABLE-BOUNDARY-START(4319778193)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Hubs.IIOTDeviceHubClientBase.Ping(object)
                    LCICH$IIOTDeviceHubClientBase$Ping()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4319778193);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Ping(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4319778193)
                    
                    //--TRIMMABLE-BOUNDARY-START(8614745489)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Hubs.IIOTDeviceHubClientBase.Pong(object)
                    LCICH$IIOTDeviceHubClientBase$Pong()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8614745489);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Pong(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8614745489)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    static $H = 2287517;
                    static $h = 2287517;
                    static $f = 0b10000000001110001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDeviceScopeFactory; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951960477),
    {
      "p": 30643601,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85901633437,
        "h": Number(BigInt(2287517)|0x1400000000n),
        "f": 50364417
      },
      "n": "Features",
      "d": 2287517,
      "H": 42951960477,
      "h": Number(BigInt(2287517)|0xA00000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42951960477),
//--TRIMMABLE-BOUNDARY-START(146031175581),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "H": 103081502621,
        "h": Number(BigInt(2287517)|0x1800000000n),
        "f": 50331652
      },
      "n": "ServerRemoteService",
      "d": 2287517,
      "H": 146031175581,
      "h": Number(BigInt(2287517)|0x2200000000n),
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(146031175581),
//--TRIMMABLE-BOUNDARY-START(38656993181),
    {
      "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily$$(TSmartDevice)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77311698845,
        "h": Number(BigInt(2287517)|0x1200000000n),
        "f": 50331649
      },
      "n": "Families",
      "d": 2287517,
      "H": 38656993181,
      "h": Number(BigInt(2287517)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656993181),
//--TRIMMABLE-BOUNDARY-START(30067058589),
    {
      "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68721764253,
        "h": Number(BigInt(2287517)|0x1000000000n),
        "f": 50364417
      },
      "n": "DeviceFamilies",
      "d": 2287517,
      "H": 30067058589,
      "h": Number(BigInt(2287517)|0x700000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30067058589),
//--TRIMMABLE-BOUNDARY-START(21477123997),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51541895069,
        "h": Number(BigInt(2287517)|0xC00000000n),
        "f": 50331777
      },
      "n": "DashboardLink",
      "d": 2287517,
      "H": 21477123997,
      "h": Number(BigInt(2287517)|0x500000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(21477123997),
//--TRIMMABLE-BOUNDARY-START(124556339101),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 94491568029,
        "h": Number(BigInt(2287517)|0x1600000000n),
        "f": 50364417
      },
      "n": "Icon",
      "d": 2287517,
      "H": 124556339101,
      "h": Number(BigInt(2287517)|0x1D00000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(124556339101),
//--TRIMMABLE-BOUNDARY-START(25772091293),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60131829661,
        "h": Number(BigInt(2287517)|0xE00000000n),
        "f": 50364417
      },
      "n": "Description",
      "d": 2287517,
      "H": 25772091293,
      "h": Number(BigInt(2287517)|0x600000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25772091293)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(133146273693),
    {
      "r": 178454529,
      "p": [
        {
          "n": "id",
          "p": 131073
        }
      ],
      "n": "Ping",
      "d": 2287517,
      "H": 133146273693,
      "h": Number(BigInt(2287517)|0x1F00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133146273693),
//--TRIMMABLE-BOUNDARY-START(137441240989),
    {
      "r": 178454529,
      "p": [
        {
          "n": "id",
          "p": 131073
        }
      ],
      "n": "Pong",
      "d": 2287517,
      "H": 137441240989,
      "h": Number(BigInt(2287517)|0x2000000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137441240989),
//--TRIMMABLE-BOUNDARY-START(141736208285),
    {
      "r": 178454529,
      "p": [
        {
          "n": "found",
          "p": $.$$.S.Action$$($.$XBGm.LCICI.IIOTDeviceScope).$h
        }
      ],
      "n": "Scan",
      "d": 2287517,
      "H": 141736208285,
      "h": Number(BigInt(2287517)|0x2100000000n),
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(141736208285),
//--TRIMMABLE-BOUNDARY-START(150326142877),
    {
      "r": 178454529,
      "p": [
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "devices",
          "p": $.$typeArray($.$XBGm.LCICI.IIOTDevice).$h,
          "f": 16
        }
      ],
      "n": "UpdateDevice",
      "d": 2287517,
      "H": 150326142877,
      "h": Number(BigInt(2287517)|0x2300000000n),
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(150326142877),
//--TRIMMABLE-BOUNDARY-START(154621110173),
    {
      "r": 178454529,
      "p": [
        {
          "n": "scopes",
          "p": $.$typeArray($.$XBGm.LCICI.IIOTDeviceScope).$h,
          "f": 16
        }
      ],
      "n": "UpdateScope",
      "d": 2287517,
      "H": 154621110173,
      "h": Number(BigInt(2287517)|0x2400000000n),
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(154621110173),
//--TRIMMABLE-BOUNDARY-START(115966404509),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$(TServiceModel)).$h,
      "n": "GetServices",
      "d": 2287517,
      "H": 115966404509,
      "h": Number(BigInt(2287517)|0x1B00000000n),
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(115966404509),
//--TRIMMABLE-BOUNDARY-START(111671437213),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TDeviceScopeModel)).$h,
      "n": "GetScopes",
      "d": 2287517,
      "H": 111671437213,
      "h": Number(BigInt(2287517)|0x1A00000000n),
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(111671437213),
//--TRIMMABLE-BOUNDARY-START(107376469917),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TDeviceModel)).$h,
      "p": [
        {
          "n": "scope",
          "p": TDeviceScopeModel?.$h??1966080
        }
      ],
      "n": "GetDevices",
      "d": 2287517,
      "H": 107376469917,
      "h": Number(BigInt(2287517)|0x1900000000n),
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(107376469917),
//--TRIMMABLE-BOUNDARY-START(128851306397),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceScope)).$h,
      "n": "LoadScopesAsync",
      "d": 2287517,
      "H": 128851306397,
      "h": Number(BigInt(2287517)|0x1E00000000n),
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(128851306397),
//--TRIMMABLE-BOUNDARY-START(34362025885),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2287517,
      "H": 34362025885,
      "h": Number(BigInt(2287517)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362025885)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(120261371805),
    {
      "t": 91095041,
      "n": "hub",
      "d": 2287517,
      "H": 120261371805,
      "h": Number(BigInt(2287517)|0x1C00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(120261371805),
//--TRIMMABLE-BOUNDARY-START(4297254813),
    {
      "t": $.$$.SCG.IEnumerable$$(TServiceModel).$h,
      "n": "_services",
      "d": 2287517,
      "H": 4297254813,
      "h": Number(BigInt(2287517)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297254813)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182156701),
    {
      "p": [
        {
          "n": "services",
          "p": 62949718
        },
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "scopeStore",
          "p": 1545617
        },
        {
          "n": "deviceStore",
          "p": 1283473
        },
        {
          "n": "families",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily$$(TSmartDevice)).$h
        },
        {
          "n": "serverRemoteService",
          "p": 1309651
        },
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$(TServiceHubClient).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2287517,
      "H": 17182156701,
      "h": Number(BigInt(2287517)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182156701)
  ],
  "d": 1697693,
  "H": 2287517,
  "h": 2287517
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient, $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>+SmartGenericServerDeviceScopeFactory`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TDeviceScopeModel?.$getFullName(separator)}$${TDeviceScopeSettings?.$getFullName(separator)}$${TDeviceScopeStates?.$getFullName(separator)}$${TDeviceModel?.$getFullName(separator)}$${TDeviceSettings?.$getFullName(separator)}$${TDeviceHardwareSettings?.$getFullName(separator)}$${TDeviceStates?.$getFullName(separator)}$${TDeviceStatusModel?.$getFullName(separator)}$${TDeviceCommandModel?.$getFullName(separator)}$${TDeviceReceivedDataModel?.$getFullName(separator)}$${TDeviceSendDataModel?.$getFullName(separator)}$${TDeviceStatusHandler?.$getFullName(separator)}$${TServiceHubClient?.$getFullName(separator)}$${TServicesRemoteService?.$getFullName(separator)}$${TDeviceGlobalSettings?.$getFullName(separator)}$${separator}SmartGenericServerDeviceScopeFactory`; }
                }, $cls, ($v) => $cls.$_SmartGenericServerDeviceScopeFactory = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2287517)
            
            //--TRIMMABLE-BOUNDARY-START(1959837)
            static $_SmartGenericDevice;
            static get SmartGenericDevice()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1959837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings);
                return $cls.$_SmartGenericDevice ??= $asm.$ncls(`$NXre.LCID.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>.SmartGenericDevice`, ($self) => class SmartGenericDevice extends $.$NXre.LCID.SmartDeviceBase
                {
                    //--TRIMMABLE-BOUNDARY-START(21476796317)
                    $ctor$2(/*IIOTDeviceFamily<TSmartDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*TDeviceModel*/ model)
                    {
                        super.$ctor$1(family, ownerScope);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21476796317);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Family$1 = $.$firstOf(family, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("family") });
                            this.Model$1 = $.$firstOf(model, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("model") });
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476796317)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771763613)
                    /*IIOTDeviceFamily<TSmartDevice>*/ $Family$1 = null;
                    /*IIOTDeviceFamily<TSmartDevice> */ get Family$1()
                    {
                        return this.$Family$1;
                    }
                     /*IIOTDeviceFamily<TSmartDevice> */ set Family$1(value)
                    {
                        this.$Family$1 = value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771763613)
                    
                    //--TRIMMABLE-BOUNDARY-START(107376142237)
                    /*IIOTDeviceReceivedDataModel? */ get ReceivedStatus()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60131501981);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return super.ReceivedStatus;
                    }
                    /*IIOTDeviceReceivedDataModel? */ set ReceivedStatus(value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(133145946013);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.Received = $.$cast(value, TDeviceReceivedDataModel);
                        if (super.ReceivedStatus !== value)
                        {
                            super.ReceivedStatus = value;
                            if (value !== null)
                            {
                                /*var*/ let _status = ($.$cast(this.Family$1.LCICI$IIOTDeviceFamily$Converter, $.$XBGm.LCICI.IIOTDeviceDataConverter$$$(TDeviceReceivedDataModel, TDeviceStatusModel)))[`LCFCD$IDataConverters$${TDeviceReceivedDataModel.$getFullName('$')}$${TDeviceStatusModel.$getFullName('$')}$Convert`]($.$cast(value, TDeviceReceivedDataModel), $.$box(this.Model$1, TDeviceModel));
                                if (_status !== null)
                                {
                                    this.Model$1.Status = _status;
                                    /*System.Collections.Generic.IEnumerable<TDeviceStatusModel>?*/ let __ca1__;
                                    this.Model$1.Statuses = $.$sl.SL.Enumerable.ToArray(TDeviceStatusModel, $.$sl.SL.Enumerable.TakeLast(TDeviceStatusModel, (((__ca1__ = this.Model$1.Statuses) !== null ? ($.$sl.SL.Enumerable.Concat(TDeviceStatusModel, __ca1__, $.$$.SRC.RuntimeHelpers.CreateArray(TDeviceStatusModel.$type, [ _status ], null, null)) ?? $.$$.SRC.RuntimeHelpers.CreateArray(TDeviceStatusModel.$type, [ _status ], null, null)) : $.$$.SRC.RuntimeHelpers.CreateArray(TDeviceStatusModel.$type, [ _status ], null, null))), 64));
                                }
                                this.Model$1.Online = true;
                                this.Status = _status;
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(107376142237)
                    
                    //--TRIMMABLE-BOUNDARY-START(103081174941)
                    /*TDeviceReceivedDataModel?*/ $Received = null;
                    /*TDeviceReceivedDataModel? */ get Received()
                    {
                        return this.$Received;
                    }
                    /*TDeviceReceivedDataModel? */ set Received(value)
                    {
                        this.$Received = value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(103081174941)
                    
                    //--TRIMMABLE-BOUNDARY-START(154620782493)
                    /*TDeviceStatusModel?*/ Status = null;
                    //--TRIMMABLE-BOUNDARY-END(154620782493)
                    
                    //--TRIMMABLE-BOUNDARY-START(98786207645)
                    /*TDeviceModel*/ Model$1 = $.$default(TDeviceModel);
                    //--TRIMMABLE-BOUNDARY-END(98786207645)
                    
                    //--TRIMMABLE-BOUNDARY-START(150325815197)
                    /*TDeviceSettings */ get Settings$1()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68721436573);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.Model$1.Settings ??= new TDeviceSettings().$gctor();
                        return this.Model$1.Settings;
                    }
                    //--TRIMMABLE-BOUNDARY-END(150325815197)
                    
                    //--TRIMMABLE-BOUNDARY-START(90196273053)
                    /*IIOTDeviceModel */ GetModel()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(90196273053);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$box(this.Model$1 ?? new TDeviceModel().$gctor(), TDeviceModel);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(90196273053)
                    
                    //--TRIMMABLE-BOUNDARY-START(94491240349)
                    /*IIOTDeviceSettings */ GetSettings()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(94491240349);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$box(this.Settings$1, TDeviceSettings);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(94491240349)
                    
                    //--TRIMMABLE-BOUNDARY-START(158915749789)
                    /*object? */ get StatusDescriptor()
                    {
                        return TDeviceStatusModel.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(158915749789)
                    
                    //--TRIMMABLE-BOUNDARY-START(146030847901)
                    /*void */ SetStatus(/*bool*/ enable)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(146030847901);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(146030847901)
                    
                    static $H = 1959837;
                    static $h = 1959837;
                    static $f = 0b10000000001110001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$NXre.LCID.SmartDeviceBase; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771763613),
    {
      "p": $.$XBGm.LCICI.IIOTDeviceFamily$$(TSmartDevice).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34361698205,
        "h": Number(BigInt(1959837)|0x800000000n),
        "f": 50331777
      },
      "n": "Family",
      "o": "@$1",
      "d": 1959837,
      "H": 25771763613,
      "h": Number(BigInt(1959837)|0x600000000n),
      "f": 538968193
    },
//--TRIMMABLE-BOUNDARY-END(25771763613),
//--TRIMMABLE-BOUNDARY-START(107376142237),
    {
      "p": 28415377,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60131501981,
        "h": Number(BigInt(1959837)|0xE00000000n),
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 133145946013,
        "h": Number(BigInt(1959837)|0x1F00000000n),
        "f": 83918849
      },
      "n": "ReceivedStatus",
      "d": 1959837,
      "H": 107376142237,
      "h": Number(BigInt(1959837)|0x1900000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(107376142237),
//--TRIMMABLE-BOUNDARY-START(103081174941),
    {
      "p": TDeviceReceivedDataModel?.$h??2555904,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51541567389,
        "h": Number(BigInt(1959837)|0xC00000000n),
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 124556011421,
        "h": Number(BigInt(1959837)|0x1D00000000n),
        "f": 83886209
      },
      "n": "Received",
      "d": 1959837,
      "H": 103081174941,
      "h": Number(BigInt(1959837)|0x1800000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(103081174941),
//--TRIMMABLE-BOUNDARY-START(154620782493),
    {
      "p": TDeviceStatusModel?.$h??2424832,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77311371165,
        "h": Number(BigInt(1959837)|0x1200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 141735880605,
        "h": Number(BigInt(1959837)|0x2100000000n),
        "f": 83886081
      },
      "n": "Status",
      "d": 1959837,
      "H": 154620782493,
      "h": Number(BigInt(1959837)|0x2400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154620782493),
//--TRIMMABLE-BOUNDARY-START(98786207645),
    {
      "p": TDeviceModel?.$h??2162688,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42951632797,
        "h": Number(BigInt(1959837)|0xA00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 115966076829,
        "h": Number(BigInt(1959837)|0x1B00000000n),
        "f": 83886082
      },
      "n": "Model",
      "o": "@$1",
      "d": 1959837,
      "H": 98786207645,
      "h": Number(BigInt(1959837)|0x1700000000n),
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(98786207645),
//--TRIMMABLE-BOUNDARY-START(150325815197),
    {
      "p": TDeviceSettings?.$h??2228224,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68721436573,
        "h": Number(BigInt(1959837)|0x1000000000n),
        "f": 50331649
      },
      "n": "Settings",
      "o": "@$1",
      "d": 1959837,
      "H": 150325815197,
      "h": Number(BigInt(1959837)|0x2300000000n),
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(150325815197),
//--TRIMMABLE-BOUNDARY-START(158915749789),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85901305757,
        "h": Number(BigInt(1959837)|0x1400000000n),
        "f": 50364417
      },
      "n": "StatusDescriptor",
      "d": 1959837,
      "H": 158915749789,
      "h": Number(BigInt(1959837)|0x2500000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158915749789)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90196273053),
    {
      "r": 27432337,
      "n": "GetModel",
      "d": 1959837,
      "H": 90196273053,
      "h": Number(BigInt(1959837)|0x1500000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90196273053),
//--TRIMMABLE-BOUNDARY-START(94491240349),
    {
      "r": 28808593,
      "n": "GetSettings",
      "d": 1959837,
      "H": 94491240349,
      "h": Number(BigInt(1959837)|0x1600000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94491240349),
//--TRIMMABLE-BOUNDARY-START(146030847901),
    {
      "r": 65537,
      "p": [
        {
          "n": "enable",
          "p": 262145
        }
      ],
      "n": "SetStatus",
      "d": 1959837,
      "H": 146030847901,
      "h": Number(BigInt(1959837)|0x2200000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146030847901)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476796317),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$(TSmartDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": TDeviceModel?.$h??2162688
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1959837,
      "H": 21476796317,
      "h": Number(BigInt(1959837)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476796317)
  ],
  "d": 1697693,
  "H": 1959837,
  "h": 1959837
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>+SmartGenericDevice`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TDeviceScopeModel?.$getFullName(separator)}$${TDeviceScopeSettings?.$getFullName(separator)}$${TDeviceScopeStates?.$getFullName(separator)}$${TDeviceModel?.$getFullName(separator)}$${TDeviceSettings?.$getFullName(separator)}$${TDeviceHardwareSettings?.$getFullName(separator)}$${TDeviceStates?.$getFullName(separator)}$${TDeviceStatusModel?.$getFullName(separator)}$${TDeviceCommandModel?.$getFullName(separator)}$${TDeviceReceivedDataModel?.$getFullName(separator)}$${TDeviceSendDataModel?.$getFullName(separator)}$${TDeviceStatusHandler?.$getFullName(separator)}$${TServiceHubClient?.$getFullName(separator)}$${TServicesRemoteService?.$getFullName(separator)}$${TDeviceGlobalSettings?.$getFullName(separator)}$${separator}SmartGenericDevice`; }
                }, $cls, ($v) => $cls.$_SmartGenericDevice = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1959837)
            
            //--TRIMMABLE-BOUNDARY-START(2156445)
            static $_SmartGenericDeviceScopeFactory;
            static get SmartGenericDeviceScopeFactory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2156445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings);
                return $cls.$_SmartGenericDeviceScopeFactory ??= $asm.$ncls(`$NXre.LCID.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>.SmartGenericDeviceScopeFactory`, ($self) => class SmartGenericDeviceScopeFactory extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(30066927517)
                    $ctor$1(/*ServiceFactory*/ services, /*IConfigurationParser*/ config, /*IScopeStore*/ scopeStore, /*IDeviceStore*/ deviceStore)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30066927517);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Services = services;
                            this.Configuration = config;
                            this.ScopeStore = scopeStore;
                            this.DeviceStore = deviceStore;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066927517)
                    
                    //--TRIMMABLE-BOUNDARY-START(304944834461)
                    /*ServiceFactory*/ Services = null;
                    //--TRIMMABLE-BOUNDARY-END(304944834461)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246796701)
                    /*IConfigurationParser*/ Configuration = null;
                    //--TRIMMABLE-BOUNDARY-END(47246796701)
                    
                    //--TRIMMABLE-BOUNDARY-START(300649867165)
                    /*IScopeStore*/ ScopeStore = null;
                    //--TRIMMABLE-BOUNDARY-END(300649867165)
                    
                    //--TRIMMABLE-BOUNDARY-START(85901502365)
                    /*IDeviceStore*/ DeviceStore = null;
                    //--TRIMMABLE-BOUNDARY-END(85901502365)
                    
                    //--TRIMMABLE-BOUNDARY-START(266290128797)
                    /*string */ get Name()
                    {
                        return $.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.Object.GetType.call(this).Name, "Scope", ""), "Factory", ""), "Dashboard", "");
                    }
                    //--TRIMMABLE-BOUNDARY-END(266290128797)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426665885)
                    /*string */ get Description()
                    {
                        return ($.$sl.SL.Enumerable.FirstOrDefault$3($.$XBGm.LCICI.IIOTDeviceFamily, this.DeviceFamilies)?.LCFC$IDescribable$Description ?? null) ?? "";
                    }
                    //--TRIMMABLE-BOUNDARY-END(64426665885)
                    
                    //--TRIMMABLE-BOUNDARY-START(240520325021)
                    /*string */ get Icon()
                    {
                        return ($.$sl.SL.Enumerable.FirstOrDefault$3($.$XBGm.LCICI.IIOTDeviceFamily, this.DeviceFamilies)?.LCFC$IDisplayable$Icon.Icon ?? null) ?? "mdi mdi-group"/*MaterialDesignIconNames.Group*/;
                    }
                    //--TRIMMABLE-BOUNDARY-END(240520325021)
                    
                    //--TRIMMABLE-BOUNDARY-START(257700194205)
                    /*bool*/ loaded = false;
                    //--TRIMMABLE-BOUNDARY-END(257700194205)
                    
                    //--TRIMMABLE-BOUNDARY-START(90196469661)
                    /*Task *//*async*/  EnsureLoaded()
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t22, $r22;
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(90196469661);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            ($t22 = $.$fPer.LCFC.LockExtensions.LockAsync(this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                            {
                                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                                {
                                    if (!this.loaded)
                                    {
                                        let $t23, $r23;
                                        /*var*/ let _scopes = ($t23 = this.LoadScopesAsync(), ($.$$.N.AsyncResolver.IsCompleted($t23, { set $v($v) { $r23 = $v; } }) ? $r23 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t23)));
                                        this.Scopes.Add(_scopes);
                                        this.loaded = true;
                                    }
                                });
                            }, $SDzaPe ??= {"r":178454529,"n":"","d":2156445,"H":0,"h":0,"f":17829890}), null, true), ($.$$.N.AsyncResolver.IsCompleted($t22, { set $v($v) { $r22 = $v; } }) ? $r22 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t22)));
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(90196469661)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592091037)
                    /*ReactiveObservableCollection<IIOTDeviceScope>?*/ _scopes = null;
                    //--TRIMMABLE-BOUNDARY-END(8592091037)
                    
                    //--TRIMMABLE-BOUNDARY-START(296354899869)
                    /*ReactiveObservableCollection<IIOTDeviceScope> */ get Scopes()
                    {
                        return this._scopes ??= (() =>
                        {
                            //new $.$fPer.LCFCR.ReactiveObservableCollection$$($.$XBGm.LCICI.IIOTDeviceScope)()
                            const $t24 = $.$fPer.LCFCR.ReactiveObservableCollection$$($.$XBGm.LCICI.IIOTDeviceScope);
                            const $i24 = new $t24();
                            $i24.$ctor$6();
                            $i24.Name = "Scope." + $.$strNN(this.Name);
                            return $i24;
                        })();
                    }
                    //--TRIMMABLE-BOUNDARY-END(296354899869)
                    
                    //--TRIMMABLE-BOUNDARY-START(244815292317)
                    /*string */ get Image()
                    {
                        return $.$NXre.LCID.Utility.ResolvePath(`~/${$.$strNN($.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.Object.GetType.call(this).Name, "Dashboard", ""), "Scope", ""), "Factory", ""))}/img/banner.jpg`, this);
                    }
                    //--TRIMMABLE-BOUNDARY-END(244815292317)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951829405)
                    /*Task *//*async*/  ClearScopes()
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(42951829405);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let $en25 = this.Scopes.SCG$IEnumerable$$$GetEnumerator();
                            while ($en25.SC$1$IEnumerator$MoveNext())
                            {
                                let scope = $en25.SCG$IEnumerator$$$Current;
                                {
                                    let $t26, $r26;
                                    let $t27, $r27;
                                    ($t26 = scope.LCICI$IIOTDeviceScope$ClearDevices().ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t26, { set $v($v) { $r26 = $v; } }) ? $r26 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t26)));
                                    ($t27 = this.ScopeStore.LCICD$ISmartDataStoreT$$$DeleteAsync(scope.LCICI$IIOTDeviceScope$Model).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t27, { set $v($v) { $r27 = $v; } }) ? $r27 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t27)));
                                }
                            }
                            this.Scopes.Clear();
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(42951829405)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297123741)
                    /*ReactiveObservableCollection<IIOTDevice>?*/ _devices = null;
                    //--TRIMMABLE-BOUNDARY-END(4297123741)
                    
                    //--TRIMMABLE-BOUNDARY-START(81606535069)
                    /*ReactiveObservableCollection<IIOTDevice> */ get Devices()
                    {
                        return this._devices ??= this.Scopes.SelectMany($.$XBGm.LCICI.IIOTDevice, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDeviceScope, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice)))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.LCICI$IIOTDeviceScope$Devices;
                        }, $MefNHj ??= {"r":$.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice).$h,"p":[{"n":"s","p":28546449}],"n":"","d":2156445,"H":0,"h":0,"f":17825794}));
                    }
                    //--TRIMMABLE-BOUNDARY-END(81606535069)
                    
                    //--TRIMMABLE-BOUNDARY-START(68721633181)
                    /*IEnumerable<IOTDeviceDescriptor>?*/ descriptors = null;
                    //--TRIMMABLE-BOUNDARY-END(68721633181)
                    
                    //--TRIMMABLE-BOUNDARY-START(73016600477)
                    /*IEnumerable<IOTDeviceDescriptor> */ get Descriptors()
                    {
                        return this.descriptors ??= $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.IDictionary$$$($.$$.S.String, $.$XBGm.LCICM.IOTDeviceDescriptor), $.$XBGm.LCICM.IOTDeviceDescriptor, this.Configuration.LCFCC$1$IConfigurationParser$GetValue($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.SCG.IDictionary$$$($.$$.S.String, $.$XBGm.LCICM.IOTDeviceDescriptor)), "DeviceFamilies", null).SCG$IDictionary$$$$Values, new ($.$$.S.Func$$$($.$$.SCG.IDictionary$$$($.$$.S.String, $.$XBGm.LCICM.IOTDeviceDescriptor), $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceDescriptor)))().$ctor(this,  (/*v*/ v) =>
                        {
                            return v.SCG$IDictionary$$$$Values;
                        }, $Sgwnxg ??= {"r":$.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceDescriptor).$h,"p":[{"n":"v","p":$.$$.SCG.IDictionary$$$($.$$.S.String, $.$XBGm.LCICM.IOTDeviceDescriptor).$h}],"n":"","d":2156445,"H":0,"h":0,"f":17825794}));
                    }
                    //--TRIMMABLE-BOUNDARY-END(73016600477)
                    
                    //--TRIMMABLE-BOUNDARY-START(227635423133)
                    /*SmartGenericDeviceScope? */ GetScope$1(/*TServiceModel*/ service)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(227635423133);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return null;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(227635423133)
                    
                    //--TRIMMABLE-BOUNDARY-START(249110259613)
                    /*IIOTDeviceScope */ LCICI$IIOTDeviceScopeFactory$GetScope(/*IIOTDeviceScopeModel*/ scope)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(249110259613);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (scope.LCFCD$IIded$Identifier.Empty)
                        {
                            return this.GetScope($.$XBGm.LCIC.UtilityExtension.Convert$3(TDeviceScopeModel, scope), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(TDeviceModel), [], [-1], null));
                        }
                        return this.GetScope($.$firstOf(this.ScopeStore.LCICD$ISmartDataStoreT$$$GetByIdAsync(TDeviceScopeModel, scope.LCFCD$IIded$Identifier).Result, () => { throw new $.$$.S.InvalidOperationException().$ctor$9() }), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(TDeviceModel), [], [-1], null));
                    }
                    //--TRIMMABLE-BOUNDARY-END(249110259613)
                    
                    //--TRIMMABLE-BOUNDARY-START(94491436957)
                    /*ScopeFactoryFeatures */ get Features()
                    {
                        return 0/*ScopeFactoryFeatures.None*/;
                    }
                    //--TRIMMABLE-BOUNDARY-END(94491436957)
                    
                    //--TRIMMABLE-BOUNDARY-START(51541763997)
                    /*Task<IIOTDeviceScope> *//*async*/  CreateScope(/*IIOTDeviceScopeModel*/ scope, /*IIOTDeviceModel[]*/ devices, /*bool*/ persist)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$XBGm.LCICI.IIOTDeviceScope), $.$XBGm.LCICI.IIOTDeviceScope, async ($asnycContext) => 
                        {
                            let $t30, $r30;
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(51541763997);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$fPer.LCFCP$1.PropertyExtension.SetValue(scope, "FullName", $.$$.S.Object.GetType.call(this).FullName);
                            if (persist)
                            {
                                let $t28, $r28;
                                let $t29, $r29;
                                ($t28 = this.ScopeStore.LCICD$ISmartDataStoreT$$$SaveAsync(scope).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t28, { set $v($v) { $r28 = $v; } }) ? $r28 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t28)));
                                ($t29 = this.ScopeStore.LCICD$IScopeStore$AddDevices(scope, devices), ($.$$.N.AsyncResolver.IsCompleted($t29, { set $v($v) { $r29 = $v; } }) ? $r29 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t29)));
                            }
                            /*var*/ let _scope = persist ? ($.$firstOf(($t30 = this.ScopeStore.LCICD$ISmartDataStoreT$$$GetByIdAsync(TDeviceScopeModel, scope.LCFCD$IIded$Identifier), ($.$$.N.AsyncResolver.IsCompleted($t30, { set $v($v) { $r30 = $v; } }) ? $r30 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t30))), () => { throw new $.$$.S.InvalidOperationException().$ctor$9() })) : $.$cast(scope, TDeviceScopeModel);
                            /*IIOTDeviceScope*/ let result;
                            if (persist)
                            {
                                /*List<TDeviceModel>*/ let _devices = new ($.$$.SCG.List$$(TDeviceModel))().$ctor$1();
                                let $i31 = 0;
                                let $arr31 = devices;
                                while ($i31 < $arr31.length)
                                {
                                    let $t32, $r32;
                                    let d = $arr31[$i31++];
                                    _devices.Add($.$firstOf(($t32 = this.DeviceStore.LCICD$ISmartDataStoreT$$$GetByIdAsync(TDeviceModel, d.LCFCD$IIded$Identifier), ($.$$.N.AsyncResolver.IsCompleted($t32, { set $v($v) { $r32 = $v; } }) ? $r32 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t32))), () => { throw new $.$$.S.InvalidOperationException().$ctor$9() }));
                                }
                                result = this.GetScope(_scope, _devices);
                            }
                            else 
                            {
                                result = this.GetScope(_scope, $.$sl.SL.Enumerable.ToList(TDeviceModel, $.$sl.SL.Enumerable.Select$1($.$XBGm.LCICI.IIOTDeviceModel, TDeviceModel, devices, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDeviceModel, TDeviceModel))().$ctor(this,  (/*t*/ t) =>
                                {
                                    return $.$XBGm.LCIC.UtilityExtension.Convert$2(TDeviceModel, t);
                                }, $wPvrgg ??= {"r":TDeviceModel?.$h??2162688,"p":[{"n":"t","p":27432337}],"n":"","d":2156445,"H":0,"h":0,"f":17825794}))));
                            }
                            result.SC$1$INotifyPropertyChanged$add_PropertyChanged(new $.$so.SC$1.PropertyChangedEventHandler().$ctor(this,  (/*s*/ s, /*e*/ e) =>
                            {
                                if (e.PropertyName === "Devices")
                                {
                                    this.RaisePropertyChanged$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "Devices" ], null, null));
                                }
                            }, $wGWGZd ??= {"r":65537,"p":[{"n":"s","p":131073},{"n":"e","p":1310738}],"n":"","d":2156445,"H":0,"h":0,"f":17825794}));
                            this.Scopes.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDeviceScope), [ result ], null, null));
                            this.RaisePropertyChanged$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "Scopes" ], null, null));
                            return $.$$.N.AsyncResolver.Result($asnycContext, result);
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(51541763997)
                    
                    //--TRIMMABLE-BOUNDARY-START(317829736349)
                    /*Task *//*async*/  UpdateScope(/*params IIOTDeviceScope[]*/ scopes)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(317829736349);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let $i33 = 0;
                            let $arr33 = scopes;
                            while ($i33 < $arr33.length)
                            {
                                let $t34, $r34;
                                let scope = $arr33[$i33++];
                                ($t34 = this.ScopeStore.LCICD$ISmartDataStoreT$$$SaveAsync(scope.LCICI$IIOTDeviceScope$Model).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t34, { set $v($v) { $r34 = $v; } }) ? $r34 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t34)));
                            }
                            this.RaisePropertyChanged$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "Scopes" ], null, null));
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(317829736349)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131698589)
                    /*Task *//*async*/  DeleteScope(/*params IIOTDeviceScope[]*/ scopes)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(60131698589);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let $i35 = 0;
                            let $arr35 = scopes;
                            while ($i35 < $arr35.length)
                            {
                                let $t36, $r36;
                                let $t37, $r37;
                                let scope = $arr35[$i35++];
                                ($t36 = scope.LCICI$IIOTDeviceScope$ClearDevices().ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t36, { set $v($v) { $r36 = $v; } }) ? $r36 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t36)));
                                ($t37 = this.ScopeStore.LCICD$ISmartDataStoreT$$$DeleteAsync(scope.LCICI$IIOTDeviceScope$Model).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t37, { set $v($v) { $r37 = $v; } }) ? $r37 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t37)));
                                this.Scopes.Remove$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDeviceScope), [ scope ], null, null));
                            }
                            this.RaisePropertyChanged$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "Scopes" ], null, null));
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(60131698589)
                    
                    //--TRIMMABLE-BOUNDARY-START(313534769053)
                    /*Task *//*async*/  UpdateDevice(/*IIOTDeviceScope*/ scope, /*params IIOTDevice[]*/ devices)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(313534769053);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let $i38 = 0;
                            let $arr38 = devices;
                            while ($i38 < $arr38.length)
                            {
                                let $t39, $r39;
                                let device = $arr38[$i38++];
                                ($t39 = this.DeviceStore.LCICD$ISmartDataStoreT$$$SaveAsync(device.LCICI$IIOTDevice$Model).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t39, { set $v($v) { $r39 = $v; } }) ? $r39 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t39)));
                            }
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(313534769053)
                    
                    //--TRIMMABLE-BOUNDARY-START(55836731293)
                    /*Task *//*async*/  DeleteDevice(/*IIOTDeviceScope*/ scope, /*params IIOTDevice[]*/ devices)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(55836731293);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let $i40 = 0;
                            let $arr40 = devices;
                            while ($i40 < $arr40.length)
                            {
                                let $t41, $r41;
                                let device = $arr40[$i40++];
                                /*var*/ let sdevice = $.$cast(device, $.$NXre.LCID.SmartDeviceBase);
                                ($t41 = this.DeviceStore.LCICD$ISmartDataStoreT$$$DeleteAsync(device.LCICI$IIOTDevice$Model).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t41, { set $v($v) { $r41 = $v; } }) ? $r41 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t41)));
                                sdevice.Scopes.ForEach(new ($.$$.S.Action$$($.$XBGm.LCICI.IIOTDeviceScope))().$ctor(this,  (/*scope*/ scope) =>
                                {
                                    return scope.LCICI$IIOTDeviceScope$RemoveDevice($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDeviceModel), [ device.LCICI$IIOTDevice$Model ], null, null));
                                }, $zzmApg ??= {"r":65537,"p":[{"n":"scope","p":28546449}],"n":"","d":2156445,"H":0,"h":0,"f":17825794}));
                                sdevice.Scopes.Remove(scope);
                            }
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(55836731293)
                    
                    //--TRIMMABLE-BOUNDARY-START(236225357725)
                    /*Task<IEnumerable<TServiceModel>> */ GetServices()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(236225357725);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.STT.Task.FromResult($.$$.SCG.IEnumerable$$(TServiceModel), $.$sl.SL.Enumerable.Empty(TServiceModel));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(236225357725)
                    
                    //--TRIMMABLE-BOUNDARY-START(253405226909)
                    /*Task<IEnumerable<IIOTServiceModel>> *//*async*/  LCICI$IIOTDeviceScopeFactory$GetServices()
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTServiceModel)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTServiceModel), async ($asnycContext) => 
                        {
                            let $t42, $r42;
                            return $.$$.N.AsyncResolver.Result($asnycContext, $.$$.N.InterfaceVarianceStubHandler.Create(($t42 = this.GetServices(), ($.$$.N.AsyncResolver.IsCompleted($t42, { set $v($v) { $r42 = $v; } }) ? $r42 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t42))), $.$$.SCG.IEnumerable$$(TServiceModel), $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTServiceModel)));
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(253405226909)
                    
                    //--TRIMMABLE-BOUNDARY-START(231930390429)
                    /*ValueTask<IEnumerable<TDeviceScopeModel>> */ GetScopes()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(231930390429);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.ScopeStore.LCICD$IScopeStore$GetAllAsync(TDeviceScopeModel, this);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(231930390429)
                    
                    //--TRIMMABLE-BOUNDARY-START(219045488541)
                    /*ValueTask<IEnumerable<TDeviceModel>> */ GetDevices(/*TDeviceScopeModel*/ scope)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(219045488541);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.ScopeStore.LCICD$IScopeStore$GetDevices(TDeviceModel, $.$box(scope, TDeviceScopeModel));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(219045488541)
                    
                    //--TRIMMABLE-BOUNDARY-START(261995161501)
                    /*Task<IEnumerable<IIOTDeviceScope>> *//*async*/  LoadScopesAsync()
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceScope)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceScope), async ($asnycContext) => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(261995161501);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            /*List<IIOTDeviceScope>*/ let scopes = new ($.$$.SCG.List$$($.$XBGm.LCICI.IIOTDeviceScope))().$ctor$1();
                            try
                            {
                                let $t43, $r43;
                                /*var*/ let _scopes = ($t43 = this.GetScopes().ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t43, { set $v($v) { $r43 = $v; } }) ? $r43 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t43)));
                                let $en44 = _scopes.SCG$IEnumerable$$$GetEnumerator();
                                while ($en44.SC$1$IEnumerator$MoveNext())
                                {
                                    let _scope = $en44.SCG$IEnumerator$$$Current;
                                    {
                                        let $t45, $r45;
                                        /*var*/ let devices = ($t45 = this.GetDevices(_scope), ($.$$.N.AsyncResolver.IsCompleted($t45, { set $v($v) { $r45 = $v; } }) ? $r45 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t45)));
                                        /*var*/ let scope = this.GetScope(_scope, devices);
                                        scope.add_PropertyChanged(new $.$so.SC$1.PropertyChangedEventHandler().$ctor(this,  (/*s*/ s, /*e*/ e) =>
                                        {
                                            if (e.PropertyName === "Devices")
                                            {
                                                this.RaisePropertyChanged$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "Devices" ], null, null));
                                            }
                                        }, $dwPDRe ??= {"r":65537,"p":[{"n":"s","p":131073},{"n":"e","p":1310738}],"n":"","d":2156445,"H":0,"h":0,"f":17825794}));
                                        scopes.Add(scope);
                                    }
                                }
                            }
                            catch($e)
                            {
                            }
                            return $.$$.N.AsyncResolver.Result($asnycContext, scopes);
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(261995161501)
                    
                    //--TRIMMABLE-BOUNDARY-START(77311567773)
                    /*IEnumerable<IIOTDeviceFamily> */ get DeviceFamilies()
                    {
                        return $.$sl.SL.Enumerable.Empty($.$XBGm.LCICI.IIOTDeviceFamily);
                    }
                    //--TRIMMABLE-BOUNDARY-END(77311567773)
                    
                    //--TRIMMABLE-BOUNDARY-START(309239801757)
                    /*string? */ get ThemeColor()
                    {
                        return ($.$sl.SL.Enumerable.FirstOrDefault$3($.$XBGm.LCICI.IIOTDeviceFamily, this.DeviceFamilies)?.LCICI$IIOTDeviceFamily$DeviceDescriptor?.ThemeColor ?? null);
                    }
                    //--TRIMMABLE-BOUNDARY-END(309239801757)
                    
                    //--TRIMMABLE-BOUNDARY-START(292059932573)
                    /*Task */ Scan(/*Action<IIOTDeviceScope>*/ found)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(292059932573);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$$.STT.Task.CompletedTask;
                    }
                    //--TRIMMABLE-BOUNDARY-END(292059932573)
                    
                    //--TRIMMABLE-BOUNDARY-START(270585096093)
                    /*PropertyChangedEventHandler?*/ PropertyChanged = null;
                    //--TRIMMABLE-BOUNDARY-END(270585096093)
                    
                    //--TRIMMABLE-BOUNDARY-START(270585096093)
                    //--TRIMMABLE-BOUNDARY-START(38656862109)
                    add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38656862109);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656862109)
                    
                    //--TRIMMABLE-BOUNDARY-START(287764965277)
                    remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(287764965277);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(287764965277)
                    
                    //--TRIMMABLE-BOUNDARY-END(270585096093)
                    
                    //--TRIMMABLE-BOUNDARY-START(274880063389)
                    /*ValueTask */ RaisePropertyChanged(/*object?*/ sender, /*params string[]*/ names)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(274880063389);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $i46 = 0;
                        let $arr46 = names;
                        while ($i46 < $arr46.length)
                        {
                            let name = $arr46[$i46++];
                            this.PropertyChanged?.Invoke(sender, new $.$so.SC$1.PropertyChangedEventArgs().$ctor$2(name));
                        }
                        return $.$$.STT.ValueTask.CompletedTask;
                    }
                    //--TRIMMABLE-BOUNDARY-END(274880063389)
                    
                    //--TRIMMABLE-BOUNDARY-START(279175030685)
                    /*void */ RaisePropertyChanged$1(/*params string[]*/ names)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(279175030685);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.RaisePropertyChanged(this, names);
                    }
                    //--TRIMMABLE-BOUNDARY-END(279175030685)
                    
                    //--TRIMMABLE-BOUNDARY-START(98812859793)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.Name.get
                    get LCICI$IIOTDeviceScopeFactory$Name()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(146057500049);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Name;
                    }
                    //--TRIMMABLE-BOUNDARY-END(98812859793)
                    
                    //--TRIMMABLE-BOUNDARY-START(81632990609)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.Icon.get
                    get LCICI$IIOTDeviceScopeFactory$Icon()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(137467565457);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Icon;
                    }
                    //--TRIMMABLE-BOUNDARY-END(81632990609)
                    
                    //--TRIMMABLE-BOUNDARY-START(90222925201)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.Image.get
                    get LCICI$IIOTDeviceScopeFactory$Image()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(141762532753);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Image;
                    }
                    //--TRIMMABLE-BOUNDARY-END(90222925201)
                    
                    //--TRIMMABLE-BOUNDARY-START(124582663569)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.ThemeColor.get
                    get LCICI$IIOTDeviceScopeFactory$ThemeColor()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(163237369233);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ThemeColor;
                    }
                    //--TRIMMABLE-BOUNDARY-END(124582663569)
                    
                    //--TRIMMABLE-BOUNDARY-START(47273252241)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.Description.get
                    get LCICI$IIOTDeviceScopeFactory$Description()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21503448465);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Description;
                    }
                    //--TRIMMABLE-BOUNDARY-END(47273252241)
                    
                    //--TRIMMABLE-BOUNDARY-START(73043056017)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.Features.get
                    get LCICI$IIOTDeviceScopeFactory$Features()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38683317649);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Features;
                    }
                    //--TRIMMABLE-BOUNDARY-END(73043056017)
                    
                    //--TRIMMABLE-BOUNDARY-START(115992728977)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.Services.get
                    get LCICI$IIOTDeviceScopeFactory$Services()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(158942401937);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Services;
                    }
                    //--TRIMMABLE-BOUNDARY-END(115992728977)
                    
                    //--TRIMMABLE-BOUNDARY-START(55863186833)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.DeviceFamilies.get
                    get LCICI$IIOTDeviceScopeFactory$DeviceFamilies()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25798415761);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceFamilies;
                    }
                    //--TRIMMABLE-BOUNDARY-END(55863186833)
                    
                    //--TRIMMABLE-BOUNDARY-START(107402794385)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.Scopes.get
                    get LCICI$IIOTDeviceScopeFactory$Scopes()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(154647434641);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Scopes;
                    }
                    //--TRIMMABLE-BOUNDARY-END(107402794385)
                    
                    //--TRIMMABLE-BOUNDARY-START(64453121425)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.Devices.get
                    get LCICI$IIOTDeviceScopeFactory$Devices()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30093383057);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Devices;
                    }
                    //--TRIMMABLE-BOUNDARY-END(64453121425)
                    
                    //--TRIMMABLE-BOUNDARY-START(150352467345)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.Scan(System.Action<LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope>)
                    LCICI$IIOTDeviceScopeFactory$Scan()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(150352467345);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Scan(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(150352467345)
                    
                    //--TRIMMABLE-BOUNDARY-START(8618546577)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.CreateScope(LivingThing.Core.IOT.Common.Models.IIOTDeviceScopeModel, LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel[], bool)
                    LCICI$IIOTDeviceScopeFactory$CreateScope()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8618546577);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CreateScope(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8618546577)
                    
                    //--TRIMMABLE-BOUNDARY-START(171827303825)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.UpdateScope(params LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope[])
                    LCICI$IIOTDeviceScopeFactory$UpdateScope()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(171827303825);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.UpdateScope(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(171827303825)
                    
                    //--TRIMMABLE-BOUNDARY-START(17208481169)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.DeleteScope(params LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope[])
                    LCICI$IIOTDeviceScopeFactory$DeleteScope()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17208481169);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeleteScope(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17208481169)
                    
                    //--TRIMMABLE-BOUNDARY-START(167532336529)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.UpdateDevice(LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope, params LivingThing.Core.IOT.Common.Interface.IIOTDevice[])
                    LCICI$IIOTDeviceScopeFactory$UpdateDevice()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(167532336529);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.UpdateDevice(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(167532336529)
                    
                    //--TRIMMABLE-BOUNDARY-START(12913513873)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.DeleteDevice(LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope, params LivingThing.Core.IOT.Common.Interface.IIOTDevice[])
                    LCICI$IIOTDeviceScopeFactory$DeleteDevice()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12913513873);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeleteDevice(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12913513873)
                    
                    //--TRIMMABLE-BOUNDARY-START(4323579281)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.ClearScopes()
                    LCICI$IIOTDeviceScopeFactory$ClearScopes()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4323579281);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ClearScopes(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4323579281)
                    
                    //--TRIMMABLE-BOUNDARY-START(34388350353)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScopeFactory.EnsureLoaded()
                    LCICI$IIOTDeviceScopeFactory$EnsureLoaded()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34388350353);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.EnsureLoaded(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(34388350353)
                    
                    //--TRIMMABLE-BOUNDARY-START(4299524438)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.INotifyOnPropertyChanged.RaisePropertyChanged(object?, params string[])
                    LCFCC$INotifyOnPropertyChanged$RaisePropertyChanged()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4299524438);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.RaisePropertyChanged(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4299524438)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591114258)
                    //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
                    SC$1$INotifyPropertyChanged$add_PropertyChanged()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8591114258);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.add_PropertyChanged(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591114258)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476016146)
                    //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
                    SC$1$INotifyPropertyChanged$remove_PropertyChanged()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476016146);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.remove_PropertyChanged(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476016146)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886081554)
                    //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
                    System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886081554);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.PropertyChanged;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886081554)
                    
                    static $H = 2156445;
                    static $h = 2156445;
                    static $f = 0b10000000001110001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(304944834461),
    {
      "p": 62949718,
      "g": {
        "r": 0,
        "d": 0,
        "H": 206160586653,
        "h": Number(BigInt(2156445)|0x3000000000n),
        "f": 50331649
      },
      "n": "Services",
      "d": 2156445,
      "H": 304944834461,
      "h": Number(BigInt(2156445)|0x4700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(304944834461),
//--TRIMMABLE-BOUNDARY-START(47246796701),
    {
      "p": 4950358,
      "g": {
        "r": 0,
        "d": 0,
        "H": 103081371549,
        "h": Number(BigInt(2156445)|0x1800000000n),
        "f": 50331649
      },
      "n": "Configuration",
      "d": 2156445,
      "H": 47246796701,
      "h": Number(BigInt(2156445)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246796701),
//--TRIMMABLE-BOUNDARY-START(300649867165),
    {
      "p": 1545617,
      "g": {
        "r": 0,
        "d": 0,
        "H": 197570652061,
        "h": Number(BigInt(2156445)|0x2E00000000n),
        "f": 50331649
      },
      "n": "ScopeStore",
      "d": 2156445,
      "H": 300649867165,
      "h": Number(BigInt(2156445)|0x4600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(300649867165),
//--TRIMMABLE-BOUNDARY-START(85901502365),
    {
      "p": 1283473,
      "g": {
        "r": 0,
        "d": 0,
        "H": 146031044509,
        "h": Number(BigInt(2156445)|0x2200000000n),
        "f": 50331649
      },
      "n": "DeviceStore",
      "d": 2156445,
      "H": 85901502365,
      "h": Number(BigInt(2156445)|0x1400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85901502365),
//--TRIMMABLE-BOUNDARY-START(266290128797),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 180390782877,
        "h": Number(BigInt(2156445)|0x2A00000000n),
        "f": 50331777
      },
      "n": "Name",
      "d": 2156445,
      "H": 266290128797,
      "h": Number(BigInt(2156445)|0x3E00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(266290128797),
//--TRIMMABLE-BOUNDARY-START(64426665885),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 111671306141,
        "h": Number(BigInt(2156445)|0x1A00000000n),
        "f": 50331777
      },
      "n": "Description",
      "d": 2156445,
      "H": 64426665885,
      "h": Number(BigInt(2156445)|0xF00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(64426665885),
//--TRIMMABLE-BOUNDARY-START(240520325021),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 163210913693,
        "h": Number(BigInt(2156445)|0x2600000000n),
        "f": 50331777
      },
      "n": "Icon",
      "d": 2156445,
      "H": 240520325021,
      "h": Number(BigInt(2156445)|0x3800000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(240520325021),
//--TRIMMABLE-BOUNDARY-START(296354899869),
    {
      "p": $.$fPer.LCFCR.ReactiveObservableCollection$$($.$XBGm.LCICI.IIOTDeviceScope).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 188980717469,
        "h": Number(BigInt(2156445)|0x2C00000000n),
        "f": 50331649
      },
      "n": "Scopes",
      "d": 2156445,
      "H": 296354899869,
      "h": Number(BigInt(2156445)|0x4500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(296354899869),
//--TRIMMABLE-BOUNDARY-START(244815292317),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 171800848285,
        "h": Number(BigInt(2156445)|0x2800000000n),
        "f": 50331777
      },
      "n": "Image",
      "d": 2156445,
      "H": 244815292317,
      "h": Number(BigInt(2156445)|0x3900000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(244815292317),
//--TRIMMABLE-BOUNDARY-START(81606535069),
    {
      "p": $.$fPer.LCFCR.ReactiveObservableCollection$$($.$XBGm.LCICI.IIOTDevice).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 137441109917,
        "h": Number(BigInt(2156445)|0x2000000000n),
        "f": 50331649
      },
      "n": "Devices",
      "d": 2156445,
      "H": 81606535069,
      "h": Number(BigInt(2156445)|0x1300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606535069),
//--TRIMMABLE-BOUNDARY-START(73016600477),
    {
      "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 120261240733,
        "h": Number(BigInt(2156445)|0x1C00000000n),
        "f": 50331649
      },
      "n": "Descriptors",
      "d": 2156445,
      "H": 73016600477,
      "h": Number(BigInt(2156445)|0x1100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016600477),
//--TRIMMABLE-BOUNDARY-START(94491436957),
    {
      "p": 30643601,
      "g": {
        "r": 0,
        "d": 0,
        "H": 154620979101,
        "h": Number(BigInt(2156445)|0x2400000000n),
        "f": 50331777
      },
      "n": "Features",
      "d": 2156445,
      "H": 94491436957,
      "h": Number(BigInt(2156445)|0x1600000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(94491436957),
//--TRIMMABLE-BOUNDARY-START(77311567773),
    {
      "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 128851175325,
        "h": Number(BigInt(2156445)|0x1E00000000n),
        "f": 50331777
      },
      "n": "DeviceFamilies",
      "d": 2156445,
      "H": 77311567773,
      "h": Number(BigInt(2156445)|0x1200000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(77311567773),
//--TRIMMABLE-BOUNDARY-START(309239801757),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 214750521245,
        "h": Number(BigInt(2156445)|0x3200000000n),
        "f": 50331777
      },
      "n": "ThemeColor",
      "d": 2156445,
      "H": 309239801757,
      "h": Number(BigInt(2156445)|0x4800000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(309239801757)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90196469661),
    {
      "r": 178454529,
      "n": "EnsureLoaded",
      "d": 2156445,
      "H": 90196469661,
      "h": Number(BigInt(2156445)|0x1500000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(90196469661),
//--TRIMMABLE-BOUNDARY-START(42951829405),
    {
      "r": 178454529,
      "n": "ClearScopes",
      "d": 2156445,
      "H": 42951829405,
      "h": Number(BigInt(2156445)|0xA00000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(42951829405),
//--TRIMMABLE-BOUNDARY-START(227635423133),
    {
      "r": 2090909,
      "p": [
        {
          "n": "service",
          "p": TServiceModel?.$h??1638400
        }
      ],
      "n": "GetScope",
      "o": "@$1",
      "d": 2156445,
      "H": 227635423133,
      "h": Number(BigInt(2156445)|0x3500000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(227635423133),
//--TRIMMABLE-BOUNDARY-START(223340455837),
    {
      "r": 2090909,
      "p": [
        {
          "n": "scope",
          "p": TDeviceScopeModel?.$h??1966080
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$(TDeviceModel).$h
        }
      ],
      "n": "GetScope",
      "d": 2156445,
      "H": 223340455837,
      "h": Number(BigInt(2156445)|0x3400000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(223340455837),
//--TRIMMABLE-BOUNDARY-START(51541763997),
    {
      "r": $.$$.STT.Task$$($.$XBGm.LCICI.IIOTDeviceScope).$h,
      "p": [
        {
          "n": "scope",
          "p": 34837905
        },
        {
          "n": "devices",
          "p": $.$typeArray($.$XBGm.LCICI.IIOTDeviceModel).$h
        },
        {
          "n": "persist",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "CreateScope",
      "d": 2156445,
      "H": 51541763997,
      "h": Number(BigInt(2156445)|0xC00000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(51541763997),
//--TRIMMABLE-BOUNDARY-START(317829736349),
    {
      "r": 178454529,
      "p": [
        {
          "n": "scopes",
          "p": $.$typeArray($.$XBGm.LCICI.IIOTDeviceScope).$h,
          "f": 16
        }
      ],
      "n": "UpdateScope",
      "d": 2156445,
      "H": 317829736349,
      "h": Number(BigInt(2156445)|0x4A00000000n),
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(317829736349),
//--TRIMMABLE-BOUNDARY-START(60131698589),
    {
      "r": 178454529,
      "p": [
        {
          "n": "scopes",
          "p": $.$typeArray($.$XBGm.LCICI.IIOTDeviceScope).$h,
          "f": 16
        }
      ],
      "n": "DeleteScope",
      "d": 2156445,
      "H": 60131698589,
      "h": Number(BigInt(2156445)|0xE00000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(60131698589),
//--TRIMMABLE-BOUNDARY-START(313534769053),
    {
      "r": 178454529,
      "p": [
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "devices",
          "p": $.$typeArray($.$XBGm.LCICI.IIOTDevice).$h,
          "f": 16
        }
      ],
      "n": "UpdateDevice",
      "d": 2156445,
      "H": 313534769053,
      "h": Number(BigInt(2156445)|0x4900000000n),
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(313534769053),
//--TRIMMABLE-BOUNDARY-START(55836731293),
    {
      "r": 178454529,
      "p": [
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "devices",
          "p": $.$typeArray($.$XBGm.LCICI.IIOTDevice).$h,
          "f": 16
        }
      ],
      "n": "DeleteDevice",
      "d": 2156445,
      "H": 55836731293,
      "h": Number(BigInt(2156445)|0xD00000000n),
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(55836731293),
//--TRIMMABLE-BOUNDARY-START(236225357725),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$(TServiceModel)).$h,
      "n": "GetServices",
      "d": 2156445,
      "H": 236225357725,
      "h": Number(BigInt(2156445)|0x3700000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(236225357725),
//--TRIMMABLE-BOUNDARY-START(231930390429),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TDeviceScopeModel)).$h,
      "n": "GetScopes",
      "d": 2156445,
      "H": 231930390429,
      "h": Number(BigInt(2156445)|0x3600000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(231930390429),
//--TRIMMABLE-BOUNDARY-START(219045488541),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(TDeviceModel)).$h,
      "p": [
        {
          "n": "scope",
          "p": TDeviceScopeModel?.$h??1966080
        }
      ],
      "n": "GetDevices",
      "d": 2156445,
      "H": 219045488541,
      "h": Number(BigInt(2156445)|0x3300000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(219045488541),
//--TRIMMABLE-BOUNDARY-START(261995161501),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceScope)).$h,
      "n": "LoadScopesAsync",
      "d": 2156445,
      "H": 261995161501,
      "h": Number(BigInt(2156445)|0x3D00000000n),
      "f": 16781444
    },
//--TRIMMABLE-BOUNDARY-END(261995161501),
//--TRIMMABLE-BOUNDARY-START(292059932573),
    {
      "r": 178454529,
      "p": [
        {
          "n": "found",
          "p": $.$$.S.Action$$($.$XBGm.LCICI.IIOTDeviceScope).$h
        }
      ],
      "n": "Scan",
      "d": 2156445,
      "H": 292059932573,
      "h": Number(BigInt(2156445)|0x4400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(292059932573),
//--TRIMMABLE-BOUNDARY-START(274880063389),
    {
      "r": 181338113,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "names",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "RaisePropertyChanged",
      "d": 2156445,
      "H": 274880063389,
      "h": Number(BigInt(2156445)|0x4000000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(274880063389),
//--TRIMMABLE-BOUNDARY-START(279175030685),
    {
      "r": 65537,
      "p": [
        {
          "n": "names",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "RaisePropertyChanged",
      "o": "@$1",
      "d": 2156445,
      "H": 279175030685,
      "h": Number(BigInt(2156445)|0x4100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(279175030685)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(257700194205),
    {
      "t": 262145,
      "n": "loaded",
      "d": 2156445,
      "H": 257700194205,
      "h": Number(BigInt(2156445)|0x3C00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(257700194205),
//--TRIMMABLE-BOUNDARY-START(8592091037),
    {
      "t": $.$fPer.LCFCR.ReactiveObservableCollection$$($.$XBGm.LCICI.IIOTDeviceScope).$h,
      "n": "_scopes",
      "d": 2156445,
      "H": 8592091037,
      "h": Number(BigInt(2156445)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592091037),
//--TRIMMABLE-BOUNDARY-START(4297123741),
    {
      "t": $.$fPer.LCFCR.ReactiveObservableCollection$$($.$XBGm.LCICI.IIOTDevice).$h,
      "n": "_devices",
      "d": 2156445,
      "H": 4297123741,
      "h": Number(BigInt(2156445)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297123741),
//--TRIMMABLE-BOUNDARY-START(68721633181),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceDescriptor).$h,
      "n": "descriptors",
      "d": 2156445,
      "H": 68721633181,
      "h": Number(BigInt(2156445)|0x1000000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68721633181)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066927517),
    {
      "p": [
        {
          "n": "services",
          "p": 62949718
        },
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "scopeStore",
          "p": 1545617
        },
        {
          "n": "deviceStore",
          "p": 1283473
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2156445,
      "H": 30066927517,
      "h": Number(BigInt(2156445)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066927517)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(270585096093),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 2156445,
        "H": 38656862109,
        "h": Number(BigInt(2156445)|0x900000000n),
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 2156445,
        "H": 287764965277,
        "h": Number(BigInt(2156445)|0x4300000000n),
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 2156445,
      "H": 270585096093,
      "h": Number(BigInt(2156445)|0x3F00000000n),
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(270585096093)
  ],
  "d": 1697693,
  "H": 2156445,
  "h": 2156445
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>+SmartGenericDeviceScopeFactory`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TDeviceScopeModel?.$getFullName(separator)}$${TDeviceScopeSettings?.$getFullName(separator)}$${TDeviceScopeStates?.$getFullName(separator)}$${TDeviceModel?.$getFullName(separator)}$${TDeviceSettings?.$getFullName(separator)}$${TDeviceHardwareSettings?.$getFullName(separator)}$${TDeviceStates?.$getFullName(separator)}$${TDeviceStatusModel?.$getFullName(separator)}$${TDeviceCommandModel?.$getFullName(separator)}$${TDeviceReceivedDataModel?.$getFullName(separator)}$${TDeviceSendDataModel?.$getFullName(separator)}$${TDeviceStatusHandler?.$getFullName(separator)}$${TServiceHubClient?.$getFullName(separator)}$${TServicesRemoteService?.$getFullName(separator)}$${TDeviceGlobalSettings?.$getFullName(separator)}$${separator}SmartGenericDeviceScopeFactory`; }
                }, $cls, ($v) => $cls.$_SmartGenericDeviceScopeFactory = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2156445)
            
            //--TRIMMABLE-BOUNDARY-START(2090909)
            static $_SmartGenericDeviceScope;
            static get SmartGenericDeviceScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2090909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings);
                return $cls.$_SmartGenericDeviceScope ??= $asm.$ncls(`$NXre.LCID.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>.SmartGenericDeviceScope`, ($self) => class SmartGenericDeviceScope extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(21476927389)
                    $ctor$1(/*SmartGenericDeviceScopeFactory*/ factory, /*TDeviceScopeModel*/ scope, /*IEnumerable<TDeviceModel>*/ devices)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21476927389);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Factory = factory;
                            this.Model = scope;
                            this._deviceModels = devices;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476927389)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297058205)
                    /*IEnumerable<TDeviceModel>*/ _deviceModels = null;
                    //--TRIMMABLE-BOUNDARY-END(4297058205)
                    
                    //--TRIMMABLE-BOUNDARY-START(236225292189)
                    /*TaskCompletionSource*/ ready = null;
                    //--TRIMMABLE-BOUNDARY-END(236225292189)
                    
                    //--TRIMMABLE-BOUNDARY-START(68721567645)
                    /*Task */ EnsureLoaded()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68721567645);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        _ = this.Devices;
                        return this.ready.Task;
                    }
                    //--TRIMMABLE-BOUNDARY-END(68721567645)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951763869)
                    /*void *//*async*/  BeginLoad(/*IEnumerable<TDeviceModel>*/ _devices)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(42951763869);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            try
                            {
                                let $en47 = _devices.SCG$IEnumerable$$$GetEnumerator();
                                while ($en47.SC$1$IEnumerator$MoveNext())
                                {
                                    let dev = $en47.SCG$IEnumerator$$$Current;
                                    {
                                        let $t48, $r48;
                                        /*var*/ let device = ($t48 = this.GetOrCreateDevice(dev).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t48, { set $v($v) { $r48 = $v; } }) ? $r48 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t48)));
                                        if (device !== null)
                                        {
                                            this.Devices.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDevice), [ device ], null, null));
                                        }
                                    }
                                }
                            }
                            catch(e)
                            {
                                $.$fPer.LCFCL.LoggingFactory.LogException(e, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices\\SmartGenericDeviceScope.cs", "BeginLoad", 83);
                                this.Devices.Error(e);
                            }
                            this.ready.SetResult();
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(42951763869)
                    
                    //--TRIMMABLE-BOUNDARY-START(51541698461)
                    /*IEnumerable<string> */ get ConnectionIdentifiers()
                    {
                        return $.$sl.SL.Enumerable.Where($.$$.S.String, (this.Model.ConnectionIdentifer !== null ? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [this.Model.ConnectionIdentifer], null, null) : $.$sl.SL.Enumerable.Select$1($.$XBGm.LCICI.IIOTDeviceFamily, $.$$.S.String, this.Factory.DeviceFamilies, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDeviceFamily, $.$$.S.String))().$ctor(this,  (/*f*/ f) =>
                        {
                            return f.LCICI$IIOTDeviceFamily$ConnectionIdentifier;
                        }, $QPXIhi ??= {"r":1310721,"p":[{"n":"f","p":26711441}],"n":"","d":2090909,"H":0,"h":0,"f":17825794}))), new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s !== null;
                        }, $aFVVoh ??= {"r":262145,"p":[{"n":"s","p":1310721}],"n":"","d":2090909,"H":0,"h":0,"f":17825794}));
                    }
                    //--TRIMMABLE-BOUNDARY-END(51541698461)
                    
                    //--TRIMMABLE-BOUNDARY-START(257700128669)
                    /*IScopeStore */ get ScopeStore()
                    {
                        return this.Factory.ScopeStore;
                    }
                    //--TRIMMABLE-BOUNDARY-END(257700128669)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426600349)
                    /*IDeviceStore */ get DeviceStore()
                    {
                        return this.Factory.DeviceStore;
                    }
                    //--TRIMMABLE-BOUNDARY-END(64426600349)
                    
                    //--TRIMMABLE-BOUNDARY-START(73016534941)
                    /*SmartGenericDeviceScopeFactory*/ Factory = null;
                    //--TRIMMABLE-BOUNDARY-END(73016534941)
                    
                    //--TRIMMABLE-BOUNDARY-START(227635357597)
                    /*string */ get Name()
                    {
                        return this.Model.Name;
                    }
                    //--TRIMMABLE-BOUNDARY-END(227635357597)
                    
                    //--TRIMMABLE-BOUNDARY-START(223340390301)
                    /*TDeviceScopeModel*/ Model = $.$default(TDeviceScopeModel);
                    //--TRIMMABLE-BOUNDARY-END(223340390301)
                    
                    //--TRIMMABLE-BOUNDARY-START(219045423005)
                    /*IIOTDeviceScopeSettings */ get LCICI$IIOTDeviceScope$Settings()
                    {
                        return $.$box((this.Model?.Settings ?? null) ?? new TDeviceScopeSettings().$gctor(), TDeviceScopeSettings);
                    }
                    //--TRIMMABLE-BOUNDARY-END(219045423005)
                    
                    //--TRIMMABLE-BOUNDARY-START(214750455709)
                    /*IIOTDeviceScopeModel */ get LCICI$IIOTDeviceScope$Model()
                    {
                        return $.$box(this.Model, TDeviceScopeModel);
                    }
                    //--TRIMMABLE-BOUNDARY-END(214750455709)
                    
                    //--TRIMMABLE-BOUNDARY-START(231930324893)
                    /*PropertyChangedEventHandler?*/ PropertyChanged = null;
                    //--TRIMMABLE-BOUNDARY-END(231930324893)
                    
                    //--TRIMMABLE-BOUNDARY-START(231930324893)
                    //--TRIMMABLE-BOUNDARY-START(30066861981)
                    add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30066861981);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066861981)
                    
                    //--TRIMMABLE-BOUNDARY-START(244815226781)
                    remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(244815226781);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(244815226781)
                    
                    //--TRIMMABLE-BOUNDARY-END(231930324893)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592025501)
                    /*ReactiveObservableCollection<IIOTDevice>?*/ _devices = null;
                    //--TRIMMABLE-BOUNDARY-END(8592025501)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131633053)
                    /*ReactiveObservableCollection<IIOTDevice> */ get Devices()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(98786338717);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._devices === null)
                        {
                            this._devices = (() =>
                            {
                                //new $.$fPer.LCFCR.ReactiveObservableCollection$$($.$XBGm.LCICI.IIOTDevice)()
                                const $t49 = $.$fPer.LCFCR.ReactiveObservableCollection$$($.$XBGm.LCICI.IIOTDevice);
                                const $i49 = new $t49();
                                $i49.$ctor$6();
                                $i49.Name = "Devices." + $.$strNN(this.Name);
                                return $i49;
                            })();
                            this.BeginLoad(this._deviceModels);
                        }
                        return this._devices;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60131633053)
                    
                    //--TRIMMABLE-BOUNDARY-START(180390717341)
                    /*IIOTDeviceScopeFactory */ get LCICI$IIOTDeviceScope$Factory()
                    {
                        return this.Factory;
                    }
                    //--TRIMMABLE-BOUNDARY-END(180390717341)
                    
                    //--TRIMMABLE-BOUNDARY-START(171800782749)
                    /*string */ get Icon()
                    {
                        return this.Factory.Icon;
                    }
                    //--TRIMMABLE-BOUNDARY-END(171800782749)
                    
                    //--TRIMMABLE-BOUNDARY-START(176095750045)
                    /*string */ get Image()
                    {
                        return this.Factory.Image;
                    }
                    //--TRIMMABLE-BOUNDARY-END(176095750045)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656796573)
                    /*string? */ get ApplicationLink()
                    {
                        return null;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656796573)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246731165)
                    /*Task *//*async*/  ClearDevices()
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t50, $r50;
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(47246731165);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            ($t50 = this.DeleteDevice($.$sl.SL.Enumerable.ToArray($.$XBGm.LCICI.IIOTDevice, this.Devices.Where(new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDevice, $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                            {
                                return d.LCICI$IIOTDevice$OwnerScope === this;
                            }, $YvwjKf ??= {"r":262145,"p":[{"n":"d","p":25925009}],"n":"","d":2090909,"H":0,"h":0,"f":17825794})))), ($.$$.N.AsyncResolver.IsCompleted($t50, { set $v($v) { $r50 = $v; } }) ? $r50 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t50)));
                            let $en51 = $.$sl.SL.Enumerable.ToList($.$XBGm.LCICI.IIOTDevice, this.Devices).GetEnumerator();
                            while ($en51.MoveNext())
                            {
                                let device = $en51.Current;
                                {
                                    let $t52, $r52;
                                    ($t52 = this.ScopeStore.LCICD$IScopeStore$RemoveDevices($.$box(this.Model, TDeviceScopeModel), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDeviceModel), [ device.LCICI$IIOTDevice$Model ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t52, { set $v($v) { $r52 = $v; } }) ? $r52 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t52)));
                                    ($.$cast(device, $.$NXre.LCID.SmartDeviceBase)).Scopes.Remove(this);
                                }
                            }
                            this.Devices.Clear();
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(47246731165)
                    
                    //--TRIMMABLE-BOUNDARY-START(167505815453)
                    /*Task<SmartDeviceBase?> *//*async*/  GetOrCreateDevice(/*TDeviceModel*/ model)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$NXre.LCID.SmartDeviceBase), $.$NXre.LCID.SmartDeviceBase, async ($asnycContext) => 
                        {
                            let $t53, $r53;
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(167505815453);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            /*var*/ let device = ($t53 = $.$fPer.LCFCD.WorkSpaceExtension.GetAsync($.$NXre.LCID.SmartDeviceBase, model.Workspace, null, "device", new ($.$$.S.Func$$($.$$.STT.Task$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this, /*async*/  () =>
                            {
                                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$NXre.LCID.SmartDeviceBase), $.$NXre.LCID.SmartDeviceBase, async ($asnycContext) => 
                                {
                                    let $t54, $r54;
                                    /*var*/ let d = ($t54 = this.GetDevice(model).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t54, { set $v($v) { $r54 = $v; } }) ? $r54 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t54)));
                                    return $.$$.N.AsyncResolver.Result($asnycContext, d);
                                });
                            }, $vWFWUf ??= {"r":$.$$.STT.Task$$($.$NXre.LCID.SmartDeviceBase).$h,"n":"","d":2090909,"H":0,"h":0,"f":17829890}), true, true).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t53, { set $v($v) { $r53 = $v; } }) ? $r53 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t53)));
                            if (device !== null)
                            {
                                $.$fPer.LCFCD.WorkSpaceExtension.Set($.$NXre.LCID.SmartDeviceBase, device.Model.LCFCD$IOneToOneMapping$Workspace, device, null, "device", true);
                            }
                            return $.$$.N.AsyncResolver.Result($asnycContext, device);
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(167505815453)
                    
                    //--TRIMMABLE-BOUNDARY-START(210455488413)
                    /*Task<IIOTDevice?> *//*async*/  LCICI$IIOTDeviceScope$GetDevice(/*IIOTDeviceModel*/ model)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$XBGm.LCICI.IIOTDevice), $.$XBGm.LCICI.IIOTDevice, async ($asnycContext) => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(210455488413);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            if (!model.LCFCD$IIded$Identifier.Empty)
                            {
                                let $t55, $r55;
                                let $t56, $r56;
                                /*var*/ let dev = ($t55 = this.Factory.DeviceStore.LCICD$ISmartDataStoreT$$$GetByIdAsync(TDeviceModel, model.LCFCD$IIded$Identifier.Id).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t55, { set $v($v) { $r55 = $v; } }) ? $r55 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t55)));
                                return $.$$.N.AsyncResolver.Result($asnycContext, ($t56 = this.GetOrCreateDevice(dev).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t56, { set $v($v) { $r56 = $v; } }) ? $r56 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t56))));
                            }
                            else 
                            {
                                let $t57, $r57;
                                /*var*/ let dev = $.$XBGm.LCIC.UtilityExtension.Convert$2(TDeviceModel, model);
                                return $.$$.N.AsyncResolver.Result($asnycContext, ($t57 = this.GetOrCreateDevice(dev).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t57, { set $v($v) { $r57 = $v; } }) ? $r57 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t57))));
                            }
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(210455488413)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361829277)
                    /*Task<IEnumerable<IIOTDevice>> *//*async*/  AddDevices(/*IIOTDeviceModel[]*/ models, /*bool*/ persist)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice), async ($asnycContext) => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34361829277);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            if (persist)
                            {
                                let $t58, $r58;
                                ($t58 = this.Factory.ScopeStore.LCICD$IScopeStore$AddDevices($.$box(this.Model, TDeviceScopeModel), models), ($.$$.N.AsyncResolver.IsCompleted($t58, { set $v($v) { $r58 = $v; } }) ? $r58 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t58)));
                            }
                            /*List<IIOTDevice>*/ let _devices = new ($.$$.SCG.List$$($.$XBGm.LCICI.IIOTDevice))().$ctor$1();
                            let $i59 = 0;
                            let $arr59 = models;
                            while ($i59 < $arr59.length)
                            {
                                let model = $arr59[$i59++];
                                /*var*/ let device = $.$cast(($.$sl.SL.Enumerable.FirstOrDefault$1($.$XBGm.LCICI.IIOTDevice, this.Devices, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDevice, $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                                {
                                    return d.LCICI$IIOTDevice$Model === model;
                                }, $VqPvri ??= {"r":262145,"p":[{"n":"d","p":25925009}],"n":"","d":2090909,"H":0,"h":0,"f":17825794}))), $.$NXre.LCID.SmartDeviceBase);
                                if (device === null)
                                {
                                    let $t60, $r60;
                                    let $t61, $r61;
                                    device = ($t60 = this.GetOrCreateDevice(persist ? ($t61 = this.Factory.DeviceStore.LCICD$ISmartDataStoreT$$$GetByIdAsync(TDeviceModel, model.LCFCD$IIded$Identifier.Id).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t61, { set $v($v) { $r61 = $v; } }) ? $r61 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t61))) : $.$XBGm.LCIC.UtilityExtension.Convert$2(TDeviceModel, model)).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t60, { set $v($v) { $r60 = $v; } }) ? $r60 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t60)));
                                    if (!device.Scopes.Contains(this))
                                    {
                                        device.Scopes.Add(this);
                                    }
                                    this.Devices.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDevice), [ device ], null, null));
                                    _devices.Add(device);
                                }
                            }
                            this.PropertyChanged?.Invoke(this, new $.$so.SC$1.PropertyChangedEventArgs().$ctor$2("Devices"));
                            return $.$$.N.AsyncResolver.Result($asnycContext, _devices);
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361829277)
                    
                    //--TRIMMABLE-BOUNDARY-START(249110194077)
                    /*Task *//*async*/  RemoveDevice(/*params IIOTDeviceModel[]*/ models)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(249110194077);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let $i62 = 0;
                            let $arr62 = models;
                            while ($i62 < $arr62.length)
                            {
                                let $t63, $r63;
                                let model = $arr62[$i62++];
                                ($t63 = this.Factory.ScopeStore.LCICD$IScopeStore$RemoveDevices($.$box(this.Model, TDeviceScopeModel), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDeviceModel), [ model ], null, null)).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t63, { set $v($v) { $r63 = $v; } }) ? $r63 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t63)));
                                /*var*/ let device = $.$cast($.$sl.SL.Enumerable.FirstOrDefault$1($.$XBGm.LCICI.IIOTDevice, this.Devices, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDevice, $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                                {
                                    return $.$dsp(d.LCICI$IIOTDevice$Model, $.$$.S.Object, ($t) => $t.Equals$1, model);
                                }, $qJXmae ??= {"r":262145,"p":[{"n":"d","p":25925009}],"n":"","d":2090909,"H":0,"h":0,"f":17825794})), $.$NXre.LCID.SmartDeviceBase);
                                if (device !== null)
                                {
                                    this.Devices.Remove$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDevice), [ device ], null, null));
                                    device.Scopes.Remove(this);
                                }
                            }
                            this.PropertyChanged?.Invoke(this, new $.$so.SC$1.PropertyChangedEventArgs().$ctor$2("Devices"));
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(249110194077)
                    
                    //--TRIMMABLE-BOUNDARY-START(270585030557)
                    /*Task */ UpdateDevice(/*params IIOTDevice[]*/ devices)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(270585030557);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Factory.UpdateDevice(this, devices);
                    }
                    //--TRIMMABLE-BOUNDARY-END(270585030557)
                    
                    //--TRIMMABLE-BOUNDARY-START(55836665757)
                    /*Task *//*async*/  DeleteDevice(/*params IIOTDevice[]*/ devices)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t64, $r64;
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(55836665757);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            ($t64 = this.Factory.DeleteDevice(this, devices).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t64, { set $v($v) { $r64 = $v; } }) ? $r64 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t64)));
                            let $i65 = 0;
                            let $arr65 = devices;
                            while ($i65 < $arr65.length)
                            {
                                let device = $arr65[$i65++];
                                this.Devices.Remove$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDevice), [ device ], null, null));
                            }
                            this.PropertyChanged?.Invoke(this, new $.$so.SC$1.PropertyChangedEventArgs().$ctor$2("Devices"));
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(55836665757)
                    
                    //--TRIMMABLE-BOUNDARY-START(253405161373)
                    /*Task */ Scan(/*Action<DiscoveredIOTDevice>*/ found)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(253405161373);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$$.STT.Task.CompletedTask;
                    }
                    //--TRIMMABLE-BOUNDARY-END(253405161373)
                    
                    //--TRIMMABLE-BOUNDARY-START(103107761553)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope.Name.get
                    get LCICI$IIOTDeviceScope$Name()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(133172532625);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Name;
                    }
                    //--TRIMMABLE-BOUNDARY-END(103107761553)
                    
                    //--TRIMMABLE-BOUNDARY-START(77337957777)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope.Icon.get
                    get LCICI$IIOTDeviceScope$Icon()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(120287630737);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Icon;
                    }
                    //--TRIMMABLE-BOUNDARY-END(77337957777)
                    
                    //--TRIMMABLE-BOUNDARY-START(85927892369)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope.Image.get
                    get LCICI$IIOTDeviceScope$Image()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(124582598033);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Image;
                    }
                    //--TRIMMABLE-BOUNDARY-END(85927892369)
                    
                    //--TRIMMABLE-BOUNDARY-START(42978219409)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope.ApplicationLink.get
                    get LCICI$IIOTDeviceScope$ApplicationLink()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8618481041);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ApplicationLink;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42978219409)
                    
                    //--TRIMMABLE-BOUNDARY-START(51568154001)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope.ConnectionIdentifiers.get
                    get LCICI$IIOTDeviceScope$ConnectionIdentifiers()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17208415633);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ConnectionIdentifiers;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51568154001)
                    
                    //--TRIMMABLE-BOUNDARY-START(60158088593)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope.Devices.get
                    get LCICI$IIOTDeviceScope$Devices()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25798350225);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Devices;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60158088593)
                    
                    //--TRIMMABLE-BOUNDARY-START(141762467217)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope.Scan(System.Action<LivingThing.Core.IOT.Common.Interface.DiscoveredIOTDevice>)
                    LCICI$IIOTDeviceScope$Scan()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(141762467217);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Scan(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(141762467217)
                    
                    //--TRIMMABLE-BOUNDARY-START(4323513745)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope.AddDevices(LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel[], bool)
                    LCICI$IIOTDeviceScope$AddDevices()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4323513745);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.AddDevices(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4323513745)
                    
                    //--TRIMMABLE-BOUNDARY-START(137467499921)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope.RemoveDevice(params LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel[])
                    LCICI$IIOTDeviceScope$RemoveDevice()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(137467499921);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.RemoveDevice(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(137467499921)
                    
                    //--TRIMMABLE-BOUNDARY-START(150352401809)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope.UpdateDevice(params LivingThing.Core.IOT.Common.Interface.IIOTDevice[])
                    LCICI$IIOTDeviceScope$UpdateDevice()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(150352401809);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.UpdateDevice(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(150352401809)
                    
                    //--TRIMMABLE-BOUNDARY-START(21503382929)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope.DeleteDevice(params LivingThing.Core.IOT.Common.Interface.IIOTDevice[])
                    LCICI$IIOTDeviceScope$DeleteDevice()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21503382929);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeleteDevice(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21503382929)
                    
                    //--TRIMMABLE-BOUNDARY-START(12913448337)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope.ClearDevices()
                    LCICI$IIOTDeviceScope$ClearDevices()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12913448337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ClearDevices(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12913448337)
                    
                    //--TRIMMABLE-BOUNDARY-START(30093317521)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope.EnsureLoaded()
                    LCICI$IIOTDeviceScope$EnsureLoaded()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30093317521);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.EnsureLoaded(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(30093317521)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591114258)
                    //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
                    SC$1$INotifyPropertyChanged$add_PropertyChanged()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8591114258);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.add_PropertyChanged(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591114258)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476016146)
                    //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
                    SC$1$INotifyPropertyChanged$remove_PropertyChanged()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476016146);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.remove_PropertyChanged(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476016146)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886081554)
                    //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
                    System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886081554);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.PropertyChanged;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886081554)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(236225292189)
                        this.ready = new $.$$.STT.TaskCompletionSource().$ctor$1();
                        //--TRIMMABLE-BOUNDARY-END(236225292189)
                        
                    }
                    static $H = 2090909;
                    static $h = 2090909;
                    static $f = 0b10000000001110001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51541698461),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90196404125,
        "h": Number(BigInt(2090909)|0x1500000000n),
        "f": 50331777
      },
      "n": "ConnectionIdentifiers",
      "d": 2090909,
      "H": 51541698461,
      "h": Number(BigInt(2090909)|0xC00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(51541698461),
//--TRIMMABLE-BOUNDARY-START(257700128669),
    {
      "p": 1545617,
      "g": {
        "r": 0,
        "d": 0,
        "H": 158915880861,
        "h": Number(BigInt(2090909)|0x2500000000n),
        "f": 50331649
      },
      "n": "ScopeStore",
      "d": 2090909,
      "H": 257700128669,
      "h": Number(BigInt(2090909)|0x3C00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257700128669),
//--TRIMMABLE-BOUNDARY-START(64426600349),
    {
      "p": 1283473,
      "g": {
        "r": 0,
        "d": 0,
        "H": 107376273309,
        "h": Number(BigInt(2090909)|0x1900000000n),
        "f": 50331649
      },
      "n": "DeviceStore",
      "d": 2090909,
      "H": 64426600349,
      "h": Number(BigInt(2090909)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426600349),
//--TRIMMABLE-BOUNDARY-START(73016534941),
    {
      "p": 2156445,
      "g": {
        "r": 0,
        "d": 0,
        "H": 115966207901,
        "h": Number(BigInt(2090909)|0x1B00000000n),
        "f": 50331649
      },
      "n": "Factory",
      "d": 2090909,
      "H": 73016534941,
      "h": Number(BigInt(2090909)|0x1100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016534941),
//--TRIMMABLE-BOUNDARY-START(227635357597),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 150325946269,
        "h": Number(BigInt(2090909)|0x2300000000n),
        "f": 50331777
      },
      "n": "Name",
      "d": 2090909,
      "H": 227635357597,
      "h": Number(BigInt(2090909)|0x3500000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(227635357597),
//--TRIMMABLE-BOUNDARY-START(223340390301),
    {
      "p": TDeviceScopeModel?.$h??1966080,
      "g": {
        "r": 0,
        "d": 0,
        "H": 141736011677,
        "h": Number(BigInt(2090909)|0x2100000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 266290063261,
        "h": Number(BigInt(2090909)|0x3E00000000n),
        "f": 83886081
      },
      "n": "Model",
      "d": 2090909,
      "H": 223340390301,
      "h": Number(BigInt(2090909)|0x3400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(223340390301),
//--TRIMMABLE-BOUNDARY-START(219045423005),
    {
      "p": 52860305,
      "g": {
        "r": 0,
        "d": 0,
        "H": 206160521117,
        "h": Number(BigInt(2090909)|0x3000000000n),
        "f": 50331650
      },
      "n": "{28546449}.Settings",
      "o": "LCICI$IIOTDeviceScope$Settings",
      "d": 2090909,
      "H": 219045423005,
      "h": Number(BigInt(2090909)|0x3300000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(219045423005),
//--TRIMMABLE-BOUNDARY-START(214750455709),
    {
      "p": 34837905,
      "g": {
        "r": 0,
        "d": 0,
        "H": 197570586525,
        "h": Number(BigInt(2090909)|0x2E00000000n),
        "f": 50331650
      },
      "n": "{28546449}.Model",
      "o": "LCICI$IIOTDeviceScope$Model",
      "d": 2090909,
      "H": 214750455709,
      "h": Number(BigInt(2090909)|0x3200000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(214750455709),
//--TRIMMABLE-BOUNDARY-START(60131633053),
    {
      "p": $.$fPer.LCFCR.ReactiveObservableCollection$$($.$XBGm.LCICI.IIOTDevice).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 98786338717,
        "h": Number(BigInt(2090909)|0x1700000000n),
        "f": 50331649
      },
      "n": "Devices",
      "d": 2090909,
      "H": 60131633053,
      "h": Number(BigInt(2090909)|0xE00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131633053),
//--TRIMMABLE-BOUNDARY-START(180390717341),
    {
      "p": 28611985,
      "g": {
        "r": 0,
        "d": 0,
        "H": 188980651933,
        "h": Number(BigInt(2090909)|0x2C00000000n),
        "f": 50331650
      },
      "n": "{28546449}.Factory",
      "o": "LCICI$IIOTDeviceScope$Factory",
      "d": 2090909,
      "H": 180390717341,
      "h": Number(BigInt(2090909)|0x2A00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(180390717341),
//--TRIMMABLE-BOUNDARY-START(171800782749),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 124556142493,
        "h": Number(BigInt(2090909)|0x1D00000000n),
        "f": 50331777
      },
      "n": "Icon",
      "d": 2090909,
      "H": 171800782749,
      "h": Number(BigInt(2090909)|0x2800000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(171800782749),
//--TRIMMABLE-BOUNDARY-START(176095750045),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 133146077085,
        "h": Number(BigInt(2090909)|0x1F00000000n),
        "f": 50331777
      },
      "n": "Image",
      "d": 2090909,
      "H": 176095750045,
      "h": Number(BigInt(2090909)|0x2900000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(176095750045),
//--TRIMMABLE-BOUNDARY-START(38656796573),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81606469533,
        "h": Number(BigInt(2090909)|0x1300000000n),
        "f": 50331777
      },
      "n": "ApplicationLink",
      "d": 2090909,
      "H": 38656796573,
      "h": Number(BigInt(2090909)|0x900000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(38656796573)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68721567645),
    {
      "r": 178454529,
      "n": "EnsureLoaded",
      "d": 2090909,
      "H": 68721567645,
      "h": Number(BigInt(2090909)|0x1000000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68721567645),
//--TRIMMABLE-BOUNDARY-START(42951763869),
    {
      "r": 65537,
      "p": [
        {
          "n": "_devices",
          "p": $.$$.SCG.IEnumerable$$(TDeviceModel).$h
        }
      ],
      "n": "BeginLoad",
      "d": 2090909,
      "H": 42951763869,
      "h": Number(BigInt(2090909)|0xA00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(42951763869),
//--TRIMMABLE-BOUNDARY-START(47246731165),
    {
      "r": 178454529,
      "n": "ClearDevices",
      "d": 2090909,
      "H": 47246731165,
      "h": Number(BigInt(2090909)|0xB00000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(47246731165),
//--TRIMMABLE-BOUNDARY-START(167505815453),
    {
      "r": $.$$.STT.Task$$($.$NXre.LCID.SmartDeviceBase).$h,
      "p": [
        {
          "n": "model",
          "p": TDeviceModel?.$h??2162688
        }
      ],
      "n": "GetOrCreateDevice",
      "d": 2090909,
      "H": 167505815453,
      "h": Number(BigInt(2090909)|0x2700000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(167505815453),
//--TRIMMABLE-BOUNDARY-START(163210848157),
    {
      "r": $.$$.STT.Task$$(TSmartDevice).$h,
      "p": [
        {
          "n": "model",
          "p": TDeviceModel?.$h??2162688
        }
      ],
      "n": "GetDevice",
      "d": 2090909,
      "H": 163210848157,
      "h": Number(BigInt(2090909)|0x2600000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(163210848157),
//--TRIMMABLE-BOUNDARY-START(34361829277),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDevice)).$h,
      "p": [
        {
          "n": "models",
          "p": $.$typeArray($.$XBGm.LCICI.IIOTDeviceModel).$h
        },
        {
          "n": "persist",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "AddDevices",
      "d": 2090909,
      "H": 34361829277,
      "h": Number(BigInt(2090909)|0x800000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(34361829277),
//--TRIMMABLE-BOUNDARY-START(249110194077),
    {
      "r": 178454529,
      "p": [
        {
          "n": "models",
          "p": $.$typeArray($.$XBGm.LCICI.IIOTDeviceModel).$h,
          "f": 16
        }
      ],
      "n": "RemoveDevice",
      "d": 2090909,
      "H": 249110194077,
      "h": Number(BigInt(2090909)|0x3A00000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(249110194077),
//--TRIMMABLE-BOUNDARY-START(270585030557),
    {
      "r": 178454529,
      "p": [
        {
          "n": "devices",
          "p": $.$typeArray($.$XBGm.LCICI.IIOTDevice).$h,
          "f": 16
        }
      ],
      "n": "UpdateDevice",
      "d": 2090909,
      "H": 270585030557,
      "h": Number(BigInt(2090909)|0x3F00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(270585030557),
//--TRIMMABLE-BOUNDARY-START(55836665757),
    {
      "r": 178454529,
      "p": [
        {
          "n": "devices",
          "p": $.$typeArray($.$XBGm.LCICI.IIOTDevice).$h,
          "f": 16
        }
      ],
      "n": "DeleteDevice",
      "d": 2090909,
      "H": 55836665757,
      "h": Number(BigInt(2090909)|0xD00000000n),
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(55836665757),
//--TRIMMABLE-BOUNDARY-START(253405161373),
    {
      "r": 178454529,
      "p": [
        {
          "n": "found",
          "p": $.$$.S.Action$$($.$XBGm.LCICI.DiscoveredIOTDevice).$h
        }
      ],
      "n": "Scan",
      "d": 2090909,
      "H": 253405161373,
      "h": Number(BigInt(2090909)|0x3B00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(253405161373)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297058205),
    {
      "t": $.$$.SCG.IEnumerable$$(TDeviceModel).$h,
      "n": "_deviceModels",
      "d": 2090909,
      "H": 4297058205,
      "h": Number(BigInt(2090909)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297058205),
//--TRIMMABLE-BOUNDARY-START(236225292189),
    {
      "t": 179568641,
      "n": "ready",
      "d": 2090909,
      "H": 236225292189,
      "h": Number(BigInt(2090909)|0x3700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(236225292189),
//--TRIMMABLE-BOUNDARY-START(8592025501),
    {
      "t": $.$fPer.LCFCR.ReactiveObservableCollection$$($.$XBGm.LCICI.IIOTDevice).$h,
      "n": "_devices",
      "d": 2090909,
      "H": 8592025501,
      "h": Number(BigInt(2090909)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592025501)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476927389),
    {
      "p": [
        {
          "n": "factory",
          "p": 2156445
        },
        {
          "n": "scope",
          "p": TDeviceScopeModel?.$h??1966080
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$(TDeviceModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2090909,
      "H": 21476927389,
      "h": Number(BigInt(2090909)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476927389)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(231930324893),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 2090909,
        "H": 30066861981,
        "h": Number(BigInt(2090909)|0x700000000n),
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 2090909,
        "H": 244815226781,
        "h": Number(BigInt(2090909)|0x3900000000n),
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 2090909,
      "H": 231930324893,
      "h": Number(BigInt(2090909)|0x3600000000n),
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(231930324893)
  ],
  "d": 1697693,
  "H": 2090909,
  "h": 2090909
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScope, $.$so.SC$1.INotifyPropertyChanged ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>+SmartGenericDeviceScope`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TDeviceScopeModel?.$getFullName(separator)}$${TDeviceScopeSettings?.$getFullName(separator)}$${TDeviceScopeStates?.$getFullName(separator)}$${TDeviceModel?.$getFullName(separator)}$${TDeviceSettings?.$getFullName(separator)}$${TDeviceHardwareSettings?.$getFullName(separator)}$${TDeviceStates?.$getFullName(separator)}$${TDeviceStatusModel?.$getFullName(separator)}$${TDeviceCommandModel?.$getFullName(separator)}$${TDeviceReceivedDataModel?.$getFullName(separator)}$${TDeviceSendDataModel?.$getFullName(separator)}$${TDeviceStatusHandler?.$getFullName(separator)}$${TServiceHubClient?.$getFullName(separator)}$${TServicesRemoteService?.$getFullName(separator)}$${TDeviceGlobalSettings?.$getFullName(separator)}$${separator}SmartGenericDeviceScope`; }
                }, $cls, ($v) => $cls.$_SmartGenericDeviceScope = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2090909)
            
            //--TRIMMABLE-BOUNDARY-START(2221981)
            static $_SmartGenericDeviceServiceAsScope;
            static get SmartGenericDeviceServiceAsScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2221981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings);
                return $cls.$_SmartGenericDeviceServiceAsScope ??= $asm.$ncls(`$NXre.LCID.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>.SmartGenericDeviceServiceAsScope`, ($self) => class SmartGenericDeviceServiceAsScope extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDeviceScope
                {
                    //--TRIMMABLE-BOUNDARY-START(8592156573)
                    $ctor$3(/*SmartGenericDeviceScopeFactory*/ factory, /*TServiceModel*/ service)
                    {
                        super.$ctor$1(factory, new ($.$$.S.Func$$(TDeviceScopeModel))().$ctor(this,  () =>
                        {
                            /*System.Collections.Generic.IEnumerable<TDeviceModel>?*/ let __ca1__;
                            return (() =>
                            {
                                //new TDeviceScopeModel()
                                const $t66 = TDeviceScopeModel.$isProxy === true ? TDeviceScopeModel.$prototype : TDeviceScopeModel;
                                const $i66 = new $t66();
                                $i66.$ctor$8();
                                $i66.Name = service.Name;
                                $i66.ServiceId = service.Identifier;
                                $i66.Devices = ((__ca1__ = service.Devices) !== null ? $.$sl.SL.Enumerable.Select$1(TDeviceModel, $.$fPer.LCFCD.DataId, __ca1__, new ($.$$.S.Func$$$(TDeviceModel, $.$fPer.LCFCD.DataId))().$ctor(this,  (/*s*/ s) =>
                                {
                                    return s.Identifier;
                                }, $iQLhpc ??= {"r":10455382,"p":[{"n":"s","p":TDeviceModel?.$h??2162688}],"n":"","d":2221981,"H":0,"h":0,"f":17825794})) : null);
                                return $i66;
                            })();
                        }, $pWqXgi ??= {"r":TDeviceScopeModel?.$h??1966080,"n":"","d":2221981,"H":0,"h":0,"f":17825794}).Invoke(), service.Devices ?? $.$sl.SL.Enumerable.Empty(TDeviceModel));
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592156573);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592156573)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297189277)
                    $ctor$2(/*SmartGenericDeviceScopeFactory*/ factory, /*TDeviceScopeModel*/ scope, /*IEnumerable<TDeviceModel>*/ devices)
                    {
                        super.$ctor$1(factory, scope, devices);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297189277);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297189277)
                    
                    static $H = 2221981;
                    static $h = 2221981;
                    static $f = 0b10000000001110001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDeviceScope; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592156573),
    {
      "p": [
        {
          "n": "factory",
          "p": 2156445
        },
        {
          "n": "service",
          "p": TServiceModel?.$h??1638400
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2221981,
      "H": 8592156573,
      "h": Number(BigInt(2221981)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8592156573),
//--TRIMMABLE-BOUNDARY-START(4297189277),
    {
      "p": [
        {
          "n": "factory",
          "p": 2156445
        },
        {
          "n": "scope",
          "p": TDeviceScopeModel?.$h??1966080
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$(TDeviceModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2221981,
      "H": 4297189277,
      "h": Number(BigInt(2221981)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297189277)
  ],
  "d": 1697693,
  "H": 2221981,
  "h": 2221981
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScope, $.$so.SC$1.INotifyPropertyChanged ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>+SmartGenericDeviceServiceAsScope`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TDeviceScopeModel?.$getFullName(separator)}$${TDeviceScopeSettings?.$getFullName(separator)}$${TDeviceScopeStates?.$getFullName(separator)}$${TDeviceModel?.$getFullName(separator)}$${TDeviceSettings?.$getFullName(separator)}$${TDeviceHardwareSettings?.$getFullName(separator)}$${TDeviceStates?.$getFullName(separator)}$${TDeviceStatusModel?.$getFullName(separator)}$${TDeviceCommandModel?.$getFullName(separator)}$${TDeviceReceivedDataModel?.$getFullName(separator)}$${TDeviceSendDataModel?.$getFullName(separator)}$${TDeviceStatusHandler?.$getFullName(separator)}$${TServiceHubClient?.$getFullName(separator)}$${TServicesRemoteService?.$getFullName(separator)}$${TDeviceGlobalSettings?.$getFullName(separator)}$${separator}SmartGenericDeviceServiceAsScope`; }
                }, $cls, ($v) => $cls.$_SmartGenericDeviceServiceAsScope = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2221981)
            
            //--TRIMMABLE-BOUNDARY-START(1763229)
            static $_ConfiguredDeviceFamily;
            static get ConfiguredDeviceFamily()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1763229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings);
                return $cls.$_ConfiguredDeviceFamily ??= $asm.$ncls(`$NXre.LCID.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>.ConfiguredDeviceFamily`, ($self) => class ConfiguredDeviceFamily extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(541167642525)
                    /*void */ ResolveImagePath(/*ProductCatalogue*/ catalogue)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(541167642525);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*string?*/ let __ca1__;
                        if ((__ca1__ = catalogue.BannerImage) !== null ? $.$$.S.String.StartsWith$3.call(__ca1__, "~/") : false)
                        {
                            catalogue.BannerImage = $.$NXre.LCID.Utility.ResolvePath(catalogue.BannerImage, this);
                        }
                        /*System.Collections.Generic.IEnumerable<string>?*/ let __ca2__;
                        if ((__ca2__ = catalogue.Images) !== null ? $.$sl.SL.Enumerable.Any($.$$.S.String, __ca2__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*im*/ im) =>
                        {
                            return $.$$.S.String.StartsWith$3.call(im, "~/");
                        }, $ESbOid ??= {"r":262145,"p":[{"n":"im","p":1310721}],"n":"","d":1763229,"H":0,"h":0,"f":17825794})) : false)
                        {
                            /*List<string>*/ let images = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                            let $en67 = catalogue.Images.SCG$IEnumerable$$$GetEnumerator();
                            while ($en67.SC$1$IEnumerator$MoveNext())
                            {
                                let img = $en67.SCG$IEnumerator$$$Current;
                                {
                                    if ($.$$.S.String.StartsWith$3.call(img, "~/"))
                                    {
                                        images.Add($.$NXre.LCID.Utility.ResolvePath(img, this));
                                    }
                                    else 
                                    {
                                        images.Add(img);
                                    }
                                }
                            }
                            catalogue.Images = images.ToArray();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(541167642525)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656468893)
                    /*IConfigurationParser?*/ config = null;
                    //--TRIMMABLE-BOUNDARY-END(38656468893)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066534301)
                    $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<TDeviceReceivedDataModel, TDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<TDeviceReceivedDataModel, TDeviceStatusModel>*/ converter)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30066534301);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.config = config;
                            this.Protocol = protocol;
                            this.Converter = converter;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066534301)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361501597)
                    $ctor$2(/*IOTDeviceDescriptor<TServiceTierType, TServiceFeatureType>*/ descriptor, /*IOTDeviceProtocol<TDeviceReceivedDataModel, TDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<TDeviceReceivedDataModel, TDeviceStatusModel>*/ converter)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34361501597);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.NormalizeDescriptor(descriptor);
                            this.descriptor = descriptor;
                            this.Protocol = protocol;
                            this.Converter = converter;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361501597)
                    
                    //--TRIMMABLE-BOUNDARY-START(571232413597)
                    /*IEnumerable<ServiceTierModel<TServiceTierType, TServiceFeatureType>> */ get ServiceTiersFromSchema()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(429498492829);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), $.$sl.SL.Enumerable.Where($.$$.S.String, $.$$.S.Enum.GetNames(TServiceTierType.$type), new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                        {
                            return t !== "None";
                        }, $cRzJwe ??= {"r":262145,"p":[{"n":"t","p":1310721}],"n":"","d":1763229,"H":0,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.String, $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)))().$ctor(this,  (/*s*/ s) =>
                        {
                            /*TServiceTierType*/ let tier = $.$$.S.Enum.Parse$7(TServiceTierType, s);
                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Attributes.SchemaAttribute>?*/ let __ca3__;
                            /*var*/ let schema = ((__ca3__ = $.$fPer.LCFCT.EnumExtensions.GetEnumAttributes($.$fPer.LCFCA$1.SchemaAttribute, tier)) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$fPer.LCFCA$1.SchemaAttribute, __ca3__) : null);
                            /*System.Collections.Generic.IEnumerable<System.ComponentModel.DescriptionAttribute>?*/ let __ca4__;
                            /*var*/ let description = ((__ca4__ = $.$fPer.LCFCT.EnumExtensions.GetEnumAttributes($.$scp.SC.DescriptionAttribute, tier)) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$scp.SC.DescriptionAttribute, __ca4__) : null);
                            /*double*/ let amount = 0;
                            /*LivingThing.Core.Frameworks.Common.Attributes.SchemaAttribute?*/ let __ca5__;
                            /*string[]?*/ let __ca6__;
                            /*string?*/ let __ca7__;
                            /*var*/ let _amt = ((__ca5__ = schema) !== null ? ((__ca6__ = __ca5__.Options) !== null ? ((__ca7__ = $.$sl.SL.Enumerable.SingleOrDefault$1($.$$.S.String, __ca6__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*o*/ o) =>
                            {
                                return $.$$.S.String.StartsWith$3.call(o, "//Amount=");
                            }, $gugNOg ??= {"r":262145,"p":[{"n":"o","p":1310721}],"n":"","d":1763229,"H":0,"h":0,"f":17825794}))) !== null ? $.$$.System.Array.$ReadT1.call($.$$.S.String.Split$1.call(__ca7__, /*=*/ 61, 0), 1) : null) : null) : null);
                            if (_amt !== null)
                            {
                                amount = $.$$.S.Double.Parse$7(_amt);
                            }
                            /*int*/ let limit = 0;
                            /*string?*/ let __ca10__;
                            /*LivingThing.Core.Frameworks.Common.Attributes.SchemaAttribute?*/ let __ca8__;
                            /*string[]?*/ let __ca9__;
                            /*var*/ let _lmt = ((__ca8__ = schema) !== null ? ((__ca9__ = __ca8__.Options) !== null ? ((__ca10__ = $.$sl.SL.Enumerable.SingleOrDefault$1($.$$.S.String, __ca9__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*o*/ o) =>
                            {
                                return $.$$.S.String.StartsWith$3.call(o, "//Limit=");
                            }, $hGxvva ??= {"r":262145,"p":[{"n":"o","p":1310721}],"n":"","d":1763229,"H":0,"h":0,"f":17825794}))) !== null ? $.$$.System.Array.$ReadT1.call($.$$.S.String.Split$1.call(__ca10__, /*=*/ 61, 0), 1) : null) : null) : null);
                            if (_lmt !== null)
                            {
                                limit = $.$$.S.Int32.Parse$7(_lmt);
                            }
                            /*TServiceFeatureType*/ let features = $.$default(TServiceFeatureType);
                            /*LivingThing.Core.Frameworks.Common.Attributes.SchemaAttribute?*/ let __ca11__;
                            /*string[]?*/ let __ca12__;
                            /*string?*/ let __ca13__;
                            /*var*/ let _f = ((__ca11__ = schema) !== null ? ((__ca12__ = __ca11__.Options) !== null ? ((__ca13__ = $.$sl.SL.Enumerable.SingleOrDefault$1($.$$.S.String, __ca12__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*o*/ o) =>
                            {
                                return $.$$.S.String.StartsWith$3.call(o, "//Features=");
                            }, $WOHnjl ??= {"r":262145,"p":[{"n":"o","p":1310721}],"n":"","d":1763229,"H":0,"h":0,"f":17825794}))) !== null ? $.$$.System.Array.$ReadT1.call($.$$.S.String.Split$1.call(__ca13__, /*=*/ 61, 0), 1) : null) : null) : null);
                            if (_f !== null)
                            {
                                features = $.$$.S.Enum.Parse$7(TServiceFeatureType, _f);
                            }
                            /*LivingThing.Core.Frameworks.Common.Attributes.SchemaAttribute?*/ let __ca14__;
                            /*string[]?*/ let __ca15__;
                            /*string?*/ let __ca16__;
                            return (() =>
                            {
                                //new $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)()
                                const $t68 = $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType);
                                const $i68 = new $t68();
                                $i68.$ctor$2();
                                $i68.Name = (schema?.Title ?? null) ?? s;
                                $i68.Description = (schema?.Description ?? null) ?? (description?.Description ?? null);
                                $i68.ServiceType = tier;
                                $i68.Cost = $.$fPer.LCFCDM.Money.op_Implicit$1(amount);
                                $i68.AmountQualification = ((__ca14__ = schema) !== null ? ((__ca15__ = __ca14__.Options) !== null ? ((__ca16__ = $.$sl.SL.Enumerable.SingleOrDefault$1($.$$.S.String, __ca15__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*o*/ o) =>
                                {
                                    return $.$$.S.String.StartsWith$3.call(o, "//Rate=");
                                }, $MEyeIa ??= {"r":262145,"p":[{"n":"o","p":1310721}],"n":"","d":1763229,"H":0,"h":0,"f":17825794}))) !== null ? $.$$.System.Array.$ReadT1.call($.$$.S.String.Split$1.call(__ca16__, /*=*/ 61, 0), 1) : null) : null) : null);
                                $i68.ServiceFeatures = features;
                                $i68.Limit = limit;
                                $i68.LimitQuantification = "devices";
                                $i68.LimitLabel = "Devices";
                                $i68.Schema = schema;
                                return $i68;
                            })();
                        }, $jEaYXc ??= {"r":$.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType).$h,"p":[{"n":"s","p":1310721}],"n":"","d":1763229,"H":0,"h":0,"f":17825794}));
                    }
                    //--TRIMMABLE-BOUNDARY-END(571232413597)
                    
                    //--TRIMMABLE-BOUNDARY-START(523987773341)
                    /*string?*/ name = null;
                    //--TRIMMABLE-BOUNDARY-END(523987773341)
                    
                    //--TRIMMABLE-BOUNDARY-START(528282740637)
                    /*string */ get Name()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(360779016093);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*LivingThing.Core.IOT.Common.Models.IOTDeviceDescriptor<TServiceTierType, TServiceFeatureType>?*/ let __ca17__;
                        /*string*/ let __ca18__;
                        return this.name ??= ((__ca17__ = this.DeviceDescriptor) !== null ? (((__ca18__ = __ca17__.Name) !== null ? ($.$$.S.String.Replace$3.call(__ca18__, " ", "") ?? $.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.Object.GetType.call(this).Name, "Device", ""), "Family", "")) : $.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.Object.GetType.call(this).Name, "Device", ""), "Family", "")) ?? $.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.Object.GetType.call(this).Name, "Device", ""), "Family", "")) : $.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.Object.GetType.call(this).Name, "Device", ""), "Family", ""));
                    }
                    //--TRIMMABLE-BOUNDARY-END(528282740637)
                    
                    //--TRIMMABLE-BOUNDARY-START(579822348189)
                    /*string */ get Title()
                    {
                        return $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle(this.Name);
                    }
                    //--TRIMMABLE-BOUNDARY-END(579822348189)
                    
                    //--TRIMMABLE-BOUNDARY-START(68721239965)
                    /*IOTDeviceDescriptor<TServiceTierType, TServiceFeatureType>?*/ descriptor = null;
                    //--TRIMMABLE-BOUNDARY-END(68721239965)
                    
                    //--TRIMMABLE-BOUNDARY-START(532577707933)
                    /*void */ NormalizeDescriptor(/*IOTDeviceDescriptor<TServiceTierType, TServiceFeatureType>*/ descriptor)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(532577707933);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        descriptor.CommunicationProtocol ??= new $.$XBGm.LCICPM.IOTDeviceCommunicationProtocolDescriptor().$ctor$1();
                        if (descriptor.CommunicationProtocol.MessageTypes === null)
                        {
                            /*var*/ let dataPoints = $.$sl.SL.Enumerable.Cast($.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor, $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCD$1.PropertyDesciptorChain, $.$fPer.LCFCD$1.IPropertyDescriptor, $.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor.GetFlattenedPropertyDescriptors(this.DevicePresentationDataModelType, 64/*SchemaType.DataPoint*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCO.OneOf$$$$($.$$.S.Object, $.$$.S.Func$$($.$$.S.Object), $.$fPer.LCFCD.IValueProvider)), [  ], null, null)), new ($.$$.S.Func$$$($.$fPer.LCFCD$1.PropertyDesciptorChain, $.$fPer.LCFCD$1.IPropertyDescriptor))().$ctor(this,  (/*d*/ d) =>
                            {
                                return d.Property;
                            }, $FlFCBi ??= {"r":40733014,"p":[{"n":"d","p":41978198}],"n":"","d":1763229,"H":0,"h":0,"f":17825794})));
                            descriptor.CommunicationProtocol.MessageTypes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICPM.IOTDeviceProtocolStatusMessageTypeDescriptor), [(() =>
                            {
                                //new $.$XBGm.LCICPM.IOTDeviceProtocolStatusMessageTypeDescriptor()
                                const $t69 = $.$XBGm.LCICPM.IOTDeviceProtocolStatusMessageTypeDescriptor;
                                const $i69 = new $t69();
                                $i69.$ctor$2();
                                $i69.Name = this.DeviceReceivedDataType.Name;
                                $i69.DataPoints = dataPoints;
                                return $i69;
                            })()], [-1], null);
                        }
                        if (descriptor.ServiceTiers === null)
                        {
                            descriptor.ServiceTiers = $.$sl.SL.Enumerable.ToList($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), this.ServiceTiersFromSchema);
                        }
                        if (descriptor.Description$1 === null)
                        {
                            descriptor.Description$1 = ($.$$.SR.CustomAttributeExtensions.GetCustomAttribute$8($.$fPer.LCFCA$1.SchemaAttribute, TServiceTierType.$type)?.Description ?? null) ?? ($.$$.SR.CustomAttributeExtensions.GetCustomAttribute$8($.$scp.SC.DescriptionAttribute, TServiceTierType.$type)?.Description ?? null);
                        }
                        this.ResolveImagePath(descriptor);
                        if (descriptor.Accessories$1 !== null)
                        {
                            let $en70 = descriptor.Accessories$1.SCG$IEnumerable$$$GetEnumerator();
                            while ($en70.SC$1$IEnumerator$MoveNext())
                            {
                                let acc = $en70.SCG$IEnumerator$$$Current;
                                {
                                    this.ResolveImagePath(acc);
                                }
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(532577707933)
                    
                    //--TRIMMABLE-BOUNDARY-START(592707250077)
                    /*void */ UpdateDescriptor(/*IOTDeviceDescriptor<TServiceTierType, TServiceFeatureType>*/ descriptor)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(592707250077);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.descriptor = descriptor;
                    }
                    //--TRIMMABLE-BOUNDARY-END(592707250077)
                    
                    //--TRIMMABLE-BOUNDARY-START(85901109149)
                    /*IOTDeviceDescriptor<TServiceTierType, TServiceFeatureType>? */ get DeviceDescriptor()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(214750128029);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this.descriptor !== null)
                        {
                            return this.descriptor;
                        }
                        this.descriptor = this.config.LCFCC$1$IConfigurationParser$GetValue($.$XBGm.LCICM.IOTDeviceDescriptor$$$(TServiceTierType, TServiceFeatureType), `Devices/${$.$strNN(TSmartDevice.$type.FullName)}`, null);
                        this.descriptor ??= new ($.$XBGm.LCICM.IOTDeviceDescriptor$$$(TServiceTierType, TServiceFeatureType))().$ctor$11();
                        this.NormalizeDescriptor(this.descriptor);
                        return this.descriptor;
                    }
                    //--TRIMMABLE-BOUNDARY-END(85901109149)
                    
                    //--TRIMMABLE-BOUNDARY-START(459563263901)
                    /*IOTDeviceDescriptor? */ GetDescriptorVariant(/*IIOTDeviceModel*/ device)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(459563263901);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceDescriptor;
                    }
                    //--TRIMMABLE-BOUNDARY-END(459563263901)
                    
                    //--TRIMMABLE-BOUNDARY-START(489628034973)
                    /*IOTDeviceDescriptor? */ get LCICI$IIOTDeviceFamily$DeviceDescriptor()
                    {
                        return this.DeviceDescriptor;
                    }
                    //--TRIMMABLE-BOUNDARY-END(489628034973)
                    
                    //--TRIMMABLE-BOUNDARY-START(588412282781)
                    /*Pager<ServiceTierModel<TServiceTierType, TServiceFeatureType>> */ get TypedServiceTiers()
                    {
                        return $.$fPer.LCFCD.Paging.GetPager($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), ((this.DeviceDescriptor?.ServiceTiers ?? null) ?? $.$sl.SL.Enumerable.Empty($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType))), null);
                    }
                    //--TRIMMABLE-BOUNDARY-END(588412282781)
                    
                    //--TRIMMABLE-BOUNDARY-START(566937446301)
                    /*Pager<ServiceTierModel> */ get ServiceTiers()
                    {
                        return $.$fPer.LCFCD.Paging.Cast$1($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType), $.$AvdQ.LCFCP.ServiceTierModel, this.TypedServiceTiers);
                    }
                    //--TRIMMABLE-BOUNDARY-END(566937446301)
                    
                    //--TRIMMABLE-BOUNDARY-START(481038100381)
                    /*Pager<ServiceTierModel<TServiceTierType, TServiceFeatureType>> */ get LCFCP$ICatalogueProvider$$$$ServiceTiers()
                    {
                        return this.TypedServiceTiers;
                    }
                    //--TRIMMABLE-BOUNDARY-END(481038100381)
                    
                    //--TRIMMABLE-BOUNDARY-START(536872675229)
                    /*IIOTDeviceProtocol<TDeviceReceivedDataModel, TDeviceSendDataModel>*/ Protocol = null;
                    //--TRIMMABLE-BOUNDARY-END(536872675229)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246403485)
                    /*IIOTDeviceDataConverter<TDeviceReceivedDataModel, TDeviceStatusModel>*/ Converter = null;
                    //--TRIMMABLE-BOUNDARY-END(47246403485)
                    
                    //--TRIMMABLE-BOUNDARY-START(519692806045)
                    /*IIOTDeviceProtocol */ get LCICI$IIOTDeviceFamily$Protocol()
                    {
                        return this.Protocol;
                    }
                    //--TRIMMABLE-BOUNDARY-END(519692806045)
                    
                    //--TRIMMABLE-BOUNDARY-START(485333067677)
                    /*IIOTDeviceDataConverter */ get LCICI$IIOTDeviceFamily$Converter()
                    {
                        return this.Converter;
                    }
                    //--TRIMMABLE-BOUNDARY-END(485333067677)
                    
                    //--TRIMMABLE-BOUNDARY-START(554052544413)
                    /*Type */ get ServiceModelType()
                    {
                        return TServiceModel.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(554052544413)
                    
                    //--TRIMMABLE-BOUNDARY-START(558347511709)
                    /*Type */ get ServiceSettingsType()
                    {
                        return TServiceSettings.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(558347511709)
                    
                    //--TRIMMABLE-BOUNDARY-START(562642479005)
                    /*Type */ get ServiceStatesType()
                    {
                        return TServiceStates.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(562642479005)
                    
                    //--TRIMMABLE-BOUNDARY-START(575527380893)
                    /*Type */ get ServiceTierType()
                    {
                        return TServiceTierType.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(575527380893)
                    
                    //--TRIMMABLE-BOUNDARY-START(545462609821)
                    /*Type */ get ServiceFeatureType()
                    {
                        return TServiceFeatureType.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(545462609821)
                    
                    //--TRIMMABLE-BOUNDARY-START(549757577117)
                    /*Type */ get ServiceHubType()
                    {
                        return TServiceHubClient.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(549757577117)
                    
                    //--TRIMMABLE-BOUNDARY-START(141735683997)
                    /*Type */ get DeviceType()
                    {
                        return TSmartDevice.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(141735683997)
                    
                    //--TRIMMABLE-BOUNDARY-START(98786011037)
                    /*Type */ get DeviceModelType()
                    {
                        return TDeviceModel.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(98786011037)
                    
                    //--TRIMMABLE-BOUNDARY-START(124555814813)
                    /*Type */ get DeviceSettingsType()
                    {
                        return TDeviceSettings.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(124555814813)
                    
                    //--TRIMMABLE-BOUNDARY-START(90196076445)
                    /*Type */ get DeviceHardwareSettingsType()
                    {
                        return TDeviceHardwareSettings.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(90196076445)
                    
                    //--TRIMMABLE-BOUNDARY-START(128850782109)
                    /*Type */ get DeviceStatesType()
                    {
                        return TDeviceStates.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(128850782109)
                    
                    //--TRIMMABLE-BOUNDARY-START(107375945629)
                    /*Type */ get DeviceReceivedDataType()
                    {
                        return TDeviceReceivedDataModel.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(107375945629)
                    
                    //--TRIMMABLE-BOUNDARY-START(120260847517)
                    /*Type */ get DeviceSendDataType()
                    {
                        return TDeviceSendDataModel.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(120260847517)
                    
                    //--TRIMMABLE-BOUNDARY-START(133145749405)
                    /*Type */ get DeviceStatusDataType()
                    {
                        return TDeviceStatusModel.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(133145749405)
                    
                    //--TRIMMABLE-BOUNDARY-START(81606141853)
                    /*Type */ get DeviceCommandDataType()
                    {
                        return TDeviceCommandModel.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(81606141853)
                    
                    //--TRIMMABLE-BOUNDARY-START(137440716701)
                    /*Type */ get DeviceStatusHandlerType()
                    {
                        return TDeviceStatusHandler.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(137440716701)
                    
                    //--TRIMMABLE-BOUNDARY-START(94491043741)
                    /*Type?*/ $DeviceLogType = null;
                    /*Type? */ get DeviceLogType()
                    {
                        return this.$DeviceLogType;
                    }
                     /*Type? */ set DeviceLogType(value)
                    {
                        this.$DeviceLogType = value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(94491043741)
                    
                    //--TRIMMABLE-BOUNDARY-START(115965880221)
                    /*Type?*/ $DeviceScheduleDataType = null;
                    /*Type? */ get DeviceScheduleDataType()
                    {
                        return this.$DeviceScheduleDataType;
                    }
                     /*Type? */ set DeviceScheduleDataType(value)
                    {
                        this.$DeviceScheduleDataType = value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(115965880221)
                    
                    //--TRIMMABLE-BOUNDARY-START(77311174557)
                    /*Type?*/ $DeviceBroadcastSendMessageEnumType = null;
                    /*Type? */ get DeviceBroadcastSendMessageEnumType()
                    {
                        return this.$DeviceBroadcastSendMessageEnumType;
                    }
                     /*Type? */ set DeviceBroadcastSendMessageEnumType(value)
                    {
                        this.$DeviceBroadcastSendMessageEnumType = value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(77311174557)
                    
                    //--TRIMMABLE-BOUNDARY-START(73016207261)
                    /*Type?*/ $DeviceBroadcastReceiveActionType = null;
                    /*Type? */ get DeviceBroadcastReceiveActionType()
                    {
                        return this.$DeviceBroadcastReceiveActionType;
                    }
                     /*Type? */ set DeviceBroadcastReceiveActionType(value)
                    {
                        this.$DeviceBroadcastReceiveActionType = value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(73016207261)
                    
                    //--TRIMMABLE-BOUNDARY-START(111670912925)
                    /*Type */ get DeviceRemoteDataModelType()
                    {
                        return $.$is(this, $.$XBGm.LCICI.IIOTServerDeviceFamily) ? this.DeviceStatusDataType : $.$XBGm.LCICM.IOTDeviceStatusModel.$type;
                    }
                    //--TRIMMABLE-BOUNDARY-END(111670912925)
                    
                    //--TRIMMABLE-BOUNDARY-START(103080978333)
                    /*Type */ get DevicePresentationDataModelType()
                    {
                        return $.$is(this, $.$XBGm.LCICI.IIOTServerDeviceFamily) ? this.DeviceStatusDataType : this.DeviceStatusDataType === $.$XBGm.LCICM.IOTDeviceStatusModel.$type ? this.DeviceReceivedDataType : this.DeviceStatusDataType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(103080978333)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426272669)
                    /*string? */ get Description()
                    {
                        return (this.DeviceDescriptor?.Description$1 ?? null);
                    }
                    //--TRIMMABLE-BOUNDARY-END(64426272669)
                    
                    //--TRIMMABLE-BOUNDARY-START(468153198493)
                    /*IconDescriptor */ get Icon()
                    {
                        return (this.DeviceDescriptor?.IconDescriptor ?? null) ?? new $.$fPer.LCFC.IconDescriptor();
                    }
                    //--TRIMMABLE-BOUNDARY-END(468153198493)
                    
                    //--TRIMMABLE-BOUNDARY-START(463858231197)
                    /*string */ get HomePageUrl()
                    {
                        return `/${$.$strNN($.$$.S.String.Replace$3.call($.$$.S.Object.GetType.call(this).Name, "DeviceFamily", ""))}`;
                    }
                    //--TRIMMABLE-BOUNDARY-END(463858231197)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131305373)
                    /*string */ get DashboardUrl()
                    {
                        return `/${$.$strNN($.$$.S.String.Replace$3.call($.$$.S.Object.GetType.call(this).Name, "DeviceFamily", ""))}/App`;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60131305373)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951436189)
                    /*string */ get ConnectionIdentifier()
                    {
                        return (this.DeviceDescriptor?.ServiceId ?? null) ?? this.Name;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42951436189)
                    
                    //--TRIMMABLE-BOUNDARY-START(146030651293)
                    /*IIOTDeviceFamilyFeatures */ get Features()
                    {
                        return 0/*IIOTDeviceFamilyFeatures.Default*/;
                    }
                    //--TRIMMABLE-BOUNDARY-END(146030651293)
                    
                    //--TRIMMABLE-BOUNDARY-START(55836338077)
                    /*TSmartDevice */ CreateDevice$1(/*IIOTDeviceScope*/ ownerScope, /*TDeviceModel*/ model)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55836338077);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let args = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [$.$XBGm.LCICI.IIOTDeviceFamily$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ TSmartDevice.$type ], null, null)), $.$XBGm.LCICI.IIOTDeviceScope.$type, TDeviceModel.$type], null, null);
                        /*var*/ let $constructor = TSmartDevice.$type.GetConstructor$4(args);
                        if ($.$$.SR.ConstructorInfo.op_Inequality$2($constructor, null))
                        {
                            return $.$cast($constructor.Invoke$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [this, ownerScope, $.$box(model, TDeviceModel)], [-1], null)), TSmartDevice);
                        }
                        throw new $.$$.S.InvalidOperationException().$ctor$12(`${$.$strNN($.$$.S.Object.GetType.call(this).Name)}.${$.$strNN("CreateDevice")} must be overriden as it doesnt conform to the standard constructor format of (${$.$strNN($.$$.S.String.Join$5(",", $.$sl.SL.Enumerable.Select$1($.$$.S.Type, $.$$.S.String, args, new ($.$$.S.Func$$$($.$$.S.Type, $.$$.S.String))().$ctor(this,  (/*a*/ a) =>
                        {
                            return a.Name;
                        }, $JubgAk ??= {"r":1310721,"p":[{"n":"a","p":188547073}],"n":"","d":1763229,"H":0,"h":0,"f":17825794}))))})`);
                    }
                    //--TRIMMABLE-BOUNDARY-END(55836338077)
                    
                    //--TRIMMABLE-BOUNDARY-START(51541370781)
                    /*IIOTDevice */ CreateDevice(/*IIOTDeviceScope*/ ownerScope, /*IIOTDeviceModel*/ model)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(51541370781);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$box(this.CreateDevice$1(ownerScope, $.$XBGm.LCIC.UtilityExtension.Convert$2(TDeviceModel, model)), TSmartDevice);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(51541370781)
                    
                    //--TRIMMABLE-BOUNDARY-START(584117315485)
                    /*string */ ToString()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(584117315485);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Name;
                    }
                    //--TRIMMABLE-BOUNDARY-END(584117315485)
                    
                    //--TRIMMABLE-BOUNDARY-START(274904618385)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.Features.get
                    get LCICI$IIOTDeviceFamily$Features()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(94515991953);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Features;
                    }
                    //--TRIMMABLE-BOUNDARY-END(274904618385)
                    
                    //--TRIMMABLE-BOUNDARY-START(103105926545)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.ConnectionIdentifier.get
                    get LCICI$IIOTDeviceFamily$ConnectionIdentifier()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4321678737);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ConnectionIdentifier;
                    }
                    //--TRIMMABLE-BOUNDARY-END(103105926545)
                    
                    //--TRIMMABLE-BOUNDARY-START(309264356753)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.ServiceModelType.get
                    get LCICI$IIOTDeviceFamily$ServiceModelType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(356508997009);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ServiceModelType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(309264356753)
                    
                    //--TRIMMABLE-BOUNDARY-START(317854291345)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.ServiceSettingsType.get
                    get LCICI$IIOTDeviceFamily$ServiceSettingsType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(360803964305);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ServiceSettingsType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(317854291345)
                    
                    //--TRIMMABLE-BOUNDARY-START(326444225937)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.ServiceStatesType.get
                    get LCICI$IIOTDeviceFamily$ServiceStatesType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(365098931601);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ServiceStatesType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(326444225937)
                    
                    //--TRIMMABLE-BOUNDARY-START(335034160529)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.ServiceTierType.get
                    get LCICI$IIOTDeviceFamily$ServiceTierType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(369393898897);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ServiceTierType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(335034160529)
                    
                    //--TRIMMABLE-BOUNDARY-START(292084487569)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.ServiceFeatureType.get
                    get LCICI$IIOTDeviceFamily$ServiceFeatureType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(347919062417);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ServiceFeatureType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(292084487569)
                    
                    //--TRIMMABLE-BOUNDARY-START(300674422161)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.ServiceHubType.get
                    get LCICI$IIOTDeviceFamily$ServiceHubType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(352214029713);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ServiceHubType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(300674422161)
                    
                    //--TRIMMABLE-BOUNDARY-START(257724749201)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.DeviceType.get
                    get LCICI$IIOTDeviceFamily$DeviceType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85926057361);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(257724749201)
                    
                    //--TRIMMABLE-BOUNDARY-START(171825403281)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.DeviceModelType.get
                    get LCICI$IIOTDeviceFamily$DeviceModelType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42976384401);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceModelType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(171825403281)
                    
                    //--TRIMMABLE-BOUNDARY-START(223365010833)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.DeviceSettingsType.get
                    get LCICI$IIOTDeviceFamily$DeviceSettingsType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68746188177);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceSettingsType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(223365010833)
                    
                    //--TRIMMABLE-BOUNDARY-START(154645534097)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.DeviceHardwareSettingsType.get
                    get LCICI$IIOTDeviceFamily$DeviceHardwareSettingsType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34386449809);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceHardwareSettingsType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(154645534097)
                    
                    //--TRIMMABLE-BOUNDARY-START(231954945425)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.DeviceStatesType.get
                    get LCICI$IIOTDeviceFamily$DeviceStatesType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73041155473);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceStatesType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(231954945425)
                    
                    //--TRIMMABLE-BOUNDARY-START(189005272465)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.DeviceReceivedDataType.get
                    get LCICI$IIOTDeviceFamily$DeviceReceivedDataType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51566318993);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceReceivedDataType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(189005272465)
                    
                    //--TRIMMABLE-BOUNDARY-START(214775076241)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.DeviceSendDataType.get
                    get LCICI$IIOTDeviceFamily$DeviceSendDataType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64451220881);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceSendDataType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(214775076241)
                    
                    //--TRIMMABLE-BOUNDARY-START(240544880017)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.DeviceStatusDataType.get
                    get LCICI$IIOTDeviceFamily$DeviceStatusDataType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77336122769);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceStatusDataType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(240544880017)
                    
                    //--TRIMMABLE-BOUNDARY-START(137465664913)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.DeviceCommandDataType.get
                    get LCICI$IIOTDeviceFamily$DeviceCommandDataType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25796515217);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceCommandDataType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(137465664913)
                    
                    //--TRIMMABLE-BOUNDARY-START(249134814609)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.DeviceStatusHandlerType.get
                    get LCICI$IIOTDeviceFamily$DeviceStatusHandlerType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81631090065);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceStatusHandlerType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(249134814609)
                    
                    //--TRIMMABLE-BOUNDARY-START(197595207057)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.DeviceRemoteDataModelType.get
                    get LCICI$IIOTDeviceFamily$DeviceRemoteDataModelType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55861286289);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceRemoteDataModelType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(197595207057)
                    
                    //--TRIMMABLE-BOUNDARY-START(180415337873)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.DevicePresentationDataModelType.get
                    get LCICI$IIOTDeviceFamily$DevicePresentationDataModelType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47271351697);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DevicePresentationDataModelType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(180415337873)
                    
                    //--TRIMMABLE-BOUNDARY-START(163235468689)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.DeviceLogType.get
                    get LCICI$IIOTDeviceFamily$DeviceLogType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38681417105);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceLogType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(163235468689)
                    
                    //--TRIMMABLE-BOUNDARY-START(206185141649)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.DeviceScheduleDataType.get
                    get LCICI$IIOTDeviceFamily$DeviceScheduleDataType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60156253585);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceScheduleDataType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(206185141649)
                    
                    //--TRIMMABLE-BOUNDARY-START(128875730321)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.DeviceBroadcastSendMessageEnumType.get
                    get LCICI$IIOTDeviceFamily$DeviceBroadcastSendMessageEnumType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21501547921);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceBroadcastSendMessageEnumType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(128875730321)
                    
                    //--TRIMMABLE-BOUNDARY-START(120285795729)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.DeviceBroadcastReceiveActionType.get
                    get LCICI$IIOTDeviceFamily$DeviceBroadcastReceiveActionType()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17206580625);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.DeviceBroadcastReceiveActionType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(120285795729)
                    
                    //--TRIMMABLE-BOUNDARY-START(339329127825)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.GetDescriptorVariant(LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel)
                    LCICI$IIOTDeviceFamily$GetDescriptorVariant()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(339329127825);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetDescriptorVariant(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(339329127825)
                    
                    //--TRIMMABLE-BOUNDARY-START(12911613329)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceFamily.CreateDevice(LivingThing.Core.IOT.Common.Interface.IIOTDeviceScope, LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel)
                    LCICI$IIOTDeviceFamily$CreateDevice()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12911613329);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CreateDevice(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12911613329)
                    
                    //--TRIMMABLE-BOUNDARY-START(17226762582)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
                    get LCFC$IDisplayable$Title()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25816697174);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Title;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17226762582)
                    
                    //--TRIMMABLE-BOUNDARY-START(8636827990)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
                    get LCFC$IDisplayable$Icon()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21521729878);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Icon;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8636827990)
                    
                    //--TRIMMABLE-BOUNDARY-START(12931729750)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
                    get LCFC$IDescribable$Description()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4341795158);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Description;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12931729750)
                    
                    //--TRIMMABLE-BOUNDARY-START(8637417814)
                    //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
                    get LCFC$INamed$Name()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12932385110);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Name;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8637417814)
                    
                    static $H = 1763229;
                    static $h = 1763229;
                    static $f = 0b10000000001110001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(571232413597),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 429498492829,
        "h": Number(BigInt(1763229)|0x6400000000n),
        "f": 50331780
      },
      "n": "ServiceTiersFromSchema",
      "d": 1763229,
      "H": 571232413597,
      "h": Number(BigInt(1763229)|0x8500000000n),
      "f": 2097284
    },
//--TRIMMABLE-BOUNDARY-END(571232413597),
//--TRIMMABLE-BOUNDARY-START(528282740637),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 360779016093,
        "h": Number(BigInt(1763229)|0x5400000000n),
        "f": 50331777
      },
      "n": "Name",
      "d": 1763229,
      "H": 528282740637,
      "h": Number(BigInt(1763229)|0x7B00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(528282740637),
//--TRIMMABLE-BOUNDARY-START(579822348189),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 446678362013,
        "h": Number(BigInt(1763229)|0x6800000000n),
        "f": 50331649
      },
      "n": "Title",
      "d": 1763229,
      "H": 579822348189,
      "h": Number(BigInt(1763229)|0x8700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(579822348189),
//--TRIMMABLE-BOUNDARY-START(85901109149),
    {
      "p": $.$XBGm.LCICM.IOTDeviceDescriptor$$$(TServiceTierType, TServiceFeatureType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 214750128029,
        "h": Number(BigInt(1763229)|0x3200000000n),
        "f": 50331777
      },
      "n": "DeviceDescriptor",
      "d": 1763229,
      "H": 85901109149,
      "h": Number(BigInt(1763229)|0x1400000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(85901109149),
//--TRIMMABLE-BOUNDARY-START(489628034973),
    {
      "p": 36803985,
      "g": {
        "r": 0,
        "d": 0,
        "H": 506807904157,
        "h": Number(BigInt(1763229)|0x7600000000n),
        "f": 50331650
      },
      "n": "{26711441}.DeviceDescriptor",
      "o": "LCICI$IIOTDeviceFamily$DeviceDescriptor",
      "d": 1763229,
      "H": 489628034973,
      "h": Number(BigInt(1763229)|0x7200000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(489628034973),
//--TRIMMABLE-BOUNDARY-START(588412282781),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 455268296605,
        "h": Number(BigInt(1763229)|0x6A00000000n),
        "f": 50331777
      },
      "n": "TypedServiceTiers",
      "d": 1763229,
      "H": 588412282781,
      "h": Number(BigInt(1763229)|0x8900000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(588412282781),
//--TRIMMABLE-BOUNDARY-START(566937446301),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ServiceTierModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 420908558237,
        "h": Number(BigInt(1763229)|0x6200000000n),
        "f": 50331649
      },
      "n": "ServiceTiers",
      "d": 1763229,
      "H": 566937446301,
      "h": Number(BigInt(1763229)|0x8400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(566937446301),
//--TRIMMABLE-BOUNDARY-START(481038100381),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TServiceFeatureType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 476743133085,
        "h": Number(BigInt(1763229)|0x6F00000000n),
        "f": 50331650
      },
      "n": "{$.$AvdQ.LCFCP.ICatalogueProvider$$$(TServiceTierType, TServiceFeatureType).$h}.ServiceTiers",
      "o": "LCFCP$ICatalogueProvider$$$$ServiceTiers",
      "d": 1763229,
      "H": 481038100381,
      "h": Number(BigInt(1763229)|0x7000000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(481038100381),
//--TRIMMABLE-BOUNDARY-START(536872675229),
    {
      "p": $.$XBGm.LCICI.IIOTDeviceProtocol$$$(TDeviceReceivedDataModel, TDeviceSendDataModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 369368950685,
        "h": Number(BigInt(1763229)|0x5600000000n),
        "f": 50331649
      },
      "n": "Protocol",
      "d": 1763229,
      "H": 536872675229,
      "h": Number(BigInt(1763229)|0x7D00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(536872675229),
//--TRIMMABLE-BOUNDARY-START(47246403485),
    {
      "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$(TDeviceReceivedDataModel, TDeviceStatusModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 163210520477,
        "h": Number(BigInt(1763229)|0x2600000000n),
        "f": 50331649
      },
      "n": "Converter",
      "d": 1763229,
      "H": 47246403485,
      "h": Number(BigInt(1763229)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246403485),
//--TRIMMABLE-BOUNDARY-START(519692806045),
    {
      "p": 27563409,
      "g": {
        "r": 0,
        "d": 0,
        "H": 515397838749,
        "h": Number(BigInt(1763229)|0x7800000000n),
        "f": 50331650
      },
      "n": "{26711441}.Protocol",
      "o": "LCICI$IIOTDeviceFamily$Protocol",
      "d": 1763229,
      "H": 519692806045,
      "h": Number(BigInt(1763229)|0x7900000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(519692806045),
//--TRIMMABLE-BOUNDARY-START(485333067677),
    {
      "p": 26252689,
      "g": {
        "r": 0,
        "d": 0,
        "H": 498217969565,
        "h": Number(BigInt(1763229)|0x7400000000n),
        "f": 50331650
      },
      "n": "{26711441}.Converter",
      "o": "LCICI$IIOTDeviceFamily$Converter",
      "d": 1763229,
      "H": 485333067677,
      "h": Number(BigInt(1763229)|0x7100000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(485333067677),
//--TRIMMABLE-BOUNDARY-START(554052544413),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 395138754461,
        "h": Number(BigInt(1763229)|0x5C00000000n),
        "f": 50331649
      },
      "n": "ServiceModelType",
      "d": 1763229,
      "H": 554052544413,
      "h": Number(BigInt(1763229)|0x8100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(554052544413),
//--TRIMMABLE-BOUNDARY-START(558347511709),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 403728689053,
        "h": Number(BigInt(1763229)|0x5E00000000n),
        "f": 50331649
      },
      "n": "ServiceSettingsType",
      "d": 1763229,
      "H": 558347511709,
      "h": Number(BigInt(1763229)|0x8200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(558347511709),
//--TRIMMABLE-BOUNDARY-START(562642479005),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 412318623645,
        "h": Number(BigInt(1763229)|0x6000000000n),
        "f": 50331649
      },
      "n": "ServiceStatesType",
      "d": 1763229,
      "H": 562642479005,
      "h": Number(BigInt(1763229)|0x8300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(562642479005),
//--TRIMMABLE-BOUNDARY-START(575527380893),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 438088427421,
        "h": Number(BigInt(1763229)|0x6600000000n),
        "f": 50331649
      },
      "n": "ServiceTierType",
      "d": 1763229,
      "H": 575527380893,
      "h": Number(BigInt(1763229)|0x8600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(575527380893),
//--TRIMMABLE-BOUNDARY-START(545462609821),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 377958885277,
        "h": Number(BigInt(1763229)|0x5800000000n),
        "f": 50331649
      },
      "n": "ServiceFeatureType",
      "d": 1763229,
      "H": 545462609821,
      "h": Number(BigInt(1763229)|0x7F00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(545462609821),
//--TRIMMABLE-BOUNDARY-START(549757577117),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 386548819869,
        "h": Number(BigInt(1763229)|0x5A00000000n),
        "f": 50331649
      },
      "n": "ServiceHubType",
      "d": 1763229,
      "H": 549757577117,
      "h": Number(BigInt(1763229)|0x8000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(549757577117),
//--TRIMMABLE-BOUNDARY-START(141735683997),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 326419277725,
        "h": Number(BigInt(1763229)|0x4C00000000n),
        "f": 50331649
      },
      "n": "DeviceType",
      "d": 1763229,
      "H": 141735683997,
      "h": Number(BigInt(1763229)|0x2100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141735683997),
//--TRIMMABLE-BOUNDARY-START(98786011037),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 240519931805,
        "h": Number(BigInt(1763229)|0x3800000000n),
        "f": 50331649
      },
      "n": "DeviceModelType",
      "d": 1763229,
      "H": 98786011037,
      "h": Number(BigInt(1763229)|0x1700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98786011037),
//--TRIMMABLE-BOUNDARY-START(124555814813),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 292059539357,
        "h": Number(BigInt(1763229)|0x4400000000n),
        "f": 50331649
      },
      "n": "DeviceSettingsType",
      "d": 1763229,
      "H": 124555814813,
      "h": Number(BigInt(1763229)|0x1D00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124555814813),
//--TRIMMABLE-BOUNDARY-START(90196076445),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 223340062621,
        "h": Number(BigInt(1763229)|0x3400000000n),
        "f": 50331649
      },
      "n": "DeviceHardwareSettingsType",
      "d": 1763229,
      "H": 90196076445,
      "h": Number(BigInt(1763229)|0x1500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196076445),
//--TRIMMABLE-BOUNDARY-START(128850782109),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 300649473949,
        "h": Number(BigInt(1763229)|0x4600000000n),
        "f": 50331649
      },
      "n": "DeviceStatesType",
      "d": 1763229,
      "H": 128850782109,
      "h": Number(BigInt(1763229)|0x1E00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128850782109),
//--TRIMMABLE-BOUNDARY-START(107375945629),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 257699800989,
        "h": Number(BigInt(1763229)|0x3C00000000n),
        "f": 50331649
      },
      "n": "DeviceReceivedDataType",
      "d": 1763229,
      "H": 107375945629,
      "h": Number(BigInt(1763229)|0x1900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375945629),
//--TRIMMABLE-BOUNDARY-START(120260847517),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 283469604765,
        "h": Number(BigInt(1763229)|0x4200000000n),
        "f": 50331649
      },
      "n": "DeviceSendDataType",
      "d": 1763229,
      "H": 120260847517,
      "h": Number(BigInt(1763229)|0x1C00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260847517),
//--TRIMMABLE-BOUNDARY-START(133145749405),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 309239408541,
        "h": Number(BigInt(1763229)|0x4800000000n),
        "f": 50331649
      },
      "n": "DeviceStatusDataType",
      "d": 1763229,
      "H": 133145749405,
      "h": Number(BigInt(1763229)|0x1F00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145749405),
//--TRIMMABLE-BOUNDARY-START(81606141853),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 206160193437,
        "h": Number(BigInt(1763229)|0x3000000000n),
        "f": 50331649
      },
      "n": "DeviceCommandDataType",
      "d": 1763229,
      "H": 81606141853,
      "h": Number(BigInt(1763229)|0x1300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606141853),
//--TRIMMABLE-BOUNDARY-START(137440716701),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 317829343133,
        "h": Number(BigInt(1763229)|0x4A00000000n),
        "f": 50331649
      },
      "n": "DeviceStatusHandlerType",
      "d": 1763229,
      "H": 137440716701,
      "h": Number(BigInt(1763229)|0x2000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137440716701),
//--TRIMMABLE-BOUNDARY-START(94491043741),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 231929997213,
        "h": Number(BigInt(1763229)|0x3600000000n),
        "f": 50331777
      },
      "n": "DeviceLogType",
      "d": 1763229,
      "H": 94491043741,
      "h": Number(BigInt(1763229)|0x1600000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(94491043741),
//--TRIMMABLE-BOUNDARY-START(115965880221),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 274879670173,
        "h": Number(BigInt(1763229)|0x4000000000n),
        "f": 50331777
      },
      "n": "DeviceScheduleDataType",
      "d": 1763229,
      "H": 115965880221,
      "h": Number(BigInt(1763229)|0x1B00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(115965880221),
//--TRIMMABLE-BOUNDARY-START(77311174557),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 197570258845,
        "h": Number(BigInt(1763229)|0x2E00000000n),
        "f": 50331777
      },
      "n": "DeviceBroadcastSendMessageEnumType",
      "d": 1763229,
      "H": 77311174557,
      "h": Number(BigInt(1763229)|0x1200000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(77311174557),
//--TRIMMABLE-BOUNDARY-START(73016207261),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 188980324253,
        "h": Number(BigInt(1763229)|0x2C00000000n),
        "f": 50331777
      },
      "n": "DeviceBroadcastReceiveActionType",
      "d": 1763229,
      "H": 73016207261,
      "h": Number(BigInt(1763229)|0x1100000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(73016207261),
//--TRIMMABLE-BOUNDARY-START(111670912925),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 266289735581,
        "h": Number(BigInt(1763229)|0x3E00000000n),
        "f": 50331777
      },
      "n": "DeviceRemoteDataModelType",
      "d": 1763229,
      "H": 111670912925,
      "h": Number(BigInt(1763229)|0x1A00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(111670912925),
//--TRIMMABLE-BOUNDARY-START(103080978333),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 249109866397,
        "h": Number(BigInt(1763229)|0x3A00000000n),
        "f": 50331777
      },
      "n": "DevicePresentationDataModelType",
      "d": 1763229,
      "H": 103080978333,
      "h": Number(BigInt(1763229)|0x1800000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(103080978333),
//--TRIMMABLE-BOUNDARY-START(64426272669),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 180390389661,
        "h": Number(BigInt(1763229)|0x2A00000000n),
        "f": 50331649
      },
      "n": "Description",
      "d": 1763229,
      "H": 64426272669,
      "h": Number(BigInt(1763229)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426272669),
//--TRIMMABLE-BOUNDARY-START(468153198493),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "H": 352189081501,
        "h": Number(BigInt(1763229)|0x5200000000n),
        "f": 50331649
      },
      "n": "Icon",
      "d": 1763229,
      "H": 468153198493,
      "h": Number(BigInt(1763229)|0x6D00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(468153198493),
//--TRIMMABLE-BOUNDARY-START(463858231197),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 343599146909,
        "h": Number(BigInt(1763229)|0x5000000000n),
        "f": 50331777
      },
      "n": "HomePageUrl",
      "d": 1763229,
      "H": 463858231197,
      "h": Number(BigInt(1763229)|0x6C00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(463858231197),
//--TRIMMABLE-BOUNDARY-START(60131305373),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 171800455069,
        "h": Number(BigInt(1763229)|0x2800000000n),
        "f": 50331777
      },
      "n": "DashboardUrl",
      "d": 1763229,
      "H": 60131305373,
      "h": Number(BigInt(1763229)|0xE00000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(60131305373),
//--TRIMMABLE-BOUNDARY-START(42951436189),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 154620585885,
        "h": Number(BigInt(1763229)|0x2400000000n),
        "f": 50331649
      },
      "n": "ConnectionIdentifier",
      "d": 1763229,
      "H": 42951436189,
      "h": Number(BigInt(1763229)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951436189),
//--TRIMMABLE-BOUNDARY-START(146030651293),
    {
      "p": 26842513,
      "g": {
        "r": 0,
        "d": 0,
        "H": 335009212317,
        "h": Number(BigInt(1763229)|0x4E00000000n),
        "f": 50331777
      },
      "n": "Features",
      "d": 1763229,
      "H": 146030651293,
      "h": Number(BigInt(1763229)|0x2200000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(146030651293)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(541167642525),
    {
      "r": 65537,
      "p": [
        {
          "n": "catalogue",
          "p": 4371392
        }
      ],
      "n": "ResolveImagePath",
      "d": 1763229,
      "H": 541167642525,
      "h": Number(BigInt(1763229)|0x7E00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(541167642525),
//--TRIMMABLE-BOUNDARY-START(532577707933),
    {
      "r": 65537,
      "p": [
        {
          "n": "descriptor",
          "p": $.$XBGm.LCICM.IOTDeviceDescriptor$$$(TServiceTierType, TServiceFeatureType).$h
        }
      ],
      "n": "NormalizeDescriptor",
      "d": 1763229,
      "H": 532577707933,
      "h": Number(BigInt(1763229)|0x7C00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(532577707933),
//--TRIMMABLE-BOUNDARY-START(592707250077),
    {
      "r": 65537,
      "p": [
        {
          "n": "descriptor",
          "p": $.$XBGm.LCICM.IOTDeviceDescriptor$$$(TServiceTierType, TServiceFeatureType).$h
        }
      ],
      "n": "UpdateDescriptor",
      "d": 1763229,
      "H": 592707250077,
      "h": Number(BigInt(1763229)|0x8A00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(592707250077),
//--TRIMMABLE-BOUNDARY-START(459563263901),
    {
      "r": 36803985,
      "p": [
        {
          "n": "device",
          "p": 27432337
        }
      ],
      "n": "GetDescriptorVariant",
      "d": 1763229,
      "H": 459563263901,
      "h": Number(BigInt(1763229)|0x6B00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(459563263901),
//--TRIMMABLE-BOUNDARY-START(55836338077),
    {
      "r": TSmartDevice?.$h??1572864,
      "p": [
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": TDeviceModel?.$h??2162688
        }
      ],
      "n": "CreateDevice",
      "o": "@$1",
      "d": 1763229,
      "H": 55836338077,
      "h": Number(BigInt(1763229)|0xD00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(55836338077),
//--TRIMMABLE-BOUNDARY-START(51541370781),
    {
      "r": 25925009,
      "p": [
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 27432337
        }
      ],
      "n": "CreateDevice",
      "d": 1763229,
      "H": 51541370781,
      "h": Number(BigInt(1763229)|0xC00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541370781),
//--TRIMMABLE-BOUNDARY-START(584117315485),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1763229,
      "H": 584117315485,
      "h": Number(BigInt(1763229)|0x8800000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(584117315485)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38656468893),
    {
      "t": 4950358,
      "n": "config",
      "d": 1763229,
      "H": 38656468893,
      "h": Number(BigInt(1763229)|0x900000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656468893),
//--TRIMMABLE-BOUNDARY-START(523987773341),
    {
      "t": 1310721,
      "n": "name",
      "d": 1763229,
      "H": 523987773341,
      "h": Number(BigInt(1763229)|0x7A00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(523987773341),
//--TRIMMABLE-BOUNDARY-START(68721239965),
    {
      "t": $.$XBGm.LCICM.IOTDeviceDescriptor$$$(TServiceTierType, TServiceFeatureType).$h,
      "n": "descriptor",
      "d": 1763229,
      "H": 68721239965,
      "h": Number(BigInt(1763229)|0x1000000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68721239965)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066534301),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$(TDeviceReceivedDataModel, TDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$(TDeviceReceivedDataModel, TDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1763229,
      "H": 30066534301,
      "h": Number(BigInt(1763229)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066534301),
//--TRIMMABLE-BOUNDARY-START(34361501597),
    {
      "p": [
        {
          "n": "descriptor",
          "p": $.$XBGm.LCICM.IOTDeviceDescriptor$$$(TServiceTierType, TServiceFeatureType).$h
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$(TDeviceReceivedDataModel, TDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$(TDeviceReceivedDataModel, TDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1763229,
      "H": 34361501597,
      "h": Number(BigInt(1763229)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361501597)
  ],
  "d": 1697693,
  "H": 1763229,
  "h": 1763229
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$(TSmartDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$(TSmartDevice, TServiceTierType, TServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$(TServiceTierType, TServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>+ConfiguredDeviceFamily`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TDeviceScopeModel?.$getFullName(separator)}$${TDeviceScopeSettings?.$getFullName(separator)}$${TDeviceScopeStates?.$getFullName(separator)}$${TDeviceModel?.$getFullName(separator)}$${TDeviceSettings?.$getFullName(separator)}$${TDeviceHardwareSettings?.$getFullName(separator)}$${TDeviceStates?.$getFullName(separator)}$${TDeviceStatusModel?.$getFullName(separator)}$${TDeviceCommandModel?.$getFullName(separator)}$${TDeviceReceivedDataModel?.$getFullName(separator)}$${TDeviceSendDataModel?.$getFullName(separator)}$${TDeviceStatusHandler?.$getFullName(separator)}$${TServiceHubClient?.$getFullName(separator)}$${TServicesRemoteService?.$getFullName(separator)}$${TDeviceGlobalSettings?.$getFullName(separator)}$${separator}ConfiguredDeviceFamily`; }
                }, $cls, ($v) => $cls.$_ConfiguredDeviceFamily = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1763229)
            
            //--TRIMMABLE-BOUNDARY-START(4296664989)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296664989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296664989)
            
            //--TRIMMABLE-BOUNDARY-START(4296664989)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296664989)
            
            static $H = 1697693;
            static $h = 1697693;
            static $g = 21;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296664989),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4296664989,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296664989)
  ],
  "s": [
    {
      "h": TSmartDevice?.$h??1572864,
      "n": "TSmartDevice",
      "c": [1501085
      ]
    },
    {
      "h": TServiceModel?.$h??1638400,
      "n": "TServiceModel",
      "f": 4,
      "c": [32019857
      ]
    },
    {
      "h": TServiceTierType?.$h??1703936,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TServiceFeatureType?.$h??1769472,
      "n": "TServiceFeatureType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TServiceSettings?.$h??1835008,
      "n": "TServiceSettings",
      "f": 4,
      "c": [55678353
      ]
    },
    {
      "h": TServiceStates?.$h??1900544,
      "n": "TServiceStates",
      "f": 4,
      "c": [59807121
      ]
    },
    {
      "h": TDeviceScopeModel?.$h??1966080,
      "n": "TDeviceScopeModel",
      "f": 4,
      "c": [31495569
      ]
    },
    {
      "h": TDeviceScopeSettings?.$h??2031616,
      "n": "TDeviceScopeSettings",
      "f": 4,
      "c": [54564241
      ]
    },
    {
      "h": TDeviceScopeStates?.$h??2097152,
      "n": "TDeviceScopeStates",
      "f": 4,
      "c": [59282833
      ]
    },
    {
      "h": TDeviceModel?.$h??2162688,
      "n": "TDeviceModel",
      "f": 4,
      "c": [31233425
      ]
    },
    {
      "h": TDeviceSettings?.$h??2228224,
      "n": "TDeviceSettings",
      "f": 4,
      "c": [31757713
      ]
    },
    {
      "h": TDeviceHardwareSettings?.$h??2293760,
      "n": "TDeviceHardwareSettings",
      "f": 4,
      "c": [54171025
      ]
    },
    {
      "h": TDeviceStates?.$h??2359296,
      "n": "TDeviceStates",
      "f": 4,
      "c": [59544977
      ]
    },
    {
      "h": TDeviceStatusModel?.$h??2424832,
      "n": "TDeviceStatusModel",
      "f": 4,
      "c": [39687569
      ]
    },
    {
      "h": TDeviceCommandModel?.$h??2490368,
      "n": "TDeviceCommandModel",
      "f": 4,
      "c": [35427729
      ]
    },
    {
      "h": TDeviceReceivedDataModel?.$h??2555904,
      "n": "TDeviceReceivedDataModel",
      "f": 4,
      "c": [38049169
      ]
    },
    {
      "h": TDeviceSendDataModel?.$h??2621440,
      "n": "TDeviceSendDataModel",
      "f": 4,
      "c": [39425425
      ]
    },
    {
      "h": TDeviceStatusHandler?.$h??2686976,
      "n": "TDeviceStatusHandler",
      "c": [31102353
      ]
    },
    {
      "h": TServiceHubClient?.$h??2752512,
      "n": "TServiceHubClient",
      "f": 1,
      "c": [31036817
      ]
    },
    {
      "h": TServicesRemoteService?.$h??2818048,
      "n": "TServicesRemoteService",
      "f": 1,
      "c": [31167889
      ]
    },
    {
      "h": TDeviceGlobalSettings?.$h??2883584,
      "n": "TDeviceGlobalSettings",
      "f": 4,
      "c": [53908881
      ]
    }
  ],
  "r": 21,
  "H": 1697693,
  "h": this.$h
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).ConfiguredServerDeviceFamily, $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).IOTDeviceModelDefinition, $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDeviceFamily, $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericServerDeviceScopeFactory, $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDevice, $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDeviceScopeFactory, $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDeviceScope, $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDeviceServiceAsScope, $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).ConfiguredDeviceFamily ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TDeviceScopeModel?.$getFullName(separator)}$${TDeviceScopeSettings?.$getFullName(separator)}$${TDeviceScopeStates?.$getFullName(separator)}$${TDeviceModel?.$getFullName(separator)}$${TDeviceSettings?.$getFullName(separator)}$${TDeviceHardwareSettings?.$getFullName(separator)}$${TDeviceStates?.$getFullName(separator)}$${TDeviceStatusModel?.$getFullName(separator)}$${TDeviceCommandModel?.$getFullName(separator)}$${TDeviceReceivedDataModel?.$getFullName(separator)}$${TDeviceSendDataModel?.$getFullName(separator)}$${TDeviceStatusHandler?.$getFullName(separator)}$${TServiceHubClient?.$getFullName(separator)}$${TServicesRemoteService?.$getFullName(separator)}$${TDeviceGlobalSettings?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1697693)
        
        

        //--TRIMMABLE-BOUNDARY-START(452509)
        $asm.$cls(`$NXre.LCID.iSmartGenericDeviceDefinition<,,,,,,,,,,,,,,,,,,,,,>`, (TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings, TReceivedStatusModel) => $asm.$gt(`$NXre.LCID.iSmartGenericDeviceDefinition<,,,,,,,,,,,,,,,,,,,,,>`, [TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings, TReceivedStatusModel], ($self) => class iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$ extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(649117)
            static $_iSmartGenericDeviceScopeFactory;
            static get iSmartGenericDeviceScopeFactory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(649117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings, TReceivedStatusModel);
                return $cls.$_iSmartGenericDeviceScopeFactory ??= $asm.$ncls(`$NXre.LCID.iSmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName},${TReceivedStatusModel?.$fullName}>.iSmartGenericDeviceScopeFactory`, ($self) => class iSmartGenericDeviceScopeFactory extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDeviceScopeFactory
                {
                    //--TRIMMABLE-BOUNDARY-START(4295616413)
                    $ctor$2(/*ServiceFactory*/ services, /*IConfigurationParser*/ config, /*IScopeStore*/ scopeStore, /*IDeviceStore*/ deviceStore)
                    {
                        super.$ctor$1(services, config, scopeStore, deviceStore);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295616413);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295616413)
                    
                    static $H = 649117;
                    static $h = 649117;
                    static $f = 0b10000000001110001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDeviceScopeFactory; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295616413),
    {
      "p": [
        {
          "n": "services",
          "p": 62949718
        },
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "scopeStore",
          "p": 1545617
        },
        {
          "n": "deviceStore",
          "p": 1283473
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 649117,
      "H": 4295616413,
      "h": Number(BigInt(649117)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295616413)
  ],
  "d": 452509,
  "H": 649117,
  "h": 649117
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.iSmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName},${TReceivedStatusModel?.$fullName}>+iSmartGenericDeviceScopeFactory`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}iSmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TDeviceScopeModel?.$getFullName(separator)}$${TDeviceScopeSettings?.$getFullName(separator)}$${TDeviceScopeStates?.$getFullName(separator)}$${TDeviceModel?.$getFullName(separator)}$${TDeviceSettings?.$getFullName(separator)}$${TDeviceHardwareSettings?.$getFullName(separator)}$${TDeviceStates?.$getFullName(separator)}$${TDeviceStatusModel?.$getFullName(separator)}$${TDeviceCommandModel?.$getFullName(separator)}$${TDeviceReceivedDataModel?.$getFullName(separator)}$${TDeviceSendDataModel?.$getFullName(separator)}$${TDeviceStatusHandler?.$getFullName(separator)}$${TServiceHubClient?.$getFullName(separator)}$${TServicesRemoteService?.$getFullName(separator)}$${TDeviceGlobalSettings?.$getFullName(separator)}$${TReceivedStatusModel?.$getFullName(separator)}$${separator}iSmartGenericDeviceScopeFactory`; }
                }, $cls, ($v) => $cls.$_iSmartGenericDeviceScopeFactory = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(649117)
            
            //--TRIMMABLE-BOUNDARY-START(714653)
            static $_iSmartGenericDeviceServiceAsScope;
            static get iSmartGenericDeviceServiceAsScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(714653);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings, TReceivedStatusModel);
                return $cls.$_iSmartGenericDeviceServiceAsScope ??= $asm.$ncls(`$NXre.LCID.iSmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName},${TReceivedStatusModel?.$fullName}>.iSmartGenericDeviceServiceAsScope`, ($self) => class iSmartGenericDeviceServiceAsScope extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDeviceServiceAsScope
                {
                    //--TRIMMABLE-BOUNDARY-START(8590649245)
                    $ctor$5(/*SmartGenericDeviceScopeFactory*/ factory, /*TServiceModel*/ service)
                    {
                        super.$ctor$3(factory, service);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590649245);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590649245)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295681949)
                    $ctor$4(/*SmartGenericDeviceScopeFactory*/ factory, /*TDeviceScopeModel*/ scope, /*IEnumerable<TDeviceModel>*/ devices)
                    {
                        super.$ctor$2(factory, scope, devices);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295681949);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295681949)
                    
                    static $H = 714653;
                    static $h = 714653;
                    static $f = 0b10000000001110001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDeviceServiceAsScope; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590649245),
    {
      "p": [
        {
          "n": "factory",
          "p": 2156445
        },
        {
          "n": "service",
          "p": TServiceModel?.$h??1638400
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 714653,
      "H": 8590649245,
      "h": Number(BigInt(714653)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590649245),
//--TRIMMABLE-BOUNDARY-START(4295681949),
    {
      "p": [
        {
          "n": "factory",
          "p": 2156445
        },
        {
          "n": "scope",
          "p": TDeviceScopeModel?.$h??1966080
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$(TDeviceModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 714653,
      "H": 4295681949,
      "h": Number(BigInt(714653)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295681949)
  ],
  "d": 452509,
  "H": 714653,
  "h": 714653
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScope, $.$so.SC$1.INotifyPropertyChanged ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.iSmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName},${TReceivedStatusModel?.$fullName}>+iSmartGenericDeviceServiceAsScope`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}iSmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TDeviceScopeModel?.$getFullName(separator)}$${TDeviceScopeSettings?.$getFullName(separator)}$${TDeviceScopeStates?.$getFullName(separator)}$${TDeviceModel?.$getFullName(separator)}$${TDeviceSettings?.$getFullName(separator)}$${TDeviceHardwareSettings?.$getFullName(separator)}$${TDeviceStates?.$getFullName(separator)}$${TDeviceStatusModel?.$getFullName(separator)}$${TDeviceCommandModel?.$getFullName(separator)}$${TDeviceReceivedDataModel?.$getFullName(separator)}$${TDeviceSendDataModel?.$getFullName(separator)}$${TDeviceStatusHandler?.$getFullName(separator)}$${TServiceHubClient?.$getFullName(separator)}$${TServicesRemoteService?.$getFullName(separator)}$${TDeviceGlobalSettings?.$getFullName(separator)}$${TReceivedStatusModel?.$getFullName(separator)}$${separator}iSmartGenericDeviceServiceAsScope`; }
                }, $cls, ($v) => $cls.$_iSmartGenericDeviceServiceAsScope = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(714653)
            
            //--TRIMMABLE-BOUNDARY-START(583581)
            static $_iSmartGenericDeviceScope;
            static get iSmartGenericDeviceScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(583581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings, TReceivedStatusModel);
                return $cls.$_iSmartGenericDeviceScope ??= $asm.$ncls(`$NXre.LCID.iSmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName},${TReceivedStatusModel?.$fullName}>.iSmartGenericDeviceScope`, ($self) => class iSmartGenericDeviceScope extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDeviceScope
                {
                    //--TRIMMABLE-BOUNDARY-START(4295550877)
                    $ctor$2(/*SmartGenericDeviceScopeFactory*/ factory, /*TDeviceScopeModel*/ scope, /*IEnumerable<TDeviceModel>*/ _devices)
                    {
                        super.$ctor$1(factory, scope, _devices);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295550877);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295550877)
                    
                    static $H = 583581;
                    static $h = 583581;
                    static $f = 0b10000000001110001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDeviceScope; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295550877),
    {
      "p": [
        {
          "n": "factory",
          "p": 2156445
        },
        {
          "n": "scope",
          "p": TDeviceScopeModel?.$h??1966080
        },
        {
          "n": "_devices",
          "p": $.$$.SCG.IEnumerable$$(TDeviceModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 583581,
      "H": 4295550877,
      "h": Number(BigInt(583581)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295550877)
  ],
  "d": 452509,
  "H": 583581,
  "h": 583581
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScope, $.$so.SC$1.INotifyPropertyChanged ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.iSmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName},${TReceivedStatusModel?.$fullName}>+iSmartGenericDeviceScope`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}iSmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TDeviceScopeModel?.$getFullName(separator)}$${TDeviceScopeSettings?.$getFullName(separator)}$${TDeviceScopeStates?.$getFullName(separator)}$${TDeviceModel?.$getFullName(separator)}$${TDeviceSettings?.$getFullName(separator)}$${TDeviceHardwareSettings?.$getFullName(separator)}$${TDeviceStates?.$getFullName(separator)}$${TDeviceStatusModel?.$getFullName(separator)}$${TDeviceCommandModel?.$getFullName(separator)}$${TDeviceReceivedDataModel?.$getFullName(separator)}$${TDeviceSendDataModel?.$getFullName(separator)}$${TDeviceStatusHandler?.$getFullName(separator)}$${TServiceHubClient?.$getFullName(separator)}$${TServicesRemoteService?.$getFullName(separator)}$${TDeviceGlobalSettings?.$getFullName(separator)}$${TReceivedStatusModel?.$getFullName(separator)}$${separator}iSmartGenericDeviceScope`; }
                }, $cls, ($v) => $cls.$_iSmartGenericDeviceScope = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(583581)
            
            //--TRIMMABLE-BOUNDARY-START(780189)
            static $_iSmartGenericServerDeviceScopeFactory;
            static get iSmartGenericServerDeviceScopeFactory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(780189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings, TReceivedStatusModel);
                return $cls.$_iSmartGenericServerDeviceScopeFactory ??= $asm.$ncls(`$NXre.LCID.iSmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName},${TReceivedStatusModel?.$fullName}>.iSmartGenericServerDeviceScopeFactory`, ($self) => class iSmartGenericServerDeviceScopeFactory extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericServerDeviceScopeFactory
                {
                    //--TRIMMABLE-BOUNDARY-START(4295747485)
                    $ctor$3(/*ServiceFactory*/ services, /*IConfigurationParser*/ config, /*IScopeStore*/ scopeStore, /*IDeviceStore*/ deviceStore, /*IEnumerable<IIOTDeviceFamily<TSmartDevice>>*/ families, /*IServerRemoteService*/ serverRemoteService, /*IHubConnector<TServiceHubClient>*/ hubConnector)
                    {
                        super.$ctor$2(services, config, scopeStore, deviceStore, families, serverRemoteService, hubConnector);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295747485);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295747485)
                    
                    static $H = 780189;
                    static $h = 780189;
                    static $f = 0b10000000001110001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericServerDeviceScopeFactory; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295747485),
    {
      "p": [
        {
          "n": "services",
          "p": 62949718
        },
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "scopeStore",
          "p": 1545617
        },
        {
          "n": "deviceStore",
          "p": 1283473
        },
        {
          "n": "families",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily$$(TSmartDevice)).$h
        },
        {
          "n": "serverRemoteService",
          "p": 1309651
        },
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$(TServiceHubClient).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 780189,
      "H": 4295747485,
      "h": Number(BigInt(780189)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295747485)
  ],
  "d": 452509,
  "H": 780189,
  "h": 780189
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient, $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.iSmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName},${TReceivedStatusModel?.$fullName}>+iSmartGenericServerDeviceScopeFactory`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}iSmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TDeviceScopeModel?.$getFullName(separator)}$${TDeviceScopeSettings?.$getFullName(separator)}$${TDeviceScopeStates?.$getFullName(separator)}$${TDeviceModel?.$getFullName(separator)}$${TDeviceSettings?.$getFullName(separator)}$${TDeviceHardwareSettings?.$getFullName(separator)}$${TDeviceStates?.$getFullName(separator)}$${TDeviceStatusModel?.$getFullName(separator)}$${TDeviceCommandModel?.$getFullName(separator)}$${TDeviceReceivedDataModel?.$getFullName(separator)}$${TDeviceSendDataModel?.$getFullName(separator)}$${TDeviceStatusHandler?.$getFullName(separator)}$${TServiceHubClient?.$getFullName(separator)}$${TServicesRemoteService?.$getFullName(separator)}$${TDeviceGlobalSettings?.$getFullName(separator)}$${TReceivedStatusModel?.$getFullName(separator)}$${separator}iSmartGenericServerDeviceScopeFactory`; }
                }, $cls, ($v) => $cls.$_iSmartGenericServerDeviceScopeFactory = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(780189)
            
            //--TRIMMABLE-BOUNDARY-START(518045)
            static $_iSmartGenericDevice;
            static get iSmartGenericDevice()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(518045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings, TReceivedStatusModel);
                return $cls.$_iSmartGenericDevice ??= $asm.$ncls(`$NXre.LCID.iSmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName},${TReceivedStatusModel?.$fullName}>.iSmartGenericDevice`, ($self) => class iSmartGenericDevice extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDevice
                {
                    //--TRIMMABLE-BOUNDARY-START(8590452637)
                    $ctor$3(/*IIOTDeviceFamily<TSmartDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*TDeviceModel*/ model)
                    {
                        super.$ctor$2(family, ownerScope, model);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590452637);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590452637)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245158301)
                    /*IOTDeviceFeatures */ get Features()
                    {
                        return 1/*IOTDeviceFeatures.HasOwnHardware*/ | 2/*IOTDeviceFeatures.HasDescriptor*/;
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245158301)
                    
                    //--TRIMMABLE-BOUNDARY-START(154619340701)
                    /*IconDescriptor */ GetSensoryInputDisplay(/*int*/ input)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(154619340701);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new $.$fPer.LCFC.IconDescriptor().$ctor$2();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(154619340701)
                    
                    //--TRIMMABLE-BOUNDARY-START(146029406109)
                    /*IconDescriptor */ GetControlOutputDisplay(/*int*/ output)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(146029406109);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return (() =>
                            {
                                //new $.$fPer.LCFC.IconDescriptor()
                                const $t1 = $.$fPer.LCFC.IconDescriptor;
                                const $i1 = new $t1();
                                $i1.$ctor$2();
                                $i1.Icon = ($.$XBGm.LCICDi.iSmartDeviceCommandExtension.GetControlOutputIOState(this, output) === true ? $.$strNN(("mdi mdi-power"/*MaterialDesignIconNames.Power*/)) + " cl-warning" : "mdi mdi-power-cycle"/*MaterialDesignIconNames.PowerCycle*/);
                                return $i1;
                            })();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(146029406109)
                    
                    //--TRIMMABLE-BOUNDARY-START(171799209885)
                    /*ValueTask *//*async*/  RaisePropertyChanged(/*object?*/ sender, /*params string[]*/ names)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t4, $r4;
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(171799209885);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            if (((this.Features & (1/*IOTDeviceFeatures.HasOwnHardware*/)) == (1/*IOTDeviceFeatures.HasOwnHardware*/)) && ((this.Features & (2/*IOTDeviceFeatures.HasDescriptor*/)) == (2/*IOTDeviceFeatures.HasDescriptor*/)))
                            {
                                if (this.HardwareDescriptor === null && ($.$$.S.MemoryExtensions.Contains$2($.$$.S.String, $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1(names), "ReceivedStatus") || $.$$.S.MemoryExtensions.Contains$2($.$$.S.String, $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1(names), "IsAvailable")) && this.IsAvailable)
                                {
                                    try
                                    {
                                        let $t2, $r2;
                                        /*var*/ let descriptor = ($t2 = $.$XBGm.LCICDi.iSmartDeviceCommandExtension.GetHWDescriptor$1($.$fPer.LCFCO.OneOf$$$($.$XBGm.LCICDi.IiSmartIOTDevice, $.$KuVO.LCFCC.IConnectionClient).FromT0(this)).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                                        if (descriptor !== null)
                                        {
                                            this.HardwareDescriptor = descriptor;
                                            if (!((this.HardwareDescriptor.Features & (1/*iSmartDeviceFeatures.TimeSet*/)) == (1/*iSmartDeviceFeatures.TimeSet*/)))
                                            {
                                                let $t3, $r3;
                                                ($t3 = $.$XBGm.LCICDi.iSmartDeviceCommandExtension.SetSystemTime$1($.$fPer.LCFCO.OneOf$$$($.$XBGm.LCICDi.IiSmartIOTDevice, $.$KuVO.LCFCC.IConnectionClient).FromT0(this), $.$$.S.DateTime.Now), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                            }
                                        }
                                    }
                                    catch($e)
                                    {
                                    }
                                }
                            }
                            ($t4 = super.RaisePropertyChanged(sender, names), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(171799209885)
                    
                    //--TRIMMABLE-BOUNDARY-START(176094177181)
                    /*IIOTDeviceReceivedDataModel? */ get ReceivedStatus()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(124554569629);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return super.ReceivedStatus;
                    }
                    /*IIOTDeviceReceivedDataModel? */ set ReceivedStatus(value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(201863980957);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let _status = $.$cast(value, TDeviceReceivedDataModel);
                        /*var*/ let _currentStatus = $.$cast(super.ReceivedStatus, TDeviceReceivedDataModel);
                        if (_status !== null && _status.ReceivedStatus === null && (_currentStatus?.ReceivedStatus ?? null) !== null)
                        {
                            _status.ReceivedStatus = _currentStatus.ReceivedStatus;
                        }
                        if (_status !== null && _status.ReceivedLog === null && (_currentStatus?.ReceivedLog ?? null) !== null)
                        {
                            _status.ReceivedLog = _currentStatus.ReceivedLog;
                        }
                        super.ReceivedStatus = value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(176094177181)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950191005)
                    /*string */ get FamilyName()
                    {
                        return this.Family$1.LCFC$INamed$Name;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950191005)
                    
                    //--TRIMMABLE-BOUNDARY-START(163209275293)
                    /*int? */ get InputStates()
                    {
                        return (this.Received?.Inputs ?? null);
                    }
                    //--TRIMMABLE-BOUNDARY-END(163209275293)
                    
                    //--TRIMMABLE-BOUNDARY-START(167504242589)
                    /*int? */ get OutputStates()
                    {
                        return (this.Received?.Outputs ?? null);
                    }
                    //--TRIMMABLE-BOUNDARY-END(167504242589)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885419933)
                    /*float[]? */ get AnalogStates()
                    {
                        return (this.Received?.Analogs ?? null);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885419933)
                    
                    //--TRIMMABLE-BOUNDARY-START(184684111773)
                    /*Task */ ResetStatus()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(184684111773);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.HardwareDescriptor = null;
                        return super.ResetStatus();
                    }
                    //--TRIMMABLE-BOUNDARY-END(184684111773)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475354525)
                    /*Task */ BindToScope(/*IIOTDeviceScope*/ scope)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475354525);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this.IsAvailable)
                        {
                            _ = $.$XBGm.LCICDi.iSmartDeviceCommandExtension.SetScope$1($.$fPer.LCFCO.OneOf$$$($.$XBGm.LCICDi.IiSmartIOTDevice, $.$KuVO.LCFCC.IConnectionClient).FromT0(this), scope.LCICI$IIOTDeviceScope$Model.LCICM$IIOTDeviceScopeModel$ConnectionIdentifer);
                        }
                        return super.BindToScope(scope);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475354525)
                    
                    //--TRIMMABLE-BOUNDARY-START(180389144477)
                    /*IIOTDeviceConfigurationProvider */ get RemoteConfigurationProvider()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(180389144477)
                    
                    //--TRIMMABLE-BOUNDARY-START(210453915549)
                    /*object? */ get StatusDescriptor()
                    {
                        return new TDeviceReceivedDataModel().$gctor().StatusType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(210453915549)
                    
                    //--TRIMMABLE-BOUNDARY-START(158914307997)
                    /*iSmartIOTDeviceDescriptor?*/ HardwareDescriptor = null;
                    //--TRIMMABLE-BOUNDARY-END(158914307997)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655223709)
                    /*int */ get CurrentFirmwareVersion()
                    {
                        return (this.HardwareDescriptor?.FirmwareVersion ?? null) ?? 0;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655223709)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065289117)
                    /*bool */ get CanUpdate()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64425027485);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartIOTDeviceDescriptor?*/ let __ca1__;
                        return ((__ca1__ = this.HardwareDescriptor) !== null ? ((__ca1__.Features & (8/*iSmartDeviceFeatures.Updatable*/)) == (8/*iSmartDeviceFeatures.Updatable*/)) : false);
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065289117)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180387229)
                    /*Task<FirmwareUpdateStatus> */ BeginUpdate(/*IOTDeviceFirmwareUpdatingModel*/ update)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180387229);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$XBGm.LCICDi.iSmartDeviceCommandExtension.BeginUpdate$2(this, update);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180387229)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360256413)
                    /*Task<int> */ ContinueUpdate(/*IOTDeviceFirmwareUpdatingModel*/ update, /*TimeSpan?*/ packetTimeOut)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34360256413);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$XBGm.LCICDi.iSmartDeviceCommandExtension.ContinueUpdate$2(this, update, $.$clone(packetTimeOut));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360256413)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770321821)
                    /*Task */ CancelUpdate()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770321821);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$XBGm.LCICDi.iSmartDeviceCommandExtension.CancelUpdate$2(this);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770321821)
                    
                    //--TRIMMABLE-BOUNDARY-START(150324373405)
                    /*Task<RemoteHardwareSettings> */ GetRemoteHardwareSettings()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(150324373405);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$XBGm.LCICDi.iSmartDeviceCommandExtension.GetRemoteHardwareSettings$2(TDeviceHardwareSettings, this);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(150324373405)
                    
                    //--TRIMMABLE-BOUNDARY-START(206158948253)
                    /*Task */ SetRemoteHardwareConfig(/*IIOTDeviceInternalConfiguration*/ configuration)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(206158948253);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$XBGm.LCICDi.iSmartDeviceCommandExtension.SetRemoteHardwareConfiguration$5($.$XBGm.LCICI.IIOTDeviceInternalConfiguration, this, configuration, null);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(206158948253)
                    
                    //--TRIMMABLE-BOUNDARY-START(21490341265)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Devices.iSmart.IiSmartIOTDevice.HardwareDescriptor.get
                    get LCICDi$IiSmartIOTDevice$HardwareDescriptor()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51555112337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.HardwareDescriptor;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21490341265)
                    
                    //--TRIMMABLE-BOUNDARY-START(30080275857)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Devices.iSmart.IiSmartIOTDevice.InputStates.get
                    get LCICDi$IiSmartIOTDevice$InputStates()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55850079633);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.InputStates;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30080275857)
                    
                    //--TRIMMABLE-BOUNDARY-START(38670210449)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Devices.iSmart.IiSmartIOTDevice.OutputStates.get
                    get LCICDi$IiSmartIOTDevice$OutputStates()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60145046929);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.OutputStates;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38670210449)
                    
                    //--TRIMMABLE-BOUNDARY-START(12900406673)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Devices.iSmart.IiSmartIOTDevice.AnalogStates.get
                    get LCICDi$IiSmartIOTDevice$AnalogStates()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4310472081);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.AnalogStates;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12900406673)
                    
                    //--TRIMMABLE-BOUNDARY-START(47260145041)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Devices.iSmart.IiSmartIOTDevice.GetSensoryInputDisplay(int)
                    LCICDi$IiSmartIOTDevice$GetSensoryInputDisplay()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47260145041);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetSensoryInputDisplay(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47260145041)
                    
                    //--TRIMMABLE-BOUNDARY-START(42965177745)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Devices.iSmart.IiSmartIOTDevice.GetControlOutputDisplay(int)
                    LCICDi$IiSmartIOTDevice$GetControlOutputDisplay()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42965177745);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetControlOutputDisplay(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(42965177745)
                    
                    //--TRIMMABLE-BOUNDARY-START(51585979793)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.OTA.IUpdatableDevice.FamilyName.get
                    get LCICO$IUpdatableDevice$FamilyName()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25816176017);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.FamilyName;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51585979793)
                    
                    //--TRIMMABLE-BOUNDARY-START(60175914385)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.OTA.IUpdatableDevice.UniqueId.get
                    get LCICO$IUpdatableDevice$UniqueId()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64470881681);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.UniqueId;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60175914385)
                    
                    //--TRIMMABLE-BOUNDARY-START(34406110609)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.OTA.IUpdatableDevice.CanUpdate.get
                    get LCICO$IUpdatableDevice$CanUpdate()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12931274129);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CanUpdate;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34406110609)
                    
                    //--TRIMMABLE-BOUNDARY-START(42996045201)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.OTA.IUpdatableDevice.CurrentFirmwareVersion.get
                    get LCICO$IUpdatableDevice$CurrentFirmwareVersion()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21521208721);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CurrentFirmwareVersion;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42996045201)
                    
                    //--TRIMMABLE-BOUNDARY-START(4341339537)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.OTA.IUpdatableDevice.BeginUpdate(LivingThing.Core.IOT.Common.OTA.IOTDeviceFirmwareUpdatingModel)
                    LCICO$IUpdatableDevice$BeginUpdate()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4341339537);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.BeginUpdate(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4341339537)
                    
                    //--TRIMMABLE-BOUNDARY-START(17226241425)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.OTA.IUpdatableDevice.ContinueUpdate(LivingThing.Core.IOT.Common.OTA.IOTDeviceFirmwareUpdatingModel, System.TimeSpan?)
                    LCICO$IUpdatableDevice$ContinueUpdate()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17226241425);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ContinueUpdate(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17226241425)
                    
                    //--TRIMMABLE-BOUNDARY-START(8636306833)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.OTA.IUpdatableDevice.CancelUpdate()
                    LCICO$IUpdatableDevice$CancelUpdate()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8636306833);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CancelUpdate(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8636306833)
                    
                    //--TRIMMABLE-BOUNDARY-START(4321023377)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceConfigurationProvider.GetRemoteHardwareSettings()
                    LCICI$IIOTDeviceConfigurationProvider$GetRemoteHardwareSettings()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4321023377);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetRemoteHardwareSettings(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4321023377)
                    
                    //--TRIMMABLE-BOUNDARY-START(8615990673)
                    //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceConfigurationProvider.SetRemoteHardwareConfig(LivingThing.Core.IOT.Common.Interface.IIOTDeviceInternalConfiguration)
                    LCICI$IIOTDeviceConfigurationProvider$SetRemoteHardwareConfig()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8615990673);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.SetRemoteHardwareConfig(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8615990673)
                    
                    static $H = 518045;
                    static $h = 518045;
                    static $f = 0b10000000001110001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings).SmartGenericDevice; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245158301),
    {
      "p": 29922705,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90194831261,
        "h": Number(BigInt(518045)|0x1500000000n),
        "f": 50364417
      },
      "n": "Features",
      "d": 518045,
      "H": 47245158301,
      "h": Number(BigInt(518045)|0xB00000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47245158301),
//--TRIMMABLE-BOUNDARY-START(176094177181),
    {
      "p": 28415377,
      "g": {
        "r": 0,
        "d": 0,
        "H": 124554569629,
        "h": Number(BigInt(518045)|0x1D00000000n),
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 201863980957,
        "h": Number(BigInt(518045)|0x2F00000000n),
        "f": 83918849
      },
      "n": "ReceivedStatus",
      "d": 518045,
      "H": 176094177181,
      "h": Number(BigInt(518045)|0x2900000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(176094177181),
//--TRIMMABLE-BOUNDARY-START(42950191005),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81604896669,
        "h": Number(BigInt(518045)|0x1300000000n),
        "f": 50331649
      },
      "n": "FamilyName",
      "d": 518045,
      "H": 42950191005,
      "h": Number(BigInt(518045)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950191005),
//--TRIMMABLE-BOUNDARY-START(163209275293),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 107374700445,
        "h": Number(BigInt(518045)|0x1900000000n),
        "f": 50331649
      },
      "n": "InputStates",
      "d": 518045,
      "H": 163209275293,
      "h": Number(BigInt(518045)|0x2600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163209275293),
//--TRIMMABLE-BOUNDARY-START(167504242589),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 115964635037,
        "h": Number(BigInt(518045)|0x1B00000000n),
        "f": 50331649
      },
      "n": "OutputStates",
      "d": 518045,
      "H": 167504242589,
      "h": Number(BigInt(518045)|0x2700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167504242589),
//--TRIMMABLE-BOUNDARY-START(12885419933),
    {
      "p": $.$typeArray($.$$.S.Single).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55835092893,
        "h": Number(BigInt(518045)|0xD00000000n),
        "f": 50331649
      },
      "n": "AnalogStates",
      "d": 518045,
      "H": 12885419933,
      "h": Number(BigInt(518045)|0x300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885419933),
//--TRIMMABLE-BOUNDARY-START(180389144477),
    {
      "p": 26056081,
      "g": {
        "r": 0,
        "d": 0,
        "H": 133144504221,
        "h": Number(BigInt(518045)|0x1F00000000n),
        "f": 50364417
      },
      "n": "RemoteConfigurationProvider",
      "d": 518045,
      "H": 180389144477,
      "h": Number(BigInt(518045)|0x2A00000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180389144477),
//--TRIMMABLE-BOUNDARY-START(210453915549),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 141734438813,
        "h": Number(BigInt(518045)|0x2100000000n),
        "f": 50364417
      },
      "n": "StatusDescriptor",
      "d": 518045,
      "H": 210453915549,
      "h": Number(BigInt(518045)|0x3100000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(210453915549),
//--TRIMMABLE-BOUNDARY-START(158914307997),
    {
      "p": 24417681,
      "g": {
        "r": 0,
        "d": 0,
        "H": 98784765853,
        "h": Number(BigInt(518045)|0x1700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 193274046365,
        "h": Number(BigInt(518045)|0x2D00000000n),
        "f": 83886082
      },
      "n": "HardwareDescriptor",
      "d": 518045,
      "H": 158914307997,
      "h": Number(BigInt(518045)|0x2500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914307997),
//--TRIMMABLE-BOUNDARY-START(38655223709),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73014962077,
        "h": Number(BigInt(518045)|0x1100000000n),
        "f": 50331649
      },
      "n": "CurrentFirmwareVersion",
      "d": 518045,
      "H": 38655223709,
      "h": Number(BigInt(518045)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655223709),
//--TRIMMABLE-BOUNDARY-START(30065289117),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64425027485,
        "h": Number(BigInt(518045)|0xF00000000n),
        "f": 50331649
      },
      "n": "CanUpdate",
      "d": 518045,
      "H": 30065289117,
      "h": Number(BigInt(518045)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065289117)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(154619340701),
    {
      "r": 46238038,
      "p": [
        {
          "n": "input",
          "p": 655361
        }
      ],
      "n": "GetSensoryInputDisplay",
      "d": 518045,
      "H": 154619340701,
      "h": Number(BigInt(518045)|0x2400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(154619340701),
//--TRIMMABLE-BOUNDARY-START(146029406109),
    {
      "r": 46238038,
      "p": [
        {
          "n": "output",
          "p": 655361
        }
      ],
      "n": "GetControlOutputDisplay",
      "d": 518045,
      "H": 146029406109,
      "h": Number(BigInt(518045)|0x2200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(146029406109),
//--TRIMMABLE-BOUNDARY-START(171799209885),
    {
      "r": 181338113,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "names",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "RaisePropertyChanged",
      "d": 518045,
      "H": 171799209885,
      "h": Number(BigInt(518045)|0x2800000000n),
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(171799209885),
//--TRIMMABLE-BOUNDARY-START(184684111773),
    {
      "r": 178454529,
      "n": "ResetStatus",
      "d": 518045,
      "H": 184684111773,
      "h": Number(BigInt(518045)|0x2B00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184684111773),
//--TRIMMABLE-BOUNDARY-START(21475354525),
    {
      "r": 178454529,
      "p": [
        {
          "n": "scope",
          "p": 28546449
        }
      ],
      "n": "BindToScope",
      "d": 518045,
      "H": 21475354525,
      "h": Number(BigInt(518045)|0x500000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475354525),
//--TRIMMABLE-BOUNDARY-START(17180387229),
    {
      "r": $.$$.STT.Task$$($.$XBGm.LCICO.FirmwareUpdateStatus).$h,
      "p": [
        {
          "n": "update",
          "p": 46110097
        }
      ],
      "n": "BeginUpdate",
      "d": 518045,
      "H": 17180387229,
      "h": Number(BigInt(518045)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180387229),
//--TRIMMABLE-BOUNDARY-START(34360256413),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "update",
          "p": 46110097
        },
        {
          "n": "packetTimeOut",
          "p": $.$typeNullable($.$$.S.TimeSpan).$h,
          "f": 65
        }
      ],
      "n": "ContinueUpdate",
      "d": 518045,
      "H": 34360256413,
      "h": Number(BigInt(518045)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360256413),
//--TRIMMABLE-BOUNDARY-START(25770321821),
    {
      "r": 178454529,
      "n": "CancelUpdate",
      "d": 518045,
      "H": 25770321821,
      "h": Number(BigInt(518045)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770321821),
//--TRIMMABLE-BOUNDARY-START(150324373405),
    {
      "r": $.$$.STT.Task$$($.$XBGm.LCICI.RemoteHardwareSettings).$h,
      "n": "GetRemoteHardwareSettings",
      "d": 518045,
      "H": 150324373405,
      "h": Number(BigInt(518045)|0x2300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150324373405),
//--TRIMMABLE-BOUNDARY-START(206158948253),
    {
      "r": 178454529,
      "p": [
        {
          "n": "configuration",
          "p": 27170193
        }
      ],
      "n": "SetRemoteHardwareConfig",
      "d": 518045,
      "H": 206158948253,
      "h": Number(BigInt(518045)|0x3000000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(206158948253)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590452637),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$(TSmartDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": TDeviceModel?.$h??2162688
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 518045,
      "H": 8590452637,
      "h": Number(BigInt(518045)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590452637)
  ],
  "d": 452509,
  "H": 518045,
  "h": 518045
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.iSmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName},${TReceivedStatusModel?.$fullName}>+iSmartGenericDevice`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}iSmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TDeviceScopeModel?.$getFullName(separator)}$${TDeviceScopeSettings?.$getFullName(separator)}$${TDeviceScopeStates?.$getFullName(separator)}$${TDeviceModel?.$getFullName(separator)}$${TDeviceSettings?.$getFullName(separator)}$${TDeviceHardwareSettings?.$getFullName(separator)}$${TDeviceStates?.$getFullName(separator)}$${TDeviceStatusModel?.$getFullName(separator)}$${TDeviceCommandModel?.$getFullName(separator)}$${TDeviceReceivedDataModel?.$getFullName(separator)}$${TDeviceSendDataModel?.$getFullName(separator)}$${TDeviceStatusHandler?.$getFullName(separator)}$${TServiceHubClient?.$getFullName(separator)}$${TServicesRemoteService?.$getFullName(separator)}$${TDeviceGlobalSettings?.$getFullName(separator)}$${TReceivedStatusModel?.$getFullName(separator)}$${separator}iSmartGenericDevice`; }
                }, $cls, ($v) => $cls.$_iSmartGenericDevice = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(518045)
            
            //--TRIMMABLE-BOUNDARY-START(4295419805)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295419805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295419805)
            
            //--TRIMMABLE-BOUNDARY-START(4295419805)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295419805)
            
            static $H = 452509;
            static $h = 452509;
            static $g = 22;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295419805),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4295419805,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295419805)
  ],
  "s": [
    {
      "h": TSmartDevice?.$h??1572864,
      "n": "TSmartDevice",
      "c": [1501085
      ]
    },
    {
      "h": TServiceModel?.$h??1638400,
      "n": "TServiceModel",
      "f": 4,
      "c": [32019857
      ]
    },
    {
      "h": TServiceTierType?.$h??1703936,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TServiceFeatureType?.$h??1769472,
      "n": "TServiceFeatureType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TServiceSettings?.$h??1835008,
      "n": "TServiceSettings",
      "f": 4,
      "c": [55678353
      ]
    },
    {
      "h": TServiceStates?.$h??1900544,
      "n": "TServiceStates",
      "f": 4,
      "c": [59807121
      ]
    },
    {
      "h": TDeviceScopeModel?.$h??1966080,
      "n": "TDeviceScopeModel",
      "f": 4,
      "c": [31495569
      ]
    },
    {
      "h": TDeviceScopeSettings?.$h??2031616,
      "n": "TDeviceScopeSettings",
      "f": 4,
      "c": [54564241
      ]
    },
    {
      "h": TDeviceScopeStates?.$h??2097152,
      "n": "TDeviceScopeStates",
      "f": 4,
      "c": [59282833
      ]
    },
    {
      "h": TDeviceModel?.$h??2162688,
      "n": "TDeviceModel",
      "f": 4,
      "c": [31233425
      ]
    },
    {
      "h": TDeviceSettings?.$h??2228224,
      "n": "TDeviceSettings",
      "f": 4,
      "c": [31757713
      ]
    },
    {
      "h": TDeviceHardwareSettings?.$h??2293760,
      "n": "TDeviceHardwareSettings",
      "f": 4,
      "c": [18322833
      ]
    },
    {
      "h": TDeviceStates?.$h??2359296,
      "n": "TDeviceStates",
      "f": 4,
      "c": [59544977
      ]
    },
    {
      "h": TDeviceStatusModel?.$h??2424832,
      "n": "TDeviceStatusModel",
      "f": 4,
      "c": [39687569
      ]
    },
    {
      "h": TDeviceCommandModel?.$h??2490368,
      "n": "TDeviceCommandModel",
      "f": 4,
      "c": [35427729
      ]
    },
    {
      "h": TDeviceReceivedDataModel?.$h??2555904,
      "n": "TDeviceReceivedDataModel",
      "f": 4,
      "c": [$.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$(TReceivedStatusModel).$h
      ]
    },
    {
      "h": TDeviceSendDataModel?.$h??2621440,
      "n": "TDeviceSendDataModel",
      "f": 4,
      "c": [23827857
      ]
    },
    {
      "h": TDeviceStatusHandler?.$h??2686976,
      "n": "TDeviceStatusHandler",
      "c": [31102353
      ]
    },
    {
      "h": TServiceHubClient?.$h??2752512,
      "n": "TServiceHubClient",
      "f": 1,
      "c": [31036817
      ]
    },
    {
      "h": TServicesRemoteService?.$h??2818048,
      "n": "TServicesRemoteService",
      "f": 1,
      "c": [31167889
      ]
    },
    {
      "h": TDeviceGlobalSettings?.$h??2883584,
      "n": "TDeviceGlobalSettings",
      "f": 4,
      "c": [53908881
      ]
    },
    {
      "h": TReceivedStatusModel?.$h??2949120,
      "n": "TReceivedStatusModel",
      "c": [23434641
      ]
    }
  ],
  "r": 22,
  "H": 452509,
  "h": this.$h
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings, TReceivedStatusModel).iSmartGenericDeviceScopeFactory, $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings, TReceivedStatusModel).iSmartGenericDeviceServiceAsScope, $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings, TReceivedStatusModel).iSmartGenericDeviceScope, $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings, TReceivedStatusModel).iSmartGenericServerDeviceScopeFactory, $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, TServiceModel, TServiceTierType, TServiceFeatureType, TServiceSettings, TServiceStates, TDeviceScopeModel, TDeviceScopeSettings, TDeviceScopeStates, TDeviceModel, TDeviceSettings, TDeviceHardwareSettings, TDeviceStates, TDeviceStatusModel, TDeviceCommandModel, TDeviceReceivedDataModel, TDeviceSendDataModel, TDeviceStatusHandler, TServiceHubClient, TServicesRemoteService, TDeviceGlobalSettings, TReceivedStatusModel).iSmartGenericDevice ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.iSmartGenericDeviceDefinition<${TSmartDevice?.$fullName},${TServiceModel?.$fullName},${TServiceTierType?.$fullName},${TServiceFeatureType?.$fullName},${TServiceSettings?.$fullName},${TServiceStates?.$fullName},${TDeviceScopeModel?.$fullName},${TDeviceScopeSettings?.$fullName},${TDeviceScopeStates?.$fullName},${TDeviceModel?.$fullName},${TDeviceSettings?.$fullName},${TDeviceHardwareSettings?.$fullName},${TDeviceStates?.$fullName},${TDeviceStatusModel?.$fullName},${TDeviceCommandModel?.$fullName},${TDeviceReceivedDataModel?.$fullName},${TDeviceSendDataModel?.$fullName},${TDeviceStatusHandler?.$fullName},${TServiceHubClient?.$fullName},${TServicesRemoteService?.$fullName},${TDeviceGlobalSettings?.$fullName},${TReceivedStatusModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}iSmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$${TServiceModel?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TServiceFeatureType?.$getFullName(separator)}$${TServiceSettings?.$getFullName(separator)}$${TServiceStates?.$getFullName(separator)}$${TDeviceScopeModel?.$getFullName(separator)}$${TDeviceScopeSettings?.$getFullName(separator)}$${TDeviceScopeStates?.$getFullName(separator)}$${TDeviceModel?.$getFullName(separator)}$${TDeviceSettings?.$getFullName(separator)}$${TDeviceHardwareSettings?.$getFullName(separator)}$${TDeviceStates?.$getFullName(separator)}$${TDeviceStatusModel?.$getFullName(separator)}$${TDeviceCommandModel?.$getFullName(separator)}$${TDeviceReceivedDataModel?.$getFullName(separator)}$${TDeviceSendDataModel?.$getFullName(separator)}$${TDeviceStatusHandler?.$getFullName(separator)}$${TServiceHubClient?.$getFullName(separator)}$${TServicesRemoteService?.$getFullName(separator)}$${TDeviceGlobalSettings?.$getFullName(separator)}$${TReceivedStatusModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(452509)
        
        

        //--TRIMMABLE-BOUNDARY-START(1370013)
        $asm.$cls(`$NXre.LCIDS.Startup`, ($self) => class Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4296337309)
            static /*void */ AddScopes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296337309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$NXre.LCIDSH.HomeScopeFactory, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceScopeFactory))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$NXre.LCIDSH.HomeScopeFactory, x);
                }, $bhNQRi ??= {"r":28611985,"p":[{"n":"x","p":327718}],"n":"","d":1370013,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$NXre.LCIDSG.GroupScopeFactory, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4296337309)
            
            static $h = 1370013;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296337309),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddScopes",
      "d": 1370013,
      "h": 4296337309,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296337309)
  ],
  "h": 1370013
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Scopes.Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Scopes${separator}Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1370013)
        
        

        //--TRIMMABLE-BOUNDARY-START(2418589)
        $asm.$cls(`$NXre.LCID.Utility`, ($self) => class Utility
        {
            //--TRIMMABLE-BOUNDARY-START(17182287773)
            static /*string */ ResolvePath(/*this string*/ path, /*object*/ owner)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182287773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Replace$3.call(path, "~", $.$$.S.Object.GetType.call(owner).Assembly.GetName().Name);
            }
            //--TRIMMABLE-BOUNDARY-END(17182287773)
            
            //--TRIMMABLE-BOUNDARY-START(4297385885)
            static /*Task<T> *//*async*/  Convert(T, /*this IDeviceStore*/ store, /*IOTDeviceModel*/ model)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(T), T, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297385885);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (model.Identifier.Empty)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$XBGm.LCIC.UtilityExtension.Convert$2(T, model));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t1 = store.LCICD$ISmartDataStoreT$$$GetByIdAsync(T, model.Identifier.Id).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))) ?? $.$XBGm.LCIC.UtilityExtension.Convert$2(T, model));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(4297385885)
            
            //--TRIMMABLE-BOUNDARY-START(8592353181)
            static /*IOTServiceModel */ ConvertService(TModel, /*TModel*/ model, /*bool*/ modelHasChanged)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592353181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let t;
                if ($.$is(model, $.$XBGm.LCICM.IOTServiceModel, { set $v($v){ t = $v; } }))
                {
                    return t;
                }
                if (modelHasChanged)
                {
                    $.$fPer.LCFCD.DataMappingExtension.JsonMapStale(TModel, $.$XBGm.LCICM.IOTServiceModel, model, true);
                }
                /*var*/ let n = $.$fPer.LCFCD.DataMappingExtension.JsonMap(TModel, $.$XBGm.LCICM.IOTServiceModel, model, null, null, true);
                n.RemoteModel ??= $.$fPer.LCFCS$1.Serialized.op_Implicit$1($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize(TModel, model, true, false, true, false, false, false, false, "ConvertService", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices\\Utility.cs", "ConvertService", 49));
                return n;
            }
            //--TRIMMABLE-BOUNDARY-END(8592353181)
            
            //--TRIMMABLE-BOUNDARY-START(12887320477)
            static /*TServiceModel */ ConvertService$1(TServiceModel, /*IOTServiceModel*/ model, /*bool*/ modelHasChanged)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887320477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let t;
                if ($.$is(model, TServiceModel, { set $v($v){ t = $v; } }))
                {
                    return t;
                }
                if (modelHasChanged)
                {
                    $.$fPer.LCFCD.DataMappingExtension.JsonMapStale($.$XBGm.LCICM.IOTServiceModel, TServiceModel, model, true);
                }
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(12887320477)
            
            static $h = 2418589;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182287773),
    {
      "r": 1310721,
      "p": [
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "owner",
          "p": 131073
        }
      ],
      "n": "ResolvePath",
      "d": 2418589,
      "h": 17182287773,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17182287773),
//--TRIMMABLE-BOUNDARY-START(4297385885),
    {
      "r": (T) => $.$$.STT.Task$$(T).$h,
      "p": [
        {
          "n": "store",
          "p": 1283473
        },
        {
          "n": "model",
          "p": 37459345
        }
      ],
      "g": [
        "T"
      ],
      "n": "Convert",
      "d": 2418589,
      "h": 4297385885,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(4297385885),
//--TRIMMABLE-BOUNDARY-START(8592353181),
    {
      "r": 42046865,
      "p": [
        {
          "n": "model",
          "p": (TModel) => TModel.$h
        },
        {
          "n": "modelHasChanged",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "g": [
        "TModel"
      ],
      "n": "ConvertService",
      "d": 2418589,
      "h": 8592353181,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8592353181),
//--TRIMMABLE-BOUNDARY-START(12887320477),
    {
      "r": (TServiceModel) => TServiceModel.$h,
      "p": [
        {
          "n": "model",
          "p": 42046865
        },
        {
          "n": "modelHasChanged",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "g": [
        "TServiceModel"
      ],
      "n": "ConvertService",
      "o": "@$1",
      "d": 2418589,
      "h": 12887320477,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887320477)
  ],
  "h": 2418589
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Utility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Utility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2418589)
        
        

        //--TRIMMABLE-BOUNDARY-START(190365)
        $asm.$cls(`$NXre.LCID.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180059549)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$sl.SL.Enumerable.Empty($.$$.S.String);
            }
            //--TRIMMABLE-BOUNDARY-END(17180059549)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295157661)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295157661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295157661)
            
            //--TRIMMABLE-BOUNDARY-START(4295157661)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295157661)
            
            static $h = 190365;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180059549),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885092253,
        "f": 50331649
      },
      "n": "Paths",
      "d": 190365,
      "h": 17180059549,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180059549)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295157661),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 190365,
      "h": 4295157661,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295157661)
  ],
  "h": 190365
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(190365)
        
        

        //--TRIMMABLE-BOUNDARY-START(845725)
        $asm.$cls(`$NXre.LCID.ResponsiveKeyValue<,>`, (TKey, TValue) => $asm.$gt(`$NXre.LCID.ResponsiveKeyValue<,>`, [TKey, TValue], ($self) => class ResponsiveKeyValue$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(47245485981)
            /*PropertyChangedEventHandler*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(47245485981)
            
            //--TRIMMABLE-BOUNDARY-START(47245485981)
            //--TRIMMABLE-BOUNDARY-START(21475682205)
            add_PropertyChanged(/*PropertyChangedEventHandler*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475682205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475682205)
            
            //--TRIMMABLE-BOUNDARY-START(55835420573)
            remove_PropertyChanged(/*PropertyChangedEventHandler*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835420573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(55835420573)
            
            //--TRIMMABLE-BOUNDARY-END(47245485981)
            
            //--TRIMMABLE-BOUNDARY-START(42950518685)
            /*TKey*/ Key = $.$default(TKey);
            //--TRIMMABLE-BOUNDARY-END(42950518685)
            
            //--TRIMMABLE-BOUNDARY-START(77310257053)
            /*TValue*/ Value = $.$default(TValue);
            //--TRIMMABLE-BOUNDARY-END(77310257053)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(12885747613)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885747613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885747613)
            
            //--TRIMMABLE-BOUNDARY-START(12885747613)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885747613)
            
            static $H = 845725;
            static $h = 845725;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950518685),
    {
      "p": TKey?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30065616797,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 64425355165,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 83886081
      },
      "n": "Key",
      "d": this.$h,
      "H": 42950518685,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950518685),
//--TRIMMABLE-BOUNDARY-START(77310257053),
    {
      "p": TValue?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38655551389,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 73015289757,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 83886081
      },
      "n": "Value",
      "d": this.$h,
      "H": 77310257053,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310257053)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885747613),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 12885747613,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885747613)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(47245485981),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": this.$h,
        "H": 21475682205,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": this.$h,
        "H": 55835420573,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": this.$h,
      "H": 47245485981,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(47245485981)
  ],
  "s": [
    {
      "h": TKey?.$h??1572864,
      "n": "TKey"
    },
    {
      "h": TValue?.$h??1638400,
      "n": "TValue"
    }
  ],
  "r": 2,
  "H": 845725,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.ResponsiveKeyValue<${TKey?.$fullName},${TValue?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}ResponsiveKeyValue$${TKey?.$getFullName(separator)}$${TValue?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(845725)
        
        

        //--TRIMMABLE-BOUNDARY-START(124829)
        $asm.$cls(`$NXre.LCID.ClassConfigurationProvider<>`, (T) => $asm.$gt(`$NXre.LCID.ClassConfigurationProvider<>`, [T], ($self) => class ClassConfigurationProvider$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590059421)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590059421);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590059421)
            
            //--TRIMMABLE-BOUNDARY-START(12885026717)
            $ctor$2(/*T*/ $class)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885026717);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Target = $class;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885026717)
            
            //--TRIMMABLE-BOUNDARY-START(34359863197)
            /*T*/ Target = $.$default(T);
            //--TRIMMABLE-BOUNDARY-END(34359863197)
            
            //--TRIMMABLE-BOUNDARY-START(30064895901)
            /*Task */ SetRemoteHardwareConfig(/*IIOTDeviceInternalConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064895901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(30064895901)
            
            //--TRIMMABLE-BOUNDARY-START(25769928605)
            /*Task<RemoteHardwareSettings> */ LCICI$IIOTDeviceConfigurationProvider$GetRemoteHardwareSettings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769928605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$XBGm.LCICI.RemoteHardwareSettings, (() =>
                {
                    //new $.$XBGm.LCICI.RemoteHardwareSettings()
                    const $t1 = $.$XBGm.LCICI.RemoteHardwareSettings;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Settings = $.$box(this.Target, T);
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(25769928605)
            
            //--TRIMMABLE-BOUNDARY-START(8615990673)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceConfigurationProvider.SetRemoteHardwareConfig(LivingThing.Core.IOT.Common.Interface.IIOTDeviceInternalConfiguration)
            LCICI$IIOTDeviceConfigurationProvider$SetRemoteHardwareConfig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8615990673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetRemoteHardwareConfig(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8615990673)
            
            //--TRIMMABLE-BOUNDARY-START(8590059421)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590059421)
            
            static $H = 124829;
            static $h = 124829;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359863197),
    {
      "p": T?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21474961309,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331650
      },
      "n": "Target",
      "d": this.$h,
      "H": 34359863197,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(34359863197)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064895901),
    {
      "r": 178454529,
      "p": [
        {
          "n": "configuration",
          "p": 27170193
        }
      ],
      "n": "SetRemoteHardwareConfig",
      "d": this.$h,
      "H": 30064895901,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064895901)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590059421),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8590059421,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590059421),
//--TRIMMABLE-BOUNDARY-START(12885026717),
    {
      "p": [
        {
          "n": "class",
          "p": T?.$h??1572864
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 12885026717,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885026717)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "c": [27039121
      ]
    }
  ],
  "r": 1,
  "H": 124829,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceConfigurationProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.ClassConfigurationProvider<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}ClassConfigurationProvider$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(124829)
        
        

        //--TRIMMABLE-BOUNDARY-START(1435549)
        $asm.$cls(`$NXre.LCID.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591370141)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591370141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$NXre.LCID.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fXpo.LCFCPC.IPipelineCollection$$($.$NXre.LCID.SmartDeviceBase), $.$fXpo.LCFCPC.DIPipelineCollection$$($.$NXre.LCID.SmartDeviceBase), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$NXre.LCID.SmartDeviceBase, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/**/ s) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$NXre.LCID.SmartDeviceBase, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDeviceFamily, s);
                }, $NkaNJe ??= {"r":26711441,"p":[{"n":"s","p":327718}],"n":"","d":1435549,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*s*/ s) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$NXre.LCID.SmartDeviceBase, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDeviceFamily, s);
                }, $rptkgc ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"s","p":327718}],"n":"","d":1435549,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$NXre.LCID.SmartGenericDeviceDataConverter, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)))().$ctor(this,  (/*s*/ s) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$NXre.LCID.SmartGenericDeviceDataConverter, s);
                }, $nLtCQd ??= {"r":$.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h,"p":[{"n":"s","p":327718}],"n":"","d":1435549,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$NXre.LCID.IOTDeviceFactory, services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$NXre.LCID.IOTDeviceFactory))().$ctor(this,  (/**/ services) =>
                {
                    return new $.$NXre.LCID.IOTDeviceFactory().$ctor(this, /*async*/  (/*scope*/ scope, /*model*/ model) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$NXre.LCID.SmartDeviceBase), $.$NXre.LCID.SmartDeviceBase, async ($asnycContext) => 
                        {
                            /*var*/ let store = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$XBGm.LCICD.IDeviceStore, services);
                            /*var*/ let factories = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceScopeFactory), services);
                            /*string*/ let __ca1__;
                            /*var*/ let familyName = ($.$strNN(((__ca1__ = model.LCICI$IIOTDeviceModel$FamilyName) !== null ? $.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call(__ca1__, " ", ""), "Device", "") : null)) + "Device");
                            /*var*/ let families = $.$sl.SL.Enumerable.SelectMany$2($.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$XBGm.LCICI.IIOTDeviceFamily, factories, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily)))().$ctor(this,  (/**/ f) =>
                            {
                                return f.LCICI$IIOTDeviceScopeFactory$DeviceFamilies;
                            }, $TraUDg ??= {"r":$.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily).$h,"p":[{"n":"f","p":28611985}],"n":"","d":1435549,"h":0,"f":17825794}));
                            /*var*/ let family = $.$sl.SL.Enumerable.SingleOrDefault$1($.$XBGm.LCICI.IIOTDeviceFamily, families, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDeviceFamily, $.$$.S.Boolean))().$ctor(this,  (/*df*/ df) =>
                            {
                                return df.LCFC$INamed$Name === familyName || df.LCFC$INamed$Name === model.LCICI$IIOTDeviceModel$FamilyName;
                            }, $hCBuDh ??= {"r":262145,"p":[{"n":"df","p":26711441}],"n":"","d":1435549,"h":0,"f":17825794}));
                            if (family !== null)
                            {
                                return $.$$.N.AsyncResolver.Result($asnycContext, $.$cast(family.LCICI$IIOTDeviceFamily$CreateDevice(scope, model), $.$NXre.LCID.SmartDeviceBase));
                            }
                            return $.$$.N.AsyncResolver.Result($asnycContext, null);
                        });
                    }, $WFMFbb ??= {"r":$.$$.STT.Task$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"scope","p":28546449},{"n":"model","p":27432337}],"n":"","d":1435549,"h":0,"f":17829890});
                }, $UHUdeg ??= {"r":321437,"p":[{"n":"services","p":327718}],"n":"","d":1435549,"h":0,"f":17825794}));
                $.$NXre.LCIDS.Startup.AddScopes(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591370141)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$NXre.LCID.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296402845)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296402845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296402845)
            
            //--TRIMMABLE-BOUNDARY-START(4296402845)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296402845)
            
            static $h = 1435549;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591370141),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1435549,
      "h": 8591370141,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591370141)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296402845),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1435549,
      "h": 4296402845,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296402845)
  ],
  "h": 1435549
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1435549)
        
        

        //--TRIMMABLE-BOUNDARY-START(321437)
        $asm.$cls(`$NXre.LCID.IOTDeviceFactory`, ($self) => class IOTDeviceFactory extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*Task<SmartDeviceBase?>*/ Invoke(/**/ ownerScope, /**/ model)
            {
                return this.$nativeFunction.call(this.$target, ownerScope, model);
            }
            static $h = 321437;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180190621),
    {
      "r": $.$$.STT.Task$$($.$NXre.LCID.SmartDeviceBase).$h,
      "p": [
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 27432337
        }
      ],
      "n": "Invoke",
      "d": 321437,
      "h": 17180190621,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180190621),
//--TRIMMABLE-BOUNDARY-START(8590256029),
    {
      "r": 90570753,
      "p": [
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 27432337
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 321437,
      "h": 8590256029,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590256029),
//--TRIMMABLE-BOUNDARY-START(12885223325),
    {
      "r": $.$$.STT.Task$$($.$NXre.LCID.SmartDeviceBase).$h,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 321437,
      "h": 12885223325,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885223325)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295288733),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 321437,
      "h": 4295288733,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295288733)
  ],
  "h": 321437
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IOTDeviceFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IOTDeviceFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(321437)
        
        

        //--TRIMMABLE-BOUNDARY-START(386973)
        $asm.$cls(`$NXre.LCID.IOTDeviceFactory<,>`, (TDeviceModel, TDevice) => $asm.$gt(`$NXre.LCID.IOTDeviceFactory<,>`, [TDeviceModel, TDevice], ($self) => class IOTDeviceFactory$$$ extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*Task<TDevice?>*/ Invoke(/**/ ownerScope, /**/ model)
            {
                return this.$nativeFunction.call(this.$target, ownerScope, model);
            }
            static $H = 386973;
            static $h = 386973;
            static $g = 2;
            static $f = 0b11000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180256157),
    {
      "r": $.$$.STT.Task$$(TDevice).$h,
      "p": [
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": TDeviceModel?.$h??1572864
        }
      ],
      "n": "Invoke",
      "d": this.$h,
      "H": 17180256157,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180256157),
//--TRIMMABLE-BOUNDARY-START(8590321565),
    {
      "r": 90570753,
      "p": [
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": TDeviceModel?.$h??1572864
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": this.$h,
      "H": 8590321565,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590321565),
//--TRIMMABLE-BOUNDARY-START(12885288861),
    {
      "r": $.$$.STT.Task$$(TDevice).$h,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": this.$h,
      "H": 12885288861,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885288861)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295354269),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4295354269,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295354269)
  ],
  "s": [
    {
      "h": TDeviceModel?.$h??1572864,
      "n": "TDeviceModel",
      "c": [27432337
      ]
    },
    {
      "h": TDevice?.$h??1638400,
      "n": "TDevice",
      "c": [1501085
      ]
    }
  ],
  "r": 2,
  "H": 386973,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.IOTDeviceFactory<${TDeviceModel?.$fullName},${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}IOTDeviceFactory$${TDeviceModel?.$getFullName(separator)}$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(386973)
        
        

        //--TRIMMABLE-BOUNDARY-START(1566621)
        $asm.$cls(`$NXre.LCID.SmartGenericDeviceDataConverter`, ($self) => class SmartGenericDeviceDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8591501213)
            /*IOTDeviceStatusModel */ Convert$1(/*IOTDeviceReceivedDataModel*/ input, /*object?*/ param)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591501213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.Common.Interface.IIOTDeviceDataPointModel>?*/ let __ca1__;
                return (() =>
                {
                    //new $.$XBGm.LCICM.IOTDeviceStatusModel()
                    const $t1 = $.$XBGm.LCICM.IOTDeviceStatusModel;
                    const $i1 = new $t1();
                    $i1.$ctor$3();
                    $i1.DateCreated = input.DateCreated;
                    $i1.DateExtended = input.DateExtended;
                    $i1.ExtraDataPoints = ((__ca1__ = input.GetDataPoints(16777215/*SchemaType.All*/)) !== null ? $.$sl.SL.Enumerable.Cast($.$XBGm.LCICM.IOTDeviceDataPointModel, __ca1__) : null);
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(8591501213)
            
            //--TRIMMABLE-BOUNDARY-START(4296533917)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296533917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296533917)
            
            //--TRIMMABLE-BOUNDARY-START(4296533917)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296533917)
            
            static $h = 1566621;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591501213),
    {
      "r": 39687569,
      "p": [
        {
          "n": "input",
          "p": 38049169
        },
        {
          "n": "param",
          "p": 131073,
          "f": 65
        }
      ],
      "n": "Convert",
      "o": "@$1",
      "d": 1566621,
      "h": 8591501213,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591501213)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296533917),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1566621,
      "h": 4296533917,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296533917)
  ],
  "h": 1566621
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartGenericDeviceDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartGenericDeviceDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1566621)
        
        

        //--TRIMMABLE-BOUNDARY-START(2353053)
        $asm.$cls(`$NXre.LCID.SmartGenericDeviceDefinition<>`, (TSmartDevice) => $asm.$gt(`$NXre.LCID.SmartGenericDeviceDefinition<>`, [TSmartDevice], ($self) => class SmartGenericDeviceDefinition$$ extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297320349)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297320349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297320349)
            
            //--TRIMMABLE-BOUNDARY-START(4297320349)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297320349)
            
            static $H = 2353053;
            static $h = 2353053;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TSmartDevice, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297320349),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4297320349,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297320349)
  ],
  "s": [
    {
      "h": TSmartDevice?.$h??1572864,
      "n": "TSmartDevice",
      "c": [1501085
      ]
    }
  ],
  "r": 1,
  "H": 2353053,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartGenericDeviceDefinition<${TSmartDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartGenericDeviceDefinition$${TSmartDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2353053)
        
        

        //--TRIMMABLE-BOUNDARY-START(1632157)
        $asm.$cls(`$NXre.LCID.SmartGenericDeviceDefinition`, ($self) => class SmartGenericDeviceDefinition extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$NXre.LCID.SmartDeviceBase, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296599453)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296599453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296599453)
            
            //--TRIMMABLE-BOUNDARY-START(4296599453)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296599453)
            
            static $h = 1632157;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$NXre.LCID.SmartDeviceBase, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296599453),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1632157,
      "h": 4296599453,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296599453)
  ],
  "h": 1632157
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.SmartGenericDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}SmartGenericDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1632157)
        
        

        //--TRIMMABLE-BOUNDARY-START(976797)
        $asm.$cls(`$NXre.LCIDSG.GroupScope<>`, (TDevice) => $asm.$gt(`$NXre.LCIDSG.GroupScope<>`, [TDevice], ($self) => class GroupScope$$ extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TDevice, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDeviceScope
        {
            //--TRIMMABLE-BOUNDARY-START(4295944093)
            $ctor$1(/*SmartGenericDeviceDefinition<TDevice>.SmartGenericDeviceScopeFactory*/ factory, /*IOTDeviceScopeModel*/ scope, /*IEnumerable<IOTDeviceModel>*/ _devices, /*IOTDeviceFactory*/ deviceFactory)
            {
                super.$ctor$1(factory, scope, _devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295944093);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.deviceFactory = deviceFactory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295944093)
            
            //--TRIMMABLE-BOUNDARY-START(8590911389)
            /*IOTDeviceFactory*/ deviceFactory = null;
            //--TRIMMABLE-BOUNDARY-END(8590911389)
            
            //--TRIMMABLE-BOUNDARY-START(12885878685)
            /*Task<TDevice?> *//*async*/  GetDevice(/*IOTDeviceModel*/ model)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(TDevice), TDevice, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885878685);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$cast(($t1 = this.deviceFactory.Invoke(this, model), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))), TDevice));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12885878685)
            
            static $H = 976797;
            static $h = 976797;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$(TDevice, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDeviceScope; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885878685),
    {
      "r": $.$$.STT.Task$$(TDevice).$h,
      "p": [
        {
          "n": "model",
          "p": 37459345
        }
      ],
      "n": "GetDevice",
      "d": this.$h,
      "H": 12885878685,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(12885878685)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590911389),
    {
      "t": 321437,
      "n": "deviceFactory",
      "d": this.$h,
      "H": 8590911389,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590911389)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295944093),
    {
      "p": [
        {
          "n": "factory",
          "p": 2156445
        },
        {
          "n": "scope",
          "p": 38638993
        },
        {
          "n": "_devices",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceModel).$h
        },
        {
          "n": "deviceFactory",
          "p": 321437
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295944093,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295944093)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice",
      "c": [1501085
      ]
    }
  ],
  "r": 1,
  "H": 976797,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScope, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Scopes.Group.GroupScope<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Scopes${separator}Group${separator}GroupScope$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(976797)
        
        

        //--TRIMMABLE-BOUNDARY-START(255901)
        $asm.$cls(`$NXre.LCIDG.SmartGenericDevice`, ($self) => class SmartGenericDevice extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$NXre.LCID.SmartDeviceBase, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4295223197)
            $ctor$2(/*IIOTDeviceFamily<SmartGenericDevice>*/ family, /*IIOTDeviceScope*/ scope, /*IOTDeviceModel*/ model)
            {
                super.$ctor$2($.$$.N.InterfaceVarianceStubHandler.Create(family, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCIDG.SmartGenericDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)), scope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295223197);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295223197)
            
            static $h = 255901;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$NXre.LCID.SmartDeviceBase, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295223197),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCIDG.SmartGenericDevice).$h
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 37459345
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 255901,
      "h": 4295223197,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295223197)
  ],
  "h": 255901
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Generic.SmartGenericDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Generic${separator}SmartGenericDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(255901)
        
        

        //--TRIMMABLE-BOUNDARY-START(911261)
        $asm.$cls(`$NXre.LCIDSG.GroupScope`, ($self) => class GroupScope extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$NXre.LCID.SmartDeviceBase, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDeviceScope
        {
            //--TRIMMABLE-BOUNDARY-START(4295878557)
            $ctor$1(/*SmartGenericDeviceDefinition.SmartGenericDeviceScopeFactory*/ factory, /*IOTDeviceScopeModel*/ scope, /*IEnumerable<IOTDeviceModel>*/ _devices, /*IOTDeviceFactory*/ deviceFactory)
            {
                super.$ctor$1(factory, scope, _devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295878557);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.deviceFactory = deviceFactory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295878557)
            
            //--TRIMMABLE-BOUNDARY-START(8590845853)
            /*IOTDeviceFactory*/ deviceFactory = null;
            //--TRIMMABLE-BOUNDARY-END(8590845853)
            
            //--TRIMMABLE-BOUNDARY-START(12885813149)
            /*Task<SmartDeviceBase?> */ GetDevice(/*IOTDeviceModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885813149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.deviceFactory.Invoke(this, model);
            }
            //--TRIMMABLE-BOUNDARY-END(12885813149)
            
            static $h = 911261;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$NXre.LCID.SmartDeviceBase, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDeviceScope; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885813149),
    {
      "r": $.$$.STT.Task$$($.$NXre.LCID.SmartDeviceBase).$h,
      "p": [
        {
          "n": "model",
          "p": 37459345
        }
      ],
      "n": "GetDevice",
      "d": 911261,
      "h": 12885813149,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885813149)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590845853),
    {
      "t": 321437,
      "n": "deviceFactory",
      "d": 911261,
      "h": 8590845853,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590845853)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295878557),
    {
      "p": [
        {
          "n": "factory",
          "p": 2156445
        },
        {
          "n": "scope",
          "p": 38638993
        },
        {
          "n": "_devices",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceModel).$h
        },
        {
          "n": "deviceFactory",
          "p": 321437
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 911261,
      "h": 4295878557,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295878557)
  ],
  "h": 911261
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScope, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Scopes.Group.GroupScope`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Scopes${separator}Group${separator}GroupScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(911261)
        
        

        //--TRIMMABLE-BOUNDARY-START(1042333)
        $asm.$cls(`$NXre.LCIDSG.GroupScopeFactory`, ($self) => class GroupScopeFactory extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$NXre.LCID.SmartDeviceBase, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDeviceScopeFactory
        {
            //--TRIMMABLE-BOUNDARY-START(8590976925)
            $ctor$1(/*ServiceFactory*/ services, /*IOTDeviceFactory*/ deviceFactory, /*IConfigurationParser*/ config, /*IScopeStore*/ scopeStore, /*IDeviceStore*/ dataStore, /*IEnumerable<IIOTDeviceFamily<SmartDeviceBase>>*/ families, /*IServerRemoteService*/ serverRemoteService)
            {
                super.$ctor$1(services, config, scopeStore, dataStore);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590976925);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.DeviceFactory = deviceFactory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590976925)
            
            //--TRIMMABLE-BOUNDARY-START(17180911517)
            /*IOTDeviceFactory*/ DeviceFactory = null;
            //--TRIMMABLE-BOUNDARY-END(17180911517)
            
            //--TRIMMABLE-BOUNDARY-START(60130584477)
            /*GroupScope */ GetScope(/*IOTDeviceScopeModel*/ scope, /*IEnumerable<IOTDeviceModel>*/ devices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130584477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$NXre.LCIDSG.GroupScope().$ctor$1(this, scope, devices, this.DeviceFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(60130584477)
            
            //--TRIMMABLE-BOUNDARY-START(21475878813)
            /*ScopeFactoryFeatures */ get Features()
            {
                return 1/*ScopeFactoryFeatures.CanAddScope*/ | 2/*ScopeFactoryFeatures.CanAddDevice*/;
            }
            //--TRIMMABLE-BOUNDARY-END(21475878813)
            
            //--TRIMMABLE-BOUNDARY-START(68720519069)
            /*string */ get Icon()
            {
                return "mdi mdi-group"/*MaterialDesignIconNames.Group*/;
            }
            //--TRIMMABLE-BOUNDARY-END(68720519069)
            
            //--TRIMMABLE-BOUNDARY-START(12885944221)
            /*string */ get Description()
            {
                return "Group devices logically";
            }
            //--TRIMMABLE-BOUNDARY-END(12885944221)
            
            //--TRIMMABLE-BOUNDARY-START(73015486365)
            /*Task<IEnumerable<IIOTDeviceScope>> */ LoadScopesAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015486365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceScope), $.$sl.SL.Enumerable.Empty($.$XBGm.LCICI.IIOTDeviceScope));
            }
            //--TRIMMABLE-BOUNDARY-END(73015486365)
            
            //--TRIMMABLE-BOUNDARY-START(64425551773)
            /*Task<IEnumerable<IOTServiceModel>> */ GetServices()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425551773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceModel), this.Scopes.Select$1($.$XBGm.LCICM.IOTServiceModel, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDeviceScope, $.$XBGm.LCICM.IOTServiceModel))().$ctor(this,  (/**/ scope) =>
                {
                    return (() =>
                    {
                        //new $.$XBGm.LCICM.IOTServiceModel()
                        const $t1 = $.$XBGm.LCICM.IOTServiceModel;
                        const $i1 = new $t1();
                        $i1.$ctor$10();
                        $i1.Name = scope.LCICI$IIOTDeviceScope$Name;
                        return $i1;
                    })();
                }, $jjtSra ??= {"r":42046865,"p":[{"n":"scope","p":28546449}],"n":"","d":1042333,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(64425551773)
            
            static $h = 1042333;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$NXre.LCID.SmartDeviceBase, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDeviceScopeFactory; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180911517),
    {
      "p": 321437,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655747997,
        "f": 50331649
      },
      "n": "DeviceFactory",
      "d": 1042333,
      "h": 17180911517,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180911517),
//--TRIMMABLE-BOUNDARY-START(21475878813),
    {
      "p": 30643601,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245682589,
        "f": 50364417
      },
      "n": "Features",
      "d": 1042333,
      "h": 21475878813,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475878813),
//--TRIMMABLE-BOUNDARY-START(68720519069),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835617181,
        "f": 50364417
      },
      "n": "Icon",
      "d": 1042333,
      "h": 68720519069,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68720519069),
//--TRIMMABLE-BOUNDARY-START(12885944221),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065813405,
        "f": 50364417
      },
      "n": "Description",
      "d": 1042333,
      "h": 12885944221,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12885944221)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130584477),
    {
      "r": 911261,
      "p": [
        {
          "n": "scope",
          "p": 38638993
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceModel).$h
        }
      ],
      "n": "GetScope",
      "d": 1042333,
      "h": 60130584477,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130584477),
//--TRIMMABLE-BOUNDARY-START(73015486365),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceScope)).$h,
      "n": "LoadScopesAsync",
      "d": 1042333,
      "h": 73015486365,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(73015486365),
//--TRIMMABLE-BOUNDARY-START(64425551773),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceModel)).$h,
      "n": "GetServices",
      "d": 1042333,
      "h": 64425551773,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425551773)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590976925),
    {
      "p": [
        {
          "n": "services",
          "p": 62949718
        },
        {
          "n": "deviceFactory",
          "p": 321437
        },
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "scopeStore",
          "p": 1545617
        },
        {
          "n": "dataStore",
          "p": 1283473
        },
        {
          "n": "families",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)).$h
        },
        {
          "n": "serverRemoteService",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1042333,
      "h": 8590976925,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590976925)
  ],
  "h": 1042333
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Scopes.Group.GroupScopeFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Scopes${separator}Group${separator}GroupScopeFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1042333)
        
        

        //--TRIMMABLE-BOUNDARY-START(1238941)
        $asm.$cls(`$NXre.LCIDSH.HomeScopeFactory`, ($self) => class HomeScopeFactory extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$NXre.LCID.SmartDeviceBase, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDeviceScopeFactory
        {
            //--TRIMMABLE-BOUNDARY-START(21476075421)
            $ctor$1(/*ServiceFactory*/ services, /*IOTDeviceFactory*/ deviceFactory, /*IConfigurationParser*/ config, /*IScopeStore*/ scopeStore, /*IDeviceStore*/ dataStore, /*IEnumerable<IIOTDeviceFamily<SmartDeviceBase>>*/ families, /*IAuthenticationService*/ authService, /*IServerRemoteService*/ serverRemoteService, /*IWifiClient*/ wifi, /*IIOTDeviceDiscovery*/ deviceFinder)
            {
                super.$ctor$1(services, config, scopeStore, dataStore);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476075421);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.authService = authService;
                    this.server = serverRemoteService;
                    this.Wifi = wifi;
                    this.DeviceFinder = deviceFinder;
                    this.deviceFactory = deviceFactory;
                    /*var*/ let custom = $.$fPer.LCFCS$3.ServiceFactoryExtensions.Get$1($.$XBGm.LCICDC.ICustomIOTDeviceFamilyFactory, services);
                    if (custom !== null)
                    {
                        this.DeviceFamilies = $.$sl.SL.Enumerable.Concat($.$XBGm.LCICI.IIOTDeviceFamily, $.$sl.SL.Enumerable.Cast($.$XBGm.LCICI.IIOTDeviceFamily, families), custom);
                    }
                    else 
                    {
                        this.DeviceFamilies = $.$$.N.InterfaceVarianceStubHandler.Create(families, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily));
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476075421)
            
            //--TRIMMABLE-BOUNDARY-START(25771042717)
            /*IAuthenticationService*/ authService = null;
            //--TRIMMABLE-BOUNDARY-END(25771042717)
            
            //--TRIMMABLE-BOUNDARY-START(124555290525)
            /*IServerRemoteService*/ server = null;
            //--TRIMMABLE-BOUNDARY-END(124555290525)
            
            //--TRIMMABLE-BOUNDARY-START(38655944605)
            /*IEnumerable<IIOTDeviceFamily>*/ DeviceFamilies = null;
            //--TRIMMABLE-BOUNDARY-END(38655944605)
            
            //--TRIMMABLE-BOUNDARY-START(34360977309)
            /*IOTDeviceFactory*/ deviceFactory = null;
            //--TRIMMABLE-BOUNDARY-END(34360977309)
            
            //--TRIMMABLE-BOUNDARY-START(42950911901)
            /*IIOTDeviceDiscovery*/ DeviceFinder = null;
            //--TRIMMABLE-BOUNDARY-END(42950911901)
            
            //--TRIMMABLE-BOUNDARY-START(128850257821)
            /*IWifiClient*/ Wifi = null;
            //--TRIMMABLE-BOUNDARY-END(128850257821)
            
            //--TRIMMABLE-BOUNDARY-START(107375421341)
            /*HomeScope */ GetScope(/*IOTDeviceScopeModel*/ scope, /*IEnumerable<IOTDeviceModel>*/ devices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375421341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$NXre.LCIDSH.HomeScope().$ctor$1(this, scope, devices, this.deviceFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(107375421341)
            
            //--TRIMMABLE-BOUNDARY-START(47245879197)
            /*ScopeFactoryFeatures */ get Features()
            {
                return 1/*ScopeFactoryFeatures.CanAddScope*/ | 2/*ScopeFactoryFeatures.CanAddDevice*/;
            }
            //--TRIMMABLE-BOUNDARY-END(47245879197)
            
            //--TRIMMABLE-BOUNDARY-START(120260323229)
            /*string */ get Icon()
            {
                return "mdi mdi-home"/*MaterialDesignIconNames.Home*/;
            }
            //--TRIMMABLE-BOUNDARY-END(120260323229)
            
            //--TRIMMABLE-BOUNDARY-START(30066010013)
            /*string */ get Description()
            {
                return "Connects home devices and appliances";
            }
            //--TRIMMABLE-BOUNDARY-END(30066010013)
            
            //--TRIMMABLE-BOUNDARY-START(4296206237)
            /*IEnumerable<IOTServiceModel>?*/ _services = null;
            //--TRIMMABLE-BOUNDARY-END(4296206237)
            
            //--TRIMMABLE-BOUNDARY-START(115965355933)
            /*Task<IEnumerable<IOTServiceModel>> *//*async*/  GetServices()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceModel)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceModel), async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115965355933);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._services !== null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, this._services);
                    }
                    /*var*/ let localServices = ($t1 = super.GetServices(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    /*IEnumerable<IOTServiceModel>*/ let remoteServices = $.$sl.SL.Enumerable.Empty($.$XBGm.LCICM.IOTServiceModel);
                    if (($t2 = this.authService.LCFCA$IReadOnlyAuthenticationService$GetIsLoggedIn(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2))))
                    {
                        try
                        {
                            let $t3, $r3;
                            remoteServices = (($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.TryReadMany($.$XBGm.LCICM.IOTServiceModel, this.server, $.$fPer.LCFCD.DataFilter.Default, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)))).Data ?? remoteServices;
                        }
                        catch($e)
                        {
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, this._services = $.$sl.SL.Enumerable.ToList($.$XBGm.LCICM.IOTServiceModel, $.$sl.SL.Enumerable.Distinct$1($.$XBGm.LCICM.IOTServiceModel, $.$sl.SL.Enumerable.Concat($.$XBGm.LCICM.IOTServiceModel, localServices, remoteServices))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(115965355933)
            
            //--TRIMMABLE-BOUNDARY-START(111670388637)
            /*ValueTask<IEnumerable<IOTDeviceScopeModel>> *//*async*/  GetScopes()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceScopeModel)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceScopeModel), async ($asnycContext) => 
                {
                    let $t4, $r4;
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670388637);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let localScopes = ($t4 = super.GetScopes(), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    /*var*/ let services = ($t5 = this.GetServices(), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    /*var*/ let remoteScopes = $.$sl.SL.Enumerable.SelectMany$2($.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTDeviceScopeModel, services, new ($.$$.S.Func$$$($.$XBGm.LCICM.IOTServiceModel, $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceScopeModel)))().$ctor(this,  (/*service*/ service) =>
                    {
                        return service.Scopes ?? $.$sl.SL.Enumerable.Empty($.$XBGm.LCICM.IOTDeviceScopeModel);
                    }, $rtechd ??= {"r":$.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceScopeModel).$h,"p":[{"n":"service","p":42046865}],"n":"","d":1238941,"h":0,"f":17825794}));
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Distinct$1($.$XBGm.LCICM.IOTDeviceScopeModel, $.$sl.SL.Enumerable.Concat($.$XBGm.LCICM.IOTDeviceScopeModel, localScopes, remoteScopes)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(111670388637)
            
            //--TRIMMABLE-BOUNDARY-START(103080454045)
            /*ValueTask<IEnumerable<IOTDeviceModel>> *//*async*/  GetDevices(/*IOTDeviceScopeModel*/ scope)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceModel)), $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceModel), async ($asnycContext) => 
                {
                    let $t6, $r6;
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103080454045);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let localDevices = ($t6 = super.GetDevices(scope), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    /*var*/ let services = ($t7 = this.GetServices(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.Common.Models.IOTServiceModel>*/ let __ca1__;
                    /*var*/ let service = ((__ca1__ = services) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$1($.$XBGm.LCICM.IOTServiceModel, __ca1__, new ($.$$.S.Func$$$($.$XBGm.LCICM.IOTServiceModel, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                    {
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.Common.Models.IOTDeviceScopeModel>?*/ let __ca2__;
                        return ((__ca2__ = s.Scopes) !== null ? $.$sl.SL.Enumerable.Contains$1($.$XBGm.LCICM.IOTDeviceScopeModel, __ca2__, scope) : false);
                    }, $zWxPXa ??= {"r":262145,"p":[{"n":"s","p":42046865}],"n":"","d":1238941,"h":0,"f":17825794})) : null);
                    /*var*/ let remoteDevices = (service?.GetDevices(scope.Devices ?? $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD.DataId)) ?? null) ?? $.$sl.SL.Enumerable.Empty($.$XBGm.LCICM.IOTDeviceModel);
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Distinct$1($.$XBGm.LCICM.IOTDeviceModel, $.$sl.SL.Enumerable.Concat($.$XBGm.LCICM.IOTDeviceModel, localDevices, remoteDevices)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(103080454045)
            
            static $h = 1238941;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$NXre.LCID.SmartDeviceBase, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDeviceScopeFactory; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655944605),
    {
      "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425748381,
        "f": 50364417
      },
      "n": "DeviceFamilies",
      "d": 1238941,
      "h": 38655944605,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655944605),
//--TRIMMABLE-BOUNDARY-START(42950911901),
    {
      "p": 26645905,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015682973,
        "f": 50331656
      },
      "n": "DeviceFinder",
      "d": 1238941,
      "h": 42950911901,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(42950911901),
//--TRIMMABLE-BOUNDARY-START(128850257821),
    {
      "p": 759185,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785486749,
        "f": 50331656
      },
      "n": "Wifi",
      "d": 1238941,
      "h": 128850257821,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(128850257821),
//--TRIMMABLE-BOUNDARY-START(47245879197),
    {
      "p": 30643601,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605617565,
        "f": 50364417
      },
      "n": "Features",
      "d": 1238941,
      "h": 47245879197,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47245879197),
//--TRIMMABLE-BOUNDARY-START(120260323229),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195552157,
        "f": 50364417
      },
      "n": "Icon",
      "d": 1238941,
      "h": 120260323229,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120260323229),
//--TRIMMABLE-BOUNDARY-START(30066010013),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835813789,
        "f": 50364417
      },
      "n": "Description",
      "d": 1238941,
      "h": 30066010013,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30066010013)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107375421341),
    {
      "r": 1173405,
      "p": [
        {
          "n": "scope",
          "p": 38638993
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceModel).$h
        }
      ],
      "n": "GetScope",
      "d": 1238941,
      "h": 107375421341,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107375421341),
//--TRIMMABLE-BOUNDARY-START(115965355933),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceModel)).$h,
      "n": "GetServices",
      "d": 1238941,
      "h": 115965355933,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(115965355933),
//--TRIMMABLE-BOUNDARY-START(111670388637),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceScopeModel)).$h,
      "n": "GetScopes",
      "d": 1238941,
      "h": 111670388637,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(111670388637),
//--TRIMMABLE-BOUNDARY-START(103080454045),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceModel)).$h,
      "p": [
        {
          "n": "scope",
          "p": 38638993
        }
      ],
      "n": "GetDevices",
      "d": 1238941,
      "h": 103080454045,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(103080454045)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25771042717),
    {
      "t": 1655170,
      "n": "authService",
      "d": 1238941,
      "h": 25771042717,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771042717),
//--TRIMMABLE-BOUNDARY-START(124555290525),
    {
      "t": 1309651,
      "n": "server",
      "d": 1238941,
      "h": 124555290525,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(124555290525),
//--TRIMMABLE-BOUNDARY-START(34360977309),
    {
      "t": 321437,
      "n": "deviceFactory",
      "d": 1238941,
      "h": 34360977309,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360977309),
//--TRIMMABLE-BOUNDARY-START(4296206237),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTServiceModel).$h,
      "n": "_services",
      "d": 1238941,
      "h": 4296206237,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296206237)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476075421),
    {
      "p": [
        {
          "n": "services",
          "p": 62949718
        },
        {
          "n": "deviceFactory",
          "p": 321437
        },
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "scopeStore",
          "p": 1545617
        },
        {
          "n": "dataStore",
          "p": 1283473
        },
        {
          "n": "families",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)).$h
        },
        {
          "n": "authService",
          "p": 1655170
        },
        {
          "n": "serverRemoteService",
          "p": 1309651
        },
        {
          "n": "wifi",
          "p": 759185
        },
        {
          "n": "deviceFinder",
          "p": 26645905
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1238941,
      "h": 21476075421,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476075421)
  ],
  "h": 1238941
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Scopes.Home.HomeScopeFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Scopes${separator}Home${separator}HomeScopeFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1238941)
        
        

        //--TRIMMABLE-BOUNDARY-START(1173405)
        $asm.$cls(`$NXre.LCIDSH.HomeScope`, ($self) => class HomeScope extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$NXre.LCID.SmartDeviceBase, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDeviceScope
        {
            //--TRIMMABLE-BOUNDARY-START(4296140701)
            $ctor$1(/*HomeScopeFactory*/ factory, /*IOTDeviceScopeModel*/ scope, /*IEnumerable<IOTDeviceModel>*/ _devices, /*IOTDeviceFactory*/ deviceFactory)
            {
                super.$ctor$1(factory, scope, _devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296140701);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.deviceFactory = deviceFactory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296140701)
            
            //--TRIMMABLE-BOUNDARY-START(12886075293)
            /*IOTDeviceFactory*/ deviceFactory = null;
            //--TRIMMABLE-BOUNDARY-END(12886075293)
            
            //--TRIMMABLE-BOUNDARY-START(17181042589)
            /*Action<DiscoveredIOTDevice>?*/ FoundDelegate = null;
            //--TRIMMABLE-BOUNDARY-END(17181042589)
            
            //--TRIMMABLE-BOUNDARY-START(47245813661)
            /*Task *//*async*/  Scan(/*Action<DiscoveredIOTDevice>*/ found)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245813661);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let impl = $.$fPer.LCFCS$3.ServiceFactoryExtensions.Get$1($.$NXre.LCIDSH.IHomeDeviceFinderImpl, this.Factory.Services);
                    if (impl !== null)
                    {
                        let $t1, $r1;
                        /*var*/ let devices = ($t1 = impl.LCIDSH$IHomeDeviceFinderImpl$ScanAsync(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        let $en2 = devices.SCG$IEnumerable$$$GetEnumerator();
                        while ($en2.SC$1$IEnumerator$MoveNext())
                        {
                            let device = $en2.SCG$IEnumerator$$$Current;
                            {
                                found.Invoke($.$clone(device));
                            }
                        }
                    }
                    else 
                    {
                        let $t3, $r3;
                        this.FoundDelegate = found;
                        _ = super.Scan(found);
                        /*var*/ let factory = $.$cast(this.Factory, $.$NXre.LCIDSH.HomeScopeFactory);
                        /*var*/ let dispose = factory.DeviceFinder.S$IObservable$LivingThing$Core$IOT$Common$Interface$DiscoveredIOTDevice$Subscribe(this);
                        /*Task*/ let delay = $.$$.STT.Task.Delay$1(15000);
                        /*Task*/ let configure = factory.Wifi.LCICC$IWifiClient$SmartConfigure(null, null, 60, null);
                        ($t3 = $.$$.STT.Task.WhenAll$1($.$$.S.ReadOnlySpan$$($.$$.STT.Task).op_Implicit$1([ configure, delay ])).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        dispose.S$IDisposable$Dispose();
                        this.FoundDelegate = null;
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(47245813661)
            
            //--TRIMMABLE-BOUNDARY-START(34360911773)
            /*void */ OnCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360911773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(34360911773)
            
            //--TRIMMABLE-BOUNDARY-START(38655879069)
            /*void */ OnError(/*Exception*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655879069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(38655879069)
            
            //--TRIMMABLE-BOUNDARY-START(42950846365)
            /*void */ OnNext(/*DiscoveredIOTDevice*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950846365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.FoundDelegate?.Invoke($.$clone(value));
            }
            //--TRIMMABLE-BOUNDARY-END(42950846365)
            
            //--TRIMMABLE-BOUNDARY-START(8591107997)
            /*IEnumerable<string> */ get ConnectionIdentifiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770977181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.Common.Interface.IIOTDevice>?*/ let __ca1__;
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.Common.Interface.IIOTDevice>*/ let __ca4__;
                return ((__ca1__ = this.Devices.Value$1) !== null ? (((__ca4__ = $.$sl.SL.Enumerable.Where($.$XBGm.LCICI.IIOTDevice, __ca1__, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDevice, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                {
                    return !$.$$.S.String.IsNullOrEmpty(s.LCICI$IIOTDevice$Model.LCICI$IIOTDeviceModel$UniqueId);
                }, $KtWkni ??= {"r":262145,"p":[{"n":"s","p":25925009}],"n":"","d":1173405,"h":0,"f":17825794}))) !== null ? ($.$sl.SL.Enumerable.Select$1($.$XBGm.LCICI.IIOTDevice, $.$$.S.String, __ca4__, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDevice, $.$$.S.String))().$ctor(this,  (/**/ d) =>
                {
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Data.DataId>?*/ let __ca2__;
                    /*object?*/ let __ca3__;
                    return `${$.$strNN((((__ca2__ = d.LCICI$IIOTDevice$Model.LCICI$IIOTDeviceModel$ScopesId) !== null ? (((__ca3__ = $.$sl.SL.Enumerable.FirstOrDefault$3($.$fPer.LCFCD.DataId, __ca2__).Id) !== null ? ($.$dspc(__ca3__, $.$$.S.Object, ($t) => $t.ToString) ?? "_") : "_") ?? "_") : "_")))}/${$.$strNN(d.LCICI$IIOTDevice$Family.LCICI$IIOTDeviceFamily$ConnectionIdentifier)}/${$.$strNN(d.LCICI$IIOTDevice$Model.LCICI$IIOTDeviceModel$UniqueId)}`;
                }, $SKmwUa ??= {"r":1310721,"p":[{"n":"d","p":25925009}],"n":"","d":1173405,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.Empty($.$$.S.String)) : $.$sl.SL.Enumerable.Empty($.$$.S.String)) ?? $.$sl.SL.Enumerable.Empty($.$$.S.String)) : $.$sl.SL.Enumerable.Empty($.$$.S.String));
            }
            //--TRIMMABLE-BOUNDARY-END(8591107997)
            
            //--TRIMMABLE-BOUNDARY-START(30065944477)
            /*Task<SmartDeviceBase?> */ GetDevice(/*IOTDeviceModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065944477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.deviceFactory.Invoke(this, model);
            }
            //--TRIMMABLE-BOUNDARY-END(30065944477)
            
            //--TRIMMABLE-BOUNDARY-START(12982091777)
            //Generated interface implemetation for System.IObserver<LivingThing.Core.IOT.Common.Interface.DiscoveredIOTDevice>.OnNext(LivingThing.Core.IOT.Common.Interface.DiscoveredIOTDevice)
            S$IObserver$$$OnNext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12982091777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnNext(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12982091777)
            
            //--TRIMMABLE-BOUNDARY-START(8687124481)
            //Generated interface implemetation for System.IObserver<LivingThing.Core.IOT.Common.Interface.DiscoveredIOTDevice>.OnError(System.Exception)
            S$IObserver$$$OnError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8687124481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnError(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8687124481)
            
            //--TRIMMABLE-BOUNDARY-START(4392157185)
            //Generated interface implemetation for System.IObserver<LivingThing.Core.IOT.Common.Interface.DiscoveredIOTDevice>.OnCompleted()
            S$IObserver$$$OnCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4392157185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnCompleted(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4392157185)
            
            static $h = 1173405;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$NXre.LCID.SmartDeviceBase, $.$XBGm.LCICM.IOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$XBGm.LCICM.IOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICM.IOTDeviceModel, $.$XBGm.LCICS$2.IOTDeviceSettings, $.$XBGm.LCICS$2.IOTDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$XBGm.LCICM.IOTDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler, $.$XBGm.LCICH.IIOTDeviceHubClient, $.$XBGm.LCICS$1.IIOTServicesRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDeviceScope; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591107997),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770977181,
        "f": 50364417
      },
      "n": "ConnectionIdentifiers",
      "d": 1173405,
      "h": 8591107997,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591107997)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245813661),
    {
      "r": 178454529,
      "p": [
        {
          "n": "found",
          "p": $.$$.S.Action$$($.$XBGm.LCICI.DiscoveredIOTDevice).$h
        }
      ],
      "n": "Scan",
      "d": 1173405,
      "h": 47245813661,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(47245813661),
//--TRIMMABLE-BOUNDARY-START(34360911773),
    {
      "r": 65537,
      "n": "OnCompleted",
      "d": 1173405,
      "h": 34360911773,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360911773),
//--TRIMMABLE-BOUNDARY-START(38655879069),
    {
      "r": 65537,
      "p": [
        {
          "n": "error",
          "p": 80805889
        }
      ],
      "n": "OnError",
      "d": 1173405,
      "h": 38655879069,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655879069),
//--TRIMMABLE-BOUNDARY-START(42950846365),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 25531793
        }
      ],
      "n": "OnNext",
      "d": 1173405,
      "h": 42950846365,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950846365),
//--TRIMMABLE-BOUNDARY-START(30065944477),
    {
      "r": $.$$.STT.Task$$($.$NXre.LCID.SmartDeviceBase).$h,
      "p": [
        {
          "n": "model",
          "p": 37459345
        }
      ],
      "n": "GetDevice",
      "d": 1173405,
      "h": 30065944477,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30065944477)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886075293),
    {
      "t": 321437,
      "n": "deviceFactory",
      "d": 1173405,
      "h": 12886075293,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886075293),
//--TRIMMABLE-BOUNDARY-START(17181042589),
    {
      "t": $.$$.S.Action$$($.$XBGm.LCICI.DiscoveredIOTDevice).$h,
      "n": "FoundDelegate",
      "d": 1173405,
      "h": 17181042589,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181042589)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296140701),
    {
      "p": [
        {
          "n": "factory",
          "p": 1238941
        },
        {
          "n": "scope",
          "p": 38638993
        },
        {
          "n": "_devices",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceModel).$h
        },
        {
          "n": "deviceFactory",
          "p": 321437
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1173405,
      "h": 4296140701,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296140701)
  ],
  "h": 1173405
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScope, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IObserver$$($.$XBGm.LCICI.DiscoveredIOTDevice) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Scopes.Home.HomeScope`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Scopes${separator}Home${separator}HomeScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1173405)
        
        

        //--TRIMMABLE-BOUNDARY-START(1107869)
        $asm.$cls(`$NXre.LCIDSH.HomeRoomScope`, ($self) => class HomeRoomScope extends $.$NXre.LCIDSH.HomeScope
        {
            //--TRIMMABLE-BOUNDARY-START(4296075165)
            $ctor$2(/*HomeScope*/ home, /*IOTDeviceScopeModel*/ scope, /*IEnumerable<IOTDeviceModel>*/ _devices, /*IOTDeviceFactory*/ deviceFactory)
            {
                super.$ctor$1($.$cast(home.Factory, $.$NXre.LCIDSH.HomeScopeFactory), scope, _devices, deviceFactory);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296075165);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296075165)
            
            static $h = 1107869;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCIDSH.HomeScope; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296075165),
    {
      "p": [
        {
          "n": "home",
          "p": 1173405
        },
        {
          "n": "scope",
          "p": 38638993
        },
        {
          "n": "_devices",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTDeviceModel).$h
        },
        {
          "n": "deviceFactory",
          "p": 321437
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1107869,
      "h": 4296075165,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296075165)
  ],
  "h": 1107869
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScope, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IObserver$$($.$XBGm.LCICI.DiscoveredIOTDevice) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Scopes.Home.HomeRoomScope`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Scopes${separator}Home${separator}HomeRoomScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1107869)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.DynamicExpresso.Core", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.IOT.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(59293)
