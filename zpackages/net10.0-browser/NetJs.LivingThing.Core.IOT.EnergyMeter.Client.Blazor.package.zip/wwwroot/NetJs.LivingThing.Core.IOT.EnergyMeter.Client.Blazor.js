
//--TRIMMABLE-BOUNDARY-START(30879)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej, $NzWm, $uUnI) {
    "use strict";
    let _;
    let $QajvPd;
    let $FHHsgb;
    let $JoKuWe;
    let $CqzlUj;
    let $rbozEk;
    let $bPAJBk;
    let $XXldqh;
    let $nKakTd;
    let $PHegVb;
    let $yhJPuk;
    let $jsWwCd;
    let $wNvYWj;
    let $RDxnPf;
    let $fekGwd;
    let $UzBPvi;
    let $xQtQgh;
    let $Mrjjth;
    let $ojZnVa;
    let $pwXasf;
    let $TOddkg;
    let $CkSRTb;
    let $bVpKOi;
    let $KHEANd;
    let $PBTRGj;
    let $EioQei;
    let $XiUWDb;
    let $lnMIlh;
    let $YHgJFk;
    let $KjPjwi;
    let $eMSttc;
    let $zfaIUd;
    let $vuKMFe;
    let $bIETyi;
    let $YfKsGd;
    let $SHihaf;
    let $oOuirj;
    let $SQuifi;
    let $SVZkHf;
    let $qKgLGa;
    let $RyJpIj;
    let $fGGtte;
    let $zkvblg;
    let $FQsofg;
    let $dhTBQi;
    let $SneDAf;
    let $NScgWh;
    let $wbscla;
    let $iBjtUa;
    let $ZKyfvh;
    let $qkUYGb;
    let $zAsMHd;
    let $qfIJDi;
    let $UmmyPe;
    let $uZFnfd;
    let $rdIbTc;
    let $GGeDGf;
    let $XaTRWg;
    let $SDoQXi;
    let $qSZRnk;
    let $KWCHPa;
    let $cXjDzd;
    let $PpwtVi;
    let $gMEMoh;
    let $FmUQyb;
    let $qvRNjg;
    let $jzyaqd;
    let $uVncRf;
    let $hmotQd;
    let $yiUXXb;
    let $ElSQra;
    let $eOpJCe;
    let $BoXwfi;
    let $pgrUAi;
    let $cEfCbe;
    let $TTdmHf;
    let $fMgIll;
    let $qrSmYj;
    let $fcKYmh;
    let $sVheka;
    let $oatWpj;
    let $eFHsgf;
    let $HPEQyj;
    let $EvCUEi;
    let $PyAlVk;
    let $RnCobe;
    let $Evdlwa;
    let $uUNktb;
    let $rnXZPf;
    let $pQtsah;
    let $BTzRbg;
    let $nJfoUg;
    let $wdJaji;
    let $GkAYyk;
    let $iKPKkj;
    let $YclHgf;
    let $IpdvAi;
    let $ViUGWj;
    let $DDtqUg;
    let $bKftQj;
    let $veKRhk;
    let $EEJAKk;
    let $luauJj;
    let $wkCnph;
    let $OcRbue;
    let $HRXlbk;
    let $RDfQia;
    let $GtgYVh;
    let $aczxEj;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.EnergyMeter.Client.Blazor", 
    {
  "h": 30879,
  "f": "LivingThing.Core.IOT.EnergyMeter.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.EnergyMeter.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.EnergyMeter.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(227487)
        $asm.$cls(`$eHSC.LCIEC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295194783)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295194783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$eHSC.LCIEC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295194783)
            
            static $h = 227487;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295194783),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 227487,
      "h": 4295194783,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295194783)
  ],
  "h": 227487
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(227487)
        
        

        //--TRIMMABLE-BOUNDARY-START(620703)
        $asm.$cls(`$eHSC.LCIEC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590555295)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590555295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$eHSC.LCIECP.App, "LivingThing.Core.IOT.EnergyMeter.Client", "Pages\\App", "App", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/EnergyMeter/App" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590555295)
            
            //--TRIMMABLE-BOUNDARY-START(4295587999)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295587999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295587999)
            
            //--TRIMMABLE-BOUNDARY-START(4295587999)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295587999)
            
            static $h = 620703;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590555295),
    {
      "r": 65537,
      "n": "Build",
      "d": 620703,
      "h": 8590555295,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590555295)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295587999),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 620703,
      "h": 4295587999,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295587999)
  ],
  "h": 620703
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(620703)
        
        

        //--TRIMMABLE-BOUNDARY-START(96415)
        $asm.$cls(`$eHSC._LCIECSE.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(8590031007)
            static /*void */ CreateRemoteDataEditor_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*T*/ __arg0, /*int*/ __seq1, /*global::Microsoft.AspNetCore.Components.EventCallback<T>*/ __arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590031007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCR$1.RemoteDataEditor$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Model", $.$box(__arg0, T));
                __builder.AddComponentParameter(__seq1, "ModelChanged", __arg1);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590031007)
            
            //--TRIMMABLE-BOUNDARY-START(4295063711)
            static /*void */ CreateAutoDashboard_1(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*T*/ __arg0)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295063711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD.AutoDashboard$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Target", $.$box(__arg0, T));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295063711)
            
            static $h = 96415;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590031007),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => T.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (T) => $.$mac.MAC.EventCallback$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateRemoteDataEditor_0",
      "d": 96415,
      "h": 8590031007,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590031007),
//--TRIMMABLE-BOUNDARY-START(4295063711),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateAutoDashboard_1",
      "d": 96415,
      "h": 4295063711,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295063711)
  ],
  "h": 96415
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.IOT.EnergyMeter.Client.Shared.EnergyMeterDevice.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}Shared${separator}EnergyMeterDevice${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(96415)
        
        

        //--TRIMMABLE-BOUNDARY-START(293023)
        $asm.$cls(`$eHSC.LCIECIU.EnergyMeterWidgetFactory`, ($self) => class EnergyMeterWidgetFactory extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(358559)
            static $_EnergyMeterWidget;
            static get EnergyMeterWidget()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(358559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$eHSC.LCIECIU.EnergyMeterWidgetFactory;
                return $cls.$_EnergyMeterWidget ??= $asm.$ncls(`$eHSC.LCIECIU.EnergyMeterWidgetFactory.EnergyMeterWidget`, ($self) => class EnergyMeterWidget extends $.$NzWm.LCIDG.BaseGatewayAutoMappingWidget
                {
                    //--TRIMMABLE-BOUNDARY-START(8590293151)
                    $ctor$7()
                    {
                        super.$ctor$6("C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Client.Blazor\\EnergyMeterWidgetFactory.cs", 21);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590293151);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590293151)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885260447)
                    $ctor$8(/*string?*/ component, /*int*/ line)
                    {
                        super.$ctor$6(component, line);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885260447);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885260447)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770162335)
                    /*string */ get MappingHandlerType()
                    {
                        return "EnergyMeter";
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770162335)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295325855)
                    /*Static constructor*/ static $cctor()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295325855);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$bMcF.LFCW.WidgetFactory.Register($.$eHSC.LCIECIU.EnergyMeterWidgetFactory.EnergyMeterWidget);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295325855)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590293151)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$7();
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590293151)
                    
                    static $h = 358559;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$NzWm.LCIDG.BaseGatewayAutoMappingWidget; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770162335),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475195039,
        "f": 50364417
      },
      "n": "MappingHandlerType",
      "d": 358559,
      "h": 25770162335,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770162335)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590293151),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 358559,
      "h": 8590293151,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590293151),
//--TRIMMABLE-BOUNDARY-START(12885260447),
    {
      "p": [
        {
          "n": "component",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126025729,
              "c": 4420993025
            }
          ]
        },
        {
          "n": "line",
          "p": 655361,
          "f": 65,
          "v": 0,
          "a": [
            {
              "t": 126091265,
              "c": 4421058561
            }
          ]
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 358559,
      "h": 12885260447,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885260447)
  ],
  "d": 293023,
  "h": 358559,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Options",
          "v": [
            "//Icon=mdi mdi-flash"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$NzWm.LCIDG.IGatewayAutoMappingWidget, $.$NzWm.LCIDG.IGatewayDatasourceWidget ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.Integrations.UIWidget.EnergyMeterWidgetFactory+EnergyMeterWidget`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}Integrations${separator}UIWidget${separator}EnergyMeterWidgetFactory${separator}EnergyMeterWidget`; }
                }, $cls, ($v) => $cls.$_EnergyMeterWidget = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(358559)
            
            //--TRIMMABLE-BOUNDARY-START(4295260319)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295260319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bMcF.LFCW.WidgetFactory.Register($.$eHSC.LCIECIU.EnergyMeterWidgetFactory.EnergyMeterWidget);
            }
            //--TRIMMABLE-BOUNDARY-END(4295260319)
            
            //--TRIMMABLE-BOUNDARY-START(21475129503)
            /*Type */ get WidgetType()
            {
                return $.$eHSC.LCIECIU.EnergyMeterWidgetFactory.EnergyMeterWidget.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(21475129503)
            
            //--TRIMMABLE-BOUNDARY-START(17205007761)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.IIOTDeviceWidgetFactory.WidgetType.get
            get LCIC$IIOTDeviceWidgetFactory$WidgetType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25794942353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WidgetType;
            }
            //--TRIMMABLE-BOUNDARY-END(17205007761)
            
            //--TRIMMABLE-BOUNDARY-START(8590227615)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590227615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590227615)
            
            //--TRIMMABLE-BOUNDARY-START(8590227615)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590227615)
            
            static $h = 293023;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475129503),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180162207,
        "f": 50331649
      },
      "n": "WidgetType",
      "d": 293023,
      "h": 21475129503,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475129503)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590227615),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 293023,
      "h": 8590227615,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590227615)
  ],
  "h": 293023
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IIOTDeviceWidgetFactory ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$eHSC.LCIECIU.EnergyMeterWidgetFactory.EnergyMeterWidget ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.Integrations.UIWidget.EnergyMeterWidgetFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}Integrations${separator}UIWidget${separator}EnergyMeterWidgetFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(293023)
        
        

        //--TRIMMABLE-BOUNDARY-START(751775)
        $asm.$cls(`$eHSC.LCIEC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590686367)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590686367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$eHSC.LCIECV.EnergyMeterClientAppViewModel, services);
                $.$sZVd.LCFCA.ClientApplicationExtension.AddApplication($.$eHSC.LCIECP.App, services, (() =>
                {
                    //new $.$sZVd.LCFCA.ClientApplicationModel$$($.$eHSC.LCIECP.App)()
                    const $t1 = $.$sZVd.LCFCA.ClientApplicationModel$$($.$eHSC.LCIECP.App);
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Categories = $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "IOT" ], null, null);
                    $i1.Name = "EnerygyMeter";
                    $i1.Title = "Enerygy Meter";
                    $i1.Description = "IOT Energy Metering application";
                    $i1.Paths = $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "EnerygyMeter/App" ], null, null);
                    $i1.Theme = $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t2 = $.$fPer.LCFC.Theme;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.BackgroundColor = "#00AEFF";
                        $i2.ForegroundColor = "#FFFFFF";
                        return $i2;
                    })());
                    $i1.Icon = $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-meter-electric"/*MaterialDesignIconNames.MeterElectric*/);
                    return $i1;
                })());
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$bMcF.LFCR.IUIRenderer$$($.$eHSC.LCIECIU.EnergyMeterWidgetFactory.EnergyMeterWidget), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$6($.$eHSC.LCIECIU.EnergyMeterWidgetRenderer, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$bMcF.LFCR.IUIRenderer$$($.$eHSC.LCIECIU.EnergyMeterWidgetFactory.EnergyMeterWidget)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$eHSC.LCIECIU.EnergyMeterWidgetRenderer, x);
                }, $QajvPd ??= {"r":$.$bMcF.LFCR.IUIRenderer$$($.$eHSC.LCIECIU.EnergyMeterWidgetFactory.EnergyMeterWidget).$h,"p":[{"n":"x","p":327718}],"n":"","d":751775,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$XBGm.LCIC.IIOTDeviceWidgetFactory, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$6($.$eHSC.LCIECIU.EnergyMeterWidgetFactory, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCIC.IIOTDeviceWidgetFactory))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$eHSC.LCIECIU.EnergyMeterWidgetFactory, x);
                }, $FHHsgb ??= {"r":25138577,"p":[{"n":"x","p":327718}],"n":"","d":751775,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590686367)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$eHSC.LCIEC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295719071)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295719071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295719071)
            
            //--TRIMMABLE-BOUNDARY-START(4295719071)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295719071)
            
            static $h = 751775;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590686367),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 751775,
      "h": 8590686367,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590686367)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295719071),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 751775,
      "h": 4295719071,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295719071)
  ],
  "h": 751775
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(751775)
        
        

        //--TRIMMABLE-BOUNDARY-START(555167)
        $asm.$cls(`$eHSC.LCIEC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180424351)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$eHSC.LCIECIU.EnergyMeterWidgetView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$eHSC.LCIECIU.EnergyMeterWidgetView().$ctor$5();
                    }, $PBTRGj ??= {"r":2752627,"n":"","d":555167,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$eHSC.LCIECP.App.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$eHSC.LCIECP.App().$ctor$3();
                    }, $EioQei ??= {"r":2752627,"n":"","d":555167,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$eHSC.LCIECS.EnergyMeterDash.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$eHSC.LCIECS.EnergyMeterDash().$ctor$3();
                    }, $XiUWDb ??= {"r":2752627,"n":"","d":555167,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$eHSC.LCIECS.EnergyMeterDevice.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$eHSC.LCIECS.EnergyMeterDevice().$ctor$3();
                    }, $lnMIlh ??= {"r":2752627,"n":"","d":555167,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$eHSC.LCIECS.EnergyMeterLogin.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$eHSC.LCIECS.EnergyMeterLogin().$ctor$3();
                    }, $YHgJFk ??= {"r":2752627,"n":"","d":555167,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$eHSC.LCIECS.EnergyMeterOverviewCard.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$eHSC.LCIECS.EnergyMeterOverviewCard().$ctor$5();
                    }, $KjPjwi ??= {"r":2752627,"n":"","d":555167,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180424351)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295522463)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295522463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295522463)
            
            //--TRIMMABLE-BOUNDARY-START(4295522463)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295522463)
            
            static $h = 555167;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180424351),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885457055,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 555167,
      "h": 17180424351,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180424351)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295522463),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 555167,
      "h": 4295522463,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295522463)
  ],
  "h": 555167
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(555167)
        
        

        //--TRIMMABLE-BOUNDARY-START(1407135)
        $asm.$cls(`$eHSC.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296374431)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296374431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296374431)
            
            //--TRIMMABLE-BOUNDARY-START(4296374431)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296374431)
            
            static $h = 1407135;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296374431),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1407135,
      "h": 4296374431,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296374431)
  ],
  "h": 1407135
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1407135)
        
        

        //--TRIMMABLE-BOUNDARY-START(1472671)
        $asm.$cls(`$eHSC.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296439967)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296439967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296439967)
            
            //--TRIMMABLE-BOUNDARY-START(4296439967)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296439967)
            
            static $h = 1472671;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296439967),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1472671,
      "h": 4296439967,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296439967)
  ],
  "h": 1472671,
  "a": [
    {
      "t": 1407135,
      "c": 4296374431
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1472671)
        
        

        //--TRIMMABLE-BOUNDARY-START(161951)
        $asm.$cls(`$eHSC.LCIEC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590096543)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590096543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590096543)
            
            //--TRIMMABLE-BOUNDARY-START(4295129247)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295129247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295129247)
            
            //--TRIMMABLE-BOUNDARY-START(4295129247)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295129247)
            
            static $h = 161951;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590096543),
    {
      "r": 65537,
      "n": "Execute",
      "d": 161951,
      "h": 8590096543,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590096543)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295129247),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 161951,
      "h": 4295129247,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295129247)
  ],
  "h": 161951
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(161951)
        
        

        //--TRIMMABLE-BOUNDARY-START(948383)
        $asm.$cls(`$eHSC.LCIECS.EnergyMeterLogin`, ($self) => class EnergyMeterLogin extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(12885850271)
            /*IClientAuthenticationService*/ AuthenticationService = null;
            //--TRIMMABLE-BOUNDARY-END(12885850271)
            
            //--TRIMMABLE-BOUNDARY-START(42950621343)
            /*string */ get OptimizedComponentName()
            {
                return "energymeterlogin";
            }
            //--TRIMMABLE-BOUNDARY-END(42950621343)
            
            //--TRIMMABLE-BOUNDARY-START(38655654047)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655654047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.AuthenticationService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IClientAuthenticationService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(38655654047)
            
            //--TRIMMABLE-BOUNDARY-START(17180817567)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180817567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "hv-10 wv-10 clip");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "hf flex pos-rel");
                __builder.AddMarkupContent(4, "<div class=\"pos-abs bg-secondary round wf\" style=\"height:200%;left:50%;top:0%\"></div>\r\n        ");
                __builder.AddMarkupContent(5, "<div class=\"pos-abs hf wx-3 bg-primary-04 stack pd\"><div class=\"mgt-10 text-center\"><h2>Managing starts with knowing</h2>\r\n                <p>Login to your energy dashboard</p></div></div>\r\n        ");
                __builder.OpenElement(6, "div");
                __builder.AddAttribute$5(7, "class", "mg-a z-2");
                __builder.AddMarkupContent(8, "<div class=\"wx-1 hx-1 mgx-a round bd bg-gray clip\"><img src=\"https://source.unsplash.com/user/c_v_r/100x100\"></div>\r\n            ");
                __builder.OpenElement(9, "div");
                __builder.AddAttribute$5(10, "class", "bg-card-05 mgt pd");
                __builder.AddContent$1(11, this.AuthenticationService.LCFCI$IClientAuthenticationService$Authenticate((() =>
                {
                    //new $.$hDPm.LCFCI.AuthenticationParameter()
                    const $t1 = $.$hDPm.LCFCI.AuthenticationParameter;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EditorFeatures = (4131/*InputEditorFeatures.Default*/ & ~2/*InputEditorFeatures.BorderBottom*/) | 8/*InputEditorFeatures.Highlight*/;
                    $i1.FormTheme = $.$fPer.LCFC.Theme.OfPrimary(0.3);
                    $i1.Theme = $.$fPer.LCFC.Theme.Primary;
                    $i1.Attributes = (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "miwx-3");
                        return $i2;
                    })();
                    return $i1;
                })()));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17180817567)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590882975)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590882975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590882975)
            
            //--TRIMMABLE-BOUNDARY-START(8590882975)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8590882975)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885850271)
                this.AuthenticationService = null;
                //--TRIMMABLE-BOUNDARY-END(12885850271)
                
            }
            static $h = 948383;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885850271),
    {
      "p": 63592106,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770752159,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540555935,
        "f": 83886081
      },
      "n": "AuthenticationService",
      "d": 948383,
      "h": 12885850271,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885850271),
//--TRIMMABLE-BOUNDARY-START(42950621343),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360686751,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 948383,
      "h": 42950621343,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950621343)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655654047),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 948383,
      "h": 38655654047,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655654047),
//--TRIMMABLE-BOUNDARY-START(17180817567),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 948383,
      "h": 17180817567,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180817567)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590882975),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 948383,
      "h": 8590882975,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590882975)
  ],
  "h": 948383
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.Shared.EnergyMeterLogin`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}Shared${separator}EnergyMeterLogin`; }
        });
        //--TRIMMABLE-BOUNDARY-END(948383)
        
        

        //--TRIMMABLE-BOUNDARY-START(686239)
        $asm.$cls(`$eHSC.LCIECP.App`, ($self) => class App extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21475522719)
            /*string */ get OptimizedComponentName()
            {
                return "app";
            }
            //--TRIMMABLE-BOUNDARY-END(21475522719)
            
            //--TRIMMABLE-BOUNDARY-START(8590620831)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590620831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$macw.MACW.PageTitle, 0);
                __builder.AddAttribute$3(1, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.AddContent$4(2, "Energy Meter");
                }), $JoKuWe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":686239,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(3, "\r\n\r\n");
                __builder.OpenComponent$1($.$maca.MACA.AuthorizeView, 4);
                __builder.AddAttribute$3(5, "NotAuthorized", new ($.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$macw.MACW.PageTitle, 6);
                        __builder2.AddAttribute$3(7, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(8, "Energy Meter");
                        }), $CqzlUj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":686239,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(9, "\r\n        ");
                        __builder2.OpenComponent$1($.$eHSC.LCIECS.EnergyMeterLogin, 10);
                        __builder2.CloseComponent();
                    }, $rbozEk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":686239,"h":0,"f":17825794});
                }), $bPAJBk ??= {"r":6881395,"p":[{"n":"context","p":131193}],"n":"","d":686239,"h":0,"f":17825794}));
                __builder.AddAttribute$3(11, "Authorized", new ($.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState))().$ctor(this, ( (/**/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$eHSC.LCIECS.EnergyMeterDash, 12);
                        __builder2.CloseComponent();
                    }, $XXldqh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":686239,"h":0,"f":17825794});
                }), $nKakTd ??= {"r":6881395,"p":[{"n":"context","p":131193}],"n":"","d":686239,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590620831)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295653535)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295653535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295653535)
            
            //--TRIMMABLE-BOUNDARY-START(4295653535)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295653535)
            
            static $h = 686239;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475522719),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180555423,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 686239,
      "h": 21475522719,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475522719)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590620831),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 686239,
      "h": 8590620831,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590620831)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295653535),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 686239,
      "h": 4295653535,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295653535)
  ],
  "h": 686239,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/EnergyMeter/App",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.Pages.App`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}Pages${separator}App`; }
        });
        //--TRIMMABLE-BOUNDARY-END(686239)
        
        

        //--TRIMMABLE-BOUNDARY-START(817311)
        $asm.$cls(`$eHSC.LCIECS.EnergyMeterDash`, ($self) => class EnergyMeterDash extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(85900163231)
            /*EnergyMeterClientAppViewModel*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(85900163231)
            
            //--TRIMMABLE-BOUNDARY-START(68720294047)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(68720294047)
            
            //--TRIMMABLE-BOUNDARY-START(90195130527)
            /*void */ Services_OnStatusReceived(/*object?*/ sender, /*IOTDeviceMessagePipeNotification<EnergyMeterDeviceReceivedDataModel, EnergyMeterDeviceStatusModel>*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195130527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.EnergyMeter.Client.ViewModels.EnergyMeterClientAppServiceViewModel?*/ let __ca1__;
                if ((__ca1__ = this.Services.SelectedServiceViewModel) !== null ? $.$sl.SL.Enumerable.Any($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel, __ca1__.Devices, new ($.$$.S.Func$$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel, $.$$.S.Boolean))().$ctor(this,  (/**/ d) =>
                {
                    return d.Model$1.UniqueId === e.DeviceId;
                }, $eMSttc ??= {"r":262145,"p":[{"n":"d","p":1210527}],"n":"","d":817311,"h":0,"f":17825794})) : false)
                {
                    _ = this.StateChanged(true, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Client.Blazor\\EnergyMeterDash.razor.cs", "Services_OnStatusReceived", 35);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195130527)
            
            //--TRIMMABLE-BOUNDARY-START(73015261343)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015261343);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Services.EnsureLoaded(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    this.Services.add_OnStatusReceived(new ($.$$.S.EventHandler$$($.$XBGm.LCICM.IOTDeviceMessagePipeNotification$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)))().$ctor(this, this.Services_OnStatusReceived));
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73015261343)
            
            //--TRIMMABLE-BOUNDARY-START(30065588383)
            /*Task *//*async*/  ExportXLS()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065588383);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.Services.SelectedDevice !== null)
                    {
                        let $t3, $r3;
                        let $t4, $r4;
                        let $t5, $r5;
                        /*var*/ let request = ($t3 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Form($.$XBGm.LCICS$1.IOTDeviceStatusReportRequestModel, "Send XLS to Email", null, "OK", "Cancel", null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        request.DeviceId = this.Services.SelectedDevice.Model$1.Identifier;
                        ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$XBGm.LCICS$1.IIOTDeviceStatusRemoteService$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), this.Services.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$XBGm.LCICS$1.IIOTDeviceStatusRemoteService$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/**/ server) =>
                        {
                            return server.LCICS$1$IIOTDeviceStatusRemoteService$$$ExcelReport(request);
                        }, $zfaIUd ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"server","p":$.$XBGm.LCICS$1.IIOTDeviceStatusRemoteService$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        ($t5 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Message("Successfull", `Excel report has been sent to ${$.$strNN(request.Emails)}`, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30065588383)
            
            //--TRIMMABLE-BOUNDARY-START(25770621087)
            /*bool*/ disposed = false;
            //--TRIMMABLE-BOUNDARY-END(25770621087)
            
            //--TRIMMABLE-BOUNDARY-START(21475653791)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475653791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Services.remove_OnStatusReceived(new ($.$$.S.EventHandler$$($.$XBGm.LCICM.IOTDeviceMessagePipeNotification$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)))().$ctor(this, this.Services_OnStatusReceived));
                this.Services.Dispose();
                super.Dispose();
                this.disposed = true;
            }
            //--TRIMMABLE-BOUNDARY-END(21475653791)
            
            //--TRIMMABLE-BOUNDARY-START(111669967007)
            /*bool*/ sideBarOpen = false;
            //--TRIMMABLE-BOUNDARY-END(111669967007)
            
            //--TRIMMABLE-BOUNDARY-START(115964934303)
            /*void */ ToggleSideBar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964934303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.sideBarOpen = !this.sideBarOpen;
            }
            //--TRIMMABLE-BOUNDARY-END(115964934303)
            
            //--TRIMMABLE-BOUNDARY-START(81605195935)
            /*bool*/ overlay = false;
            //--TRIMMABLE-BOUNDARY-END(81605195935)
            
            //--TRIMMABLE-BOUNDARY-START(64425326751)
            /*Task *//*async*/  Logout()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425326751);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t6 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Authentication.LCFCA$IAuthenticationService$LogOut(null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    this.Navigation.NavigateTo$2(this.Navigation.Uri, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64425326751)
            
            //--TRIMMABLE-BOUNDARY-START(77310228639)
            /*string */ get OptimizedComponentName()
            {
                return "energymeterdash";
            }
            //--TRIMMABLE-BOUNDARY-END(77310228639)
            
            //--TRIMMABLE-BOUNDARY-START(60130359455)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130359455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Services = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$eHSC.LCIECV.EnergyMeterClientAppViewModel, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(60130359455)
            
            //--TRIMMABLE-BOUNDARY-START(17180686495)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180686495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$macw.MACW.PageTitle, 0);
                __builder.AddAttribute$3(1, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$4(2, (this.Services.Selected?.Service?.Name ?? null));
                    __builder2.AddContent$4(3, " - Energy Meter");
                }), $vuKMFe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":817311,"h":0,"f":17825794}));
                __builder.CloseComponent();
                if (this.Services.SelectedServiceViewModel !== null)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCS$7.SideBar, 4);
                    __builder.AddComponentParameter(5, "Side", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarSide, 1/*SideBarSide.Left*/), $.$hDPm.LCFCCS$7.SideBarSide));
                    __builder.AddComponentParameter(6, "Class", "hf");
                    __builder.AddComponentParameter(7, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarFeatures, 32/*SideBarFeatures.Default*/ | 1/*SideBarFeatures.Dynamic*/ | (((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? 2/*SideBarFeatures.Cover*/ | 4/*SideBarFeatures.BackDrop*/ | 8/*SideBarFeatures.BackDropClose*/ : 0/*SideBarFeatures.None*/)), $.$hDPm.LCFCCS$7.SideBarFeatures));
                    __builder.AddComponentParameter(8, "bar-class", "pd bg-secondary cl-text stack");
                    __builder.AddComponentParameter(9, "content-class", "stack clip mawx-14 mgx-a");
                    __builder.AddComponentParameter(10, "ShowSide", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, this.sideBarOpen), $.$$.S.Boolean));
                    __builder.AddComponentParameter(11, "ShowSideChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.Boolean), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Boolean, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Boolean, this, new ($.$$.S.Action$$($.$$.S.Boolean))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.sideBarOpen = __value;
                    }, $bIETyi ??= {"r":65537,"p":[{"n":"__value","p":262145}],"n":"","d":817311,"h":0,"f":17825794}), this.sideBarOpen))));
                    __builder.AddAttribute$3(12, "Bar", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(13, "div");
                        __builder2.AddAttribute$5(14, "class", "text-center");
                        __builder2.AddMarkupContent(15, "<div class=\"wx-1 hx-1 mgx-a round bd bg-gray clip mgt-20\"><img src=\"https://source.unsplash.com/user/c_v_r/100x100\"></div>\r\n                ");
                        __builder2.OpenElement(16, "h3");
                        __builder2.AddAttribute$5(17, "class", "nowrap mgt-5 cl-black text-center");
                        __builder2.AddContent$4(18, this.Services.Selected.Service.Name);
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(19, "\r\n            ");
                        __builder2.OpenElement(20, "div");
                        __builder2.AddAttribute$5(21, "class", "fill scroll mgx-no-gutter");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCA.Accordion, 22);
                        __builder2.AddComponentParameter(23, "Exclusive", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                        __builder2.AddAttribute$3(24, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel), 25);
                            __builder3.AddComponentParameter(26, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel), this.Services.Services));
                            __builder3.AddComponentParameter(27, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, (35184372092928n & ~524288n) | 65536n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder3.AddComponentParameter(28, "Selected", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel), this.Services.SelectedServiceViewModels));
                            __builder3.AddComponentParameter(29, "SelectedChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel)), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel), this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel), this, new ($.$$.S.Action$$($.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel)))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                return this.Services.SelectedServiceViewModels = __value;
                            }, $YfKsGd ??= {"r":65537,"p":[{"n":"__value","p":$.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel).$h}],"n":"","d":817311,"h":0,"f":17825794}), this.Services.SelectedServiceViewModels))));
                            __builder3.AddAttribute$3(30, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel))))().$ctor(this, ( (/*service*/ service) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 31);
                                    __builder4.AddAttribute$3(32, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*t*/ t) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.OpenElement(33, "div");
                                            __builder5.AddAttribute$5(34, "class", "row cl-white pd");
                                            __builder5.OpenElement(35, "div");
                                            __builder5.AddAttribute$5(36, "class", "col-10");
                                            __builder5.OpenElement(37, "b");
                                            __builder5.AddContent$4(38, service.Data.Model.Title);
                                            __builder5.CloseElement();
                                            __builder5.CloseElement();
                                            __builder5.AddMarkupContent(39, "\r\n                                        ");
                                            __builder5.OpenElement(40, "div");
                                            __builder5.AddAttribute$5(41, "class", "col-a");
                                            __builder5.OpenElement(42, "i");
                                            __builder5.AddAttribute$5(43, "class", $.$strNN("mdi" + " mdi-chevron-") + $.$strNN((t.Data ? "down" : "up")));
                                            __builder5.CloseElement();
                                            __builder5.CloseElement();
                                            __builder5.CloseElement();
                                        }, $SHihaf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $oOuirj ??= {"r":6881395,"p":[{"n":"t","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder4.AddAttribute$3(44, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel), 45);
                                            __builder5.AddComponentParameter(46, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel), service.Data.Devices));
                                            __builder5.AddComponentParameter(47, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, (35184372092928n & ~524288n) | 65536n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                            __builder5.AddComponentParameter(48, "li-class", "pd-2 cl-white");
                                            __builder5.AddComponentParameter(49, "Selected", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel), service.Data.SelectedDevices));
                                            __builder5.AddComponentParameter(50, "SelectedChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel)), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel), this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel), this, new ($.$$.S.Action$$($.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel)))().$ctor(this,  (/*__value*/ __value) =>
                                            {
                                                return service.Data.SelectedDevices = __value;
                                            }, $SQuifi ??= {"r":65537,"p":[{"n":"__value","p":$.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel).$h}],"n":"","d":817311,"h":0,"f":17825794}), service.Data.SelectedDevices))));
                                            __builder5.AddAttribute$3(51, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel))))().$ctor(this, ( (/*dev*/ dev) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.OpenElement(52, "div");
                                                    __builder6.AddAttribute$5(53, "class", "flex bg-card bd corner-3 nowrap pdy-1 pdx-2");
                                                    __builder6.OpenElement(54, "div");
                                                    __builder6.AddAttribute$5(55, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("hx-01" + " wx-01") + " ") + $.$strNN((dev.Data.Model$1.Online === true ? "bg-success" : "bg-warning"))) + " round") + " mgr-2") + " mgy-a");
                                                    __builder6.CloseElement();
                                                    __builder6.AddMarkupContent(56, "\r\n                                                ");
                                                    __builder6.AddContent$4(57, dev.Data.Model$1.Name);
                                                    __builder6.CloseElement();
                                                }, $SVZkHf ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                            }), $qKgLGa ??= {"r":6881395,"p":[{"n":"dev","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel)).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                            __builder5.CloseComponent();
                                        }, $RyJpIj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $fGGtte ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $zkvblg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                            }), $FQsofg ??= {"r":6881395,"p":[{"n":"service","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel)).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }), $dhTBQi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":817311,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(58, "\r\n            ");
                        __builder2.OpenElement(59, "div");
                        __builder2.OpenElement(60, "button");
                        __builder2.AddAttribute$5(61, "class", "fw-bold cl-error pd miwx-1 clickable fsz-18 mgx-a d-block");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 62, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Logout)));
                        __builder2.AddContent$4(63, "Logout");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }), $SneDAf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":817311,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(64, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(65, "div");
                        __builder2.AddAttribute$5(66, "class", "row pd bg-tb-white-secondary ");
                        __builder2.OpenElement(67, "button");
                        __builder2.AddAttribute$5(68, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("mdi" + " ") + $.$strNN((this.sideBarOpen ? "mdi-close" : "mdi-menu"))) + " clickable") + " bg-transparent") + " bd-0") + " fsz-40") + " mgx-a") + " pos-abs") + " z-10");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 69, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToggleSideBar)));
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(70, "\r\n\r\n                ");
                        __builder2.OpenElement(71, "div");
                        __builder2.AddAttribute$5(72, "class", "col-10 flex flex-end-x");
                        __builder2.OpenElement(73, "div");
                        __builder2.AddAttribute$5(74, "class", "flex");
                        __builder2.OpenElement(75, "div");
                        __builder2.AddAttribute$5(76, "class", "mgl mgy-a");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 77);
                        __builder2.AddComponentParameter(78, "Class", "bg-card bd bd-black corner-3 mdi mdi-plus cl-black nowrap pdx fw-bold");
                        __builder2.AddComponentParameter(79, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.ExportXLS))));
                        __builder2.AddComponentParameter(80, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/ | 4096/*ButtonFeatures.SwallowClickException*/ | 8192/*ButtonFeatures.LoadingOnClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder2.AddAttribute$3(81, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(82, "\r\n                                Export XLS\r\n                            ");
                        }), $NScgWh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":817311,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(83, "\r\n                        ");
                        __builder2.OpenElement(84, "div");
                        __builder2.AddAttribute$5(85, "class", "mgy-a mg");
                        __builder2.OpenElement(86, "div");
                        __builder2.AddAttribute$5(87, "class", $.$strNN($.$strNN($.$strNN("bg-" + $.$strNN(((this.Services.SelectedServiceViewModel.SelectedDevice?.Model$1.Online ?? null) === true ? "primary" : "info"))) + " pdx") + " pdy-1") + " corner-5");
                        __builder2.AddContent$4(88, (this.Services.SelectedServiceViewModel.SelectedDevice?.Model$1.Online ?? null) === true ? "ONLINE" : "OFFLINE");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(89, "\r\n                        ");
                        __builder2.OpenElement(90, "div");
                        __builder2.AddAttribute$5(91, "class", "mgl fw-bold mgy-a");
                        __builder2.AddMarkupContent(92, "\r\n                            SITE: ");
                        __builder2.AddContent$4(93, (this.Services.SelectedServiceViewModel.SelectedDevice?.Model$1.Name ?? null));
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(94, "\r\n                        ");
                        __builder2.AddMarkupContent(95, "<div class=\"mgl wx-04 hx-04 round bd bg-gray clip\"><img src=\"https://source.unsplash.com/user/c_v_r/100x100\"></div>");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(96, "\r\n            ");
                        __builder2.OpenElement(97, "div");
                        __builder2.AddAttribute$5(98, "class", $.$strNN($.$strNN($.$strNN("fill" + " pd") + $.$strNN((((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsDesktop ?? null) ?? false) ? "-10" : ""))) + " pos-rel") + " scroll");
                        if (this.overlay)
                        {
                            __builder2.AddMarkupContent(99, "<div class=\"pos-abs t-0 b-0 l-0 r-0\" style=\"backdrop-filter: blur(20px);\"></div>");
                        }
                        if (this.Services.SelectedServiceViewModel.SelectedDevice !== null)
                        {
                            __builder2.OpenComponent$1($.$eHSC.LCIECS.EnergyMeterOverviewCard, 100);
                            __builder2.AddComponentParameter(101, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uUnI.LCIECM.EnergyMeterDeviceModel, this.Services.SelectedServiceViewModel.SelectedDevice.Model$1));
                            __builder2.CloseComponent();
                            __builder2.AddMarkupContent(102, "\r\n                    ");
                            __builder2.OpenElement(103, "div");
                            __builder2.AddAttribute$5(104, "class", "bg-tb-secondary-dark pd mgt-10 corner-5 row responsive");
                            __builder2.OpenElement(105, "div");
                            __builder2.AddAttribute$5(106, "class", "col-3 pd miwx-2");
                            __builder2.OpenElement(107, "div");
                            __builder2.AddAttribute$5(108, "class", "bg-card hx-2");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 109);
                            __builder2.AddComponentParameter(110, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), this.Services.SelectedServiceViewModel.SelectedDevice.Model$1.Statuses));
                            __builder2.AddComponentParameter(111, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*e*/ e) =>
                            {
                                return e.DateCreated.ToString();
                            }), $wbscla ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"e","p":2910116}],"n":"","d":817311,"h":0,"f":17825794}));
                            __builder2.AddComponentParameter(112, "MinAxes", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Double), 0), $.$$.S.Double));
                            __builder2.AddAttribute$3(113, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 114);
                                    __builder3.AddComponentParameter(115, "Label", "Red");
                                    __builder3.AddComponentParameter(116, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))().$ctor(this, ( (/*e*/ e) =>
                                    {
                                        return $.$box((e.LCFCCD$1$IDataListItemContext$$$Data.Red?.Voltage ?? null), $.$$.S.Double);
                                    }), $iBjtUa ??= {"r":131073,"p":[{"n":"e","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddComponentParameter(117, "BorderColor", "#FF0000");
                                    __builder3.AddComponentParameter(118, "BackgroundColor", "#FF000080");
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(119, "\r\n                                    ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 120);
                                    __builder3.AddComponentParameter(121, "Label", "Yellow");
                                    __builder3.AddComponentParameter(122, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))().$ctor(this, ( (/*e*/ e) =>
                                    {
                                        return $.$box((e.LCFCCD$1$IDataListItemContext$$$Data.Yellow?.Voltage ?? null), $.$$.S.Double);
                                    }), $ZKyfvh ??= {"r":131073,"p":[{"n":"e","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddComponentParameter(123, "BorderColor", "#FFFF00");
                                    __builder3.AddComponentParameter(124, "BackgroundColor", "#FFFF0080");
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(125, "\r\n                                    ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 126);
                                    __builder3.AddComponentParameter(127, "Label", "Blue");
                                    __builder3.AddComponentParameter(128, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))().$ctor(this, ( (/*e*/ e) =>
                                    {
                                        return $.$box((e.LCFCCD$1$IDataListItemContext$$$Data.Blue?.Voltage ?? null), $.$$.S.Double);
                                    }), $qkUYGb ??= {"r":131073,"p":[{"n":"e","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddComponentParameter(129, "BorderColor", "#0000FF");
                                    __builder3.AddComponentParameter(130, "BackgroundColor", "#0000FF80");
                                    __builder3.CloseComponent();
                                }, $zAsMHd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                            }), $qfIJDi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(131, "\r\n                            ");
                            __builder2.AddMarkupContent(132, "<h3 class=\"text-center mgb-0\">L1 - L3 VOLTAGE (V)</h3>");
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(133, "\r\n                        ");
                            __builder2.OpenElement(134, "div");
                            __builder2.AddAttribute$5(135, "class", "col-3 pd miwx-2");
                            __builder2.OpenElement(136, "div");
                            __builder2.AddAttribute$5(137, "class", "bg-card hx-2");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 138);
                            __builder2.AddComponentParameter(139, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), this.Services.SelectedServiceViewModel.SelectedDevice.Model$1.Statuses));
                            __builder2.AddComponentParameter(140, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*e*/ e) =>
                            {
                                return e.DateCreated.ToString();
                            }), $UmmyPe ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"e","p":2910116}],"n":"","d":817311,"h":0,"f":17825794}));
                            __builder2.AddComponentParameter(141, "MinAxes", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Double), 0), $.$$.S.Double));
                            __builder2.AddAttribute$3(142, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 143);
                                    __builder3.AddComponentParameter(144, "Label", "Red");
                                    __builder3.AddComponentParameter(145, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))().$ctor(this, ( (/*e*/ e) =>
                                    {
                                        return $.$box((e.LCFCCD$1$IDataListItemContext$$$Data.Red?.Current ?? null), $.$$.S.Double);
                                    }), $uZFnfd ??= {"r":131073,"p":[{"n":"e","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddComponentParameter(146, "BorderColor", "#FF0000");
                                    __builder3.AddComponentParameter(147, "BackgroundColor", "#FF000080");
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(148, "\r\n                                    ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 149);
                                    __builder3.AddComponentParameter(150, "Label", "Yellow");
                                    __builder3.AddComponentParameter(151, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))().$ctor(this, ( (/*e*/ e) =>
                                    {
                                        return $.$box((e.LCFCCD$1$IDataListItemContext$$$Data.Yellow?.Current ?? null), $.$$.S.Double);
                                    }), $rdIbTc ??= {"r":131073,"p":[{"n":"e","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddComponentParameter(152, "BorderColor", "#FFFF00");
                                    __builder3.AddComponentParameter(153, "BackgroundColor", "#FFFF0080");
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(154, "\r\n                                    ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 155);
                                    __builder3.AddComponentParameter(156, "Label", "Blue");
                                    __builder3.AddComponentParameter(157, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))().$ctor(this, ( (/*e*/ e) =>
                                    {
                                        return $.$box((e.LCFCCD$1$IDataListItemContext$$$Data.Blue?.Current ?? null), $.$$.S.Double);
                                    }), $GGeDGf ??= {"r":131073,"p":[{"n":"e","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddComponentParameter(158, "BorderColor", "#0000FF");
                                    __builder3.AddComponentParameter(159, "BackgroundColor", "#0000FF80");
                                    __builder3.CloseComponent();
                                }, $XaTRWg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                            }), $SDoQXi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(160, "\r\n                            ");
                            __builder2.AddMarkupContent(161, "<h3 class=\"text-center mgb-0\">L1 - L3 CURRENT (A)</h3>");
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(162, "\r\n                        ");
                            __builder2.OpenElement(163, "div");
                            __builder2.AddAttribute$5(164, "class", "col-3 pd miwx-2");
                            __builder2.OpenElement(165, "div");
                            __builder2.AddAttribute$5(166, "class", "bg-card hx-2");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 167);
                            __builder2.AddComponentParameter(168, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), this.Services.SelectedServiceViewModel.SelectedDevice.Model$1.Statuses));
                            __builder2.AddComponentParameter(169, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*e*/ e) =>
                            {
                                return e.DateCreated.ToString();
                            }), $qSZRnk ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"e","p":2910116}],"n":"","d":817311,"h":0,"f":17825794}));
                            __builder2.AddComponentParameter(170, "MinAxes", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Double), 0), $.$$.S.Double));
                            __builder2.AddAttribute$3(171, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 172);
                                    __builder3.AddComponentParameter(173, "Label", "Red");
                                    __builder3.AddComponentParameter(174, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))().$ctor(this, ( (/*e*/ e) =>
                                    {
                                        return $.$box((e.LCFCCD$1$IDataListItemContext$$$Data.Red?.VA ?? null) / 1000, $.$$.S.Double);
                                    }), $KWCHPa ??= {"r":131073,"p":[{"n":"e","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddComponentParameter(175, "BorderColor", "#FF0000");
                                    __builder3.AddComponentParameter(176, "BackgroundColor", "#FF000080");
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(177, "\r\n                                    ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 178);
                                    __builder3.AddComponentParameter(179, "Label", "Yellow");
                                    __builder3.AddComponentParameter(180, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))().$ctor(this, ( (/*e*/ e) =>
                                    {
                                        return $.$box((e.LCFCCD$1$IDataListItemContext$$$Data.Yellow?.VA ?? null) / 1000, $.$$.S.Double);
                                    }), $cXjDzd ??= {"r":131073,"p":[{"n":"e","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddComponentParameter(181, "BorderColor", "#FFFF00");
                                    __builder3.AddComponentParameter(182, "BackgroundColor", "#FFFF0080");
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(183, "\r\n                                    ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 184);
                                    __builder3.AddComponentParameter(185, "Label", "Blue");
                                    __builder3.AddComponentParameter(186, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))().$ctor(this, ( (/*e*/ e) =>
                                    {
                                        return $.$box((e.LCFCCD$1$IDataListItemContext$$$Data.Blue?.VA ?? null) / 1000, $.$$.S.Double);
                                    }), $PpwtVi ??= {"r":131073,"p":[{"n":"e","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddComponentParameter(187, "BorderColor", "#0000FF");
                                    __builder3.AddComponentParameter(188, "BackgroundColor", "#0000FF80");
                                    __builder3.CloseComponent();
                                }, $gMEMoh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                            }), $FmUQyb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(189, "\r\n                            ");
                            __builder2.AddMarkupContent(190, "<h3 class=\"text-center mgb-0\">L1 - L3 POWER (KVA)</h3>");
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(191, "\r\n                    ");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCD$2.DataTable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 192);
                            __builder2.AddComponentParameter(193, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), this.Services.SelectedServiceViewModel.SelectedDevice.Model$1.Statuses));
                            __builder2.AddComponentParameter(194, "Class", "mgt-10");
                            __builder2.AddAttribute$3(195, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 196);
                                    __builder3.AddAttribute$3(197, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)))().$ctor(this, ( (/*items*/ items) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddContent$4(198, "Date/Time");
                                        }, $qvRNjg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $jzyaqd ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(199, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddContent$3(200, item.Data.DateCreated);
                                        }, $uVncRf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $hmotQd ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(201, "\r\n                            ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 202);
                                    __builder3.AddAttribute$3(203, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)))().$ctor(this, ( (/*items*/ items) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddContent$4(204, "Red Voltage");
                                        }, $yiUXXb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $ElSQra ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(205, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            /*LivingThing.Core.IOT.Common.Models.Gauges.Power.PowerPhase?*/ let __ca1__;
                                            __builder4.AddContent$4(206, ((__ca1__ = item.Data.Red) !== null ? $.$$.S.Double.ToString$3.call(__ca1__.Voltage, "0.00") : null));
                                        }, $eOpJCe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $BoXwfi ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(207, "\r\n                            ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 208);
                                    __builder3.AddAttribute$3(209, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)))().$ctor(this, ( (/*items*/ items) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddContent$4(210, "Yellow Voltage");
                                        }, $pgrUAi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $cEfCbe ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(211, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            /*LivingThing.Core.IOT.Common.Models.Gauges.Power.PowerPhase?*/ let __ca2__;
                                            __builder4.AddContent$4(212, ((__ca2__ = item.Data.Yellow) !== null ? $.$$.S.Double.ToString$3.call(__ca2__.Voltage, "0.00") : null));
                                        }, $TTdmHf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $fMgIll ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(213, "\r\n                            ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 214);
                                    __builder3.AddAttribute$3(215, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)))().$ctor(this, ( (/*items*/ items) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddContent$4(216, "Blue Voltage");
                                        }, $qrSmYj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $fcKYmh ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(217, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            /*LivingThing.Core.IOT.Common.Models.Gauges.Power.PowerPhase?*/ let __ca3__;
                                            __builder4.AddContent$4(218, ((__ca3__ = item.Data.Blue) !== null ? $.$$.S.Double.ToString$3.call(__ca3__.Voltage, "0.00") : null));
                                        }, $sVheka ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $oatWpj ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(219, "\r\n                            ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 220);
                                    __builder3.AddAttribute$3(221, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)))().$ctor(this, ( (/*items*/ items) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddContent$4(222, "Red Current");
                                        }, $eFHsgf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $HPEQyj ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(223, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            /*LivingThing.Core.IOT.Common.Models.Gauges.Power.PowerPhase?*/ let __ca4__;
                                            __builder4.AddContent$4(224, ((__ca4__ = item.Data.Red) !== null ? $.$$.S.Double.ToString$3.call(__ca4__.Current, "0.00") : null));
                                        }, $EvCUEi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $PyAlVk ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(225, "\r\n                            ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 226);
                                    __builder3.AddAttribute$3(227, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)))().$ctor(this, ( (/*items*/ items) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddContent$4(228, "Yellow Current");
                                        }, $RnCobe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $Evdlwa ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(229, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            /*LivingThing.Core.IOT.Common.Models.Gauges.Power.PowerPhase?*/ let __ca5__;
                                            __builder4.AddContent$4(230, ((__ca5__ = item.Data.Yellow) !== null ? $.$$.S.Double.ToString$3.call(__ca5__.Current, "0.00") : null));
                                        }, $uUNktb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $rnXZPf ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(231, "\r\n                            ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 232);
                                    __builder3.AddAttribute$3(233, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)))().$ctor(this, ( (/*items*/ items) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddContent$4(234, "Blue Current");
                                        }, $pQtsah ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $BTzRbg ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(235, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            /*LivingThing.Core.IOT.Common.Models.Gauges.Power.PowerPhase?*/ let __ca6__;
                                            __builder4.AddContent$4(236, ((__ca6__ = item.Data.Blue) !== null ? $.$$.S.Double.ToString$3.call(__ca6__.Current, "0.00") : null));
                                        }, $nJfoUg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $wdJaji ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(237, "\r\n                            ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 238);
                                    __builder3.AddAttribute$3(239, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)))().$ctor(this, ( (/*items*/ items) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddContent$4(240, "Red Power");
                                        }, $GkAYyk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $iKPKkj ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(241, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            /*LivingThing.Core.IOT.Common.Models.Gauges.Power.PowerPhase?*/ let __ca7__;
                                            __builder4.AddContent$4(242, ((__ca7__ = item.Data.Red) !== null ? $.$$.S.Double.ToString$3.call(__ca7__.Power, "0.00") : null));
                                        }, $YclHgf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $IpdvAi ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(243, "\r\n                            ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 244);
                                    __builder3.AddAttribute$3(245, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)))().$ctor(this, ( (/*items*/ items) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddContent$4(246, "Yellow Power");
                                        }, $ViUGWj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $DDtqUg ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(247, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            /*LivingThing.Core.IOT.Common.Models.Gauges.Power.PowerPhase?*/ let __ca8__;
                                            __builder4.AddContent$4(248, ((__ca8__ = item.Data.Yellow) !== null ? $.$$.S.Double.ToString$3.call(__ca8__.Power, "0.00") : null));
                                        }, $bKftQj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $veKRhk ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(249, "\r\n                            ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), 250);
                                    __builder3.AddAttribute$3(251, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)))().$ctor(this, ( (/*items*/ items) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddContent$4(252, "Blue Power");
                                        }, $EEJAKk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $luauJj ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(253, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            /*LivingThing.Core.IOT.Common.Models.Gauges.Power.PowerPhase?*/ let __ca9__;
                                            __builder4.AddContent$4(254, ((__ca9__ = item.Data.Blue) !== null ? $.$$.S.Double.ToString$3.call(__ca9__.Power, "0.00") : null));
                                        }, $wkCnph ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                                    }), $OcRbue ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }, $HRXlbk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":817311,"h":0,"f":17825794});
                            }), $RDfQia ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).$h}],"n":"","d":817311,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(255, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 256);
                                __builder3.AddComponentParameter(257, "Class", "mg");
                                __builder3.AddComponentParameter(258, "Message", "No data here");
                                __builder3.CloseComponent();
                            }), $GtgYVh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":817311,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }
                        __builder2.CloseElement();
                    }), $aczxEj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":817311,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180686495)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885719199)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885719199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885719199)
            
            //--TRIMMABLE-BOUNDARY-START(12885719199)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885719199)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(85900163231)
                this.Services = null;
                //--TRIMMABLE-BOUNDARY-END(85900163231)
                
                //--TRIMMABLE-BOUNDARY-START(68720294047)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(68720294047)
                
            }
            static $h = 817311;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85900163231),
    {
      "p": 1341599,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835392159,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374999711,
        "f": 83886081
      },
      "n": "Services",
      "d": 817311,
      "h": 85900163231,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900163231),
//--TRIMMABLE-BOUNDARY-START(68720294047),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655522975,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785065119,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 817311,
      "h": 68720294047,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720294047),
//--TRIMMABLE-BOUNDARY-START(77310228639),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245457567,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 817311,
      "h": 77310228639,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77310228639)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90195130527),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": $.$XBGm.LCICM.IOTDeviceMessagePipeNotification$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h
        }
      ],
      "n": "Services_OnStatusReceived",
      "d": 817311,
      "h": 90195130527,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90195130527),
//--TRIMMABLE-BOUNDARY-START(73015261343),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 817311,
      "h": 73015261343,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(73015261343),
//--TRIMMABLE-BOUNDARY-START(30065588383),
    {
      "r": 178454529,
      "n": "ExportXLS",
      "d": 817311,
      "h": 30065588383,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(30065588383),
//--TRIMMABLE-BOUNDARY-START(21475653791),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 817311,
      "h": 21475653791,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475653791),
//--TRIMMABLE-BOUNDARY-START(115964934303),
    {
      "r": 65537,
      "n": "ToggleSideBar",
      "d": 817311,
      "h": 115964934303,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115964934303),
//--TRIMMABLE-BOUNDARY-START(64425326751),
    {
      "r": 178454529,
      "n": "Logout",
      "d": 817311,
      "h": 64425326751,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(64425326751),
//--TRIMMABLE-BOUNDARY-START(60130359455),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 817311,
      "h": 60130359455,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130359455),
//--TRIMMABLE-BOUNDARY-START(17180686495),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 817311,
      "h": 17180686495,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180686495)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770621087),
    {
      "t": 262145,
      "n": "disposed",
      "d": 817311,
      "h": 25770621087,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770621087),
//--TRIMMABLE-BOUNDARY-START(111669967007),
    {
      "t": 262145,
      "n": "sideBarOpen",
      "d": 817311,
      "h": 111669967007,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(111669967007),
//--TRIMMABLE-BOUNDARY-START(81605195935),
    {
      "t": 262145,
      "n": "overlay",
      "d": 817311,
      "h": 81605195935,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81605195935)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885719199),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 817311,
      "h": 12885719199,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885719199)
  ],
  "h": 817311
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.Shared.EnergyMeterDash`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}Shared${separator}EnergyMeterDash`; }
        });
        //--TRIMMABLE-BOUNDARY-END(817311)
        
        

        //--TRIMMABLE-BOUNDARY-START(424095)
        $asm.$cls(`$eHSC.LCIECIU.EnergyMeterWidgetRenderer`, ($self) => class EnergyMeterWidgetRenderer extends $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$eHSC.LCIECIU.EnergyMeterWidgetFactory.EnergyMeterWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(8590358687)
            /*RenderFragment */ RenderToFragment(/*EnergyMeterWidgetFactory.EnergyMeterWidget*/ widget, /*IWidgetDataSource*/ dataSource, /*IRootWidgetRenderer*/ root)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590358687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$eHSC.LCIECIU.EnergyMeterWidgetView, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("ViewModel", widget);
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590358687)
            
            //--TRIMMABLE-BOUNDARY-START(4295391391)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295391391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295391391)
            
            //--TRIMMABLE-BOUNDARY-START(4295391391)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295391391)
            
            static $h = 424095;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$rfUg.LCFCFR.BaseWidgetRenderer$$($.$eHSC.LCIECIU.EnergyMeterWidgetFactory.EnergyMeterWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590358687),
    {
      "r": 6881395,
      "p": [
        {
          "n": "widget",
          "p": 358559
        },
        {
          "n": "dataSource",
          "p": 1453808
        },
        {
          "n": "root",
          "p": 1978096
        }
      ],
      "n": "RenderToFragment",
      "d": 424095,
      "h": 8590358687,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590358687)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295391391),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 424095,
      "h": 4295391391,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295391391)
  ],
  "h": 424095
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bMcF.LFCR.IUIRenderer$$($.$eHSC.LCIECIU.EnergyMeterWidgetFactory.EnergyMeterWidget), $.$bMcF.LFCR.IUIRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.Integrations.UIWidget.EnergyMeterWidgetRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}Integrations${separator}UIWidget${separator}EnergyMeterWidgetRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(424095)
        
        

        //--TRIMMABLE-BOUNDARY-START(489631)
        $asm.$cls(`$eHSC.LCIECIU.EnergyMeterWidgetView`, ($self) => class EnergyMeterWidgetView extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$eHSC.LCIECIU.EnergyMeterWidgetFactory.EnergyMeterWidget)
        {
            //--TRIMMABLE-BOUNDARY-START(47245129887)
            /*string */ get OptimizedComponentName()
            {
                return "energymeterwidgetview";
            }
            //--TRIMMABLE-BOUNDARY-END(47245129887)
            
            //--TRIMMABLE-BOUNDARY-START(38655195295)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655195295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Services = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$eHSC.LCIECV.EnergyMeterClientAppViewModel, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(38655195295)
            
            //--TRIMMABLE-BOUNDARY-START(51540097183)
            /*EnergyMeterClientAppViewModel*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(51540097183)
            
            //--TRIMMABLE-BOUNDARY-START(17180358815)
            /*EnergyMeterDeviceModel?*/ device = null;
            //--TRIMMABLE-BOUNDARY-END(17180358815)
            
            //--TRIMMABLE-BOUNDARY-START(42950162591)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950162591);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.ViewModel.UniqueId !== null)
                    {
                        let $t1, $r1;
                        ($t1 = this.Services.EnsureLoaded(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        this.device = $.$sl.SL.Enumerable.Single($.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$sl.SL.Enumerable.SelectMany$2($.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel, $.$uUnI.LCIECM.EnergyMeterDeviceModel, this.Services.Services, new ($.$$.S.Func$$$($.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel, $.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceModel)))().$ctor(this,  (/**/ c) =>
                        {
                            return $.$sl.SL.Enumerable.Select$1($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel, $.$uUnI.LCIECM.EnergyMeterDeviceModel, c.Devices, new ($.$$.S.Func$$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel, $.$uUnI.LCIECM.EnergyMeterDeviceModel))().$ctor(this,  (/**/ c) =>
                            {
                                return c.Model$1;
                            }, $PHegVb ??= {"r":1861540,"p":[{"n":"c","p":1210527}],"n":"","d":489631,"h":0,"f":17825794}));
                        }, $yhJPuk ??= {"r":$.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceModel).$h,"p":[{"n":"c","p":1276063}],"n":"","d":489631,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.UniqueId === this.ViewModel.UniqueId;
                        }, $jsWwCd ??= {"r":262145,"p":[{"n":"s","p":1861540}],"n":"","d":489631,"h":0,"f":17825794}));
                    }
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42950162591)
            
            //--TRIMMABLE-BOUNDARY-START(12885391519)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885391519);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.device !== null)
                {
                    __builder.OpenComponent$1($.$eHSC.LCIECS.EnergyMeterOverviewCard, 0);
                    __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uUnI.LCIECM.EnergyMeterDeviceModel, this.device));
                    __builder.AddComponentParameter(2, "FromWidget", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                    __builder.AddComponentParameter(3, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.AddProperty$3(this.OwnAttributes(null), this.ViewModel.Attributes).AddProperty($.$fPer.LCFC.Stringy.op_Implicit$3("class"), `bd sd bg-card`)));
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenElement(4, "div");
                    __builder.AddMultipleAttributes(5, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$3(this.OwnAttributes(null), this.ViewModel.Attributes).AddProperty($.$fPer.LCFC.Stringy.op_Implicit$3("class"), `bd sd bg-card stack`))));
                    __builder.OpenElement(6, "h3");
                    __builder.AddAttribute$5(7, "class", "mg-0 text-center");
                    __builder.AddContent$4(8, this.ViewModel.Name);
                    __builder.CloseElement();
                    __builder.AddMarkupContent(9, "\r\n        ");
                    __builder.OpenElement(10, "p");
                    __builder.AddContent$4(11, "Meter ");
                    __builder.AddContent$4(12, this.ViewModel.UniqueId);
                    __builder.AddContent$4(13, " not found.");
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885391519)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590424223)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590424223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590424223)
            
            //--TRIMMABLE-BOUNDARY-START(8590424223)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590424223)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51540097183)
                this.Services = null;
                //--TRIMMABLE-BOUNDARY-END(51540097183)
                
            }
            static $h = 489631;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$eHSC.LCIECIU.EnergyMeterWidgetFactory.EnergyMeterWidget); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245129887),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770293407,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 489631,
      "h": 47245129887,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47245129887),
//--TRIMMABLE-BOUNDARY-START(51540097183),
    {
      "p": 1341599,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360227999,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130031775,
        "f": 83886081
      },
      "n": "Services",
      "d": 489631,
      "h": 51540097183,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540097183)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655195295),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 489631,
      "h": 38655195295,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655195295),
//--TRIMMABLE-BOUNDARY-START(42950162591),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 489631,
      "h": 42950162591,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(42950162591),
//--TRIMMABLE-BOUNDARY-START(12885391519),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 489631,
      "h": 12885391519,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885391519)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180358815),
    {
      "t": 1861540,
      "n": "device",
      "d": 489631,
      "h": 17180358815,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180358815)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590424223),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 489631,
      "h": 8590424223,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590424223)
  ],
  "h": 489631
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.Integrations.UIWidget.EnergyMeterWidgetView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}Integrations${separator}UIWidget${separator}EnergyMeterWidgetView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(489631)
        
        

        //--TRIMMABLE-BOUNDARY-START(882847)
        $asm.$cls(`$eHSC.LCIECS.EnergyMeterDevice`, ($self) => class EnergyMeterDevice extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(51540490399)
            /*IHubConnector<IEnergyMeterServiceHubClient>*/ Hub = null;
            //--TRIMMABLE-BOUNDARY-END(51540490399)
            
            //--TRIMMABLE-BOUNDARY-START(60130424991)
            /*string*/ MeterId = null;
            //--TRIMMABLE-BOUNDARY-END(60130424991)
            
            //--TRIMMABLE-BOUNDARY-START(21475719327)
            /*IDisposable*/ dispose = null;
            //--TRIMMABLE-BOUNDARY-END(21475719327)
            
            //--TRIMMABLE-BOUNDARY-START(64425392287)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425392287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.dispose = this.Hub.LCFCH$IHubConnector$$$Subscribe(this);
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(64425392287)
            
            //--TRIMMABLE-BOUNDARY-START(107375065247)
            /*Task *//*async*/  UpdateStatus(/*object*/ id, /*EnergyMeterDeviceReceivedDataModel?*/ received, /*EnergyMeterDeviceStatusModel?*/ model)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107375065247);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.S.String.Equals$5.call($.$dsp(id, $.$$.S.Object, ($t) => $t.ToString), this.MeterId))
                    {
                        let $t1, $r1;
                        this.status = model;
                        ($t1 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Client.Blazor\\EnergyMeterDevice.razor.cs", "UpdateStatus", 30), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107375065247)
            
            //--TRIMMABLE-BOUNDARY-START(73015326879)
            /*Task */ Ping(/*object*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015326879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(73015326879)
            
            //--TRIMMABLE-BOUNDARY-START(77310294175)
            /*Task */ Pong(/*object*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310294175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(77310294175)
            
            //--TRIMMABLE-BOUNDARY-START(98785130655)
            /*EnergyMeterDeviceStatusModel*/ status = null;
            //--TRIMMABLE-BOUNDARY-END(98785130655)
            
            //--TRIMMABLE-BOUNDARY-START(68720359583)
            /*string */ get OptimizedComponentName()
            {
                return "energymeterdevice";
            }
            //--TRIMMABLE-BOUNDARY-END(68720359583)
            
            //--TRIMMABLE-BOUNDARY-START(103080097951)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080097951);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch2 = parameter.Name;
                switch($switch2)
                {
                    case "MeterId":
                    this.MeterId = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(103080097951)
            
            //--TRIMMABLE-BOUNDARY-START(55835457695)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835457695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Hub = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$kVHt.LCFCH.IHubConnector$$($.$uUnI.LCIECH.IEnergyMeterServiceHubClient), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(55835457695)
            
            //--TRIMMABLE-BOUNDARY-START(17180752031)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180752031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCR$1.RemoteDataDetail$$($.$uUnI.LCIECM.EnergyMeterDeviceModel), 0);
                __builder.AddComponentParameter(1, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$12(new $.$fPer.LCFCD.DataId().$ctor$3(this.MeterId, null))));
                __builder.AddAttribute$3(2, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$uUnI.LCIECM.EnergyMeterDeviceModel)))().$ctor(this, ( (/**/ meter) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.Menu, 3);
                        __builder2.AddAttribute$3(4, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*_*/ _0) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 5);
                                __builder3.AddAttribute$3(6, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCE.Editable$$($.$$.S.String), 7);
                                        __builder4.AddComponentParameter(8, "Enable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Boolean), true), $.$$.S.Boolean));
                                        __builder4.AddComponentParameter(9, "Tag", "h2");
                                        __builder4.AddComponentParameter(10, "EditableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCE.EditableFeatures, 54/*EditableFeatures.Default*/ | 1/*EditableFeatures.ServerUpdate*/), $.$hDPm.LCFCCE.EditableFeatures));
                                        __builder4.AddComponentParameter(11, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, meter.Model.Name));
                                        __builder4.AddComponentParameter(12, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                        {
                                            return meter.Model.Name = __value;
                                        }, $wNvYWj ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":882847,"h":0,"f":17825794}), meter.Model.Name))));
                                        __builder4.AddComponentParameter(13, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                        {
                                            return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1($.$clone(meter)), "Model"), "Name"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                        }, $RDxnPf ??= {"r":38797349,"n":"","d":882847,"h":0,"f":17825794})).Invoke())));
                                        __builder4.CloseComponent();
                                    }, $fekGwd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":882847,"h":0,"f":17825794});
                                }), $UzBPvi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":882847,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                                __builder3.AddMarkupContent(14, "\r\n        ");
                                __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 15);
                                __builder3.AddComponentParameter(16, "Fill", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                                __builder3.CloseComponent();
                                __builder3.AddMarkupContent(17, "\r\n        ");
                                __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 18);
                                __builder3.AddAttribute$3(19, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        $.$eHSC._LCIECSE.TypeInference.CreateRemoteDataEditor_0($.$hDPm.LCFCI.ContainerContext$$($.$uUnI.LCIECM.EnergyMeterDeviceModel), __builder4, 20, 21, $.$clone(meter), 22, $.$mac.MAC.EventCallback.Factory.Create$6($.$hDPm.LCFCI.ContainerContext$$($.$uUnI.LCIECM.EnergyMeterDeviceModel), this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$hDPm.LCFCI.ContainerContext$$($.$uUnI.LCIECM.EnergyMeterDeviceModel), this, new ($.$$.S.Action$$($.$hDPm.LCFCI.ContainerContext$$($.$uUnI.LCIECM.EnergyMeterDeviceModel)))().$ctor(this,  (/*__value*/ __value) =>
                                        {
                                            return meter = $.$clone(__value);
                                        }, $xQtQgh ??= {"r":65537,"p":[{"n":"__value","p":$.$hDPm.LCFCI.ContainerContext$$($.$uUnI.LCIECM.EnergyMeterDeviceModel).$h}],"n":"","d":882847,"h":0,"f":17825794}), $.$clone(meter))));
                                    }, $Mrjjth ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":882847,"h":0,"f":17825794});
                                }), $ojZnVa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":882847,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }, $pwXasf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":882847,"h":0,"f":17825794});
                        }), $TOddkg ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":882847,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        if ((this.status ?? (meter.Model?.Status ?? null)) !== null)
                        {
                            $.$eHSC._LCIECSE.TypeInference.CreateAutoDashboard_1($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, __builder2, 23, 24, this.status ?? (meter.Model?.Status ?? null));
                        }
                    }, $CkSRTb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":882847,"h":0,"f":17825794});
                }), $bVpKOi ??= {"r":6881395,"p":[{"n":"meter","p":$.$hDPm.LCFCI.ContainerContext$$($.$uUnI.LCIECM.EnergyMeterDeviceModel).$h}],"n":"","d":882847,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17180752031)
            
            //--TRIMMABLE-BOUNDARY-START(4319843729)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Hubs.IIOTDeviceHubClientBase<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel>.UpdateStatus(object, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModel?, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel?)
            LCICH$IIOTDeviceHubClientBase$$$$UpdateStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4319843729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UpdateStatus(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4319843729)
            
            //--TRIMMABLE-BOUNDARY-START(4319778193)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Hubs.IIOTDeviceHubClientBase.Ping(object)
            LCICH$IIOTDeviceHubClientBase$Ping()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4319778193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Ping(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4319778193)
            
            //--TRIMMABLE-BOUNDARY-START(8614745489)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Hubs.IIOTDeviceHubClientBase.Pong(object)
            LCICH$IIOTDeviceHubClientBase$Pong()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8614745489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Pong(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8614745489)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885784735)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885784735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885784735)
            
            //--TRIMMABLE-BOUNDARY-START(12885784735)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885784735)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51540490399)
                this.Hub = null;
                //--TRIMMABLE-BOUNDARY-END(51540490399)
                
            }
            static $h = 882847;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540490399),
    {
      "p": $.$kVHt.LCFCH.IHubConnector$$($.$uUnI.LCIECH.IEnergyMeterServiceHubClient).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065653919,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900228767,
        "f": 83886081
      },
      "n": "Hub",
      "d": 882847,
      "h": 51540490399,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540490399),
//--TRIMMABLE-BOUNDARY-START(60130424991),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655588511,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490163359,
        "f": 83886081
      },
      "n": "MeterId",
      "d": 882847,
      "h": 60130424991,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130424991),
//--TRIMMABLE-BOUNDARY-START(68720359583),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245523103,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 882847,
      "h": 68720359583,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68720359583)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425392287),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 882847,
      "h": 64425392287,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(64425392287),
//--TRIMMABLE-BOUNDARY-START(107375065247),
    {
      "r": 178454529,
      "p": [
        {
          "n": "id",
          "p": 131073
        },
        {
          "n": "received",
          "p": 2123684
        },
        {
          "n": "model",
          "p": 2910116
        }
      ],
      "n": "UpdateStatus",
      "d": 882847,
      "h": 107375065247,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(107375065247),
//--TRIMMABLE-BOUNDARY-START(73015326879),
    {
      "r": 178454529,
      "p": [
        {
          "n": "id",
          "p": 131073
        }
      ],
      "n": "Ping",
      "d": 882847,
      "h": 73015326879,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015326879),
//--TRIMMABLE-BOUNDARY-START(77310294175),
    {
      "r": 178454529,
      "p": [
        {
          "n": "id",
          "p": 131073
        }
      ],
      "n": "Pong",
      "d": 882847,
      "h": 77310294175,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310294175),
//--TRIMMABLE-BOUNDARY-START(103080097951),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 882847,
      "h": 103080097951,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103080097951),
//--TRIMMABLE-BOUNDARY-START(55835457695),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 882847,
      "h": 55835457695,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835457695),
//--TRIMMABLE-BOUNDARY-START(17180752031),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 882847,
      "h": 17180752031,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180752031)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475719327),
    {
      "t": 91095041,
      "n": "dispose",
      "d": 882847,
      "h": 21475719327,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475719327),
//--TRIMMABLE-BOUNDARY-START(98785130655),
    {
      "t": 2910116,
      "n": "status",
      "d": 882847,
      "h": 98785130655,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98785130655)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885784735),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 882847,
      "h": 12885784735,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885784735)
  ],
  "h": 882847
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.Shared.EnergyMeterDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}Shared${separator}EnergyMeterDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(882847)
        
        

        //--TRIMMABLE-BOUNDARY-START(1013919)
        $asm.$cls(`$eHSC.LCIECS.EnergyMeterOverviewCard`, ($self) => class EnergyMeterOverviewCard extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$uUnI.LCIECM.EnergyMeterDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(103080229023)
            /*string */ get OptimizedComponentName()
            {
                return "energymeteroverviewcard";
            }
            //--TRIMMABLE-BOUNDARY-END(103080229023)
            
            //--TRIMMABLE-BOUNDARY-START(150324869279)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324869279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "FromWidget":
                    this.FromWidget = $.$cast(parameter.Value, $.$$.S.Boolean);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(150324869279)
            
            //--TRIMMABLE-BOUNDARY-START(94490294431)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490294431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Services = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$eHSC.LCIECV.EnergyMeterClientAppViewModel, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(94490294431)
            
            //--TRIMMABLE-BOUNDARY-START(111670163615)
            /*EnergyMeterClientAppViewModel*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(111670163615)
            
            //--TRIMMABLE-BOUNDARY-START(47245654175)
            /*bool*/ FromWidget = false;
            //--TRIMMABLE-BOUNDARY-END(47245654175)
            
            //--TRIMMABLE-BOUNDARY-START(34360752287)
            /*bool*/ cyclePhase = true;
            //--TRIMMABLE-BOUNDARY-END(34360752287)
            
            //--TRIMMABLE-BOUNDARY-START(107375196319)
            /*int*/ phase = 0;
            //--TRIMMABLE-BOUNDARY-END(107375196319)
            
            //--TRIMMABLE-BOUNDARY-START(30065784991)
            /*int*/ cycleDelay = 0;
            //--TRIMMABLE-BOUNDARY-END(30065784991)
            
            //--TRIMMABLE-BOUNDARY-START(141734934687)
            /*void */ ToRedPhase()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734934687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.phase = 0;
                this.cycleDelay = 2;
            }
            //--TRIMMABLE-BOUNDARY-END(141734934687)
            
            //--TRIMMABLE-BOUNDARY-START(146029901983)
            /*void */ ToYellowPhase()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029901983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.phase = 1;
                this.cycleDelay = 2;
            }
            //--TRIMMABLE-BOUNDARY-END(146029901983)
            
            //--TRIMMABLE-BOUNDARY-START(137439967391)
            /*void */ ToBluePhase()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439967391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.phase = 2;
                this.cycleDelay = 2;
            }
            //--TRIMMABLE-BOUNDARY-END(137439967391)
            
            //--TRIMMABLE-BOUNDARY-START(21475850399)
            /*string */ get ColorStyle()
            {
                return this.phase === 0 ? "#FF3333" : this.phase === 1 ? "#C0C022" : "#3333FF";
            }
            //--TRIMMABLE-BOUNDARY-END(21475850399)
            
            //--TRIMMABLE-BOUNDARY-START(115965130911)
            /*void */ Services_OnStatusReceived(/*object?*/ sender, /*IOTDeviceMessagePipeNotification<EnergyMeterDeviceReceivedDataModel, EnergyMeterDeviceStatusModel>*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965130911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ViewModel.UniqueId === e.DeviceId)
                {
                    _ = this.StateChanged(true, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Client.Blazor\\EnergyMeterOverviewCard.razor.cs", "Services_OnStatusReceived", 29);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115965130911)
            
            //--TRIMMABLE-BOUNDARY-START(25770817695)
            /*PowerPhase? */ get CurrentPhase()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425523359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(this.phase)
                {
                    case 0:
                    return this.ViewModel.Status?.Red ?? null;
                    case 1:
                    return this.ViewModel.Status?.Yellow ?? null;
                    case 2:
                    return this.ViewModel.Status?.Blue ?? null;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(25770817695)
            
            //--TRIMMABLE-BOUNDARY-START(98785261727)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98785261727);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t3 = this.Services.EnsureLoaded(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    this.Services.add_OnStatusReceived(new ($.$$.S.EventHandler$$($.$XBGm.LCICM.IOTDeviceMessagePipeNotification$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)))().$ctor(this, this.Services_OnStatusReceived));
                    _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            while(!this.disposed)
                            {
                                let $t4, $r4;
                                ($t4 = $.$$.STT.Task.Delay$1(2000), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                if (this.cyclePhase)
                                {
                                    if (this.cycleDelay > 0)
                                    {
                                        this.cycleDelay--;
                                    }
                                    else 
                                    {
                                        this.phase = (((this.phase + 1) | 0)) % 3;
                                        _ = this.StateChanged(true, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Client.Blazor\\EnergyMeterOverviewCard.razor.cs", "OnInitializedAsync", 68);
                                    }
                                }
                            }
                        });
                    }, $KHEANd ??= {"r":178454529,"n":"","d":1013919,"h":0,"f":17829890}));
                    ($t5 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(98785261727)
            
            //--TRIMMABLE-BOUNDARY-START(42950686879)
            /*bool*/ disposed = false;
            //--TRIMMABLE-BOUNDARY-END(42950686879)
            
            //--TRIMMABLE-BOUNDARY-START(38655719583)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655719583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Services.remove_OnStatusReceived(new ($.$$.S.EventHandler$$($.$XBGm.LCICM.IOTDeviceMessagePipeNotification$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)))().$ctor(this, this.Services_OnStatusReceived));
                super.Dispose();
                this.disposed = true;
            }
            //--TRIMMABLE-BOUNDARY-END(38655719583)
            
            //--TRIMMABLE-BOUNDARY-START(17180883103)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180883103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass(this.OwnAttributes(null), `bg-card pd ${$.$strNN((!this.FromWidget ? "corner-5" : ""))} row`))));
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "col-a stack");
                __builder.OpenElement(4, "button");
                __builder.AddAttribute$5(5, "class", "mgx-a shadow clickable cl-white bd-0 wx-04 hx-04 round flex");
                __builder.AddAttribute$5(6, "style", "background-color:#FF3333" + $.$strNN((this.phase === 0 ? "" : "40")));
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 7, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToRedPhase)));
                __builder.AddMarkupContent(8, "<b class=\"mg-a\">L1</b>");
                __builder.CloseElement();
                __builder.AddMarkupContent(9, "\r\n        <div class=\"fill\"></div>\r\n        ");
                __builder.OpenElement(10, "button");
                __builder.AddAttribute$5(11, "class", "mgx-a shadow clickable cl-white bd-0 wx-04 hx-04 round flex");
                __builder.AddAttribute$5(12, "style", "background-color:#C0C022" + $.$strNN((this.phase === 1 ? "" : "40")));
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 13, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToYellowPhase)));
                __builder.AddMarkupContent(14, "<b class=\"mg-a\">L2</b>");
                __builder.CloseElement();
                __builder.AddMarkupContent(15, "\r\n        <div class=\"fill\"></div>\r\n        ");
                __builder.OpenElement(16, "button");
                __builder.AddAttribute$5(17, "class", "mgx-a shadow clickable cl-white bd-0 wx-04 hx-04 round flex");
                __builder.AddAttribute$5(18, "style", "background-color:#3333FF" + $.$strNN((this.phase === 2 ? "" : "40")));
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 19, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToBluePhase)));
                __builder.AddMarkupContent(20, "<b class=\"mg-a\">L3</b>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(21, "\r\n    ");
                __builder.OpenElement(22, "div");
                __builder.AddAttribute$5(23, "class", "col-a");
                __builder.OpenElement(24, "div");
                __builder.AddAttribute$5(25, "class", "clip hf bg-card wx-01 corner mgl stack");
                __builder.OpenElement(26, "div");
                __builder.AddAttribute$5(27, "class", $.$strNN($.$strNN("fill" + " clickable") + " ") + $.$strNN((this.phase === 0 ? "bg-primary" : "")));
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 28, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToRedPhase)));
                __builder.CloseElement();
                __builder.AddMarkupContent(29, "\r\n            ");
                __builder.OpenElement(30, "div");
                __builder.AddAttribute$5(31, "class", $.$strNN($.$strNN("fill" + " clickable") + " ") + $.$strNN((this.phase === 1 ? "bg-primary" : "")));
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 32, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToYellowPhase)));
                __builder.CloseElement();
                __builder.AddMarkupContent(33, "\r\n            ");
                __builder.OpenElement(34, "div");
                __builder.AddAttribute$5(35, "class", $.$strNN($.$strNN("fill" + " clickable") + " ") + $.$strNN((this.phase === 2 ? "bg-primary" : "")));
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 36, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToBluePhase)));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(37, "\r\n    ");
                __builder.OpenElement(38, "div");
                __builder.AddAttribute$5(39, "class", "col-10");
                __builder.OpenElement(40, "div");
                __builder.AddAttribute$5(41, "class", $.$strNN($.$strNN("mgx-a" + " ") + $.$strNN((this.FromWidget ? "flex flow" : "grid gap-1"))) + " colm-2");
                __builder.OpenElement(42, "div");
                __builder.AddAttribute$5(43, "class", "flex pd");
                __builder.OpenElement(44, "div");
                __builder.AddAttribute$5(45, "class", "mg-a stack");
                __builder.OpenElement(46, "div");
                __builder.AddAttribute$5(47, "class", "flex wx-15 hx-15 round bd bd-white bdw-3");
                __builder.AddAttribute$5(48, "style", "background-image: radial-gradient(#FFF 5%, #FFF 15%, #00AEFF 60%) ");
                __builder.OpenElement(49, "span");
                __builder.AddAttribute$5(50, "class", "mg-a fsz-50 fw-bold");
                __builder.AddAttribute$5(51, "style", "color:" + $.$strNN((this.ColorStyle)));
                /*LivingThing.Core.IOT.Common.Models.Gauges.Power.PowerPhase?*/ let __ca1__;
                __builder.AddContent$4(52, ((__ca1__ = this.CurrentPhase) !== null ? $.$$.S.Double.ToString$3.call(__ca1__.Voltage, "0.0") : null));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(53, "\r\n                    ");
                __builder.AddMarkupContent(54, "<span class=\"text-center fsz-25 mgt-5\">V</span>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(55, "\r\n            ");
                __builder.OpenElement(56, "div");
                __builder.AddAttribute$5(57, "class", "flex pd");
                __builder.OpenElement(58, "div");
                __builder.AddAttribute$5(59, "class", "mg-a stack");
                __builder.OpenElement(60, "div");
                __builder.AddAttribute$5(61, "class", "flex wx-15 hx-15 round bd bd-white bdw-3");
                __builder.AddAttribute$5(62, "style", "background-image: radial-gradient(#FFF 5%, #FFF 15%, #00AEFF 60%) ");
                __builder.OpenElement(63, "span");
                __builder.AddAttribute$5(64, "class", "mg-a fsz-50 fw-bold");
                __builder.AddAttribute$5(65, "style", "color:" + $.$strNN((this.ColorStyle)));
                /*LivingThing.Core.IOT.Common.Models.Gauges.Power.PowerPhase?*/ let __ca2__;
                __builder.AddContent$4(66, ((__ca2__ = this.CurrentPhase) !== null ? $.$$.S.Double.ToString$3.call(__ca2__.Current, "0.0") : null));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(67, "\r\n                    ");
                __builder.AddMarkupContent(68, "<span class=\"text-center fsz-25 mgt-5\">A</span>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(69, "\r\n            ");
                __builder.OpenElement(70, "div");
                __builder.AddAttribute$5(71, "class", "flex pd");
                __builder.OpenElement(72, "div");
                __builder.AddAttribute$5(73, "class", "mg-a stack");
                __builder.OpenElement(74, "div");
                __builder.AddAttribute$5(75, "class", "flex wx-15 hx-15 round bd bd-white bdw-3");
                __builder.AddAttribute$5(76, "style", "background-image: radial-gradient(#FFF 5%, #FFF 15%, #00AEFF 60%) ");
                __builder.OpenElement(77, "span");
                __builder.AddAttribute$5(78, "class", "mg-a fsz-50 fw-bold");
                __builder.AddAttribute$5(79, "style", "color:" + $.$strNN((this.ColorStyle)));
                /*double?*/ let __ca3__;
                __builder.AddContent$4(80, ((__ca3__ = ((this.CurrentPhase?.Power ?? null) > 1000 ? this.CurrentPhase.Power / 1000 : (this.CurrentPhase?.Power ?? null))) !== null ? $.$$.S.Double.ToString$3.call($.$$.S.Nullable$$($.$$.S.Double).Value$get.call(__ca3__), "0.0") : null));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(81, "\r\n                    ");
                __builder.OpenElement(82, "span");
                __builder.AddAttribute$5(83, "class", "text-center fsz-25 mgt-5");
                __builder.AddContent$4(84, (this.CurrentPhase?.Power ?? null) > 1000 ? "KW" : "W");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(85, "\r\n            ");
                __builder.OpenElement(86, "div");
                __builder.AddAttribute$5(87, "class", "flex pd");
                __builder.OpenElement(88, "div");
                __builder.AddAttribute$5(89, "class", "mg-a stack");
                __builder.OpenElement(90, "div");
                __builder.AddAttribute$5(91, "class", "flex wx-15 hx-15 round bd bd-white bdw-3");
                __builder.AddAttribute$5(92, "style", "background-image: radial-gradient(#FFF 5%, #FFF 15%, #00AEFF 60%)");
                __builder.OpenElement(93, "span");
                __builder.AddAttribute$5(94, "class", "mg-a fsz-50 fw-bold");
                __builder.AddAttribute$5(95, "style", "color:" + $.$strNN((this.ColorStyle)));
                /*double?*/ let __ca4__;
                __builder.AddContent$4(96, ((__ca4__ = ((this.CurrentPhase?.VA ?? null) > 1000 ? this.CurrentPhase.VA / 1000 : (this.CurrentPhase?.VA ?? null))) !== null ? $.$$.S.Double.ToString$3.call($.$$.S.Nullable$$($.$$.S.Double).Value$get.call(__ca4__), "0.0") : null));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(97, "\r\n                    ");
                __builder.OpenElement(98, "span");
                __builder.AddAttribute$5(99, "class", "text-center fsz-25 mgt-5");
                __builder.AddContent$4(100, (this.CurrentPhase?.VA ?? null) > 1000 ? "KVA" : "VA");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(101, "\r\n            ");
                __builder.OpenElement(102, "div");
                __builder.AddAttribute$5(103, "class", "flex pd");
                __builder.OpenElement(104, "div");
                __builder.AddAttribute$5(105, "class", "mg-a stack");
                __builder.OpenElement(106, "div");
                __builder.AddAttribute$5(107, "class", "flex wx-15 hx-15 round bd bd-white bdw-3");
                __builder.AddAttribute$5(108, "style", "background-image: radial-gradient(#FFF 5%, #FFF 15%, #00AEFF 60%)");
                __builder.OpenElement(109, "span");
                __builder.AddAttribute$5(110, "class", "mg-a fsz-50 fw-bold");
                __builder.AddAttribute$5(111, "style", "color:" + $.$strNN((this.ColorStyle)));
                /*LivingThing.Core.IOT.Common.Models.Gauges.Power.PowerPhase?*/ let __ca5__;
                __builder.AddContent$4(112, ((__ca5__ = this.CurrentPhase) !== null ? $.$$.S.Double.ToString$3.call(__ca5__.PowerFactor, "0.0") : null));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(113, "\r\n                    ");
                __builder.AddMarkupContent(114, "<span class=\"text-center fsz-25 mgt-5\">PF</span>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17180883103)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885915807)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885915807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885915807)
            
            //--TRIMMABLE-BOUNDARY-START(12885915807)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(12885915807)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(111670163615)
                this.Services = null;
                //--TRIMMABLE-BOUNDARY-END(111670163615)
                
            }
            static $h = 1013919;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$uUnI.LCIECM.EnergyMeterDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103080229023),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605392543,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1013919,
      "h": 103080229023,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(103080229023),
//--TRIMMABLE-BOUNDARY-START(111670163615),
    {
      "p": 1341599,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195327135,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145000095,
        "f": 83886081
      },
      "n": "Services",
      "d": 1013919,
      "h": 111670163615,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111670163615),
//--TRIMMABLE-BOUNDARY-START(47245654175),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015457951,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555065503,
        "f": 83886081
      },
      "n": "FromWidget",
      "d": 1013919,
      "h": 47245654175,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245654175),
//--TRIMMABLE-BOUNDARY-START(21475850399),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835588767,
        "f": 50331650
      },
      "n": "ColorStyle",
      "d": 1013919,
      "h": 21475850399,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21475850399),
//--TRIMMABLE-BOUNDARY-START(25770817695),
    {
      "p": 32871825,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425523359,
        "f": 50331650
      },
      "n": "CurrentPhase",
      "d": 1013919,
      "h": 25770817695,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(25770817695)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(150324869279),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1013919,
      "h": 150324869279,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150324869279),
//--TRIMMABLE-BOUNDARY-START(94490294431),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1013919,
      "h": 94490294431,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94490294431),
//--TRIMMABLE-BOUNDARY-START(141734934687),
    {
      "r": 65537,
      "n": "ToRedPhase",
      "d": 1013919,
      "h": 141734934687,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(141734934687),
//--TRIMMABLE-BOUNDARY-START(146029901983),
    {
      "r": 65537,
      "n": "ToYellowPhase",
      "d": 1013919,
      "h": 146029901983,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(146029901983),
//--TRIMMABLE-BOUNDARY-START(137439967391),
    {
      "r": 65537,
      "n": "ToBluePhase",
      "d": 1013919,
      "h": 137439967391,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137439967391),
//--TRIMMABLE-BOUNDARY-START(115965130911),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": $.$XBGm.LCICM.IOTDeviceMessagePipeNotification$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h
        }
      ],
      "n": "Services_OnStatusReceived",
      "d": 1013919,
      "h": 115965130911,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115965130911),
//--TRIMMABLE-BOUNDARY-START(98785261727),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1013919,
      "h": 98785261727,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(98785261727),
//--TRIMMABLE-BOUNDARY-START(38655719583),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1013919,
      "h": 38655719583,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655719583),
//--TRIMMABLE-BOUNDARY-START(17180883103),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1013919,
      "h": 17180883103,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180883103)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360752287),
    {
      "t": 262145,
      "n": "cyclePhase",
      "d": 1013919,
      "h": 34360752287,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360752287),
//--TRIMMABLE-BOUNDARY-START(107375196319),
    {
      "t": 655361,
      "n": "phase",
      "d": 1013919,
      "h": 107375196319,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(107375196319),
//--TRIMMABLE-BOUNDARY-START(30065784991),
    {
      "t": 655361,
      "n": "cycleDelay",
      "d": 1013919,
      "h": 30065784991,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065784991),
//--TRIMMABLE-BOUNDARY-START(42950686879),
    {
      "t": 262145,
      "n": "disposed",
      "d": 1013919,
      "h": 42950686879,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950686879)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885915807),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1013919,
      "h": 12885915807,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885915807)
  ],
  "h": 1013919
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.Shared.EnergyMeterOverviewCard`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}Shared${separator}EnergyMeterOverviewCard`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1013919)
        
        

        $asm.$typeProxy("$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel", "$eHSC.LivingThing.Core.IOT.EnergyMeter.Client.ViewModels.EnergyMeterClientAppServiceViewModel");
        $asm.$typeProxy("$eHSC.LCIECV.EnergyMeterClientAppDeviceScopeViewModel", "$eHSC.LivingThing.Core.IOT.EnergyMeter.Client.ViewModels.EnergyMeterClientAppDeviceScopeViewModel");
        $asm.$typeProxy("$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel", "$eHSC.LivingThing.Core.IOT.EnergyMeter.Client.ViewModels.EnergyMeterClientAppDeviceViewModel");
        //--TRIMMABLE-BOUNDARY-START(1341599)
        $asm.$cls(`$eHSC.LCIECV.EnergyMeterClientAppViewModel`, ($self) => class EnergyMeterClientAppViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($self, $.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceScopeViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel, $.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings).IOTClientAppViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296308895)
            $ctor$5(/*IOTRootViewModel*/ root, /*EnergyMeterDeviceFamily*/ family, /*IHubConnector<IEnergyMeterServiceHubClient>*/ hubConnector)
            {
                super.$ctor$5(root, family, hubConnector);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296308895);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296308895)
            
            //--TRIMMABLE-BOUNDARY-START(8591276191)
            /*bool */ get Authorize()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591276191)
            
            //--TRIMMABLE-BOUNDARY-START(21476178079)
            /*EnergyMeterClientAppServiceViewModel */ GetServiceViewModel(/*EnergyMeterServiceModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476178079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel().$ctor$3(this, model);
            }
            //--TRIMMABLE-BOUNDARY-END(21476178079)
            
            static $h = 1341599;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$eHSC.LCIECV.EnergyMeterClientAppViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceScopeViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel, $.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings).IOTClientAppViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591276191),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181210783,
        "f": 50364417
      },
      "n": "Authorize",
      "d": 1341599,
      "h": 8591276191,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591276191)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476178079),
    {
      "r": 1276063,
      "p": [
        {
          "n": "model",
          "p": 3368868
        }
      ],
      "n": "GetServiceViewModel",
      "d": 1341599,
      "h": 21476178079,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476178079)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296308895),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "family",
          "p": 419748
        },
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$($.$uUnI.LCIECH.IEnergyMeterServiceHubClient).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1341599,
      "h": 4296308895,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296308895)
  ],
  "h": 1341599
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$ntej.LCICV.IIOTAppViewModel$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$ntej.LCICV.IIOTApplicationViewModel, $.$vWqU.LCFCC.IServiceViewModel$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$vWqU.LCFCC.IServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$yleQ.LCFCA.IApplicationService, $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType), $.$vWqU.LCFCC.IServiceSubscriptionViewModel$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$vWqU.LCFCC.IServiceSubscriptionViewModel, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IClientRootService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$vWqU.LCFCC.IClientRootService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.ViewModels.EnergyMeterClientAppViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}ViewModels${separator}EnergyMeterClientAppViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1341599)
        
        

        //--TRIMMABLE-BOUNDARY-START(1144991)
        $asm.$cls(`$eHSC.LCIECV.EnergyMeterClientAppDeviceScopeViewModel`, ($self) => class EnergyMeterClientAppDeviceScopeViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$eHSC.LCIECV.EnergyMeterClientAppViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel, $self, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel, $.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296112287)
            $ctor$3(/*EnergyMeterClientAppServiceViewModel*/ service, /*EnergyMeterDeviceScopeModel*/ model, /*IEnumerable<EnergyMeterClientAppDeviceViewModel>*/ devices)
            {
                super.$ctor$3(service, model, devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296112287);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296112287)
            
            static $h = 1144991;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$eHSC.LCIECV.EnergyMeterClientAppViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceScopeViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel, $.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296112287),
    {
      "p": [
        {
          "n": "service",
          "p": 1276063
        },
        {
          "n": "model",
          "p": 2385828
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1144991,
      "h": 4296112287,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296112287)
  ],
  "h": 1144991
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$vWqU.LCFCC.IViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTDeviceScopeViewModel$$$($.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.ViewModels.EnergyMeterClientAppDeviceScopeViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}ViewModels${separator}EnergyMeterClientAppDeviceScopeViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1144991)
        
        

        //--TRIMMABLE-BOUNDARY-START(1276063)
        $asm.$cls(`$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel`, ($self) => class EnergyMeterClientAppServiceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$eHSC.LCIECV.EnergyMeterClientAppViewModel, $self, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceScopeViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel, $.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings).IOTClientAppServiceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296243359)
            $ctor$3(/*EnergyMeterClientAppViewModel*/ app, /*EnergyMeterServiceModel*/ model)
            {
                super.$ctor$3(app, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296243359);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296243359)
            
            //--TRIMMABLE-BOUNDARY-START(12886177951)
            /*EnergyMeterClientAppDeviceViewModel */ GetDeviceViewModel(/*EnergyMeterDeviceModel*/ model, /*IEnumerable<EnergyMeterClientAppDeviceScopeViewModel>*/ scopes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886177951);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel().$ctor$7(this, model, scopes);
            }
            //--TRIMMABLE-BOUNDARY-END(12886177951)
            
            //--TRIMMABLE-BOUNDARY-START(8591210655)
            /*EnergyMeterClientAppDeviceScopeViewModel */ GetDeviceScopeViewModel(/*EnergyMeterDeviceScopeModel*/ model, /*IEnumerable<EnergyMeterClientAppDeviceViewModel>*/ devices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591210655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$eHSC.LCIECV.EnergyMeterClientAppDeviceScopeViewModel().$ctor$3(this, model, devices);
            }
            //--TRIMMABLE-BOUNDARY-END(8591210655)
            
            static $h = 1276063;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$eHSC.LCIECV.EnergyMeterClientAppViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceScopeViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel, $.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings).IOTClientAppServiceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886177951),
    {
      "r": 1210527,
      "p": [
        {
          "n": "model",
          "p": 1861540
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": "GetDeviceViewModel",
      "d": 1276063,
      "h": 12886177951,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886177951),
//--TRIMMABLE-BOUNDARY-START(8591210655),
    {
      "r": 1144991,
      "p": [
        {
          "n": "model",
          "p": 2385828
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel).$h
        }
      ],
      "n": "GetDeviceScopeViewModel",
      "d": 1276063,
      "h": 8591210655,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591210655)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296243359),
    {
      "p": [
        {
          "n": "app",
          "p": 1341599
        },
        {
          "n": "model",
          "p": 3368868
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1276063,
      "h": 4296243359,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296243359)
  ],
  "h": 1276063
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTApplicationServiceViewModel$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceScopeViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), $.$ntej.LCICV.IIOTApplicationServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.ViewModels.EnergyMeterClientAppServiceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}ViewModels${separator}EnergyMeterClientAppServiceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1276063)
        
        

        //--TRIMMABLE-BOUNDARY-START(1210527)
        $asm.$cls(`$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel`, ($self) => class EnergyMeterClientAppDeviceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$eHSC.LCIECV.EnergyMeterClientAppViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceScopeViewModel, $self, $.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings).IOTClientAppDeviceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296177823)
            $ctor$7(/*EnergyMeterClientAppServiceViewModel*/ service, /*EnergyMeterDeviceModel*/ model, /*IEnumerable<EnergyMeterClientAppDeviceScopeViewModel>*/ scopes)
            {
                super.$ctor$7(service, model, scopes);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296177823);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296177823)
            
            static $h = 1210527;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$eHSC.LCIECV.EnergyMeterClientAppViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceScopeViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel, $.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings).IOTClientAppDeviceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296177823),
    {
      "p": [
        {
          "n": "service",
          "p": 1276063
        },
        {
          "n": "model",
          "p": 1861540
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$eHSC.LCIECV.EnergyMeterClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1210527,
      "h": 4296177823,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296177823)
  ],
  "h": 1210527
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICV.IIOTDeviceViewModel$$$$($.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), $.$ntej.LCICV.IIOTDeviceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.ViewModels.EnergyMeterClientAppDeviceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}ViewModels${separator}EnergyMeterClientAppDeviceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1210527)
        
        

        //--TRIMMABLE-BOUNDARY-START(1079455)
        $asm.$cls(`$eHSC.LCIECV.EnergyMeterClientAppDefinition`, ($self) => class EnergyMeterClientAppDefinition extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$eHSC.LCIECV.EnergyMeterClientAppViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceScopeViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel, $.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296046751)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296046751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296046751)
            
            //--TRIMMABLE-BOUNDARY-START(4296046751)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296046751)
            
            static $h = 1079455;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$eHSC.LCIECV.EnergyMeterClientAppViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppServiceViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceScopeViewModel, $.$eHSC.LCIECV.EnergyMeterClientAppDeviceViewModel, $.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296046751),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1079455,
      "h": 4296046751,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296046751)
  ],
  "h": 1079455
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Client.ViewModels.EnergyMeterClientAppDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Client${separator}ViewModels${separator}EnergyMeterClientAppDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1079455)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor", "NetJs.LivingThing.Core.IOT.Devices.Gateway", "NetJs.LivingThing.Core.IOT.EnergyMeter.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(30879)
