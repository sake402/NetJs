
//--TRIMMABLE-BOUNDARY-START(26532)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej, $NzWm) {
    "use strict";
    let _;
    let $JopPje;
    let $YIOZRj;
    let $HqVozh;
    let $qLJLkc;
    let $tpwNVi;
    let $NvIVue;
    let $oWWBSj;
    let $myXTSj;
    let $KGYCii;
    let $uSfSqk;
    let $DTMBhl;
    let $GmDheb;
    let $ubWQic;
    let $EivVka;
    let $BGJIQi;
    let $cmdFqc;
    let $iqMGPc;
    let $rmJXCa;
    let $tbotLj;
    let $fYiZpa;
    let $QWWXij;
    let $mKdCSe;
    let $szgYxd;
    let $OpmOji;
    let $DPFZac;
    let $HGjsRg;
    let $IleCLe;
    let $vKAxfc;
    let $aXLoKe;
    let $hQmaYf;
    let $qDaccl;
    let $zLePFk;
    let $zmIEud;
    let $QnMAhh;
    let $SwJIwd;
    let $JpZMuc;
    let $pbfeGe;
    let $ZyNTle;
    let $vzUVSd;
    let $bltoch;
    let $vThvla;
    let $Rayifi;
    let $GYeIBe;
    let $cWkMah;
    let $RQpscb;
    let $gwglZh;
    let $oOFUYe;
    let $irXEje;
    let $uUiGuh;
    let $cfIZxb;
    let $OKOoyf;
    let $fnTdHb;
    let $LPoNVe;
    let $HDbAZg;
    let $gMXbkd;
    let $McVeyj;
    let $YqURzh;
    let $ZSqqfi;
    let $gYbjVi;
    let $SQhLRk;
    let $OtrMUd;
    let $mVkfKc;
    let $GktqMf;
    let $rwzhlb;
    let $OePANh;
    let $eYfQkc;
    let $SXHMaj;
    let $rSATal;
    let $HMPoSh;
    let $uxLvFe;
    let $YYrUJf;
    let $boiUTa;
    let $rfUDnf;
    let $vTPfUf;
    let $UcIted;
    let $iSQCdh;
    let $cEJDme;
    let $wsVetd;
    let $nGuwyd;
    let $wSKjTe;
    let $uYmEYc;
    let $hcBAYe;
    let $iFDVQj;
    let $NIarai;
    let $LVhyfk;
    let $zRHNUc;
    let $ZOzIig;
    let $xHOeqg;
    let $qWwsff;
    let $QoLZbl;
    let $yRXTTb;
    let $xTSozh;
    let $AEVtjb;
    let $oAwKrf;
    let $EXxBNk;
    let $ePBzOc;
    let $lhunYh;
    let $QlNdqk;
    let $xXLcig;
    let $LgojXg;
    let $KYjIhk;
    let $YQfSdl;
    let $DzWkrj;
    let $zUeljc;
    let $YILTlh;
    let $AIEkab;
    let $LtBUne;
    let $tDoaTc;
    let $VqDNLb;
    let $YpJJwf;
    let $obYAmf;
    let $tnMoQc;
    let $dbFJec;
    let $notVpj;
    let $NZpUdf;
    let $VVaJwb;
    let $HjbVHe;
    let $nVNYae;
    let $jrvUJd;
    let $OIIYcf;
    let $ArcLFc;
    let $cKrYok;
    let $OYxjic;
    let $miZjHh;
    let $XAowsj;
    let $oIFYoh;
    let $TzHrXi;
    let $lwhtub;
    let $wofDvh;
    let $YxOxZk;
    let $JnkhNe;
    let $iusNRi;
    let $Cpthgk;
    let $KVkqaf;
    let $yZIsUi;
    let $MRVqQi;
    let $gBloGg;
    let $RaDpih;
    let $LCKrXd;
    let $yZxNmc;
    let $aqRXAi;
    let $CiRlHj;
    let $VIsmhh;
    let $DDXlnd;
    let $JpoBTf;
    let $mzRROc;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.EnergyMeter.Common", 
    {
  "h": 26532,
  "f": "LivingThing.Core.IOT.EnergyMeter.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.EnergyMeter.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.EnergyMeter.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRW5lcmd5TWV0ZXIuQ29tbW9uLkVuZXJneU1ldGVyU21hcnREZXZpY2UiOiB7DQogICAgICAiQ2F0ZWdvcmllcyI6IFsgIlBvd2VyIiBdLA0KICAgICAgIk5hbWUiOiAiRW5lcmd5TWV0ZXIiLA0KICAgICAgIkRlc2NyaXB0aW9uIjogIkdhdWdlIEFDIHBvd2VyIHN1cHBseSB2b2x0YWdlLCBjdXJyZW50IGFuZCBsb2FkLiIsDQogICAgICAiU2VydmljZUxpbmsiOiAiRW5lcmd5TWV0ZXIvQXBwIiwNCiAgICAgICJJY29uIjogeyAiTmFtZSI6ICJtZGkgbWRpLWZsYXNoIiB9LA0KICAgICAgIlRoZW1lQ29sb3IiOiAiI2FjMzIzMiIsDQogICAgICAiU2hvcnREZXNjcmlwdGlvbiI6ICJHYXVnZSBBQyBwb3dlciBzdXBwbHkgdm9sdGFnZSwgY3VycmVudCBhbmQgbG9hZC4iLA0KICAgICAgIlNjb3BlIjogIkhvbWUiLA0KICAgICAgIlNlY3VyaXRpZXMiOiAiQ2hhbGxlbmdlSGFuZFNoYWtlQXV0aGVudGljYXRpb25Qcm90b2NvbCxBZHZhbmNlZEVuY3J5cHRpb25TdGFuZGFyZCxFbGxpcHRpY0N1cnZlRmlybXdhcmVVcGRhdGVTaWduaW5nIiwNCiAgICAgICJTdGF0dXNOYW1lcyI6ICIuTW9kZWwuU3RhdHVzLlJlZC5Qb3dlckEsLk1vZGVsLlN0YXR1cy5SZWQuVm9sdGFnZUEsLk1vZGVsLlN0YXR1cy5SZWQuQ3VycmVudEEiDQogICAgfQ0KICB9DQp9"
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(747428)
        $asm.$cls(`$uUnI.LCIECH.IEnergyMeterHubServer`, ($self) => class IEnergyMeterHubServer
        {
            static $h = 747428;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 747428
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICH.IIOTDeviceHubServer, $.$kVHt.LCFCH.IComponentHubServer, $.$kVHt.LCFCH.IPluginHubServer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Hubs.IEnergyMeterHubServer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Hubs${separator}IEnergyMeterHubServer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(747428)
        
        

        //--TRIMMABLE-BOUNDARY-START(5072804)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettingsCustomAttributesProvider`, ($self) => class EnergyMeterDeviceGlobalSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300040100)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300040100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$2.IOTDeviceGlobalSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4300040100)
            
            static $h = 5072804;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300040100),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5072804,
      "h": 4300040100,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4300040100)
  ],
  "h": 5072804
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceGlobalSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDeviceGlobalSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5072804)
        
        

        //--TRIMMABLE-BOUNDARY-START(6645668)
        $asm.$cls(`$uUnI.LCIECS$2.EnergyMeterDeviceStatesCustomAttributesProvider`, ($self) => class EnergyMeterDeviceStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4301612964)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301612964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$3.IOTDeviceStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4301612964)
            
            static $h = 6645668;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4301612964),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 6645668,
      "h": 4301612964,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4301612964)
  ],
  "h": 6645668
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}States${separator}EnergyMeterDeviceStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6645668)
        
        

        //--TRIMMABLE-BOUNDARY-START(5597092)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettingsCustomAttributesProvider`, ($self) => class EnergyMeterDeviceScopeSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300564388)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300564388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$2.IOTDeviceScopeSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4300564388)
            
            static $h = 5597092;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300564388),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5597092,
      "h": 4300564388,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4300564388)
  ],
  "h": 5597092
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceScopeSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDeviceScopeSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5597092)
        
        

        //--TRIMMABLE-BOUNDARY-START(2451364)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceScopeModelCustomAttributesProvider`, ($self) => class EnergyMeterDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297418660)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297418660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297418660)
            
            static $h = 2451364;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297418660),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2451364,
      "h": 4297418660,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297418660)
  ],
  "h": 2451364
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2451364)
        
        

        //--TRIMMABLE-BOUNDARY-START(1664932)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceLogModelCustomAttributesProvider`, ($self) => class EnergyMeterDeviceLogModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296632228)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296632228)
            
            //--TRIMMABLE-BOUNDARY-START(8591599524)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591599524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$uUnI.LCIECM.EnergyMeterDeviceLogModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Type", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.ConvertType = ($.$$.S.Byte.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Date", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$uUnI.LCIECM.EnergyMeterDeviceLogModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $HqVozh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1664932,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $qLJLkc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1664932,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591599524)
            
            static $h = 1664932;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591599524),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1664932,
      "h": 8591599524,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591599524)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296632228),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1664932,
      "h": 4296632228,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296632228)
  ],
  "h": 1664932
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceLogModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceLogModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1664932)
        
        

        //--TRIMMABLE-BOUNDARY-START(3696548)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterServiceTierTypeCustomAttributesProvider`, ($self) => class EnergyMeterServiceTierTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298663844)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298663844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298663844)
            
            static $h = 3696548;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298663844),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3696548,
      "h": 4298663844,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298663844)
  ],
  "h": 3696548
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceTierTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterServiceTierTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3696548)
        
        

        //--TRIMMABLE-BOUNDARY-START(681892)
        $asm.$cls(`$uUnI.LCIEC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295649188)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295649188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295649188)
            
            static $h = 681892;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295649188),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 681892,
      "h": 4295649188,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295649188)
  ],
  "h": 681892
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(681892)
        
        

        //--TRIMMABLE-BOUNDARY-START(1009572)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceCommandModelCustomAttributesProvider`, ($self) => class EnergyMeterDeviceCommandModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295976868)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295976868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICM.IOTDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295976868)
            
            static $h = 1009572;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295976868),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1009572,
      "h": 4295976868,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295976868)
  ],
  "h": 1009572
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceCommandModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceCommandModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1009572)
        
        

        //--TRIMMABLE-BOUNDARY-START(2189220)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class EnergyMeterDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297156516)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297156516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$$($.$uUnI.LCIECM.EnergyMeterReceivedStatus, $.$uUnI.LCIECM.EnergyMeterDeviceLogModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297156516)
            
            static $h = 2189220;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297156516),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2189220,
      "h": 4297156516,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297156516)
  ],
  "h": 2189220
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2189220)
        
        

        //--TRIMMABLE-BOUNDARY-START(3893156)
        $asm.$cls(`$uUnI.LCIECM.EnergyPhaseCustomAttributesProvider`, ($self) => class EnergyPhaseCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298860452)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298860452)
            
            //--TRIMMABLE-BOUNDARY-START(8593827748)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593827748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$uUnI.LCIECM.EnergyPhaseCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$uUnI.LCIECM.EnergyPhaseCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $JopPje ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3893156,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $YIOZRj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3893156,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593827748)
            
            static $h = 3893156;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593827748),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3893156,
      "h": 8593827748,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593827748)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298860452),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3893156,
      "h": 4298860452,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298860452)
  ],
  "h": 3893156
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyPhaseCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyPhaseCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3893156)
        
        

        //--TRIMMABLE-BOUNDARY-START(1533860)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceFlagsCustomAttributesProvider`, ($self) => class EnergyMeterDeviceFlagsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296501156)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296501156)
            
            //--TRIMMABLE-BOUNDARY-START(8591468452)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591468452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$uUnI.LCIECM.EnergyMeterDeviceFlagsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$uUnI.LCIECM.EnergyMeterDeviceFlagsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $tpwNVi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1533860,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $NvIVue ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1533860,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591468452)
            
            static $h = 1533860;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591468452),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1533860,
      "h": 8591468452,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591468452)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296501156),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1533860,
      "h": 4296501156,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296501156)
  ],
  "h": 1533860
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceFlagsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceFlagsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1533860)
        
        

        //--TRIMMABLE-BOUNDARY-START(3434404)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterServiceModelCustomAttributesProvider`, ($self) => class EnergyMeterServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298401700)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298401700)
            
            //--TRIMMABLE-BOUNDARY-START(8593368996)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593368996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$uUnI.LCIECM.EnergyMeterServiceModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((1039), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$uUnI.LCIECM.EnergyMeterServiceModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $oWWBSj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3434404,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $myXTSj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3434404,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593368996)
            
            static $h = 3434404;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593368996),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3434404,
      "h": 8593368996,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593368996)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298401700),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3434404,
      "h": 4298401700,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298401700)
  ],
  "h": 3434404
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3434404)
        
        

        //--TRIMMABLE-BOUNDARY-START(6383524)
        $asm.$cls(`$uUnI.LCIECS$2.EnergyMeterDeviceScopeStatesCustomAttributesProvider`, ($self) => class EnergyMeterDeviceScopeStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4301350820)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301350820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$3.IOTDeviceScopeStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4301350820)
            
            static $h = 6383524;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4301350820),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 6383524,
      "h": 4301350820,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4301350820)
  ],
  "h": 6383524
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceScopeStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}States${separator}EnergyMeterDeviceScopeStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6383524)
        
        

        //--TRIMMABLE-BOUNDARY-START(5859236)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDeviceSettingsCustomAttributesProvider`, ($self) => class EnergyMeterDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300826532)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4300826532)
            
            //--TRIMMABLE-BOUNDARY-START(8595793828)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595793828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$uUnI.LCIECS$1.EnergyMeterDeviceSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("PowerCalibration", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$uUnI.LCIECS$1.EnergyMeterDeviceSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $ubWQic ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":5859236,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $EivVka ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":5859236,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8595793828)
            
            static $h = 5859236;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595793828),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5859236,
      "h": 8595793828,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595793828)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4300826532),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 5859236,
      "h": 4300826532,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4300826532)
  ],
  "h": 5859236
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5859236)
        
        

        //--TRIMMABLE-BOUNDARY-START(5334948)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class EnergyMeterDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300302244)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4300302244)
            
            //--TRIMMABLE-BOUNDARY-START(8595269540)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595269540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("CurrentTransformerRatio", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Key = "ct";
                            $i3.Order = (32);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("BurdenResitor", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Key = "bd";
                            $i4.Order = (33);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $KGYCii ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":5334948,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $uSfSqk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":5334948,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8595269540)
            
            static $h = 5334948;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595269540),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5334948,
      "h": 8595269540,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595269540)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4300302244),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 5334948,
      "h": 4300302244,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4300302244)
  ],
  "h": 5334948
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5334948)
        
        

        //--TRIMMABLE-BOUNDARY-START(1271716)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelCustomAttributesProvider`, ($self) => class EnergyMeterDeviceDataClassificationModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296239012)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296239012)
            
            //--TRIMMABLE-BOUNDARY-START(8591206308)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591206308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(7, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Runtime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Unit=s"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("RedEnergy", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Unit=Wh"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("BlueEnergy", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Unit=Wh"], [-1], null);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("YellowEnergy", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Unit=Wh"], [-1], null);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("TotalEnergy", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Unit=Wh"], [-1], null);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PeakPower", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Unit=W"], [-1], null);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ChartX", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $DTMBhl ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1271716,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $GmDheb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1271716,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICP.BaseDeviceDataClassificationModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591206308)
            
            static $h = 1271716;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591206308),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1271716,
      "h": 8591206308,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591206308)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296239012),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1271716,
      "h": 4296239012,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296239012)
  ],
  "h": 1271716
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceDataClassificationModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1271716)
        
        

        //--TRIMMABLE-BOUNDARY-START(6252452)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterServiceSettingsTypeDescriptorBuilder`, ($self) => class EnergyMeterServiceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8596187044)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596187044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECS$1.EnergyMeterServiceSettingsTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECS$1.EnergyMeterServiceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterServiceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $BGJIQi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":6252452,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECS$1.EnergyMeterServiceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8596187044)
            
            //--TRIMMABLE-BOUNDARY-START(4301219748)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301219748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301219748)
            
            //--TRIMMABLE-BOUNDARY-START(4301219748)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4301219748)
            
            static $h = 6252452;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596187044),
    {
      "r": 65537,
      "n": "Register",
      "d": 6252452,
      "h": 8596187044,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8596187044)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301219748),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 6252452,
      "h": 4301219748,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301219748)
  ],
  "h": 6252452
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterServiceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterServiceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6252452)
        
        

        //--TRIMMABLE-BOUNDARY-START(6907812)
        $asm.$cls(`$uUnI.LCIECS$2.EnergyMeterServiceStatesCustomAttributesProvider`, ($self) => class EnergyMeterServiceStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4301875108)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301875108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$3.IOTServiceStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4301875108)
            
            static $h = 6907812;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4301875108),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 6907812,
      "h": 4301875108,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4301875108)
  ],
  "h": 6907812
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterServiceStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}States${separator}EnergyMeterServiceStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6907812)
        
        

        //--TRIMMABLE-BOUNDARY-START(616356)
        $asm.$cls(`$uUnI.LCIEC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295583652)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295583652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECM.EnergyMeterDeviceCommandModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceCommandModelCustomAttributesProvider, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelCustomAttributesProvider, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECM.EnergyMeterDeviceFlags.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceFlagsCustomAttributesProvider, $.$uUnI.LCIECM.EnergyMeterDeviceFlagsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECM.EnergyMeterDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceModelCustomAttributesProvider, $.$uUnI.LCIECM.EnergyMeterDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECM.EnergyMeterDeviceLogModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceLogModelCustomAttributesProvider, $.$uUnI.LCIECM.EnergyMeterDeviceLogModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModelCustomAttributesProvider, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECM.EnergyMeterDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceScopeModelCustomAttributesProvider, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceSendDataModelCustomAttributesProvider, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceStatusModelCustomAttributesProvider, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECM.EnergyMeterServiceFeatureType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECM.EnergyMeterServiceFeatureTypeCustomAttributesProvider, $.$uUnI.LCIECM.EnergyMeterServiceFeatureTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECM.EnergyMeterServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECM.EnergyMeterServiceModelCustomAttributesProvider, $.$uUnI.LCIECM.EnergyMeterServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECM.EnergyMeterServiceTierType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECM.EnergyMeterServiceTierTypeCustomAttributesProvider, $.$uUnI.LCIECM.EnergyMeterServiceTierTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECM.EnergyPhase.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECM.EnergyPhaseCustomAttributesProvider, $.$uUnI.LCIECM.EnergyPhaseCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelCustomAttributesProvider, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettingsCustomAttributesProvider, $.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettingsCustomAttributesProvider, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettingsCustomAttributesProvider, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettingsCustomAttributesProvider, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECS$1.EnergyMeterDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECS$1.EnergyMeterDeviceSettingsCustomAttributesProvider, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECS$1.EnergyMeterServiceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECS$1.EnergyMeterServiceSettingsCustomAttributesProvider, $.$uUnI.LCIECS$1.EnergyMeterServiceSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStatesCustomAttributesProvider, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStatesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECS$2.EnergyMeterDeviceStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECS$2.EnergyMeterDeviceStatesCustomAttributesProvider, $.$uUnI.LCIECS$2.EnergyMeterDeviceStatesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uUnI.LCIECS$2.EnergyMeterServiceStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uUnI.LCIECS$2.EnergyMeterServiceStatesCustomAttributesProvider, $.$uUnI.LCIECS$2.EnergyMeterServiceStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295583652)
            
            static $h = 616356;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295583652),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 616356,
      "h": 4295583652,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295583652)
  ],
  "h": 616356
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(616356)
        
        

        //--TRIMMABLE-BOUNDARY-START(1796004)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceLogModelTypeDescriptorBuilder`, ($self) => class EnergyMeterDeviceLogModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591730596)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591730596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECM.EnergyMeterDeviceLogModelTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECM.EnergyMeterDeviceLogModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceLogModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $hQmaYf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1796004,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECM.EnergyMeterDeviceLogModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591730596)
            
            //--TRIMMABLE-BOUNDARY-START(4296763300)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296763300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296763300)
            
            //--TRIMMABLE-BOUNDARY-START(4296763300)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296763300)
            
            static $h = 1796004;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591730596),
    {
      "r": 65537,
      "n": "Register",
      "d": 1796004,
      "h": 8591730596,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591730596)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296763300),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1796004,
      "h": 4296763300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296763300)
  ],
  "h": 1796004
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceLogModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceLogModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1796004)
        
        

        //--TRIMMABLE-BOUNDARY-START(2582436)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceScopeModelTypeDescriptorBuilder`, ($self) => class EnergyMeterDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592517028)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592517028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECM.EnergyMeterDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECM.EnergyMeterDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $vKAxfc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2582436,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECM.EnergyMeterDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592517028)
            
            //--TRIMMABLE-BOUNDARY-START(4297549732)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297549732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297549732)
            
            //--TRIMMABLE-BOUNDARY-START(4297549732)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297549732)
            
            static $h = 2582436;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592517028),
    {
      "r": 65537,
      "n": "Register",
      "d": 2582436,
      "h": 8592517028,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592517028)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297549732),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2582436,
      "h": 4297549732,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297549732)
  ],
  "h": 2582436
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2582436)
        
        

        //--TRIMMABLE-BOUNDARY-START(5728164)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettingsTypeDescriptorBuilder`, ($self) => class EnergyMeterDeviceScopeSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595662756)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595662756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettingsTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceScopeSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $iqMGPc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5728164,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595662756)
            
            //--TRIMMABLE-BOUNDARY-START(4300695460)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300695460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300695460)
            
            //--TRIMMABLE-BOUNDARY-START(4300695460)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300695460)
            
            static $h = 5728164;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595662756),
    {
      "r": 65537,
      "n": "Register",
      "d": 5728164,
      "h": 8595662756,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595662756)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300695460),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5728164,
      "h": 4300695460,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300695460)
  ],
  "h": 5728164
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceScopeSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDeviceScopeSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5728164)
        
        

        //--TRIMMABLE-BOUNDARY-START(4810660)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettingsCustomAttributesProvider`, ($self) => class EnergyMeterDashboardGlobalSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299777956)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299777956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$2.IOTDashboardGlobalSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299777956)
            
            static $h = 4810660;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299777956),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4810660,
      "h": 4299777956,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299777956)
  ],
  "h": 4810660
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDashboardGlobalSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDashboardGlobalSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4810660)
        
        

        //--TRIMMABLE-BOUNDARY-START(6121380)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterServiceSettingsCustomAttributesProvider`, ($self) => class EnergyMeterServiceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4301088676)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301088676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICS$2.IOTServiceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4301088676)
            
            static $h = 6121380;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4301088676),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 6121380,
      "h": 4301088676,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4301088676)
  ],
  "h": 6121380
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterServiceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterServiceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6121380)
        
        

        //--TRIMMABLE-BOUNDARY-START(1402788)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptorBuilder`, ($self) => class EnergyMeterDeviceDataClassificationModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591337380)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591337380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $zUeljc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1402788,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591337380)
            
            //--TRIMMABLE-BOUNDARY-START(4296370084)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296370084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296370084)
            
            //--TRIMMABLE-BOUNDARY-START(4296370084)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296370084)
            
            static $h = 1402788;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591337380),
    {
      "r": 65537,
      "n": "Register",
      "d": 1402788,
      "h": 8591337380,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591337380)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296370084),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1402788,
      "h": 4296370084,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296370084)
  ],
  "h": 1402788
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceDataClassificationModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1402788)
        
        

        //--TRIMMABLE-BOUNDARY-START(2713508)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceSendDataModelCustomAttributesProvider`, ($self) => class EnergyMeterDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297680804)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297680804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceAcknowledgeLogModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297680804)
            
            static $h = 2713508;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297680804),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2713508,
      "h": 4297680804,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297680804)
  ],
  "h": 2713508
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2713508)
        
        

        //--TRIMMABLE-BOUNDARY-START(6514596)
        $asm.$cls(`$uUnI.LCIECS$2.EnergyMeterDeviceScopeStatesTypeDescriptorBuilder`, ($self) => class EnergyMeterDeviceScopeStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8596449188)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596449188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStatesTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceScopeStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $JpZMuc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":6514596,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8596449188)
            
            //--TRIMMABLE-BOUNDARY-START(4301481892)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301481892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301481892)
            
            //--TRIMMABLE-BOUNDARY-START(4301481892)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4301481892)
            
            static $h = 6514596;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596449188),
    {
      "r": 65537,
      "n": "Register",
      "d": 6514596,
      "h": 8596449188,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8596449188)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301481892),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 6514596,
      "h": 4301481892,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301481892)
  ],
  "h": 6514596
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceScopeStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}States${separator}EnergyMeterDeviceScopeStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6514596)
        
        

        //--TRIMMABLE-BOUNDARY-START(1140644)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceCommandModelTypeDescriptorBuilder`, ($self) => class EnergyMeterDeviceCommandModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591075236)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591075236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECM.EnergyMeterDeviceCommandModelTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECM.EnergyMeterDeviceCommandModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceCommandModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $bltoch ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1140644,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECM.EnergyMeterDeviceCommandModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591075236)
            
            //--TRIMMABLE-BOUNDARY-START(4296107940)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296107940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296107940)
            
            //--TRIMMABLE-BOUNDARY-START(4296107940)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296107940)
            
            static $h = 1140644;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591075236),
    {
      "r": 65537,
      "n": "Register",
      "d": 1140644,
      "h": 8591075236,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591075236)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296107940),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1140644,
      "h": 4296107940,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296107940)
  ],
  "h": 1140644
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceCommandModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceCommandModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1140644)
        
        

        //--TRIMMABLE-BOUNDARY-START(3303332)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterServiceFeatureTypeCustomAttributesProvider`, ($self) => class EnergyMeterServiceFeatureTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298270628)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298270628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298270628)
            
            static $h = 3303332;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298270628),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3303332,
      "h": 4298270628,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298270628)
  ],
  "h": 3303332
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceFeatureTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterServiceFeatureTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3303332)
        
        

        //--TRIMMABLE-BOUNDARY-START(7038884)
        $asm.$cls(`$uUnI.LCIECS$2.EnergyMeterServiceStatesTypeDescriptorBuilder`, ($self) => class EnergyMeterServiceStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8596973476)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596973476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECS$2.EnergyMeterServiceStatesTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECS$2.EnergyMeterServiceStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterServiceStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Rayifi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":7038884,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECS$2.EnergyMeterServiceStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8596973476)
            
            //--TRIMMABLE-BOUNDARY-START(4302006180)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4302006180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4302006180)
            
            //--TRIMMABLE-BOUNDARY-START(4302006180)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4302006180)
            
            static $h = 7038884;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596973476),
    {
      "r": 65537,
      "n": "Register",
      "d": 7038884,
      "h": 8596973476,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8596973476)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4302006180),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 7038884,
      "h": 4302006180,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4302006180)
  ],
  "h": 7038884
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterServiceStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}States${separator}EnergyMeterServiceStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(7038884)
        
        

        //--TRIMMABLE-BOUNDARY-START(2844580)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class EnergyMeterDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592779172)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592779172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ZyNTle ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2844580,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592779172)
            
            //--TRIMMABLE-BOUNDARY-START(4297811876)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297811876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297811876)
            
            //--TRIMMABLE-BOUNDARY-START(4297811876)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297811876)
            
            static $h = 2844580;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592779172),
    {
      "r": 65537,
      "n": "Register",
      "d": 2844580,
      "h": 8592779172,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592779172)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297811876),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2844580,
      "h": 4297811876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297811876)
  ],
  "h": 2844580
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2844580)
        
        

        //--TRIMMABLE-BOUNDARY-START(4155300)
        $asm.$cls(`$uUnI.LCIECP.EnergyMeterDeviceDashboardModelCustomAttributesProvider`, ($self) => class EnergyMeterDeviceDashboardModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299122596)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299122596)
            
            //--TRIMMABLE-BOUNDARY-START(8594089892)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594089892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(6, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("TotalRuntime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.Description = "Runtime";
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=Clock", "//Unit=s"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PowerCuts", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.Description = "How many times power was taken";
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=Power"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PeakVoltage", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3);
                            $i5.Description = "Maximum voltage recorded";
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=ElectricArc", "//Unit=V"], [-1], null);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PeakCurrent", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (4);
                            $i6.Description = "Maximum current recorded";
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=River", "//Unit=A"], [-1], null);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PeakPower", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (5);
                            $i7.Description = "Maximum power recorded";
                            $i7.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=River", "//Unit=W"], [-1], null);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("EnergyUsage", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Order = (6);
                            $i8.Description = "Energy Usage";
                            $i8.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=River", "//Unit=Wh"], [-1], null);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $uUiGuh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4155300,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $cfIZxb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4155300,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594089892)
            
            static $h = 4155300;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594089892),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4155300,
      "h": 8594089892,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594089892)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299122596),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4155300,
      "h": 4299122596,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299122596)
  ],
  "h": 4155300
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Processings.EnergyMeterDeviceDashboardModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Processings${separator}EnergyMeterDeviceDashboardModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4155300)
        
        

        //--TRIMMABLE-BOUNDARY-START(6776740)
        $asm.$cls(`$uUnI.LCIECS$2.EnergyMeterDeviceStatesTypeDescriptorBuilder`, ($self) => class EnergyMeterDeviceStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8596711332)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596711332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECS$2.EnergyMeterDeviceStatesTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECS$2.EnergyMeterDeviceStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $oOFUYe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":6776740,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECS$2.EnergyMeterDeviceStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8596711332)
            
            //--TRIMMABLE-BOUNDARY-START(4301744036)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301744036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301744036)
            
            //--TRIMMABLE-BOUNDARY-START(4301744036)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4301744036)
            
            static $h = 6776740;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596711332),
    {
      "r": 65537,
      "n": "Register",
      "d": 6776740,
      "h": 8596711332,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8596711332)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301744036),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 6776740,
      "h": 4301744036,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301744036)
  ],
  "h": 6776740
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}States${separator}EnergyMeterDeviceStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6776740)
        
        

        //--TRIMMABLE-BOUNDARY-START(5990308)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDeviceSettingsTypeDescriptorBuilder`, ($self) => class EnergyMeterDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595924900)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595924900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECS$1.EnergyMeterDeviceSettingsTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECS$1.EnergyMeterDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $rfUDnf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5990308,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECS$1.EnergyMeterDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595924900)
            
            //--TRIMMABLE-BOUNDARY-START(4300957604)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300957604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300957604)
            
            //--TRIMMABLE-BOUNDARY-START(4300957604)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300957604)
            
            static $h = 5990308;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595924900),
    {
      "r": 65537,
      "n": "Register",
      "d": 5990308,
      "h": 8595924900,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595924900)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300957604),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5990308,
      "h": 4300957604,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300957604)
  ],
  "h": 5990308
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5990308)
        
        

        //--TRIMMABLE-BOUNDARY-START(3565476)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterServiceModelTypeDescriptorBuilder`, ($self) => class EnergyMeterServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593500068)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593500068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECM.EnergyMeterServiceModelTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECM.EnergyMeterServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $gMXbkd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3565476,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECM.EnergyMeterServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593500068)
            
            //--TRIMMABLE-BOUNDARY-START(4298532772)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298532772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298532772)
            
            //--TRIMMABLE-BOUNDARY-START(4298532772)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298532772)
            
            static $h = 3565476;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593500068),
    {
      "r": 65537,
      "n": "Register",
      "d": 3565476,
      "h": 8593500068,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593500068)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298532772),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3565476,
      "h": 4298532772,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298532772)
  ],
  "h": 3565476
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3565476)
        
        

        //--TRIMMABLE-BOUNDARY-START(5203876)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettingsTypeDescriptorBuilder`, ($self) => class EnergyMeterDeviceGlobalSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595138468)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595138468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettingsTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceGlobalSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $OKOoyf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5203876,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595138468)
            
            //--TRIMMABLE-BOUNDARY-START(4300171172)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300171172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300171172)
            
            //--TRIMMABLE-BOUNDARY-START(4300171172)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300171172)
            
            static $h = 5203876;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595138468),
    {
      "r": 65537,
      "n": "Register",
      "d": 5203876,
      "h": 8595138468,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595138468)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300171172),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5203876,
      "h": 4300171172,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300171172)
  ],
  "h": 5203876
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceGlobalSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDeviceGlobalSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5203876)
        
        

        //--TRIMMABLE-BOUNDARY-START(2320292)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class EnergyMeterDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592254884)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592254884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $YqURzh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2320292,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592254884)
            
            //--TRIMMABLE-BOUNDARY-START(4297287588)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297287588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297287588)
            
            //--TRIMMABLE-BOUNDARY-START(4297287588)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297287588)
            
            static $h = 2320292;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592254884),
    {
      "r": 65537,
      "n": "Register",
      "d": 2320292,
      "h": 8592254884,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592254884)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297287588),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2320292,
      "h": 4297287588,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297287588)
  ],
  "h": 2320292
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2320292)
        
        

        //--TRIMMABLE-BOUNDARY-START(4089764)
        $asm.$cls(`$uUnI.LCIECP.EnergyMeterDeviceDashboardModel`, ($self) => class EnergyMeterDeviceDashboardModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(158917879716)
            /*int*/ TotalRuntime = 0;
            //--TRIMMABLE-BOUNDARY-END(158917879716)
            
            //--TRIMMABLE-BOUNDARY-START(103083304868)
            /*int*/ PowerCuts = 0;
            //--TRIMMABLE-BOUNDARY-END(103083304868)
            
            //--TRIMMABLE-BOUNDARY-START(98788337572)
            /*double*/ PeakVoltage = 0;
            //--TRIMMABLE-BOUNDARY-END(98788337572)
            
            //--TRIMMABLE-BOUNDARY-START(90198402980)
            /*double*/ PeakCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(90198402980)
            
            //--TRIMMABLE-BOUNDARY-START(94493370276)
            /*double*/ PeakPower = 0;
            //--TRIMMABLE-BOUNDARY-END(94493370276)
            
            //--TRIMMABLE-BOUNDARY-START(34363828132)
            /*double*/ EnergyUsage = 0;
            //--TRIMMABLE-BOUNDARY-END(34363828132)
            
            //--TRIMMABLE-BOUNDARY-START(30068860836)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068860836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30068860836)
            
            //--TRIMMABLE-BOUNDARY-START(30068860836)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(30068860836)
            
            static $h = 4089764;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(158917879716),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85903435684,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154622912420,
        "f": 83886081
      },
      "n": "TotalRuntime",
      "d": 4089764,
      "h": 158917879716,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Runtime",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=Clock",
                "//Unit=s"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158917879716),
//--TRIMMABLE-BOUNDARY-START(103083304868),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77313501092,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146032977828,
        "f": 83886081
      },
      "n": "PowerCuts",
      "d": 4089764,
      "h": 103083304868,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "How many times power was taken",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=Power"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103083304868),
//--TRIMMABLE-BOUNDARY-START(98788337572),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68723566500,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137443043236,
        "f": 83886081
      },
      "n": "PeakVoltage",
      "d": 4089764,
      "h": 98788337572,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Maximum voltage recorded",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=ElectricArc",
                "//Unit=V"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98788337572),
//--TRIMMABLE-BOUNDARY-START(90198402980),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51543697316,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120263174052,
        "f": 83886081
      },
      "n": "PeakCurrent",
      "d": 4089764,
      "h": 90198402980,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Maximum current recorded",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=River",
                "//Unit=A"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90198402980),
//--TRIMMABLE-BOUNDARY-START(94493370276),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60133631908,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128853108644,
        "f": 83886081
      },
      "n": "PeakPower",
      "d": 4089764,
      "h": 94493370276,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Maximum power recorded",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=River",
                "//Unit=W"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94493370276),
//--TRIMMABLE-BOUNDARY-START(34363828132),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42953762724,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111673239460,
        "f": 83886081
      },
      "n": "EnergyUsage",
      "d": 4089764,
      "h": 34363828132,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 6,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Energy Usage",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=River",
                "//Unit=Wh"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34363828132)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30068860836),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4089764,
      "h": 30068860836,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30068860836)
  ],
  "h": 4089764
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Processings.EnergyMeterDeviceDashboardModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Processings${separator}EnergyMeterDeviceDashboardModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4089764)
        
        

        //--TRIMMABLE-BOUNDARY-START(1927076)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceModelCustomAttributesProvider`, ($self) => class EnergyMeterDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296894372)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296894372)
            
            //--TRIMMABLE-BOUNDARY-START(8591861668)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591861668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$uUnI.LCIECM.EnergyMeterDeviceModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("DeviceFlags", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1536);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$uUnI.LCIECM.EnergyMeterDeviceModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $SQhLRk ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1927076,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $OtrMUd ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1927076,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591861668)
            
            static $h = 1927076;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591861668),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1927076,
      "h": 8591861668,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591861668)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296894372),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1927076,
      "h": 4296894372,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296894372)
  ],
  "h": 1927076
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1927076)
        
        

        //--TRIMMABLE-BOUNDARY-START(2975652)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceStatusModelCustomAttributesProvider`, ($self) => class EnergyMeterDeviceStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297942948)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297942948)
            
            //--TRIMMABLE-BOUNDARY-START(8592910244)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592910244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$uUnI.LCIECM.EnergyMeterDeviceStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(7, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("AvailablePhase", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1024);
                            $i3.ExcludeFilter = ($.$uUnI.LCIECM.VisibilityProvider.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Red", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (1025);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Yellow", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (1026);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Blue", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (1027);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Current", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (1038);
                            $i7.ExcludeFilter = ($.$uUnI.LCIECM.VisibilityProvider.$type);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Power", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Order = (1039);
                            $i8.ExcludeFilter = ($.$uUnI.LCIECM.VisibilityProvider.$type);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ConsumedEnergy", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Order = (1040);
                            $i9.ExcludeFilter = ($.$uUnI.LCIECM.VisibilityProvider.$type);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$uUnI.LCIECM.EnergyMeterDeviceStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $mVkfKc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2975652,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $GktqMf ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2975652,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICM.IOTDeviceStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592910244)
            
            static $h = 2975652;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592910244),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2975652,
      "h": 8592910244,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592910244)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297942948),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2975652,
      "h": 4297942948,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297942948)
  ],
  "h": 2975652
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2975652)
        
        

        //--TRIMMABLE-BOUNDARY-START(4286372)
        $asm.$cls(`$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptorBuilder`, ($self) => class EnergyMeterDeviceDashboardModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594220964)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594220964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.Processings.EnergyMeterDeviceDashboardModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $OIIYcf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4286372,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594220964)
            
            //--TRIMMABLE-BOUNDARY-START(4299253668)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299253668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299253668)
            
            //--TRIMMABLE-BOUNDARY-START(4299253668)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299253668)
            
            static $h = 4286372;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594220964),
    {
      "r": 65537,
      "n": "Register",
      "d": 4286372,
      "h": 8594220964,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594220964)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299253668),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4286372,
      "h": 4299253668,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299253668)
  ],
  "h": 4286372
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Processings.EnergyMeterDeviceDashboardModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Processings${separator}EnergyMeterDeviceDashboardModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4286372)
        
        

        //--TRIMMABLE-BOUNDARY-START(5466020)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class EnergyMeterDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595400612)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595400612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $oAwKrf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5466020,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595400612)
            
            //--TRIMMABLE-BOUNDARY-START(4300433316)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300433316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300433316)
            
            //--TRIMMABLE-BOUNDARY-START(4300433316)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300433316)
            
            static $h = 5466020;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595400612),
    {
      "r": 65537,
      "n": "Register",
      "d": 5466020,
      "h": 8595400612,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595400612)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300433316),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5466020,
      "h": 4300433316,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300433316)
  ],
  "h": 5466020
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5466020)
        
        

        //--TRIMMABLE-BOUNDARY-START(4941732)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettingsTypeDescriptorBuilder`, ($self) => class EnergyMeterDashboardGlobalSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594876324)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594876324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettingsTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDashboardGlobalSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $YYrUJf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4941732,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594876324)
            
            //--TRIMMABLE-BOUNDARY-START(4299909028)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299909028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299909028)
            
            //--TRIMMABLE-BOUNDARY-START(4299909028)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299909028)
            
            static $h = 4941732;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594876324),
    {
      "r": 65537,
      "n": "Register",
      "d": 4941732,
      "h": 8594876324,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594876324)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299909028),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4941732,
      "h": 4299909028,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299909028)
  ],
  "h": 4941732
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDashboardGlobalSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDashboardGlobalSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4941732)
        
        

        //--TRIMMABLE-BOUNDARY-START(878500)
        $asm.$cls(`$uUnI.LCIEC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295845796)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295845796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking().$ctor$3(impl);
                }, $hcBAYe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":878500,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel), $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking().$ctor$3(impl);
                }, $iFDVQj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":878500,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking().$ctor$3(impl);
                }, $NIarai ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":878500,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.IServiceRemoteService$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType), $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking().$ctor$3(impl);
                }, $LVhyfk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":878500,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking().$ctor$3(impl);
                }, $zRHNUc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":878500,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking().$ctor$3(impl);
                }, $ZOzIig ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":878500,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking().$ctor$3(impl);
                }, $xHOeqg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":878500,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking().$ctor$3(impl);
                }, $qWwsff ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":878500,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking().$ctor$3(impl);
                }, $QoLZbl ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":878500,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking().$ctor$3(impl);
                }, $yRXTTb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":878500,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking().$ctor$3(impl);
                }, $xTSozh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":878500,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$vWqU.LCFCCR.IReportService$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking().$ctor$3(impl);
                }, $AEVtjb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":878500,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295845796)
            
            static $h = 878500;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295845796),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 878500,
      "h": 4295845796,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295845796)
  ],
  "h": 878500
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(878500)
        
        

        //--TRIMMABLE-BOUNDARY-START(2058148)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceModelTypeDescriptorBuilder`, ($self) => class EnergyMeterDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591992740)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591992740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECM.EnergyMeterDeviceModelTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECM.EnergyMeterDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $LgojXg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2058148,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECM.EnergyMeterDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591992740)
            
            //--TRIMMABLE-BOUNDARY-START(4297025444)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297025444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297025444)
            
            //--TRIMMABLE-BOUNDARY-START(4297025444)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297025444)
            
            static $h = 2058148;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591992740),
    {
      "r": 65537,
      "n": "Register",
      "d": 2058148,
      "h": 8591992740,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591992740)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297025444),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2058148,
      "h": 4297025444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297025444)
  ],
  "h": 2058148
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2058148)
        
        

        //--TRIMMABLE-BOUNDARY-START(3106724)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptorBuilder`, ($self) => class EnergyMeterDeviceStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593041316)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593041316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptor()
                        const $t1 = $.$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $KVkqaf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3106724,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593041316)
            
            //--TRIMMABLE-BOUNDARY-START(4298074020)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298074020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298074020)
            
            //--TRIMMABLE-BOUNDARY-START(4298074020)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298074020)
            
            static $h = 3106724;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593041316),
    {
      "r": 65537,
      "n": "Register",
      "d": 3106724,
      "h": 8593041316,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593041316)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298074020),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3106724,
      "h": 4298074020,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298074020)
  ],
  "h": 3106724
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3106724)
        
        

        //--TRIMMABLE-BOUNDARY-START(7104420)
        $asm.$cls(`$uUnI.LCIEC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4302071716)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4302071716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$uUnI.LCIECM.EnergyMeterDeviceCommandModelTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECM.EnergyMeterDeviceModelTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECM.EnergyMeterDeviceLogModelTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECM.EnergyMeterDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECM.EnergyMeterServiceModelTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettingsTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettingsTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettingsTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECS$1.EnergyMeterDeviceSettingsTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECS$1.EnergyMeterServiceSettingsTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStatesTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECS$2.EnergyMeterDeviceStatesTypeDescriptorBuilder.Register();
                $.$uUnI.LCIECS$2.EnergyMeterServiceStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4302071716)
            
            static $h = 7104420;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4302071716),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 7104420,
      "h": 4302071716,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4302071716)
  ],
  "h": 7104420
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(7104420)
        
        

        //--TRIMMABLE-BOUNDARY-START(92068)
        $asm.$cls(`$uUnI.LCIEC.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17179961252)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17179961252)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295059364)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295059364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295059364)
            
            //--TRIMMABLE-BOUNDARY-START(4295059364)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295059364)
            
            static $h = 92068;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17179961252),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12884993956,
        "f": 50331649
      },
      "n": "Paths",
      "d": 92068,
      "h": 17179961252,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17179961252)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295059364),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 92068,
      "h": 4295059364,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295059364)
  ],
  "h": 92068
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(92068)
        
        

        //--TRIMMABLE-BOUNDARY-START(4417444)
        $asm.$cls(`$uUnI.LCIEC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594352036)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594352036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICP.IIOTDeviceDataClassifier$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), $.$uUnI.LCIECP.EnergyMeterDeviceDataClassifier, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICP.IIOTDeviceDashboardDataBuilder$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$uUnI.LCIECP.EnergyMeterDeviceDashboardBuilder, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$uUnI.LCIEC.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$uUnI.LCIEC.EnergyMeterDataConverter, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uUnI.LCIEC.EnergyMeterDataConverter, x);
                }, $tbotLj ??= {"r":$.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":4417444,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType), $.$uUnI.LCIEC.EnergyMeterDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$NzWm.LCIDGM$1.IGatewayModBusDeviceConfiguration$$($.$uUnI.LCIEC.EnergyMeterSmartDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$uUnI.LCIEC.EnergyMeterSmartDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$uUnI.LCIEC.EnergyMeterDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uUnI.LCIEC.EnergyMeterDeviceFamily, x);
                }, $fYiZpa ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":4417444,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uUnI.LCIEC.EnergyMeterDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$uUnI.LCIEC.EnergyMeterSmartDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $QWWXij ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":4417444,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$uUnI.LCIEC.EnergyMeterSmartDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uUnI.LCIEC.EnergyMeterDeviceFamily, x);
                }, $mKdCSe ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$uUnI.LCIEC.EnergyMeterSmartDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":4417444,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$NzWm.LCIDGM$1.IGatewayModBusDeviceConfiguration$$($.$uUnI.LCIEC.EnergyMeterSmartDevice)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uUnI.LCIEC.EnergyMeterDeviceFamily, x);
                }, $szgYxd ??= {"r":$.$NzWm.LCIDGM$1.IGatewayModBusDeviceConfiguration$$($.$uUnI.LCIEC.EnergyMeterSmartDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":4417444,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fPer.LCFCD.IDefaultValuesProvider$$($.$NzWm.LCIDGC.ModBusInputRegisterConfiguration), $.$NzWm.LCIDGS.GatewayChannelledDeviceModBusConfigurationProvider$$($.$uUnI.LCIEC.EnergyMeterSmartDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler$$($.$fPer.LCFCDM.BackedUpSinglePhasePower), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler$$($.$fPer.LCFCDM.BackedUpThreePhasePower), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$uUnI.LCIECS.EnergyMeterDeviceStatusHandler, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uUnI.LCIECS.EnergyMeterDeviceStatusHandler, x);
                }, $OpmOji ??= {"r":$.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":4417444,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler$$($.$fPer.LCFCDM.BackedUpThreePhasePower)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uUnI.LCIECS.EnergyMeterDeviceStatusHandler, x);
                }, $DPFZac ??= {"r":$.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler$$($.$fPer.LCFCDM.BackedUpThreePhasePower).$h,"p":[{"n":"x","p":327718}],"n":"","d":4417444,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler$$($.$fPer.LCFCDM.BackedUpSinglePhasePower)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uUnI.LCIECS.EnergyMeterDeviceStatusHandler, x);
                }, $HGjsRg ??= {"r":$.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler$$($.$fPer.LCFCDM.BackedUpSinglePhasePower).$h,"p":[{"n":"x","p":327718}],"n":"","d":4417444,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$uUnI.LCIEC.EnergyMeterDashboardScopeFactory, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceScopeFactory))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uUnI.LCIEC.EnergyMeterDashboardScopeFactory, x);
                }, $IleCLe ??= {"r":28611985,"p":[{"n":"x","p":327718}],"n":"","d":4417444,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel), $.$XBGm.LCICPB.BinaryPacketProtocol$$$$($.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICPB.BinaryPacketProtocolDecoder$$$($.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICPB.BinaryPacketProtocolEncoder$$$($.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICPB.BinaryPacketProtocolCommands$$($.$uUnI.LCIEC.EnergyMeterSmartDevice), services);
                $.$uUnI.LCIEC.MockingFactoryExtension.AddGeneratedMockedServices(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8594352036)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$uUnI.LCIEC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4299384740)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299384740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299384740)
            
            //--TRIMMABLE-BOUNDARY-START(4299384740)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299384740)
            
            static $h = 4417444;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594352036),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 4417444,
      "h": 8594352036,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594352036)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299384740),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4417444,
      "h": 4299384740,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299384740)
  ],
  "h": 4417444
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4417444)
        
        

        //--TRIMMABLE-BOUNDARY-START(3958692)
        $asm.$cls(`$uUnI.LCIECM.VisibilityProvider`, ($self) => class VisibilityProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593893284)
            /*bool */ Filter(/*object?*/ target, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593893284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let model;
                let device;
                if ($.$is(target, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, { set $v($v){ model = $v; } }))
                {
                    if (model.AvailablePhase !== null)
                    {
                        return typeOrProperty.AsT1.LCFCD$1$IPropertyDescriptor$Name === "AvailablePhase";
                    }
                    else 
                    {
                        return typeOrProperty.AsT1.LCFCD$1$IPropertyDescriptor$Name !== "AvailablePhase";
                    }
                }
                else if ($.$is(target, $.$uUnI.LCIECM.EnergyMeterDeviceModel, { set $v($v){ device = $v; } }))
                {
                    if (!((device.DeviceFlags & (1/*EnergyMeterDeviceFlags.LogAvailability*/)) == (1/*EnergyMeterDeviceFlags.LogAvailability*/)) && typeOrProperty.AsT1.LCFCD$1$IPropertyDescriptor$Name === "AvailablePhase")
                    {
                        return false;
                    }
                    if (!((device.DeviceFlags & (2/*EnergyMeterDeviceFlags.LogUsage*/)) == (2/*EnergyMeterDeviceFlags.LogUsage*/)) && typeOrProperty.AsT1.LCFCD$1$IPropertyDescriptor$Name !== "AvailablePhase")
                    {
                        return false;
                    }
                }
                return schema.AttributeFilter;
            }
            //--TRIMMABLE-BOUNDARY-END(8593893284)
            
            //--TRIMMABLE-BOUNDARY-START(4296968534)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaFilterProvider.Filter(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCA$1$ISchemaFilterProvider$Filter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296968534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Filter(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296968534)
            
            //--TRIMMABLE-BOUNDARY-START(4298925988)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298925988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298925988)
            
            //--TRIMMABLE-BOUNDARY-START(4298925988)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298925988)
            
            static $h = 3958692;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593893284),
    {
      "r": 262145,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "Filter",
      "d": 3958692,
      "h": 8593893284,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593893284)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298925988),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3958692,
      "h": 4298925988,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298925988)
  ],
  "h": 3958692
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaFilterProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.VisibilityProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}VisibilityProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3958692)
        
        

        //--TRIMMABLE-BOUNDARY-START(3762084)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterSupply`, ($self) => class EnergyMeterSupply extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(103082977188)
            /*PowerPhase*/ Red = null;
            //--TRIMMABLE-BOUNDARY-END(103082977188)
            
            //--TRIMMABLE-BOUNDARY-START(137442715556)
            /*PowerPhase*/ Yellow = null;
            //--TRIMMABLE-BOUNDARY-END(137442715556)
            
            //--TRIMMABLE-BOUNDARY-START(21478598564)
            /*PowerPhase*/ Blue = null;
            //--TRIMMABLE-BOUNDARY-END(21478598564)
            
            //--TRIMMABLE-BOUNDARY-START(60133304228)
            /*bool */ get HasValue()
            {
                return this.Red !== null || this.Yellow !== null || this.Blue !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(60133304228)
            
            //--TRIMMABLE-BOUNDARY-START(94493042596)
            /*ISinglePhasePower */ get LCFCDM$IThreePhasePower$Red()
            {
                return this.Red;
            }
            //--TRIMMABLE-BOUNDARY-END(94493042596)
            
            //--TRIMMABLE-BOUNDARY-START(98788009892)
            /*ISinglePhasePower */ get LCFCDM$IThreePhasePower$Yellow()
            {
                return this.Yellow;
            }
            //--TRIMMABLE-BOUNDARY-END(98788009892)
            
            //--TRIMMABLE-BOUNDARY-START(64428271524)
            /*ISinglePhasePower */ get LCFCDM$IThreePhasePower$Blue()
            {
                return this.Blue;
            }
            //--TRIMMABLE-BOUNDARY-END(64428271524)
            
            //--TRIMMABLE-BOUNDARY-START(133147748260)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133147748260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `R:(${$.$strNN(this.Red.ToString())}),Yellow:(${$.$strNN(this.Yellow.ToString())}),Blue:(${$.$strNN(this.Blue.ToString())})`;
            }
            //--TRIMMABLE-BOUNDARY-END(133147748260)
            
            //--TRIMMABLE-BOUNDARY-START(21502069078)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.Measurements.IThreePhasePower.HasValue.get
            get LCFCDM$IThreePhasePower$HasValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42976905558);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HasValue;
            }
            //--TRIMMABLE-BOUNDARY-END(21502069078)
            
            //--TRIMMABLE-BOUNDARY-START(17183631268)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183631268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183631268)
            
            //--TRIMMABLE-BOUNDARY-START(17183631268)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17183631268)
            
            static $h = 3762084;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103082977188),
    {
      "p": 32871825,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47248402340,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120262846372,
        "f": 83886081
      },
      "n": "Red",
      "d": 3762084,
      "h": 103082977188,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103082977188),
//--TRIMMABLE-BOUNDARY-START(137442715556),
    {
      "p": 32871825,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55838336932,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128852780964,
        "f": 83886081
      },
      "n": "Yellow",
      "d": 3762084,
      "h": 137442715556,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137442715556),
//--TRIMMABLE-BOUNDARY-START(21478598564),
    {
      "p": 32871825,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068533156,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111672911780,
        "f": 83886081
      },
      "n": "Blue",
      "d": 3762084,
      "h": 21478598564,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21478598564),
//--TRIMMABLE-BOUNDARY-START(60133304228),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38658467748,
        "f": 50331649
      },
      "n": "HasValue",
      "d": 3762084,
      "h": 60133304228,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60133304228),
//--TRIMMABLE-BOUNDARY-START(94493042596),
    {
      "p": 27167062,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81608140708,
        "f": 50331650
      },
      "n": "{27232598}.Red",
      "o": "LCFCDM$IThreePhasePower$Red",
      "d": 3762084,
      "h": 94493042596,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(94493042596),
//--TRIMMABLE-BOUNDARY-START(98788009892),
    {
      "p": 27167062,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90198075300,
        "f": 50331650
      },
      "n": "{27232598}.Yellow",
      "o": "LCFCDM$IThreePhasePower$Yellow",
      "d": 3762084,
      "h": 98788009892,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98788009892),
//--TRIMMABLE-BOUNDARY-START(64428271524),
    {
      "p": 27167062,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73018206116,
        "f": 50331650
      },
      "n": "{27232598}.Blue",
      "o": "LCFCDM$IThreePhasePower$Blue",
      "d": 3762084,
      "h": 64428271524,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(64428271524)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(133147748260),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 3762084,
      "h": 133147748260,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(133147748260)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183631268),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3762084,
      "h": 17183631268,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183631268)
  ],
  "h": 3762084
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCDM.IThreePhasePower, $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterSupply`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterSupply`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3762084)
        
        

        //--TRIMMABLE-BOUNDARY-START(1206180)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel`, ($self) => class EnergyMeterDeviceDataClassificationModel extends $.$XBGm.LCICP.BaseDeviceDataClassificationModel
        {
            //--TRIMMABLE-BOUNDARY-START(128850225060)
            /*int*/ Runtime = 0;
            //--TRIMMABLE-BOUNDARY-END(128850225060)
            
            //--TRIMMABLE-BOUNDARY-START(120260290468)
            /*int*/ PowerCuts = 0;
            //--TRIMMABLE-BOUNDARY-END(120260290468)
            
            //--TRIMMABLE-BOUNDARY-START(124555257764)
            /*double*/ RedEnergy = 0;
            //--TRIMMABLE-BOUNDARY-END(124555257764)
            
            //--TRIMMABLE-BOUNDARY-START(34360944548)
            /*double*/ BlueEnergy = 0;
            //--TRIMMABLE-BOUNDARY-END(34360944548)
            
            //--TRIMMABLE-BOUNDARY-START(188979767204)
            /*double*/ YellowEnergy = 0;
            //--TRIMMABLE-BOUNDARY-END(188979767204)
            
            //--TRIMMABLE-BOUNDARY-START(184684799908)
            /*double */ get TotalEnergy()
            {
                return this.RedEnergy + this.BlueEnergy + this.YellowEnergy;
            }
            //--TRIMMABLE-BOUNDARY-END(184684799908)
            
            //--TRIMMABLE-BOUNDARY-START(115965323172)
            /*double*/ PeakPower = 0;
            //--TRIMMABLE-BOUNDARY-END(115965323172)
            
            //--TRIMMABLE-BOUNDARY-START(38655911844)
            /*string */ get ChartX()
            {
                return this.StartDate.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(38655911844)
            
            //--TRIMMABLE-BOUNDARY-START(111670355876)
            /*object? */ GetChartDataPoint(/*IPropertyDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670355876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = descriptor.LCFCD$1$IPropertyDescriptor$Name;
                switch($switch1)
                {
                    case "Runtime":
                    return $.$box(this.Runtime, $.$$.S.Int32);
                    case "PowerCuts":
                    return $.$box(this.PowerCuts, $.$$.S.Int32);
                    case "RedEnergy":
                    return $.$box(this.RedEnergy, $.$$.S.Double);
                    case "BlueEnergy":
                    return $.$box(this.BlueEnergy, $.$$.S.Double);
                    case "YellowEnergy":
                    return $.$box(this.YellowEnergy, $.$$.S.Double);
                    case "TotalEnergy":
                    return $.$box(this.TotalEnergy, $.$$.S.Double);
                    case "PeakPower":
                    return $.$box(this.PeakPower, $.$$.S.Double);
                }
                return super.GetChartDataPoint(descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(111670355876)
            
            //--TRIMMABLE-BOUNDARY-START(30065977252)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065977252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065977252)
            
            //--TRIMMABLE-BOUNDARY-START(30065977252)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(30065977252)
            
            static $h = 1206180;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICP.BaseDeviceDataClassificationModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(128850225060),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195519396,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799898020,
        "f": 83886081
      },
      "n": "Runtime",
      "d": 1206180,
      "h": 128850225060,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Unit=s"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128850225060),
//--TRIMMABLE-BOUNDARY-START(120260290468),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015650212,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620028836,
        "f": 83886081
      },
      "n": "PowerCuts",
      "d": 1206180,
      "h": 120260290468,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260290468),
//--TRIMMABLE-BOUNDARY-START(124555257764),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605584804,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209963428,
        "f": 83886081
      },
      "n": "RedEnergy",
      "d": 1206180,
      "h": 124555257764,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Unit=Wh"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124555257764),
//--TRIMMABLE-BOUNDARY-START(34360944548),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245846436,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137440159652,
        "f": 83886081
      },
      "n": "BlueEnergy",
      "d": 1206180,
      "h": 34360944548,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Unit=Wh"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360944548),
//--TRIMMABLE-BOUNDARY-START(188979767204),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375388580,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180389832612,
        "f": 83886081
      },
      "n": "YellowEnergy",
      "d": 1206180,
      "h": 188979767204,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Unit=Wh"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188979767204),
//--TRIMMABLE-BOUNDARY-START(184684799908),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785453988,
        "f": 50331649
      },
      "n": "TotalEnergy",
      "d": 1206180,
      "h": 184684799908,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Unit=Wh"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184684799908),
//--TRIMMABLE-BOUNDARY-START(115965323172),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425715620,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146030094244,
        "f": 83886081
      },
      "n": "PeakPower",
      "d": 1206180,
      "h": 115965323172,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Unit=W"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115965323172),
//--TRIMMABLE-BOUNDARY-START(38655911844),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835781028,
        "f": 50364417
      },
      "n": "ChartX",
      "d": 1206180,
      "h": 38655911844,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655911844)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111670355876),
    {
      "r": 131073,
      "p": [
        {
          "n": "descriptor",
          "p": 40733014
        }
      ],
      "n": "GetChartDataPoint",
      "d": 1206180,
      "h": 111670355876,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111670355876)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065977252),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1206180,
      "h": 30065977252,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065977252)
  ],
  "h": 1206180
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICP.IIOTDeviceClassifiedData, $.$fPer.LCFCD.IChartableData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceDataClassificationModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1206180)
        
        

        //--TRIMMABLE-BOUNDARY-START(3172260)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterReceivedStatus`, ($self) => class EnergyMeterReceivedStatus extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(47247812516)
            /*EnergyMeterSupply*/ Grid = null;
            //--TRIMMABLE-BOUNDARY-END(47247812516)
            
            //--TRIMMABLE-BOUNDARY-START(17183041444)
            /*EnergyMeterSupply*/ Backup = null;
            //--TRIMMABLE-BOUNDARY-END(17183041444)
            
            //--TRIMMABLE-BOUNDARY-START(51542779812)
            /*bool */ get HasValue()
            {
                return ((this.Grid?.HasValue ?? null) ?? false) || ((this.Backup?.HasValue ?? null) ?? false);
            }
            //--TRIMMABLE-BOUNDARY-END(51542779812)
            
            //--TRIMMABLE-BOUNDARY-START(77312583588)
            /*IThreePhasePower */ get LCFCDM$IBackedUpThreePhasePower$Grid()
            {
                return this.Grid;
            }
            //--TRIMMABLE-BOUNDARY-END(77312583588)
            
            //--TRIMMABLE-BOUNDARY-START(55837747108)
            /*IThreePhasePower */ get LCFCDM$IBackedUpThreePhasePower$Backup()
            {
                return this.Backup;
            }
            //--TRIMMABLE-BOUNDARY-END(55837747108)
            
            //--TRIMMABLE-BOUNDARY-START(98787420068)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787420068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `Grid: ${$.$strNN(this.Grid.ToString())}\r\nBackup:${$.$strNN(this.Backup.ToString())}`;
            }
            //--TRIMMABLE-BOUNDARY-END(98787420068)
            
            //--TRIMMABLE-BOUNDARY-START(30091807062)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.Measurements.IBackedUpThreePhasePower.HasValue.get
            get LCFCDM$IBackedUpThreePhasePower$HasValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38681741654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HasValue;
            }
            //--TRIMMABLE-BOUNDARY-END(30091807062)
            
            //--TRIMMABLE-BOUNDARY-START(12888074148)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888074148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888074148)
            
            //--TRIMMABLE-BOUNDARY-START(12888074148)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12888074148)
            
            static $h = 3172260;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47247812516),
    {
      "p": 3762084,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362910628,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94492452772,
        "f": 83886081
      },
      "n": "Grid",
      "d": 3172260,
      "h": 47247812516,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 10,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47247812516),
//--TRIMMABLE-BOUNDARY-START(17183041444),
    {
      "p": 3762084,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772976036,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85902518180,
        "f": 83886081
      },
      "n": "Backup",
      "d": 3172260,
      "h": 17183041444,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17183041444),
//--TRIMMABLE-BOUNDARY-START(51542779812),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952845220,
        "f": 50331649
      },
      "n": "HasValue",
      "d": 3172260,
      "h": 51542779812,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51542779812),
//--TRIMMABLE-BOUNDARY-START(77312583588),
    {
      "p": 27232598,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73017616292,
        "f": 50331650
      },
      "n": "{27035990}.Grid",
      "o": "LCFCDM$IBackedUpThreePhasePower$Grid",
      "d": 3172260,
      "h": 77312583588,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(77312583588),
//--TRIMMABLE-BOUNDARY-START(55837747108),
    {
      "p": 27232598,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427681700,
        "f": 50331650
      },
      "n": "{27035990}.Backup",
      "o": "LCFCDM$IBackedUpThreePhasePower$Backup",
      "d": 3172260,
      "h": 55837747108,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55837747108)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98787420068),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 3172260,
      "h": 98787420068,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98787420068)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888074148),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3172260,
      "h": 12888074148,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888074148)
  ],
  "h": 3172260
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder, $.$fPer.LCFCDM.IBackedUpThreePhasePower ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterReceivedStatus`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterReceivedStatus`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3172260)
        
        

        //--TRIMMABLE-BOUNDARY-START(3631012)
        $asm.$str(`$uUnI.LCIECM.EnergyMeterServiceTierType`, ($self) => class EnergyMeterServiceTierType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3631012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298598308)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298598308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298598308)
            
            //--TRIMMABLE-BOUNDARY-START(4298598308)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298598308)
            
            static $h = 3631012;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8593565604),
    {
      "t": 3631012,
      "n": "None",
      "d": 3631012,
      "h": 8593565604,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593565604)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298598308),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3631012,
      "h": 4298598308,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298598308)
  ],
  "h": 3631012
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceTierType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterServiceTierType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3631012)
        
        

        //--TRIMMABLE-BOUNDARY-START(1468324)
        $asm.$str(`$uUnI.LCIECM.EnergyMeterDeviceFlags`, ($self) => class EnergyMeterDeviceFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static LogAvailability = 1;
            static LogUsage = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1468324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "LogAvailability": 1n,
                    "LogUsage": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296435620)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296435620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296435620)
            
            //--TRIMMABLE-BOUNDARY-START(4296435620)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296435620)
            
            static $h = 1468324;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181337508),
    {
      "t": 1468324,
      "n": "None",
      "d": 1468324,
      "h": 17181337508,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181337508),
//--TRIMMABLE-BOUNDARY-START(8591402916),
    {
      "t": 1468324,
      "n": "LogAvailability",
      "d": 1468324,
      "h": 8591402916,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591402916),
//--TRIMMABLE-BOUNDARY-START(12886370212),
    {
      "t": 1468324,
      "n": "LogUsage",
      "d": 1468324,
      "h": 12886370212,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886370212)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296435620),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1468324,
      "h": 4296435620,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296435620)
  ],
  "h": 1468324,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1468324)
        
        

        //--TRIMMABLE-BOUNDARY-START(3827620)
        $asm.$str(`$uUnI.LCIECM.EnergyPhase`, ($self) => class EnergyPhase extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Red = 1;
            static Blue = 2;
            static Yellow = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3827620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Red": 1n,
                    "Blue": 2n,
                    "Yellow": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298794916)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298794916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298794916)
            
            //--TRIMMABLE-BOUNDARY-START(4298794916)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298794916)
            
            static $h = 3827620;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12888729508),
    {
      "t": 3827620,
      "n": "None",
      "d": 3827620,
      "h": 12888729508,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888729508),
//--TRIMMABLE-BOUNDARY-START(17183696804),
    {
      "t": 3827620,
      "n": "Red",
      "d": 3827620,
      "h": 17183696804,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183696804),
//--TRIMMABLE-BOUNDARY-START(8593762212),
    {
      "t": 3827620,
      "n": "Blue",
      "d": 3827620,
      "h": 8593762212,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593762212),
//--TRIMMABLE-BOUNDARY-START(21478664100),
    {
      "t": 3827620,
      "n": "Yellow",
      "d": 3827620,
      "h": 21478664100,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21478664100)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298794916),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3827620,
      "h": 4298794916,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298794916)
  ],
  "h": 3827620,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyPhase`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyPhase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3827620)
        
        

        //--TRIMMABLE-BOUNDARY-START(3237796)
        $asm.$str(`$uUnI.LCIECM.EnergyMeterServiceFeatureType`, ($self) => class EnergyMeterServiceFeatureType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3237796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298205092)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298205092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298205092)
            
            //--TRIMMABLE-BOUNDARY-START(4298205092)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298205092)
            
            static $h = 3237796;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8593172388),
    {
      "t": 3237796,
      "n": "None",
      "d": 3237796,
      "h": 8593172388,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593172388)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298205092),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3237796,
      "h": 4298205092,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298205092)
  ],
  "h": 3237796
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceFeatureType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterServiceFeatureType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3237796)
        
        

        //--TRIMMABLE-BOUNDARY-START(1599396)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceLogModel`, ($self) => class EnergyMeterDeviceLogModel extends $.$uUnI.LCIECM.EnergyMeterReceivedStatus
        {
            //--TRIMMABLE-BOUNDARY-START(55836174244)
            /*int*/ Type = 0;
            //--TRIMMABLE-BOUNDARY-END(55836174244)
            
            //--TRIMMABLE-BOUNDARY-START(17181468580)
            /*DateTime*/ Date;
            //--TRIMMABLE-BOUNDARY-END(17181468580)
            
            //--TRIMMABLE-BOUNDARY-START(12886501284)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886501284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886501284)
            
            //--TRIMMABLE-BOUNDARY-START(12886501284)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12886501284)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17181468580)
                this.Date = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(17181468580)
                
            }
            static $h = 1599396;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uUnI.LCIECM.EnergyMeterReceivedStatus; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836174244),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361337764,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51541206948,
        "f": 83886081
      },
      "n": "Type",
      "d": 1599396,
      "h": 55836174244,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836174244),
//--TRIMMABLE-BOUNDARY-START(17181468580),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771403172,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42951272356,
        "f": 83886081
      },
      "n": "Date",
      "d": 1599396,
      "h": 17181468580,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181468580)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886501284),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1599396,
      "h": 12886501284,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886501284)
  ],
  "h": 1599396
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder, $.$fPer.LCFCDM.IBackedUpThreePhasePower ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceLogModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceLogModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1599396)
        
        

        //--TRIMMABLE-BOUNDARY-START(4220836)
        $asm.$cls(`$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor`, ($self) => class EnergyMeterDeviceDashboardModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299188132)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299188132);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor.GenerateProperties($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel, this, factory);
                    }, $ArcLFc ??= {"r":65537,"n":"","d":4220836,"h":0,"f":17825794}), 0, "EnergyMeterDeviceDashboardModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\Processings_EnergyMeterDeviceDashboardBuilder_LivingThing.Core.IOT.EnergyMeter.Common.Processings.EnergyMeterDeviceDashboardModelTypeDescriptorBuilder.g.cs", "EnergyMeterDeviceDashboardModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299188132)
            
            //--TRIMMABLE-BOUNDARY-START(12889122724)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889122724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TotalRuntime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel.$type, $.$discardRef(), "TotalRuntime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TotalRuntime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "TotalRuntime";
                        $i1.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Processings.EnergyMeterDeviceDashboardModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel)).TotalRuntime);
                        }, $cKrYok ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4220836,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.TotalRuntime = value.AsInt();
                        }, $OYxjic ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4220836,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PowerCuts"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel.$type, $.$discardRef(), "PowerCuts", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PowerCuts")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "PowerCuts";
                        $i3.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Processings.EnergyMeterDeviceDashboardModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel)).PowerCuts);
                        }, $miZjHh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4220836,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PowerCuts = value.AsInt();
                        }, $XAowsj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4220836,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PeakVoltage"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel.$type, $.$discardRef(), "PeakVoltage", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PeakVoltage")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "PeakVoltage";
                        $i5.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Processings.EnergyMeterDeviceDashboardModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel)).PeakVoltage);
                        }, $oIFYoh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4220836,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PeakVoltage = value.AsDouble();
                        }, $TzHrXi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4220836,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PeakCurrent"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel.$type, $.$discardRef(), "PeakCurrent", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PeakCurrent")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "PeakCurrent";
                        $i7.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Processings.EnergyMeterDeviceDashboardModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel)).PeakCurrent);
                        }, $lwhtub ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4220836,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.PeakCurrent = value.AsDouble();
                        }, $wofDvh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4220836,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PeakPower"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel.$type, $.$discardRef(), "PeakPower", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PeakPower")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "PeakPower";
                        $i9.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Processings.EnergyMeterDeviceDashboardModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel)).PeakPower);
                        }, $YxOxZk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4220836,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PeakPower = value.AsDouble();
                        }, $JnkhNe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4220836,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("EnergyUsage"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel.$type, $.$discardRef(), "EnergyUsage", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("EnergyUsage")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "EnergyUsage";
                        $i11.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Processings.EnergyMeterDeviceDashboardModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel)).EnergyUsage);
                        }, $iusNRi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4220836,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.EnergyUsage = value.AsDouble();
                        }, $Cpthgk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4220836,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12889122724)
            
            //--TRIMMABLE-BOUNDARY-START(17184090020)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Processings.EnergyMeterDeviceDashboardModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184090020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _TotalRuntime = _target.TotalRuntime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TotalRuntime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _TotalRuntime, ($v) => _TotalRuntime = $v, $.$$.S.Int32)))
                    {
                        _target.TotalRuntime = _TotalRuntime;
                    }
                }
                {
                    /*var*/ let _PowerCuts = _target.PowerCuts;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PowerCuts"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _PowerCuts, ($v) => _PowerCuts = $v, $.$$.S.Int32)))
                    {
                        _target.PowerCuts = _PowerCuts;
                    }
                }
                {
                    /*var*/ let _PeakVoltage = _target.PeakVoltage;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PeakVoltage"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _PeakVoltage, ($v) => _PeakVoltage = $v, $.$$.S.Double)))
                    {
                        _target.PeakVoltage = _PeakVoltage;
                    }
                }
                {
                    /*var*/ let _PeakCurrent = _target.PeakCurrent;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PeakCurrent"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _PeakCurrent, ($v) => _PeakCurrent = $v, $.$$.S.Double)))
                    {
                        _target.PeakCurrent = _PeakCurrent;
                    }
                }
                {
                    /*var*/ let _PeakPower = _target.PeakPower;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PeakPower"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _PeakPower, ($v) => _PeakPower = $v, $.$$.S.Double)))
                    {
                        _target.PeakPower = _PeakPower;
                    }
                }
                {
                    /*var*/ let _EnergyUsage = _target.EnergyUsage;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("EnergyUsage"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _EnergyUsage, ($v) => _EnergyUsage = $v, $.$$.S.Double)))
                    {
                        _target.EnergyUsage = _EnergyUsage;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184090020)
            
            //--TRIMMABLE-BOUNDARY-START(8594155428)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Processings.EnergyMeterDeviceDashboardModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594155428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel)))
                {
                    /*var*/ let result = $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594155428)
            
            static $h = 4220836;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889122724),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4220836,
      "h": 12889122724,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889122724),
//--TRIMMABLE-BOUNDARY-START(17184090020),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4089764,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4220836,
      "h": 17184090020,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184090020),
//--TRIMMABLE-BOUNDARY-START(8594155428),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4089764,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4220836,
      "h": 8594155428,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594155428)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299188132),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4220836,
      "h": 4299188132,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299188132)
  ],
  "h": 4220836
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Processings.EnergyMeterDeviceDashboardModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Processings${separator}EnergyMeterDeviceDashboardModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4220836)
        
        

        //--TRIMMABLE-BOUNDARY-START(1337252)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor`, ($self) => class EnergyMeterDeviceDataClassificationModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296304548)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296304548);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor.GenerateProperties($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, this, factory);
                    }, $YILTlh ??= {"r":65537,"n":"","d":1337252,"h":0,"f":17825794}), 0, "EnergyMeterDeviceDataClassificationModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\Models_EnergyMeterDeviceDataClassificationModel_LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModelTypeDescriptorBuilder.g.cs", "EnergyMeterDeviceDataClassificationModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296304548)
            
            //--TRIMMABLE-BOUNDARY-START(12886239140)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886239140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Runtime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel.$type, $.$discardRef(), "Runtime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Runtime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Runtime";
                        $i1.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)).Runtime);
                        }, $AIEkab ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337252,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Runtime = value.AsInt();
                        }, $LtBUne ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1337252,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PowerCuts"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel.$type, $.$discardRef(), "PowerCuts", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PowerCuts")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "PowerCuts";
                        $i3.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)).PowerCuts);
                        }, $tDoaTc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337252,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PowerCuts = value.AsInt();
                        }, $VqDNLb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1337252,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("RedEnergy"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel.$type, $.$discardRef(), "RedEnergy", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("RedEnergy")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "RedEnergy";
                        $i5.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)).RedEnergy);
                        }, $YpJJwf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337252,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.RedEnergy = value.AsDouble();
                        }, $obYAmf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1337252,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BlueEnergy"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel.$type, $.$discardRef(), "BlueEnergy", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BlueEnergy")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "BlueEnergy";
                        $i7.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)).BlueEnergy);
                        }, $tnMoQc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337252,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.BlueEnergy = value.AsDouble();
                        }, $dbFJec ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1337252,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("YellowEnergy"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel.$type, $.$discardRef(), "YellowEnergy", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("YellowEnergy")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "YellowEnergy";
                        $i9.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)).YellowEnergy);
                        }, $notVpj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337252,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.YellowEnergy = value.AsDouble();
                        }, $NZpUdf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1337252,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TotalEnergy"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel.$type, $.$discardRef(), "TotalEnergy", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TotalEnergy")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "TotalEnergy";
                        $i11.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)).TotalEnergy);
                        }, $VVaJwb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337252,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PeakPower"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel.$type, $.$discardRef(), "PeakPower", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PeakPower")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "PeakPower";
                        $i13.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)).PeakPower);
                        }, $HjbVHe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337252,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.PeakPower = value.AsDouble();
                        }, $nVNYae ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1337252,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ChartX"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel.$type, $.$discardRef(), "ChartX", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ChartX")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "ChartX";
                        $i15.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)).ChartX);
                        }, $jrvUJd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337252,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICP.BaseDeviceDataClassificationModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886239140)
            
            //--TRIMMABLE-BOUNDARY-START(17181206436)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181206436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Processings.BaseDeviceDataClassificationModel?*/ let targetBase = _target;
                $.$XBGm.LCICP.BaseDeviceDataClassificationModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICP.BaseDeviceDataClassificationModel));
                {
                    /*var*/ let _Runtime = _target.Runtime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Runtime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Runtime, ($v) => _Runtime = $v, $.$$.S.Int32)))
                    {
                        _target.Runtime = _Runtime;
                    }
                }
                {
                    /*var*/ let _PowerCuts = _target.PowerCuts;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PowerCuts"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _PowerCuts, ($v) => _PowerCuts = $v, $.$$.S.Int32)))
                    {
                        _target.PowerCuts = _PowerCuts;
                    }
                }
                {
                    /*var*/ let _RedEnergy = _target.RedEnergy;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("RedEnergy"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _RedEnergy, ($v) => _RedEnergy = $v, $.$$.S.Double)))
                    {
                        _target.RedEnergy = _RedEnergy;
                    }
                }
                {
                    /*var*/ let _BlueEnergy = _target.BlueEnergy;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BlueEnergy"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _BlueEnergy, ($v) => _BlueEnergy = $v, $.$$.S.Double)))
                    {
                        _target.BlueEnergy = _BlueEnergy;
                    }
                }
                {
                    /*var*/ let _YellowEnergy = _target.YellowEnergy;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("YellowEnergy"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _YellowEnergy, ($v) => _YellowEnergy = $v, $.$$.S.Double)))
                    {
                        _target.YellowEnergy = _YellowEnergy;
                    }
                }
                {
                    /*var*/ let _TotalEnergy = _target.TotalEnergy;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TotalEnergy"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _TotalEnergy, ($v) => _TotalEnergy = $v, $.$$.S.Double)))
                    {
                    }
                }
                {
                    /*var*/ let _PeakPower = _target.PeakPower;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PeakPower"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _PeakPower, ($v) => _PeakPower = $v, $.$$.S.Double)))
                    {
                        _target.PeakPower = _PeakPower;
                    }
                }
                {
                    /*var*/ let _ChartX = _target.ChartX;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ChartX"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ChartX, ($v) => _ChartX = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181206436)
            
            //--TRIMMABLE-BOUNDARY-START(8591271844)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591271844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)))
                {
                    /*var*/ let result = $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591271844)
            
            static $h = 1337252;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886239140),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1337252,
      "h": 12886239140,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886239140),
//--TRIMMABLE-BOUNDARY-START(17181206436),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1206180,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1337252,
      "h": 17181206436,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181206436),
//--TRIMMABLE-BOUNDARY-START(8591271844),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1206180,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1337252,
      "h": 8591271844,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591271844)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296304548),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1337252,
      "h": 4296304548,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296304548)
  ],
  "h": 1337252
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceDataClassificationModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1337252)
        
        

        //--TRIMMABLE-BOUNDARY-START(4745124)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettings`, ($self) => class EnergyMeterDashboardGlobalSettings extends $.$XBGm.LCICS$2.IOTDashboardGlobalSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4299712420)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299712420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299712420)
            
            //--TRIMMABLE-BOUNDARY-START(4299712420)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4299712420)
            
            static $h = 4745124;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$2.IOTDashboardGlobalSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299712420),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4745124,
      "h": 4299712420,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299712420)
  ],
  "h": 4745124
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IGlobalSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDashboardGlobalSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDashboardGlobalSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4745124)
        
        

        //--TRIMMABLE-BOUNDARY-START(5007268)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings`, ($self) => class EnergyMeterDeviceGlobalSettings extends $.$XBGm.LCICS$2.IOTDeviceGlobalSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4299974564)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299974564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299974564)
            
            //--TRIMMABLE-BOUNDARY-START(4299974564)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4299974564)
            
            static $h = 5007268;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$2.IOTDeviceGlobalSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299974564),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 5007268,
      "h": 4299974564,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299974564)
  ],
  "h": 5007268
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IGlobalSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceGlobalSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDeviceGlobalSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5007268)
        
        

        //--TRIMMABLE-BOUNDARY-START(6317988)
        $asm.$cls(`$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates`, ($self) => class EnergyMeterDeviceScopeStates extends $.$XBGm.LCICS$3.IOTDeviceScopeStates
        {
            //--TRIMMABLE-BOUNDARY-START(4301285284)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301285284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301285284)
            
            //--TRIMMABLE-BOUNDARY-START(4301285284)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4301285284)
            
            static $h = 6317988;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$3.IOTDeviceScopeStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301285284),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 6317988,
      "h": 4301285284,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301285284)
  ],
  "h": 6317988
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceScopeStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}States${separator}EnergyMeterDeviceScopeStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6317988)
        
        

        //--TRIMMABLE-BOUNDARY-START(6580132)
        $asm.$cls(`$uUnI.LCIECS$2.EnergyMeterDeviceStates`, ($self) => class EnergyMeterDeviceStates extends $.$XBGm.LCICS$3.IOTDeviceStates
        {
            //--TRIMMABLE-BOUNDARY-START(4301547428)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301547428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301547428)
            
            //--TRIMMABLE-BOUNDARY-START(4301547428)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4301547428)
            
            static $h = 6580132;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$3.IOTDeviceStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301547428),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 6580132,
      "h": 4301547428,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301547428)
  ],
  "h": 6580132
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}States${separator}EnergyMeterDeviceStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6580132)
        
        

        //--TRIMMABLE-BOUNDARY-START(5531556)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings`, ($self) => class EnergyMeterDeviceScopeSettings extends $.$XBGm.LCICS$2.IOTDeviceScopeSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4300498852)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300498852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300498852)
            
            //--TRIMMABLE-BOUNDARY-START(4300498852)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4300498852)
            
            static $h = 5531556;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$2.IOTDeviceScopeSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300498852),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 5531556,
      "h": 4300498852,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300498852)
  ],
  "h": 5531556
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICS$2.IIOTDeviceScopeSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceScopeSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDeviceScopeSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5531556)
        
        

        //--TRIMMABLE-BOUNDARY-START(944036)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceCommandModel`, ($self) => class EnergyMeterDeviceCommandModel extends $.$XBGm.LCICM.IOTDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295911332)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295911332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295911332)
            
            //--TRIMMABLE-BOUNDARY-START(4295911332)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295911332)
            
            static $h = 944036;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICM.IOTDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295911332),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 944036,
      "h": 4295911332,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295911332)
  ],
  "h": 944036
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceCommandModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceCommandModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(944036)
        
        

        //--TRIMMABLE-BOUNDARY-START(2910116)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceStatusModel`, ($self) => class EnergyMeterDeviceStatusModel extends $.$XBGm.LCICM.IOTDeviceStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(25772713892)
            /*EnergyPhase?*/ AvailablePhase = null;
            //--TRIMMABLE-BOUNDARY-END(25772713892)
            
            //--TRIMMABLE-BOUNDARY-START(107377092516)
            /*PowerPhase?*/ Red = null;
            //--TRIMMABLE-BOUNDARY-END(107377092516)
            
            //--TRIMMABLE-BOUNDARY-START(146031798180)
            /*PowerPhase?*/ Yellow = null;
            //--TRIMMABLE-BOUNDARY-END(146031798180)
            
            //--TRIMMABLE-BOUNDARY-START(30067681188)
            /*PowerPhase?*/ Blue = null;
            //--TRIMMABLE-BOUNDARY-END(30067681188)
            
            //--TRIMMABLE-BOUNDARY-START(38657615780)
            /*double */ get Current()
            {
                return ((this.Red?.Current ?? null) ?? 0) + ((this.Yellow?.Current ?? null) ?? 0) + ((this.Blue?.Current ?? null) ?? 0);
            }
            //--TRIMMABLE-BOUNDARY-END(38657615780)
            
            //--TRIMMABLE-BOUNDARY-START(103082125220)
            /*double */ get Power()
            {
                return ((this.Red?.Power ?? null) ?? 0) + ((this.Yellow?.Power ?? null) ?? 0) + ((this.Blue?.Power ?? null) ?? 0);
            }
            //--TRIMMABLE-BOUNDARY-END(103082125220)
            
            //--TRIMMABLE-BOUNDARY-START(34362648484)
            /*double */ get ConsumedEnergy()
            {
                return ((this.Red?.Energy ?? null) ?? 0) + ((this.Yellow?.Energy ?? null) ?? 0) + ((this.Blue?.Energy ?? null) ?? 0);
            }
            //--TRIMMABLE-BOUNDARY-END(34362648484)
            
            //--TRIMMABLE-BOUNDARY-START(21477746596)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477746596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477746596)
            
            //--TRIMMABLE-BOUNDARY-START(21477746596)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(21477746596)
            
            static $h = 2910116;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICM.IOTDeviceStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772713892),
    {
      "p": $.$typeNullable($.$uUnI.LCIECM.EnergyPhase).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247550372,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115967027108,
        "f": 83886081
      },
      "n": "AvailablePhase",
      "d": 2910116,
      "h": 25772713892,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1024,
              "t": 655361
            },
            {
              "n": "ExcludeFilter",
              "v": 3958692,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25772713892),
//--TRIMMABLE-BOUNDARY-START(107377092516),
    {
      "p": 32871825,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90197223332,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133146896292,
        "f": 83886081
      },
      "n": "Red",
      "d": 2910116,
      "h": 107377092516,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1025,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107377092516),
//--TRIMMABLE-BOUNDARY-START(146031798180),
    {
      "p": 32871825,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98787157924,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141736830884,
        "f": 83886081
      },
      "n": "Yellow",
      "d": 2910116,
      "h": 146031798180,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1026,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146031798180),
//--TRIMMABLE-BOUNDARY-START(30067681188),
    {
      "p": 32871825,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837484964,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124556961700,
        "f": 83886081
      },
      "n": "Blue",
      "d": 2910116,
      "h": 30067681188,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1027,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30067681188),
//--TRIMMABLE-BOUNDARY-START(38657615780),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73017354148,
        "f": 50331649
      },
      "n": "Current",
      "d": 2910116,
      "h": 38657615780,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1038,
              "t": 655361
            },
            {
              "n": "ExcludeFilter",
              "v": 3958692,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38657615780),
//--TRIMMABLE-BOUNDARY-START(103082125220),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81607288740,
        "f": 50331649
      },
      "n": "Power",
      "d": 2910116,
      "h": 103082125220,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1039,
              "t": 655361
            },
            {
              "n": "ExcludeFilter",
              "v": 3958692,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103082125220),
//--TRIMMABLE-BOUNDARY-START(34362648484),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427419556,
        "f": 50331649
      },
      "n": "ConsumedEnergy",
      "d": 2910116,
      "h": 34362648484,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1040,
              "t": 655361
            },
            {
              "n": "ExcludeFilter",
              "v": 3958692,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34362648484)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477746596),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2910116,
      "h": 21477746596,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477746596)
  ],
  "h": 2910116
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2910116)
        
        

        //--TRIMMABLE-BOUNDARY-START(1730468)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceLogModelTypeDescriptor`, ($self) => class EnergyMeterDeviceLogModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296697764)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296697764);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECM.EnergyMeterDeviceLogModelTypeDescriptor.GenerateProperties($.$uUnI.LCIECM.EnergyMeterDeviceLogModel, this, factory);
                    }, $qDaccl ??= {"r":65537,"n":"","d":1730468,"h":0,"f":17825794}), 0, "EnergyMeterDeviceLogModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\Models_EnergyMeterDeviceReceivedDataModel_LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceLogModelTypeDescriptorBuilder.g.cs", "EnergyMeterDeviceLogModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296697764)
            
            //--TRIMMABLE-BOUNDARY-START(12886632356)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886632356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceLogModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceLogModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceLogModel)).Type);
                        }, $zLePFk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1730468,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceLogModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Type = value.AsInt();
                        }, $zmIEud ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1730468,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Date"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceLogModel.$type, $.$discardRef(), "Date", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Date")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Date";
                        $i3.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceLogModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceLogModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceLogModel)).Date);
                        }, $QnMAhh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1730468,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceLogModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Date = value.AsDateTime();
                        }, $SwJIwd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1730468,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886632356)
            
            //--TRIMMABLE-BOUNDARY-START(17181599652)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceLogModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181599652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Type, ($v) => _Type = $v, $.$$.S.Int32)))
                    {
                        _target.Type = _Type;
                    }
                }
                {
                    /*var*/ let _Date = _target.Date;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Date"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _Date, ($v) => _Date = $v, null, true)))
                    {
                        _target.Date = _Date;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181599652)
            
            //--TRIMMABLE-BOUNDARY-START(8591665060)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceLogModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591665060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECM.EnergyMeterDeviceLogModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECM.EnergyMeterDeviceLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceLogModel)))
                {
                    /*var*/ let result = $.$uUnI.LCIECM.EnergyMeterDeviceLogModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceLogModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECM.EnergyMeterDeviceLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceLogModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591665060)
            
            static $h = 1730468;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886632356),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1730468,
      "h": 12886632356,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886632356),
//--TRIMMABLE-BOUNDARY-START(17181599652),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1599396,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1730468,
      "h": 17181599652,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181599652),
//--TRIMMABLE-BOUNDARY-START(8591665060),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1599396,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1730468,
      "h": 8591665060,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591665060)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296697764),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1730468,
      "h": 4296697764,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296697764)
  ],
  "h": 1730468
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceLogModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceLogModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceLogModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1730468)
        
        

        //--TRIMMABLE-BOUNDARY-START(6055844)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterServiceSettings`, ($self) => class EnergyMeterServiceSettings extends $.$XBGm.LCICS$2.IOTServiceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4301023140)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301023140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301023140)
            
            //--TRIMMABLE-BOUNDARY-START(4301023140)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4301023140)
            
            static $h = 6055844;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$2.IOTServiceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301023140),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6055844,
      "h": 4301023140,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301023140)
  ],
  "h": 6055844
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterServiceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterServiceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6055844)
        
        

        //--TRIMMABLE-BOUNDARY-START(6842276)
        $asm.$cls(`$uUnI.LCIECS$2.EnergyMeterServiceStates`, ($self) => class EnergyMeterServiceStates extends $.$XBGm.LCICS$3.IOTServiceStates
        {
            //--TRIMMABLE-BOUNDARY-START(4301809572)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301809572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301809572)
            
            //--TRIMMABLE-BOUNDARY-START(4301809572)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4301809572)
            
            static $h = 6842276;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICS$3.IOTServiceStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301809572),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6842276,
      "h": 4301809572,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301809572)
  ],
  "h": 6842276
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterServiceStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}States${separator}EnergyMeterServiceStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6842276)
        
        

        //--TRIMMABLE-BOUNDARY-START(5138340)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettingsTypeDescriptor`, ($self) => class EnergyMeterDeviceGlobalSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4300105636)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300105636);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettingsTypeDescriptor.GenerateProperties($.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings, this, factory);
                    }, $fnTdHb ??= {"r":65537,"n":"","d":5138340,"h":0,"f":17825794}), 0, "EnergyMeterDeviceGlobalSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\Settings_EnergyMeterDeviceGlobalSettings_LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceGlobalSettingsTypeDescriptorBuilder.g.cs", "EnergyMeterDeviceGlobalSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300105636)
            
            //--TRIMMABLE-BOUNDARY-START(12890040228)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890040228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$2.IOTDeviceGlobalSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890040228)
            
            //--TRIMMABLE-BOUNDARY-START(17185007524)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceGlobalSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185007524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Settings.IOTDeviceGlobalSettings?*/ let targetBase = _target;
                $.$XBGm.LCICS$2.IOTDeviceGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185007524)
            
            //--TRIMMABLE-BOUNDARY-START(8595072932)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceGlobalSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595072932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings)))
                {
                    /*var*/ let result = $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595072932)
            
            static $h = 5138340;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890040228),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5138340,
      "h": 12890040228,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890040228),
//--TRIMMABLE-BOUNDARY-START(17185007524),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5007268,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5138340,
      "h": 17185007524,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185007524),
//--TRIMMABLE-BOUNDARY-START(8595072932),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5007268,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5138340,
      "h": 8595072932,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595072932)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300105636),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5138340,
      "h": 4300105636,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300105636)
  ],
  "h": 5138340
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceGlobalSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDeviceGlobalSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5138340)
        
        

        //--TRIMMABLE-BOUNDARY-START(4876196)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettingsTypeDescriptor`, ($self) => class EnergyMeterDashboardGlobalSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299843492)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299843492);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettingsTypeDescriptor.GenerateProperties($.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettings, this, factory);
                    }, $boiUTa ??= {"r":65537,"n":"","d":4876196,"h":0,"f":17825794}), 0, "EnergyMeterDashboardGlobalSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\Settings_EnergyMeterDashboardGlobalSettings_LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDashboardGlobalSettingsTypeDescriptorBuilder.g.cs", "EnergyMeterDashboardGlobalSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299843492)
            
            //--TRIMMABLE-BOUNDARY-START(12889778084)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889778084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$2.IOTDashboardGlobalSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889778084)
            
            //--TRIMMABLE-BOUNDARY-START(17184745380)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDashboardGlobalSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184745380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Settings.IOTDashboardGlobalSettings?*/ let targetBase = _target;
                $.$XBGm.LCICS$2.IOTDashboardGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$2.IOTDashboardGlobalSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184745380)
            
            //--TRIMMABLE-BOUNDARY-START(8594810788)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDashboardGlobalSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594810788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettings)))
                {
                    /*var*/ let result = $.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594810788)
            
            static $h = 4876196;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889778084),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4876196,
      "h": 12889778084,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889778084),
//--TRIMMABLE-BOUNDARY-START(17184745380),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4745124,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4876196,
      "h": 17184745380,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184745380),
//--TRIMMABLE-BOUNDARY-START(8594810788),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4745124,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4876196,
      "h": 8594810788,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594810788)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299843492),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4876196,
      "h": 4299843492,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299843492)
  ],
  "h": 4876196
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterDashboardGlobalSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDashboardGlobalSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDashboardGlobalSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4876196)
        
        

        //--TRIMMABLE-BOUNDARY-START(6449060)
        $asm.$cls(`$uUnI.LCIECS$2.EnergyMeterDeviceScopeStatesTypeDescriptor`, ($self) => class EnergyMeterDeviceScopeStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4301416356)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301416356);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStatesTypeDescriptor.GenerateProperties($.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, this, factory);
                    }, $pbfeGe ??= {"r":65537,"n":"","d":6449060,"h":0,"f":17825794}), 0, "EnergyMeterDeviceScopeStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\States_EnergyMeterDeviceScopeStates_LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceScopeStatesTypeDescriptorBuilder.g.cs", "EnergyMeterDeviceScopeStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301416356)
            
            //--TRIMMABLE-BOUNDARY-START(12891350948)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891350948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$3.IOTDeviceScopeStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12891350948)
            
            //--TRIMMABLE-BOUNDARY-START(17186318244)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceScopeStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17186318244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates?*/ let targetBase = _target;
                $.$XBGm.LCICS$3.IOTDeviceScopeStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$3.IOTDeviceScopeStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17186318244)
            
            //--TRIMMABLE-BOUNDARY-START(8596383652)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceScopeStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596383652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates)))
                {
                    /*var*/ let result = $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8596383652)
            
            static $h = 6449060;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12891350948),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 6449060,
      "h": 12891350948,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12891350948),
//--TRIMMABLE-BOUNDARY-START(17186318244),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6317988,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 6449060,
      "h": 17186318244,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17186318244),
//--TRIMMABLE-BOUNDARY-START(8596383652),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6317988,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 6449060,
      "h": 8596383652,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8596383652)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301416356),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6449060,
      "h": 4301416356,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301416356)
  ],
  "h": 6449060
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceScopeStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}States${separator}EnergyMeterDeviceScopeStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6449060)
        
        

        //--TRIMMABLE-BOUNDARY-START(6711204)
        $asm.$cls(`$uUnI.LCIECS$2.EnergyMeterDeviceStatesTypeDescriptor`, ($self) => class EnergyMeterDeviceStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$2.EnergyMeterDeviceStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4301678500)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301678500);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECS$2.EnergyMeterDeviceStatesTypeDescriptor.GenerateProperties($.$uUnI.LCIECS$2.EnergyMeterDeviceStates, this, factory);
                    }, $irXEje ??= {"r":65537,"n":"","d":6711204,"h":0,"f":17825794}), 0, "EnergyMeterDeviceStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\States_EnergyMeterDeviceStates_LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceStatesTypeDescriptorBuilder.g.cs", "EnergyMeterDeviceStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301678500)
            
            //--TRIMMABLE-BOUNDARY-START(12891613092)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891613092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$3.IOTDeviceStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12891613092)
            
            //--TRIMMABLE-BOUNDARY-START(17186580388)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17186580388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.States.IOTDeviceStates?*/ let targetBase = _target;
                $.$XBGm.LCICS$3.IOTDeviceStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$3.IOTDeviceStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17186580388)
            
            //--TRIMMABLE-BOUNDARY-START(8596645796)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596645796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECS$2.EnergyMeterDeviceStates().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates)))
                {
                    /*var*/ let result = $.$uUnI.LCIECS$2.EnergyMeterDeviceStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8596645796)
            
            static $h = 6711204;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$2.EnergyMeterDeviceStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12891613092),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 6711204,
      "h": 12891613092,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12891613092),
//--TRIMMABLE-BOUNDARY-START(17186580388),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6580132,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 6711204,
      "h": 17186580388,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17186580388),
//--TRIMMABLE-BOUNDARY-START(8596645796),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6580132,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 6711204,
      "h": 8596645796,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8596645796)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301678500),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6711204,
      "h": 4301678500,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301678500)
  ],
  "h": 6711204
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECS$2.EnergyMeterDeviceStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}States${separator}EnergyMeterDeviceStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6711204)
        
        

        //--TRIMMABLE-BOUNDARY-START(5662628)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettingsTypeDescriptor`, ($self) => class EnergyMeterDeviceScopeSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4300629924)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300629924);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettingsTypeDescriptor.GenerateProperties($.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, this, factory);
                    }, $rmJXCa ??= {"r":65537,"n":"","d":5662628,"h":0,"f":17825794}), 0, "EnergyMeterDeviceScopeSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\Settings_EnergyMeterDeviceScopeSettings_LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceScopeSettingsTypeDescriptorBuilder.g.cs", "EnergyMeterDeviceScopeSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300629924)
            
            //--TRIMMABLE-BOUNDARY-START(12890564516)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890564516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$2.IOTDeviceScopeSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890564516)
            
            //--TRIMMABLE-BOUNDARY-START(17185531812)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceScopeSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185531812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings?*/ let targetBase = _target;
                $.$XBGm.LCICS$2.IOTDeviceScopeSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$2.IOTDeviceScopeSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185531812)
            
            //--TRIMMABLE-BOUNDARY-START(8595597220)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceScopeSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595597220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings)))
                {
                    /*var*/ let result = $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595597220)
            
            static $h = 5662628;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890564516),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5662628,
      "h": 12890564516,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890564516),
//--TRIMMABLE-BOUNDARY-START(17185531812),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5531556,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5662628,
      "h": 17185531812,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185531812),
//--TRIMMABLE-BOUNDARY-START(8595597220),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5531556,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5662628,
      "h": 8595597220,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595597220)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300629924),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5662628,
      "h": 4300629924,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300629924)
  ],
  "h": 5662628
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceScopeSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDeviceScopeSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5662628)
        
        

        //--TRIMMABLE-BOUNDARY-START(1075108)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceCommandModelTypeDescriptor`, ($self) => class EnergyMeterDeviceCommandModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceCommandModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296042404)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296042404);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECM.EnergyMeterDeviceCommandModelTypeDescriptor.GenerateProperties($.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, this, factory);
                    }, $vThvla ??= {"r":65537,"n":"","d":1075108,"h":0,"f":17825794}), 0, "EnergyMeterDeviceCommandModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\Models_EnergyMeterDeviceCommandModel_LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceCommandModelTypeDescriptorBuilder.g.cs", "EnergyMeterDeviceCommandModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296042404)
            
            //--TRIMMABLE-BOUNDARY-START(12885976996)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885976996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICM.IOTDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885976996)
            
            //--TRIMMABLE-BOUNDARY-START(17180944292)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceCommandModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180944292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICM.IOTDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICM.IOTDeviceCommandModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180944292)
            
            //--TRIMMABLE-BOUNDARY-START(8591009700)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceCommandModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591009700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel)))
                {
                    /*var*/ let result = $.$uUnI.LCIECM.EnergyMeterDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591009700)
            
            static $h = 1075108;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceCommandModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885976996),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1075108,
      "h": 12885976996,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885976996),
//--TRIMMABLE-BOUNDARY-START(17180944292),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 944036,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1075108,
      "h": 17180944292,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180944292),
//--TRIMMABLE-BOUNDARY-START(8591009700),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 944036,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1075108,
      "h": 8591009700,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591009700)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296042404),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1075108,
      "h": 4296042404,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296042404)
  ],
  "h": 1075108
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceCommandModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceCommandModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceCommandModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1075108)
        
        

        //--TRIMMABLE-BOUNDARY-START(4024228)
        $asm.$cls(`$uUnI.LCIECP.EnergyMeterDeviceDashboardBuilder`, ($self) => class EnergyMeterDeviceDashboardBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593958820)
            /*object */ BuildDashboardModel(/*IIOTDeviceModel*/ device, /*IEnumerable<EnergyMeterDeviceStatusModel>*/ data, /*Dictionary<PeriodicInterval, IEnumerable<EnergyMeterDeviceDataClassificationModel>>*/ classifications)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593958820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let allPhases = $.$sl.SL.Enumerable.SelectMany$2($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$XBGm.LCICMGP.PowerPhase, data, new ($.$$.S.Func$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$$.SCG.IEnumerable$$($.$XBGm.LCICMGP.PowerPhase)))().$ctor(this,  (/*d*/ d) =>
                {
                    return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICMGP.PowerPhase), [d.Red, d.Yellow, d.Blue], null, null);
                }, $rwzhlb ??= {"r":$.$$.SCG.IEnumerable$$($.$XBGm.LCICMGP.PowerPhase).$h,"p":[{"n":"d","p":2910116}],"n":"","d":4024228,"h":0,"f":17825794}));
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel>*/ let __ca1__;
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel>*/ let __ca2__;
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel>*/ let __ca3__;
                return (() =>
                {
                    //new $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel()
                    const $t1 = $.$uUnI.LCIECP.EnergyMeterDeviceDashboardModel;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.TotalRuntime = ((__ca1__ = $.$sl.SL.Enumerable.LastOrDefault$3($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCDC.PeriodicInterval, $.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)), classifications).Value) !== null ? $.$sl.SL.Enumerable.Sum$17($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, __ca1__, new ($.$$.S.Func$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$$.S.Int32))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t.Runtime;
                    }, $OePANh ??= {"r":655361,"p":[{"n":"t","p":1206180}],"n":"","d":4024228,"h":0,"f":17825794})) : 0);
                    $i1.PowerCuts = ((__ca2__ = $.$sl.SL.Enumerable.LastOrDefault$3($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCDC.PeriodicInterval, $.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)), classifications).Value) !== null ? $.$sl.SL.Enumerable.Sum$17($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, __ca2__, new ($.$$.S.Func$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$$.S.Int32))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t.PowerCuts;
                    }, $eYfQkc ??= {"r":655361,"p":[{"n":"t","p":1206180}],"n":"","d":4024228,"h":0,"f":17825794})) : 0);
                    $i1.EnergyUsage = ((__ca3__ = $.$sl.SL.Enumerable.LastOrDefault$3($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCDC.PeriodicInterval, $.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)), classifications).Value) !== null ? $.$sl.SL.Enumerable.Sum$16($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, __ca3__, new ($.$$.S.Func$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$$.S.Double))().$ctor(this,  (/**/ t) =>
                    {
                        return t.TotalEnergy;
                    }, $SXHMaj ??= {"r":1179649,"p":[{"n":"t","p":1206180}],"n":"","d":4024228,"h":0,"f":17825794})) : 0);
                    $i1.PeakVoltage = $.$sl.SL.Enumerable.Any$1($.$XBGm.LCICMGP.PowerPhase, allPhases) ? $.$sl.SL.Enumerable.Max$13($.$XBGm.LCICMGP.PowerPhase, allPhases, new ($.$$.S.Func$$$($.$XBGm.LCICMGP.PowerPhase, $.$$.S.Double))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d.Voltage;
                    }, $rSATal ??= {"r":1179649,"p":[{"n":"d","p":32871825}],"n":"","d":4024228,"h":0,"f":17825794})) : 0;
                    $i1.PeakCurrent = $.$sl.SL.Enumerable.Any$1($.$XBGm.LCICMGP.PowerPhase, allPhases) ? $.$sl.SL.Enumerable.Max$13($.$XBGm.LCICMGP.PowerPhase, allPhases, new ($.$$.S.Func$$$($.$XBGm.LCICMGP.PowerPhase, $.$$.S.Double))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d.Current;
                    }, $HMPoSh ??= {"r":1179649,"p":[{"n":"d","p":32871825}],"n":"","d":4024228,"h":0,"f":17825794})) : 0;
                    $i1.PeakPower = $.$sl.SL.Enumerable.Any$1($.$XBGm.LCICMGP.PowerPhase, allPhases) ? $.$sl.SL.Enumerable.Max$13($.$XBGm.LCICMGP.PowerPhase, allPhases, new ($.$$.S.Func$$$($.$XBGm.LCICMGP.PowerPhase, $.$$.S.Double))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d.Power;
                    }, $uxLvFe ??= {"r":1179649,"p":[{"n":"d","p":32871825}],"n":"","d":4024228,"h":0,"f":17825794})) : 0;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(8593958820)
            
            //--TRIMMABLE-BOUNDARY-START(4341863825)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Processings.IIOTDeviceDashboardDataBuilder<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel>.BuildDashboardModel(LivingThing.Core.IOT.Common.Interface.IIOTDeviceModel, System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel>, System.Collections.Generic.Dictionary<LivingThing.Core.Frameworks.Common.Data.Calendar.PeriodicInterval, System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel>>)
            LCICP$IIOTDeviceDashboardDataBuilder$LivingThing$Core$IOT$EnergyMeter$Common$Models$EnergyMeterDeviceStatusModel$LivingThing$Core$IOT$EnergyMeter$Common$Models$EnergyMeterDeviceDataClassificationModel$BuildDashboardModel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341863825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BuildDashboardModel(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4341863825)
            
            //--TRIMMABLE-BOUNDARY-START(4298991524)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298991524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298991524)
            
            //--TRIMMABLE-BOUNDARY-START(4298991524)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298991524)
            
            static $h = 4024228;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593958820),
    {
      "r": 131073,
      "p": [
        {
          "n": "device",
          "p": 27432337
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h
        },
        {
          "n": "classifications",
          "p": $.$$.SCG.Dictionary$$$($.$fPer.LCFCDC.PeriodicInterval, $.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)).$h
        }
      ],
      "n": "BuildDashboardModel",
      "d": 4024228,
      "h": 8593958820,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593958820)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298991524),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4024228,
      "h": 4298991524,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298991524)
  ],
  "h": 4024228
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICP.IIOTDeviceDashboardDataBuilder$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Processings.EnergyMeterDeviceDashboardBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Processings${separator}EnergyMeterDeviceDashboardBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4024228)
        
        

        //--TRIMMABLE-BOUNDARY-START(3041188)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptor`, ($self) => class EnergyMeterDeviceStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298008484)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298008484);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptor.GenerateProperties($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, this, factory);
                    }, $yZIsUi ??= {"r":65537,"n":"","d":3041188,"h":0,"f":17825794}), 0, "EnergyMeterDeviceStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\Models_EnergyMeterDeviceStatusModel_LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModelTypeDescriptorBuilder.g.cs", "EnergyMeterDeviceStatusModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298008484)
            
            //--TRIMMABLE-BOUNDARY-START(12887943076)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887943076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AvailablePhase"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel.$type, $.$discardRef(), "AvailablePhase", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AvailablePhase")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$uUnI.LCIECM.EnergyPhase), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "AvailablePhase";
                        $i1.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$uUnI.LCIECM.EnergyPhase, ($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).AvailablePhase);
                        }, $MRVqQi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3041188,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.AvailablePhase = value.AsNullableValue($.$uUnI.LCIECM.EnergyPhase);
                        }, $gBloGg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3041188,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Red"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel.$type, $.$discardRef(), "Red", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Red")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICMGP.PowerPhase, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Red";
                        $i3.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICMGP.PowerPhase, ($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).Red);
                        }, $RaDpih ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3041188,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.Red = value.AsReference($.$XBGm.LCICMGP.PowerPhase);
                        }, $LCKrXd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3041188,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Yellow"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel.$type, $.$discardRef(), "Yellow", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Yellow")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICMGP.PowerPhase, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Yellow";
                        $i5.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICMGP.PowerPhase, ($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).Yellow);
                        }, $yZxNmc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3041188,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Yellow = value.AsReference($.$XBGm.LCICMGP.PowerPhase);
                        }, $aqRXAi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3041188,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Blue"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel.$type, $.$discardRef(), "Blue", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Blue")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICMGP.PowerPhase, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Blue";
                        $i7.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICMGP.PowerPhase, ($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).Blue);
                        }, $CiRlHj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3041188,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Blue = value.AsReference($.$XBGm.LCICMGP.PowerPhase);
                        }, $VIsmhh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3041188,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Current"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel.$type, $.$discardRef(), "Current", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Current")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Current";
                        $i9.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).Current);
                        }, $DDXlnd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3041188,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Power"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel.$type, $.$discardRef(), "Power", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Power")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Power";
                        $i11.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).Power);
                        }, $JpoBTf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3041188,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ConsumedEnergy"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel.$type, $.$discardRef(), "ConsumedEnergy", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ConsumedEnergy")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "ConsumedEnergy";
                        $i13.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)).ConsumedEnergy);
                        }, $mzRROc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3041188,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICM.IOTDeviceStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887943076)
            
            //--TRIMMABLE-BOUNDARY-START(17182910372)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182910372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICM.IOTDeviceStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICM.IOTDeviceStatusModel));
                {
                    /*var*/ let _AvailablePhase = _target.AvailablePhase;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AvailablePhase"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$uUnI.LCIECM.EnergyPhase)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$uUnI.LCIECM.EnergyPhase), () => _AvailablePhase, ($v) => _AvailablePhase = $v, null, true)))
                    {
                        _target.AvailablePhase = _AvailablePhase;
                    }
                }
                {
                    /*var*/ let _Red = _target.Red;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Red"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICMGP.PowerPhase));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Red, ($v) => _Red = $v, $.$XBGm.LCICMGP.PowerPhase)))
                    {
                        _target.Red = _Red;
                    }
                }
                {
                    /*var*/ let _Yellow = _target.Yellow;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Yellow"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICMGP.PowerPhase));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Yellow, ($v) => _Yellow = $v, $.$XBGm.LCICMGP.PowerPhase)))
                    {
                        _target.Yellow = _Yellow;
                    }
                }
                {
                    /*var*/ let _Blue = _target.Blue;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Blue"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICMGP.PowerPhase));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Blue, ($v) => _Blue = $v, $.$XBGm.LCICMGP.PowerPhase)))
                    {
                        _target.Blue = _Blue;
                    }
                }
                {
                    /*var*/ let _Current = _target.Current;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Current"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Current, ($v) => _Current = $v, $.$$.S.Double)))
                    {
                    }
                }
                {
                    /*var*/ let _Power = _target.Power;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Power"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Power, ($v) => _Power = $v, $.$$.S.Double)))
                    {
                    }
                }
                {
                    /*var*/ let _ConsumedEnergy = _target.ConsumedEnergy;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ConsumedEnergy"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _ConsumedEnergy, ($v) => _ConsumedEnergy = $v, $.$$.S.Double)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182910372)
            
            //--TRIMMABLE-BOUNDARY-START(8592975780)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592975780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)))
                {
                    /*var*/ let result = $.$uUnI.LCIECM.EnergyMeterDeviceStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592975780)
            
            static $h = 3041188;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887943076),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3041188,
      "h": 12887943076,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887943076),
//--TRIMMABLE-BOUNDARY-START(17182910372),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2910116,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3041188,
      "h": 17182910372,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182910372),
//--TRIMMABLE-BOUNDARY-START(8592975780),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2910116,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3041188,
      "h": 8592975780,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592975780)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298008484),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3041188,
      "h": 4298008484,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298008484)
  ],
  "h": 3041188
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3041188)
        
        

        //--TRIMMABLE-BOUNDARY-START(4351908)
        $asm.$cls(`$uUnI.LCIECP.EnergyMeterDeviceDataClassifier`, ($self) => class EnergyMeterDeviceDataClassifier extends $.$XBGm.LCICP.BaseDeviceDataClassifier$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)
        {
            //--TRIMMABLE-BOUNDARY-START(12889253796)
            static /*IEnumerable<EnergyMeterDeviceDataClassificationModel> */ DoClassify(/*IEnumerable<EnergyMeterDeviceStatusModel>*/ statuses, /*DateTime*/ startDate, /*DateTime*/ endDate, /*PeriodicInterval*/ interval, /*EnergyMeterDeviceFlags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889253796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.DataClassifier.ClassifyByInterval($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, statuses, startDate, endDate, interval, new ($.$$.S.Func$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Nullable$$($.$$.S.DateTime))))().$ctor(this,  (/**/ s) =>
                {
                    return new ($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Nullable$$($.$$.S.DateTime)))().$ctor$3($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(s.DateCreated), s.DateExtended);
                }, $LPoNVe ??= {"r":$.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Nullable$$($.$$.S.DateTime)).$h,"p":[{"n":"s","p":2910116}],"n":"","d":4351908,"h":0,"f":17825794}), new ($.$$.S.Func$$$$$($.$$.S.DateTime, $.$$.S.DateTime, $.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))().$ctor(this,  (/*start*/ start, /*end*/ end, /*data*/ data) =>
                {
                    /*double*/ let energyR = 0;
                    /*double*/ let energyB = 0;
                    /*double*/ let energyY = 0;
                    /*double*/ let peakPower = 0;
                    /*double*/ let runTime = 0;
                    /*int*/ let powerCuts = 0;
                    /*EnergyMeterDeviceStatusModel*/ let lastPoint = null;
                    let $en1 = data.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let dat = $en1.SCG$IEnumerator$$$Current;
                        {
                            if (dat.Power > peakPower)
                            {
                                peakPower = dat.Power;
                            }
                            if (((flags & (1/*EnergyMeterDeviceFlags.LogAvailability*/)) == (1/*EnergyMeterDeviceFlags.LogAvailability*/)) && dat.AvailablePhase !== null)
                            {
                                if (dat.AvailablePhase !== 0/*EnergyPhase.None*/ && dat.DateExtended !== null)
                                {
                                    /*DateTime*/ let _start = $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(dat.DateCreated);
                                    /*DateTime*/ let _end = $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(dat.DateExtended);
                                    if ($.$$.S.DateTime.op_LessThan(_start, start))
                                    {
                                        _start = start;
                                    }
                                    if ($.$$.S.DateTime.op_GreaterThan(_end, end))
                                    {
                                        _end = end;
                                    }
                                    runTime += ($.$$.S.DateTime.op_Subtraction$1(_end, _start)).TotalSeconds;
                                }
                                if (lastPoint !== null && dat.AvailablePhase === 0/*EnergyPhase.None*/ && lastPoint.AvailablePhase !== 0/*EnergyPhase.None*/)
                                {
                                    powerCuts++;
                                }
                            }
                            else 
                            {
                                if (lastPoint !== null)
                                {
                                    /*var*/ let _energy = dat.Red.Energy - lastPoint.Red.Energy;
                                    if (_energy > 0)
                                    {
                                        energyR += _energy;
                                    }
                                    _energy = dat.Yellow.Energy - lastPoint.Yellow.Energy;
                                    if (_energy > 0)
                                    {
                                        energyY += _energy;
                                    }
                                    _energy = dat.Blue.Energy - lastPoint.Blue.Energy;
                                    if (_energy > 0)
                                    {
                                        energyB += _energy;
                                    }
                                    /*var*/ let interv = $.$$.S.DateTime.op_Subtraction$1($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(dat.DateCreated), $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call((lastPoint.DateExtended ?? lastPoint.DateCreated)));
                                    if ($.$$.S.TimeSpan.op_LessThan(interv, $.$$.S.TimeSpan.FromMinutes$2(5n)))
                                    {
                                        runTime += interv.TotalSeconds;
                                    }
                                    if (dat.DateExtended !== null)
                                    {
                                        runTime += ($.$$.S.DateTime.op_Subtraction$1($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(dat.DateExtended), $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(dat.DateCreated))).TotalSeconds;
                                    }
                                    if (dat.Power < 10 && lastPoint.Power > 100)
                                    {
                                        powerCuts++;
                                    }
                                }
                            }
                            lastPoint = dat;
                        }
                    }
                    return (() =>
                    {
                        //new $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel()
                        const $t2 = $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.StartDate = start;
                        $i2.RedEnergy = energyR;
                        $i2.BlueEnergy = energyB;
                        $i2.YellowEnergy = energyY;
                        $i2.PeakPower = peakPower;
                        $i2.Runtime = $.$cast(runTime, $.$$.S.Int32);
                        $i2.PowerCuts = powerCuts;
                        return $i2;
                    })();
                }, $HDbAZg ??= {"r":1206180,"p":[{"n":"start","p":65994753},{"n":"end","p":65994753},{"n":"data","p":$.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h}],"n":"","d":4351908,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(12889253796)
            
            //--TRIMMABLE-BOUNDARY-START(8594286500)
            /*IEnumerable<IIOTDeviceClassifiedData> */ Classify(/*IIOTDeviceModel*/ device, /*IEnumerable<EnergyMeterDeviceStatusModel>*/ data, /*DateTime*/ startTime, /*DateTime*/ endTime, /*PeriodicInterval*/ interval)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594286500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.N.InterfaceVarianceStubHandler.Create($.$uUnI.LCIECP.EnergyMeterDeviceDataClassifier.DoClassify(data, startTime, endTime, interval, ($.$cast(device, $.$uUnI.LCIECM.EnergyMeterDeviceModel)).DeviceFlags), $.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$$.SCG.IEnumerable$$($.$XBGm.LCICP.IIOTDeviceClassifiedData));
            }
            //--TRIMMABLE-BOUNDARY-END(8594286500)
            
            //--TRIMMABLE-BOUNDARY-START(4299319204)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299319204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299319204)
            
            //--TRIMMABLE-BOUNDARY-START(4299319204)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299319204)
            
            static $h = 4351908;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICP.BaseDeviceDataClassifier$$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889253796),
    {
      "r": $.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel).$h,
      "p": [
        {
          "n": "statuses",
          "p": $.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h
        },
        {
          "n": "startDate",
          "p": 65994753
        },
        {
          "n": "endDate",
          "p": 65994753
        },
        {
          "n": "interval",
          "p": 7178582
        },
        {
          "n": "flags",
          "p": 1468324
        }
      ],
      "n": "DoClassify",
      "d": 4351908,
      "h": 12889253796,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12889253796),
//--TRIMMABLE-BOUNDARY-START(8594286500),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCICP.IIOTDeviceClassifiedData).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h
        },
        {
          "n": "startTime",
          "p": 65994753
        },
        {
          "n": "endTime",
          "p": 65994753
        },
        {
          "n": "interval",
          "p": 7178582
        }
      ],
      "n": "Classify",
      "d": 4351908,
      "h": 8594286500,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8594286500)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299319204),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4351908,
      "h": 4299319204,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299319204)
  ],
  "h": 4351908
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICP.IIOTDeviceDataClassifier$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), $.$fPer.LCFCD.IChartable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Processings.EnergyMeterDeviceDataClassifier`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Processings${separator}EnergyMeterDeviceDataClassifier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4351908)
        
        

        //--TRIMMABLE-BOUNDARY-START(6186916)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterServiceSettingsTypeDescriptor`, ($self) => class EnergyMeterServiceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterServiceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4301154212)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301154212);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECS$1.EnergyMeterServiceSettingsTypeDescriptor.GenerateProperties($.$uUnI.LCIECS$1.EnergyMeterServiceSettings, this, factory);
                    }, $cmdFqc ??= {"r":65537,"n":"","d":6186916,"h":0,"f":17825794}), 0, "EnergyMeterServiceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\Settings_EnergyMeterServiceSettings_LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterServiceSettingsTypeDescriptorBuilder.g.cs", "EnergyMeterServiceSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301154212)
            
            //--TRIMMABLE-BOUNDARY-START(12891088804)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891088804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$2.IOTServiceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12891088804)
            
            //--TRIMMABLE-BOUNDARY-START(17186056100)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterServiceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17186056100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Settings.IOTServiceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICS$2.IOTServiceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$2.IOTServiceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17186056100)
            
            //--TRIMMABLE-BOUNDARY-START(8596121508)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterServiceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596121508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECS$1.EnergyMeterServiceSettings().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings)))
                {
                    /*var*/ let result = $.$uUnI.LCIECS$1.EnergyMeterServiceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8596121508)
            
            static $h = 6186916;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterServiceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12891088804),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 6186916,
      "h": 12891088804,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12891088804),
//--TRIMMABLE-BOUNDARY-START(17186056100),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6055844,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 6186916,
      "h": 17186056100,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17186056100),
//--TRIMMABLE-BOUNDARY-START(8596121508),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6055844,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 6186916,
      "h": 8596121508,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8596121508)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301154212),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6186916,
      "h": 4301154212,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301154212)
  ],
  "h": 6186916
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterServiceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterServiceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterServiceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6186916)
        
        

        //--TRIMMABLE-BOUNDARY-START(6973348)
        $asm.$cls(`$uUnI.LCIECS$2.EnergyMeterServiceStatesTypeDescriptor`, ($self) => class EnergyMeterServiceStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$2.EnergyMeterServiceStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4301940644)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301940644);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECS$2.EnergyMeterServiceStatesTypeDescriptor.GenerateProperties($.$uUnI.LCIECS$2.EnergyMeterServiceStates, this, factory);
                    }, $GYeIBe ??= {"r":65537,"n":"","d":6973348,"h":0,"f":17825794}), 0, "EnergyMeterServiceStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\States_EnergyMeterServiceStates_LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterServiceStatesTypeDescriptorBuilder.g.cs", "EnergyMeterServiceStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301940644)
            
            //--TRIMMABLE-BOUNDARY-START(12891875236)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891875236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICS$3.IOTServiceStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12891875236)
            
            //--TRIMMABLE-BOUNDARY-START(17186842532)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterServiceStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17186842532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.States.IOTServiceStates?*/ let targetBase = _target;
                $.$XBGm.LCICS$3.IOTServiceStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICS$3.IOTServiceStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17186842532)
            
            //--TRIMMABLE-BOUNDARY-START(8596907940)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterServiceStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596907940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECS$2.EnergyMeterServiceStates().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$2.EnergyMeterServiceStates)))
                {
                    /*var*/ let result = $.$uUnI.LCIECS$2.EnergyMeterServiceStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$2.EnergyMeterServiceStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$2.EnergyMeterServiceStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8596907940)
            
            static $h = 6973348;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$2.EnergyMeterServiceStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12891875236),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 6973348,
      "h": 12891875236,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12891875236),
//--TRIMMABLE-BOUNDARY-START(17186842532),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6842276,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 6973348,
      "h": 17186842532,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17186842532),
//--TRIMMABLE-BOUNDARY-START(8596907940),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6842276,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 6973348,
      "h": 8596907940,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8596907940)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301940644),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6973348,
      "h": 4301940644,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301940644)
  ],
  "h": 6973348
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECS$2.EnergyMeterServiceStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterServiceStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}States${separator}EnergyMeterServiceStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6973348)
        
        

        //--TRIMMABLE-BOUNDARY-START(2647972)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceSendDataModel`, ($self) => class EnergyMeterDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceAcknowledgeLogModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297615268)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3(-1);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297615268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297615268)
            
            //--TRIMMABLE-BOUNDARY-START(4297615268)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297615268)
            
            static $h = 2647972;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceAcknowledgeLogModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297615268),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2647972,
      "h": 4297615268,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297615268)
  ],
  "h": 2647972
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2647972)
        
        

        //--TRIMMABLE-BOUNDARY-START(2779044)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceSendDataModelTypeDescriptor`, ($self) => class EnergyMeterDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297746340)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297746340);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModelTypeDescriptor.GenerateProperties($.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, this, factory);
                    }, $vzUVSd ??= {"r":65537,"n":"","d":2779044,"h":0,"f":17825794}), 0, "EnergyMeterDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\Models_EnergyMeterDeviceSendDataModel_LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceSendDataModelTypeDescriptorBuilder.g.cs", "EnergyMeterDeviceSendDataModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297746340)
            
            //--TRIMMABLE-BOUNDARY-START(12887680932)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887680932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceAcknowledgeLogModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887680932)
            
            //--TRIMMABLE-BOUNDARY-START(17182648228)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182648228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceAcknowledgeLogModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceAcknowledgeLogModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceAcknowledgeLogModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182648228)
            
            //--TRIMMABLE-BOUNDARY-START(8592713636)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592713636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592713636)
            
            static $h = 2779044;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887680932),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2779044,
      "h": 12887680932,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887680932),
//--TRIMMABLE-BOUNDARY-START(17182648228),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2647972,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2779044,
      "h": 17182648228,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182648228),
//--TRIMMABLE-BOUNDARY-START(8592713636),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2647972,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2779044,
      "h": 8592713636,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592713636)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297746340),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2779044,
      "h": 4297746340,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297746340)
  ],
  "h": 2779044
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2779044)
        
        

        //--TRIMMABLE-BOUNDARY-START(2123684)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel`, ($self) => class EnergyMeterDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$uUnI.LCIECM.EnergyMeterReceivedStatus, $.$uUnI.LCIECM.EnergyMeterDeviceLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(21476960164)
            /*bool */ get IsValid()
            {
                return super.IsValid && ((this.Log?.Data ?? null) === null || (this.Log.Data.Date.Year > 2022 && this.Log.Data.Grid.Red.Voltage >= 0 && this.Log.Data.Grid.Red.Voltage < 500 && this.Log.Data.Grid.Yellow.Voltage >= 0 && this.Log.Data.Grid.Yellow.Voltage < 500 && this.Log.Data.Grid.Blue.Voltage >= 0 && this.Log.Data.Grid.Blue.Voltage < 500 && this.Log.Data.Grid.Red.Current >= 0 && this.Log.Data.Grid.Red.Current < 10000 && this.Log.Data.Grid.Yellow.Current >= 0 && this.Log.Data.Grid.Yellow.Current < 10000 && this.Log.Data.Grid.Blue.Current >= 0 && this.Log.Data.Grid.Blue.Current < 10000));
            }
            //--TRIMMABLE-BOUNDARY-END(21476960164)
            
            //--TRIMMABLE-BOUNDARY-START(8592058276)
            /*IOTDeviceSendDataModel? */ Ack()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592058276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Log !== null)
                {
                    return (() =>
                    {
                        //new $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel()
                        const $t1 = $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel;
                        const $i1 = new $t1();
                        $i1.$ctor$4();
                        $i1.LogAck = (() =>
                        {
                            //new $.$XBGm.LCICDi.iSmartDeviceLogAcknowledgeModel()
                            const $t2 = $.$XBGm.LCICDi.iSmartDeviceLogAcknowledgeModel;
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            return $i2;
                        })();
                        return $i1;
                    })();
                }
                return super.Ack();
            }
            //--TRIMMABLE-BOUNDARY-END(8592058276)
            
            //--TRIMMABLE-BOUNDARY-START(4297090980)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297090980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297090980)
            
            //--TRIMMABLE-BOUNDARY-START(4297090980)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4297090980)
            
            static $h = 2123684;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$uUnI.LCIECM.EnergyMeterReceivedStatus, $.$uUnI.LCIECM.EnergyMeterDeviceLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476960164),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181992868,
        "f": 50364417
      },
      "n": "IsValid",
      "d": 2123684,
      "h": 21476960164,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21476960164)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592058276),
    {
      "r": 39425425,
      "n": "Ack",
      "d": 2123684,
      "h": 8592058276,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8592058276)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297090980),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2123684,
      "h": 4297090980,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297090980)
  ],
  "h": 2123684
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2123684)
        
        

        //--TRIMMABLE-BOUNDARY-START(2254756)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModelTypeDescriptor`, ($self) => class EnergyMeterDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297222052)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297222052);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, this, factory);
                    }, $ZSqqfi ??= {"r":65537,"n":"","d":2254756,"h":0,"f":17825794}), 0, "EnergyMeterDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\Models_EnergyMeterDeviceReceivedDataModel_LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "EnergyMeterDeviceReceivedDataModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297222052)
            
            //--TRIMMABLE-BOUNDARY-START(12887156644)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887156644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsValid"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel.$type, $.$discardRef(), "IsValid", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsValid")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "IsValid";
                        $i1.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel)).IsValid);
                        }, $gYbjVi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2254756,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$uUnI.LCIECM.EnergyMeterReceivedStatus, $.$uUnI.LCIECM.EnergyMeterDeviceLogModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887156644)
            
            //--TRIMMABLE-BOUNDARY-START(17182123940)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182123940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterReceivedStatus, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceLogModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$uUnI.LCIECM.EnergyMeterReceivedStatus, $.$uUnI.LCIECM.EnergyMeterDeviceLogModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$uUnI.LCIECM.EnergyMeterReceivedStatus, $.$uUnI.LCIECM.EnergyMeterDeviceLogModel)));
                {
                    /*var*/ let _IsValid = _target.IsValid;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsValid"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsValid, ($v) => _IsValid = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182123940)
            
            //--TRIMMABLE-BOUNDARY-START(8592189348)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592189348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592189348)
            
            static $h = 2254756;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887156644),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2254756,
      "h": 12887156644,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887156644),
//--TRIMMABLE-BOUNDARY-START(17182123940),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2123684,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2254756,
      "h": 17182123940,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182123940),
//--TRIMMABLE-BOUNDARY-START(8592189348),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2123684,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2254756,
      "h": 8592189348,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592189348)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297222052),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2254756,
      "h": 4297222052,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297222052)
  ],
  "h": 2254756
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2254756)
        
        

        //--TRIMMABLE-BOUNDARY-START(288676)
        $asm.$cls(`$uUnI.LCIEC.EnergyMeterDataConverter`, ($self) => class EnergyMeterDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8590223268)
            /*EnergyMeterDeviceStatusModel */ Convert$1(/*EnergyMeterDeviceReceivedDataModel*/ input, /*object*/ param)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590223268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((input.Status?.Grid ?? null) !== null)
                {
                    return (() =>
                    {
                        //new $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel()
                        const $t1 = $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel;
                        const $i1 = new $t1();
                        $i1.$ctor$4();
                        $i1.DateCreated = input.DateCreated;
                        $i1.DateExtended = input.DateExtended;
                        $i1.Red = input.Status.Grid.Red;
                        $i1.Blue = input.Status.Grid.Blue;
                        $i1.Yellow = input.Status.Grid.Yellow;
                        return $i1;
                    })();
                }
                return super.Convert$1(input, param);
            }
            //--TRIMMABLE-BOUNDARY-END(8590223268)
            
            //--TRIMMABLE-BOUNDARY-START(4295255972)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295255972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295255972)
            
            //--TRIMMABLE-BOUNDARY-START(4295255972)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295255972)
            
            static $h = 288676;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590223268),
    {
      "r": 2910116,
      "p": [
        {
          "n": "input",
          "p": 2123684
        },
        {
          "n": "param",
          "p": 131073,
          "f": 65
        }
      ],
      "n": "Convert",
      "o": "@$1",
      "d": 288676,
      "h": 8590223268,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590223268)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295255972),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 288676,
      "h": 4295255972,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295255972)
  ],
  "h": 288676
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$uUnI.LCIECM.EnergyMeterDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.EnergyMeterDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}EnergyMeterDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(288676)
        
        

        $asm.$typeProxy("$uUnI.LCIECM.EnergyMeterServiceModel", "$uUnI.LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel");
        $asm.$typeProxy("$uUnI.LCIECM.EnergyMeterDeviceModel", "$uUnI.LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceModel");
        $asm.$typeProxy("$uUnI.LCIECS$1.EnergyMeterDeviceSettings", "$uUnI.LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettings");
        $asm.$typeProxy("$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings", "$uUnI.LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettings");
        $asm.$typeProxy("$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler", "$uUnI.LivingThing.Core.IOT.EnergyMeter.Common.Services.IEnergyMeterDeviceStatusHandler");
        $asm.$typeProxy("$uUnI.LCIECH.IEnergyMeterServiceHubClient", "$uUnI.LivingThing.Core.IOT.EnergyMeter.Common.Hubs.IEnergyMeterServiceHubClient");
        $asm.$typeProxy("$uUnI.LCIECS.IEnergyMeterRemoteService", "$uUnI.LivingThing.Core.IOT.EnergyMeter.Common.Services.IEnergyMeterRemoteService");
        //--TRIMMABLE-BOUNDARY-START(2385828)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceScopeModel`, ($self) => class EnergyMeterDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $self, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297353124)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297353124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297353124)
            
            //--TRIMMABLE-BOUNDARY-START(4297353124)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4297353124)
            
            static $h = 2385828;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297353124),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 2385828,
      "h": 4297353124,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297353124)
  ],
  "h": 2385828
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2385828)
        
        

        //--TRIMMABLE-BOUNDARY-START(1861540)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceModel`, ($self) => class EnergyMeterDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $self, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(12886763428)
            /*EnergyMeterDeviceFlags*/ DeviceFlags = 0;
            //--TRIMMABLE-BOUNDARY-END(12886763428)
            
            //--TRIMMABLE-BOUNDARY-START(8591796132)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591796132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591796132)
            
            //--TRIMMABLE-BOUNDARY-START(8591796132)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(8591796132)
            
            static $h = 1861540;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886763428),
    {
      "p": 1468324,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476698020,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066632612,
        "f": 83886081
      },
      "n": "DeviceFlags",
      "d": 1861540,
      "h": 12886763428,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1536,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886763428)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591796132),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1861540,
      "h": 8591796132,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591796132)
  ],
  "h": 1861540
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1861540)
        
        

        //--TRIMMABLE-BOUNDARY-START(4548516)
        $asm.$cls(`$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler`, ($self) => class IEnergyMeterDeviceStatusHandler
        {
            static $h = 4548516;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 4548516
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver, $.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler$$($.$fPer.LCFCDM.BackedUpThreePhasePower), $.$tUcV.LCFCM.INotificationHandler$$($.$NzWm.LCIDGS.GatewayNotification$$($.$fPer.LCFCDM.BackedUpThreePhasePower)), $.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler$$($.$fPer.LCFCDM.BackedUpSinglePhasePower), $.$tUcV.LCFCM.INotificationHandler$$($.$NzWm.LCIDGS.GatewayNotification$$($.$fPer.LCFCDM.BackedUpSinglePhasePower)), $.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Services.IEnergyMeterDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Services${separator}IEnergyMeterDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4548516)
        
        

        //--TRIMMABLE-BOUNDARY-START(4614052)
        $asm.$cls(`$uUnI.LCIECS.IEnergyMeterRemoteService`, ($self) => class IEnergyMeterRemoteService
        {
            static $h = 4614052;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 4614052,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$vWqU.LCFCCR.IReportService$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Services.IEnergyMeterRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Services${separator}IEnergyMeterRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4614052)
        
        

        //--TRIMMABLE-BOUNDARY-START(3368868)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterServiceModel`, ($self) => class EnergyMeterServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298336164)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298336164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298336164)
            
            //--TRIMMABLE-BOUNDARY-START(4298336164)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4298336164)
            
            static $h = 3368868;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298336164),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 3368868,
      "h": 4298336164,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298336164)
  ],
  "h": 3368868,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "Exclude",
          "v": 1039,
          "t": 2722134
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$uUnI.LCIECM.EnergyMeterServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3368868)
        
        

        //--TRIMMABLE-BOUNDARY-START(5269412)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings`, ($self) => class EnergyMeterDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $self, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(21480105892)
            /*IOTDeviceInternalConfiguration<float>*/ CurrentTransformerRatio = null;
            //--TRIMMABLE-BOUNDARY-END(21480105892)
            
            //--TRIMMABLE-BOUNDARY-START(17185138596)
            /*IOTDeviceInternalConfiguration<float>*/ BurdenResitor = null;
            //--TRIMMABLE-BOUNDARY-END(17185138596)
            
            //--TRIMMABLE-BOUNDARY-START(12890171300)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890171300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12890171300)
            
            //--TRIMMABLE-BOUNDARY-START(12890171300)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12890171300)
            
            static $h = 5269412;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21480105892),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38659975076,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55839844260,
        "f": 83886081
      },
      "n": "CurrentTransformerRatio",
      "d": 5269412,
      "h": 21480105892,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "ct",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 32,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21480105892),
//--TRIMMABLE-BOUNDARY-START(17185138596),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30070040484,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47249909668,
        "f": 83886081
      },
      "n": "BurdenResitor",
      "d": 5269412,
      "h": 17185138596,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "bd",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 33,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17185138596)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12890171300),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5269412,
      "h": 12890171300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12890171300)
  ],
  "h": 5269412
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5269412)
        
        

        //--TRIMMABLE-BOUNDARY-START(812964)
        $asm.$cls(`$uUnI.LCIECH.IEnergyMeterServiceHubClient`, ($self) => class IEnergyMeterServiceHubClient
        {
            static $h = 812964;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 812964
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Hubs.IEnergyMeterServiceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Hubs${separator}IEnergyMeterServiceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(812964)
        
        

        //--TRIMMABLE-BOUNDARY-START(5793700)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDeviceSettings`, ($self) => class EnergyMeterDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $self, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(94495074212)
            /*double*/ VoltageCalibration = 0;
            //--TRIMMABLE-BOUNDARY-END(94495074212)
            
            //--TRIMMABLE-BOUNDARY-START(21480630180)
            /*double*/ CurrentCalibration = 0;
            //--TRIMMABLE-BOUNDARY-END(21480630180)
            
            //--TRIMMABLE-BOUNDARY-START(60135335844)
            /*double*/ MaximumCurrent = 0;
            //--TRIMMABLE-BOUNDARY-END(60135335844)
            
            //--TRIMMABLE-BOUNDARY-START(64430303140)
            /*double */ get PowerCalibration()
            {
                return this.VoltageCalibration * this.CurrentCalibration;
            }
            //--TRIMMABLE-BOUNDARY-END(64430303140)
            
            //--TRIMMABLE-BOUNDARY-START(17185662884)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185662884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17185662884)
            
            //--TRIMMABLE-BOUNDARY-START(17185662884)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(17185662884)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(94495074212)
                this.VoltageCalibration = 1;
                //--TRIMMABLE-BOUNDARY-END(94495074212)
                
                //--TRIMMABLE-BOUNDARY-START(21480630180)
                this.CurrentCalibration = 1;
                //--TRIMMABLE-BOUNDARY-END(21480630180)
                
                //--TRIMMABLE-BOUNDARY-START(60135335844)
                this.MaximumCurrent = 100;
                //--TRIMMABLE-BOUNDARY-END(60135335844)
                
            }
            static $h = 5793700;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94495074212),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55840368548,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90200106916,
        "f": 83886081
      },
      "n": "VoltageCalibration",
      "d": 5793700,
      "h": 94495074212,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94495074212),
//--TRIMMABLE-BOUNDARY-START(21480630180),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30070564772,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73020237732,
        "f": 83886081
      },
      "n": "CurrentCalibration",
      "d": 5793700,
      "h": 21480630180,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21480630180),
//--TRIMMABLE-BOUNDARY-START(60135335844),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38660499364,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81610172324,
        "f": 83886081
      },
      "n": "MaximumCurrent",
      "d": 5793700,
      "h": 60135335844,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60135335844),
//--TRIMMABLE-BOUNDARY-START(64430303140),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47250433956,
        "f": 50331649
      },
      "n": "PowerCalibration",
      "d": 5793700,
      "h": 64430303140,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64430303140)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17185662884),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 5793700,
      "h": 17185662884,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17185662884)
  ],
  "h": 5793700
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5793700)
        
        

        //--TRIMMABLE-BOUNDARY-START(4482980)
        $asm.$cls(`$uUnI.LCIECS.EnergyMeterDeviceStatusHandler`, ($self) => class EnergyMeterDeviceStatusHandler extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12889384868)
            /*Task */ Handle$1(/*GatewayNotification<BackedUpThreePhasePower>*/ notification, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889384868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12889384868)
            
            //--TRIMMABLE-BOUNDARY-START(8594417572)
            /*Task */ Handle(/*GatewayNotification<BackedUpSinglePhasePower>*/ notification, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594417572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(8594417572)
            
            //--TRIMMABLE-BOUNDARY-START(17184352164)
            /*Task */ HandleConnected(/*IConnectionClient*/ client, /*object?*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184352164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(17184352164)
            
            //--TRIMMABLE-BOUNDARY-START(21479319460)
            /*Task */ HandleDisconnected(/*IConnectionClient*/ client, /*object?*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479319460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(21479319460)
            
            //--TRIMMABLE-BOUNDARY-START(25774286756)
            /*Task<EnergyMeterDeviceSendDataModel?> */ HandleReceived(/*IConnectionMessage*/ message, /*EnergyMeterDeviceReceivedDataModel*/ status, /*object?*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25774286756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, null);
            }
            //--TRIMMABLE-BOUNDARY-END(25774286756)
            
            //--TRIMMABLE-BOUNDARY-START(4323972497)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceStatusHandler<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceSendDataModel>.HandleReceived(LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModel, object?)
            LCICI$IIOTDeviceStatusHandler$$$$HandleReceived()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4323972497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleReceived(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4323972497)
            
            //--TRIMMABLE-BOUNDARY-START(8616056209)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceConnectionStatusHandler.HandleConnected(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, object?)
            LCICI$IIOTDeviceConnectionStatusHandler$HandleConnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8616056209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleConnected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8616056209)
            
            //--TRIMMABLE-BOUNDARY-START(12911023505)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceConnectionStatusHandler.HandleDisconnected(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, object?)
            LCICI$IIOTDeviceConnectionStatusHandler$HandleDisconnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12911023505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleDisconnected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12911023505)
            
            //--TRIMMABLE-BOUNDARY-START(4295315818)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mediator.INotificationHandler<LivingThing.Core.IOT.Devices.Gateway.Services.GatewayNotification<LivingThing.Core.Frameworks.Common.Data.Measurements.BackedUpThreePhasePower>>.Handle(LivingThing.Core.IOT.Devices.Gateway.Services.GatewayNotification<LivingThing.Core.Frameworks.Common.Data.Measurements.BackedUpThreePhasePower>, System.Threading.CancellationToken)
            [`LCFCM$INotificationHandler$LivingThing$Core$IOT$Devices$Gateway$Services$GatewayNotification$LivingThing$Core$Frameworks$Common$Data$Measurements$BackedUpThreePhasePower$$Handle`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295315818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Handle$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295315818)
            
            //--TRIMMABLE-BOUNDARY-START(4295315818)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mediator.INotificationHandler<LivingThing.Core.IOT.Devices.Gateway.Services.GatewayNotification<LivingThing.Core.Frameworks.Common.Data.Measurements.BackedUpSinglePhasePower>>.Handle(LivingThing.Core.IOT.Devices.Gateway.Services.GatewayNotification<LivingThing.Core.Frameworks.Common.Data.Measurements.BackedUpSinglePhasePower>, System.Threading.CancellationToken)
            [`LCFCM$INotificationHandler$LivingThing$Core$IOT$Devices$Gateway$Services$GatewayNotification$LivingThing$Core$Frameworks$Common$Data$Measurements$BackedUpSinglePhasePower$$Handle`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295315818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Handle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295315818)
            
            //--TRIMMABLE-BOUNDARY-START(4299450276)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299450276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299450276)
            
            //--TRIMMABLE-BOUNDARY-START(4299450276)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299450276)
            
            static $h = 4482980;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889384868),
    {
      "r": 178454529,
      "p": [
        {
          "n": "notification",
          "p": $.$NzWm.LCIDGS.GatewayNotification$$($.$fPer.LCFCDM.BackedUpThreePhasePower).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Handle",
      "o": "@$1",
      "d": 4482980,
      "h": 12889384868,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12889384868),
//--TRIMMABLE-BOUNDARY-START(8594417572),
    {
      "r": 178454529,
      "p": [
        {
          "n": "notification",
          "p": $.$NzWm.LCIDGS.GatewayNotification$$($.$fPer.LCFCDM.BackedUpSinglePhasePower).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Handle",
      "d": 4482980,
      "h": 8594417572,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8594417572),
//--TRIMMABLE-BOUNDARY-START(17184352164),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "arg",
          "p": 131073
        }
      ],
      "n": "HandleConnected",
      "d": 4482980,
      "h": 17184352164,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17184352164),
//--TRIMMABLE-BOUNDARY-START(21479319460),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "arg",
          "p": 131073
        }
      ],
      "n": "HandleDisconnected",
      "d": 4482980,
      "h": 21479319460,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21479319460),
//--TRIMMABLE-BOUNDARY-START(25774286756),
    {
      "r": $.$$.STT.Task$$($.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel).$h,
      "p": [
        {
          "n": "message",
          "p": 1961646
        },
        {
          "n": "status",
          "p": 2123684
        },
        {
          "n": "arg",
          "p": 131073
        }
      ],
      "n": "HandleReceived",
      "d": 4482980,
      "h": 25774286756,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25774286756)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299450276),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4482980,
      "h": 4299450276,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299450276)
  ],
  "h": 4482980
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver, $.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler$$($.$fPer.LCFCDM.BackedUpThreePhasePower), $.$tUcV.LCFCM.INotificationHandler$$($.$NzWm.LCIDGS.GatewayNotification$$($.$fPer.LCFCDM.BackedUpThreePhasePower)), $.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler$$($.$fPer.LCFCDM.BackedUpSinglePhasePower), $.$tUcV.LCFCM.INotificationHandler$$($.$NzWm.LCIDGS.GatewayNotification$$($.$fPer.LCFCDM.BackedUpSinglePhasePower)), $.$NzWm.LCIDGS.IGatewayChanneledDeviceStatusHandler ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Services.EnergyMeterDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Services${separator}EnergyMeterDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4482980)
        
        

        //--TRIMMABLE-BOUNDARY-START(485284)
        $asm.$cls(`$uUnI.LCIEC.EnergyMeterDeviceModelDefinition`, ($self) => class EnergyMeterDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4295452580)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295452580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295452580)
            
            //--TRIMMABLE-BOUNDARY-START(4295452580)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295452580)
            
            static $h = 485284;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295452580),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 485284,
      "h": 4295452580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295452580)
  ],
  "h": 485284
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.EnergyMeterDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}EnergyMeterDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(485284)
        
        

        //--TRIMMABLE-BOUNDARY-START(4679588)
        $asm.$cls(`$uUnI.LCIECS.IEnergyMeterRemoteService_Mocking`, ($self) => class IEnergyMeterRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4299646884)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299646884);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299646884)
            
            //--TRIMMABLE-BOUNDARY-START(42954352548)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel>> */ Publish(/*LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel*/ dashboard)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42954352548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$uUnI.LCIECM.EnergyMeterServiceModel).$type;
                    $i1.MethodName = "Publish";
                    return $i1;
                })();
                return this.InvokeAsync($.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel), $.$fPer.LCFCD.WireTransportModel$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$uUnI.LCIECM.EnergyMeterServiceModel.$type, dashboard) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(42954352548)
            
            //--TRIMMABLE-BOUNDARY-START(12889581476)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Frameworks.Common.Models.UserServiceSubscriptionModel<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel>>> */ LCFCCR$ISubscriptionBasedRemoteService$LivingThing$Core$IOT$EnergyMeter$Common$Models$EnergyMeterServiceModel$LoadServices(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889581476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$uUnI.LCIECM.EnergyMeterServiceModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$uUnI.LCIECM.EnergyMeterServiceModel)).$type;
                    $i2.MethodName = "LoadServices";
                    return $i2;
                })();
                return this.InvokeAsync($.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$uUnI.LCIECM.EnergyMeterServiceModel)), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12889581476)
            
            //--TRIMMABLE-BOUNDARY-START(38659385252)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel> */ LCFCR$IServiceRemoteService$LivingThing$Core$IOT$EnergyMeter$Common$Models$EnergyMeterServiceModel$LivingThing$Core$IOT$EnergyMeter$Common$Models$EnergyMeterServiceTierType$ChangeServiceTier(/*string*/ contextId, /*LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceTierType*/ newTier, /*System.DateTime*/ expiryDate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38659385252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$uvJL.LCFCR.IServiceRemoteService$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel.$type;
                    $i3.MethodName = "ChangeServiceTier";
                    return $i3;
                })();
                return this.InvokeAsync($.$uvJL.LCFCR.IServiceRemoteService$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType), $.$fPer.LCFCD.WireTransportModel, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, contextId), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$uUnI.LCIECM.EnergyMeterServiceTierType.$type, $.$box(newTier, $.$uUnI.LCIECM.EnergyMeterServiceTierType)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, expiryDate) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(38659385252)
            
            //--TRIMMABLE-BOUNDARY-START(17184548772)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel>> */ LCFCD$ICreateDataService$LivingThing$Core$IOT$EnergyMeter$Common$Models$EnergyMeterServiceModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184548772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$uUnI.LCIECM.EnergyMeterServiceModel).$type;
                    $i4.MethodName = "Create";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$uUnI.LCIECM.EnergyMeterServiceModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17184548772)
            
            //--TRIMMABLE-BOUNDARY-START(25774483364)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$IOT$EnergyMeter$Common$Models$EnergyMeterServiceModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25774483364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$uUnI.LCIECM.EnergyMeterServiceModel).$type;
                    $i5.MethodName = "ReadMany";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$uUnI.LCIECM.EnergyMeterServiceModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25774483364)
            
            //--TRIMMABLE-BOUNDARY-START(30069450660)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$IOT$EnergyMeter$Common$Models$EnergyMeterServiceModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30069450660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel).$type;
                    $i6.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$uUnI.LCIECM.EnergyMeterServiceModel).$type;
                    $i6.MethodName = "ReadSingle";
                    return $i6;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.WireTransportModel$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$uUnI.LCIECM.EnergyMeterServiceModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30069450660)
            
            //--TRIMMABLE-BOUNDARY-START(34364417956)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$IOT$EnergyMeter$Common$Models$EnergyMeterServiceModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34364417956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t7 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Mock = this;
                    $i7.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel).$type;
                    $i7.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$uUnI.LCIECM.EnergyMeterServiceModel).$type;
                    $i7.MethodName = "Update";
                    return $i7;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$uUnI.LCIECM.EnergyMeterServiceModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(34364417956)
            
            //--TRIMMABLE-BOUNDARY-START(21479516068)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479516068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t8 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i8 = new $t8();
                    $i8.$ctor$2();
                    $i8.Mock = this;
                    $i8.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel).$type;
                    $i8.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i8.MethodName = "Delete";
                    return $i8;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$uUnI.LCIECM.EnergyMeterServiceModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21479516068)
            
            //--TRIMMABLE-BOUNDARY-START(8594614180)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceDataClassificationModel>> */ LCFCCR$IReportService$LivingThing$Core$IOT$EnergyMeter$Common$Models$EnergyMeterDeviceDataClassificationModel$GetReport(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594614180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t9 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i9 = new $t9();
                    $i9.$ctor$2();
                    $i9.Mock = this;
                    $i9.DeclaringType = $.$vWqU.LCFCCR.IReportService$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel).$type;
                    $i9.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel).$type;
                    $i9.MethodName = "GetReport";
                    return $i9;
                })();
                return this.InvokeAsync($.$vWqU.LCFCCR.IReportService$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8594614180)
            
            //--TRIMMABLE-BOUNDARY-START(4347434385)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Services.IIOTServicesRemoteService<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceTierType, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterServiceSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterServiceStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceScopeModel, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceScopeSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceScopeStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceModel, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettings, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceCommandModel>.Publish(LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel)
            LCICS$1$IIOTServicesRemoteService$LivingThing$Core$IOT$EnergyMeter$Common$Models$EnergyMeterServiceTierType$LivingThing$Core$IOT$EnergyMeter$Common$Models$EnergyMeterServiceModel$LivingThing$Core$IOT$EnergyMeter$Common$Settings$EnergyMeterServiceSettings$LivingThing$Core$IOT$EnergyMeter$Common$States$EnergyMeterServiceStates$LivingThing$Core$IOT$EnergyMeter$Common$Models$EnergyMeterDeviceScopeModel$LivingThing$Core$IOT$EnergyMeter$Common$Settings$EnergyMeterDeviceScopeSettings$LivingThing$Core$IOT$EnergyMeter$Common$States$EnergyMeterDeviceScopeStates$LivingThing$Core$IOT$EnergyMeter$Common$Models$EnergyMeterDeviceModel$LivingThing$Core$IOT$EnergyMeter$Common$Settings$EnergyMeterDeviceSettings$LivingThing$Core$IOT$EnergyMeter$Common$Settings$EnergyMeterDeviceHardwareSettings$LivingThing$Core$IOT$EnergyMeter$Common$States$EnergyMeterDeviceStates$LivingThing$Core$IOT$EnergyMeter$Common$Models$EnergyMeterDeviceStatusModel$LivingThing$Core$IOT$EnergyMeter$Common$Models$EnergyMeterDeviceCommandModel$Publish()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4347434385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Publish(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4347434385)
            
            static $h = 4679588;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(42954352548),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$uUnI.LCIECM.EnergyMeterServiceModel)).$h,
      "p": [
        {
          "n": "dashboard",
          "p": 3368868
        }
      ],
      "n": "Publish",
      "d": 4679588,
      "h": 42954352548,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42954352548)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299646884),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4679588,
      "h": 4299646884,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4299646884)
  ],
  "h": 4679588
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$vWqU.LCFCCR.IReportService$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Services.IEnergyMeterRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Services${separator}IEnergyMeterRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4679588)
        
        

        //--TRIMMABLE-BOUNDARY-START(2516900)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceScopeModelTypeDescriptor`, ($self) => class EnergyMeterDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297484196)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297484196);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECM.EnergyMeterDeviceScopeModelTypeDescriptor.GenerateProperties($.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, this, factory);
                    }, $aXLoKe ??= {"r":65537,"n":"","d":2516900,"h":0,"f":17825794}), 0, "EnergyMeterDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\Models_EnergyMeterDeviceScopeModel_LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceScopeModelTypeDescriptorBuilder.g.cs", "EnergyMeterDeviceScopeModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297484196)
            
            //--TRIMMABLE-BOUNDARY-START(12887418788)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887418788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887418788)
            
            //--TRIMMABLE-BOUNDARY-START(17182386084)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182386084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceTierType, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceFeatureType, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterServiceSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterServiceStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceScopeModel, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceScopeSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceScopeStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceModel, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettings, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceCommandModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceSendDataModel, LivingThing.Core.IOT.EnergyMeter.Common.Services.IEnergyMeterDeviceStatusHandler, LivingThing.Core.IOT.EnergyMeter.Common.Hubs.IEnergyMeterServiceHubClient, LivingThing.Core.IOT.EnergyMeter.Common.Services.IEnergyMeterRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182386084)
            
            //--TRIMMABLE-BOUNDARY-START(8592451492)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592451492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel)))
                {
                    /*var*/ let result = $.$uUnI.LCIECM.EnergyMeterDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592451492)
            
            static $h = 2516900;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887418788),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2516900,
      "h": 12887418788,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887418788),
//--TRIMMABLE-BOUNDARY-START(17182386084),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2385828,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2516900,
      "h": 17182386084,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182386084),
//--TRIMMABLE-BOUNDARY-START(8592451492),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2385828,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2516900,
      "h": 8592451492,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592451492)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297484196),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2516900,
      "h": 4297484196,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297484196)
  ],
  "h": 2516900
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2516900)
        
        

        //--TRIMMABLE-BOUNDARY-START(5924772)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDeviceSettingsTypeDescriptor`, ($self) => class EnergyMeterDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4300892068)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300892068);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECS$1.EnergyMeterDeviceSettingsTypeDescriptor.GenerateProperties($.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, this, factory);
                    }, $vTPfUf ??= {"r":65537,"n":"","d":5924772,"h":0,"f":17825794}), 0, "EnergyMeterDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\Settings_EnergyMeterDeviceSettings_LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettingsTypeDescriptorBuilder.g.cs", "EnergyMeterDeviceSettingsTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300892068)
            
            //--TRIMMABLE-BOUNDARY-START(12890826660)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890826660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("VoltageCalibration"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings.$type, $.$discardRef(), "VoltageCalibration", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("VoltageCalibration")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "VoltageCalibration";
                        $i1.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECS$1.EnergyMeterDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings)).VoltageCalibration);
                        }, $UcIted ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5924772,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECS$1.EnergyMeterDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.VoltageCalibration = value.AsDouble();
                        }, $iSQCdh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5924772,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CurrentCalibration"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings.$type, $.$discardRef(), "CurrentCalibration", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CurrentCalibration")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "CurrentCalibration";
                        $i3.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECS$1.EnergyMeterDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings)).CurrentCalibration);
                        }, $cEJDme ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5924772,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECS$1.EnergyMeterDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CurrentCalibration = value.AsDouble();
                        }, $wsVetd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5924772,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MaximumCurrent"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings.$type, $.$discardRef(), "MaximumCurrent", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MaximumCurrent")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "MaximumCurrent";
                        $i5.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettings";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECS$1.EnergyMeterDeviceSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings)).MaximumCurrent);
                        }, $nGuwyd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5924772,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECS$1.EnergyMeterDeviceSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.MaximumCurrent = value.AsDouble();
                        }, $wSKjTe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5924772,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PowerCalibration"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings.$type, $.$discardRef(), "PowerCalibration", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PowerCalibration")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "PowerCalibration";
                        $i7.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettings";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECS$1.EnergyMeterDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings)).PowerCalibration);
                        }, $uYmEYc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5924772,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890826660)
            
            //--TRIMMABLE-BOUNDARY-START(17185793956)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185793956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceTierType, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceFeatureType, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterServiceSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterServiceStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceScopeModel, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceScopeSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceScopeStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceModel, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettings, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceCommandModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceSendDataModel, LivingThing.Core.IOT.EnergyMeter.Common.Services.IEnergyMeterDeviceStatusHandler, LivingThing.Core.IOT.EnergyMeter.Common.Hubs.IEnergyMeterServiceHubClient, LivingThing.Core.IOT.EnergyMeter.Common.Services.IEnergyMeterRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).iSmartDeviceSettings));
                {
                    /*var*/ let _VoltageCalibration = _target.VoltageCalibration;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("VoltageCalibration"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _VoltageCalibration, ($v) => _VoltageCalibration = $v, $.$$.S.Double)))
                    {
                        _target.VoltageCalibration = _VoltageCalibration;
                    }
                }
                {
                    /*var*/ let _CurrentCalibration = _target.CurrentCalibration;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CurrentCalibration"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _CurrentCalibration, ($v) => _CurrentCalibration = $v, $.$$.S.Double)))
                    {
                        _target.CurrentCalibration = _CurrentCalibration;
                    }
                }
                {
                    /*var*/ let _MaximumCurrent = _target.MaximumCurrent;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MaximumCurrent"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _MaximumCurrent, ($v) => _MaximumCurrent = $v, $.$$.S.Double)))
                    {
                        _target.MaximumCurrent = _MaximumCurrent;
                    }
                }
                {
                    /*var*/ let _PowerCalibration = _target.PowerCalibration;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PowerCalibration"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _PowerCalibration, ($v) => _PowerCalibration = $v, $.$$.S.Double)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185793956)
            
            //--TRIMMABLE-BOUNDARY-START(8595859364)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595859364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings)))
                {
                    /*var*/ let result = $.$uUnI.LCIECS$1.EnergyMeterDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595859364)
            
            static $h = 5924772;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890826660),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5924772,
      "h": 12890826660,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890826660),
//--TRIMMABLE-BOUNDARY-START(17185793956),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5793700,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5924772,
      "h": 17185793956,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185793956),
//--TRIMMABLE-BOUNDARY-START(8595859364),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5793700,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5924772,
      "h": 8595859364,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595859364)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300892068),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5924772,
      "h": 4300892068,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300892068)
  ],
  "h": 5924772
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5924772)
        
        

        //--TRIMMABLE-BOUNDARY-START(3499940)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterServiceModelTypeDescriptor`, ($self) => class EnergyMeterServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298467236)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298467236);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECM.EnergyMeterServiceModelTypeDescriptor.GenerateProperties($.$uUnI.LCIECM.EnergyMeterServiceModel, this, factory);
                    }, $McVeyj ??= {"r":65537,"n":"","d":3499940,"h":0,"f":17825794}), 0, "EnergyMeterServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\Models_EnergyMeterServiceModel_LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModelTypeDescriptorBuilder.g.cs", "EnergyMeterServiceModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298467236)
            
            //--TRIMMABLE-BOUNDARY-START(12888401828)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888401828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888401828)
            
            //--TRIMMABLE-BOUNDARY-START(17183369124)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183369124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceTierType, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceFeatureType, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterServiceSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterServiceStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceScopeModel, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceScopeSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceScopeStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceModel, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettings, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceCommandModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceSendDataModel, LivingThing.Core.IOT.EnergyMeter.Common.Services.IEnergyMeterDeviceStatusHandler, LivingThing.Core.IOT.EnergyMeter.Common.Hubs.IEnergyMeterServiceHubClient, LivingThing.Core.IOT.EnergyMeter.Common.Services.IEnergyMeterRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183369124)
            
            //--TRIMMABLE-BOUNDARY-START(8593434532)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593434532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECM.EnergyMeterServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECM.EnergyMeterServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterServiceModel)))
                {
                    /*var*/ let result = $.$uUnI.LCIECM.EnergyMeterServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECM.EnergyMeterServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593434532)
            
            static $h = 3499940;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888401828),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3499940,
      "h": 12888401828,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888401828),
//--TRIMMABLE-BOUNDARY-START(17183369124),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3368868,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3499940,
      "h": 17183369124,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183369124),
//--TRIMMABLE-BOUNDARY-START(8593434532),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3368868,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3499940,
      "h": 8593434532,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593434532)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298467236),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3499940,
      "h": 4298467236,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298467236)
  ],
  "h": 3499940
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3499940)
        
        

        //--TRIMMABLE-BOUNDARY-START(5400484)
        $asm.$cls(`$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettingsTypeDescriptor`, ($self) => class EnergyMeterDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4300367780)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300367780);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, this, factory);
                    }, $EXxBNk ??= {"r":65537,"n":"","d":5400484,"h":0,"f":17825794}), 0, "EnergyMeterDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\Settings_EnergyMeterDeviceHardwareSettings_LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "EnergyMeterDeviceHardwareSettingsTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300367780)
            
            //--TRIMMABLE-BOUNDARY-START(12890302372)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890302372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CurrentTransformerRatio"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings.$type, $.$discardRef(), "CurrentTransformerRatio", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CurrentTransformerRatio")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "CurrentTransformerRatio";
                        $i1.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single), ($.$cast(target, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings)).CurrentTransformerRatio);
                        }, $ePBzOc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5400484,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CurrentTransformerRatio = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single));
                        }, $lhunYh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5400484,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BurdenResitor"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings.$type, $.$discardRef(), "BurdenResitor", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BurdenResitor")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "BurdenResitor";
                        $i3.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single), ($.$cast(target, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings)).BurdenResitor);
                        }, $QlNdqk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5400484,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.BurdenResitor = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single));
                        }, $xXLcig ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5400484,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890302372)
            
            //--TRIMMABLE-BOUNDARY-START(17185269668)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185269668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceTierType, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceFeatureType, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterServiceSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterServiceStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceScopeModel, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceScopeSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceScopeStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceModel, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettings, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceCommandModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceSendDataModel, LivingThing.Core.IOT.EnergyMeter.Common.Services.IEnergyMeterDeviceStatusHandler, LivingThing.Core.IOT.EnergyMeter.Common.Hubs.IEnergyMeterServiceHubClient, LivingThing.Core.IOT.EnergyMeter.Common.Services.IEnergyMeterRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).iSmartDeviceHardwareSettings));
                {
                    /*var*/ let _CurrentTransformerRatio = _target.CurrentTransformerRatio;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CurrentTransformerRatio"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _CurrentTransformerRatio, ($v) => _CurrentTransformerRatio = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single))))
                    {
                        _target.CurrentTransformerRatio = _CurrentTransformerRatio;
                    }
                }
                {
                    /*var*/ let _BurdenResitor = _target.BurdenResitor;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BurdenResitor"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _BurdenResitor, ($v) => _BurdenResitor = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single))))
                    {
                        _target.BurdenResitor = _BurdenResitor;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185269668)
            
            //--TRIMMABLE-BOUNDARY-START(8595335076)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595335076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595335076)
            
            static $h = 5400484;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890302372),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5400484,
      "h": 12890302372,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890302372),
//--TRIMMABLE-BOUNDARY-START(17185269668),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5269412,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5400484,
      "h": 17185269668,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185269668),
//--TRIMMABLE-BOUNDARY-START(8595335076),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5269412,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5400484,
      "h": 8595335076,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595335076)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300367780),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5400484,
      "h": 4300367780,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300367780)
  ],
  "h": 5400484
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Settings${separator}EnergyMeterDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5400484)
        
        

        //--TRIMMABLE-BOUNDARY-START(1992612)
        $asm.$cls(`$uUnI.LCIECM.EnergyMeterDeviceModelTypeDescriptor`, ($self) => class EnergyMeterDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296959908)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296959908);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uUnI.LCIECM.EnergyMeterDeviceModelTypeDescriptor.GenerateProperties($.$uUnI.LCIECM.EnergyMeterDeviceModel, this, factory);
                    }, $KYjIhk ??= {"r":65537,"n":"","d":1992612,"h":0,"f":17825794}), 0, "EnergyMeterDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.EnergyMeter.Common\\Models_EnergyMeterDeviceModel_LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceModelTypeDescriptorBuilder.g.cs", "EnergyMeterDeviceModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296959908)
            
            //--TRIMMABLE-BOUNDARY-START(12886894500)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886894500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DeviceFlags"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uUnI.LCIECM.EnergyMeterDeviceModel.$type, $.$discardRef(), "DeviceFlags", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DeviceFlags")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$uUnI.LCIECM.EnergyMeterDeviceFlags, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "DeviceFlags";
                        $i1.DelaredOn = "LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$uUnI.LCIECM.EnergyMeterDeviceFlags, ($.$cast(target, $.$uUnI.LCIECM.EnergyMeterDeviceModel)).DeviceFlags);
                        }, $YQfSdl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1992612,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uUnI.LCIECM.EnergyMeterDeviceModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DeviceFlags = value.AsEnumValue($.$uUnI.LCIECM.EnergyMeterDeviceFlags);
                        }, $DzWkrj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1992612,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886894500)
            
            //--TRIMMABLE-BOUNDARY-START(17181861796)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181861796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceTierType, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterServiceFeatureType, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterServiceSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterServiceStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceScopeModel, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceScopeSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceScopeStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceModel, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceSettings, LivingThing.Core.IOT.EnergyMeter.Common.Settings.EnergyMeterDeviceHardwareSettings, LivingThing.Core.IOT.EnergyMeter.Common.States.EnergyMeterDeviceStates, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceStatusModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceCommandModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceReceivedDataModel, LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceSendDataModel, LivingThing.Core.IOT.EnergyMeter.Common.Services.IEnergyMeterDeviceStatusHandler, LivingThing.Core.IOT.EnergyMeter.Common.Hubs.IEnergyMeterServiceHubClient, LivingThing.Core.IOT.EnergyMeter.Common.Services.IEnergyMeterRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService).IOTDeviceModel));
                {
                    /*var*/ let _DeviceFlags = _target.DeviceFlags;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DeviceFlags"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceFlags));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$uUnI.LCIECM.EnergyMeterDeviceFlags, () => _DeviceFlags, ($v) => _DeviceFlags = $v, null, true)))
                    {
                        _target.DeviceFlags = _DeviceFlags;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181861796)
            
            //--TRIMMABLE-BOUNDARY-START(8591927204)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591927204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uUnI.LCIECM.EnergyMeterDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uUnI.LCIECM.EnergyMeterDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceModel)))
                {
                    /*var*/ let result = $.$uUnI.LCIECM.EnergyMeterDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uUnI.LCIECM.EnergyMeterDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uUnI.LCIECM.EnergyMeterDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591927204)
            
            static $h = 1992612;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886894500),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1992612,
      "h": 12886894500,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886894500),
//--TRIMMABLE-BOUNDARY-START(17181861796),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1861540,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1992612,
      "h": 17181861796,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181861796),
//--TRIMMABLE-BOUNDARY-START(8591927204),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1861540,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1992612,
      "h": 8591927204,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591927204)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296959908),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1992612,
      "h": 4296959908,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296959908)
  ],
  "h": 1992612
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uUnI.LCIECM.EnergyMeterDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.Models.EnergyMeterDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}Models${separator}EnergyMeterDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1992612)
        
        

        //--TRIMMABLE-BOUNDARY-START(550820)
        $asm.$cls(`$uUnI.LCIEC.EnergyMeterSmartDevice`, ($self) => class EnergyMeterSmartDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings, $.$uUnI.LCIECM.EnergyMeterReceivedStatus).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(8590485412)
            $ctor$3(/*EnergyMeterDashboardScope*/ scope, /*EnergyMeterDeviceModel*/ model)
            {
                super.$ctor$3($.$cast($.$sl.SL.Enumerable.First$1($.$XBGm.LCICI.IIOTDeviceFamily, scope.Factory.DeviceFamilies), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$uUnI.LCIEC.EnergyMeterSmartDevice)), scope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590485412);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590485412)
            
            //--TRIMMABLE-BOUNDARY-START(4295518116)
            $ctor$2(/*IIOTDeviceFamily<EnergyMeterSmartDevice>*/ family, /*IIOTDeviceScope*/ scope, /*EnergyMeterDeviceModel*/ model)
            {
                super.$ctor$3(family, scope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295518116);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295518116)
            
            static $h = 550820;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings, $.$uUnI.LCIECM.EnergyMeterReceivedStatus).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590485412),
    {
      "p": [
        {
          "n": "scope",
          "p": 157604
        },
        {
          "n": "model",
          "p": 1861540
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 550820,
      "h": 8590485412,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590485412),
//--TRIMMABLE-BOUNDARY-START(4295518116),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$uUnI.LCIEC.EnergyMeterSmartDevice).$h
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 1861540
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 550820,
      "h": 4295518116,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295518116)
  ],
  "h": 550820
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.EnergyMeterSmartDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}EnergyMeterSmartDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(550820)
        
        

        //--TRIMMABLE-BOUNDARY-START(354212)
        $asm.$cls(`$uUnI.LCIEC.EnergyMeterDeviceDefinition`, ($self) => class EnergyMeterDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings, $.$uUnI.LCIECM.EnergyMeterReceivedStatus)
        {
            //--TRIMMABLE-BOUNDARY-START(4295321508)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295321508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295321508)
            
            //--TRIMMABLE-BOUNDARY-START(4295321508)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295321508)
            
            static $h = 354212;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings, $.$uUnI.LCIECM.EnergyMeterReceivedStatus); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295321508),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 354212,
      "h": 4295321508,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295321508)
  ],
  "h": 354212
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.EnergyMeterDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}EnergyMeterDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(354212)
        
        

        //--TRIMMABLE-BOUNDARY-START(419748)
        $asm.$cls(`$uUnI.LCIEC.EnergyMeterDeviceFamily`, ($self) => class EnergyMeterDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings).ConfiguredServerDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4295387044)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<EnergyMeterDeviceReceivedDataModel, EnergyMeterDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<EnergyMeterDeviceReceivedDataModel, EnergyMeterDeviceStatusModel>*/ converter)
            {
                super.$ctor$3(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295387044);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295387044)
            
            //--TRIMMABLE-BOUNDARY-START(55834994596)
            /*IOTDeviceDescriptor */ GetDescriptorVariant(/*IIOTDeviceModel*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834994596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let dev = $.$cast(device, $.$uUnI.LCIECM.EnergyMeterDeviceModel);
                /*var*/ let descriptor = super.GetDescriptorVariant(device);
                if (((dev.DeviceFlags & (1/*EnergyMeterDeviceFlags.LogAvailability*/)) == (1/*EnergyMeterDeviceFlags.LogAvailability*/)) || ((dev.DeviceFlags & (2/*EnergyMeterDeviceFlags.LogUsage*/)) == (2/*EnergyMeterDeviceFlags.LogUsage*/)))
                {
                    /*var*/ let cloneDescriptor = descriptor.Clone();
                    let $en1 = cloneDescriptor.CommunicationProtocol.MessageTypes.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let status = $en1.SCG$IEnumerator$$$Current;
                        {
                            /*var*/ let originalStatus = $.$sl.SL.Enumerable.Single($.$XBGm.LCICPM.IOTDeviceProtocolStatusMessageTypeDescriptor, descriptor.CommunicationProtocol.MessageTypes, new ($.$$.S.Func$$$($.$XBGm.LCICPM.IOTDeviceProtocolStatusMessageTypeDescriptor, $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                            {
                                return d.Name === status.Name;
                            }, $cWkMah ??= {"r":262145,"p":[{"n":"d","p":49386897}],"n":"","d":419748,"h":0,"f":17825794}));
                            if (((dev.DeviceFlags & (1/*EnergyMeterDeviceFlags.LogAvailability*/)) == (1/*EnergyMeterDeviceFlags.LogAvailability*/)))
                            {
                                status.DataPoints = $.$sl.SL.Enumerable.ToList($.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor, $.$sl.SL.Enumerable.Where($.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor, status.DataPoints, new ($.$$.S.Func$$$($.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                                {
                                    return s.Name === "AvailablePhase";
                                }, $RQpscb ??= {"r":262145,"p":[{"n":"s","p":36541841}],"n":"","d":419748,"h":0,"f":17825794})));
                            }
                            else if (((dev.DeviceFlags & (2/*EnergyMeterDeviceFlags.LogUsage*/)) == (2/*EnergyMeterDeviceFlags.LogUsage*/)))
                            {
                                status.DataPoints = $.$sl.SL.Enumerable.ToList($.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor, $.$sl.SL.Enumerable.Where($.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor, status.DataPoints, new ($.$$.S.Func$$$($.$XBGm.LCICM.IOTDeviceDataPointPropertyDescriptor, $.$$.S.Boolean))().$ctor(this,  (/**/ s) =>
                                {
                                    return s.Name !== "AvailablePhase";
                                }, $gwglZh ??= {"r":262145,"p":[{"n":"s","p":36541841}],"n":"","d":419748,"h":0,"f":17825794})));
                            }
                        }
                    }
                    descriptor = cloneDescriptor;
                }
                return descriptor;
            }
            //--TRIMMABLE-BOUNDARY-END(55834994596)
            
            //--TRIMMABLE-BOUNDARY-START(73014863780)
            /*GatewayDeviceModBusType */ get Type()
            {
                return 2/*GatewayDeviceModBusType.InputRegister*/;
            }
            //--TRIMMABLE-BOUNDARY-END(73014863780)
            
            //--TRIMMABLE-BOUNDARY-START(8590354340)
            /*byte */ get BusAddress()
            {
                return 1;
            }
            //--TRIMMABLE-BOUNDARY-END(8590354340)
            
            //--TRIMMABLE-BOUNDARY-START(64424929188)
            /*ushort */ get RegisterAddress()
            {
                return 35550;
            }
            //--TRIMMABLE-BOUNDARY-END(64424929188)
            
            //--TRIMMABLE-BOUNDARY-START(60129961892)
            /*string */ get Key()
            {
                return "pmr";
            }
            //--TRIMMABLE-BOUNDARY-END(60129961892)
            
            //--TRIMMABLE-BOUNDARY-START(68719896484)
            /*byte */ get RegisterCount()
            {
                return 12;
            }
            //--TRIMMABLE-BOUNDARY-END(68719896484)
            
            //--TRIMMABLE-BOUNDARY-START(38666696255)
            //Generated interface implemetation for LivingThing.Core.IOT.Devices.Gateway.Models.IGatewayModBusDeviceConfiguration.Type.get
            get LCIDGM$1$IGatewayModBusDeviceConfiguration$Type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51551598143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Type;
            }
            //--TRIMMABLE-BOUNDARY-END(38666696255)
            
            //--TRIMMABLE-BOUNDARY-START(12896892479)
            //Generated interface implemetation for LivingThing.Core.IOT.Devices.Gateway.Models.IGatewayModBusDeviceConfiguration.BusAddress.get
            get LCIDGM$1$IGatewayModBusDeviceConfiguration$BusAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4306957887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BusAddress;
            }
            //--TRIMMABLE-BOUNDARY-END(12896892479)
            
            //--TRIMMABLE-BOUNDARY-START(21486827071)
            //Generated interface implemetation for LivingThing.Core.IOT.Devices.Gateway.Models.IGatewayModBusDeviceConfiguration.RegisterAddress.get
            get LCIDGM$1$IGatewayModBusDeviceConfiguration$RegisterAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42961663551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisterAddress;
            }
            //--TRIMMABLE-BOUNDARY-END(21486827071)
            
            //--TRIMMABLE-BOUNDARY-START(30076761663)
            //Generated interface implemetation for LivingThing.Core.IOT.Devices.Gateway.Models.IGatewayModBusDeviceConfiguration.RegisterCount.get
            get LCIDGM$1$IGatewayModBusDeviceConfiguration$RegisterCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47256630847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisterCount;
            }
            //--TRIMMABLE-BOUNDARY-END(30076761663)
            
            //--TRIMMABLE-BOUNDARY-START(8601859647)
            //Generated interface implemetation for LivingThing.Core.IOT.Devices.Gateway.Models.IGatewayDeviceConfiguration.Key.get
            get LCIDGM$1$IGatewayDeviceConfiguration$Key()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12896826943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Key;
            }
            //--TRIMMABLE-BOUNDARY-END(8601859647)
            
            static $h = 419748;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings).ConfiguredServerDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73014863780),
    {
      "p": 5830207,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540027300,
        "f": 50331649
      },
      "n": "Type",
      "d": 419748,
      "h": 73014863780,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014863780),
//--TRIMMABLE-BOUNDARY-START(8590354340),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180288932,
        "f": 50331649
      },
      "n": "BusAddress",
      "d": 419748,
      "h": 8590354340,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590354340),
//--TRIMMABLE-BOUNDARY-START(64424929188),
    {
      "p": 589825,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360158116,
        "f": 50331649
      },
      "n": "RegisterAddress",
      "d": 419748,
      "h": 64424929188,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424929188),
//--TRIMMABLE-BOUNDARY-START(60129961892),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770223524,
        "f": 50331649
      },
      "n": "Key",
      "d": 419748,
      "h": 60129961892,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129961892),
//--TRIMMABLE-BOUNDARY-START(68719896484),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950092708,
        "f": 50331649
      },
      "n": "RegisterCount",
      "d": 419748,
      "h": 68719896484,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719896484)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55834994596),
    {
      "r": 36803985,
      "p": [
        {
          "n": "device",
          "p": 27432337
        }
      ],
      "n": "GetDescriptorVariant",
      "d": 419748,
      "h": 55834994596,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55834994596)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295387044),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 419748,
      "h": 4295387044,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295387044)
  ],
  "h": 419748
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$uUnI.LCIEC.EnergyMeterSmartDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$XBGm.LCICI.IIOTServerDeviceFamily, $.$NzWm.LCIDGM$1.IGatewayModBusDeviceConfiguration$$($.$uUnI.LCIEC.EnergyMeterSmartDevice), $.$NzWm.LCIDGM$1.IGatewayModBusDeviceConfiguration, $.$NzWm.LCIDGM$1.IGatewayDeviceConfiguration ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.EnergyMeterDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}EnergyMeterDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(419748)
        
        

        //--TRIMMABLE-BOUNDARY-START(157604)
        $asm.$cls(`$uUnI.LCIEC.EnergyMeterDashboardScope`, ($self) => class EnergyMeterDashboardScope extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings, $.$uUnI.LCIECM.EnergyMeterReceivedStatus).iSmartGenericDeviceServiceAsScope
        {
            //--TRIMMABLE-BOUNDARY-START(8590092196)
            $ctor$3(/*EnergyMeterDashboardScopeFactory*/ factory, /*EnergyMeterServiceModel*/ service)
            {
                super.$ctor$5(factory, service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590092196);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590092196)
            
            //--TRIMMABLE-BOUNDARY-START(4295124900)
            $ctor$2(/*EnergyMeterDashboardScopeFactory*/ factory, /*EnergyMeterDeviceScopeModel*/ scope, /*IEnumerable<EnergyMeterDeviceModel>*/ _devices)
            {
                super.$ctor$4(factory, scope, _devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295124900);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295124900)
            
            //--TRIMMABLE-BOUNDARY-START(12885059492)
            /*Task<EnergyMeterSmartDevice?> */ GetDevice(/*EnergyMeterDeviceModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885059492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$uUnI.LCIEC.EnergyMeterSmartDevice, new $.$uUnI.LCIEC.EnergyMeterSmartDevice().$ctor$3(this, model));
            }
            //--TRIMMABLE-BOUNDARY-END(12885059492)
            
            static $h = 157604;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings, $.$uUnI.LCIECM.EnergyMeterReceivedStatus).iSmartGenericDeviceServiceAsScope; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885059492),
    {
      "r": $.$$.STT.Task$$($.$uUnI.LCIEC.EnergyMeterSmartDevice).$h,
      "p": [
        {
          "n": "model",
          "p": 1861540
        }
      ],
      "n": "GetDevice",
      "d": 157604,
      "h": 12885059492,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885059492)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590092196),
    {
      "p": [
        {
          "n": "factory",
          "p": 223140
        },
        {
          "n": "service",
          "p": 3368868
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 157604,
      "h": 8590092196,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590092196),
//--TRIMMABLE-BOUNDARY-START(4295124900),
    {
      "p": [
        {
          "n": "factory",
          "p": 223140
        },
        {
          "n": "scope",
          "p": 2385828
        },
        {
          "n": "_devices",
          "p": $.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 157604,
      "h": 4295124900,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295124900)
  ],
  "h": 157604
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScope, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.EnergyMeterDashboardScope`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}EnergyMeterDashboardScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(157604)
        
        

        //--TRIMMABLE-BOUNDARY-START(223140)
        $asm.$cls(`$uUnI.LCIEC.EnergyMeterDashboardScopeFactory`, ($self) => class EnergyMeterDashboardScopeFactory extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings, $.$uUnI.LCIECM.EnergyMeterReceivedStatus).iSmartGenericServerDeviceScopeFactory
        {
            //--TRIMMABLE-BOUNDARY-START(8590157732)
            $ctor$1(/*ServiceFactory*/ services, /*IConfigurationParser*/ config, /*IScopeStore*/ scopeStore, /*IDeviceStore*/ deviceStore, /*IIOTDeviceFamily<EnergyMeterSmartDevice>*/ family, /*IServerRemoteService*/ serverRemoteService, /*IHubConnector<IEnergyMeterServiceHubClient>*/ hubConnector, /*EnergyMeterDataConverter*/ converter)
            {
                super.$ctor$3(services, config, scopeStore, deviceStore, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCICI.IIOTDeviceFamily$$($.$uUnI.LCIEC.EnergyMeterSmartDevice)), [family], null, null), serverRemoteService, hubConnector);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590157732);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Converter = converter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590157732)
            
            //--TRIMMABLE-BOUNDARY-START(12885125028)
            /*EnergyMeterDataConverter*/ Converter = null;
            //--TRIMMABLE-BOUNDARY-END(12885125028)
            
            //--TRIMMABLE-BOUNDARY-START(17180092324)
            /*string */ get DashboardLink()
            {
                return "EnergyMeter";
            }
            //--TRIMMABLE-BOUNDARY-END(17180092324)
            
            //--TRIMMABLE-BOUNDARY-START(38654928804)
            /*EnergyMeterDashboardScope */ GetScope(/*EnergyMeterDeviceScopeModel*/ scope, /*IEnumerable<EnergyMeterDeviceModel>*/ devices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654928804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$uUnI.LCIEC.EnergyMeterDashboardScope().$ctor$2(this, scope, devices);
            }
            //--TRIMMABLE-BOUNDARY-END(38654928804)
            
            //--TRIMMABLE-BOUNDARY-START(42949896100)
            /*EnergyMeterDashboardScope? */ GetScope$1(/*EnergyMeterServiceModel*/ service)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949896100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$uUnI.LCIEC.EnergyMeterDashboardScope().$ctor$3(this, service);
            }
            //--TRIMMABLE-BOUNDARY-END(42949896100)
            
            static $h = 223140;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$uUnI.LCIEC.EnergyMeterSmartDevice, $.$uUnI.LCIECM.EnergyMeterServiceModel, $.$uUnI.LCIECM.EnergyMeterServiceTierType, $.$uUnI.LCIECM.EnergyMeterServiceFeatureType, $.$uUnI.LCIECS$1.EnergyMeterServiceSettings, $.$uUnI.LCIECS$2.EnergyMeterServiceStates, $.$uUnI.LCIECM.EnergyMeterDeviceScopeModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceScopeSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceScopeStates, $.$uUnI.LCIECM.EnergyMeterDeviceModel, $.$uUnI.LCIECS$1.EnergyMeterDeviceSettings, $.$uUnI.LCIECS$1.EnergyMeterDeviceHardwareSettings, $.$uUnI.LCIECS$2.EnergyMeterDeviceStates, $.$uUnI.LCIECM.EnergyMeterDeviceStatusModel, $.$uUnI.LCIECM.EnergyMeterDeviceCommandModel, $.$uUnI.LCIECM.EnergyMeterDeviceReceivedDataModel, $.$uUnI.LCIECM.EnergyMeterDeviceSendDataModel, $.$uUnI.LCIECS.IEnergyMeterDeviceStatusHandler, $.$uUnI.LCIECH.IEnergyMeterServiceHubClient, $.$uUnI.LCIECS.IEnergyMeterRemoteService, $.$uUnI.LCIECS$1.EnergyMeterDeviceGlobalSettings, $.$uUnI.LCIECM.EnergyMeterReceivedStatus).iSmartGenericServerDeviceScopeFactory; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885125028),
    {
      "p": 288676,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770026916,
        "f": 50331649
      },
      "n": "Converter",
      "d": 223140,
      "h": 12885125028,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885125028),
//--TRIMMABLE-BOUNDARY-START(17180092324),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359961508,
        "f": 50364417
      },
      "n": "DashboardLink",
      "d": 223140,
      "h": 17180092324,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180092324)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38654928804),
    {
      "r": 157604,
      "p": [
        {
          "n": "scope",
          "p": 2385828
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$uUnI.LCIECM.EnergyMeterDeviceModel).$h
        }
      ],
      "n": "GetScope",
      "d": 223140,
      "h": 38654928804,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38654928804),
//--TRIMMABLE-BOUNDARY-START(42949896100),
    {
      "r": 157604,
      "p": [
        {
          "n": "service",
          "p": 3368868
        }
      ],
      "n": "GetScope",
      "o": "@$1",
      "d": 223140,
      "h": 42949896100,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42949896100)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590157732),
    {
      "p": [
        {
          "n": "services",
          "p": 62949718
        },
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "scopeStore",
          "p": 1545617
        },
        {
          "n": "deviceStore",
          "p": 1283473
        },
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$uUnI.LCIEC.EnergyMeterSmartDevice).$h
        },
        {
          "n": "serverRemoteService",
          "p": 1309651
        },
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$($.$uUnI.LCIECH.IEnergyMeterServiceHubClient).$h
        },
        {
          "n": "converter",
          "p": 288676
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 223140,
      "h": 8590157732,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590157732)
  ],
  "h": 223140
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceScopeFactory, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.EnergyMeter.Common.EnergyMeterDashboardScopeFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}EnergyMeter${separator}Common${separator}EnergyMeterDashboardScopeFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(223140)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor", "NetJs.LivingThing.Core.IOT.Devices.Gateway"));
})();
//--TRIMMABLE-BOUNDARY-END(26532)
