
//--TRIMMABLE-BOUNDARY-START(48013)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mnhh, $maw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej, $NzWm, $cCKL, $MZKr, $uUnI, $eHSC, $mXnX, $zxUu) {
    "use strict";
    let _;
    let $jDtHNi;
    let $QwLTdh;
    let $JXFmJc;
    let $eWcCPg;
    let $gkzuGd;
    let $KiQkka;
    let $cDXZoa;
    let $Ousolj;
    let $dFRAdk;
    let $YYQLcb;
    let $VIhMzj;
    let $VvFWjh;
    let $IlSMbi;
    let $YpIcqg;
    let $ThnANd;
    let $PuyOBa;
    let $SBmwxa;
    let $soLybj;
    let $MEQZcg;
    let $xUxDKf;
    let $CPSpfa;
    let $InYOah;
    let $RzDoAi;
    let $dMpDMi;
    let $gIbBvg;
    let $yMSsHe;
    let $GXkjQg;
    let $igkNgb;
    let $CcRTXd;
    let $YWcjSi;
    let $pAFqyh;
    let $FpKkyk;
    let $bUSbyc;
    let $GUanDk;
    let $SbGKEk;
    let $qqMove;
    let $FKtJDk;
    let $vgjlIi;
    let $mRLMCc;
    let $dhRltj;
    let $nBskmb;
    let $JnCAxk;
    let $lYbHSc;
    let $qTkSme;
    let $Vlftag;
    let $btrvKc;
    let $hxNFdf;
    let $bunxSi;
    let $rTPLNj;
    let $JBfSll;
    let $WHLnCj;
    let $ixEHyk;
    let $XrZBib;
    let $ZPuDqk;
    let $jNgPVg;
    let $dtzmLh;
    let $jPXlPf;
    let $pUeuFc;
    let $GcFkbg;
    let $ugMDBk;
    let $jFFtIc;
    let $YlEiQf;
    let $fmNmDa;
    let $hzOeQa;
    let $MpheOe;
    let $ZmOghf;
    let $gfYOnd;
    let $KQFOIe;
    let $JBYgmj;
    let $tIrkRa;
    let $NkktUi;
    let $HegESb;
    let $RycsVa;
    let $JrZQBb;
    let $bqcGwh;
    let $leYEfc;
    let $HZfbWj;
    let $bZhrYg;
    let $jkilCk;
    let $mgRlRc;
    let $NfrKqg;
    let $edAPKb;
    let $gszbcf;
    let $oyqSkl;
    let $sQmoCf;
    let $CQUQoh;
    let $fHqbUd;
    let $tSRgWe;
    let $vsddPj;
    let $ytwrfd;
    let $ITrASh;
    let $ShSmPh;
    let $JbglVj;
    let $TbQxLa;
    let $Wjakwg;
    let $tHJxPi;
    let $MDdDRj;
    let $NjCSqj;
    let $kgwjNh;
    let $rNZyxc;
    let $otyofb;
    let $Kemtkj;
    let $hQMLka;
    let $nMEqBk;
    let $tWBxvc;
    let $BTTEdg;
    let $rDMEha;
    let $vgzPil;
    let $bqPAZe;
    let $CxhEvb;
    let $OMuSia;
    let $VBqSWj;
    let $OeErcc;
    let $drjKog;
    let $AZJFBj;
    let $hkcXha;
    let $ZSsLQk;
    let $GERshj;
    let $MVYUse;
    let $ezKMbd;
    let $zUVkvg;
    let $FEmkbk;
    let $bOczgg;
    let $vhWulc;
    let $PuOAae;
    let $cjZnIa;
    let $rwTTZf;
    let $kamyqa;
    let $uvzbvj;
    let $ZYKUoc;
    let $lAyFSj;
    let $yaCCZd;
    let $buxjse;
    let $MSSJId;
    let $Qzxrjd;
    let $PHbZfh;
    let $uNiYyd;
    let $WWwgWh;
    let $zTmDOh;
    let $XbZmRi;
    let $hSHIhi;
    let $Kfeawh;
    let $zRVNSk;
    let $TPOyxk;
    let $qbmtke;
    let $HnvESj;
    let $JVCSvj;
    let $nuLFjl;
    let $YQoFgb;
    let $mhvNij;
    let $aRJLvi;
    let $JsRWka;
    let $NzsWfe;
    let $khLCbj;
    let $UnwPMe;
    let $YrrYqf;
    let $pMKVvh;
    let $giPMOj;
    let $eLgXke;
    let $HteFEc;
    let $tgChWk;
    let $bcrKcc;
    let $KSxhwg;
    let $DtPkjb;
    let $QJsXja;
    let $uwiyEh;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.PowerHouse.Client.Blazor", 
    {
  "h": 48013,
  "f": "LivingThing.Core.IOT.PowerHouse.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.PowerHouse.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.PowerHouse.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(244621)
        $asm.$cls(`$qKfs.LCIPC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295211917)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295211917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$qKfs.LCIPC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295211917)
            
            static $h = 244621;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295211917),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 244621,
      "h": 4295211917,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295211917)
  ],
  "h": 244621
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(244621)
        
        

        //--TRIMMABLE-BOUNDARY-START(375693)
        $asm.$cls(`$qKfs.LCIPCI.Startup`, ($self) => class Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295342989)
            static /*void */ AddPowerHouseIntegrations(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295342989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICS$1.IIOTServicePageProvider, $.$qKfs.LCIPCI.AppPageProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295342989)
            
            static $h = 375693;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295342989),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddPowerHouseIntegrations",
      "d": 375693,
      "h": 4295342989,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295342989)
  ],
  "h": 375693
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Client.Integrations.Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Client${separator}Integrations${separator}Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(375693)
        
        

        //--TRIMMABLE-BOUNDARY-START(506765)
        $asm.$cls(`$qKfs.LCIPC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590441357)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590441357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$qKfs.LCIPCP.App, "LivingThing.Core.IOT.PowerHouse.Client", "Pages\\App", "App", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/PowerHouse", "/PowerHouse/{Page}", "/PowerHouse/{Page}/{Action}", "/PowerHouse/App", "/PowerHouse/App/{Page}", "/PowerHouse/App/{Page}/{Action}" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590441357)
            
            //--TRIMMABLE-BOUNDARY-START(4295474061)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295474061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295474061)
            
            //--TRIMMABLE-BOUNDARY-START(4295474061)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295474061)
            
            static $h = 506765;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590441357),
    {
      "r": 65537,
      "n": "Build",
      "d": 506765,
      "h": 8590441357,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590441357)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295474061),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 506765,
      "h": 4295474061,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295474061)
  ],
  "h": 506765
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Client.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Client${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(506765)
        
        

        //--TRIMMABLE-BOUNDARY-START(113549)
        $asm.$cls(`$qKfs._LCIPCPA.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295080845)
            static /*void */ CreateChart_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::System.Func<global::System.Int32, T, global::System.String>*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Client.Components.Charts.ChartFeatures*/ __arg2, /*int*/ __seq3, /*global::System.String*/ __arg3, /*int*/ __seq4, /*global::System.String*/ __arg4, /*int*/ __seq5, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.Charts.ChartYAxis<T>>>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295080845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "XAxis", __arg1);
                __builder.AddComponentParameter(__seq2, "ChartFeatures", $.$box(__arg2, $.$hDPm.LCFCCC$3.ChartFeatures));
                __builder.AddComponentParameter(__seq3, "FontColor", __arg3);
                __builder.AddComponentParameter(__seq4, "Class", __arg4);
                __builder.AddComponentParameter(__seq5, "ChildContent", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295080845)
            
            //--TRIMMABLE-BOUNDARY-START(8590048141)
            static /*void */ CreateChart_1(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::System.Func<global::System.Int32, T, global::System.String>*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Client.Components.Charts.ChartFeatures*/ __arg2, /*int*/ __seq3, /*global::System.String*/ __arg3, /*int*/ __seq4, /*global::System.String*/ __arg4, /*int*/ __seq5, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.Charts.ChartYAxis<T>>>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590048141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "XAxis", __arg1);
                __builder.AddComponentParameter(__seq2, "ChartFeatures", $.$box(__arg2, $.$hDPm.LCFCCC$3.ChartFeatures));
                __builder.AddComponentParameter(__seq3, "FontColor", __arg3);
                __builder.AddComponentParameter(__seq4, "Class", __arg4);
                __builder.AddComponentParameter(__seq5, "ChildContent", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590048141)
            
            //--TRIMMABLE-BOUNDARY-START(12885015437)
            static /*void */ CreateChart_2(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::System.Func<global::System.Int32, T, global::System.String>*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Client.Components.Charts.ChartFeatures*/ __arg2, /*int*/ __seq3, /*global::System.String*/ __arg3, /*int*/ __seq4, /*global::System.String*/ __arg4, /*int*/ __seq5, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.Charts.ChartYAxis<T>>>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885015437);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "XAxis", __arg1);
                __builder.AddComponentParameter(__seq2, "ChartFeatures", $.$box(__arg2, $.$hDPm.LCFCCC$3.ChartFeatures));
                __builder.AddComponentParameter(__seq3, "FontColor", __arg3);
                __builder.AddComponentParameter(__seq4, "Class", __arg4);
                __builder.AddComponentParameter(__seq5, "ChildContent", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12885015437)
            
            //--TRIMMABLE-BOUNDARY-START(17179982733)
            static /*void */ CreateChart_3(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::System.Func<global::System.Int32, T, global::System.String>*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Client.Components.Charts.ChartFeatures*/ __arg2, /*int*/ __seq3, /*global::System.String*/ __arg3, /*int*/ __seq4, /*global::System.String*/ __arg4, /*int*/ __seq5, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.Charts.ChartYAxis<T>>>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179982733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "XAxis", __arg1);
                __builder.AddComponentParameter(__seq2, "ChartFeatures", $.$box(__arg2, $.$hDPm.LCFCCC$3.ChartFeatures));
                __builder.AddComponentParameter(__seq3, "FontColor", __arg3);
                __builder.AddComponentParameter(__seq4, "Class", __arg4);
                __builder.AddComponentParameter(__seq5, "ChildContent", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17179982733)
            
            static $h = 113549;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295080845),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (T) => $.$$.S.Func$$$$($.$$.S.Int32, T, $.$$.S.String).$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 9328298
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 1310721
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": 1310721
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCC$3.ChartYAxis$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateChart_0",
      "d": 113549,
      "h": 4295080845,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295080845),
//--TRIMMABLE-BOUNDARY-START(8590048141),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (T) => $.$$.S.Func$$$$($.$$.S.Int32, T, $.$$.S.String).$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 9328298
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 1310721
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": 1310721
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCC$3.ChartYAxis$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateChart_1",
      "d": 113549,
      "h": 8590048141,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590048141),
//--TRIMMABLE-BOUNDARY-START(12885015437),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (T) => $.$$.S.Func$$$$($.$$.S.Int32, T, $.$$.S.String).$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 9328298
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 1310721
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": 1310721
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCC$3.ChartYAxis$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateChart_2",
      "d": 113549,
      "h": 12885015437,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885015437),
//--TRIMMABLE-BOUNDARY-START(17179982733),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (T) => $.$$.S.Func$$$$($.$$.S.Int32, T, $.$$.S.String).$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 9328298
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 1310721
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": 1310721
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCC$3.ChartYAxis$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateChart_3",
      "d": 113549,
      "h": 17179982733,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17179982733)
  ],
  "h": 113549
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.IOT.PowerHouse.Client.Pages.App.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Client${separator}Pages${separator}App${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(113549)
        
        

        //--TRIMMABLE-BOUNDARY-START(637837)
        $asm.$cls(`$qKfs.LCIPC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590572429)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590572429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$qKfs.LCIPCI.Startup.AddPowerHouseIntegrations(services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$qKfs.LCIPCV.PowerHousesViewModel, services);
                $.$sZVd.LCFCA.ClientApplicationExtension.AddApplication($.$qKfs.LCIPCP.App, services, (() =>
                {
                    //new $.$sZVd.LCFCA.ClientApplicationModel$$($.$qKfs.LCIPCP.App)()
                    const $t1 = $.$sZVd.LCFCA.ClientApplicationModel$$($.$qKfs.LCIPCP.App);
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Categories = $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "IOT" ], null, null);
                    $i1.Name = "PowerHouse";
                    $i1.Title = "PowerHouse";
                    $i1.Description = "IOT PowerHouse application";
                    $i1.Paths = $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "PowerHouse/App" ], null, null);
                    $i1.Theme = $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t2 = $.$fPer.LCFC.Theme;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.BackgroundColor = "#00AEFF";
                        $i2.ForegroundColor = "#FFFFFF";
                        return $i2;
                    })());
                    $i1.Icon = $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-power"/*MaterialDesignIconNames.Power*/);
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(8590572429)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$qKfs.LCIPC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295605133)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295605133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295605133)
            
            //--TRIMMABLE-BOUNDARY-START(4295605133)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295605133)
            
            static $h = 637837;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590572429),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 637837,
      "h": 8590572429,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590572429)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295605133),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 637837,
      "h": 4295605133,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295605133)
  ],
  "h": 637837
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(637837)
        
        

        //--TRIMMABLE-BOUNDARY-START(310157)
        $asm.$cls(`$qKfs.LCIPCI.AppPageProvider`, ($self) => class AppPageProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475146637)
            /*string */ get Name()
            {
                return "PowerHouse";
            }
            //--TRIMMABLE-BOUNDARY-END(21475146637)
            
            //--TRIMMABLE-BOUNDARY-START(17180179341)
            /*RenderFragment */ GetView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180179341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$qKfs.LCIPCP.App, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("BasePath", "");
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180179341)
            
            //--TRIMMABLE-BOUNDARY-START(8602878998)
            //Generated interface implemetation for LivingThing.Core.IOT.Client.Services.IIOTServicePageProvider.Name.get
            get LCICS$1$IIOTServicePageProvider$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17192813590);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8602878998)
            
            //--TRIMMABLE-BOUNDARY-START(12897846294)
            //Generated interface implemetation for LivingThing.Core.IOT.Client.Services.IIOTServicePageProvider.GetView()
            LCICS$1$IIOTServicePageProvider$GetView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12897846294);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12897846294)
            
            //--TRIMMABLE-BOUNDARY-START(4295277453)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295277453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295277453)
            
            //--TRIMMABLE-BOUNDARY-START(4295277453)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295277453)
            
            static $h = 310157;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475146637),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885212045,
        "f": 50331649
      },
      "n": "Name",
      "d": 310157,
      "h": 21475146637,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475146637)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180179341),
    {
      "r": 6881395,
      "n": "GetView",
      "d": 310157,
      "h": 17180179341,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180179341)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295277453),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 310157,
      "h": 4295277453,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295277453)
  ],
  "h": 310157
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICS$1.IIOTServicePageProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Client.Integrations.AppPageProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Client${separator}Integrations${separator}AppPageProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(310157)
        
        

        //--TRIMMABLE-BOUNDARY-START(441229)
        $asm.$cls(`$qKfs.LCIPC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180310413)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$qKfs.LCIPCP.App.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$qKfs.LCIPCP.App().$ctor$4();
                    }, $jDtHNi ??= {"r":2752627,"n":"","d":441229,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180310413)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295408525)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295408525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295408525)
            
            //--TRIMMABLE-BOUNDARY-START(4295408525)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295408525)
            
            static $h = 441229;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180310413),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885343117,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 441229,
      "h": 17180310413,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180310413)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295408525),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 441229,
      "h": 4295408525,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295408525)
  ],
  "h": 441229
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(441229)
        
        

        //--TRIMMABLE-BOUNDARY-START(834445)
        $asm.$cls(`$qKfs.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295801741)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295801741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295801741)
            
            //--TRIMMABLE-BOUNDARY-START(4295801741)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295801741)
            
            static $h = 834445;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295801741),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 834445,
      "h": 4295801741,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295801741)
  ],
  "h": 834445
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(834445)
        
        

        //--TRIMMABLE-BOUNDARY-START(899981)
        $asm.$cls(`$qKfs.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295867277)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295867277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295867277)
            
            //--TRIMMABLE-BOUNDARY-START(4295867277)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295867277)
            
            static $h = 899981;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295867277),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 899981,
      "h": 4295867277,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295867277)
  ],
  "h": 899981,
  "a": [
    {
      "t": 834445,
      "c": 4295801741
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(899981)
        
        

        //--TRIMMABLE-BOUNDARY-START(179085)
        $asm.$cls(`$qKfs.LCIPC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590113677)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590113677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590113677)
            
            //--TRIMMABLE-BOUNDARY-START(4295146381)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295146381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295146381)
            
            //--TRIMMABLE-BOUNDARY-START(4295146381)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295146381)
            
            static $h = 179085;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590113677),
    {
      "r": 65537,
      "n": "Execute",
      "d": 179085,
      "h": 8590113677,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590113677)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295146381),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 179085,
      "h": 4295146381,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295146381)
  ],
  "h": 179085
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(179085)
        
        

        //--TRIMMABLE-BOUNDARY-START(768909)
        $asm.$cls(`$qKfs.LCIPCV.PowerHouseViewModel`, ($self) => class PowerHouseViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(60130311053)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(60130311053)
            
            //--TRIMMABLE-BOUNDARY-START(51540376461)
            /*PowerHouseDeviceModel*/ Model = null;
            //--TRIMMABLE-BOUNDARY-END(51540376461)
            
            //--TRIMMABLE-BOUNDARY-START(73015212941)
            /*IEnumerable<PowerHouseDeviceStatusModel>*/ Statuses = null;
            //--TRIMMABLE-BOUNDARY-END(73015212941)
            
            //--TRIMMABLE-BOUNDARY-START(17180638093)
            $ctor$3(/*IServerRemoteService*/ server, /*PowerHouseDeviceModel*/ model)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180638093);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                    this.Model = model;
                    _ = this.Load();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180638093)
            
            //--TRIMMABLE-BOUNDARY-START(55835343757)
            /*ReportParameterModel*/ Parameter = null;
            //--TRIMMABLE-BOUNDARY-END(55835343757)
            
            //--TRIMMABLE-BOUNDARY-START(47245409165)
            /*ValueTask *//*async*/  Load()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245409165);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let service = null;
                            try
                            {
                                let $t2, $r2;
                                service = this.Server.LCFCR$IServerRemoteService$GetRemoteService($.$mXnX.LCIPCS.IPowerHouseRemoteService, null);
                                /*var*/ let data = ($t2 = service.LCFCS$3$IServiceProxy$$$Service.LCIPCS$IPowerHouseRemoteService$GetReport($.$with(new $.$fPer.LCFCD.DataFilter().$ctor$12(this.Model.Identifier), ($clone) =>
                                {
                                    $clone.StartDate = this.Parameter.From;
                                    $clone.EndDate = this.Parameter.To;
                                })), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                                this.Statuses = $.$sl.SL.Enumerable.ToList($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, data.Data);
                            }
                            finally
                            {
                                service?.S$IDisposable$Dispose();
                            }
                        });
                    }, $QwLTdh ??= {"r":181338113,"n":"","d":768909,"h":0,"f":17829890}), false, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(47245409165)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(73015212941)
                this.Statuses = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel), null, [0], null);
                //--TRIMMABLE-BOUNDARY-END(73015212941)
                
                //--TRIMMABLE-BOUNDARY-START(55835343757)
                this.Parameter = (() =>
                {
                    //new $.$fPer.LCFCR$1.ReportParameterModel()
                    const $t3 = $.$fPer.LCFCR$1.ReportParameterModel;
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.Range = 2/*DateRange.Today*/;
                    $i3.Interval = 1/*PeriodicInterval.Minutely*/;
                    return $i3;
                })();
                //--TRIMMABLE-BOUNDARY-END(55835343757)
                
            }
            static $h = 768909;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540376461),
    {
      "p": 997772,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770572685,
        "f": 50331649
      },
      "n": "Model",
      "d": 768909,
      "h": 51540376461,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540376461),
//--TRIMMABLE-BOUNDARY-START(73015212941),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950441869,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720245645,
        "f": 83886082
      },
      "n": "Statuses",
      "d": 768909,
      "h": 73015212941,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015212941),
//--TRIMMABLE-BOUNDARY-START(55835343757),
    {
      "p": 56068438,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360507277,
        "f": 50331649
      },
      "n": "Parameter",
      "d": 768909,
      "h": 55835343757,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835343757)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245409165),
    {
      "r": 181338113,
      "n": "Load",
      "d": 768909,
      "h": 47245409165,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(47245409165)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60130311053),
    {
      "t": 1309651,
      "n": "Server",
      "d": 768909,
      "h": 60130311053,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60130311053)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180638093),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "model",
          "p": 997772
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 768909,
      "h": 17180638093,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180638093)
  ],
  "h": 768909
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Client.ViewModel.PowerHouseViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Client${separator}ViewModel${separator}PowerHouseViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(768909)
        
        

        //--TRIMMABLE-BOUNDARY-START(703373)
        $asm.$cls(`$qKfs.LCIPCV.PowerHousesViewModel`, ($self) => class PowerHousesViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(64425212813)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(64425212813)
            
            //--TRIMMABLE-BOUNDARY-START(60130245517)
            /*PowerHouseServiceModel*/ Model = null;
            //--TRIMMABLE-BOUNDARY-END(60130245517)
            
            //--TRIMMABLE-BOUNDARY-START(8590637965)
            $ctor$3(/*IServerRemoteService*/ server)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590637965);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590637965)
            
            //--TRIMMABLE-BOUNDARY-START(12885605261)
            /*PowerHouseViewModel*/ current = null;
            //--TRIMMABLE-BOUNDARY-END(12885605261)
            
            //--TRIMMABLE-BOUNDARY-START(17180572557)
            /*PowerHouseViewModel */ get Current()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770507149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.current ?? $.$sl.SL.Enumerable.FirstOrDefault$3($.$qKfs.LCIPCV.PowerHouseViewModel, this.Houses);
            }
            /*PowerHouseViewModel */ set Current(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015147405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.current = value;
            }
            //--TRIMMABLE-BOUNDARY-END(17180572557)
            
            //--TRIMMABLE-BOUNDARY-START(85900049293)
            /*Task<bool> */ SetCurrent(/*PowerHouseViewModel*/ house)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900049293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Current = house;
                return $.$$.STT.Task.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(85900049293)
            
            //--TRIMMABLE-BOUNDARY-START(47245343629)
            /*IEnumerable<PowerHouseViewModel>*/ houses = null;
            //--TRIMMABLE-BOUNDARY-END(47245343629)
            
            //--TRIMMABLE-BOUNDARY-START(51540310925)
            /*IEnumerable<PowerHouseViewModel> */ get Houses()
            {
                return this.houses;
            }
            //--TRIMMABLE-BOUNDARY-END(51540310925)
            
            //--TRIMMABLE-BOUNDARY-START(55835278221)
            /*ValueTask *//*async*/  Load()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835278221);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            if (this.Model === null)
                            {
                                let service = null;
                                try
                                {
                                    let $t2, $r2;
                                    service = this.Server.LCFCR$IServerRemoteService$GetRemoteService($.$mXnX.LCIPCS.IPowerHouseRemoteService, null);
                                    /*var*/ let m = ($t2 = service.LCFCS$3$IServiceProxy$$$Service.LCFCCR$ISubscriptionBasedRemoteService$LivingThing$Core$IOT$PowerHouse$Common$Models$PowerHouseServiceModel$LoadServices(new $.$fPer.LCFCD.DataFilter().$ctor$1()), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                                    if (!$.$sl.SL.Enumerable.Any$1($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel), m.Data))
                                    {
                                        throw new $.$$.S.ApplicationException().$ctor$8("No active subscription to Power House");
                                    }
                                    this.houses = $.$sl.SL.Enumerable.ToArray($.$qKfs.LCIPCV.PowerHouseViewModel, $.$sl.SL.Enumerable.Select$1($.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$qKfs.LCIPCV.PowerHouseViewModel, $.$sl.SL.Enumerable.SelectMany$2($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$mXnX.LCIPCM.PowerHouseDeviceModel, m.Data, new ($.$$.S.Func$$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel), $.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceModel)))().$ctor(this,  (/*h*/ h) =>
                                    {
                                        return h.Service.Devices;
                                    }, $JXFmJc ??= {"r":$.$$.SCG.IEnumerable$$($.$mXnX.LCIPCM.PowerHouseDeviceModel).$h,"p":[{"n":"h","p":$.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$mXnX.LCIPCM.PowerHouseServiceModel).$h}],"n":"","d":703373,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceModel, $.$qKfs.LCIPCV.PowerHouseViewModel))().$ctor(this,  (/*d*/ d) =>
                                    {
                                        /*var*/ let h = new $.$qKfs.LCIPCV.PowerHouseViewModel().$ctor$3(this.Server, d);
                                        h.add_PropertyChanged(new $.$so.SC$1.PropertyChangedEventHandler().$ctor(this,  (/*s*/ s, /*e*/ e) =>
                                        {
                                            return this.RaisePropertyChanged$1("Load");
                                        }, $eWcCPg ??= {"r":65537,"p":[{"n":"s","p":131073},{"n":"e","p":1310738}],"n":"","d":703373,"h":0,"f":17825794}));
                                        return h;
                                    }, $gkzuGd ??= {"r":768909,"p":[{"n":"d","p":997772}],"n":"","d":703373,"h":0,"f":17825794})));
                                }
                                finally
                                {
                                    service?.S$IDisposable$Dispose();
                                }
                            }
                        });
                    }, $KiQkka ??= {"r":181338113,"n":"","d":703373,"h":0,"f":17829890}), false, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(55835278221)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(47245343629)
                this.houses = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$qKfs.LCIPCV.PowerHouseViewModel), null, [0], null);
                //--TRIMMABLE-BOUNDARY-END(47245343629)
                
            }
            static $h = 703373;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130245517),
    {
      "p": 2505100,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950376333,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605081997,
        "f": 83886082
      },
      "n": "Model",
      "d": 703373,
      "h": 60130245517,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130245517),
//--TRIMMABLE-BOUNDARY-START(17180572557),
    {
      "p": 768909,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770507149,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015147405,
        "f": 83886081
      },
      "n": "Current",
      "d": 703373,
      "h": 17180572557,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180572557),
//--TRIMMABLE-BOUNDARY-START(51540310925),
    {
      "p": $.$$.SCG.IEnumerable$$($.$qKfs.LCIPCV.PowerHouseViewModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360441741,
        "f": 50331649
      },
      "n": "Houses",
      "d": 703373,
      "h": 51540310925,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540310925)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85900049293),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "house",
          "p": 768909
        }
      ],
      "n": "SetCurrent",
      "d": 703373,
      "h": 85900049293,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900049293),
//--TRIMMABLE-BOUNDARY-START(55835278221),
    {
      "r": 181338113,
      "n": "Load",
      "d": 703373,
      "h": 55835278221,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(55835278221)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64425212813),
    {
      "t": 1309651,
      "n": "Server",
      "d": 703373,
      "h": 64425212813,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425212813),
//--TRIMMABLE-BOUNDARY-START(12885605261),
    {
      "t": 768909,
      "n": "current",
      "d": 703373,
      "h": 12885605261,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885605261),
//--TRIMMABLE-BOUNDARY-START(47245343629),
    {
      "t": $.$$.SCG.IEnumerable$$($.$qKfs.LCIPCV.PowerHouseViewModel).$h,
      "n": "houses",
      "d": 703373,
      "h": 47245343629,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245343629)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590637965),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 703373,
      "h": 8590637965,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590637965)
  ],
  "h": 703373
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Client.ViewModel.PowerHousesViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Client${separator}ViewModel${separator}PowerHousesViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(703373)
        
        

        //--TRIMMABLE-BOUNDARY-START(572301)
        $asm.$cls(`$qKfs.LCIPCP.App`, ($self) => class App extends $.$hDPm.LCFCC$1.BaseComponent$$($.$qKfs.LCIPCV.PowerHousesViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(85899918221)
            /*string */ get OptimizedComponentName()
            {
                return "app";
            }
            //--TRIMMABLE-BOUNDARY-END(85899918221)
            
            //--TRIMMABLE-BOUNDARY-START(120259656589)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259656589);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "BasePath":
                    this.BasePath = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(120259656589)
            
            //--TRIMMABLE-BOUNDARY-START(73015016333)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015016333);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.ViewModel = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qKfs.LCIPCV.PowerHousesViewModel, serviceProvider);
                this.RenderingProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IUIRenderingProvider, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(73015016333)
            
            //--TRIMMABLE-BOUNDARY-START(124554623885)
            /*PowerHousesViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(124554623885)
            
            //--TRIMMABLE-BOUNDARY-START(90194885517)
            /*IUIRenderingProvider*/ RenderingProvider = null;
            //--TRIMMABLE-BOUNDARY-END(90194885517)
            
            //--TRIMMABLE-BOUNDARY-START(21475408781)
            /*string*/ BasePath = null;
            //--TRIMMABLE-BOUNDARY-END(21475408781)
            
            //--TRIMMABLE-BOUNDARY-START(81604950925)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604950925);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.RenderingProvider.LCFCC$IUIRenderingProvider$IsPreRendering)
                {
                    _ = this.ViewModel.Load();
                }
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(81604950925)
            
            //--TRIMMABLE-BOUNDARY-START(68720049037)
            /*string */ HMS(/*TimeSpan*/ time)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720049037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (time.Hours > 0)
                {
                    return `${$.$strNN(time.Hours)}hr ${$.$strNN(time.Minutes)}min`;
                }
                return `${$.$strNN(time.Minutes)}min`;
            }
            //--TRIMMABLE-BOUNDARY-END(68720049037)
            
            //--TRIMMABLE-BOUNDARY-START(128849591181)
            /*string */ Wh(/*double*/ kwh)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849591181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (kwh > 999999.99)
                {
                    return (() =>
                    {
                        var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                        $handler.AppendFormatted($.$box((kwh / 1000), $.$$.S.Double), null, "N");
                        $handler.AppendLiteral(" MWh");
                        return $handler.ToStringAndClear                ();
                    })();
                }
                else 
                {
                    return (() =>
                    {
                        var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                        $handler.AppendFormatted($.$box(kwh, $.$$.S.Double), null, "N");
                        $handler.AppendLiteral(" kWh");
                        return $handler.ToStringAndClear                ();
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849591181)
            
            //--TRIMMABLE-BOUNDARY-START(77309983629)
            /*string */ Naira(/*double*/ kwh)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309983629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let naira = kwh * 24;
                return (() =>
                {
                    var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                    $handler.AppendLiteral("\u20A6");
                    $handler.AppendFormatted($.$box(naira, $.$$.S.Double), null, "N");
                    return $handler.ToStringAndClear            ();
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(77309983629)
            
            //--TRIMMABLE-BOUNDARY-START(30065343373)
            /*double */ FuelNaira(/*double*/ l)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065343373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let naira = l * 220;
                return naira;
            }
            //--TRIMMABLE-BOUNDARY-END(30065343373)
            
            //--TRIMMABLE-BOUNDARY-START(25770376077)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770376077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$macw.MACW.PageTitle, 0);
                __builder.AddAttribute$3(1, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$4(2, "Power Generator");
                }), $cDXZoa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":572301,"h":0,"f":17825794}));
                __builder.CloseComponent();
                //if (true)
                {
                    __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 3);
                    __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ | 128/*ApplicationFeatures.ToolBarBorder*/ | 64/*ApplicationFeatures.ToolBarShadow*/), $.$lJUR.LCFCS.ApplicationFeatures));
                    __builder.AddComponentParameter(5, "InitialViewIndex", "0");
                    __builder.AddComponentParameter(6, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.ViewModel));
                    __builder.AddComponentParameter(7, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(this.BasePath)));
                    __builder.AddAttribute$3(8, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.AddContent$4(9, "Power House / ");
                            /*LivingThing.Core.IOT.PowerHouse.Client.ViewModel.PowerHouseViewModel*/ let __ca1__;
                            /*LivingThing.Core.Frameworks.Common.Report.ReportParameterModel*/ let __ca2__;
                            /*string*/ let __ca3__;
                            __builder2.AddContent$4(10, ((__ca1__ = this.ViewModel.Current) !== null ? ((__ca2__ = __ca1__.Parameter) !== null ? ((__ca3__ = $.$$.S.Enum.ToStringT($.$fPer.LCFCDC.DateRange, $.$$.S.UInt32, __ca2__.Range)) !== null ? $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle(__ca3__) : null) : null) : null));
                            __builder2.AddContent$4(11, " / ");
                            __builder2.AddContent$3(12, $.$box((this.ViewModel.Current?.Parameter?.Interval ?? null), $.$fPer.LCFCDC.PeriodicInterval));
                        }, $Ousolj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                    }), $dFRAdk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(13, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCC$4.ClassIcon, 14);
                            __builder2.AddComponentParameter(15, "Class", "mdi mdi-engine-outline cl-primary");
                            __builder2.CloseComponent();
                        }, $YYQLcb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                    }), $VIhMzj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(16, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        let $en2 = this.ViewModel.Houses.SCG$IEnumerable$$$GetEnumerator();
                        while ($en2.SC$1$IEnumerator$MoveNext())
                        {
                            let _house = $en2.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let house = _house;
                                /*var*/ let utilities = $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetUtilities(house.Statuses);
                                /*var*/ let generators = $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetGenerators(house.Statuses);
                                /*var*/ let tanks = $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTanks(house.Statuses);
                                __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 17);
                                __builder2.AddComponentParameter(18, "OnShowing", "()=>ViewModel.SetCurrent(house)");
                                __builder2.AddComponentParameter(19, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, house.Model.Name ?? house.Model.Identifier.ToString()));
                                __builder2.AddComponentParameter(20, "Class", "pd");
                                __builder2.AddAttribute$3(21, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                    {
                                        __builder3.AddContent$4(22, house.Model.Name ?? "Power House");
                                    }, $VvFWjh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                }), $IlSMbi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                __builder2.AddAttribute$3(23, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                    {
                                        __builder3.AddMarkupContent(24, "<i class=\"mdi mdi-engine-outline wx-03 hx-03 bg-primary round mgc-a flex\"></i>");
                                    }, $YpIcqg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                }), $ThnANd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                __builder2.AddAttribute$3(25, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*______*/ ______) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                    {
                                        __builder3.OpenComponent$1($.$lJUR.LCFCS.BottomSheetPage, 26);
                                        __builder3.AddAttribute$3(27, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*sheet*/ sheet) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                            {
                                                __builder4.OpenComponent$1($.$hDPm.LCFCCT$4.Themable, 28);
                                                __builder4.AddAttribute$3(29, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors)))().$ctor(this, ( (/*theme*/ theme) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                    {
                                                        /*var*/ let data = house.Statuses;
                                                        if ($.$sl.SL.Enumerable.Any$1($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, data))
                                                        {
                                                            /*var*/ let maxUtilEnergy = $.$$.S.Math.Max$2(1, $.$sl.SL.Enumerable.Max$13($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, data, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$$.S.Double))().$ctor(this,  (/*d*/ d) =>
                                                            {
                                                                return (d.Utility?.TotalEnergy ?? null) ?? 0;
                                                            }, $PuyOBa ??= {"r":1179649,"p":[{"n":"d","p":2046348}],"n":"","d":572301,"h":0,"f":17825794})));
                                                            /*var*/ let maxGenEnergy = $.$$.S.Math.Max$2(1, $.$sl.SL.Enumerable.Max$13($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, data, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$$.S.Double))().$ctor(this,  (/*d*/ d) =>
                                                            {
                                                                return (d.Generator?.TotalEnergy ?? null) ?? 0;
                                                            }, $SBmwxa ??= {"r":1179649,"p":[{"n":"d","p":2046348}],"n":"","d":572301,"h":0,"f":17825794})));
                                                            /*var*/ let maxFuelUsage = $.$$.S.Math.Max$2(1, $.$sl.SL.Enumerable.Max$13($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, data, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$$.S.Double))().$ctor(this,  (/*d*/ d) =>
                                                            {
                                                                return (d.Tank?.UsageQuantity ?? null) ?? 0;
                                                            }, $soLybj ??= {"r":1179649,"p":[{"n":"d","p":2046348}],"n":"","d":572301,"h":0,"f":17825794})));
                                                            /*var*/ let maxFuelDelivery = $.$$.S.Math.Max$2(1, $.$sl.SL.Enumerable.Max$13($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, data, new ($.$$.S.Func$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$$.S.Double))().$ctor(this,  (/*d*/ d) =>
                                                            {
                                                                return (d.Tank?.DeliveryQuantity ?? null) ?? 0;
                                                            }, $MEQZcg ??= {"r":1179649,"p":[{"n":"d","p":2046348}],"n":"","d":572301,"h":0,"f":17825794})));
                                                            __builder5.AddMarkupContent(30, "<h3 class=\"mgy\">Performance Chart</h3>\r\n                                        ");
                                                            __builder5.OpenElement(31, "div");
                                                            __builder5.AddAttribute$5(32, "class", "grid colm-25 gap-2");
                                                            __builder5.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 33);
                                                            __builder5.AddAttribute$3(34, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                                            {
                                                                $.$qKfs._LCIPCPA.TypeInference.CreateChart_0($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, __builder6, 35, 36, data, 37, new ($.$$.S.Func$$$$($.$$.S.Int32, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$$.S.String))().$ctor(this,  (/*i*/ i, /*t*/ t) =>
                                                                {
                                                                    return t.DateCreated.ToString();
                                                                }, $xUxDKf ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"t","p":2046348}],"n":"","d":572301,"h":0,"f":17825794}), 38, 127/*ChartFeatures.Default*/ & ~1/*ChartFeatures.XAxis*/ & ~2/*ChartFeatures.YAxis*/, 39, theme.Data.TextBackgroundColor, 40, "mgt", 41, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel))))().$ctor(this,  (/*context*/ context) =>
                                                                {
                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder7*/ __builder7) =>
                                                                    {
                                                                        __builder7.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel), 42);
                                                                        __builder7.AddComponentParameter(43, "Label", "Utility");
                                                                        __builder7.AddComponentParameter(44, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel))().$ctor(this, ( (/*t*/ t) =>
                                                                        {
                                                                            return ($.$box((t.LCFCCD$1$IDataListItemContext$$$Data.Utility?.TotalEnergy ?? null) ?? 0, $.$$.S.Double));
                                                                        }), $CPSpfa ??= {"r":131073,"p":[{"n":"t","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                        __builder7.AddComponentParameter(45, "PointColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 0)));
                                                                        __builder7.AddComponentParameter(46, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 0)));
                                                                        __builder7.AddComponentParameter(47, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 0)) + "40"));
                                                                        __builder7.CloseComponent();
                                                                    }, $InYOah ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                }, $RzDoAi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                            }), $dMpDMi ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":572301,"h":0,"f":17825794}));
                                                            __builder5.CloseComponent();
                                                            __builder5.AddMarkupContent(48, "\r\n                                            ");
                                                            __builder5.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 49);
                                                            __builder5.AddAttribute$3(50, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                                            {
                                                                $.$qKfs._LCIPCPA.TypeInference.CreateChart_1($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, __builder6, 51, 52, data, 53, new ($.$$.S.Func$$$$($.$$.S.Int32, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$$.S.String))().$ctor(this,  (/*i*/ i, /*t*/ t) =>
                                                                {
                                                                    return t.DateCreated.ToString();
                                                                }, $gIbBvg ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"t","p":2046348}],"n":"","d":572301,"h":0,"f":17825794}), 54, 127/*ChartFeatures.Default*/ & ~1/*ChartFeatures.XAxis*/ & ~2/*ChartFeatures.YAxis*/, 55, theme.Data.TextBackgroundColor, 56, "mgt", 57, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel))))().$ctor(this,  (/*context*/ context) =>
                                                                {
                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder7*/ __builder7) =>
                                                                    {
                                                                        __builder7.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel), 58);
                                                                        __builder7.AddComponentParameter(59, "Label", "Generator");
                                                                        __builder7.AddComponentParameter(60, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel))().$ctor(this, ( (/*t*/ t) =>
                                                                        {
                                                                            return ($.$box((t.LCFCCD$1$IDataListItemContext$$$Data.Generator?.TotalEnergy ?? null) ?? 0, $.$$.S.Double));
                                                                        }), $yMSsHe ??= {"r":131073,"p":[{"n":"t","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                        __builder7.AddComponentParameter(61, "PointColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 2)));
                                                                        __builder7.AddComponentParameter(62, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 2)));
                                                                        __builder7.AddComponentParameter(63, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 2)) + "40"));
                                                                        __builder7.CloseComponent();
                                                                    }, $GXkjQg ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                }, $igkNgb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                            }), $CcRTXd ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":572301,"h":0,"f":17825794}));
                                                            __builder5.CloseComponent();
                                                            __builder5.AddMarkupContent(64, "\r\n                                            ");
                                                            __builder5.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 65);
                                                            __builder5.AddAttribute$3(66, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                                            {
                                                                $.$qKfs._LCIPCPA.TypeInference.CreateChart_2($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, __builder6, 67, 68, data, 69, new ($.$$.S.Func$$$$($.$$.S.Int32, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$$.S.String))().$ctor(this,  (/*i*/ i, /*t*/ t) =>
                                                                {
                                                                    return t.DateCreated.ToString();
                                                                }, $YWcjSi ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"t","p":2046348}],"n":"","d":572301,"h":0,"f":17825794}), 70, 127/*ChartFeatures.Default*/ & ~1/*ChartFeatures.XAxis*/ & ~2/*ChartFeatures.YAxis*/, 71, theme.Data.TextBackgroundColor, 72, "mgt", 73, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel))))().$ctor(this,  (/*context*/ context) =>
                                                                {
                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder7*/ __builder7) =>
                                                                    {
                                                                        __builder7.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel), 74);
                                                                        __builder7.AddComponentParameter(75, "Label", "Fuel Usage");
                                                                        __builder7.AddComponentParameter(76, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel))().$ctor(this, ( (/*t*/ t) =>
                                                                        {
                                                                            return ($.$box((t.LCFCCD$1$IDataListItemContext$$$Data.Tank?.UsageQuantity ?? null) ?? 0, $.$$.S.Double));
                                                                        }), $pAFqyh ??= {"r":131073,"p":[{"n":"t","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                        __builder7.AddComponentParameter(77, "PointColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 4)));
                                                                        __builder7.AddComponentParameter(78, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 4)));
                                                                        __builder7.AddComponentParameter(79, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 4)) + "40"));
                                                                        __builder7.CloseComponent();
                                                                    }, $FpKkyk ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                }, $bUSbyc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                            }), $GUanDk ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":572301,"h":0,"f":17825794}));
                                                            __builder5.CloseComponent();
                                                            __builder5.AddMarkupContent(80, "\r\n                                            ");
                                                            __builder5.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 81);
                                                            __builder5.AddAttribute$3(82, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                                            {
                                                                $.$qKfs._LCIPCPA.TypeInference.CreateChart_3($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, __builder6, 83, 84, data, 85, new ($.$$.S.Func$$$$($.$$.S.Int32, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$$.S.String))().$ctor(this,  (/*i*/ i, /*t*/ t) =>
                                                                {
                                                                    return t.DateCreated.ToString();
                                                                }, $SbGKEk ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"t","p":2046348}],"n":"","d":572301,"h":0,"f":17825794}), 86, 127/*ChartFeatures.Default*/ & ~1/*ChartFeatures.XAxis*/ & ~2/*ChartFeatures.YAxis*/, 87, theme.Data.TextBackgroundColor, 88, "mgt", 89, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel))))().$ctor(this,  (/*context*/ context) =>
                                                                {
                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder7*/ __builder7) =>
                                                                    {
                                                                        __builder7.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel), 90);
                                                                        __builder7.AddComponentParameter(91, "Label", "Fuel Delivery");
                                                                        __builder7.AddComponentParameter(92, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel))().$ctor(this, ( (/*t*/ t) =>
                                                                        {
                                                                            return ($.$box((t.LCFCCD$1$IDataListItemContext$$$Data.Tank?.DeliveryQuantity ?? null) ?? 0, $.$$.S.Double));
                                                                        }), $qqMove ??= {"r":131073,"p":[{"n":"t","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                        __builder7.AddComponentParameter(93, "PointColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 5)));
                                                                        __builder7.AddComponentParameter(94, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 5)));
                                                                        __builder7.AddComponentParameter(95, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 5)) + "40"));
                                                                        __builder7.CloseComponent();
                                                                    }, $FKtJDk ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                }, $vgjlIi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$mXnX.LCIPCM.PowerHouseDeviceStatusModel)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                            }), $mRLMCc ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":572301,"h":0,"f":17825794}));
                                                            __builder5.CloseComponent();
                                                            __builder5.CloseElement();
                                                        }
                                                        else 
                                                        {
                                                            __builder5.AddMarkupContent(96, "<div class=\"flex hx-2 bg-tb-primary-secondary\"><div class=\"mg-a fw-bold\">No data for this period</div></div>");
                                                        }
                                                        __builder5.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 97);
                                                        __builder5.AddComponentParameter(98, "Class", "mgt-10");
                                                        __builder5.AddAttribute$3(99, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                                        {
                                                            __builder6.OpenComponent$1($.$hDPm.LCFCCA.Accordion, 100);
                                                            __builder6.AddAttribute$3(101, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder7*/ __builder7) =>
                                                            {
                                                                __builder7.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 102);
                                                                __builder7.AddComponentParameter(103, "Class", "bdb");
                                                                __builder7.AddAttribute$3(104, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*open*/ open) =>
                                                                {
                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder8*/ __builder8) =>
                                                                    {
                                                                        __builder8.OpenElement(105, "div");
                                                                        __builder8.AddAttribute$5(106, "class", $.$strNN($.$strNN("row" + " pd-2") + " ") + $.$strNN(($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).op_Implicit(open) ? "bg-card" : "")));
                                                                        __builder8.AddMarkupContent(107, "<div class=\"col-a\"><i class=\"mdi mdi-lightbulb-on-outline fsz-50\"></i></div>\r\n                                                        ");
                                                                        __builder8.AddMarkupContent(108, "<div class=\"col-10 stack\"><div class=\"mgy-a mgl\"><h3 class=\"mg-0\">Total Uptime</h3>\r\n                                                                <em class=\"op-8\">Power supply availability</em></div></div>\r\n                                                        ");
                                                                        __builder8.OpenElement(109, "div");
                                                                        __builder8.AddAttribute$5(110, "class", "col-a stack");
                                                                        __builder8.OpenElement(111, "div");
                                                                        __builder8.AddAttribute$5(112, "class", "mgy-a stack text-right");
                                                                        __builder8.OpenElement(113, "h3");
                                                                        __builder8.AddAttribute$5(114, "class", "cl-primary mg-0 nowrap");
                                                                        __builder8.AddContent$4(115, this.HMS($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalUpTime(house.Statuses)));
                                                                        __builder8.CloseElement();
                                                                        __builder8.CloseElement();
                                                                        __builder8.CloseElement();
                                                                        __builder8.CloseElement();
                                                                    }, $dhRltj ??= {"r":65537,"p":[{"n":"__builder8","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                }), $nBskmb ??= {"r":6881395,"p":[{"n":"open","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                __builder7.AddAttribute$3(116, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*_*/ _0) =>
                                                                {
                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder8*/ __builder8) =>
                                                                    {
                                                                        /*var*/ let sums = $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetSumByDate(house.Statuses);
                                                                        if ($.$sl.SL.Enumerable.Any$1($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), sums))
                                                                        {
                                                                            __builder8.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 117);
                                                                            __builder8.AddComponentParameter(118, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 21/*CardFeatures.Default*/ & ~4/*CardFeatures.Shadow*/ & ~8/*CardFeatures.Border*/), $.$hDPm.LCFCCC$1.CardFeatures));
                                                                            __builder8.AddAttribute$3(119, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder9*/ __builder9) =>
                                                                            {
                                                                                __builder9.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)), 120);
                                                                                __builder9.AddComponentParameter(121, "Class", "mgt-10");
                                                                                __builder9.AddComponentParameter(122, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)), sums));
                                                                                __builder9.AddComponentParameter(123, "FontColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, theme.Data.TextBackgroundColor));
                                                                                __builder9.AddComponentParameter(124, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*c*/ c) =>
                                                                                {
                                                                                    return c.Item1.ToLocalTime().ToString();
                                                                                }), $JnCAxk ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"c","p":$.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.AddComponentParameter(125, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartType, 4/*ChartType.SparkLine*/), $.$hDPm.LCFCCC$3.ChartType));
                                                                                __builder9.AddComponentParameter(126, "YLabel", "Availibility");
                                                                                __builder9.AddComponentParameter(127, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 100), $.$$.S.Int32));
                                                                                __builder9.AddAttribute$3(128, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)))))().$ctor(this, ( (/*context*/ context) =>
                                                                                {
                                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder10*/ __builder10) =>
                                                                                    {
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)), 129);
                                                                                        __builder10.AddComponentParameter(130, "Label", "Hours");
                                                                                        __builder10.AddComponentParameter(131, "BackgroundColor", "#00000000");
                                                                                        __builder10.AddComponentParameter(132, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 0)));
                                                                                        __builder10.AddComponentParameter(133, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box(c.LCFCCD$1$IDataListItemContext$$$Data.Item2.Runtime, $.$$.S.Int32);
                                                                                        }), $lYbHSc ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.CloseComponent();
                                                                                    }, $qTkSme ??= {"r":65537,"p":[{"n":"__builder10","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                }), $Vlftag ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.CloseComponent();
                                                                                __builder9.AddMarkupContent(134, "\r\n                                                            ");
                                                                                __builder9.OpenElement(135, "div");
                                                                                __builder9.AddAttribute$5(136, "class", "row");
                                                                                __builder9.OpenElement(137, "div");
                                                                                __builder9.AddAttribute$5(138, "class", "col-5 clip");
                                                                                __builder9.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$$.S.Double), 139);
                                                                                __builder9.AddComponentParameter(140, "Class", "mgt-10");
                                                                                __builder9.AddComponentParameter(141, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.Double), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Double), [$.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalUtilityRuntime(house.Statuses).TotalHours, $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalGeneratorRuntime(house.Statuses).TotalHours], [-1], null)));
                                                                                __builder9.AddComponentParameter(142, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.Double, $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*c*/ c) =>
                                                                                {
                                                                                    return i === 0 ? "Utility" : "Generator";
                                                                                }), $btrvKc ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"c","p":1179649}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.AddComponentParameter(143, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartType, 3/*ChartType.Doughnut*/), $.$hDPm.LCFCCC$3.ChartType));
                                                                                __builder9.AddComponentParameter(144, "YLabel", "Availibility(hrs)");
                                                                                __builder9.AddComponentParameter(145, "FontColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, theme.Data.TextBackgroundColor));
                                                                                __builder9.AddComponentParameter(146, "ChartFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartFeatures, 127/*ChartFeatures.Default*/ & ~1/*ChartFeatures.XAxis*/ & ~2/*ChartFeatures.YAxis*/ & ~16/*ChartFeatures.Legend*/), $.$hDPm.LCFCCC$3.ChartFeatures));
                                                                                __builder9.AddComponentParameter(147, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 200), $.$$.S.Int32));
                                                                                __builder9.AddAttribute$3(148, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.Double, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Double))))().$ctor(this, ( (/*context*/ context) =>
                                                                                {
                                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder10*/ __builder10) =>
                                                                                    {
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Double), 149);
                                                                                        __builder10.AddComponentParameter(150, "Label", "Availibility");
                                                                                        __builder10.AddComponentParameter(151, "BackgroundColors", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.String), $.$sl.SL.Enumerable.ToArray($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$$.S.String, theme.Data.ChartColors, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$strNN(c) + "80";
                                                                                        }, $hxNFdf ??= {"r":1310721,"p":[{"n":"c","p":1310721}],"n":"","d":572301,"h":0,"f":17825794})))));
                                                                                        __builder10.AddComponentParameter(152, "BorderColors", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.String), $.$sl.SL.Enumerable.ToArray($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$$.S.String, theme.Data.ChartColors, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$strNN(c) + "80";
                                                                                        }, $bunxSi ??= {"r":1310721,"p":[{"n":"c","p":1310721}],"n":"","d":572301,"h":0,"f":17825794})))));
                                                                                        __builder10.AddComponentParameter(153, "BorderWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 1), $.$$.S.Int32));
                                                                                        __builder10.AddComponentParameter(154, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.S.Double))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box(c.LCFCCD$1$IDataListItemContext$$$Data, $.$$.S.Double);
                                                                                        }), $rTPLNj ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.S.Double).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.CloseComponent();
                                                                                    }, $JBfSll ??= {"r":65537,"p":[{"n":"__builder10","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                }), $WHLnCj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.Double, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Double)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.CloseComponent();
                                                                                __builder9.CloseElement();
                                                                                __builder9.AddMarkupContent(155, "\r\n                                                                ");
                                                                                __builder9.OpenElement(156, "div");
                                                                                __builder9.AddAttribute$5(157, "class", "col-5 flex");
                                                                                __builder9.OpenElement(158, "div");
                                                                                __builder9.AddAttribute$5(159, "class", "mgy-a pdl");
                                                                                __builder9.OpenElement(160, "h3");
                                                                                __builder9.AddAttribute$5(161, "style", "color:" + $.$strNN(($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 0))));
                                                                                __builder9.AddContent$4(162, "Utility: ");
                                                                                __builder9.AddContent$4(163, this.HMS($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalUtilityRuntime(house.Statuses)));
                                                                                __builder9.CloseElement();
                                                                                __builder9.AddMarkupContent(164, "\r\n                                                                        ");
                                                                                __builder9.OpenElement(165, "h3");
                                                                                __builder9.AddAttribute$5(166, "style", "color:" + $.$strNN(($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 1))));
                                                                                __builder9.AddContent$4(167, "Generator:  ");
                                                                                __builder9.AddContent$4(168, this.HMS($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalGeneratorRuntime(house.Statuses)));
                                                                                __builder9.CloseElement();
                                                                                __builder9.CloseElement();
                                                                                __builder9.CloseElement();
                                                                                __builder9.CloseElement();
                                                                                __builder9.AddMarkupContent(169, "\r\n                                                            ");
                                                                                __builder9.OpenElement(170, "h4");
                                                                                __builder9.AddAttribute$5(171, "class", "mgy-2");
                                                                                __builder9.AddContent$3(172, $.$box(house.Parameter.Interval, $.$fPer.LCFCDC.PeriodicInterval));
                                                                                __builder9.AddContent$4(173, " Availability");
                                                                                __builder9.CloseElement();
                                                                                __builder9.AddMarkupContent(174, "\r\n                                                            ");
                                                                                __builder9.OpenComponent$1($.$hDPm.LCFCCT.TableChart$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))), 175);
                                                                                __builder9.AddComponentParameter(176, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))), $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetGroupByDate(house.Statuses)));
                                                                                __builder9.AddComponentParameter(177, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)), $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*c*/ c) =>
                                                                                {
                                                                                    return c.Key.ToString();
                                                                                }), $ixEHyk ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"c","p":$.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.AddComponentParameter(178, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartType, 1/*ChartType.Bar*/), $.$hDPm.LCFCCC$3.ChartType));
                                                                                __builder9.AddComponentParameter(179, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 300), $.$$.S.Int32));
                                                                                __builder9.AddComponentParameter(180, "ChartFontColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, theme.Data.TextBackgroundColor));
                                                                                __builder9.AddComponentParameter(181, "YLabel", "Availability(s)");
                                                                                __builder9.AddComponentParameter(182, "TabsFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT$1.TabsFeatures, 65/*TabsFeatures.Default*/ | 128/*TabsFeatures.ButtonTabs*/), $.$hDPm.LCFCCT$1.TabsFeatures));
                                                                                __builder9.AddComponentParameter(183, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                                                __builder9.AddComponentParameter(184, "ChartFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartFeatures, 127/*ChartFeatures.Default*/ & ~4/*ChartFeatures.XGrid*/ & ~8/*ChartFeatures.YGrid*/), $.$hDPm.LCFCCC$3.ChartFeatures));
                                                                                __builder9.AddAttribute$3(185, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)))))().$ctor(this, ( (/*context*/ context) =>
                                                                                {
                                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder10*/ __builder10) =>
                                                                                    {
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCT.TableChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))), 186);
                                                                                        __builder10.AddComponentParameter(187, "Label", "Utility");
                                                                                        __builder10.AddComponentParameter(188, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 0)) + "80"));
                                                                                        __builder10.AddComponentParameter(189, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 0)));
                                                                                        __builder10.AddComponentParameter(190, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box((c.LCFCCD$1$IDataListItemContext$$$Data.Value.Item1?.Runtime ?? null) ?? 0, $.$$.S.Int32);
                                                                                        }), $XrZBib ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.AddComponentParameter(191, "Stack", "+");
                                                                                        __builder10.AddAttribute$3(192, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)))))().$ctor(this, ( (/*rt*/ rt) =>
                                                                                        {
                                                                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder11*/ __builder11) =>
                                                                                            {
                                                                                                /*var*/ let ts = new $.$$.S.TimeSpan().$ctor$6(0, 0, (rt.Data.Value.Item1?.Runtime ?? null) ?? 0);
                                                                                                __builder11.OpenElement(193, "span");
                                                                                                __builder11.AddAttribute$5(194, "class", "nowrap");
                                                                                                __builder11.AddContent$4(195, `${$.$strNN((ts.Hours > 0 ? `${$.$strNN(ts.Hours)}hr` : ""))} ${$.$strNN(ts.Minutes)}min`);
                                                                                                __builder11.CloseElement();
                                                                                            }, $ZPuDqk ??= {"r":65537,"p":[{"n":"__builder11","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                        }), $jNgPVg ??= {"r":6881395,"p":[{"n":"rt","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.CloseComponent();
                                                                                        __builder10.AddMarkupContent(196, "\r\n                                                                ");
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCT.TableChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))), 197);
                                                                                        __builder10.AddComponentParameter(198, "Label", "Generator");
                                                                                        __builder10.AddComponentParameter(199, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 1)) + "80"));
                                                                                        __builder10.AddComponentParameter(200, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 1)));
                                                                                        __builder10.AddComponentParameter(201, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box((c.LCFCCD$1$IDataListItemContext$$$Data.Value.Item2?.Runtime ?? null) ?? 0, $.$$.S.Int32);
                                                                                        }), $dtzmLh ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.AddComponentParameter(202, "Stack", "+");
                                                                                        __builder10.AddAttribute$3(203, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)))))().$ctor(this, ( (/*rt*/ rt) =>
                                                                                        {
                                                                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder11*/ __builder11) =>
                                                                                            {
                                                                                                /*var*/ let ts = new $.$$.S.TimeSpan().$ctor$6(0, 0, (rt.Data.Value.Item2?.Runtime ?? null) ?? 0);
                                                                                                __builder11.OpenElement(204, "span");
                                                                                                __builder11.AddAttribute$5(205, "class", "nowrap");
                                                                                                __builder11.AddContent$4(206, `${$.$strNN((ts.Hours > 0 ? `${$.$strNN(ts.Hours)}hr` : ""))} ${$.$strNN(ts.Minutes)}min`);
                                                                                                __builder11.CloseElement();
                                                                                            }, $jPXlPf ??= {"r":65537,"p":[{"n":"__builder11","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                        }), $pUeuFc ??= {"r":6881395,"p":[{"n":"rt","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.CloseComponent();
                                                                                        __builder10.AddMarkupContent(207, "\r\n                                                                ");
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCT.TableChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))), 208);
                                                                                        __builder10.AddComponentParameter(209, "Label", "Total");
                                                                                        __builder10.AddComponentParameter(210, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT.TableChartFeatures, 7/*TableChartFeatures.Default*/ & ~2/*TableChartFeatures.Chart*/), $.$hDPm.LCFCCT.TableChartFeatures));
                                                                                        __builder10.AddComponentParameter(211, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 2)) + "80"));
                                                                                        __builder10.AddComponentParameter(212, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 2)));
                                                                                        __builder10.AddComponentParameter(213, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box(c.LCFCCD$1$IDataListItemContext$$$Data.Value.Item3.Runtime, $.$$.S.Int32);
                                                                                        }), $GcFkbg ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.AddComponentParameter(214, "Stack", "+");
                                                                                        __builder10.AddAttribute$3(215, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)))))().$ctor(this, ( (/*rt*/ rt) =>
                                                                                        {
                                                                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder11*/ __builder11) =>
                                                                                            {
                                                                                                /*var*/ let ts = new $.$$.S.TimeSpan().$ctor$6(0, 0, (rt.Data.Value.Item3?.Runtime ?? null) ?? 0);
                                                                                                __builder11.OpenElement(216, "span");
                                                                                                __builder11.AddAttribute$5(217, "class", "nowrap");
                                                                                                __builder11.AddContent$4(218, `${$.$strNN((ts.Hours > 0 ? `${$.$strNN(ts.Hours)}hr` : ""))} ${$.$strNN(ts.Minutes)}min`);
                                                                                                __builder11.CloseElement();
                                                                                            }, $ugMDBk ??= {"r":65537,"p":[{"n":"__builder11","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                        }), $jFFtIc ??= {"r":6881395,"p":[{"n":"rt","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.CloseComponent();
                                                                                    }, $YlEiQf ??= {"r":65537,"p":[{"n":"__builder10","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                }), $fmNmDa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.CloseComponent();
                                                                            }), $hzOeQa ??= {"r":65537,"p":[{"n":"__builder9","p":7536755}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                            __builder8.CloseComponent();
                                                                        }
                                                                        else 
                                                                        {
                                                                            __builder8.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 219);
                                                                            __builder8.AddComponentParameter(220, "Class", "mg");
                                                                            __builder8.AddComponentParameter(221, "Message", "No data");
                                                                            __builder8.CloseComponent();
                                                                        }
                                                                    }, $MpheOe ??= {"r":65537,"p":[{"n":"__builder8","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                }), $ZmOghf ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                __builder7.CloseComponent();
                                                                __builder7.AddMarkupContent(222, "\r\n                                            ");
                                                                __builder7.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 223);
                                                                __builder7.AddComponentParameter(224, "Class", "bdb");
                                                                __builder7.AddAttribute$3(225, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*open*/ open) =>
                                                                {
                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder8*/ __builder8) =>
                                                                    {
                                                                        __builder8.OpenElement(226, "div");
                                                                        __builder8.AddAttribute$5(227, "class", $.$strNN($.$strNN("row" + " pd-2") + " ") + $.$strNN(($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).op_Implicit(open) ? "bg-card" : "")));
                                                                        __builder8.AddMarkupContent(228, "<div class=\"col-a\"><i class=\"mdi mdi-lightbulb-off fsz-50\"></i></div>\r\n                                                        ");
                                                                        __builder8.AddMarkupContent(229, "<div class=\"col-10 stack\"><div class=\"mgy-a mgl\"><h3 class=\"mg-0\">Total Downtime</h3>\r\n                                                                <em class=\"op-8\">Power supply outage</em></div></div>\r\n                                                        ");
                                                                        __builder8.OpenElement(230, "div");
                                                                        __builder8.AddAttribute$5(231, "class", "col-a stack");
                                                                        __builder8.OpenElement(232, "div");
                                                                        __builder8.AddAttribute$5(233, "class", "mgy-a stack text-right");
                                                                        __builder8.OpenElement(234, "h3");
                                                                        __builder8.AddAttribute$5(235, "class", "cl-error mg-0 nowrap");
                                                                        __builder8.AddContent$4(236, this.HMS($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalDownTime(house.Statuses, house.Parameter.From, house.Parameter.To)));
                                                                        __builder8.CloseElement();
                                                                        __builder8.CloseElement();
                                                                        __builder8.CloseElement();
                                                                        __builder8.CloseElement();
                                                                    }, $gfYOnd ??= {"r":65537,"p":[{"n":"__builder8","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                }), $KQFOIe ??= {"r":6881395,"p":[{"n":"open","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                __builder7.CloseComponent();
                                                                __builder7.AddMarkupContent(237, "\r\n                                            ");
                                                                __builder7.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 238);
                                                                __builder7.AddComponentParameter(239, "Class", "bdb");
                                                                __builder7.AddAttribute$3(240, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*open*/ open) =>
                                                                {
                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder8*/ __builder8) =>
                                                                    {
                                                                        __builder8.OpenElement(241, "div");
                                                                        __builder8.AddAttribute$5(242, "class", $.$strNN($.$strNN("row" + " pd-2") + " ") + $.$strNN(($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).op_Implicit(open) ? "bg-card" : "")));
                                                                        __builder8.AddMarkupContent(243, "<div class=\"col-a\"><i class=\"mdi mdi-solar-power fsz-50\"></i></div>\r\n                                                        ");
                                                                        __builder8.AddMarkupContent(244, "<div class=\"col-10 stack\"><div class=\"mgy-a mgl\"><h3 class=\"mg-0\">Total Energy Usage</h3>\r\n                                                                <em class=\"op-8\">Electricity used</em></div></div>\r\n                                                        ");
                                                                        __builder8.OpenElement(245, "div");
                                                                        __builder8.AddAttribute$5(246, "class", "col-a stack");
                                                                        __builder8.OpenElement(247, "div");
                                                                        __builder8.AddAttribute$5(248, "class", "mgy-a stack text-right");
                                                                        __builder8.OpenElement(249, "h3");
                                                                        __builder8.AddAttribute$5(250, "class", "cl-message mg-0 nowrap");
                                                                        __builder8.AddContent$4(251, this.Wh($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalEnergy(house.Statuses)));
                                                                        __builder8.CloseElement();
                                                                        __builder8.CloseElement();
                                                                        __builder8.CloseElement();
                                                                        __builder8.CloseElement();
                                                                    }, $JBYgmj ??= {"r":65537,"p":[{"n":"__builder8","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                }), $tIrkRa ??= {"r":6881395,"p":[{"n":"open","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                __builder7.AddAttribute$3(252, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*_*/ _0) =>
                                                                {
                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder8*/ __builder8) =>
                                                                    {
                                                                        /*var*/ let sums = $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetSumByDate(house.Statuses);
                                                                        if ($.$sl.SL.Enumerable.Any$1($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), sums))
                                                                        {
                                                                            __builder8.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 253);
                                                                            __builder8.AddComponentParameter(254, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 21/*CardFeatures.Default*/ & ~4/*CardFeatures.Shadow*/ & ~8/*CardFeatures.Border*/), $.$hDPm.LCFCCC$1.CardFeatures));
                                                                            __builder8.AddAttribute$3(255, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder9*/ __builder9) =>
                                                                            {
                                                                                __builder9.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)), 256);
                                                                                __builder9.AddComponentParameter(257, "Class", "mgt-10");
                                                                                __builder9.AddComponentParameter(258, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)), sums));
                                                                                __builder9.AddComponentParameter(259, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*c*/ c) =>
                                                                                {
                                                                                    return c.Item1.ToLocalTime().ToString();
                                                                                }), $NkktUi ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"c","p":$.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.AddComponentParameter(260, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartType, 4/*ChartType.SparkLine*/), $.$hDPm.LCFCCC$3.ChartType));
                                                                                __builder9.AddComponentParameter(261, "YLabel", "Energy");
                                                                                __builder9.AddComponentParameter(262, "FontColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, theme.Data.TextBackgroundColor));
                                                                                __builder9.AddComponentParameter(263, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 100), $.$$.S.Int32));
                                                                                __builder9.AddAttribute$3(264, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)))))().$ctor(this, ( (/*context*/ context) =>
                                                                                {
                                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder10*/ __builder10) =>
                                                                                    {
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)), 265);
                                                                                        __builder10.AddComponentParameter(266, "Label", "Energy");
                                                                                        __builder10.AddComponentParameter(267, "BackgroundColor", "#00000000");
                                                                                        __builder10.AddComponentParameter(268, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 0)));
                                                                                        __builder10.AddComponentParameter(269, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box(c.LCFCCD$1$IDataListItemContext$$$Data.Item2.TotalEnergy, $.$$.S.Double);
                                                                                        }), $HegESb ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.CloseComponent();
                                                                                    }, $RycsVa ??= {"r":65537,"p":[{"n":"__builder10","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                }), $JrZQBb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel), $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.CloseComponent();
                                                                                __builder9.AddMarkupContent(270, "\r\n                                                            ");
                                                                                __builder9.OpenElement(271, "div");
                                                                                __builder9.AddAttribute$5(272, "class", "row");
                                                                                __builder9.OpenElement(273, "div");
                                                                                __builder9.AddAttribute$5(274, "class", "col-5 clip");
                                                                                __builder9.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$$.S.Double), 275);
                                                                                __builder9.AddComponentParameter(276, "Class", "mgt-10");
                                                                                __builder9.AddComponentParameter(277, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.Double), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Double), [$.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalUtilityEnergy(house.Statuses), $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalGeneratorEnergy(house.Statuses)], [-1], null)));
                                                                                __builder9.AddComponentParameter(278, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.Double, $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*c*/ c) =>
                                                                                {
                                                                                    return i === 0 ? (() =>
                                                                                    {
                                                                                        var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(2, 1);
                                                                                        $handler.AppendLiteral("Utility(");
                                                                                        $handler.AppendFormatted($.$box($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalUtilityEnergy(house.Statuses), $.$$.S.Double), null, "N");
                                                                                        $handler.AppendLiteral("kWh)");
                                                                                        return $handler.ToStringAndClear                                                                                ();
                                                                                    })() : (() =>
                                                                                    {
                                                                                        var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(2, 1);
                                                                                        $handler.AppendLiteral("Generator(");
                                                                                        $handler.AppendFormatted($.$box($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalGeneratorEnergy(house.Statuses), $.$$.S.Double), null, "N");
                                                                                        $handler.AppendLiteral("kWh)");
                                                                                        return $handler.ToStringAndClear                                                                                ();
                                                                                    })();
                                                                                }), $bqcGwh ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"c","p":1179649}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.AddComponentParameter(279, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartType, 3/*ChartType.Doughnut*/), $.$hDPm.LCFCCC$3.ChartType));
                                                                                __builder9.AddComponentParameter(280, "YLabel", "Energy(kWh)");
                                                                                __builder9.AddComponentParameter(281, "ChartFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartFeatures, 127/*ChartFeatures.Default*/ & ~1/*ChartFeatures.XAxis*/ & ~2/*ChartFeatures.YAxis*/ & ~16/*ChartFeatures.Legend*/), $.$hDPm.LCFCCC$3.ChartFeatures));
                                                                                __builder9.AddComponentParameter(282, "FontColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, theme.Data.TextBackgroundColor));
                                                                                __builder9.AddComponentParameter(283, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 200), $.$$.S.Int32));
                                                                                __builder9.AddAttribute$3(284, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.Double, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Double))))().$ctor(this, ( (/*context*/ context) =>
                                                                                {
                                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder10*/ __builder10) =>
                                                                                    {
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Double), 285);
                                                                                        __builder10.AddComponentParameter(286, "Label", "Energy");
                                                                                        __builder10.AddComponentParameter(287, "BackgroundColors", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.String), $.$sl.SL.Enumerable.ToArray($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$$.S.String, theme.Data.ChartColors, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$strNN(c) + "80";
                                                                                        }, $leYEfc ??= {"r":1310721,"p":[{"n":"c","p":1310721}],"n":"","d":572301,"h":0,"f":17825794})))));
                                                                                        __builder10.AddComponentParameter(288, "BorderColors", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.String), $.$sl.SL.Enumerable.ToArray($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$$.S.String, theme.Data.ChartColors, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$strNN(c) + "80";
                                                                                        }, $HZfbWj ??= {"r":1310721,"p":[{"n":"c","p":1310721}],"n":"","d":572301,"h":0,"f":17825794})))));
                                                                                        __builder10.AddComponentParameter(289, "BorderWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 1), $.$$.S.Int32));
                                                                                        __builder10.AddComponentParameter(290, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.S.Double))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box(c.LCFCCD$1$IDataListItemContext$$$Data, $.$$.S.Double);
                                                                                        }), $bZhrYg ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.S.Double).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.CloseComponent();
                                                                                    }, $jkilCk ??= {"r":65537,"p":[{"n":"__builder10","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                }), $mgRlRc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.Double, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.S.Double)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.CloseComponent();
                                                                                __builder9.CloseElement();
                                                                                __builder9.AddMarkupContent(291, "\r\n                                                                ");
                                                                                __builder9.OpenElement(292, "div");
                                                                                __builder9.AddAttribute$5(293, "class", "col-5 flex");
                                                                                __builder9.OpenElement(294, "div");
                                                                                __builder9.AddAttribute$5(295, "class", "mgy-a pdl");
                                                                                __builder9.OpenElement(296, "em");
                                                                                __builder9.AddAttribute$5(297, "style", "color:" + $.$strNN(($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 0))));
                                                                                __builder9.AddContent$4(298, "Utility: ");
                                                                                __builder9.OpenElement(299, "span");
                                                                                __builder9.AddAttribute$5(300, "class", "nowrap");
                                                                                __builder9.AddContent$4(301, this.Wh($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalUtilityEnergy(house.Statuses)));
                                                                                __builder9.AddContent$4(302, ",");
                                                                                __builder9.CloseElement();
                                                                                __builder9.AddContent$4(303, " ");
                                                                                __builder9.OpenElement(304, "span");
                                                                                __builder9.AddAttribute$5(305, "class", "nowrap");
                                                                                __builder9.AddContent$4(306, this.Naira($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalUtilityEnergy(house.Statuses)));
                                                                                __builder9.CloseElement();
                                                                                __builder9.CloseElement();
                                                                                __builder9.AddMarkupContent(307, "\r\n                                                                        ");
                                                                                __builder9.OpenElement(308, "em");
                                                                                __builder9.AddAttribute$5(309, "class", "mgt d-block");
                                                                                __builder9.AddAttribute$5(310, "style", "color:" + $.$strNN(($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 1))));
                                                                                __builder9.AddContent$4(311, "Generator:  ");
                                                                                __builder9.OpenElement(312, "span");
                                                                                __builder9.AddAttribute$5(313, "class", "nowrap");
                                                                                __builder9.AddContent$4(314, this.Wh($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalGeneratorEnergy(house.Statuses)));
                                                                                __builder9.AddContent$4(315, ",");
                                                                                __builder9.CloseElement();
                                                                                __builder9.AddContent$4(316, " ");
                                                                                __builder9.OpenElement(317, "span");
                                                                                __builder9.AddAttribute$5(318, "class", "nowrap");
                                                                                __builder9.AddContent$4(319, this.Naira($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalGeneratorEnergy(house.Statuses)));
                                                                                __builder9.CloseElement();
                                                                                __builder9.CloseElement();
                                                                                __builder9.CloseElement();
                                                                                __builder9.CloseElement();
                                                                                __builder9.CloseElement();
                                                                                __builder9.AddMarkupContent(320, "\r\n                                                            ");
                                                                                __builder9.OpenElement(321, "h4");
                                                                                __builder9.AddAttribute$5(322, "class", "mgy-2");
                                                                                __builder9.AddContent$3(323, $.$box(house.Parameter.Interval, $.$fPer.LCFCDC.PeriodicInterval));
                                                                                __builder9.AddContent$4(324, " Power Consumption");
                                                                                __builder9.CloseElement();
                                                                                __builder9.AddMarkupContent(325, "\r\n                                                            ");
                                                                                __builder9.OpenComponent$1($.$hDPm.LCFCCT.TableChart$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))), 326);
                                                                                __builder9.AddComponentParameter(327, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))), $.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetGroupByDate(house.Statuses)));
                                                                                __builder9.AddComponentParameter(328, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)), $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*c*/ c) =>
                                                                                {
                                                                                    return c.Key.ToString();
                                                                                }), $NfrKqg ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"c","p":$.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.AddComponentParameter(329, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartType, 1/*ChartType.Bar*/), $.$hDPm.LCFCCC$3.ChartType));
                                                                                __builder9.AddComponentParameter(330, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 300), $.$$.S.Int32));
                                                                                __builder9.AddComponentParameter(331, "ChartFontColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, theme.Data.TextBackgroundColor));
                                                                                __builder9.AddComponentParameter(332, "YLabel", "Energy");
                                                                                __builder9.AddComponentParameter(333, "TabsFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT$1.TabsFeatures, 65/*TabsFeatures.Default*/ | 128/*TabsFeatures.ButtonTabs*/), $.$hDPm.LCFCCT$1.TabsFeatures));
                                                                                __builder9.AddComponentParameter(334, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                                                __builder9.AddComponentParameter(335, "ChartFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartFeatures, 127/*ChartFeatures.Default*/ & ~4/*ChartFeatures.XGrid*/ & ~8/*ChartFeatures.YGrid*/), $.$hDPm.LCFCCC$3.ChartFeatures));
                                                                                __builder9.AddAttribute$3(336, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel)))))().$ctor(this, ( (/*context*/ context) =>
                                                                                {
                                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder10*/ __builder10) =>
                                                                                    {
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCT.TableChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))), 337);
                                                                                        __builder10.AddComponentParameter(338, "Label", "Utility/Red");
                                                                                        __builder10.AddComponentParameter(339, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 1)) + "80"));
                                                                                        __builder10.AddComponentParameter(340, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 1)));
                                                                                        __builder10.AddComponentParameter(341, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box((c.LCFCCD$1$IDataListItemContext$$$Data.Value.Item1?.RedEnergy ?? null) ?? 0, $.$$.S.Double);
                                                                                        }), $edAPKb ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.AddComponentParameter(342, "Stack", "+");
                                                                                        __builder10.CloseComponent();
                                                                                        __builder10.AddMarkupContent(343, "\r\n                                                                ");
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCT.TableChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))), 344);
                                                                                        __builder10.AddComponentParameter(345, "Label", "Utility/Blue");
                                                                                        __builder10.AddComponentParameter(346, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 2)) + "80"));
                                                                                        __builder10.AddComponentParameter(347, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 2)));
                                                                                        __builder10.AddComponentParameter(348, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box((c.LCFCCD$1$IDataListItemContext$$$Data.Value.Item1?.BlueEnergy ?? null) ?? 0, $.$$.S.Double);
                                                                                        }), $gszbcf ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.AddComponentParameter(349, "Stack", "+");
                                                                                        __builder10.CloseComponent();
                                                                                        __builder10.AddMarkupContent(350, "\r\n                                                                ");
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCT.TableChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))), 351);
                                                                                        __builder10.AddComponentParameter(352, "Label", "Utility/Yellow");
                                                                                        __builder10.AddComponentParameter(353, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 3)) + "80"));
                                                                                        __builder10.AddComponentParameter(354, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 3)));
                                                                                        __builder10.AddComponentParameter(355, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box((c.LCFCCD$1$IDataListItemContext$$$Data.Value.Item1?.YellowEnergy ?? null) ?? 0, $.$$.S.Double);
                                                                                        }), $oyqSkl ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.AddComponentParameter(356, "Stack", "+");
                                                                                        __builder10.CloseComponent();
                                                                                        __builder10.AddMarkupContent(357, "\r\n                                                                ");
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCT.TableChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))), 358);
                                                                                        __builder10.AddComponentParameter(359, "Label", "Generator/Red");
                                                                                        __builder10.AddComponentParameter(360, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 4)) + "80"));
                                                                                        __builder10.AddComponentParameter(361, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 4)));
                                                                                        __builder10.AddComponentParameter(362, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box((c.LCFCCD$1$IDataListItemContext$$$Data.Value.Item2?.RedEnergy ?? null) ?? 0, $.$$.S.Double);
                                                                                        }), $sQmoCf ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.AddComponentParameter(363, "Stack", "-");
                                                                                        __builder10.CloseComponent();
                                                                                        __builder10.AddMarkupContent(364, "\r\n                                                                ");
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCT.TableChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))), 365);
                                                                                        __builder10.AddComponentParameter(366, "Label", "Generator/Blue");
                                                                                        __builder10.AddComponentParameter(367, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 5)) + "80"));
                                                                                        __builder10.AddComponentParameter(368, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 5)));
                                                                                        __builder10.AddComponentParameter(369, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box((c.LCFCCD$1$IDataListItemContext$$$Data.Value.Item2?.BlueEnergy ?? null) ?? 0, $.$$.S.Double);
                                                                                        }), $CQUQoh ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.AddComponentParameter(370, "Stack", "-");
                                                                                        __builder10.CloseComponent();
                                                                                        __builder10.AddMarkupContent(371, "\r\n                                                                ");
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCT.TableChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))), 372);
                                                                                        __builder10.AddComponentParameter(373, "Label", "Generator/Yellow");
                                                                                        __builder10.AddComponentParameter(374, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 6)) + "80"));
                                                                                        __builder10.AddComponentParameter(375, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 6)));
                                                                                        __builder10.AddComponentParameter(376, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box((c.LCFCCD$1$IDataListItemContext$$$Data.Value.Item2?.YellowEnergy ?? null) ?? 0, $.$$.S.Double);
                                                                                        }), $fHqbUd ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.AddComponentParameter(377, "Stack", "-");
                                                                                        __builder10.CloseComponent();
                                                                                        __builder10.AddMarkupContent(378, "\r\n                                                                ");
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCT.TableChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))), 379);
                                                                                        __builder10.AddComponentParameter(380, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT.TableChartFeatures, 7/*TableChartFeatures.Default*/ & ~2/*TableChartFeatures.Chart*/), $.$hDPm.LCFCCT.TableChartFeatures));
                                                                                        __builder10.AddComponentParameter(381, "Label", "Total");
                                                                                        __builder10.AddComponentParameter(382, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 9)) + "80"));
                                                                                        __builder10.AddComponentParameter(383, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 9)));
                                                                                        __builder10.AddComponentParameter(384, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box(c.LCFCCD$1$IDataListItemContext$$$Data.Value.Item3.TotalEnergy, $.$$.S.Double);
                                                                                        }), $tSRgWe ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.AddComponentParameter(385, "Stack", "-");
                                                                                        __builder10.CloseComponent();
                                                                                    }, $vsddPj ??= {"r":65537,"p":[{"n":"__builder10","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                }), $ytwrfd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.DateTime, $.$$.S.ValueTuple$$$$($.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel, $.$uUnI.LCIECM.EnergyMeterDeviceDataClassificationModel))).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.CloseComponent();
                                                                            }), $ITrASh ??= {"r":65537,"p":[{"n":"__builder9","p":7536755}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                            __builder8.CloseComponent();
                                                                        }
                                                                        else 
                                                                        {
                                                                            __builder8.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 386);
                                                                            __builder8.AddComponentParameter(387, "Class", "mg");
                                                                            __builder8.AddComponentParameter(388, "Message", "No data");
                                                                            __builder8.CloseComponent();
                                                                        }
                                                                    }, $ShSmPh ??= {"r":65537,"p":[{"n":"__builder8","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                }), $JbglVj ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                __builder7.CloseComponent();
                                                                __builder7.AddMarkupContent(389, "\r\n                                            ");
                                                                __builder7.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 390);
                                                                __builder7.AddComponentParameter(391, "Class", "bdb");
                                                                __builder7.AddAttribute$3(392, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*open*/ open) =>
                                                                {
                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder8*/ __builder8) =>
                                                                    {
                                                                        __builder8.OpenElement(393, "div");
                                                                        __builder8.AddAttribute$5(394, "class", $.$strNN($.$strNN("row" + " pd-2") + " ") + $.$strNN(($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).op_Implicit(open) ? "bg-card" : "")));
                                                                        __builder8.AddMarkupContent(395, "<div class=\"col-a\"><i class=\"mdi mdi-oil fsz-50\"></i></div>\r\n                                                        ");
                                                                        __builder8.AddMarkupContent(396, "<div class=\"col-10 stack\"><div class=\"mgy-a mgl\"><h3 class=\"mg-0\">Fuel Usage</h3>\r\n                                                                <em class=\"op-8\">Fuel consumed</em></div></div>\r\n                                                        ");
                                                                        __builder8.OpenElement(397, "div");
                                                                        __builder8.AddAttribute$5(398, "class", "col-a stack");
                                                                        __builder8.OpenElement(399, "div");
                                                                        __builder8.AddAttribute$5(400, "class", "mgy-a stack text-right");
                                                                        __builder8.OpenElement(401, "h3");
                                                                        __builder8.AddAttribute$5(402, "class", "cl-message mg-0 nowrap");
                                                                        __builder8.AddContent$4(403, (() =>
                                                                        {
                                                                            var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(0, 1);
                                                                            $handler.AppendFormatted($.$box($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalFuelOutflow(house.Statuses), $.$$.S.Double), null, "f");
                                                                            return $handler.ToStringAndClear                                                                    ();
                                                                        })());
                                                                        __builder8.AddContent$4(404, " L");
                                                                        __builder8.CloseElement();
                                                                        __builder8.CloseElement();
                                                                        __builder8.CloseElement();
                                                                        __builder8.CloseElement();
                                                                    }, $TbQxLa ??= {"r":65537,"p":[{"n":"__builder8","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                }), $Wjakwg ??= {"r":6881395,"p":[{"n":"open","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                __builder7.AddAttribute$3(405, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*_*/ _0) =>
                                                                {
                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder8*/ __builder8) =>
                                                                    {
                                                                        if ($.$sl.SL.Enumerable.Any$1($.$cCKL.LCITCM.TankDataClassificationModel, tanks))
                                                                        {
                                                                            __builder8.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 406);
                                                                            __builder8.AddComponentParameter(407, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 21/*CardFeatures.Default*/ & ~4/*CardFeatures.Shadow*/ & ~8/*CardFeatures.Border*/), $.$hDPm.LCFCCC$1.CardFeatures));
                                                                            __builder8.AddAttribute$3(408, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder9*/ __builder9) =>
                                                                            {
                                                                                __builder9.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$cCKL.LCITCM.TankDataClassificationModel), 409);
                                                                                __builder9.AddComponentParameter(410, "Class", "mgt-10");
                                                                                __builder9.AddComponentParameter(411, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$cCKL.LCITCM.TankDataClassificationModel), tanks));
                                                                                __builder9.AddComponentParameter(412, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$cCKL.LCITCM.TankDataClassificationModel, $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*c*/ c) =>
                                                                                {
                                                                                    return c.StartDate.ToString();
                                                                                }), $tHJxPi ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"c","p":1605809}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.AddComponentParameter(413, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartType, 4/*ChartType.SparkLine*/), $.$hDPm.LCFCCC$3.ChartType));
                                                                                __builder9.AddComponentParameter(414, "YLabel", "Fuel");
                                                                                __builder9.AddComponentParameter(415, "FontColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, theme.Data.TextBackgroundColor));
                                                                                __builder9.AddComponentParameter(416, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 100), $.$$.S.Int32));
                                                                                __builder9.AddAttribute$3(417, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$cCKL.LCITCM.TankDataClassificationModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$cCKL.LCITCM.TankDataClassificationModel))))().$ctor(this, ( (/*context*/ context) =>
                                                                                {
                                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder10*/ __builder10) =>
                                                                                    {
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$cCKL.LCITCM.TankDataClassificationModel), 418);
                                                                                        __builder10.AddComponentParameter(419, "Label", "Volume(L)");
                                                                                        __builder10.AddComponentParameter(420, "BackgroundColor", "#00000000");
                                                                                        __builder10.AddComponentParameter(421, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 4)));
                                                                                        __builder10.AddComponentParameter(422, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$cCKL.LCITCM.TankDataClassificationModel))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box(c.LCFCCD$1$IDataListItemContext$$$Data.UsageQuantity, $.$$.S.Double);
                                                                                        }), $MDdDRj ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$cCKL.LCITCM.TankDataClassificationModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.CloseComponent();
                                                                                    }, $NjCSqj ??= {"r":65537,"p":[{"n":"__builder10","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                }), $kgwjNh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$cCKL.LCITCM.TankDataClassificationModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$cCKL.LCITCM.TankDataClassificationModel)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.CloseComponent();
                                                                                __builder9.AddMarkupContent(423, "\r\n                                                            ");
                                                                                __builder9.OpenElement(424, "h4");
                                                                                __builder9.AddAttribute$5(425, "class", "mgy-2");
                                                                                __builder9.AddContent$3(426, $.$box(house.Parameter.Interval, $.$fPer.LCFCDC.PeriodicInterval));
                                                                                __builder9.AddContent$4(427, " Fuel Outflow");
                                                                                __builder9.CloseElement();
                                                                                __builder9.AddMarkupContent(428, "\r\n                                                            ");
                                                                                __builder9.OpenComponent$1($.$hDPm.LCFCCT.TableChart$$($.$cCKL.LCITCM.TankDataClassificationModel), 429);
                                                                                __builder9.AddComponentParameter(430, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$cCKL.LCITCM.TankDataClassificationModel), tanks));
                                                                                __builder9.AddComponentParameter(431, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$cCKL.LCITCM.TankDataClassificationModel, $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*c*/ c) =>
                                                                                {
                                                                                    return c.StartDate.ToString();
                                                                                }), $rNZyxc ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"c","p":1605809}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.AddComponentParameter(432, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartType, 1/*ChartType.Bar*/), $.$hDPm.LCFCCC$3.ChartType));
                                                                                __builder9.AddComponentParameter(433, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 300), $.$$.S.Int32));
                                                                                __builder9.AddComponentParameter(434, "ChartFontColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, theme.Data.TextBackgroundColor));
                                                                                __builder9.AddComponentParameter(435, "YLabel", "Usage(L)");
                                                                                __builder9.AddComponentParameter(436, "TabsFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT$1.TabsFeatures, 65/*TabsFeatures.Default*/ | 128/*TabsFeatures.ButtonTabs*/), $.$hDPm.LCFCCT$1.TabsFeatures));
                                                                                __builder9.AddComponentParameter(437, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                                                __builder9.AddComponentParameter(438, "ChartFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartFeatures, 127/*ChartFeatures.Default*/ & ~4/*ChartFeatures.XGrid*/ & ~8/*ChartFeatures.YGrid*/), $.$hDPm.LCFCCC$3.ChartFeatures));
                                                                                __builder9.AddAttribute$3(439, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$cCKL.LCITCM.TankDataClassificationModel)))().$ctor(this, ( (/*context*/ context) =>
                                                                                {
                                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder10*/ __builder10) =>
                                                                                    {
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCT.TableChartYAxis$$($.$cCKL.LCITCM.TankDataClassificationModel), 440);
                                                                                        __builder10.AddComponentParameter(441, "Label", "Usage(L)");
                                                                                        __builder10.AddComponentParameter(442, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 5)) + "80"));
                                                                                        __builder10.AddComponentParameter(443, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 5)));
                                                                                        __builder10.AddComponentParameter(444, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$cCKL.LCITCM.TankDataClassificationModel))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box(c.LCFCCD$1$IDataListItemContext$$$Data.UsageQuantity, $.$$.S.Double);
                                                                                        }), $otyofb ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$cCKL.LCITCM.TankDataClassificationModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.AddAttribute$3(445, "TableFooter", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$cCKL.LCITCM.TankDataClassificationModel)))().$ctor(this, ( (/*items*/ items) =>
                                                                                        {
                                                                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder11*/ __builder11) =>
                                                                                            {
                                                                                                __builder11.OpenElement(446, "span");
                                                                                                __builder11.AddAttribute$5(447, "class", "nowrap");
                                                                                                __builder11.AddContent$4(448, (() =>
                                                                                                {
                                                                                                    var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(0, 1);
                                                                                                    $handler.AppendFormatted($.$box($.$sl.SL.Enumerable.Sum$16($.$cCKL.LCITCM.TankDataClassificationModel, items, new ($.$$.S.Func$$$($.$cCKL.LCITCM.TankDataClassificationModel, $.$$.S.Double))().$ctor(this,  (/*c*/ c) =>
                                                                                                    {
                                                                                                        return c.UsageQuantity;
                                                                                                    }, $Kemtkj ??= {"r":1179649,"p":[{"n":"c","p":1605809}],"n":"","d":572301,"h":0,"f":17825794})), $.$$.S.Double), null, "f");
                                                                                                    return $handler.ToStringAndClear                                                                                            ();
                                                                                                })());
                                                                                                __builder11.AddContent$4(449, "L");
                                                                                                __builder11.CloseElement();
                                                                                            }, $hQMLka ??= {"r":65537,"p":[{"n":"__builder11","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                        }), $nMEqBk ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$cCKL.LCITCM.TankDataClassificationModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.CloseComponent();
                                                                                        __builder10.AddMarkupContent(450, "\r\n                                                                ");
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCT.TableChartYAxis$$($.$cCKL.LCITCM.TankDataClassificationModel), 451);
                                                                                        __builder10.AddComponentParameter(452, "Label", "Amount(\u20A6)");
                                                                                        __builder10.AddComponentParameter(453, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT.TableChartFeatures, 7/*TableChartFeatures.Default*/ & ~2/*TableChartFeatures.Chart*/), $.$hDPm.LCFCCT.TableChartFeatures));
                                                                                        __builder10.AddComponentParameter(454, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 6)) + "80"));
                                                                                        __builder10.AddComponentParameter(455, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 6)));
                                                                                        __builder10.AddComponentParameter(456, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$cCKL.LCITCM.TankDataClassificationModel))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box(this.FuelNaira(c.LCFCCD$1$IDataListItemContext$$$Data.UsageQuantity), $.$$.S.Double);
                                                                                        }), $tWBxvc ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$cCKL.LCITCM.TankDataClassificationModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.AddAttribute$3(457, "TableFooter", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$cCKL.LCITCM.TankDataClassificationModel)))().$ctor(this, ( (/*items*/ items) =>
                                                                                        {
                                                                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder11*/ __builder11) =>
                                                                                            {
                                                                                                __builder11.OpenElement(458, "span");
                                                                                                __builder11.AddAttribute$5(459, "class", "nowrap");
                                                                                                __builder11.AddMarkupContent(460, "\u20A6");
                                                                                                __builder11.AddContent$4(461, (() =>
                                                                                                {
                                                                                                    var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(0, 1);
                                                                                                    $handler.AppendFormatted($.$box(this.FuelNaira($.$sl.SL.Enumerable.Sum$16($.$cCKL.LCITCM.TankDataClassificationModel, items, new ($.$$.S.Func$$$($.$cCKL.LCITCM.TankDataClassificationModel, $.$$.S.Double))().$ctor(this,  (/*c*/ c) =>
                                                                                                    {
                                                                                                        return c.UsageQuantity;
                                                                                                    }, $BTTEdg ??= {"r":1179649,"p":[{"n":"c","p":1605809}],"n":"","d":572301,"h":0,"f":17825794}))), $.$$.S.Double), null, "N");
                                                                                                    return $handler.ToStringAndClear                                                                                            ();
                                                                                                })());
                                                                                                __builder11.CloseElement();
                                                                                            }, $rDMEha ??= {"r":65537,"p":[{"n":"__builder11","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                        }), $vgzPil ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$cCKL.LCITCM.TankDataClassificationModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.CloseComponent();
                                                                                    }, $bqPAZe ??= {"r":65537,"p":[{"n":"__builder10","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                }), $CxhEvb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$cCKL.LCITCM.TankDataClassificationModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.CloseComponent();
                                                                            }), $OMuSia ??= {"r":65537,"p":[{"n":"__builder9","p":7536755}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                            __builder8.CloseComponent();
                                                                        }
                                                                        else 
                                                                        {
                                                                            __builder8.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 462);
                                                                            __builder8.AddComponentParameter(463, "Class", "mg");
                                                                            __builder8.AddComponentParameter(464, "Message", "No data");
                                                                            __builder8.CloseComponent();
                                                                        }
                                                                    }, $VBqSWj ??= {"r":65537,"p":[{"n":"__builder8","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                }), $OeErcc ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                __builder7.CloseComponent();
                                                                __builder7.AddMarkupContent(465, "\r\n                                            ");
                                                                __builder7.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 466);
                                                                __builder7.AddComponentParameter(467, "Class", "bdb");
                                                                __builder7.AddAttribute$3(468, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*open*/ open) =>
                                                                {
                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder8*/ __builder8) =>
                                                                    {
                                                                        __builder8.OpenElement(469, "div");
                                                                        __builder8.AddAttribute$5(470, "class", $.$strNN($.$strNN("row" + " pd-2") + " ") + $.$strNN(($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).op_Implicit(open) ? "bg-card" : "")));
                                                                        __builder8.AddMarkupContent(471, "<div class=\"col-a\"><i class=\"mdi mdi-fuel fsz-50\"></i></div>\r\n                                                        ");
                                                                        __builder8.AddMarkupContent(472, "<div class=\"col-10 stack\"><div class=\"mgy-a mgl\"><h3 class=\"mg-0\">Fuel Delivery</h3>\r\n                                                                <em class=\"op-8\">Fuel infow to tank</em></div></div>\r\n                                                        ");
                                                                        __builder8.OpenElement(473, "div");
                                                                        __builder8.AddAttribute$5(474, "class", "col-a stack");
                                                                        __builder8.OpenElement(475, "div");
                                                                        __builder8.AddAttribute$5(476, "class", "mgy-a stack text-right");
                                                                        __builder8.OpenElement(477, "h3");
                                                                        __builder8.AddAttribute$5(478, "class", "cl-message mg-0");
                                                                        __builder8.AddContent$4(479, (() =>
                                                                        {
                                                                            var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(0, 1);
                                                                            $handler.AppendFormatted($.$box($.$mXnX.LCIPCM.PowerHouseDeviceStatusModelExtension.GetTotalFuelInflow(house.Statuses), $.$$.S.Double), null, "f");
                                                                            return $handler.ToStringAndClear                                                                    ();
                                                                        })());
                                                                        __builder8.AddContent$4(480, "L");
                                                                        __builder8.CloseElement();
                                                                        __builder8.CloseElement();
                                                                        __builder8.CloseElement();
                                                                        __builder8.CloseElement();
                                                                    }, $drjKog ??= {"r":65537,"p":[{"n":"__builder8","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                }), $AZJFBj ??= {"r":6881395,"p":[{"n":"open","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                __builder7.AddAttribute$3(481, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*_*/ _0) =>
                                                                {
                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder8*/ __builder8) =>
                                                                    {
                                                                        if ($.$sl.SL.Enumerable.Any$1($.$cCKL.LCITCM.TankDataClassificationModel, tanks))
                                                                        {
                                                                            __builder8.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 482);
                                                                            __builder8.AddComponentParameter(483, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 21/*CardFeatures.Default*/ & ~4/*CardFeatures.Shadow*/ & ~8/*CardFeatures.Border*/), $.$hDPm.LCFCCC$1.CardFeatures));
                                                                            __builder8.AddAttribute$3(484, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder9*/ __builder9) =>
                                                                            {
                                                                                __builder9.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$cCKL.LCITCM.TankDataClassificationModel), 485);
                                                                                __builder9.AddComponentParameter(486, "Class", "mgt-10");
                                                                                __builder9.AddComponentParameter(487, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$cCKL.LCITCM.TankDataClassificationModel), tanks));
                                                                                __builder9.AddComponentParameter(488, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$cCKL.LCITCM.TankDataClassificationModel, $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*c*/ c) =>
                                                                                {
                                                                                    return c.StartDate.ToString();
                                                                                }), $hkcXha ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"c","p":1605809}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.AddComponentParameter(489, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartType, 4/*ChartType.SparkLine*/), $.$hDPm.LCFCCC$3.ChartType));
                                                                                __builder9.AddComponentParameter(490, "YLabel", "Fuel");
                                                                                __builder9.AddComponentParameter(491, "FontColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, theme.Data.TextBackgroundColor));
                                                                                __builder9.AddComponentParameter(492, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 100), $.$$.S.Int32));
                                                                                __builder9.AddAttribute$3(493, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$cCKL.LCITCM.TankDataClassificationModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$cCKL.LCITCM.TankDataClassificationModel))))().$ctor(this, ( (/*context*/ context) =>
                                                                                {
                                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder10*/ __builder10) =>
                                                                                    {
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$cCKL.LCITCM.TankDataClassificationModel), 494);
                                                                                        __builder10.AddComponentParameter(495, "Label", "Volume(L)");
                                                                                        __builder10.AddComponentParameter(496, "BackgroundColor", "#00000000");
                                                                                        __builder10.AddComponentParameter(497, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 2)));
                                                                                        __builder10.AddComponentParameter(498, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$cCKL.LCITCM.TankDataClassificationModel))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box(c.LCFCCD$1$IDataListItemContext$$$Data.DeliveryQuantity, $.$$.S.Double);
                                                                                        }), $ZSsLQk ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$cCKL.LCITCM.TankDataClassificationModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.CloseComponent();
                                                                                    }, $GERshj ??= {"r":65537,"p":[{"n":"__builder10","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                }), $MVYUse ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$cCKL.LCITCM.TankDataClassificationModel, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$cCKL.LCITCM.TankDataClassificationModel)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.CloseComponent();
                                                                                __builder9.AddMarkupContent(499, "\r\n                                                            ");
                                                                                __builder9.OpenElement(500, "h4");
                                                                                __builder9.AddAttribute$5(501, "class", "mgy-2");
                                                                                __builder9.AddContent$3(502, $.$box(house.Parameter.Interval, $.$fPer.LCFCDC.PeriodicInterval));
                                                                                __builder9.AddContent$4(503, " Fuel Inflow");
                                                                                __builder9.CloseElement();
                                                                                __builder9.AddMarkupContent(504, "\r\n                                                            ");
                                                                                __builder9.OpenComponent$1($.$hDPm.LCFCCT.TableChart$$($.$cCKL.LCITCM.TankDataClassificationModel), 505);
                                                                                __builder9.AddComponentParameter(506, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$cCKL.LCITCM.TankDataClassificationModel), tanks));
                                                                                __builder9.AddComponentParameter(507, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$cCKL.LCITCM.TankDataClassificationModel, $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*c*/ c) =>
                                                                                {
                                                                                    return c.StartDate.ToString();
                                                                                }), $ezKMbd ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"c","p":1605809}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.AddComponentParameter(508, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartType, 1/*ChartType.Bar*/), $.$hDPm.LCFCCC$3.ChartType));
                                                                                __builder9.AddComponentParameter(509, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 300), $.$$.S.Int32));
                                                                                __builder9.AddComponentParameter(510, "ChartFontColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, theme.Data.TextBackgroundColor));
                                                                                __builder9.AddComponentParameter(511, "YLabel", "Volume(L)");
                                                                                __builder9.AddComponentParameter(512, "TabsFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT$1.TabsFeatures, 65/*TabsFeatures.Default*/ | 128/*TabsFeatures.ButtonTabs*/), $.$hDPm.LCFCCT$1.TabsFeatures));
                                                                                __builder9.AddComponentParameter(513, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                                                __builder9.AddComponentParameter(514, "ChartFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartFeatures, 127/*ChartFeatures.Default*/ & ~4/*ChartFeatures.XGrid*/ & ~8/*ChartFeatures.YGrid*/), $.$hDPm.LCFCCC$3.ChartFeatures));
                                                                                __builder9.AddAttribute$3(515, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$cCKL.LCITCM.TankDataClassificationModel)))().$ctor(this, ( (/*context*/ context) =>
                                                                                {
                                                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder10*/ __builder10) =>
                                                                                    {
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCT.TableChartYAxis$$($.$cCKL.LCITCM.TankDataClassificationModel), 516);
                                                                                        __builder10.AddComponentParameter(517, "Label", "Delivery(L)");
                                                                                        __builder10.AddComponentParameter(518, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 3)) + "80"));
                                                                                        __builder10.AddComponentParameter(519, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 3)));
                                                                                        __builder10.AddComponentParameter(520, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$cCKL.LCITCM.TankDataClassificationModel))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box(c.LCFCCD$1$IDataListItemContext$$$Data.DeliveryQuantity, $.$$.S.Double);
                                                                                        }), $zUVkvg ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$cCKL.LCITCM.TankDataClassificationModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.AddAttribute$3(521, "TableFooter", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$cCKL.LCITCM.TankDataClassificationModel)))().$ctor(this, ( (/*items*/ items) =>
                                                                                        {
                                                                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder11*/ __builder11) =>
                                                                                            {
                                                                                                __builder11.OpenElement(522, "span");
                                                                                                __builder11.AddAttribute$5(523, "class", "nowrap");
                                                                                                __builder11.AddContent$4(524, (() =>
                                                                                                {
                                                                                                    var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(0, 1);
                                                                                                    $handler.AppendFormatted($.$box($.$sl.SL.Enumerable.Sum$16($.$cCKL.LCITCM.TankDataClassificationModel, items, new ($.$$.S.Func$$$($.$cCKL.LCITCM.TankDataClassificationModel, $.$$.S.Double))().$ctor(this,  (/*c*/ c) =>
                                                                                                    {
                                                                                                        return c.DeliveryQuantity;
                                                                                                    }, $FEmkbk ??= {"r":1179649,"p":[{"n":"c","p":1605809}],"n":"","d":572301,"h":0,"f":17825794})), $.$$.S.Double), null, "f");
                                                                                                    return $handler.ToStringAndClear                                                                                            ();
                                                                                                })());
                                                                                                __builder11.AddContent$4(525, "L");
                                                                                                __builder11.CloseElement();
                                                                                            }, $bOczgg ??= {"r":65537,"p":[{"n":"__builder11","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                        }), $vhWulc ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$cCKL.LCITCM.TankDataClassificationModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.CloseComponent();
                                                                                        __builder10.AddMarkupContent(526, "\r\n                                                                ");
                                                                                        __builder10.OpenComponent$1($.$hDPm.LCFCCT.TableChartYAxis$$($.$cCKL.LCITCM.TankDataClassificationModel), 527);
                                                                                        __builder10.AddComponentParameter(528, "Label", "Amount(\u20A6)");
                                                                                        __builder10.AddComponentParameter(529, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT.TableChartFeatures, 7/*TableChartFeatures.Default*/ & ~2/*TableChartFeatures.Chart*/), $.$hDPm.LCFCCT.TableChartFeatures));
                                                                                        __builder10.AddComponentParameter(530, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 6)) + "80"));
                                                                                        __builder10.AddComponentParameter(531, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.System.Array.$ReadT1.call(theme.Data.ChartColors, 6)));
                                                                                        __builder10.AddComponentParameter(532, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$cCKL.LCITCM.TankDataClassificationModel))().$ctor(this, ( (/*c*/ c) =>
                                                                                        {
                                                                                            return $.$box(this.FuelNaira(c.LCFCCD$1$IDataListItemContext$$$Data.UsageQuantity), $.$$.S.Double);
                                                                                        }), $PuOAae ??= {"r":131073,"p":[{"n":"c","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$cCKL.LCITCM.TankDataClassificationModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.AddAttribute$3(533, "TableFooter", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$cCKL.LCITCM.TankDataClassificationModel)))().$ctor(this, ( (/*items*/ items) =>
                                                                                        {
                                                                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder11*/ __builder11) =>
                                                                                            {
                                                                                                __builder11.OpenElement(534, "span");
                                                                                                __builder11.AddAttribute$5(535, "class", "nowrap");
                                                                                                __builder11.AddMarkupContent(536, "\u20A6");
                                                                                                __builder11.AddContent$4(537, (() =>
                                                                                                {
                                                                                                    var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(0, 1);
                                                                                                    $handler.AppendFormatted($.$box(this.FuelNaira($.$sl.SL.Enumerable.Sum$16($.$cCKL.LCITCM.TankDataClassificationModel, items, new ($.$$.S.Func$$$($.$cCKL.LCITCM.TankDataClassificationModel, $.$$.S.Double))().$ctor(this,  (/*c*/ c) =>
                                                                                                    {
                                                                                                        return c.DeliveryQuantity;
                                                                                                    }, $cjZnIa ??= {"r":1179649,"p":[{"n":"c","p":1605809}],"n":"","d":572301,"h":0,"f":17825794}))), $.$$.S.Double), null, "N");
                                                                                                    return $handler.ToStringAndClear                                                                                            ();
                                                                                                })());
                                                                                                __builder11.CloseElement();
                                                                                            }, $rwTTZf ??= {"r":65537,"p":[{"n":"__builder11","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                        }), $kamyqa ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$cCKL.LCITCM.TankDataClassificationModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                        __builder10.CloseComponent();
                                                                                    }, $uvzbvj ??= {"r":65537,"p":[{"n":"__builder10","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                                }), $ZYKUoc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$cCKL.LCITCM.TankDataClassificationModel).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                                __builder9.CloseComponent();
                                                                            }), $lAyFSj ??= {"r":65537,"p":[{"n":"__builder9","p":7536755}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                            __builder8.CloseComponent();
                                                                        }
                                                                        else 
                                                                        {
                                                                            __builder8.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 538);
                                                                            __builder8.AddComponentParameter(539, "Class", "mg");
                                                                            __builder8.AddComponentParameter(540, "Message", "No data");
                                                                            __builder8.CloseComponent();
                                                                        }
                                                                    }, $yaCCZd ??= {"r":65537,"p":[{"n":"__builder8","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                                }), $buxjse ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                                __builder7.CloseComponent();
                                                            }), $MSSJId ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":572301,"h":0,"f":17825794}));
                                                            __builder6.CloseComponent();
                                                        }), $Qzxrjd ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":572301,"h":0,"f":17825794}));
                                                        __builder5.CloseComponent();
                                                    }, $PHbZfh ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                                }), $uNiYyd ??= {"r":6881395,"p":[{"n":"theme","p":$.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                                __builder4.CloseComponent();
                                            }, $WWwgWh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                        }), $zTmDOh ??= {"r":6881395,"p":[{"n":"sheet","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                        __builder3.AddAttribute$3(541, "SheetContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*__*/ __) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                            {
                                                __builder4.AddMarkupContent(542, "<h2 class=\"text-center\">Report Settings</h2>\r\n                                ");
                                                __builder4.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$($.$fPer.LCFCR$1.ReportParameterModel), 543);
                                                __builder4.AddComponentParameter(544, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$1.ReportParameterModel, house.Parameter));
                                                __builder4.AddComponentParameter(545, "OnSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$fPer.LCFCR$1.ReportParameterModel), $.$mac.MAC.EventCallback.Factory.Create$8($.$fPer.LCFCR$1.ReportParameterModel, this, new ($.$$.S.Action$$($.$fPer.LCFCR$1.ReportParameterModel))().$ctor(this,  (/*v*/ v) =>
                                                {
                                                    return house.Load();
                                                }, $XbZmRi ??= {"r":65537,"p":[{"n":"v","p":56068438}],"n":"","d":572301,"h":0,"f":17825794}))));
                                                __builder4.AddComponentParameter(546, "Class", "mgx mgb");
                                                __builder4.AddAttribute$3(547, "Submit", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 548);
                                                    __builder5.AddComponentParameter(549, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                    __builder5.AddComponentParameter(550, "Class", "corner-5 !corner-1 miwx-2");
                                                    __builder5.AddComponentParameter(551, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 256/*ButtonFeatures.Small*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                                    __builder5.AddComponentParameter(552, "type", "submit");
                                                    __builder5.AddAttribute$3(553, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                                    {
                                                        __builder6.AddContent$4(554, "Load");
                                                    }), $hSHIhi ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":572301,"h":0,"f":17825794}));
                                                    __builder5.CloseComponent();
                                                }), $Kfeawh ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":572301,"h":0,"f":17825794}));
                                                __builder4.CloseComponent();
                                            }, $zRVNSk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                        }), $TPOyxk ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                        __builder3.CloseComponent();
                                    }, $qbmtke ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                }), $HnvESj ??= {"r":6881395,"p":[{"n":"______","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                __builder2.AddAttribute$3(555, "ChildPages", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 556);
                                    __builder3.AddComponentParameter(557, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN(house.Model.Name) + " Tank"));
                                    __builder3.AddAttribute$3(558, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddContent$4(559, house.Model.Name);
                                            __builder4.AddContent$4(560, " Tank");
                                        }, $JVCSvj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                    }), $nuLFjl ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(561, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddMarkupContent(562, "<i class=\"d-block mdi mdi-gas-cylinder wx-03 hx-03 bg-warning round mgc-a flex\"></i>");
                                        }, $YQoFgb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                    }), $mhvNij ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(563, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenElement(564, "LivingThing.Core.IOT.TankTalks.Client.Shared.TankTalksTank");
                                            __builder4.AddAttribute$5(565, "TankId", house.Model.FuelTankId);
                                            __builder4.CloseElement();
                                        }, $aRJLvi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                    }), $JsRWka ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(566, "\r\n                        ");
                                    __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 567);
                                    __builder3.AddComponentParameter(568, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN(house.Model.Name) + " Grid"));
                                    __builder3.AddComponentParameter(569, "Class", "pd");
                                    __builder3.AddAttribute$3(570, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddContent$4(571, house.Model.Name);
                                            __builder4.AddContent$4(572, " Grid");
                                        }, $NzsWfe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                    }), $khLCbj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(573, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddMarkupContent(574, "<i class=\"d-block mdi mdi-flash wx-03 hx-03 bg-info round mgc-a flex\"></i>");
                                        }, $UnwPMe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                    }), $YrrYqf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(575, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenComponent$1($.$eHSC.LCIECS.EnergyMeterDevice, 576);
                                            __builder4.AddComponentParameter(577, "MeterId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, house.Model.GridMeterId));
                                            __builder4.CloseComponent();
                                        }, $pMKVvh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                    }), $giPMOj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(578, "\r\n                        ");
                                    __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 579);
                                    __builder3.AddComponentParameter(580, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN(house.Model.Name) + " Generator"));
                                    __builder3.AddComponentParameter(581, "Class", "pd");
                                    __builder3.AddAttribute$3(582, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddContent$4(583, house.Model.Name);
                                            __builder4.AddContent$4(584, " Generator");
                                        }, $eLgXke ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                    }), $HteFEc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(585, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddMarkupContent(586, "<i class=\"d-block mdi mdi-engine wx-03 hx-03 bg-message round mgc-a flex\"></i>");
                                        }, $tgChWk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                    }), $bcrKcc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(587, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenComponent$1($.$eHSC.LCIECS.EnergyMeterDevice, 588);
                                            __builder4.AddComponentParameter(589, "MeterId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, house.Model.GeneratorMeterId));
                                            __builder4.CloseComponent();
                                        }, $KSxhwg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":572301,"h":0,"f":17825794});
                                    }), $DtPkjb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":572301,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }), $QJsXja ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":572301,"h":0,"f":17825794}));
                                __builder2.CloseComponent();
                            }
                        }
                    }), $uwiyEh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":572301,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                //else { ... }
            }
            //--TRIMMABLE-BOUNDARY-END(25770376077)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180441485)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180441485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180441485)
            
            //--TRIMMABLE-BOUNDARY-START(17180441485)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(17180441485)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(124554623885)
                this.ViewModel = null;
                //--TRIMMABLE-BOUNDARY-END(124554623885)
                
                //--TRIMMABLE-BOUNDARY-START(90194885517)
                this.RenderingProvider = null;
                //--TRIMMABLE-BOUNDARY-END(90194885517)
                
                //--TRIMMABLE-BOUNDARY-START(21475408781)
                this.BasePath = "PowerHouse/App";
                //--TRIMMABLE-BOUNDARY-END(21475408781)
                
            }
            static $h = 572301;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$qKfs.LCIPCV.PowerHousesViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85899918221),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245212557,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 572301,
      "h": 85899918221,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(85899918221),
//--TRIMMABLE-BOUNDARY-START(124554623885),
    {
      "p": 703373,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425081741,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964689293,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 572301,
      "h": 124554623885,
      "f": 2129921,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124554623885),
//--TRIMMABLE-BOUNDARY-START(90194885517),
    {
      "p": 5463464,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835147149,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374754701,
        "f": 83886081
      },
      "n": "RenderingProvider",
      "d": 572301,
      "h": 90194885517,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90194885517),
//--TRIMMABLE-BOUNDARY-START(21475408781),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655277965,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784820109,
        "f": 83886081
      },
      "n": "BasePath",
      "d": 572301,
      "h": 21475408781,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475408781)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(120259656589),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 572301,
      "h": 120259656589,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120259656589),
//--TRIMMABLE-BOUNDARY-START(73015016333),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 572301,
      "h": 73015016333,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015016333),
//--TRIMMABLE-BOUNDARY-START(81604950925),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 572301,
      "h": 81604950925,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(81604950925),
//--TRIMMABLE-BOUNDARY-START(68720049037),
    {
      "r": 1310721,
      "p": [
        {
          "n": "time",
          "p": 186646529
        }
      ],
      "n": "HMS",
      "d": 572301,
      "h": 68720049037,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720049037),
//--TRIMMABLE-BOUNDARY-START(128849591181),
    {
      "r": 1310721,
      "p": [
        {
          "n": "kwh",
          "p": 1179649
        }
      ],
      "n": "Wh",
      "d": 572301,
      "h": 128849591181,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128849591181),
//--TRIMMABLE-BOUNDARY-START(77309983629),
    {
      "r": 1310721,
      "p": [
        {
          "n": "kwh",
          "p": 1179649
        }
      ],
      "n": "Naira",
      "d": 572301,
      "h": 77309983629,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77309983629),
//--TRIMMABLE-BOUNDARY-START(30065343373),
    {
      "r": 1179649,
      "p": [
        {
          "n": "l",
          "p": 1179649
        }
      ],
      "n": "FuelNaira",
      "d": 572301,
      "h": 30065343373,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065343373),
//--TRIMMABLE-BOUNDARY-START(25770376077),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 572301,
      "h": 25770376077,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770376077)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180441485),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 572301,
      "h": 17180441485,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180441485)
  ],
  "h": 572301,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/PowerHouse",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/PowerHouse/{Page}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/PowerHouse/{Page}/{Action}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/PowerHouse/App",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/PowerHouse/App/{Page}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/PowerHouse/App/{Page}/{Action}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.PowerHouse.Client.Pages.App`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}PowerHouse${separator}Client${separator}Pages${separator}App`; }
        });
        //--TRIMMABLE-BOUNDARY-END(572301)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Net.Http.Headers", "NetJs.Microsoft.AspNetCore.WebUtilities", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor", "NetJs.LivingThing.Core.IOT.Devices.Gateway", "NetJs.LivingThing.Core.IOT.TankTalks.Common", "NetJs.LivingThing.Core.IOT.Devices.TankTalks", "NetJs.LivingThing.Core.IOT.EnergyMeter.Common", "NetJs.LivingThing.Core.IOT.EnergyMeter.Client.Blazor", "NetJs.LivingThing.Core.IOT.PowerHouse.Common", "NetJs.LivingThing.Core.IOT.TankTalks.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(48013)
